

# Generated at 2022-06-18 00:41:22.372009
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:30.279028
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name

    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = build_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2

# Generated at 2022-06-18 00:41:37.987147
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:44.343338
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = """
        class A:
            def __init__(self):
                super()
    """
    tree = get_ast(source_to_unicode(source))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == """
        class A:
            def __init__(self):
                super(A, self)
    """

# Generated at 2022-06-18 00:41:53.653720
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class Test:
            def __init__(self):
                super()
    """)

    expected_source = source_to_unicode("""
        class Test:
            def __init__(self):
                super(Test, self)
    """)

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert expected_source == ast.dump(tree)

# Generated at 2022-06-18 00:42:03.844038
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-18 00:42:09.212244
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:13.638821
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:20.378276
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:27.221033
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def f(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def f(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:34.531002
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from ..utils.source_code_helpers import get_source_code_from_ast_node


# Generated at 2022-06-18 00:42:42.772726
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:42:50.827277
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def f(self):
                super()
    """)
    expected_source = source_to_unicode("""
        class A:
            def f(self):
                super(A, self)
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert expected_source == astor.to_source(tree).strip()

# Generated at 2022-06-18 00:43:02.195309
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    # Test 1: super()
    tree = ast_call(
        func=ast_name(id='super'),
        args=[]
    )

    func = ast_function_def(
        name='func',
        args=ast_arguments(
            args=[ast_arg(arg='self')]
        ),
        body=[tree]
    )

    cls = ast_class_def(
        name='Cls',
        body=[func]
    )

    tree = cls


# Generated at 2022-06-18 00:43:04.103984
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:43:11.050090
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:17.250292
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Test(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id='Cls'), ast.Name(id='self')]
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:43:28.074580
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return

            try:
                cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
            except NodeNotFound:
                warn('super() outside of class')
                return


# Generated at 2022-06-18 00:43:35.284082
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:44.307610
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected_source = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(expected_source, tree)

# Generated at 2022-06-18 00:43:54.214515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:05.037932
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_args
    from ..utils.ast_helpers import get_ast_node_func

    node = ast.parse('super()')
    node = node.body[0]
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.Call)
    assert get_ast_node_name(node.func) == 'super'
    assert not get_ast_node_args(node)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert get_ast_node_name(node.func) == 'super'
    assert get_ast_node_args

# Generated at 2022-06-18 00:44:14.730784
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    tree = ast_class_def(
        name='Cls',
        body=[
            ast_function_def(
                name='method',
                body=[
                    ast_call(
                        func=ast_name(id='super')
                    )
                ]
            )
        ]
    )

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()


# Generated at 2022-06-18 00:44:21.538648
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:23.777416
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:44:27.628546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast_node_at_line
    from ..utils.helpers import get_code
    from .base import BaseNodeTransformer
    from .super_without_arguments import SuperWithoutArgumentsTransformer


# Generated at 2022-06-18 00:44:35.197359
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:42.911342
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:44:51.071472
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree_to_str(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:44:57.133361
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    expected_tree = get_ast(source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """))

    assert tree_to_str(tree) == tree_to_str(expected_tree)

# Generated at 2022-06-18 00:45:09.807499
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:45:15.940240
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:45:16.458750
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:45:23.023021
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:45:30.682146
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast
    from ..utils.helpers import get_func_args
    from ..utils.helpers import get_func_name

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert get_func_name(tree.body[0].body[0]) == 'super'
    assert get_func_args(tree.body[0].body[0]) == ['A', 'self']

# Generated at 2022-06-18 00:45:31.153293
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:45:32.690888
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:45:36.621224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:45.972993
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert_equal_ignore_ws(source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """), tree)

# Generated at 2022-06-18 00:45:52.472997
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:09.227961
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:13.732580
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:20.259623
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:28.458662
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    tree = ast_call(ast_name('super'))
    func = ast_function_def(args=ast_name('self'))
    cls = ast_class_def(name='Cls')
    func.parent = cls
    tree.parent = func

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert source_to_unicode(tree) == 'super(Cls, self)'

# Generated at 2022-06-18 00:46:31.012891
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of


# Generated at 2022-06-18 00:46:38.293563
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .. import compile_src
    from ..utils.helpers import get_ast_node

    src = """
    class A:
        def __init__(self):
            super()
    """
    tree = compile_src(source_to_unicode(src), 2, 7)
    node = get_ast_node(tree, ast.Call)
    assert node.args[0].id == 'A'
    assert node.args[1].id == 'self'

# Generated at 2022-06-18 00:46:49.413368
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:46:51.692100
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:46:59.500520
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer.tree_changed
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:47:04.156034
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:47:26.584413
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:27.145052
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:33.666245
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:47:43.432108
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def f(self):
                super()
    """)
    tree = get_ast(source)
    node = tree.body[0].body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not len(node.args)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert isinstance(node, ast.Call)

# Generated at 2022-06-18 00:47:43.839194
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:48.816589
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast_node_at_line
    from ..utils.helpers import get_ast_of_code
    from ..utils.source import get_source_of_node


# Generated at 2022-06-18 00:47:51.547420
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-18 00:47:58.548565
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    expected_ast = get_ast('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert compare_ast(tree, expected_ast)

# Generated at 2022-06-18 00:48:03.393407
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    tree = ast_class_def(
        'Cls',
        ast_function_def(
            'func',
            ast_call('super')
        )
    )

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert source_to_unicode(tree) == 'class Cls:\n    def func(self):\n        super(Cls, self)\n'

# Generated at 2022-06-18 00:48:06.883973
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class Foo:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class Foo:
            def __init__(self):
                super(Foo, self)
    """)

# Generated at 2022-06-18 00:48:56.370357
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:57.194706
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:49:04.518677
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:49:11.579218
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    tree = ast.Module([
        ast_class_def('Cls', [
            ast_function_def('__init__', [ast_name('self')], [
                ast_call('super'),
            ]),
        ]),
    ])

    expected_tree = ast.Module([
        ast_class_def('Cls', [
            ast_function_def('__init__', [ast_name('self')], [
                ast_call('super', [ast_name('Cls'), ast_name('self')]),
            ]),
        ]),
    ])

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
   

# Generated at 2022-06-18 00:49:17.269789
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as parse
    from ..utils.source import source_to_ast_as_string as to_string

    source = u('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert to_string(tree) == u('''
    class A:
        def __init__(self):
            super(A, self)
    ''')

# Generated at 2022-06-18 00:49:21.479532
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_func_arg_names

    source = """
    class Cls:
        def __init__(self):
            super()
    """
    tree = ast.parse(source_to_unicode(source))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert get_ast_node_name(tree.body[0].body[0].value.args[0]) == 'Cls'
    assert get_ast_node_name(tree.body[0].body[0].value.args[1]) == 'self'

# Generated at 2022-06-18 00:49:21.942998
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:49:28.587218
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:49:36.626085
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:49:43.940277
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_functiondef, ast_name
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of

    class TestClass(object):
        def __init__(self):
            super()

    tree = ast.parse(inspect.getsource(TestClass))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    # Check if the tree has changed
    assert transformer.tree_changed is True

    # Check if the super() call has been replaced
    super_call = get_closest_parent_of(tree, ast_call(ast_name('super')), ast.Call)
    assert get_ast_