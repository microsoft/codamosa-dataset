

# Generated at 2022-06-18 00:41:14.824218
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:21.546574
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast_call('super'))

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-18 00:41:22.366680
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:28.974236
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_source

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast_from_source(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer.tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:41:36.729356
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:38.922948
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:41:46.809769
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:41:55.916712
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast, get_name_node, get_call_node
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode('''
        class Cls:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    node = get_call_node(tree, 'super')
    SuperWithoutArgumentsTransformer(tree).visit(node)
    expected = source_to_unicode('''
        class Cls:
            def __init__(self):
                super(Cls, self)
    ''')
    assert_equal_ignore_ws(expected, tree)

# Generated at 2022-06-18 00:42:00.672781
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:42:03.027917
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_node_of_class


# Generated at 2022-06-18 00:42:12.488392
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert_equal_ignore_ws(expected, tree)

# Generated at 2022-06-18 00:42:19.434380
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:21.593850
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..transforms.super_without_arguments import SuperWithoutArgumentsTransformer


# Generated at 2022-06-18 00:42:29.250738
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:38.695492
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def, ast_arguments
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    tree = get_ast(source)
    node = get_closest_parent_of(tree, ast_call(ast_name('super')), ast.Call)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'A'

# Generated at 2022-06-18 00:42:39.330270
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:50.475954
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert not len(node.value.args)

    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert isinstance(node.value, ast.Call)

# Generated at 2022-06-18 00:43:01.540211
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:43:11.148799
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class Cls:
            def method(self):
                super()
    """)
    tree = get_ast(source)

    node = ast_call(func=ast_name(id='super'), args=[])
    func = ast_functiondef(name='method', args=ast_arguments(args=[ast_arg(arg='self')]))
    cls = ast_classdef(name='Cls')

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)


# Generated at 2022-06-18 00:43:20.281590
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_classdef, ast_funcdef, ast_name, ast_arguments

    source = source_to_unicode("""
        class Foo:
            def __init__(self):
                super()
    """)

    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    expected_tree = ast.parse(source_to_unicode("""
        class Foo:
            def __init__(self):
                super(Foo, self)
    """))

    assert tree == expected_tree

# Generated at 2022-06-18 00:43:35.173090
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_all_nodes_of_type

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    node = get_all_nodes_of_type(tree, ast.Call)[0]
    assert get_ast_node_name(node) == 'super()'

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert get_ast_node_name(node)

# Generated at 2022-06-18 00:43:36.961915
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:43:44.697381
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A(object):
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode('''
        class A(object):
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:50.316366
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast, dump_ast
    from ..utils.helpers import get_func_arg_names
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert dump_ast(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')


# Generated at 2022-06-18 00:43:57.189791
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected_source = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert_equal_ignore_ws(expected_source, tree)

# Generated at 2022-06-18 00:43:58.633212
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-18 00:44:05.356453
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:44:08.674291
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:44:11.063991
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import ast_to_source as to_source


# Generated at 2022-06-18 00:44:16.051120
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def a(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def a(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:44:35.371880
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    class Dummy(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    tree = ast.parse(source_to_unicode('''
    class Cls:
        def method(self):
            super()
    '''))

    expected = ast.parse(source_to_unicode('''
    class Cls:
        def method(self):
            super(Cls, self)
    '''))

    node = get_closest_parent_of(tree, ast_call(ast_name('super')), ast.FunctionDef)

# Generated at 2022-06-18 00:44:40.599108
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])"

# Generated at 2022-06-18 00:44:50.475679
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import print_tree

    tree = compile_to_ast("""
    class A:
        def __init__(self):
            super().__init__()
    """)
    print_tree(tree)
    SuperWithoutArgumentsTransformer().visit(tree)
    print_tree(tree)
    assert get_ast_node_name(tree.body[0].body[0].body[0].args[0]) == 'A'
    assert get_ast_node_name(tree.body[0].body[0].body[0].args[1]) == 'self'

# Generated at 2022-06-18 00:44:56.843482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str
    from ..utils.ast_helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert_equal_ignore_ws(tree_to_str(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:45:04.143496
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:14.518994
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.helpers import get_ast_node_at_line
    from ..utils.helpers import get_code_node_at_line
    from ..utils.helpers import get_code_node_range
    from ..utils.helpers import get_ast_node_range
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_code_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_code_node_type
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_code_node_lineno
   

# Generated at 2022-06-18 00:45:22.446733
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:30.095426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    expected_source = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(astor.to_source(tree), expected_source)

# Generated at 2022-06-18 00:45:33.498003
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    source = """
    class A:
        def __init__(self):
            super()
    """
    tree = source_to_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    assert transformer._tree.body[0].body[0].args.args[1].id == 'self'

# Generated at 2022-06-18 00:45:37.320694
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class C:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class C:
            def __init__(self):
                super(C, self)
    """)

# Generated at 2022-06-18 00:45:52.194834
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:57.629914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    code = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert code_gen.to_source(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:05.812996
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(tree_to_str(tree), source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    '''))

# Generated at 2022-06-18 00:46:13.512804
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:14.049069
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:46:21.085911
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    expected = source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')
    assert node_to_str(tree) == expected

# Generated at 2022-06-18 00:46:28.218392
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:32.973206
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-18 00:46:40.569736
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected_source = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(astor.to_source(tree).strip(), expected_source.strip())

# Generated at 2022-06-18 00:46:48.424106
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:47:08.919907
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_func, ast_class, ast_arguments
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of

    source = source_to_unicode('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = ast.parse(source)
    node = get_closest_parent_of(tree, ast_call(ast_name('super'), []), ast.FunctionDef)
    assert get_ast_node_name(node) == '__init__'


# Generated at 2022-06-18 00:47:17.181482
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_parser import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:47:27.487932
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_classdef, ast_functiondef, ast_name
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_child_nodes_of_type
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast_node_name

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    cls = get_child_nodes_of_type(tree, ast.ClassDef)[0]

# Generated at 2022-06-18 00:47:29.782466
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:47:37.773397
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast

    code = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert isinstance(tree.body[0].body[0].body[0], ast_call)
    assert isinstance(tree.body[0].body[0].body[0].func, ast_name)
    assert tree.body[0].body[0].body[0].func.id == 'super'

# Generated at 2022-06-18 00:47:45.585029
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import Source
    from ..utils.helpers import get_ast

    source = Source("""
    class A:
        def __init__(self):
            super()
    """)

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast.Name)
    assert tree.body[0].body[0].body[0].value.func.id == 'super'
    assert isinstance(tree.body[0].body[0].body[0].value.args[0], ast.Name)

# Generated at 2022-06-18 00:47:48.180943
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:47:57.723212
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed
    assert get_ast_node(tree, 'super(A, self)') is not None

    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed

# Generated at 2022-06-18 00:48:04.068236
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_source

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast_from_source(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
            @classmethod
            def cls_method(cls):
                super()
    """)

# Generated at 2022-06-18 00:48:12.619740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:47.991360
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:57.990502
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)

        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:49:00.434656
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source


# Generated at 2022-06-18 00:49:00.934388
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:49:07.217423
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as parse
    from ..utils.source import source_to_ast_as_module as parse_module
    from ..utils.helpers import get_ast_node_at_line
    from ..utils.helpers import get_ast_nodes_of_type
    from ..utils.helpers import get_ast_node_name_at_line
    from ..utils.helpers import get_ast_node_names_of_type


# Generated at 2022-06-18 00:49:12.378252
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(ast.dump(tree), expected)

# Generated at 2022-06-18 00:49:16.173026
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer.tree_changed
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:49:17.275078
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:49:24.521746
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert node_to_str(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:49:27.176773
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:50:51.836279
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:50:58.279604
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class Cls:
            def __init__(self):
                super()
    """)
    expected_source = source_to_unicode("""
        class Cls:
            def __init__(self):
                super(Cls, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(astor.to_source(tree).strip(), expected_source.strip())

# Generated at 2022-06-18 00:51:03.768766
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:51:08.085385
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str
    from ..utils.ast_helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    result = tree_to_str(tree)
    expected = source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')
    assert_equal_ignore_ws(result, expected)

# Generated at 2022-06-18 00:51:18.760177
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_args
    from ..utils.ast_helpers import get_ast_node_func_name
    from ..utils.ast_helpers import get_ast_node_func_args
    from ..utils.ast_helpers import get_ast_node_func_kwargs
    from ..utils.ast_helpers import get_ast_node_func_defaults
    from ..utils.ast_helpers import get_ast_node_func_vararg
    from ..utils.ast_helpers import get_ast_node_func_kwarg
    from ..utils.ast_helpers import get_ast_node_func_body