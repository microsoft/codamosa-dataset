

# Generated at 2022-06-18 00:41:16.825683
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:41:21.594872
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:41:28.225583
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:41:36.357565
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    expected_source = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert_equal_ignore_ws(astor.to_source(tree).strip(), expected_source.strip())

# Generated at 2022-06-18 00:41:43.646088
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:48.093939
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:41:55.138432
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:01.276333
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:08.443277
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:42:18.890784
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast_call('super'))

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    node = tree.body[0].body[0].body[0]

# Generated at 2022-06-18 00:42:28.655536
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:29.596766
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:36.407876
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:39.238360
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_closest_parent_of


# Generated at 2022-06-18 00:42:40.056836
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:49.083448
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class Foo:
            def __init__(self):
                super()
    """)
    expected = source_to_unicode("""
        class Foo:
            def __init__(self):
                super(Foo, self)
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(ast.dump(tree), expected)

# Generated at 2022-06-18 00:42:54.549480
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.ast_helpers import get_func_name, get_class_name
    from ..utils.tree import print_tree
    from ..utils.compare import compare_source

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert compare_source(print_tree(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')


# Generated at 2022-06-18 00:43:01.732625
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:43:07.981368
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:15.882263
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast_node_at_line
    from ..utils.source import source_to_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')

    tree = source_to_ast(source)
    node = get_ast_node_at_line(tree, 3)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not len(node.args)


# Generated at 2022-06-18 00:43:27.842494
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:43:32.642629
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type


# Generated at 2022-06-18 00:43:38.079413
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:45.288881
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super().__init__()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:43:53.976761
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:59.516561
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_first_of_node_type

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    node = get_first_of_node_type(tree, ast.Call)
    assert node.args[0].id == 'A'
    assert node.args[1].id == 'self'

# Generated at 2022-06-18 00:44:05.883963
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    expected = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(ast.dump(tree), expected)

# Generated at 2022-06-18 00:44:15.291058
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def, ast_arguments

    tree = ast_call(
        func=ast_name(id='super'),
        args=[],
    )

    func = ast_function_def(
        name='foo',
        args=ast_arguments(
            args=[ast_arguments(args=[ast_name(id='self')])],
        ),
        body=[tree],
    )

    cls = ast_class_def(
        name='Cls',
        body=[func],
    )

    tree = ast.Module(body=[cls])

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to

# Generated at 2022-06-18 00:44:25.871285
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_nodes

# Generated at 2022-06-18 00:44:32.887342
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:50.349589
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class Test:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
        class Test:
            def __init__(self):
                super(Test, self)
    ''')

# Generated at 2022-06-18 00:44:56.147679
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:04.000123
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:11.646320
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class Test:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class Test:
            def __init__(self):
                super(Test, self)
    """)

# Generated at 2022-06-18 00:45:12.692113
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:45:22.972786
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call
    from ..utils.ast_factory import ast_function_def
    from ..utils.ast_factory import ast_class_def
    from ..utils.ast_factory import ast_name
    from ..utils.ast_factory import ast_arguments
    from ..utils.ast_factory import ast_arg
    from ..utils.ast_factory import ast_expect

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)

    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0]

    transformer = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-18 00:45:29.846482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:33.723928
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Test(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id='Cls'), ast.Name(id='self')]
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:45:36.798300
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:45:42.169747
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:46:01.632437
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:46:12.163637
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import assert_equal

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-18 00:46:19.047438
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
    class A(object):
        def __init__(self):
            super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
    class A(object):
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:46:23.295709
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import get_closest_parent_of


# Generated at 2022-06-18 00:46:29.396249
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:31.379858
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-18 00:46:39.295574
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A(object):
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    source = source_to_unicode("""
        class A(object):
            def __init__(self):
                super(A, self)
    """)
    expected_tree = get_ast(source)

    assert expected_tree == tree

# Generated at 2022-06-18 00:46:43.491484
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import get_closest_parent_of


# Generated at 2022-06-18 00:46:50.534604
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:46:58.363935
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import get_closest_parent_of

    tree = build_ast("""
    class A:
        def __init__(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    node = get_node_of_class(tree, ast.Call)
    assert node.args[0].id == 'A'
    assert node.args[1].id == 'self'


# Generated at 2022-06-18 00:47:42.276711
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_str
    from ..utils.tree import get_node_of_type

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast_from_str(source)
    node = get_node_of_type(tree, ast.Call)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert transformer._tree_changed is True
    assert node.args[0].id == 'A'
    assert node.args[1].id == 'self'

# Generated at 2022-06-18 00:47:48.074059
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_children
    from ..utils.helpers import get_ast_node

# Generated at 2022-06-18 00:47:48.590468
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:56.137246
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree_to_str(tree) == tree_to_str(get_ast("""
        class A:
            def __init__(self):
                super(A, self)
    """))

# Generated at 2022-06-18 00:48:01.424444
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:48:09.186884
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:48:18.762660
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    tree = build_ast("""
    class A:
        def __init__(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert get_ast_node_name(tree.body[0].body[0].body[0].value) == 'Call'
    assert get_ast_node_name(tree.body[0].body[0].body[0].value.func) == 'Name'

# Generated at 2022-06-18 00:48:24.626397
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:48:26.037294
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:48:35.716040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_arguments, ast_arg, ast_classdef
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast_call())
    assert isinstance(node.value.func, ast_name())
    assert node.value.func.id == 'super'
    assert not node.value.args

    transformer = SuperWithoutArgumentsTrans

# Generated at 2022-06-18 00:50:03.560544
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:50:09.308645
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:50:19.787075
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not node.args

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert isinstance(node, ast.Call)

# Generated at 2022-06-18 00:50:25.853630
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)

    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:50:30.419076
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_to_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = compile_to_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:50:36.474506
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_trees
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_trees

    source = source_to_unicode('''
    class A:
        def __init__(self):
            super()
    ''')


# Generated at 2022-06-18 00:50:45.240096
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import assert_equal

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-18 00:50:52.844919
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:51:00.898623
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_all_nodes_of_type

    source = """
    class A:
        def __init__(self):
            super()
    """
    nodes = source_to_nodes(source)
    transformer = SuperWithoutArgumentsTransformer(nodes)
    transformer.visit(nodes)

    assert get_ast_node_name(nodes) == 'Module'
    assert len(get_all_nodes_of_type(nodes, ast.Call)) == 1
    assert len(get_all_nodes_of_type(nodes, ast.Name)) == 3

# Generated at 2022-06-18 00:51:10.427188
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_arguments, ast_arg, ast_classdef

    source = source_to_unicode("""
        class Cls:
            def func(self):
                super()
    """)
    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not node.args

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
