

# Generated at 2022-06-21 18:07:58.749153
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.tree import node_factory
    test_code = """
    super()
    """
    expected_code = """
    super(cls, self)
    """
    
    tree = node_factory.ext_parse(test_code)
    SuperWithoutArgumentsTransformer(tree, 2, 7).visit(tree)
    assert expected_code == astor.to_source(tree)


# Generated at 2022-06-21 18:07:59.319411
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:08:01.909396
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    

# Generated at 2022-06-21 18:08:02.964625
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:04.909113
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from ..utils.helpers import get_ast


# Generated at 2022-06-21 18:08:08.171621
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import setup_ast_node
    from ..utils.get_args import get_arg_names_from_function_def

# Generated at 2022-06-21 18:08:18.733231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.mock_data import get_mock_composition
    from ..utils.mock_data import get_mock_cls1_ast
    from ..utils.mock_data import get_mock_function_ast
    from ..utils.tester import node_error_transform_tester
    from ast import parse

    mock_tree = get_mock_composition()

    def mock_cls1_ast() -> ast.ClassDef:
        mock_cls1 = get_mock_cls1_ast()

        mock_function = get_mock_function_ast()

        mock_super_node = parse("super()").body[0]
        mock_function.body.append(mock_super_node)
        mock_cls1.body.append(mock_function)

        return

# Generated at 2022-06-21 18:08:22.273854
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor, sys, io
    from python_minifier.transformer.super_without_argument_transformer import SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:22.889192
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:34.590024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor.code_gen import to_source
    from .fake_ast import FakeTree, FakeNode

    tree = FakeTree()
    tree._ast = FakeNode(body=[
        FakeNode(
            name='abc',
            body=[
                FakeNode(
                    name='def',
                    args=[FakeNode(args=[FakeNode(arg='self')])],
                    body=[FakeNode(func=FakeNode(id='super'), args=[])]
                )
            ]
        )
    ])
    trans = SuperWithoutArgumentsTransformer(tree)
    trans.visit(tree.body[0])

    assert to_source(tree) == dedent("""
    class abc:
        def def(self):
            super(abc, self)
    """)



# Generated at 2022-06-21 18:08:41.061462
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_unicode
    from ..transpile import transpile_function
    from ..utils.helpers import create_function

# Generated at 2022-06-21 18:08:41.696914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:08:52.594294
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('line = super()')
    tr = SuperWithoutArgumentsTransformer(2, 7)
    tr.visit(node)
    assert 'line = super(Parent, self)' == astor.to_source(node)

    node = ast.parse('line = super()')
    tr = SuperWithoutArgumentsTransformer(3, 6)
    tr.visit(node)
    assert 'line = super()' == astor.to_source(node)

    node = ast.parse('line = super(Parent)')
    tr = SuperWithoutArgumentsTransformer(2, 7)
    tr.visit(node)
    assert 'line = super(Parent, self)' == astor.to_source(node)

    node = ast.parse('line = super(Parent)')
    tr = SuperWithoutArgumentsTrans

# Generated at 2022-06-21 18:08:58.879611
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    s = """class A:
        def __init__(self):
            super()"""
    t = ast.parse(s)
    exp = """class A:
        def __init__(self):
            super(A, self)"""  # noqa
    t2 = SuperWithoutArgumentsTransformer(t).get_tree()
    assert astunparse.unparse(t2) == exp

# Generated at 2022-06-21 18:09:01.351099
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:04.789095
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(
            func=ast.Name(id='super', ctx=ast.Load()),
            args=[],
            keywords=[])

# Generated at 2022-06-21 18:09:06.450257
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer

# Generated at 2022-06-21 18:09:12.186666
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    node = tree.body[0].value
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-21 18:09:18.695165
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """class Super(object):
                def __init__(self):
                    super()
                @classmethod
                def test(cls):
                    super()
            """
    expected = """class Super(object):
            def __init__(self):
                super(Super, self)
            @classmethod
            def test(cls):
                super(Super, cls)
            """
    tree = ast.parse(input)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    output = astor.to_source(tree).strip()
    assert output == expected

# Generated at 2022-06-21 18:09:24.499583
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    string = """
    class Cls(object):
        def meth(self):
            super()
    """
    tree = ast.parse(string)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '<test>', 'exec')
    exec(compiled)  # noqa: F821; pylint: disable=undefined-variable



# Generated at 2022-06-21 18:09:36.653882
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import load_module

    module = load_module("""
    class Cls(object):
        def f(self):
            super()""")

    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.recurse()

    node = module.body[0].body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-21 18:09:42.218319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def __init__(self):
                super().__init__()
    """
    pytree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(pytree)
    transformer.visit(pytree)
    compile(pytree, filename='', mode='exec')

# Generated at 2022-06-21 18:09:49.875305
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = '''
    class A:
        def __init__(self):
            super()
     '''
    expected_code = '''
    class A:
        def __init__(self):
            super(A, self)
     '''
    expected_ast = parse(expected_code)

    actual_ast = parse(source)
    tree = SuperWithoutArgumentsTransformer().visit(actual_ast)

    assert compare_ast(tree, expected_ast) == True, "SuperWithoutArgumentsTransformer did not work as expected"

# Generated at 2022-06-21 18:09:54.494401
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Test(object):
        def __init__(self):
            super()
    '''
    node = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    print(ast.dump(node))

# Generated at 2022-06-21 18:09:56.844572
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Program:
        # super()
        def __init__(self):
            pass
    

# Generated at 2022-06-21 18:09:57.819264
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:58.381663
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:09:58.961328
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:04.381663
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    transformer = SuperWithoutArgumentsTransformer()

    call = ast.Call(
        func=ast.Name(id='super'),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )

    assert transformer.visit(call) == ast.Call(
        func=ast.Name(id='super'),
        args=[
            ast.Name(id='Cls'),
            ast.Name(id='self')
        ],
        keywords=[],
        starargs=None,
        kwargs=None
    )



# Generated at 2022-06-21 18:10:09.884897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTester
    from ..utils.helpers import should_run_node_transformer
    class _Tester(BaseNodeTransformerTester):
        target_version = (2, 7)
    if should_run_node_transformer(_Tester.target_version, SuperWithoutArgumentsTransformer):
        _Tester.check_node_transformer(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:10:21.827224
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    '''
    Visit Call to find call to super()
    '''
    astroid_module, _ = tests.build_module("""
    class A(object):
        def __init__(self):
            super().__init__()
    """)
    node = astroid_module.body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node.args[0])

    assert transformer._tree_changed is True
    assert transformer._tree is node.args[0]

# Generated at 2022-06-21 18:10:23.972491
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = '''super()'''
    expect = '''super(Cls, self)'''
    ast_tree = compile(input, filename="", mode="exec", flags=ast.PyCF_ONLY_AST)
    c = SuperWithoutArgumentsTransformer(ast_tree)
    c.visit(ast_tree)
    actual = astor.to_source(ast_tree).strip()
    assert expect == actual

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:10:32.659788
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    @add_slots
    class Call(ast.Call):
        _fields = ('func', 'args', 'keywords', 'starargs', 'kwargs')
        func: ast.Name
        args: ast.Node = None
        keywords: ast.Node = None
        starargs: ast.Node = None
        kwargs: ast.Node = None

    tree = Call(func=Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None),
                args=[], keywords=[], starargs=None, kwargs=None)
    node = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(node.func, ast.Call)
    assert isinstance(node.func.args[0], ast.Name)

# Generated at 2022-06-21 18:10:44.228993
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from python_minifier.ast_compare import compare_ast
    code = """super()"""
    expected_code = """super(Cls, self)"""
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer(tree, (), {}).run()
    astor.codegen.to_source(tree)
    print('TEST 1:')
    print('Input:      ', code)
    print('Expected:   ', expected_code)
    print('Output:     ', astor.to_source(tree))
    print('AST Equal?: ', compare_ast(ast.parse(expected_code), tree))
    assert compare_ast(ast.parse(expected_code), tree)

    code = """super(cls="1")"""

# Generated at 2022-06-21 18:10:49.627210
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.fixtures import SuperWithoutArgumentsTransformer_test
    from .. import compile_src

    code = SuperWithoutArgumentsTransformer_test.__doc__
    tree = compile_src(code, '<test>', 'exec')
    SuperWithoutArgumentsTransformer().visit(tree)



# Generated at 2022-06-21 18:10:52.401289
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    transpiler = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-21 18:11:02.246023
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.mock_tree import get_tree

    tree = get_tree(ast.parse('''
        class A:
            def __init__(self):
                super()
        class B(A):
            def __init__(self):
                super()
    '''))

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()

    assert tree == get_tree(ast.parse('''
        class A:
            def __init__(self):
                super(A, self)
        class B(A):
            def __init__(self):
                super(B, self)
    '''))

# Generated at 2022-06-21 18:11:09.730573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_tree = ast.parse('class my_class:\n\tdef my_func(self):\n\t\tsuper()')
    func_tree = ast.parse('def my_func(self):\n\tsuper()')

    assert SuperWithoutArgumentsTransformer().visit(class_tree) == ast.parse('class my_class:\n\tdef my_func(self):\n\t\tsuper(my_class, self)')
    assert SuperWithoutArgumentsTransformer().visit(func_tree) == func_tree

# Generated at 2022-06-21 18:11:14.128278
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        super()
    """
    tree = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assertEqual(transformer.tree_changed, True)



# Generated at 2022-06-21 18:11:15.661510
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:28.959673
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))


if __name__ == "__main__":
    node = ast.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))

# Generated at 2022-06-21 18:11:40.305579
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import transform_and_compare_ast
    from ..utils.helpers import fake_position_info
    import ast
    class TestClass:
        def TestFunc(self):
            super()
    tree = fake_position_info(ast.parse(TestClass.__dict__['TestFunc'].__doc__))
    SuperWithoutArgumentsTransformer().generic_visit(tree)

# Generated at 2022-06-21 18:11:49.666752
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    module = ast.parse("""
        class A:
            def __init__(self):
                super()
        class A:
            def __init__(self):
                super(A, self)
    """)

    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)

    assert_source_equal("""
        class A:
            def __init__(self):
                super(A, self)
        class A:
            def __init__(self):
                super(A, self)
    """, module)

# Generated at 2022-06-21 18:11:58.157341
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parser import PythonTranspiler
    from ..patch_ast import replace_ast_attributes

    code = 'class Cls:\n  def method(self): pass\n  def method2(self): return super()'
    transpiler = PythonTranspiler(code, target=PythonTranspiler.Target.PY27)
    patch_ast = [
        (ast.Call, 'func', 'args', 'keywords'),
        (ast.FunctionDef, 'args', 'body', 'decorator_list'),
    ]
    if sys.version_info[:2] >= (3, 6):
        patch_ast.append((ast.ClassDef, 'name', 'bases', 'keywords'))

# Generated at 2022-06-21 18:12:06.447346
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import fixer_applier
    code = """
        class A(B):
            def m(self):
                super()
    """

    tree = ast.parse(code)
    fixer_applier.apply_transformer(SuperWithoutArgumentsTransformer, tree)

    expected_code = """
        class A(B):
            def m(self):
                super(A, self)
    """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:12:12.802697
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_transformer

    code = '''
        class A:
            def foo(self):
                super().foo()
        '''
    node = compile(code, 'test', 'exec', ast.PyCF_ONLY_AST)
    result = ast_transformer(node, SuperWithoutArgumentsTransformer)
    expected = '''
        class A:
            def foo(self):
                super(A, self).foo()
        '''

    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-21 18:12:18.921203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.compat import Literal
    from ..utils.inspect import get_class_nodes
    from .. import transform

    src = '''class A:
        def __init__(self):
            super().__init__()
    class B(A):
        def __init__(self):
            super().__init__()'''

    tree = source_to_nodes(src)
    transform(tree, SuperWithoutArgumentsTransformer)
    nodeA = get_class_nodes(tree, 'A')[0]
    nodeB = get_class_nodes(tree, 'B')[0]
    funcA = nodeA.body[0]
    funcB = nodeB.body[0]

# Generated at 2022-06-21 18:12:28.052928
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object
    from ..utils.ast import code_object_to_ast

    src = """
        class A:
            def m(self):
                super()
        """
    co = source_to_code_object(src)
    tree = code_object_to_ast(co)
    t = SuperWithoutArgumentsTransformer(tree)
    t.visit(tree)
    assert astor.to_source(tree).strip() == """
        class A:
            def m(self):
                super(A, self)
        """.strip()

# Generated at 2022-06-21 18:12:36.205026
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from tests import compile_to_typed_tree
    from tests.test_compilers import run_compiler, assert_ast_node_types_are
    from .helpers import assert_equal_source, assert_tree_changed_from_compiler

    tree = compile_to_typed_tree(
        source="""
    class A:
        def meth(self):
            super()
        def meth2(self):
            super()
            super()
            super()
    """)

    assert_tree_changed_from_compiler(SuperWithoutArgumentsTransformer, tree, 'meth')
    assert_tree_changed_from_compiler(SuperWithoutArgumentsTransformer, tree, 'meth2')


# Generated at 2022-06-21 18:12:37.870499
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def check(code, expected):
        tree = ast.parse(code)
        SuperWithoutArgumentsTransformer(tree).visit(tree)
        actual = ast.dump(tree, include_attributes=True)
        assert expected == actual


# Generated at 2022-06-21 18:13:01.764068
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from copy import deepcopy
    from typed_ast import ast3
    from .sample_asts import super_wo_arguments

    tree = ast3.parse(super_wo_arguments.source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree == deepcopy(ast3.parse(super_wo_arguments.expected))

# Generated at 2022-06-21 18:13:09.241913
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from _ast import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import parse as parse3

    code = """class Cls:
        def __init__(self):
            super()"""
    tree = parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert dump(tree) == dump(parse3(
        """class Cls:
        def __init__(self):
            super(Cls, self)"""))
# End unit test



# Generated at 2022-06-21 18:13:16.351038
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object
    from ..utils.trees import get_ast

    code = """
    class A:
        def m(self):
            super()

    class B(A):
        pass

    B().m()
    """
    co = source_to_code_object(code)
    SuperWithoutArgumentsTransformer(co).visit(get_ast(co))

    assert co.co_consts[0] == 'A'
    assert co.co_consts[1] == 'm'
    assert co.co_consts[3] == 'B'
    assert co.co_consts[5] == 'super'

# Generated at 2022-06-21 18:13:25.531010
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with open('test/fixtures/2.7/super.ast') as f:
        tree = ast.parse(f.read(), '', 'exec')

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    print(astor.to_source(tree))

    with open('test/fixtures/2.7/super.fixed.ast') as f:
        fixed_tree = ast.parse(f.read(), '', 'exec')

    assert astor.to_source(tree) == astor.to_source(fixed_tree)

# Generated at 2022-06-21 18:13:30.753493
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    code = """
        class Example:
            def __init__(self):
                super()
    """

    expected_code = """
        class Example:
            def __init__(self):
                super(Example, self)
    """
    module = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer(module)
    tree.run()
    result = astor.to_source(module)
    assert expected_code == result

# Generated at 2022-06-21 18:13:38.410268
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    class Cool(object):
        def __init__(self):
            super().__init__()
    """
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    expected_output = """
    class Cool(object):
        def __init__(self):
            super(Cool, self).__init__()
    """
    assert ast.dump(tree) == expected_output


# Generated at 2022-06-21 18:13:43.945532
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert ast.dump(tree, include_attributes=False) == """
Module(
  body=[
    Expr(
      value=Call(
        func=Name(
          id='super',
          ctx=Load()
        ),
        args=[
          Name(
            id='Cls',
            ctx=Load()
          ),
          Name(
            id='self',
            ctx=Load()
          )
        ],
        keywords=[],
        starargs=None,
        kwargs=None
      )
    )
  ]
)"""

# Generated at 2022-06-21 18:13:49.517509
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    tree = astor.parse_file('./test/test_files/test_super_without_arguments.py')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == "class Test:\n\n    def outer(self):\n        super(Test, self)\n        super(Test, self)\n"

# Generated at 2022-06-21 18:13:51.254068
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:55.154378
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_equal

    node = ast.parse("super()")
    obj = SuperWithoutArgumentsTransformer(node)
    assert_code_equal("super(Cls, self)", obj.visit(node))

# Generated at 2022-06-21 18:14:28.858066
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    trafo = SuperWithoutArgumentsTransformer()

    # Simple test class definition

# Generated at 2022-06-21 18:14:36.872782
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    program = """
    class A():
        pass

    class B(A):
        def __init__(self):
            super()
            super()
            super()
            super()

    class C(A):
        def method(self):
            super()
            super()
            super()

        @classmethod
        def method(cls):
            super()
            super()
            super()

        @staticmethod
        def method():
            super()
            super()
            super()
    """
    tree = ast.parse(program)
    SuperWithoutArgumentsTransformer(tree).run()

# Generated at 2022-06-21 18:14:43.222927
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..transpiler import Transpiler
    from .. import tree
    from ..utils import ast_to_text

    code = """
    class A:
        def __init__(self):
            super()
    """
    module = tree.parse(code, parser='py27')
    transpiler = Transpiler(module)
    transpiler.register_transformers(SuperWithoutArgumentsTransformer)
    transpiler.transpile()


# Generated at 2022-06-21 18:14:49.079258
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.utils import generate_code_for_ast_nodes
    from numpy import long as np_long

    for cls in (ast.ClassDef, 'class'):
        # Test that super() is transformed to super(Cls, self)
        tree = ast.parse("""
            class A:
                def __init__(self):
                    super()
        """)
        node = tree.body[0].body[0].body[0]
        SuperWithoutArgumentsTransformer(tree).visit(node)
        assert generate_code_for_ast_nodes(tree.body) == 'class A:\n    def __init__(self):\n        ' \
                                                         'super(A, self)\n'

        # Test that super() is transformed to super(B, cls)

# Generated at 2022-06-21 18:14:49.697776
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:51.495411
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:52.633479
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:54.084175
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-21 18:15:00.203081
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cls1(object):
            def f(self):
                super()
    """
    expected_code = """
        class Cls1(object):
            def f(self):
                super(Cls1, self)
    """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_code.strip()

# Generated at 2022-06-21 18:15:07.717151
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..macros.refactor_tools import get_ast
    from ..utils.helpers import get_func
    from ..transpiler.base import Transpiler

    code = '''
        class A:
            def foo(self):
                bar = super()
    '''

    tree = get_ast(code)
    get_func(tree, 'foo').body = [SuperWithoutArgumentsTransformer().visit(get_func(tree, 'foo').body[0])]
    assert Transpiler().visit(tree) == '\n        class A:\n            def foo(self):\n                bar = super(A, self)\n        \n'

# Generated at 2022-06-21 18:15:53.184943
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class C:
      def method(self):
        super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)

    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert tree.body[0].body[0].body[0].value.args[0].id == "C"
    assert tree.body[0].body[0].body[0].value.args[1].id == "self"

# Generated at 2022-06-21 18:16:00.991461
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .utils import parse_to_ast_node
    from .utils import dump_ast_tree

    tree = parse_to_ast_node("""
super()
""")
    node = SuperWithoutArgumentsTransformer().visit(tree)
    assert dump_ast_tree(node) == """Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='cls', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"""

# Generated at 2022-06-21 18:16:07.269409
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from os.path import dirname, join
    from textwrap import dedent
    from ..utils.source import source_to_unicode
    from ..utils.helpers import run_transformer
    from ..utils.compat import unicode

    source = source_to_unicode(join(dirname(__file__), 'constructor.py'))
    source = dedent(unicode(source))

    tree = run_transformer(SuperWithoutArgumentsTransformer, source)
    exec(compile(tree, filename="<ast>", mode="exec"))
    assert Car.__bases__[1] == Car
    assert Car.__bases__[0] == object

# Generated at 2022-06-21 18:16:18.414867
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():  # type: ignore
    code = "super()"
    expected_code = "super(Cls, self)"

    module = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(module)
    compiled_module = compile(module, '', 'exec')

    # Create the namespace
    namespace = {}

    # Execute the compiled module in the namespace
    exec(compiled_module, namespace)

    # Now namespace should contain a function called 'f'
    f = namespace['f']

    # Let's call the function and make sure it returns 3
    class Cls(object):
        def f(self):
            return super(Cls, self)

    # Let's call the function and make sure it returns 3
    assert(Cls().f.__self__ == object)

# Generated at 2022-06-21 18:16:21.071715
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')  # type: ast.AST
    SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '', 'exec') == compile('super(Cls, self)', '', 'exec')

# Generated at 2022-06-21 18:16:30.134316
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from darglint.transformers import SuperWithoutArgumentsTransformer
    from darglint.utils.tree import parse_tree, assert_tree
    code = """
        class super_no_arguments(object):
            def func(self):
                super()
        """
    tree = parse_tree(code)
    expected_tree = parse_tree("""
        class super_no_arguments(object):
            def func(self):
                super(super_no_arguments, self)
        """)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert_tree(tree, expected_tree)



# Generated at 2022-06-21 18:16:40.713541
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # https://github.com/serge-sans-paille/python-modernize/issues/13
    # This code is to test if the SuperWithoutArgumentsTranformer 
    # can fix super() inside of class and the super(Cls, self). 
    # It shouldn't throw any syntax errors.
    import inspect
    import textwrap
    source = textwrap.dedent('''
    class MyClass(object):
        def foo(self):
            super()
    ''')
    tree = ast.parse(source)
    transformer  = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    print(ast.dump(tree))
    # Save the transformed tree as a .py file for later inspection.
    import tempfile

# Generated at 2022-06-21 18:16:51.453875
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
    class Cls:
        def __init__(self):
            super().__init__()
    """)

    c = SuperWithoutArgumentsTransformer(tree)
    c.visit(tree)
    assert isinstance(tree.body[0].body[0].body[0], ast.Call)

    call = tree.body[0].body[0].body[0]
    assert isinstance(call.func, ast.Attribute)
    assert isinstance(call.func.value, ast.Attribute)
    assert call.func.value.attr == 'super'
    assert call.func.value.value.id == 'Cls'
    assert len(call.args) == 2
    assert isinstance(call.args[0], ast.Name)

# Generated at 2022-06-21 18:16:55.176680
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    node = ast.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert astor.to_source(node) == "super(Cls, self)"

# Generated at 2022-06-21 18:16:55.708798
# Unit test for constructor of class SuperWithoutArgumentsTransformer