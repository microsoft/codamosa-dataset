

# Generated at 2022-06-21 18:08:02.761913
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import ASTCodeGenerator
    from ..utils.helpers import print_ast


# Generated at 2022-06-21 18:08:14.036469
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    import sys
    import io
    import tokenize
    from .base import BaseNodeTransformer
    assert issubclass(SuperWithoutArgumentsTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 18:08:22.011446
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    class AST:
        class Call:
            def __init__(self, func, *args):
                self.func = func
                self.args = list(args)

        class Name:
            def __init__(self, id):
                self.id = id

        class FunctionDef:
            def __init__(self, name, *args, **kwargs):
                self.name = name
                self.args = args[0]

        class ClassDef:
            def __init__(self, name, *args, **kwargs):
                self.name = name
                self.args = args[0]

    node1 = AST.Call(AST.Name('super'), *[])

# Generated at 2022-06-21 18:08:24.799448
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import cst_to_ast
    from ..utils import ast_to_cst
    from ..utils import strip_empty_lines

# Generated at 2022-06-21 18:08:26.316254
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that super() is correctly transformed"""

# Generated at 2022-06-21 18:08:38.778841
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import Module, Name, Load, Expr, Call
    
    code = '''class Foo:
    def __init__(self):
        super()
        '''

    expected_code = '''class Foo:
    def __init__(self):
        super(Foo, self)
        '''


# Generated at 2022-06-21 18:08:45.217416
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = 'super()'
    expected_output = 'super(Cls, self)'
    module_node = ast.parse(input_code)

# Generated at 2022-06-21 18:08:46.453634
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:57.550038
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_source = """
        class A:
            def __init__(self):
                super()

    """
    expected_source = """
        class A:
            def __init__(self):
                super(A, self)
    """

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(input_source))
    result_source = compile(t._tree, '', 'exec')
    assert expected_source in result_source

    input_source = """
        class A:
            def __init__(self):
                super()
        def f():
            super()
    """
    expected_source = """
        class A:
            def __init__(self):
                super(A, self)
        def f():
            super()
    """

    t = SuperWithoutArgumentsTrans

# Generated at 2022-06-21 18:09:08.898245
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    cls = ast.ClassDef(name='Test', body=[
        ast.FunctionDef(name='transform', args=ast.arguments(args=[ast.arg(arg='self')]), body=[
            ast.Return(value=ast.Call(func=ast.Name(id='super')))
        ])
    ])

    t = SuperWithoutArgumentsTransformer()
    t.visit(cls)

    assert isinstance(cls.body[0], ast.FunctionDef)
    assert isinstance(cls.body[0].body[0], ast.Return)
    assert isinstance(cls.body[0].body[0].value, ast.Call)
    assert isinstance(cls.body[0].body[0].value.args[0], ast.Name)

# Generated at 2022-06-21 18:09:18.181631
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class DummySuperWithoutArgumentsTransformer(BaseNodeTransformer):
        def visit_Assert(self, node: ast.Assert) -> ast.Assert:
            return self.generic_visit(node)  # type: ignore

    cls = DummySuperWithoutArgumentsTransformer()
    node = ast.parse('assert 1 == 2')
    cls.visit(node)

# Generated at 2022-06-21 18:09:30.256659
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestSuperWithoutArgumentsTransformer:
        def test_transformed(self):
            # This should not compile
            input_code = """
            class A:
                def __init__(self):
                    super()
            """
            output_code = """
            class A:
                def __init__(self):
                    super(A, self)
            """
            tree = ast.parse(input_code)
            transformer = SuperWithoutArgumentsTransformer(tree)
            transformer.run()
            compare_ast(tree, output_code)

        def test_class_outside_function(self):
            input_code = """
            class A:
                super()
            """
            tree = ast.parse(input_code)
            transformer = SuperWithoutArgumentsTransformer(tree)
            transformer.run()

# Generated at 2022-06-21 18:09:38.070458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..pipeline import Pipeline, Unit
    from ..config import Config

    config = Config()
    pipeline = Pipeline(config)

    unit_cls = Unit(
        SuperWithoutArgumentsTransformer,
        config,
    )

    tree = ast.parse('super()')
    unit_cls.run(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('super(Cls, self)'))

    tree = ast.parse('class A:\n def b():\n  super()')
    unit_cls.run(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('class A:\n def b():\n  super(A, self)'))


# Generated at 2022-06-21 18:09:42.263270
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    node = ast.parse(code, mode='eval')
    SuperWithoutArgumentsTransformer().visit(node)
    assert_code(node, 'super(cls, self)')

# Generated at 2022-06-21 18:09:49.921776
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls:
        def __init__(self):
            super().__init__()

    class Cls1(Cls):
        def __init__(self):
            super().__init__()

    class Cls2(Cls):
        def __init__(self):
            def foo():
                super()
            foo()
    """

    tree = ast.parse(code)
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(tree)
    assert trans._tree_changed



# Generated at 2022-06-21 18:09:57.079829
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
            class Cls:
                def __init__(self):
                    super().__init__()
        """
    expected_output = """
            class Cls:
                def __init__(self):
                    super(Cls, self).__init__()
        """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    output = ast.dump(tree)
    assert expected_output == output

# Generated at 2022-06-21 18:10:02.263079
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    code = 'super()'

    tree = get_ast(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '', 'exec')
    exec(compiled, {}, {})
    assert source_to_unicode(compiled) == source_to_unicode("""
super(Cls, self)
    """)

# Generated at 2022-06-21 18:10:03.607608
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass




# Generated at 2022-06-21 18:10:08.783150
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing_utils import assert_transformed_code_equals

    assert_transformed_code_equals(
        SuperWithoutArgumentsTransformer,
        """
        class C(object):
            def f(self):
                super()
        """,
        """
        class C(object):
            def f(self):
                super(C, self)
        """
    )

# Generated at 2022-06-21 18:10:11.717916
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake import FakeFileOpen
    from ..utils.ast_parse import ast_parse
    import sys


# Generated at 2022-06-21 18:10:17.031216
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:23.775682
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..utils import parse, dump

    sample_code1 = '''
super()
'''
    expected_code1 = '''
super(Cls, self)
'''
    tree = parse(sample_code1)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    assert dump(new_tree) == expected_code1


# Generated at 2022-06-21 18:10:32.557122
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parser import PythonParser
    parser = PythonParser()
    module = parser.parse('''
        class A:
            def f(self):
                super()

        class B:
            def f(self):
                try:
                    super()
                except Exception:
                    pass

        def f():
            super()
    ''')
    node = module.body[0].body[0].body[0]
    assert type(node) == ast.Expr
    assert type(node.value) == ast.Call
    assert type(node.value.func) == ast.Name
    assert node.value.func.id == 'super'
    node = module.body[1].body[0].body[1].body[0]
    assert type(node) == ast.Expr
    assert type(node.value) == ast

# Generated at 2022-06-21 18:10:34.819772
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:37.157949
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import setup_ast_parser
    setup_ast_parser()


# Generated at 2022-06-21 18:10:46.585214
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class ATestTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node):
            if node.args:
                raise Exception()

            return ast.Name(id='test_super')

    code = """
            from typing import Callable
            
            class A:
                def __init__(self):
                    super()
                    super().test()
            
            class B(A):
                def __init__(self):
                    super()
                    super().test()
            
            def C(func: Callable):
                def wrapper():
                    func()
                    super()
                
                return wrapper
                
            @C
            def f():
                pass
    """

    tree = compile_source(code, '<test>', 'exec')
    ATestTransformer(tree).visit(tree)

# Generated at 2022-06-21 18:10:47.247284
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:48.923413
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:00.427081
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformer2(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
        """
        target = (3, 8)

        def _replace_super_args(self, node):
            node.args = [ast.Name(id='A'), ast.Name(id='a')]

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self._replace_super_args(node)
                self._tree_changed = True
            return node

    class A:
        def __init__(self, a):
            self.a = a


# Generated at 2022-06-21 18:11:10.939662
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.utils import generate_call_node, generate_function_def_node, generate_class_def_node
    def test():
        super()
    t = ast.parse(test.__code__).body[0]

    # no arg
    assert isinstance(t.body[0], ast.Expr)
    assert isinstance(t.body[0].value, ast.Call)
    assert isinstance(t.body[0].value.func, ast.Name)
    assert t.body[0].value.func.id == 'super'
    assert len(t.body[0].value.args) == 0

    # last arg
    t.body[0].value.args.append(ast.Name(id='test'))
    assert len(t.body[0].value.args) == 1

    # not

# Generated at 2022-06-21 18:11:26.720485
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = ast.parse('super()')
    t2 = ast.parse('super(A, B)')

    class MyTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:
            node.args = [ast.Name(id='A'), ast.Name(id='B')]

    assert ast.dump(t) == 'Module(body=[Call(func=Name(id=\'super\', ctx=Load()), args=[], keywords=[])])'

    MyTransformer(t).visit(t)

# Generated at 2022-06-21 18:11:28.834029
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test method visit_Call of class SuperWithoutArgumentsTransformer
    """
    import astor

# Generated at 2022-06-21 18:11:40.196366
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import (
        Module, FunctionDef, ClassDef, Name, Load, Call, Arguments,
        Store, Str, Expr, Pass
    )
    
    # Define input tree
    tree = ast.parse('class Cls:\n'
                     '    def __init__(self):\n'
                     '        super()')

    tree_expected = ast.parse('class Cls:\n'
                              '    def __init__(self):\n'
                              '        super(Cls, self)')

    # Apply transformer
    tr = SuperWithoutArgumentsTransformer()
    tr.visit(tree)
    assert tr._tree_changed == True

# Generated at 2022-06-21 18:11:41.262479
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:53.128310
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Create the AST of node to be visited
    call_node = ast.Call(
        func=ast.Name(id='super'), 
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None)

    # Create the AST of parent
    parent = ast.FunctionDef(
        name='f',
        args=ast.arguments(
            args=[ast.Name(id='x', ctx=ast.Param())],
            vararg=None,
            kwarg=None,
            defaults=[]),
        body=[call_node],
        decorator_list=[],
        returns=None)

    # Create the AST of parent

# Generated at 2022-06-21 18:11:56.549927
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    super()
    """
    expected = """
    super(Cls, self)
    """
    module, _ = compile_text(source, 'Cls.py')
    SuperWithoutArgumentsTransformer(module).run()
    check_source(expected, module)

# Generated at 2022-06-21 18:12:08.007793
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes


# Generated at 2022-06-21 18:12:10.430635
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)


# Generated at 2022-06-21 18:12:17.340395
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake_ast_nodes import FunctionDef, Call, ClassDef, Name
    class_ = ClassDef(name='parent', body=[
        FunctionDef(name='foobar', args=FunctionDef.args(args=[Name(id='self')]), body=[
            Call(func=Name(id='super'))
        ])
    ])
    super_call = class_.body[0].body[0]
    assert str(super_call) == 'super()'
    SuperWithoutArgumentsTransformer().visit(class_)
    assert str(super_call) == 'super(parent, self)'

# Generated at 2022-06-21 18:12:20.890850
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    before = """
super()
"""
    after = """
super(Super, self)
"""

    tree = ast.parse(before)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == after

# Generated at 2022-06-21 18:12:42.045123
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('''
    class Foo:
        def __init__(self):
            super().__init__
    ''')

    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(Foo, self)' == ast.dump(tree.body[0].body[0].value.args[0])

# Generated at 2022-06-21 18:12:53.213927
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.ast_builder import build_ast
    class TestClass(object):
        def test(self):
            super()
    # A transformer object should be initialized
    transformer = SuperWithoutArgumentsTransformer(build_ast(TestClass))
    # Getting the first class type node of the ast tree
    cls = transformer._tree.body[0]
    assert cls.name == 'TestClass'
    # Getting the method inside the class type node
    method = cls.body[0]
    assert method.name == 'test'
    # Getting the method's child nodes
    call = method.body[0]
    # Getting the name's type of the method's child nodes
    assert isinstance(call, ast.Call)
    # Getting the function's type of the method's child nodes

# Generated at 2022-06-21 18:13:03.979866
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class C: def __init__(self): super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == \
        "Module(body=[ClassDef(name='C', " \
        "bases=[], keywords=[], body=[FunctionDef(name='__init__', args=arguments(args=[Name(id='self', ctx=Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='C', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))], decorator_list=[])], decorator_list=[])])"



# Generated at 2022-06-21 18:13:11.764095
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    code = """super()"""
    node = ast.parse(code, mode='eval')
    SuperWithoutArgumentsTransformer().visit(node)
    assert str(node).replace(' ', '').replace('\n','') == 'super(Cls,self)'

    code = """super()"""
    node = ast.parse(code, mode='exec')
    SuperWithoutArgumentsTransformer().visit(node)
    assert str(node).replace(' ', '').replace('\n','') == 'super(Cls,cls)'

# Generated at 2022-06-21 18:13:23.229070
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test1 = code_to_ast("super()")
    test2 = code_to_ast("super(A, self)")
    test3 = code_to_ast("super(B, cls)")
    test4 = code_to_ast("super(A, self, l)")
    test5 = code_to_ast("super(B, cls, d)")
    test6 = code_to_ast("class A:\n    def __init__(self):\n        super()")
    test7 = code_to_ast("class B:\n    def __init__(cls):\n        super()")
    test8 = code_to_ast("def func(self):\n    super()")

    tester = SuperWithoutArgumentsTransformer()
    # test1_result = tester.visit(

# Generated at 2022-06-21 18:13:25.632410
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.misc import print_ast


# Generated at 2022-06-21 18:13:31.018008
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)

    expected_code = """
    class A:
        def __init__(self):
            super(A, self)
    """
    expected_tree = ast.parse(expected_code)

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:13:34.089885
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:13:34.540948
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:37.992512
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """\
        super()
    """
    # The AST is created by calling compile(code, filename, 'exec', ast.PyCF_ONLY_AST)
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert tree.body[0].value.func.args[0].id == 'Cls'
    assert tree.body[0].value.func.args[1].id == 'self'

# Generated at 2022-06-21 18:14:16.796523
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    node = tree.body[0].value
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_node = transformer.visit_Call(node)
    assert transformer._tree_changed
    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.func, ast.Name)
    assert new_node.func.id == 'super'
    assert len(new_node.args) == 2
    assert isinstance(new_node.args[0], ast.Name)
    assert isinstance(new_node.args[1], ast.Name)
    assert new_node.args[0].id == 'Cls'
    assert new_node.args[1].id == 'self'

# Generated at 2022-06-21 18:14:28.272093
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transpiler = SuperWithoutArgumentsTransformer()
    src = '''
    class cls:
        def method_z():
            super()
    def f(x):
        x.super()
'''
    tree = ast.parse(src)
    try:
        transpiler.visit(tree)
    except Exception as e:
        assert False, f"Should not raise an error: {e}"

    expected = """
    class cls:
        def method_z():
            super(cls, self)
    def f(x):
        x.super()
"""
    assert astor.to_source(tree) == expected.strip(), "Should add super(cls, self) to super/class"

    src = '''
    def method_z():
        super()
'''

# Generated at 2022-06-21 18:14:36.562306
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

    code = '''
    class A:
        def __init__(self):
            super()
    '''
    tree = ast.parse(code)

    transformer.visit(tree)

    correct_code = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
    correct_tree = ast.parse(correct_code)

    assert ast.dump(tree) == ast.dump(correct_tree)

    code = '''
    class B:
        @staticmethod
        def m():
            super()
    '''
    tree = ast.parse(code)

    transformer.visit(tree)


# Generated at 2022-06-21 18:14:38.281994
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from .. import parse

# Generated at 2022-06-21 18:14:39.943252
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')

# Generated at 2022-06-21 18:14:40.283131
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:43.183574
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def _do_test(src, expected):
        parsed = ast.parse(src)
        tree = SuperWithoutArgumentsTransformer().visit(parsed)
        assert ast.dump(tree) == ast.dump(ast.parse(expected))


# Generated at 2022-06-21 18:14:46.221141
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        """Testing the SuperWithoutArgumentsTransformer class."""
        def test_init(self):
            """Test the init function."""
            SuperWithoutArgumentsTransformer()

    unittest.main(exit=False)


# Generated at 2022-06-21 18:14:49.850740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import Compiler
    code_compiler = Compiler(target=(2, 7))
    code_compiler.register_transformer(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:15:01.961151
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    import typed_astunparse

    code_1 = """class a:
    def __init__(self):
        super()"""

    cls = compile(code_1, '<test>', 'exec', flags=ast.Python27)
    exp_1 = """class a:
    def __init__(self):
        super(a, self)"""
    assert typed_astunparse.unparse(cls) == exp_1

    code_2 = """class a:
    def __init__(cls):
        super()"""

    cls = compile(code_2, '<test>', 'exec', flags=ast.Python27)
    exp_2 = """class a:
    def __init__(cls):
        super(a, cls)"""
    assert typed_astunparse

# Generated at 2022-06-21 18:16:13.803495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    code = 'super()'
    tree = ast.parse(code)

    t.visit(tree)

    assert 'super(Cls, self)' in astor.to_source(tree)

# Generated at 2022-06-21 18:16:25.255144
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    import inspect
    from copy import copy, deepcopy
    from astmonkey import transformers, visitors, class_def

    tree = ast.parse(inspect.getsource(SuperWithoutArgumentsTransformer))
    tree = transformers.ParentNodeTransformer().visit(tree)

    def _assert(before: ast.AST, after: ast.AST) -> None:
        tree = deepcopy(before)
        tree = transformers.ParentNodeTransformer().visit(tree)
        SuperWithoutArgumentsTransformer(tree).visit(tree)
        assert astor.to_source(after) == astor.to_source(tree)

    class_ = class_def.ClassDef('X', ['a', 'b'])

# Generated at 2022-06-21 18:16:29.369818
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """
a = super()
    """
    expected = """
a = super(Cls, self)
    """
    tree = ast.parse(source)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-21 18:16:30.226061
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:40.811777
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_base import CompilerTestCase
    from .test_base import assert_compilation

    class TestSuperWithoutArgumentsTransformer(CompilerTestCase):
        """Test for the method visit_Call of class
        SuperWithoutArgumentsTransformer."""

        def test_super_inside_class_method(self):
            source = '''
            class My:
                def __init__(self):
                    super()
            '''
            tree = ast.parse(source)
            SuperWithoutArgumentsTransformer(tree).visit(tree)

            expected_result = '''
            class My:
                def __init__(self):
                    super(My, self)
            '''
            assert_compilation(tree, expected_result)


# Generated at 2022-06-21 18:16:42.043414
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-21 18:16:49.062795
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    filename = os.path.join(os.path.dirname(__file__), 'samples', 'super.py')
    with open(filename, 'r', encoding='utf-8') as f:
        tree = ast.parse(f.read())

    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == textwrap.dedent(
        """
        class B(object):
            def f1(self):
                super(B, self).f2()
        """
    )

# Generated at 2022-06-21 18:16:55.911678
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    
    class FakeTree:
        def __init__(self, node):
            self._node = node

        def _get_base_node(self):
            return self._node
    
    node = ast.parse('super()')    
    node = SuperWithoutArgumentsTransformer(FakeTree(node)).visit(node)
    assert str(node) == 'super(Cls, self)'

# Generated at 2022-06-21 18:16:57.055318
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:04.346045
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    expected_code = """
    class A:
        def __init__(self):
            super(A, self)
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    new_code = compile(tree, filename="<ast>", mode="exec")
    expected_code = compile(ast.parse(expected_code), filename="<ast>", mode="exec")
    assert new_code == expected_code