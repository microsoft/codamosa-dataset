

# Generated at 2022-06-21 18:08:03.061867
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import get_ast
    from .test_helpers import get_exec

    # Simple transformation

# Generated at 2022-06-21 18:08:09.213682
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..codegen import to_source
    class NodeTransformerMock(SuperWithoutArgumentsTransformer):
        _tree = None

        def visit_Assign(self, node):
            assert isinstance(node.value, ast.Call)
            assert node.value.func.id == 'super'
            assert len(node.value.args) == 2


# Generated at 2022-06-21 18:08:15.216520
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    from ast import parse
    from .base import BaseNodeTransformer

    class Tester(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    code = '''class A:
        def foo(self):
            super()
    '''
    tree = parse(code)
    Tester().visit(tree)
    assert code == compile(tree, '', 'exec')



# Generated at 2022-06-21 18:08:27.196915
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3, parse
    from ..context import Context
    import astunparse, six

    code = astunparse.unparse(ast.parse(six.u('''
        class Test:
            def __init__(self):
                super()
            def some_method(self):
                super()
    ''')))

    dr = SuperWithoutArgumentsTransformer(Context(), parse(code))
    dr.visit(dr.tree)
    assert astunparse.unparse(dr.tree) == six.u('''
        class Test:
            def __init__(self):
                super(Test, self)
            def some_method(self):
                super(Test, self)
    ''')

# Generated at 2022-06-21 18:08:27.796755
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:08:29.944023
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-21 18:08:31.366186
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    code = 'super()'
    assert code == compile(code)

# Generated at 2022-06-21 18:08:43.570102
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call()
    node.func = ast.Name()
    node.func.id = 'super'
    
    node.args = []

    class FunctionDef:
        args = ast.arguments()
        args.args = [ast.arg(arg='self')]

    class ClassDef:
        name = 'Cls'

    def get_closest_parent_of(self, node: ast.AST, typ: type) -> ast.AST:
        if typ == FunctionDef:
            return FunctionDef
        elif typ == ClassDef:
            return ClassDef
        else:
            raise NodeNotFound

    from ..utils.tree import Tree

    transformer = SuperWithoutArgumentsTransformer(Tree(node))
    transformer._get_closest_parent_of = get

# Generated at 2022-06-21 18:08:44.603613
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from .test_helpers import _convert, _compare_source


# Generated at 2022-06-21 18:08:56.406225
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = \
        """
        class A:
            def f():
                b = super()
        """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-21 18:08:59.757369
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:01.814656
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_manipulation


# Generated at 2022-06-21 18:09:02.441717
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:07.605032
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that super() is converted to super(Cls, self)"""
    code = """super()"""
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    code2 = compile(tree, "<ast>", "exec")
    assert "super(Cls, self)" in str(code2)

# Generated at 2022-06-21 18:09:16.260836
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as ast
    from ..utils.source import source_to_fixed as fix
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)

        def _find_super_nodes(self, node):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                return [node]
            else:
                return []


# Generated at 2022-06-21 18:09:20.048501
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    # Ignore this check, because we don't have a super class
    transformer = SuperWithoutArgumentsTransformer()  # type: ignore

# Generated at 2022-06-21 18:09:27.598095
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import cst_to_ast, ast_to_cst, get_ast_from_code
    from_code = get_ast_from_code('''
        class Foo:
            def __init__(self, *args, **kwargs):
                super()
    ''')
    compiled = ast.fix_missing_locations(ast.Module(body=SuperWithoutArgumentsTransformer().visit(from_code.body)))
    assert 'super(Foo, self)' in ast_to_cst(compiled)

# Generated at 2022-06-21 18:09:30.981626
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.setup import setup_transformer
    from ..utils.helpers import ensure_value

    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:09:33.481628
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_astunparse import unparse
    from ..utils.helpers import copy_node, get_ast_of_tree


# Generated at 2022-06-21 18:09:33.957298
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:49.079703
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from typed_ast import ast27
    from ..utils.fixtures import fix_ast, fix_module
    s = 'super()'
    tree = fix_ast(s)
    assert len(tree.body[0].value.args) == 0
    assert isinstance(tree.body[0].value.func, ast27.Name)
    SuperWithoutArgumentsTransformer(fix_module(s)).visit(tree)
    assert len(tree.body[0].value.args) == 2
    assert isinstance(tree.body[0].value.args[0], ast27.Name)
    assert isinstance(tree.body[0].value.args[1], ast27.Name)

# Generated at 2022-06-21 18:09:56.585286
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.source import source_to_nodes

    source = """
    class A:
        def b(self):
            super()
    
    """
    current_module = source_to_nodes(source, mode='exec')
    output = SuperWithoutArgumentsTransformer(current_module).visit(current_module)
    assert astor.to_source(output[0].body[0].body[0]).strip() == 'super(A, self)'

# Generated at 2022-06-21 18:10:04.359501
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""class C:
    def f(self):
       super()""")

    SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(C, self)" == astor.to_source(tree).strip()

    tree = ast.parse("""class C:
    def f(self):
        super()""")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(C, self)" == astor.to_source(tree).strip()

    tree = ast.parse("""@classmethod
    def f(cls):
        super()""")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(C, cls)" == astor.to_source(tree).strip()
    

# Generated at 2022-06-21 18:10:05.366069
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:15.170810
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def compile_and_run(code):
        return compile(ast.parse(code), '<test>', mode='exec')

    test_cases = [
        ('super()',
         'super(Parent, self)'),
        ('super().foo()',
         'super(Parent, self).foo()'),
        ('super(Foo, Self).foo()',
         'super(Foo, Self).foo()'),
    ]
    for test_case in test_cases:
        tree = ast.parse(test_case[0])
        SuperWithoutArgumentsTransformer().visit(tree)
        exec(compile_and_run(test_case[1]), {}, {})

# Generated at 2022-06-21 18:10:16.308116
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:20.162705
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from py2neo import Graph
    from utils.tree import print_ast

    class ExampleNodeTransformer(SuperWithoutArgumentsTransformer):
        graph: Graph

        def __init__(self, graph):
            self.graph = graph


# Generated at 2022-06-21 18:10:20.531110
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:21.823381
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:23.521681
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input_src = 'super()'
    output_src = 'super(Cls, self)'
    assert_compile_to(input_src, output_src, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-21 18:10:42.878922
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class SuperTestSample(object):
            def __init__(self):
                super()
            def func(self, a, b, c, d):
                super()
    """

    expected_out = """
        class SuperTestSample(object):
            def __init__(self):
                super(SuperTestSample, self)
            def func(self, a, b, c, d):
                super(SuperTestSample, self)
    """

    transformer = SuperWithoutArgumentsTransformer()
    result = transformer.visit_and_transform(ast.parse(code))
    assert result == ast.parse(expected_out)

# Generated at 2022-06-21 18:10:45.594630
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as py_ast
    import typed_ast.ast3 as typed_py_ast


# Generated at 2022-06-21 18:10:54.385754
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    ast_tree = ast.parse('super()')
    visitor = SuperWithoutArgumentsTransformer(ast_tree)
    node = visitor.visit(ast_tree)  # type: ignore

    if not isinstance(node.body[0].value, ast.Call):
        raise AssertionError('Failed to find super() call')

    node = node.body[0].value
    if len(node.args):
        raise AssertionError('visit_Call() modified super() call')

    if node.func.id != 'super':
        raise AssertionError('Failed to find super() call')

# Generated at 2022-06-21 18:10:59.282116
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    code = 'class C(object):\n def f(self): super().add(1)'
    tree = ast.parse(code)
    transformer.visit(tree)
    if transformer._tree_changed:
        print(ast.dump(tree))

# Generated at 2022-06-21 18:11:08.642231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_before_transformation = "\n"
    result_of_transformation = "class A:\n" \
                               "    def __init__(self):\n" \
                               "        super(A, self).__init__()\n"
    tree_before_transformation = ast.parse(code_before_transformation)
    expected_tree = ast.parse(result_of_transformation)
    transform = SuperWithoutArgumentsTransformer()
    result_of_transformation = ast.fix_missing_locations(transform.visit(tree_before_transformation))
    assert ast.dump(result_of_transformation) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:11:15.253495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as to_ast

    src = 'class A: def m(self): super()'
    expected_src = 'class A: def m(self): super(A,self)'
    expected_ast = to_ast(expected_src)
    ast_ = to_ast(src)
    node_transformer = SuperWithoutArgumentsTransformer(src, ast_)
    new_ast = node_transformer.visit(ast_)
    assert new_ast == expected_ast

# Generated at 2022-06-21 18:11:17.045545
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast, compare_asts


# Generated at 2022-06-21 18:11:24.616971
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..helpers import get_node_of_class
    from ..utils.tree import find_all_nodes_of_type

    module = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer(module)
    assert get_node_of_class(tree._tree, ast.Name) is None
    tree.visit(tree._tree)
    assert get_node_of_class(tree._tree, ast.Name) is not None
    assert len(find_all_nodes_of_type(tree._tree, ast.Call)) == 0



# Generated at 2022-06-21 18:11:25.092264
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:28.168721
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile as compile_
    example = '''
        class Widget:
            def __init__(self):
                super()
    '''
    code = compile_(example, '<test>', mode='exec', rule_set=[SuperWithoutArgumentsTransformer])
    assert code == 'class Widget:\n    def __init__(self):\n        super(Widget, self)\n'


# Generated at 2022-06-21 18:11:42.054964
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = inspect.cleandoc('''
        def foo(self):
            super()
    ''')
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    code_after = fix_code(tree)
    assert code_after == inspect.cleandoc('''
        def foo(self):
            super(__tau_class__, self)
    ''')



# Generated at 2022-06-21 18:11:53.648978
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astmonkey
    from ..utils.helpers import get_ast

    code = """
    class Cls:
        def func(self):
            super()

    class Cls2(object):
        def func(self):
            super()

    class Cls3:
        @staticmethod
        def func(self):
            super()

    class Cls4(Cls3):
        @staticmethod
        def func(self):
            super()
    """

    ast1 = get_ast(code)
    SuperWithoutArgumentsTransformer().visit(ast1)

# Generated at 2022-06-21 18:12:03.651424
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node):
            node.args = [ast.Num(n=5), ast.Num(n=6)]

    code = '''
    class Cls:
        pass


    class Cls2(Cls):
        def func():
            super()
    '''

    tree = ast.parse(code)
    func_node = tree.body[3].body[0].body[0]
    TestSuperWithoutArgumentsTransformer().visit(func_node)

    args = func_node.value.args
    assert args == [ast.Num(n=5), ast.Num(n=6)]

# Generated at 2022-06-21 18:12:11.528694
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from typing import List, Any, Tuple
    from ..transpile import Transpiler

    transpiler = Transpiler()

    class Cls(ast.NodeVisitor):
        def __init__(self):
            self._result: List[Tuple[Any, ast.AST]] = []

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == 'super':
                self._result.append((node.func, node))
            self.generic_visit(node)

    class Cls2(ast.NodeVisitor):
        def __init__(self):
            self._result: List[Tuple[Any, ast.AST]] = []


# Generated at 2022-06-21 18:12:18.072936
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    trans = SuperWithoutArgumentsTransformer()

    tree = ast.parse('def f(): super()')
    tree = trans.visit(tree)
    assert 'super(__main__.F, self)' in ast.dump(tree)

    tree = ast.parse('def f(): super(int)')
    tree = trans.visit(tree)
    assert 'super(int, self)' == ast.dump(tree)

    tree = ast.parse('def f(): super(int, 42)')
    tree = trans.visit(tree)
    assert 'super(int, 42)' == ast.dump(tree)

# Generated at 2022-06-21 18:12:18.669454
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:30.115121
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3

    node = ast3.Call(func=ast3.Name(id='super'), args=[], keywords=[])
    func_def = ast3.FunctionDef(name='foo', args=ast3.arguments(args=[ast3.arg(arg='self', annotation=None)],
                                                                vararg=None,
                                                                kwonlyargs=[],
                                                                kw_defaults=[],
                                                                kwarg=None,
                                                                defaults=[]),
                                body=[], decorator_list=[], returns=None)
    cls_def = ast3.ClassDef(name='A', bases=[], keywords=[], body=[node, func_def], decorator_list=[])
    module = ast3.Module(body=[cls_def])
    formula

# Generated at 2022-06-21 18:12:34.811795
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import assert_source

    source = """
        class C:
            def m(self):
                super()
    """
    expected = """
        class C:
            def m(self):
                super(C, self)
    """
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert_source(tree, expected)



# Generated at 2022-06-21 18:12:44.187839
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from typed_astunparse import unparse

    source = dedent('''
    class A:
        def bar(self):
            super()
    ''')

    tree = ast.parse(source)
    assert unparse(tree) == source
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    expected_output = dedent('''
    class A:
        def bar(self):
            super(A, self)
    ''')
    assert unparse(tree) == expected_output

# Generated at 2022-06-21 18:12:45.073887
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:08.600465
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake import FakeMember, FakeName, FakeStore, FakeLoad, FakeSubscript, FakeAttribute, FakeModule, \
        FakeFunctionDef, FakeAssign, FakeClassDef, FakeArguments, FakeExpr, FakeExprName, FakeArgs, FakeArg, FakeList, \
        FakeStr, FakeNodeTransformer
    import ast


# Generated at 2022-06-21 18:13:09.760332
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    from ..utils.constants import CL_HEADER, CL_END
    from ..utils import RefactoringErrorState

# Generated at 2022-06-21 18:13:10.265821
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:14.800101
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # test super()
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    result = ast.dump(tree)
    assert result == "Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), " \
                     "args=[Name(id='A', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

    # test super() outside function
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit_Expr(tree.body[0])
    transformer.visit(tree)

# Generated at 2022-06-21 18:13:26.698109
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 0
    assert len(node.value.keywords) == 0

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2
    assert len(node.value.keywords) == 0

# Generated at 2022-06-21 18:13:29.140693
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..transpiler import Transpiler
    from ..utils.helpers import run_tb, get_ast
    from ..exceptions import UnsupportedFeature


# Generated at 2022-06-21 18:13:38.275045
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_source_equal
    source = """
    class Cls:
        def __init__(self, *args):
            super()
            super(MyClass, self)
            super.__init__()
        def __add__(self):
            super(MyClass, self).__add__()
    """
    expected = """
    class Cls:
        def __init__(self, *args):
            super(Cls, self)
        def __add__(self):
            super(Cls, self).__add__()
    """
    assert_source_equal(SuperWithoutArgumentsTransformer, source, expected)

# Generated at 2022-06-21 18:13:40.877386
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_of_type, find_first_occurrence
    from .base import BaseNodeTransformer


# Generated at 2022-06-21 18:13:46.397605
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    inputcode = """
    class A:
        def __init__(self):
            super().__init__()
    """
    i = ast.parse(inputcode)
    t = SuperWithoutArgumentsTransformer()
    expected = """
    class A:
        def __init__(self):
            super(A, self).__init__()
    """
    t.visit(i)
    assert ast.dump(i) == ast.dump(ast.parse(expected))



# Generated at 2022-06-21 18:13:57.670661
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    # Test 1
    test_tree1 = source_to_ast.parse('''
        class MyClass(object):
            def __init__(self, arg):
                super().__init__(arg)
    ''')

    transformer = SuperWithoutArgumentsTransformer(test_tree1)
    transformer.visit(test_tree1)


# Generated at 2022-06-21 18:14:30.294913
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.mock_tree import get_mock_tree


# Generated at 2022-06-21 18:14:37.706583
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..node_util import compare_ast

    # Test 1. Simple test:
    tree = ast.parse('''
        class Cls(object):
            def my_method(self):
                super()
    ''')

    expected = ast.parse('''
        class Cls(object):
            def my_method(self):
                super(Cls, self)
    ''')

    SuperWithoutArgumentsTransformer().visit(tree)
    assert compare_ast(tree, expected)

    # Test 2. Real world example
    tree = ast.parse('''
        class Cls(object):
            def get_absolute_url(self):
                return super().get_absolute_url()
    ''')


# Generated at 2022-06-21 18:14:46.051661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ... import transform
    from ...utils.helpers import module_from_node
    from ...utils.testing import assert_tree_equal

    transformer = SuperWithoutArgumentsTransformer(None)

    node = ast.parse('super()')
    transformer.visit(node)
    assert_tree_equal(module_from_node(node), module_from_node(ast.parse('super(Cls, self)')))
    assert transformer._tree_changed is True

    # Reset _tree_changed
    transformer._tree_changed = False
    node = ast.parse('super(foo, bar)')
    transformer.visit(node)
    assert_tree_equal(module_from_node(node), module_from_node(ast.parse('super(foo, bar)')))
    assert transformer._tree_changed is False


# Generated at 2022-06-21 18:14:48.873783
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..refactor import RefactoringTool, RefactoringError

# Generated at 2022-06-21 18:15:00.375676
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    sys.modules["typed_ast"] = sys.modules["ast"]
    
    from typed_ast import ast3 as ast
    from .base import NodeTransformer

    class Cls(NodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            self._tree = tree
            self._tree_changed = False

        def generic_visit(self, node: ast.AST) -> ast.AST:
            for field, old_value in ast.iter_fields(node):
                if isinstance(old_value, list):
                    new_values = []
                    for value in old_value:
                        if isinstance(value, ast.AST):
                            value = self.visit(value)
                            if value is None:
                                continue

# Generated at 2022-06-21 18:15:05.587630
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import os,sys
    sys.path.append(os.getcwd())
    from src.compat import byteify
    from .testutils.compiler import compile_snippet, assert_func_equals, load_function
    from ..utils.tree import get_node_of_type, find_all_nodes_of_type


# Generated at 2022-06-21 18:15:20.409188
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_source

    code = '''
        class A:
            def __init__(self):
                super()
        class B(A):
            def __init__(self):
                super()
                super().f()
        class C(Unrelated):
            def __init__(self):
                super()
    '''
    expected = '''
        class A:
            def __init__(self):
                super(A, self)
        class B(A):
            def __init__(self):
                super(B, self)
                super(B, self).f()
        class C(Unrelated):
            def __init__(self):
                super(C, self)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()

# Generated at 2022-06-21 18:15:26.215442
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("""class Test(object):
        def test(self):
            super()
            super()
            super()
        def test2(self):
            super(Test)
            super
    """)   # noqa: E501 line too long
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-21 18:15:37.191696
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.source import source_to_nodes
    from uuid import uuid4
    from ..utils.helpers import generate_dummy_code_for_class

    class_template = '''
    class Test{0}(object):
        def __init__(self):
            super().__init__()
    '''

    code = class_template.format(str(uuid4())[:8])
    print('---> compiling:')
    print(code)

    root_node = source_to_nodes(code)
    SuperWithoutArgumentsTransformer().visit(root_node)

    print('---> result:')
    print(astor.to_source(root_node))

# Generated at 2022-06-21 18:15:38.940612
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..utils import dump_ast


# Generated at 2022-06-21 18:16:46.269785
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test method visit_Call of class SuperWithoutArgumentsTransformer"""
    import astor


# Generated at 2022-06-21 18:16:53.739398
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.scope import Scope
    from ..utils.node_utils import remove_imports
    import astor

    # from typed_ast import ast3 as ast
    # from py2py3 import utils
    # from py2py3.utils.scope import Scope
    # from py2py3.translators.base import BaseNodeTransformer, tree_changed
    # from py2py3.parsers.utils import ClassParser


# Generated at 2022-06-21 18:17:00.518727
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import generate_visitor_test

    # see tests/visitor_tests/test_super_without_arguments_transformer.py for test data
    test_cases = generate_visitor_test('super_without_arguments')
    transformer = SuperWithoutArgumentsTransformer()

    for test_input, expected in test_cases:
        transformer.visit(test_input)
        assert test_input == expected, 'test failed for:\n{}\n---'.format(test_input)

# Generated at 2022-06-21 18:17:07.655282
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.helpers import compile_source
    from ..utils.helpers import assert_compiled_output
    from typed_ast import ast3 as ast
    
    transformer = SuperWithoutArgumentsTransformer()
    
    # Simple usage in methods
    source = u('''
    class SuperCls(object):
        def meth(self):
            super()

    class Cls(SuperCls):
        def meth(self):
            super()
    ''')
    

# Generated at 2022-06-21 18:17:15.823343
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import format_code, trim

    source = format_code('''
        class Parent:
            def __init__(self):
                super().__init__()
            
            def bar(self):
                super().bar()
            
            @classmethod
            def qux(cls):
                super().qux()
            
            @staticmethod
            def foo():
                super().foo()

        class Child(Parent):
            def __init__(self):
                super().__init__()
            
            def bar(self):
                super().bar()
            
            @classmethod
            def qux(cls):
                super().qux()
            
            @staticmethod
            def foo():
                super().foo()
        ''')


# Generated at 2022-06-21 18:17:25.364519
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # before
    input = """
        class A:
            def __init__(self):
                super()

        class B:
            def __init__(self):
                super()
    """
    tree = ast.parse(input)

    # action
    t = SuperWithoutArgumentsTransformer()
    tree = t.visit(tree)

    # after
    output = """
        class A:
            def __init__(self):
                super(A, self)

        class B:
            def __init__(self):
                super(B, self)
    """
    assert ast.dump(tree, include_attributes=True) == ast.dump(ast.parse(output), include_attributes=True)

# Generated at 2022-06-21 18:17:26.132929
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:29.041176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def test_method_1():
        super()

    def test_method_2():
        super(Cls, self)

    node = ast.parse(dedent(inspect.getsource(test_method_1))).body[0]
    SuperWithoutArgumentsTransformer(node).visit(node)
    assert_code_equal(inspect.getsource(test_method_2), node)

# Generated at 2022-06-21 18:17:30.553599
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

# Generated at 2022-06-21 18:17:40.437257
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast_parser import cst_to_ast
    from ..utils.helpers import example

    # noinspection PyUnusedLocal
    class Super:
        def __init__(self):
            super().__init__()

    tree = cst_to_ast(example(Super))
    transformer = SuperWithoutArgumentsTransformer(tree)

    node = tree.body[0].body[0].value
    node = transformer.visit(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Attribute)
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Super'  # type: ignore