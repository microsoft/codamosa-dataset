

# Generated at 2022-06-21 18:08:12.534347
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = """super()"""
    tree = ast.parse(s)  # type: ignore
    SuperWithoutArgumentsTransformer(tree).run()
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Str(s='Cls'), Name(id='self', ctx=Load())], keywords=[]))])"

    s = """a.super()"""
    tree = ast.parse(s)  # type: ignore
    SuperWithoutArgumentsTransformer(tree).run()
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Attribute(value=Name(id='a', ctx=Load()), attr='super', ctx=Load()), args=[], keywords=[]))])"

    s

# Generated at 2022-06-21 18:08:13.677213
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:14.660188
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:18.533136
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_transformer
    return run_transformer(SuperWithoutArgumentsTransformer, 'super()', 'super(Cls, self)')

# Generated at 2022-06-21 18:08:30.692504
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import sys
    import textwrap
    from ..utils import test_utils

    cls_def = textwrap.dedent("""\
    class Cls:
        def __init__(self):
            super()
    """)

    module = test_utils.build_module("""\
    {}
    """.format(cls_def), __file__)
    module_2 = test_utils.build_module("""\
    {}
    """.format(cls_def), __file__)

    tree = test_utils.build_typed_ast_from_text(cls_def)

    transformer = SuperWithoutArgumentsTransformer(tree, sys.modules[__name__])

    assert module.body[0] == module_2.body[0]

# Generated at 2022-06-21 18:08:42.962403
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from .. import ast_converter

    class MockCompiler(ast_converter.Compiler):

        def __init__(self):
            super().__init__()
            self._tree_changed = False

        def mark_changed(self):
            self._tree_changed = True

    class MockClassDef(ast.ClassDef):

        def __init__(self):
            self.name = "MockClass"

        def __str__(self):
            return self.name

    class MockFunctionDef(ast.FunctionDef):

        def __init__(self):
            self.name = "MockFunction"

        def __str__(self):
            return self.name

        def find_body_node(self, node_name: str) -> ast.AST:
            if node_name == self.name:
                return

# Generated at 2022-06-21 18:08:47.871794
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "class A: def b(self): super()"
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree, code=code)
    transformer.visit(tree)
    assert transformer.transformed_code == "class A: def b(self): super(A, self)"

# Generated at 2022-06-21 18:08:49.196303
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:59.397867
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Two test cases for this method.
    # case 1:
    #   Given: valid super()
    #   node.func is a Name
    #   node.func.id is "super" (case 1)
    #   node.args is empty
    #   Expected: super(Cls, self)
    tree = ast.parse("""
        class Test(object):
            def f(self):
                super()
                self.g()
            def g(self):
                pass
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed == True

    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.ClassDef)
    cls: ast.ClassDef = tree.body[0]
   

# Generated at 2022-06-21 18:09:10.376458
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test module SuperWithoutArgumentsTransformer
    """

    node = ast.parse("""
    class Cls:
        def __init__(self):
            super()
            super()
    """)

    tree = SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-21 18:09:14.966075
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_node
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-21 18:09:23.740949
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    src = '''
    class Cls:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    '''
    expected = '''
    class Cls:
        def __init__(self, *args, **kwargs):
            super(Cls, self).__init__(*args, **kwargs)
    '''
    tree = ast.parse(src)
    t = SuperWithoutArgumentsTransformer(tree)
    t.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))


# Generated at 2022-06-21 18:09:27.387621
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap
    code = 'super().foo()'
    tree = ast.parse(textwrap.dedent(code))

    transformer = SuperWithoutArgumentsTransformer(tree, None)
    transformer.visit(tree)


# Generated at 2022-06-21 18:09:34.716809
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import test_utils as tu
    from ..utils.test_utils import nodes as n

    node = tu.parse('''
        class A:
            def __init__(self):
                super()
    ''')

    t = SuperWithoutArgumentsTransformer()
    t.visit(node)

    assert tu.ast_to_str(node) == '''
        class A:
            def __init__(self):
                super(A, self)
    '''


# Generated at 2022-06-21 18:09:38.269711
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert SuperWithoutArgumentsTransformer.visit_Call(None, ast.parse("super()").body[0]) == \
        ast.parse("super(Cls, self)").body[0]

# Generated at 2022-06-21 18:09:40.077610
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:41.184656
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:51.881661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    visitor = SuperWithoutArgumentsTransformer()

    assert visitor.visit(ast.parse('super()')) == ast.parse('super(Cls, self)')
    assert visitor.visit(ast.parse('super(a)')) == ast.parse('super(a)')
    assert visitor.visit(ast.parse('super(1, 2)')) == ast.parse('super(1, 2)')
    assert visitor.visit(ast.parse('super(1, 2, 3)')) == ast.parse('super(1, 2, 3)')
    assert visitor.visit(ast.parse('super(1, 2, 3, 4)')) == ast.parse('super(1, 2, 3, 4)')

# Generated at 2022-06-21 18:10:02.163023
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = ast.parse('''
    class A:
        def f(self):
            super()
    ''')
    SuperWithoutArgumentsTransformer().visit(t)
    assert t == ast.parse('''
    class A:
        def f(self):
            super(A, self)
    ''')

    t = ast.parse('''
    class A:
        def f(self, b):
            super()
    ''')
    SuperWithoutArgumentsTransformer().visit(t)
    assert t == ast.parse('''
    class A:
        def f(self, b):
            super(A, self)
    ''')

    t = ast.parse('''
    class A:
        def f(a):
            super()
    ''')
    Super

# Generated at 2022-06-21 18:10:04.463174
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from .. import _ast_converter

# Generated at 2022-06-21 18:10:18.412669
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.test_utils import build_ir
    from .base import BaseNodeTransformer

    class _Transformer(BaseNodeTransformer):
        """An empty transformer"""

    source = '''class A:
        def f(self):
            return super()
        '''

    tree = build_ir(source, TransformerClass=SuperWithoutArgumentsTransformer)
    assert astor.to_source(tree) == dedent('''\
    class A:
        def f(self):
            return super(A, self)
        ''')


# Generated at 2022-06-21 18:10:26.754468
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Checks that the 'super()' is successfully replaced by 'super(Cls, self) or super(Cls, cls)'."""
    from .. import transformers
    from typed_ast import ast3 as ast

    tree = ast.parse('class B: pass\nclass C(B):\n    def __init__(self):\n        super()')
    tree = SuperWithoutArgumentsTransformer(verbose=0)(tree)
    assert transformers.to_source(tree).strip() == 'class B: pass\nclass C(B):\n    def __init__(self):\n        super(C, self)'

# Generated at 2022-06-21 18:10:29.308946
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]  # type: ignore
    transformer = SuperWithoutArgumentsTransformer()
    transformer.generic_visit(node)

# Generated at 2022-06-21 18:10:37.063179
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class Cls:
            
            def m(self):
                super()
                
            @classmethod
            def cm(cls):
                super()
            '''
    
    
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(Cls, self)' in astor.to_source(tree)
    assert 'super(Cls, cls)' in astor.to_source(tree)

# Generated at 2022-06-21 18:10:46.534865
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from .stub_node import S

    from .test_BaseNodeTransformer import transform

    case1 = S.Expr(S.Call(S.Name('super'), []))
    case2 = S.Expr(S.Call(S.Name('super'), [S.Name('a')]))
    case3 = S.FunctionDef('f', S.arguments([S.arg('a')], None, None, None), [
        S.Expr(S.Call(S.Name('super')))], [])
    case4 = S.ClassDef('C', [], [], [
        S.FunctionDef('f', S.arguments([S.arg('a')], None, None, None), [
            S.Expr(S.Call(S.Name('super')))], [])])

    case5 = S.Function

# Generated at 2022-06-21 18:10:47.198144
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:49.313836
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing.test_utils import compile_source_to_ast as to_ast


# Generated at 2022-06-21 18:10:56.935565
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    tree_str = ast.dump(tree)
    assert tree_str == "Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-21 18:11:00.629617
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Super(Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load()))"

# Generated at 2022-06-21 18:11:06.880124
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from .test_base import compile_code, transform_source

    code = """
    class A:
        def f(self):
            super()
    """

    comp = compile_code(code, 'file.py')
    module = comp.tree
    result = transform_source(module, SuperWithoutArgumentsTransformer)

    assert result.strip() == astor.to_source(module).strip()

# Generated at 2022-06-21 18:11:25.829354
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test case for class SuperWithoutArgumentsTransformer, method visit_Call.
    """
    from ..tests.utils.tree import ast_from_str
    from ..tests.utils.tree import ast_equals
    from ..tests.utils.helpers import get_test_data
    from ..tests.utils.helpers import restore_test_data
    from ..utils.helpers import get_python_path
    from .base import run_transformer_on_file

    # Test case 1
    raw_data = get_test_data('FunctionDef_1.py')
    raw_data = raw_data.replace('super()', 'super(Cls, cls)')
    tree = ast_from_str(raw_data)
    node = tree.body[0]

    transformer = SuperWithoutArgumentsTransformer(tree)
   

# Generated at 2022-06-21 18:11:37.279363
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    from typed_ast.ast3 import parse
    from ..utils.helpers import unparse

    code = """class A(object):
        def m(self):
            super()
    """
    tree = parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    assert unparse(tree) == code.replace('super()', 'super(A, self)')

    code = """class A(object):
        def m(self):
            super()
    """
    tree = parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    assert unparse(tree) == code.replace('super()', 'super(A, self)')


# Generated at 2022-06-21 18:11:44.206490
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_helpers import get_ast
    from astunparse import unparse
    from .constructor import check_ast
    # Set up initial class
    test_ast = get_ast("""class A(object):
        def __init__(self):
            super()
            """)
    test_ast_2 = get_ast("""class A(object):
        def __init__(self, *args):
            super()
            """)
    test_ast_3 = get_ast("""class A(object):
        class B(object):
            def __init__(self):
                super()
        def __init__(self):
            super()
            """)

# Generated at 2022-06-21 18:11:47.436559
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    'visit_Call()'

    super_without_arguments = 'super()'

# Generated at 2022-06-21 18:11:55.510962
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from asttokens import ASTTokens
    from ..utils.helpers import get_ast
    from .base import BaseNodeTransformer

    source = '''class Cls(object):
    def foo(self):
        super()
'''

    expected_result = '''class Cls(object):
    def foo(self):
        super(Cls, self)
'''

    tree = get_ast(ASTTokens(source, parse=True))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert BaseNodeTransformer.compare_trees(tree, expected_result)



# Generated at 2022-06-21 18:12:02.001654
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """

    module, _ = ast_parse(code)
    transformer = SuperWithoutArgumentsTransformer(module)
    new_module = transformer.visit(module)

    assert_equals(
        'class A:\n    def __init__(self):\n        super(A, self)\n',
        unparse(new_module).strip(),
    )

# Generated at 2022-06-21 18:12:12.067354
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import compile_source, get_ast_node, dump_tree
    from ...__main__ import run_backwards_transpilers
    import ast
    import astunparse

    source = source_to_unicode('''
    class Cl:
        def __init__(self):
            super()
    ''')
    old_tree = compile_source(source, '<test>', 'exec')
    new_tree = compile_source(source, '<test>', 'exec')
    run_backwards_transpilers(new_tree, python_version=(2, 7))

    old_func_init = get_ast_node(old_tree.body[0], ast.FunctionDef)
    new_func_init = get_ast_

# Generated at 2022-06-21 18:12:16.775125
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_migrated

    code = '''
        class A:
            def __init__(self):
                super()
    '''

    expected = '''
        class A:
            def __init__(self):
                super(A, self)
    '''
    assert_migrated(
        SuperWithoutArgumentsTransformer,
        code,
        expected,
    )

# Generated at 2022-06-21 18:12:17.708820
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:24.065462
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_str = '''class Foo:
    def bar(self):
        return super()'''

    tree = ast.parse(test_str)
    SuperWithoutArgumentsTransformer().visit(tree)
    expected_str = '''class Foo:
    def bar(self):
        return super(Foo, self)'''
    assert astor.to_source(tree) == expected_str

# Generated at 2022-06-21 18:12:41.919751
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import parse

    node = parse('super(a, b).do_it()', mode='eval')

    # Test inner call
    new_node = SuperWithoutArgumentsTransformer._replace_super_args(node.body)  # type: ignore
    assert new_node.func.id == 'do_it'

    # Test with sub expr
    node = parse('super(a, b).do_it()', mode='eval')

    new_node = SuperWithoutArgumentsTransformer._replace_super_args(node.body)  # type: ignore
    assert new_node.func.id == 'do_it'

    # Test with arguments
    node = parse('super(a, b)', mode='eval')


# Generated at 2022-06-21 18:12:46.587532
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import assert_code_equal, load_example

    example = load_example('super_without_args')
    tree = example['python_tree']
    expected = example['expected']

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)  # type: ignore
    assert_code_equal(tree, expected)

# Generated at 2022-06-21 18:12:47.711105
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:12:57.756358
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'super()\n'
    func_name = 'func'
    cls_name = 'Cls'
    func_args = 'a'
    expected = f'class {cls_name}:\n    def {func_name}({func_args}):\n        super({cls_name}, {func_args})\n'
    tree = ast.parse(code)  # type: ast.Module
    tree: ast.Module
    tree.body[0].body[0].name = func_name
    tree.body[0].name = cls_name
    tree.body[0].body[0].args.args[0].arg = func_args
    func = tree.body[0].body[0]  # type: ast.FunctionDef
    func: ast.FunctionDef

    actual = SuperWithoutArg

# Generated at 2022-06-21 18:13:08.754372
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class TransformTest(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(object):
        def method(self):
            super().method2()

    tree = ast.parse(inspect.getsource(Test.method))
    TransformTest().visit(tree)

    assert len(tree.body[0].body[0].value.args) == 2
    assert isinstance(tree.body[0].body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].body[0].value.args[1], ast.Name)
    assert tree.body[0].body[0].value.args[0].id == 'Test'
    assert tree.body

# Generated at 2022-06-21 18:13:09.549133
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:13.768332
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    node = tree.body[0]

    transformer = SuperWithoutArgumentsTransformer('__module__')
    transformer.visit_Call(node)

    assert node.args[0].id == '__module__'
    assert node.args[1].id == '__module__'

# Generated at 2022-06-21 18:13:24.140399
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        class One:
            def one(self):
                super().one()
    ''')
    node = tree.body[0].body[0].body[0]
    SuperWithoutArgumentsTransformer(tree).visit(node)
    assert isinstance(node.func, ast.Name) and node.func.id == 'super'
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name) and node.args[0].id == 'One'
    assert isinstance(node.args[1], ast.Name) and node.args[1].id == 'self'

# Generated at 2022-06-21 18:13:25.390781
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:31.687315
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call

    source = source_to_unicode("super()")
    node = ast_call(source)
    assert len(node.args) == 0

    transformer = SuperWithoutArgumentsTransformer()
    node = transformer.visit(node)
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert isinstance(node.args[1], ast.Name)
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'

# Generated at 2022-06-21 18:13:57.076937
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    t = SuperWithoutArgumentsTransformer()

    class_def = ast.ClassDef('A', [], [], [], [])
    func = ast.FunctionDef('foo', ast.arguments(args=[ast.Name(id='self')], vararg=None, kwarg=None, defaults=[]), [], [], None)
    func.body.append(ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[], keywords=[])))
    class_def.body.append(func)
    t.visit(class_def)
    assert len(func.body[0].value.args) == 2
    assert isinstance(func.body[0].value.args[0], ast.Name)

# Generated at 2022-06-21 18:14:07.152257
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = """
    class Test:
        def __init__(self):
            super()
    """
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(s))

# Generated at 2022-06-21 18:14:11.175113
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """\
        super()
    """
    expected_code = """\
        super(Cls, self)
    """
    tree = ast.parse(dedent(code))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert expected_code == astor.to_source(tree).strip()

# Generated at 2022-06-21 18:14:14.517263
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert isinstance(transformer._tree, ast.AST)
    expected_code = 'super(__class__, self)'
    assert codegen.to_source(transformer._tree) == expected_code

# Generated at 2022-06-21 18:14:16.872056
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..chained import ChainedTransformer
    import ast


# Generated at 2022-06-21 18:14:20.920433
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse

    class SubClass(object):
        pass

    SuperClass = SubClass

    class Target(SubClass):
        def __init__(self) -> None:
            super()


# Generated at 2022-06-21 18:14:25.054254
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert ast.dump(tree) == ast.dump(ast.parse('super(cls, self)'))


# Generated at 2022-06-21 18:14:26.024792
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:31.876193
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(self)' in astor.to_source(tree).strip()
    code = 'super(arg)'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert code in astor.to_source(tree).strip()

# Generated at 2022-06-21 18:14:40.327615
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    super_arguments = ast.parse("""
    class Class:
        def function(self):
            super()
    """)

    # Act
    transformer = SuperWithoutArgumentsTransformer(super_arguments)
    transformer.visit(super_arguments)
    transformed_function = super_arguments.body[0].body[0]

    # Assert
    assert transformed_function.args.args[0].arg == 'self'
    assert type(transformed_function.body[0].args[0].n) == ast.Name
    assert transformed_function.body[0].args[0].n.id == 'Class'



# Generated at 2022-06-21 18:15:24.724107
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_function_def, ast_class_def, ast_args, ast_arg, ast_name

    src_tree = ast.Module(body=[
        ast_class_def(
            name='Cls',
            body=[
                ast_function_def(
                    name='method',
                    args=ast_args(
                        args=[ast_arg(arg='self')], kwonlyargs=[]
                    ),
                    body=[
                        ast_call(func=ast_name(id='super'))
                    ]
                )
            ]
        )
    ])


# Generated at 2022-06-21 18:15:29.745674
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    super()
    """
    expect = """
    super(__Base, self)
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).run()
    assert ast.dump(ast.parse(expect)) == ast.dump(tree)

# Generated at 2022-06-21 18:15:39.331826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast_helper import parse, dump, compile_to_module
    from ..utils import cst as ast
    module = compile_to_module("super()")
    module = ast.parse_module(dump(module))
    cls = module.body[0].body[0]
    cls.name = "Cls"
    cls.bases = [ast.Name(id="object", ctx=ast.Load())]
    tree = SuperWithoutArgumentsTransformer().visit(parse(dump(module)))
    assert dump(tree).find(
        'super(Cls, self)') != -1 or dump(tree).find('super(Cls, cls)') != -1


# Generated at 2022-06-21 18:15:43.922012
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_importer import AstImporter
    from ..convert import SourceConverter
    from .. import load_ast


# Generated at 2022-06-21 18:15:52.156787
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from ._test_utils import _check_tree_changed, _test_ast, _TestTransformer

    class DummyTransformer(_TestTransformer):
        target = (3, 0)

        def visit_Call(self, node):
            return node

        def visit_ClassDef(self, node):
            return node

        def visit_FunctionDef(self, node):
            return node

    # test "super()" -> "super(Cls, self)"
    tree = _test_ast(dedent('''\
        class Cls:
            def __init__(self):
                super()
    '''))
    tree = DummyTransformer(tree).visit(tree)

# Generated at 2022-06-21 18:16:01.975951
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    instance = SuperWithoutArgumentsTransformer(None)
    funcdef = ast.FunctionDef(name="f", args=ast.arguments(args=[ast.arg(arg='self', annotation=None)], kwonlyargs=[], kw_defaults=[], vararg=None, kwarg=None), body=[ast.Return(value=ast.Call(func=ast.Name(id="super"), args=[], keywords=[])), ast.Return(value=ast.Call(func=ast.Name(id="super"), args=[ast.Name(id="arg")], keywords=[]))], decorator_list=[], returns=None)

# Generated at 2022-06-21 18:16:06.516004
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    text = """class C:
    def f(self):
        super()
    """

    tree = ast.parse(text)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert tree.body[0].body[0].body[0].value.args[0].id == 'C'
    assert tree.body[0].body[0].body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:16:13.893245
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast

    code = '''
        class Cls:
            def __init__(self):
                super()
    '''

    tree = ast.parse(source_to_unicode(code))
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    BaseNodeTransformer.raise_on_unused_args(tree)
    assert ast.dump(tree) == code.replace('super()', 'super(Cls, self)')


# Generated at 2022-06-21 18:16:25.009133
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_helpers import source_to_tree
    from .return_self_transformer import ReturnSelfTransformer
    from .yield_iterable_transformer import YieldIterableTransformer
    from .remove_decorator_assignment_transformer import RemoveDecoratorAssignmentTransformer
    from .remove_ellipsis_transformer import RemoveEllipsisTransformer
    from .yield_from_transformer import YieldFromTransformer
    from .nonlocal_transformer import NonlocalTransformer
    from .with_as_variable_transformer import WithAsVariableTransformer
    from .metaclass_transformer import MetaclassTransformer
    from .reassign_self_transformer import ReassignSelfTransformer


# Generated at 2022-06-21 18:16:34.143582
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from typed_ast import ast3 as ast
    import astunparse

    # Tests for the case when super() is a call outside of a function and a class
    tree = ast.parse("super()", mode='eval')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astunparse.unparse(tree) == "super()"

    # Tests for the case when super() is a call outside of a function but inside a class
    tree = ast.parse("class Test:\n\tsuper()", mode='eval')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astunparse.unparse(tree) == "class Test:\n    super()"

    # Tests for the case when super() is a call outside of a class but inside a function