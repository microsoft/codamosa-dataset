

# Generated at 2022-06-21 18:08:06.427030
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO: mock tree, test if correct arguments are injected
    pass

# Generated at 2022-06-21 18:08:07.472567
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:18.204375
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_code_1 = """
    class Foo:
        def __init__(self):
            super()
    """

    expected_result_1 = """
    class Foo:
        def __init__(self):
            super(Foo, self)
    """
    tree = ast.parse(test_code_1)
    node = tree.body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_result_1))

    test_code_2 = """
    class Test:
        def __init__(self):
            super()
        def __new__(cls):
            super()
    """


# Generated at 2022-06-21 18:08:21.763833
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astor import dumps
    import ast
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:08:33.447263
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from transpyle.general import PythonCodeGenerator
    from transpyle.general.code_formatter import format_code, format_ast

    tree = ast.parse('''
    class A(object):
        def _v(self):
            super()
        def _w(self):
            super.foo()
        def _x(self):
            super(A, self)
        def _y():
            super()
        def _z():
            super()
    ''')

    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    assert t.tree_changed() is True

    # print(format_code(PythonCodeGenerator.to_source(tree)))
    # print(format_ast(tree))

# Generated at 2022-06-21 18:08:35.145086
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:38.901967
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import Py2to3TreeTransformer
    from ..utils.parsers import get_python_parser
    from ..utils.helpers import tree_to_str
    parser = get_python_parser()

# Generated at 2022-06-21 18:08:50.544209
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')

    """
    Module(
        body=[
            Expr(value=Call(
                func=Name(id='super', ctx=Load()),
                args=[], keywords=[], starargs=None, kwargs=None
            ))
        ]
    )
    """

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)

    result = ast.dump(node)


# Generated at 2022-06-21 18:08:53.011257
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed


# Generated at 2022-06-21 18:09:01.283362
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import get_fixture
    from .unpacking import UnpackingTransformer
    from .annotations import AnnotationRemover

    fixture = get_fixture('super.py')
    tree = ast.parse(fixture)

    transformer1 = AnnotationRemover()
    transformer2 = UnpackingTransformer()
    transformer3 = SuperWithoutArgumentsTransformer()
    
    transformer1.visit(tree)
    transformer2.visit(tree)
    transformer3.visit(tree)

    ret = astor.to_source(tree)
    print(ret)

# Generated at 2022-06-21 18:09:14.112850
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Test case 1: super() outside of function and class

    node_tree_before = ast.parse("""
        super()
    """)

    node_tree_after = SuperWithoutArgumentsTransformer.run_single_visit(node_tree_before)
    assert node_tree_after == ast.parse("""
        super()
    """)

    # Test case 2: super() inside of a method and a class

    node_tree_before = ast.parse("""
        class Test:
            def test_method(self):
                super()
    """)

    node_tree_after = SuperWithoutArgumentsTransformer.run_single_visit(node_tree_before)

# Generated at 2022-06-21 18:09:14.746973
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:25.305444
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from textwrap import dedent
    from ..utils.helpers import tree_from_src

    # case 1: super() outside of function
    src1 = 'super()'
    tree1 = tree_from_src(src1)
    SuperWithoutArgumentsTransformer(tree1).visit()
    result1 = astor.to_source(tree1).strip()
    expected_result1 = dedent('''\
    super(Cls, self)
    ''')

    # case 2: super() outside of class
    src2 = '''
    class A:
        def f():
            super()
    '''
    tree2 = tree_from_src(src2)
    SuperWithoutArgumentsTransformer(tree2).visit()

# Generated at 2022-06-21 18:09:32.058975
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.parse('super()')
    fname = '__main__'
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert tree is not None
    assert tree.body[0].value.args[0].id == 'cls'
    assert tree.body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:09:43.471395
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""if True:
        super()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert isinstance(tree.body[0].body[0], ast.Call)
    assert isinstance(tree.body[0].body[0].args[0], ast.Name)
    assert tree.body[0].body[0].args[0].id == 'Cls'
    assert isinstance(tree.body[0].body[0].args[1], ast.Name)

    tree = ast.parse("""if True:
        super()
    """, mode='eval')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert isinstance(tree.body, ast.Call)

# Generated at 2022-06-21 18:09:48.060271
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(node)
    new_node = transformer.visit(node)
    assert unparse(new_node) == 'super(cls, self)'



# Generated at 2022-06-21 18:09:53.700288
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Compile the following input code
    in_code = """
        class Foo:
            def bar(cls):
                super()
    """
    # To the following output code
    out_code = """
        class Foo:
            def bar(cls):
                super(Foo, cls)
    """
    # Set up the test case
    test_case = TestCase(in_code, out_code)
    # And test it
    test_case.test_transform(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:09:59.376499
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""
        super()
    """)
    tree = ast3.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    codeobj = compile(tree, "<ast>", "exec")
    ns = {}
    exec(codeobj, ns)
    assert False, 'implement tests'

# Generated at 2022-06-21 18:10:12.453412
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse("super()")

    class TestTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)

        def visit_Name(self, node):
            self._tree_changed = True
            return ast.Name()

        def visit_Expr(self, node):
            self._tree_changed = True
            return node

    transformer = TestTransformer(module)
    module = transformer.visit(module)
    assert not transformer._tree_changed
    assert isinstance(module, ast.Module)

    transformer = TestTransformer(module)
    module = transformer.visit(module)
    assert transformer._tree_changed
    assert isinstance(module, ast.Module)

    transformer = SuperWithoutArgumentsTransformer(module)
    module = transformer.visit

# Generated at 2022-06-21 18:10:14.043220
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:20.335026
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    x = ast.parse('x=super().f()')
    node = x.body[0].value
    expected_output = 'x=super(Cls, self).f()'

    transformer = SuperWithoutArgumentsTransformer(x)
    transformer.visit(x)
    code = compile(x, '<string>', 'exec')

    exec(code)
    assert x == ast.parse(expected_output)
    assert str(x) == expected_output
    assert str(node) == 'super(Cls, self).f()'

# Generated at 2022-06-21 18:10:30.606923
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import cst_to_ast
    from .test_helpers import _compare_ast

    code = 'super()'  # syntax error
    tree = cst_to_ast.parse(code)
    # match_attrs -> ('id', 'args', 'body', 'decorator_list', 'name', 'returns', 'arguments', 'ctx')
    # get_closest_parent_of(tree, tree.body[0].value, ast.FunctionDef) -> ValueError('node not found')
    # SuperWithoutArgumentsTransformer(tree).visit(tree) -> tree
    new_tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected_code = code

# Generated at 2022-06-21 18:10:42.479591
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = parse('''
    class Cls(object):
        def __init__(self, x):
            super().__init__(x)
        def method(self):
            super().method()
        @classmethod
        def class_method(cls):
            super().class_method()
        @staticmethod
        def static_method():
            super().static_method()
    ''')
    transformer = SuperWithoutArgumentsTransformer.create_from_tree(tree)
    transformer.visit(tree)
    assert transformer.tree_changed

# Generated at 2022-06-21 18:10:45.094425
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..transforms.super_without_arguments import SuperWithoutArgumentsTransformer
    from ..utils import cst_to_ast, parse


# Generated at 2022-06-21 18:10:57.155095
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import test_utils

    class Test:
        def __init__(self):
            self.x = "x"
            super()

        def method(self):
            super().method()

    expect_ast = test_utils.build_ast(Test)
    expect_src = test_utils.build_src(Test)

    class Test(metaclass=test_utils.MockMetaPathFinder):
        def __init__(self):
            self.x = "x"
            super(Test, self)

        def method(self):
            super(Test, self).method()

    tree = test_utils.build_module(Test)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert test_utils.cmp_ast(tree, expect_ast)
    assert test_utils

# Generated at 2022-06-21 18:11:05.588126
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import assert_equal_ast

    assert_equal_ast(
        """
        class A:
            def __init__(self):
                super().__init__()

        class B(A):
            def __init__(self):
                super().__init__()
        """,
        """
        class A:
            def __init__(self):
                super(A, self).__init__()

        class B(A):
            def __init__(self):
                super(B, self).__init__()
        """,
        [SuperWithoutArgumentsTransformer]
    )

# Generated at 2022-06-21 18:11:07.512986
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake_context import FakeContext
    context = FakeContext()

# Generated at 2022-06-21 18:11:11.368360
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Unit test for method visit_Call of class SuperWithoutArgumentsTransformer.
    
    """
    from .. import utils
    module_path = utils.get_path_to_this_module()
    module_name = utils.path_to_modulename(module_path)

# Generated at 2022-06-21 18:11:12.200934
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:23.189843
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    with open('./tests/fixtures/transforms/super_without_args.py') as f:
        src = f.read()
        tree = ast.parse(src)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    with open('./tests/fixtures/transforms/super_without_args_expected.py') as f:
        expected = f.read()

    gen = ast.PyCF_ONLY_AST.to_code(tree)
    compiled = compile(gen, filename="<ast>", mode="exec")
    code = marshal.dumps(compiled)
    codeObject = types.CodeType(*marshal.loads(code)[:6])
    source = codeObject.co_code.decode("utf-8")

    return src == expected and expected == source

# Generated at 2022-06-21 18:11:40.446858
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:48.095197
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import to_source
    tree = ast.parse('super()', mode='exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert to_source(tree) == 'super(Cls, self)'

    tree = ast.parse('super(baz=None)', mode='exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert to_source(tree) == 'super(Cls, self, baz=None)'

# Generated at 2022-06-21 18:11:49.124410
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:56.874514
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Test SuperWithoutArgumentsTransformer by compiling an ast and then transforming it back to a string. Compare with expected output
    """
    import astor
    tree = ast.parse('''class C(object):
    def __init__(self, arg):
        super().__init__(arg)''')
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    compiled_source = astor.to_source(tree)
    expected_output = '''class C(object):\n    def __init__(self, arg):\n        super(C, self).__init__(arg)'''
    assert compiled_source == expected_output

# Generated at 2022-06-21 18:11:58.128990
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-21 18:11:59.575169
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:08.961368
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from py2to3.tests.test_utils import make_2_and_3_code
    f = make_2_and_3_code("""
    class A(object):
        def __init__(self):
            super().__init__()
        @classmethod
        def f(cls):
            super().f()
    """)
    assert f(2).code == f(3).code
    """
    class A(object):
        def __init__(self):
            super(A, self).__init__()
        @classmethod
        def f(cls):
            super(A, cls).f()
    """

# Generated at 2022-06-21 18:12:17.980327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Simple test of transformer
    from ..utils.source_code_to_ast import source_code_to_ast
    source = '''
        class C(object):
            def d(self):
                super()
    '''
    tree = source_code_to_ast(source=source)
    t = SuperWithoutArgumentsTransformer(tree=tree)
    t.visit(tree)

# Generated at 2022-06-21 18:12:29.474559
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class MockNode:
        args = []
        name = "MockNode"

    class MockNode2:
        args = [MockNode(name="arg1")]
        name = "MockNode2"

    # Test case 1: super()
    tree = {
        "__class__": ast.Call,
        "func": {
            "__class__": ast.Name,
            "id": "super",
        },
        "args": [],
    }
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    assert tree == {
        "__class__": ast.Call,
        "func": {
            "__class__": ast.Name,
            "id": "super",
        },
        "args": [MockNode(name="arg1")],
    }


# Generated at 2022-06-21 18:12:33.276140
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """super()"""
    tree = ast.parse(source)
    node = tree.body[0]
    SuperWithoutArgumentsTransformer(tree).visit(node)

    assert type(node) is ast.Call
    assert type(node.func) is ast.Name
    assert type(node.args[0]) is ast.Name

# Generated at 2022-06-21 18:12:48.625129
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from typed_ast.codegen import CodeGenerator


    code = """\
    class Cls:
        def func(self):
            super()
    """

    expected = """\
    class Cls:
        def func(self):
            super(Cls, self)
    """

    tree = ast3.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    gen = CodeGenerator()
    result = gen.visit(tree)

    #print(result)

    assert result == expected

# Generated at 2022-06-21 18:12:54.552010
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    node = ast.Call(func=ast.Name(id='super'), args=[])
    transformer = SuperWithoutArgumentsTransformer()

    # When
    transformer._replace_super_args(node)
    result = transformer.visit(node)

    # Then
    assert result.args[0].id == 'Cls_Class'
    assert result.args[1].id == 'self'

# Generated at 2022-06-21 18:13:01.697976
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
        class C:
            def __init__(self):
                super()
            def f(self):
                def f2(self2):
                    super()
                super()
        '''
    expected_code = '''
        class C:
            def __init__(self):
                super(C, self)
            def f(self):
                def f2(self2):
                    super(C, self)
                super(C, self)
        '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree, code)
    transformer.visit(tree)
    assert astor.to_source(tree).strip() == expected_code.strip()


# Generated at 2022-06-21 18:13:05.157823
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    code = """
    class Test:
        def __init__(self):
            super()
    """

    tree = source_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    code_expected = """
    class Test:
        def __init__(self):
            super(Test, self)
    """

    tree_expected = source_to_ast(code_expected)
    assert tree_expected == tree

# Generated at 2022-06-21 18:13:14.320321
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """this test prove that class SuperWithoutArgumentsTransformer
    can replace super() with super(cls,self).
    """
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import ast_from_str, build_function_def

    def test_func(a):
        return super()

    t = ast_from_str(test_func)
    t.body[0].body[0].value = build_function_def(t.body[0].body[0].value, params=[ast.arg(arg='a', annotation=None)])
    t = SuperWithoutArgumentsTransformer(t).visit(t)
    assert t.body[0].body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:13:16.396176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    # Test 1: Test super() outside of function

# Generated at 2022-06-21 18:13:28.313810
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import compare_ast


# Generated at 2022-06-21 18:13:30.598657
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_string
    import ast as pyast

# Generated at 2022-06-21 18:13:41.325844
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .utils import get_node_as_str
    from .utils import compare_node

    # Testing for super() -> super(Cls, self)
    code = 'a = super()'
    expected_code = 'a = super(Test, self)'

# Generated at 2022-06-21 18:13:42.777436
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ...utils.ast_builder import build_ast


# Generated at 2022-06-21 18:14:00.826462
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...codegen import to_source
    from ..tests.utils import transform_and_compare


# Generated at 2022-06-21 18:14:10.710298
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.func, ast.Name)
    assert node.body[0].value.func.id == 'super'
    assert len(node.body[0].value.args) == 2
    assert isinstance(node.body[0].value.args[0], ast.Name)
    assert node.body[0].value.args[0].id == 'Cls'
    assert isinstance(node.body[0].value.args[1], ast.Name)
    assert node.body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:14:11.793343
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import transform
    from ..utils.helpers import get_call_names

# Generated at 2022-06-21 18:14:22.029847
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .rewrite_utils import parse_visit_and_dump

    code = 'super()'
    tree = parse_visit_and_dump(code, SuperWithoutArgumentsTransformer)
    expected = ast3.parse('''
    class A:
        def foo(self):
            super(A, self)
    ''')
    assert ast3.dump(tree) == ast3.dump(expected)

    code = '''
    class A:
        def foo(self):
            super(A, self)
            super(A, self)
            def bar():
                super()
                super()
    '''
    tree = parse_visit_and_dump(code, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:14:23.602845
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


# Generated at 2022-06-21 18:14:24.921228
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-21 18:14:25.926834
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:26.877881
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


# Generated at 2022-06-21 18:14:32.337370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse(
        "super()"
    )
    tree_2 = copy.deepcopy(tree)
    transformer = SuperWithoutArgumentsTransformer(tree)

    tree_2.body[0].value.args = [ast.Name(id="Cls"), ast.Name(id="self")]

    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(tree_2)

# Generated at 2022-06-21 18:14:35.608601
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast
    code = "super()"
    tree = ast.parse(code)
    obj = SuperWithoutArgumentsTransformer(tree)
    obj.run()
    assert str(tree) == "super(Cls, self)"

# Generated at 2022-06-21 18:15:11.640863
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:23.686818
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..utils.helpers import node_to_string

    context = Context()
    node = ast.parse('super()')
    for n in node.body:
        SuperWithoutArgumentsTransformer(context).visit(n)
    result = node_to_string(node)
    assert result == 'super(self)'

    context = Context()
    node = ast.parse('super()')
    node.body[0].args[0].ctx = ast.Load()
    for n in node.body:
        SuperWithoutArgumentsTransformer(context).visit(n)
    result = node_to_string(node)
    assert result == 'super(cls)'

# Generated at 2022-06-21 18:15:35.079303
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # NodeInstantiator should be used here. But type of arg isn't Call.
    # NodeInstantiator can create only nodes with callable type as arg
    call = ast.Call(func=ast.Name(id='super',
                                  ctx=ast.Load()),
                    args=[], keywords=[],
                    starargs=None, kwargs=None)

    transformer = SuperWithoutArgumentsTransformer()

    # no changes
    call = transformer.visit(call)
    assert transformer._tree_changed == False
    assert call == ast.Call(func=ast.Name(id='super',
                                          ctx=ast.Load()),
                            args=[], keywords=[],
                            starargs=None, kwargs=None)


# Generated at 2022-06-21 18:15:36.999577
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import compile_source
    from . import run_module

# Generated at 2022-06-21 18:15:39.787119
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import cst_to_ast
    from ..meta import pseudo_parse
    from .base import BaseNodeTransformer, AutoNumberTransformer
    from .types import TypedTransformer
  

# Generated at 2022-06-21 18:15:43.285914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import get_parser
    from ..utils.source import source_to_unicode as u


# Generated at 2022-06-21 18:15:48.737684
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    tree = ast3.parse('class A:\n def __init__(self):\n  super(A, self)')
    expected = ast3.parse('class A:\n def __init__(self):\n  super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert ast3.dump(tree) == ast3.dump(expected)

# Generated at 2022-06-21 18:15:59.422273
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    code = """
    class A:
        def a_method(self):
            super(A, cls)
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-21 18:16:07.118025
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    from ..node_utils import iter_all_ast_nodes

    expected_ast = compile_to_ast('''
        class MyClass:
            def __init__(self):
                if (super(MyClass, self).__init__()):
                    pass
    ''')

    for node in iter_all_ast_nodes(expected_ast):
        if isinstance(node, ast.Call):
            assert len(node.args) == 2, node
        else:
            assert isinstance(node, (ast.FunctionDef, ast.ClassDef)), node

    source = '''
        class MyClass:
            def __init__(self):
                if (super().__init__()):
                    pass
    '''

# Generated at 2022-06-21 18:16:08.380594
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import normalize
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:17:35.629239
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_astunparse
    node = ast.parse('super()')
    fixer = SuperWithoutArgumentsTransformer(node)
    fixed_code = typed_astunparse.unparse(fixer.visit(node))
    assert fixed_code == 'super(C, self)'

# Generated at 2022-06-21 18:17:44.398816
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class FakeVisitor:
        def __init__(self, tree: ast.Module) -> None:
            class FakeVisitor:
                # _tree: ast.Module
                _tree_changed: bool
            self._tree = tree
            self._tree_changed = False

    class FakeNode:
        class FakeFuncType:
            def __init__(self, fake_id: str) -> None:
                self.id = fake_id
        class FakeArgsType:
            class FakeArgsTypeArg:
                def __init__(self, fake_arg: str) -> None:
                    self.arg = fake_arg
            def __init__(self, fake_arg: FakeArgsTypeArg) -> None:
                self.args = [fake_arg]


# Generated at 2022-06-21 18:17:54.860934
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import Module, Call, FunctionDef, Name, ClassDef
    # Given
    class_name = Name('TestClass')
    function_name = Name('TestFunction')
    node = Call(func=Name(id='super'), args=[])
    func = FunctionDef(name=function_name.id, args=FunctionDef._fields, body=[node])
    cls = ClassDef(name=class_name.id, body=[func])
    tree = Module([cls])
    transformer = SuperWithoutArgumentsTransformer(tree)

    # When
    transformer.visit(tree)

    # Then
    assert transformer._tree_changed is True

# Generated at 2022-06-21 18:17:56.113688
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3

# Generated at 2022-06-21 18:17:56.918694
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:18:06.272831
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that super() becomes super(Cls, self) and super(Cls, cls)"""
    code = '''\
    class A:
        def __init__(self):
            super()
    '''
    expected_output = '''\
    class A:
        def __init__(self):
            super(A, self)
    '''
    node = ast.parse(textwrap.dedent(code))
    transformer = SuperWithoutArgumentsTransformer(tree=node, version=(2, 7))
    output = transformer.run()
    result = ast.parse(textwrap.dedent(expected_output))
    assert output.body[0].body[0].body[0].args[0].id == result.body[0].body[0].body[0].args[0].id
    assert output.body