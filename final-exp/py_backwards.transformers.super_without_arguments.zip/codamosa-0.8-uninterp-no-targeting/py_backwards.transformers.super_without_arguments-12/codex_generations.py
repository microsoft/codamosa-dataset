

# Generated at 2022-06-21 18:08:04.752607
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    exp = ast.parse('super(Cls, self)')
    assert ast.dump(tree, include_attributes=False) == ast.dump(exp, include_attributes=False)

# Generated at 2022-06-21 18:08:13.447565
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..registry import register_transformer
    register_transformer(SuperWithoutArgumentsTransformer)

    import astor
    from ..utils.ast_builder import build_ast

    # Given
    source = """
    class A:
        def b(s):
            super()
    """
    expected = """
    class A:
        def b(s):
            super(A, s)
    """
    tree = build_ast(source)

    # When
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    # Then
    assert astor.to_source(tree) == expected

# Generated at 2022-06-21 18:08:14.128146
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:14.710080
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:08:21.857996
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code import test_node

    code1 = test_node('''
foo()
''')
    code2 = test_node('''
super()
''')
    code3 = test_node('''
super()
''', {'super': '__super'})

# Generated at 2022-06-21 18:08:24.656629
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import ast_to_source as ats


# Generated at 2022-06-21 18:08:37.030426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_node = ast.parse(textwrap.dedent("""
    class Test():
        def test(self):
            super()
    """))

    # Assert no errors
    transformer = SuperWithoutArgumentsTransformer(module_node)
    module_node = transformer.visit(module_node)

    assert isinstance(module_node.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(module_node.body[0].body[0].body[0].value.func, ast.Attribute)
    assert isinstance(module_node.body[0].body[0].body[0].value.func.value, ast.Name)
    assert isinstance(module_node.body[0].body[0].body[0].value.func.value.id, str)
    assert module

# Generated at 2022-06-21 18:08:38.233052
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer

# Generated at 2022-06-21 18:08:40.393718
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    assert t.target == (2, 7)
    # Given:

# Generated at 2022-06-21 18:08:41.839709
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:08:49.265428
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Foo:
        class EmptyClass:
            pass
        class EmptyClassWithConstructor:
            def __init__(self):
                super().__init__()

    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.transform([
        Foo.EmptyClass,
        Foo.EmptyClassWithConstructor
    ])

# Generated at 2022-06-21 18:08:57.816435
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
        class b(object):
            def __init__(self):
                super().__init__()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-21 18:09:02.728800
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def call(tree_str: str) -> ast.node:
        tree: ast.Call = ast.parse(tree_str)
        SuperWithoutArgumentsTransformer().visit(tree)
        return tree.body[0].value


# Generated at 2022-06-21 18:09:10.939459
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from tests.fixtures.typed_asts import SUPER_WITHOUT_ARGS_INPUT
    from tests.fixtures.typed_asts import SUPER_WITHOUT_ARGS_OUTPUT

    from typed_ast.ast3 import parse
    from ..utils.context import Context
    from ..utils.tree import typed_ast_to_str

    context = Context()
    tree = parse(SUPER_WITHOUT_ARGS_INPUT)
    SuperWithoutArgumentsTransformer(tree, context).visit(tree)
    assert typed_ast_to_str(tree) == SUPER_WITHOUT_ARGS_OUTPUT

# Generated at 2022-06-21 18:09:17.223998
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from typed_ast import ast3 as ast

    source = """
    class C:
        def __init__(self):
            super()
    """
    java_output = """
    class C {
        C();

        public void __init__(C self){
            super(C, self);
        }
    }
    """

    tree = ast.parse(source)
    res = transform(tree, SuperWithoutArgumentsTransformer)
    assert java_output == res

# Generated at 2022-06-21 18:09:19.733119
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    transformer = SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:31.260065
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Example code where super() is inside class but outside of method
    code = "class Cls:\n super()"

    tree: ast.Module = ast.parse(code=code)
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree=tree)
    compiled: str = compile(node=tree, filename="<ast>", mode="exec", optimize=2)

    assert 'class Cls:\n super(Cls, cls)' in compiled

    # Example code where super() is outside of class
    code = "super()"

    tree: ast.Module = ast.parse(code=code)
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree=tree)
    compiled: str = compile(node=tree, filename="<ast>", mode="exec", optimize=2)


# Generated at 2022-06-21 18:09:38.645068
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .context import Context
    from .common import NoopTransformer
    from .defaults import BuiltinDefaultsTransformer
    from .fix_builtins import FixBuiltinsTransformer
    from .fix_imports import FixImportsTransformer
    from .unify_unpacking import UnifyUnpackingTransformer
    from .unify_tuples import UnifyTuplesTransformer
    from .unify_dictionaries import UnifyDictionariesTransformer
    from .unify_exceptions import UnifyExceptionsTransformer
    from .unify_comprehensions import UnifyComprehensionsTransformer
    from .fix_metaclass import FixMetaclassTransformer
    from .fix_raise import FixRaiseTransformer
    from .fix_try import FixTryTransformer

# Generated at 2022-06-21 18:09:47.967425
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Success
    code = '\nsuper()'
    prepare_code = '\nsuper(Cls, self)'
    tree = ast.parse(code)  # type: ignore
    result = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(result) == prepare_code
    # Success
    code = '\nsuper()'
    prepare_code = '\nsuper(Cls, cls)'
    tree = ast.parse(code)  # type: ignore
    result = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(result) == prepare_code

# Generated at 2022-06-21 18:09:49.222504
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:56.065831
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .common import get_module
    from .expression_transformer import ExpressionTransformer


# Generated at 2022-06-21 18:10:00.016344
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    from ..utils import get_ast

    tree = get_ast("""super()""")
    transformer = SuperWithoutArgumentsTransformer(tree)

    transformer.visit(tree)

    assert str(tree) == """super(Cls, self)"""

# Generated at 2022-06-21 18:10:12.537755
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    import astor

    # Test for super() inside of a class
    class_ast = build_ast('''
        class A:
            def __init__(self):
                super()
        ''')

    class_ast_expected = build_ast('''
        class A:
            def __init__(self):
                super(A, self)
        ''')

    super_transformer = SuperWithoutArgumentsTransformer(class_ast)
    super_transformer.visit(class_ast)
    assert astor.to_source(class_ast) == astor.to_source(class_ast_expected)

    # Test for super() outside of a class

# Generated at 2022-06-21 18:10:13.596707
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:17.490367
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformed_code = transformer.transform()
    assert transformed_code == ast.parse('super(Cls, self)')

# Generated at 2022-06-21 18:10:25.383871
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..unit_test import get_node_of_type_by_position

    # This test is to enforce 100% coverage
    code = '''
    class MyClass:
        def myfunc(self):
            super().__init__()
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    call_node = get_node_of_type_by_position(tree, ast.Call, line=4, column=15)
    transformer.visit_Call(call_node)
    assert transformer._tree_changed == True

# Generated at 2022-06-21 18:10:31.290850
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from typed_ast import ast3 as ast

    ast_tree = ast.parse(dedent('''
        class Foo:
            def __init__(self):
                super()
    '''))
    transformer = SuperWithoutArgumentsTransformer(ast_tree)
    transformer.run()
    assert ast_tree == ast.parse(dedent('''
        class Foo:
            def __init__(self):
                super(Foo, self)
    '''))

# Generated at 2022-06-21 18:10:33.221879
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    # Example 1

# Generated at 2022-06-21 18:10:36.664442
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(A, a)' in astor.to_source(tree)

# Generated at 2022-06-21 18:10:46.348149
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.helpers import change_target_version

    transformer = SuperWithoutArgumentsTransformer()

    # Test inside function
    assert to_code(
        transformer.visit(to_ast(
            """
            class C:
                def f(self):
                    super()
            """
        ))
    ) == change_target_version(
        """
        class C:
            def f(self):
                super(C, self)
        """
    )

    # Test inside classmethod

# Generated at 2022-06-21 18:11:06.057140
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that super() is transformed into super(Cls, self)"""

    from typed_ast import ast3 as ast

    # Prepare
    source = 'super()'
    expected = ast.copy_location(ast.Call(
        func=ast.Name(
            id='super',
            ctx=ast.Load()),
        args=[
            ast.Name(
                id='Cls',
                ctx=ast.Load()),
            ast.Name(
                id='self',
                ctx=ast.Load())]),
        ast.parse(source))
    transformer = SuperWithoutArgumentsTransformer()

    # Run & Verify
    result = transformer.visit(ast.parse(source))
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-21 18:11:07.933688
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import AST
    from ..utils import parse


# Generated at 2022-06-21 18:11:09.300236
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse


# Generated at 2022-06-21 18:11:13.032939
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.fixtures.super import call
    result = SuperWithoutArgumentsTransformer().visit(call)
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.Name)
    assert result.args[0].id == "A"
    assert isinstance(result.args[1], ast.Name)
    assert result.args[1].id == "self"



# Generated at 2022-06-21 18:11:16.540706
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "super()"
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer.tree_changed() == True

# Generated at 2022-06-21 18:11:18.776301
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test the constructor of class SuperWithoutArgumentsTransformer."""

# Generated at 2022-06-21 18:11:26.979876
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    """
    ################################################################################
    # super()
    ################################################################################
    class SuperWithoutArgumentsTransformer_visit_Call_test0(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node):
            super(SuperWithoutArgumentsTransformer_visit_Call_test0, self).visit_Call(node)
            print('visited')
            if not isinstance(node.func, ast.Name):
                raise TypeError
            if node.func.id != 'super':
                raise ValueError
    tree = ast.parse('''class A:
        def __init__(self):
            print(super())''')
    SuperWithoutArgumentsTransformer_visit_Call_test0().vis

# Generated at 2022-06-21 18:11:34.529124
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from typed_ast import ast3 as ast
    node = ast.parse('super()').body[0].value
    SuperWithoutArgumentsTransformer().visit(node)
    v = ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='cls'), ast.Name(id='self')], keywords=[])
    assert astor.to_source(node) == astor.to_source(v)
    #s = SuperWithoutArgumentsTransformer()
    #s.visit(node)

# Generated at 2022-06-21 18:11:40.267497
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import assert_transformed_code

    assert_transformed_code(
        SuperWithoutArgumentsTransformer,
        'super()',
        'super(Cls, self)'
    )
    assert_transformed_code(
        SuperWithoutArgumentsTransformer,
        'super()',
        'super(Cls, cls)',
        tree__type='classdef'
    )

# Generated at 2022-06-21 18:11:51.236788
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()

    # super()
    source = """
        super()
    """
    tree = ast.parse(source)
    transformer.visit(tree)
    assert transformer._tree_changed == True  # type: ignore
    assert astor.code_gen.to_source(tree).strip() == """\
super(Cls, self)"""

    # super() - nesting
    source = """
        class Cls:
            def foo():
                super()
    """
    tree = ast.parse(source)
    transformer.visit(tree)
    assert transformer._tree_changed == True  # type: ignore

# Generated at 2022-06-21 18:12:02.642994
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:11.093770
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    with open('tests/fixtures/super_without_args.py') as f:
        input_source = f.read()
    with open('tests/fixtures/super_without_args_output.py') as f:
        output_source = f.read()

    tree = ast.parse(input_source)
    transformer.visit(tree)
    
    with open('tests/fixtures/super_without_args_output.py', 'w') as f:
        f.write(astunparse.unparse(tree))

    assert astunparse.unparse(tree) == output_source

# Generated at 2022-06-21 18:12:12.042292
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:12.554603
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:18.160452
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    src = """
    class Test:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    """
    tree = ast.parse(src)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)

    tree = transformer.visit(tree)  # type: ignore
    target_src = """
    class Test:
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
    """
    target_tree = ast.parse(target_src)  # type: ignore
    assert ast.dump(tree) == ast.dump(target_tree)

# Generated at 2022-06-21 18:12:25.367200
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_transformer import run_test, check_expected_tree, load_test_tree
    from ..parser.parser import PythonParser

    expected_tree = load_test_tree(__file__, 'expected_tree.py')

    tree = run_test(SuperWithoutArgumentsTransformer, __file__, 'test_tree.py')
    check_expected_tree(tree, expected_tree)

    assert PythonParser().parse('class A(super): pass') == expected_tree

# Generated at 2022-06-21 18:12:34.660559
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import assert_code_equal
    from ..testing import assert_node_equal

    tree = ast.parse("""
    class Cls:
        def method(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()

    assert_code_equal("""
    class Cls:
        def method(self):
            super(Cls, self)
    """, tree)

    tree = ast.parse("""
    class Cls:
        def method(self):
            def inner():
                super()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()


# Generated at 2022-06-21 18:12:38.107221
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from astunparse import unparse
    

# Generated at 2022-06-21 18:12:39.468983
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:41.081315
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...utils.testing import check_transform


# Generated at 2022-06-21 18:13:00.113598
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tokenize import source_to_tokens

# Generated at 2022-06-21 18:13:03.001662
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .unpacking import UnpackTransformer
    from .. import jit
    pyversion = (2, 7)


# Generated at 2022-06-21 18:13:03.854541
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:09.931938
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class X:
        def f(self):
            super()
    
    tree = ast.parse(dedent(X.f.__doc__))
    
    SuperWithoutArgumentsTransformer().visit(tree)
    
    assert tree.body[0].body[0].value.args[0].id == 'X'
    assert tree.body[0].body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:13:20.012194
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Dummy(ast.Call):
        _fields = ('args', 'keywords',  'starargs', 'kwargs')

    args = ast.arguments()

    keywords = ast.keyword()

    starargs = ast.Name

    kwargs = ast.Name

    args1 = Dummy(args, keywords, starargs, kwargs)

    func1 = ast.Name(id='super', ctx=ast.Load)

    args.args = [ast.arg(arg='self', annotation=None)]

    args.vararg = None

    args.kwonlyargs = []

    args.kw_defaults = []

    args.kwarg = None

    args.defaults = []

    keywords.arg = None

    keywords.value = None


# Generated at 2022-06-21 18:13:30.372811
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = [ast.Name(id='test')]
            return node
            
    code = """
    class A:
        pass

    class B(A):
        def f(self):
            super()
    """
    tree = ast.parse(code)
    transpiled_tree = tree.body[1].body[0].body[0]

    assert len(transpiled_tree.args) == 0

    SuperWithoutArgumentsTransformer(Test()).visit(tree)
    transpiled_tree = tree.body[1].body[0].body[0]

    assert isinstance(transpiled_tree, ast.Call)

# Generated at 2022-06-21 18:13:33.778440
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as sta

    # Test 1

# Generated at 2022-06-21 18:13:34.090810
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:39.859270
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert_source_equal(NodeTransformer(), 'super()', 'super(Cls, self)')
    assert_source_equal(NodeTransformer(), 'super()', 'super(Cls, cls)')
    assert_source_equal(NodeTransformer(), 'super().__init__()', 'super(Cls, self).__init__()')
    assert_source_equal(NodeTransformer(), 'super().__init__()', 'super(Cls, cls).__init__()')

# Generated at 2022-06-21 18:13:43.452884
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=ast.fix_missing_locations(test_tree))
    transformer.visit(test_tree)
    assert(transformer.get_tree().body[0].value.args[0].id == 'Cls')
    assert(transformer.get_tree().body[0].value.args[1].id == 'self')

# Generated at 2022-06-21 18:14:33.419323
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import compile_to_node
    module = ast.Module([])
    call_super = ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)
    func_def = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.arg(arg='self')],
                                                              vararg=None, kwonlyargs=[], kw_defaults=[],
                                                              kwarg=None, defaults=[]), body=[], decorator_list=[],
                              returns=None)
    class_def = ast.ClassDef(name='Cls', bases=[], keywords=[],
                             body=[func_def], decorator_list=[])

# Generated at 2022-06-21 18:14:34.340452
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:36.983142
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import test_nodes as tn
    from ..transformers import SuperWithoutArgumentsTransformer
    from .. import tree


# Generated at 2022-06-21 18:14:45.900416
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from ..utils.cst import parse_module
    from .base import BaseNodeTransformer

    source_1 = """
        class Foo:
            def bar(self):
                super()
    """
    expected_result_1 = """
        class Foo:
            def bar(self):
                super(Foo, self)
    """
    module_ast_1 = parse_module(source_1)
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(module_ast_1)
    assert ast.dump(module_ast_1) == ast.dump(parse_module(expected_result_1))
    assert trans._tree_changed

    source_2 = """
        class Foo:
            def __init__(self):
                super()
    """

# Generated at 2022-06-21 18:14:53.297156
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astor.code_gen import to_source

    code = 'class Cls(object):\n def foo(self):\n  super()\n'
    tree = _ast.parse(code)
    tree = SuperWithoutArgumentsTransformer.run(tree)
    expected_code = 'class Cls(object):\n def foo(self):\n  super(Cls, self)\n'
    assert to_source(tree) == expected_code


# Generated at 2022-06-21 18:14:57.530901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Cls:
        def __init__(self):
            super()
    '''
    comp = SuperWithoutArgumentsTransformer(code)
    assert comp.result == '''
    class Cls:
        def __init__(self):
            super(Cls, self)
    '''



# Generated at 2022-06-21 18:15:07.241252
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code_to_ast import source_code_to_ast as sc2ast
    from ..utils.tree import get_first_of_node_type_from_tree
    tree = sc2ast('''
        class A:
            def method(self):
                super()
        ''')
    node = get_first_of_node_type_from_tree(tree, ast.Call)
    xformer = SuperWithoutArgumentsTransformer(tree)
    xformer.visit(node)
    assert tree.body[0].body[0].body[0].args[0].id == 'A'
    assert tree.body[0].body[0].body[0].args[1].id == 'self'

# Generated at 2022-06-21 18:15:09.590396
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.ast_parser import AstParser
    from ..utils.source import Source


# Generated at 2022-06-21 18:15:10.893112
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:12.905645
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:41.164733
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
    class X:
        def foo(self):
            super()
    '''
    expected_code = '''
    class X:
        def foo(self):
            super(X, self)
    '''
    assert expected_code == run_transformer(code, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:16:50.531003
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import get_ast, compare_asts, get_tree_changed
    ast1 = get_ast("""super()""")
    ast2 = get_ast("""super(Cls, self)""")
    ast3 = get_ast("""super(Cls, cls)""")
    node_transformer = SuperWithoutArgumentsTransformer('File', ast1, False)
    compare_asts(ast2, node_transformer.visit(ast1))
    assert get_tree_changed()
    node_transformer = SuperWithoutArgumentsTransformer('File', ast3, False)
    compare_asts(ast3, node_transformer.visit(ast1))
    assert get_tree_changed()

# Generated at 2022-06-21 18:16:51.830790
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:02.956395
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    foo = ast.Name(id='foo')
    cls = ast.ClassDef(name='cls', bases=[], body=[])
    cls.body.append(ast.FunctionDef(name='__init__', args=ast.arguments(args=[ast.arg(arg='self')], vararg=None,
                                                                       kwonlyargs=[], kw_defaults=[],
                                                                       kwarg=None, defaults=[]),
                                    body=[ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[]))]))

    # Expected result
    cls_expected = ast.ClassDef(name='cls', bases=[], body=[])

# Generated at 2022-06-21 18:17:10.268541
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing_utils import assert_source

    source = "super()"
    expected = "super(Cls, self)"
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_tree = transformer.visit(tree)
    assert_source(new_tree, expected)


# Generated at 2022-06-21 18:17:12.138009
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..bases import Transformer
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-21 18:17:16.996457
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    with open('tests/resources/super_without_arguments.py') as f:
        tree = ast.parse(f.read())
        transformer.visit(tree)
        assert transformer._tree_changed is True
        print(astor.to_source(tree))

# Generated at 2022-06-21 18:17:17.942780
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:24.696639
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("a()")
    node_to_be_tested = tree.body[0].value
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert isinstance(node_to_be_tested, ast.Call)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer._replace_super_args(node_to_be_tested)
    assert isinstance(node_to_be_tested, ast.Call)

# Generated at 2022-06-21 18:17:34.083542
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class SuperWithoutArgumentsTransformerMock(SuperWithoutArgumentsTransformer):
        def _get_tree(self) -> ast.AST:
            def g(x: int) -> int:
                return super()
            return ast.parse('def f():\n    return 3')

    x = SuperWithoutArgumentsTransformerMock()
    x.visit(x._get_tree())

    assert x._tree_changed is True

    class SuperWithoutArgumentsTransformerMock2(SuperWithoutArgumentsTransformer):
        def _get_tree(self) -> ast.AST:
            def f(x: int) -> int:
                return super()
            return ast.parse('def f():\n    return 3')

    x = SuperWithoutArgumentsTransformerMock2()
    x.visit(x._get_tree())

   