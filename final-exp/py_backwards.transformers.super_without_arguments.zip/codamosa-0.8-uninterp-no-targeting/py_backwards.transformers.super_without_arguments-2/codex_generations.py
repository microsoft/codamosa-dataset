

# Generated at 2022-06-21 18:08:02.339594
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:03.617234
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_utils import compile_func


# Generated at 2022-06-21 18:08:15.103072
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import unittest
    
    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return

            try:
                cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
            except NodeNotFound:
                warn('super() outside of class')
               

# Generated at 2022-06-21 18:08:27.936638
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()").body[0]
    assert isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
    
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(node)
    new_node = visitor.visit(node)
    assert isinstance(new_node, ast.Expr) and isinstance(new_node.value, ast.Call)
    assert isinstance(new_node.value.func, ast.Attribute)
    assert new_node.value.func.attr == "__init__"
    assert isinstance(new_node.value.func.value, ast.Attribute)
    assert new_node.value.func.value.attr == "__init__"

# Generated at 2022-06-21 18:08:30.500879
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode_node, source_to_ast


# Generated at 2022-06-21 18:08:35.833764
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer
    from .. import parse

    source = '''
    class A(object):
        def __init__(self):
            super()
    '''

    result = run_transformer(SuperWithoutArgumentsTransformer, source)
    assert 'super(A, self)' in result

# Generated at 2022-06-21 18:08:38.139827
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import get_node, remove_linenos

# Generated at 2022-06-21 18:08:39.808071
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast_from_source

# Generated at 2022-06-21 18:08:46.401027
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    node = astor.code_to_ast("super()").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    node = astor.code_to_ast("super(cls, self)").body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 2

    trans = SuperWithoutArgumentsTran

# Generated at 2022-06-21 18:08:48.465625
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_restricted
    from ..utils.helpers import get_ast, dump_args


# Generated at 2022-06-21 18:09:01.191863
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_conversion

    tree = ast_conversion.parse(2, 7, 'super()')
    tree_changed = False

    class UnitTestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree, tree_changed):
            self._tree_changed = tree_changed
            super(UnitTestSuperWithoutArgumentsTransformer, self).__init__(tree, "")

        def _replace_super_args(self, node):
            assert isinstance(node, ast.Call)
            assert isinstance(node.func, ast.Name)
            assert node.func.id == 'super'
            assert not node.args
            assert isinstance(node.keywords, list)
            assert len(node.keywords) == 0

# Generated at 2022-06-21 18:09:07.048052
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Input
    root = ast.parse("super()")
    old_cls = root.body[0].value.func  # super()
    # Expected output
    expected = ast.Call(
        func=ast.Name(id="super", ctx=ast.Load()),  # type: ignore
        args=[ast.Name(id=Cls.__name__, ctx=ast.Load()),
              ast.Name(id=test_SuperWithoutArgumentsTransformer_visit_Call.__name__, ctx=ast.Load()),
              ],
        keywords=[],
        starargs=None,
        kwargs=None,
    )
    # Apply transformer
    transformer = SuperWithoutArgumentsTransformer(root)
    new_root = transformer.visit(root)
    # Check that super() has been replaced

# Generated at 2022-06-21 18:09:16.878324
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List
    from ..utils.source import Source
    from .unpacking_transformer import UnpackingTransformer
    from .raise_transformer import RaiseTransformer
    from .tuplize_transformer import TuplizeTransformer
    from .named_tuple_transformer import NamedTupleTransformer
    from .set_literal_transformer import SetLiteralTransformer
    from .super_transformer import SuperTransformer
    from .kwarg_transformer import KwargTransformer
    from ..base import JSTransformer

    # Expression:
    #   super(B, self).__init__()
    # Output:
    #   super(B, self).__init__();

# Generated at 2022-06-21 18:09:28.434791
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test method visit_Call of class SuperWithoutArgumentsTransformer.

    Test that super() without arguments is replaced by super(Cls, cls) when
    inside a function and by super(Cls, self) when inside a method.
    """
    tree = ast.parse(u"""
        class B(object):
            def b(self):
                super()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    node = tree.body[0].body[0].body[0]

    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'B'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'



# Generated at 2022-06-21 18:09:35.210094
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]
    transformer = SuperWithoutArgumentsTransformer()
    node = transformer.visit_Call(node)
    assert(isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'super')
    assert(len(node.args) == 2)
    assert(isinstance(node.args[0], ast.Name) and isinstance(node.args[1], ast.Name))

# Generated at 2022-06-21 18:09:47.560482
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parser import Parser


# Generated at 2022-06-21 18:09:55.267250
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..bst import parse

    source = """
        class A:
            def __init__(self):
                super().__init__()

            def foo(self):
                super().foo()

        class B(A):
            def __init__(self):
                super().__init__()

    """
    tree = parse(source)
    node = get_name_node(tree, 'A')
    SuperWithoutArgumentsTransformer(tree, {2: 3}).visit(node)
    expected = """
        class A:
            def __init__(self):
                super(A, self).__init__()

            def foo(self):
                super(A, self).foo()

        class B(A):
            def __init__(self):
                super(B, self).__init__()

    """


# Generated at 2022-06-21 18:09:55.918558
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:06.225901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from mypy_boto3_builder.type_annotations.class_ import Class
    from mypy_boto3_builder.type_annotations.function import Function

    class_ = Class()
    class_.construct_ast()
    class_.ast.body.append(Function('bar').construct_ast())
    class_.ast.body[0].body.append(ast.Pass())

    func = Function('foo')
    func.construct_ast()
    func.ast.body.append(ast.Call(ast.Name(id='super'), [], []))

    transformer = SuperWithoutArgumentsTransformer(class_.ast)
    transformer.visit(func.ast)


# Generated at 2022-06-21 18:10:11.218144
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast as pyast
    from ..utils.dump import to_source
    tree = pyast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert to_source(transformer.tree) == 'super(Cls, self)'

# Generated at 2022-06-21 18:10:20.364908
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = textwrap.dedent('''\
        class Foo:
            def __init__(self):
                super().test()
        ''')
    t = textwrap.dedent('''\
        class Foo:
            def __init__(self):
                super(Foo, self)
        ''')

    tree = ast.parse(s)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astor.code_gen.to_source(tree) == t



# Generated at 2022-06-21 18:10:22.591044
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .test_helpers import round_trip

# Generated at 2022-06-21 18:10:29.823537
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_in = '''
    class Demo:
        def __init__(self):
            super()
    '''
    code_out = '''
    class Demo:
        def __init__(self):
            super(Demo, self)
    '''
    tree_in = ast.parse(code_in)
    tree_out = ast.parse(code_out)
    transformer = SuperWithoutArgumentsTransformer(tree_in)
    transformer.visit(tree_in)
    assert transformer.generic_visit(tree_in) == tree_out

# Generated at 2022-06-21 18:10:31.014739
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-21 18:10:39.704209
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    code = '''
    class A:
        def foo(self):
            super()
    '''
    tree = ast.parse(code)

    trans = SuperWithoutArgumentsTransformer()
    new_tree = trans.visit(tree)

    assert trans._tree_changed
    assert new_tree.body[0].body[0].body[0].args[0].id == 'A'
    assert new_tree.body[0].body[0].body[0].args[1].id == 'self'

# Generated at 2022-06-21 18:10:41.174432
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_tree


# Generated at 2022-06-21 18:10:45.568173
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """class A: super()"""
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()

    tree = transformer.visit(tree)
    assert transformer._tree_changed

    code1 = astor.to_source(tree).strip()
    code2 = """class A: super(A, self)"""
    assert code1 == code2

# Generated at 2022-06-21 18:10:47.986347
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code import SourceCode
    from ..utils.helpers import dummy_visitor


# Generated at 2022-06-21 18:10:59.593106
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import textwrap

    from ..pgen2 import tokenize
    from ..utils.source import source_to_unicode
    from . import FromImportTransformer

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        maxDiff = None

        def _format_code(self, code: str) -> str:
            return '\n'.join(code.strip().splitlines())

        def test_compiles_super_without_arguments_to_super_with_cls_and_self(self):
            code = '''\
            class A(object):
                def a(self):
                    super()
            '''
            expected_code = '''\
            class A(object):
                def a(self):
                    super(A, self)
            '''
            transformer = Super

# Generated at 2022-06-21 18:11:00.960348
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:11:12.873560
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as _ast
    from typing import List
    # super() -> super(Cls, self)
    #
    def func1():
        super()


# Generated at 2022-06-21 18:11:23.667371
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_all_nodes, run_all_nodes_with_errors

    run_all_nodes(
        SuperWithoutArgumentsTransformer(),
        (2, 7),
        """
        super()
        """
    )

    run_all_nodes(
        SuperWithoutArgumentsTransformer(),
        (2, 7),
        """
        class A:
            pass
        class B(A):
            def run(self):
                super()
        """
    )

    run_all_nodes(
        SuperWithoutArgumentsTransformer(),
        (2, 7),
        """
        class A:
            @classmethod
            def run(cls):
                super()
        """
    )


# Generated at 2022-06-21 18:11:25.223480
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:36.685727
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    obj = SuperWithoutArgumentsTransformer()
    obj._tree = ast.parse('''class A:\n  def __init__(self):\n    super()''')
    obj.visit(obj._tree)
    code = compile(obj._tree, '', 'exec')
    with locals_cmpt_context(code):
        assert A().__class__.__bases__[0] == A

    obj = SuperWithoutArgumentsTransformer()
    obj._tree = ast.parse('''class A:\n  def __init__(self):\n    super().__init__()''')
    obj.visit(obj._tree)
    code = compile(obj._tree, '', 'exec')
    with locals_cmpt_context(code):
        assert A().__class__.__bases__[0] == A

# Generated at 2022-06-21 18:11:47.985514
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
        class A:
            def method(self):
                super()
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    statement = transformer.visit(node)
    node_to_test = statement.value
    assert not len(node_to_test.args)
    node_to_test = node_to_test.args[0]
    assert isinstance(node_to_test, ast.Name)
    assert node_to_test.id == 'A'
    node_to_test = node_to_test.args[1]
    assert isinstance(node_to_test, ast.Name)
    assert node_to_test.id == 'self'

# Generated at 2022-06-21 18:11:57.229887
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class DummyTree(ast.AST):
        def __init__(self, tree: ast.AST):
            self._tree = tree
            self.walk = tree.walk

    class DummyNode(ast.AST):
        pass

    class DummyCall(ast.Call):
        pass

    class DummyName(ast.Name):
        pass

    class DummyFunctionDef(ast.FunctionDef):
        pass

    class DummyClassDef(ast.ClassDef):
        pass

    class DummyName(ast.Name):
        pass

    class DummyArg(ast.arg):
        pass

    class DummyArgs(ast.arguments):
        pass

    dummy_tree = DummyTree(ast.AST())
    dummy_node = DummyNode()

# Generated at 2022-06-21 18:12:08.961800
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class A:
            def __init__(self):
                super()
        '''

    module = ast.parse(code)
    sut = SuperWithoutArgumentsTransformer()
    module = sut.visit(module)
    
    assert isinstance(module.body[0].body[0].value, ast.Call)
    assert isinstance(module.body[0].body[0].value.func, ast.Name)
    assert module.body[0].body[0].value.func.id == 'super'
    assert isinstance(module.body[0].body[0].value.args[0], ast.Name)
    assert module.body[0].body[0].value.args[0].id == 'A'

# Generated at 2022-06-21 18:12:09.791674
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-21 18:12:19.090958
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import pretty

    arg_first_code = '''
    class MyClass:
        def m(self):
            super()
    '''

    arg_first_tree = ast.parse(arg_first_code)
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(arg_first_tree)
    expected_result = '''
    class MyClass:
        def m(self):
            super(MyClass, self)
    '''
    result = pretty(arg_first_tree)
    assert result == expected_result

    arg_second_code = '''
    class MyClass:
        a = 42
        def m(self):
            super()
    '''


# Generated at 2022-06-21 18:12:20.570951
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from . import get_ast


# Generated at 2022-06-21 18:12:34.428418
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake_ast import make_fake_module_from_source
    m = make_fake_module_from_source("super()")
    SuperWithoutArgumentsTransformer(m).run() #type: ignore
    assert m.body[0].value.args[0].id == 'X'
    assert m.body[0].value.args[1].id == 'self'
    assert m.body[0].value.func.value.id == 'super'
    m = make_fake_module_from_source("super(1)")
    SuperWithoutArgumentsTransformer(m).run() #type: ignore
    assert m.body[0].value.args[0].n == 1


# Generated at 2022-06-21 18:12:43.105480
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodetree
    tree = source_to_nodetree('''
    class Cls:
        def method(self):
            super()
    ''')

    node = tree.body[0].body[0].body[0]
    expected = ast.parse('''
    super(Cls, self)
    ''').body[0]

    node = SuperWithoutArgumentsTransformer().visit(node)

    assert node == expected

# Generated at 2022-06-21 18:12:53.633186
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.visitor import dump
    from .example import example1
    node = ast.parse(example1).body[0].body[5]
    # super(Cls, self)
    node = ast.copy_location(ast.Expr(
        value=ast.Call(
            func=ast.Name(id='super'), 
            args=[ast.Name(id='Cls'), ast.Name(id='self')], 
            keywords=[], 
            starargs=None, 
            kwargs=None
        )
    ), node)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert dump(node) == dump(ast.parse(example1).body[0].body[5])

# Generated at 2022-06-21 18:13:00.129477
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from .. import compile
    super_call_code = 'class Foo(object):\n   def bar(self):\n       super()'

    tree = compile(super_call_code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    result: str = """"""
    for line in compile.ast_to_source(tree).splitlines():
        result += line.strip() + "\n"

    # result.strip() will remove the last \n
    assert result.strip() == """class Foo(object):

   def bar(self):
       super(Foo, self)"""
    # TODO: add test for when class Foo(Bar)

# Generated at 2022-06-21 18:13:02.684240
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_python_with_modes, get_all_modes, check_expected_result
    from ..utils.constants import CompiledCodeInfo


# Generated at 2022-06-21 18:13:07.027821
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that SuperWithoutArgumentsTransformer transforms
        super() (line 2)
    to
        super(Class, self)(line 6)
    """
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:13:15.238320
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node_names

    transformer = SuperWithoutArgumentsTransformer(tree=None, filename='')
    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[])
    transformer._replace_super_args = lambda a: None

    class C:
        def f(self):
            return super()

    class D:
        def f(self):
            return super()
        class F:
            def g(self):
                return super()

    assert get_ast_node_names(transformer.visit(node)) == (['Name', 'Name', 'Call'])

    transformer._tree = ast.parse(dedent(C.__doc__))
    transformer._replace_super

# Generated at 2022-06-21 18:13:19.887856
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    program_text = 'super()'

    tree = ast.parse(program_text)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    result = astor.to_source(tree)

    assert result == 'super(Cls, self)'

# Generated at 2022-06-21 18:13:21.452506
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:25.117163
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=node)
    result = transformer.visit(node)
    assert str(result) == "super(__class__, arg)"



# Generated at 2022-06-21 18:13:42.459875
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_tree
    from ..utils.string import indent
    from .debug import PrettyPrintNodeVisitor

    tree = source_to_tree(
        indent(
            """
            class A:
                def __init__(self):
                    super()
                    self.x = 1
            """)[1:])
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert PrettyPrintNodeVisitor().visit(tree).strip() == indent(
        """
        class A:
            def __init__(self):
                super(A, self)
                self.x = 1
        """)[1:].strip()



# Generated at 2022-06-21 18:13:45.303911
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    code = 'super()'
    expected = 'super(Cls, self)'
    tree = ast.parse(code)

    # Act
    SuperWithoutArgumentsTransformer().visit(tree)

    # Assert
    assert expected == astor.to_source(tree).strip()

# Generated at 2022-06-21 18:13:56.712873
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    import inspect
    import ast
    from typed_ast import ast3 as ast3
    
    class SuperVisitor(ast3.NodeVisitor):
        def __init__(self, max_depth: int):
            self.max_depth = max_depth
            self.depth = 0
            self.nodes = []
            
        def visit(self, node: ast3.AST) -> None:
            if self.depth == self.max_depth:
                self.nodes.append(node)
                return
            
            self.depth += 1
            self.generic_visit(node)
            self.depth -= 1
    

# Generated at 2022-06-21 18:13:57.261901
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:07.324171
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    tree = ast3.parse('super()')

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
            
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast3.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast3.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-21 18:14:08.758388
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:15.796901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from . import parse, run_transformer

    source = 'super()'
    tree = ast.parse(source)
    fixed = parse('super(Dummy, self)')
    new = run_transformer(SuperWithoutArgumentsTransformer, tree)
    assert astor.to_source(new) == astor.to_source(fixed)

    source = 'super(X)'
    tree = ast.parse(source)
    fixed = parse('super(X, self)')
    new = run_transformer(SuperWithoutArgumentsTransformer, tree)
    assert astor.to_source(new) == astor.to_source(fixed)

    source = 'super(X, Y)'
    tree = ast.parse(source)
    fixed = parse('super(X, Y)')
    new = run_

# Generated at 2022-06-21 18:14:16.573687
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:18.299334
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor  # type: ignore


# Generated at 2022-06-21 18:14:23.567204
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    class Foo(object):
        def foo(self):
            super()

    s = astor.to_source(Foo.__dict__['foo'].__code__)
    _test_source = "    def foo(self):\n        super(Foo, self)"
    assert s == _test_source

# Generated at 2022-06-21 18:14:53.457544
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast


# Generated at 2022-06-21 18:15:02.393952
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import setup_ast_parser, parse_string
    parser = setup_ast_parser()
    module = parse_string('super()', parser=parser)
    x = SuperWithoutArgumentsTransformer()
    y = x.visit(module)
    expected = Module(body=[Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='C', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))])
    assert ast.dump(y) == ast.dump(expected)

# Generated at 2022-06-21 18:15:09.844464
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code_string = 'super()'
    expected_ast = ast.parse('super(Cls, self)')
    tr = SuperWithoutArgumentsTransformer(code_string)

    # There is no function `test_` in this module
    tr.visit(ast.parse('class Cls(object): def func(self): pass'))
    actual_ast = tr.tree

    assert actual_ast.body[0].body[0].body[0].value.args == expected_ast.body[0].value.args



# Generated at 2022-06-21 18:15:12.902555
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import parse


# Generated at 2022-06-21 18:15:14.281744
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:22.753415
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    import textwrap
    sample = textwrap.dedent("""
    class Test:
        def method(self):
            super()
            super()
            """)
    tree = ast.parse(sample)
    tree = SuperWithoutArgumentsTransformer(target=(2, 7)).visit(tree)
    assert ast3.dump(tree) == textwrap.dedent("""\
    class Test:
        def method(self):
            super(Test, self)
            super(Test, self)""")

# Generated at 2022-06-21 18:15:25.385848
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from .helpers import assert_equal_ast
    from .helpers import get_ast


# Generated at 2022-06-21 18:15:37.355960
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from typing import List
    from ..utils.ast_builder import build_ast

    # Given
    class_node = pyast.ClassDef(name='MyClass', body=[], bases=[pyast.Name(id='Base', ctx=pyast.Load())])
    function_node = pyast.FunctionDef(name='my_method', args=pyast.arguments(args=[pyast.Name(id='self', ctx=pyast.Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[pyast.Expr(value=pyast.Call(func=pyast.Name(id='super', ctx=pyast.Load()), args=[], keywords=[]))], decorator_list=[], returns=None)

# Generated at 2022-06-21 18:15:37.953443
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:41.611201
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from .helpers import dump

    node = ast.parse("super()")
    Compiler = compile.create_compiler_cls(
        type_comments=False,
        transformers=[(SuperWithoutArgumentsTransformer, 1)]
    )
    assert dump(node) == dump(Compiler(node).tree)

# Generated at 2022-06-21 18:16:45.181726
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:48.965697
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")
    expected = ast.parse("super(Cls, self)")
    SuperWithoutArgumentsTransformer(tree, "Cls").visit(tree)
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-21 18:16:53.910539
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")
    from python_to_python.compiler import compile_src


# Generated at 2022-06-21 18:16:57.674109
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from ..utils.tree import get_all_nodes_of_type
    from ..utils.helpers import assert_nodes_equals
    

# Generated at 2022-06-21 18:17:06.543118
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import cst_to_ast
    from .base import BaseNodeTransformerTest
    from ..utils.helpers import get_node_of_class
    
    tree = cst_to_ast.parse_module('''
foo = super()
baz = 2
    ''')
    cls = get_node_of_class(BaseNodeTransformerTest, 'SuperWithoutArgumentsTransformer')
    node = cls().visit(tree)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Assign)  # foo = super()
    assert isinstance(node.body[1], ast.Assign)  # baz = 2
    assert isinstance(node.body[0].value, ast.Call)  #

# Generated at 2022-06-21 18:17:07.618303
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:12.457544
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    source = """
        class Cls:
            def func(self):
                super()
    """
    expected = """
        class Cls:
            def func(self):
                super(Cls, self)
    """

    transformer.visit(ast.parse(source))
    assert expected == transformer.result()

# Generated at 2022-06-21 18:17:23.894595
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test if SuperWithoutArgumentsTransformer.visit_Call compile super() to super(cls, self)
    """
    from typed_ast import ast3
    from ..transpile import Transpiler
    
    transformer = SuperWithoutArgumentsTransformer(ast3.parse('', mode='exec'), target=(2, 7), current_module='')
    tree = ast3.parse('class Foo: def bar(self): super()') 
    new_tree = Transpiler.run_transformer(transformer, tree)
    super_call = new_tree.body[0].body[0].body[0]
    assert isinstance(super_call, ast3.Expr)
    assert isinstance(super_call.value, ast3.Call)

# Generated at 2022-06-21 18:17:25.221864
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transform = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:17:26.004624
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor