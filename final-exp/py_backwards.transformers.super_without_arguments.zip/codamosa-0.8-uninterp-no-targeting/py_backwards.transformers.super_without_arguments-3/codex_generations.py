

# Generated at 2022-06-21 18:08:07.651862
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    assert compile('super()').strip() == 'super(__class__, self)'


# Generated at 2022-06-21 18:08:10.660372
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    mod = ast.parse('super()')
    assert isinstance(mod, ast.Module)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(mod)

# Generated at 2022-06-21 18:08:11.292329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:20.461199
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_helpers import transform
    from ..utils.template_parser import TemplateParser
    src = '''
    class Cls:
        def __init__(self):
            super()
    '''
    res = transform(src, (SuperWithoutArgumentsTransformer,))
    assert res == '''
    class Cls:
        def __init__(self):
            super(Cls, self)
    '''
    parser = TemplateParser(res)
    arg0 = parser.find_node('Call', 'super')
    assert isinstance(arg0.args[0], ast.Name)
    assert arg0.args[0].id == 'Cls'
    assert isinstance(arg0.args[1], ast.Name)
    assert arg0.args[1].id == 'self'

# Generated at 2022-06-21 18:08:22.010919
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    

# Generated at 2022-06-21 18:08:33.693691
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class DummyNode(object):
        pass
    dummy_tree = DummyNode()
    dummy_tree.body = [DummyNode()]
    dummy_tree.body[0].body = [DummyNode()]
    dummy_tree.body[0].body[0].func = DummyNode()
    dummy_tree.body[0].body[0].func.id = 'super'
    dummy_tree.body[0].body[0].args = []
    dummy_tree.body[0].name = 'foo'

    dummy_tree.body.append(DummyNode())
    dummy_tree.body[1].body = [DummyNode()]
    dummy_tree.body[1].body[0].func = DummyNode()
    dummy_tree.body[1].body[0].func.id = 'super'

# Generated at 2022-06-21 18:08:36.176015
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast27
    from typed_ast.ast27 import parse

# Generated at 2022-06-21 18:08:42.914044
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    from ..utils.helpers import get_node_name
    node = ast.parse("super()")
    node = get_ast(node, (2, 7))
    visitor = SuperWithoutArgumentsTransformer()

    node = visitor.visit(node)
    assert not visitor._tree_changed
    n = get_node_name(node)
    assert n == 'Expr[Call[Super]]'

# Generated at 2022-06-21 18:08:44.309934
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...testing import assert_code_equal


# Generated at 2022-06-21 18:08:56.099208
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_restricted
    from .. import set_debug
    from .test_utils import assert_tree

    set_debug(False)

    tree = compile_restricted('super()')

# Generated at 2022-06-21 18:09:04.710992
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.parse("super()").body[0].value
    new_node = SuperWithoutArgumentsTransformer.visit_Call(None, node)
    assert new_node.args[0].id == 'Cls'
    assert new_node.args[1].id == 'self'

# Generated at 2022-06-21 18:09:09.393874
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class TestClass:
            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    print(astor.to_source(tree))
    
# Output the following code.

# Generated at 2022-06-21 18:09:18.511996
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code_before_transformation = '''
        class Cls:
            def method(self):
                super().method()
                print(42)
    '''
    code_after_transformation = '''
        class Cls:
            def method(self):
                super(Cls, self).method()
                print(42)
    '''

    add_to_path('Cls')

    tree = ast.parse(code_before_transformation)
    SuperWithoutArgumentsTransformer().visit(tree)

    code_generated_by_transformed_tree = compile(tree, filename="<ast>", mode="exec")
    exec(code_generated_by_transformed_tree)

    assert_code_equal(code_after_transformation, code_generated_by_transformed_tree)



# Generated at 2022-06-21 18:09:27.596346
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_compile(
        """
        class A:
            def __init__(self):
                super()
            def __add__(self):
                super(B, cls)
            @classmethod
            def __sub__(cls):
                super()
                """,
        """
        class A:
            def __init__(self):
                super(A, self)
            def __add__(self):
                super(A, cls)
            @classmethod
            def __sub__(cls):
                super(A, cls)
        """,
        [
            SuperWithoutArgumentsTransformer,
        ],
    )

# Generated at 2022-06-21 18:09:28.269162
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:33.036919
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import as_tuple
    from ..utils.source import source_to_nodes, source_to_node
    from ..utils.tree import walk, NodeNotFound
    from ..utils.compat import Literal
    import ast


# Generated at 2022-06-21 18:09:42.115330
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_src(
        src="""
        class Cls(object):
            def method(self):
                super()
            def class_method(cls):
                super()
            @staticmethod
            def static_method():
                super()
        """,
        expected="""
        class Cls(object):
            def method(self):
                super(Cls, self)
            def class_method(cls):
                super(Cls, cls)
            @staticmethod
            def static_method():
                super()
        """,
        transformer=SuperWithoutArgumentsTransformer,
    )

# Generated at 2022-06-21 18:09:52.364226
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    from typed_ast import ast3
    from typed_ast import _ast27

    import typed_astunparse
    from transformers.super_without_arguments_transformer import SuperWithoutArgumentsTransformer

    class DummyClass:
        def assertEqual(self, x: object, y: object) -> None:
            assert x == y

    def assertEqual(x: object, y: object) -> None:
        assert x == y


# Generated at 2022-06-21 18:09:54.391016
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:55.445676
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:05.773883
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transformers.helpers import get_ast_of_code
    assert get_ast_of_code('super()', SuperWithoutArgumentsTransformer) == \
        ast.parse('super(Cls, self)')

# Generated at 2022-06-21 18:10:12.918106
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.tree import parse_tree, render_tree

    source = '''
    class MyClass():
        def __init__(self):
            super(MyClass, self)
    '''

    tree = parse_tree(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert render_tree(tree) == '''
    class MyClass():
        def __init__(self):
            super().__init__()
    '''

# Generated at 2022-06-21 18:10:20.401730
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast

    from ..utils.helpers import get_ast

    sample = '''class A(object):
        def __init__(self):
            super()
    '''

    expected = '''class A(object):
        def __init__(self):
            super(A, self)
    '''

    tree = get_ast(sample)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert ast.dump(tree) == ast.dump(get_ast(expected))

# Generated at 2022-06-21 18:10:27.818639
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..python_transformer import PythonTransformer
    transformer = PythonTransformer(PythonTransformer.level("2to3"))
    code = '''
    class A:
        def __init__(self, x: object):
            super(A, self)
    '''
    tree = transformer.transform_source(code)
    assert transformer.tree_changed
    expected = '''class A:
    def __init__(self, x: object):
        super(A, self)'''
    assert tree == ast.parse(expected)

# Generated at 2022-06-21 18:10:34.234890
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    import unittest
    from unittest import mock
    from ..utils.test_utils import run_test_for

    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        def _test_replace_super_args_with_self(self, transformer, node, func_args, class_name):
            transformer._replace_super_args(node)
            self.assertEqual(
                node.args,
                [ast3.Name(id=class_name), ast3.Name(id=func_args[0].arg)],
            )

        @mock.patch.object(SuperWithoutArgumentsTransformer, '_replace_super_args')
        def test_super_outside_class_outside_function(self, mock_replace_super_args):
            node = ast

# Generated at 2022-06-21 18:10:45.130498
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from other_mypy_types import Any
    from .fixtures import ast_call, ast_class_def, ast_func_def, ast_name

    class SuperWithoutArgumentsTransformerTest(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast3.AST, *args: Any, **kwargs: Any) -> None:
            super().__init__(tree, *args, **kwargs)

    ast_node = ast_call(
        ast_name(id='super'),
        args=[],
    )

    class_def = ast_class_def(name="Cls", bases=[ast_name("object")])

# Generated at 2022-06-21 18:10:52.734665
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..utils.builder import build
    from ..utils.testing import (
            wrap_with_fstring_support,
            wrap_with_pipeline,
            extract_node_by_type,
            node_to_source,
    )

    class T(ast.NodeTransformer):
        def visit_Call(self, node):
            return ast.Call(func=ast.Name(id='super'), args=[])


# Generated at 2022-06-21 18:10:54.211297
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:56.045700
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:57.738723
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert SuperWithoutArgumentsTransformer._replace_super_args.__code__.co_argcount == 2


# Generated at 2022-06-21 18:11:11.515812
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ts = SuperWithoutArgumentsTransformer()
    assert isinstance(ts, BaseNodeTransformer)
    assert ts.t

# Generated at 2022-06-21 18:11:22.789151
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test if super() is replaced by super(Cls, cls)
    string = '''class A:
                    def __init__(self):
                        super()
    '''
    tree = ast.parse(string)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected = '''class A:
                    def __init__(self):
                        super(A, self)
    '''
    assert ast.dump(tree) == expected

    # Test if super() is replaced by super(Cls, cls)
    string = '''class A:
                    def __init__(self):
                        super()
    '''
    tree = ast.parse(string)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-21 18:11:25.147132
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTester
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:11:31.512648
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # This is just an example of how the SuperWithoutArgumentsTransformer works
    code = '''class A:
    def b(self):
        super()
'''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    exec(compile(tree, filename="", mode="exec"))
    assert str(tree).count("super(A, self)") == 1

# Generated at 2022-06-21 18:11:36.035801
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    tree = ast.parse('class A(object): def b(): return super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astor.to_source(tree) == 'class A(object): def b(): return super(A, self)'

# Generated at 2022-06-21 18:11:37.798316
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:38.531326
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:43.807616
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(func=ast.Name(id='super'), args=[])  # type: ignore

    transformer = SuperWithoutArgumentsTransformer(tree=None)  # type: ignore
    new_node = transformer.visit_Call(node)

    assert new_node.func.id == 'super'
    assert len(new_node.args) == 2
    assert isinstance(new_node.args[0], ast.Name)
    assert new_node.args[0].id == 'Cls'
    assert isinstance(new_node.args[1], ast.Name)



# Generated at 2022-06-21 18:11:44.497321
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:11:55.547747
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert SuperWithoutArgumentsTransformer._replace_super_args.__doc__ == SuperWithoutArgumentsTransformer.__doc__

# Generated at 2022-06-21 18:12:04.743940
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parser import parse

    # Given

# Generated at 2022-06-21 18:12:10.036365
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ... import ast_manipulation

    code = 'super()'

    assert ast_manipulation.to_source(ast.parse(code)) == code

    code = 'super()'
    tran = SuperWithoutArgumentsTransformer(ast.parse(code))

# Generated at 2022-06-21 18:12:19.418157
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    cls = ast.ClassDef(name='class', body=[
        ast.FunctionDef(name='fun', args=ast.arguments(args=[ast.arg(arg='self')]),
                        body=[ast.Expr(ast.Call(func=ast.Name(id='super'),
                                        args=[], keywords=[]))])])
    transformed_cls = SuperWithoutArgumentsTransformer(cls).visit(cls)
    assert isinstance(transformed_cls, ast.ClassDef)
    assert transformed_cls.body[0].body[0].value.args[0].id == 'class'
    assert transformed_cls.body[0].body[0].value.args[1].id == 'self'


# Generated at 2022-06-21 18:12:29.220278
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    s = """
    class Cls:
        def __init__(self):
            super()
        def func(self):
            super()
    """
    tree = ast.parse(s)
    transformer = SuperWithoutArgumentsTransformer(tree)
    
    # Exercise
    transformer.visit(tree)
    
    # Verify
    expected_tree = ast.parse(
    """
    class Cls:
        def __init__(self):
            super(Cls, self)
        def func(self):
            super(Cls, self)
    """)
    
    assert tree == expected_tree
    assert transformer._tree_changed == True

# Generated at 2022-06-21 18:12:31.496648
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import io
    import unittest


# Generated at 2022-06-21 18:12:38.237529
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-21 18:12:39.572234
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:47.940952
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    py_vers = '2.7'
    code = 'super()'
    code_obj = compile(code, '<string>', 'exec')
    module_node = ast.parse(code_obj)

    transformer = SuperWithoutArgumentsTransformer(
        module_node, py_vers
    )
    new_module_node = transformer.visit(module_node)

    assert transformer._tree_changed

    # Compare to the expected output
    expected_output = ast.parse(
        'super(cls, self)'
    )

    assert ast.dump(new_module_node) == ast.dump(expected_output)

# Generated at 2022-06-21 18:12:57.610570
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value.func.id == 'super'
    assert len(tree.body[0].value.args) == 2
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert isinstance(tree.body[0].value.args[1], ast.Name)
    assert tree.body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:12:59.190948
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    assert isinstance(node, ast.Call)

# Generated at 2022-06-21 18:13:15.021878
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast_node
    transformer = SuperWithoutArgumentsTransformer()
    node = get_ast_node('''
    class Foo:
        def __init__(self):
            super()
    ''')
    try:
        transformer.visit(node)
    except Exception:
        return False
    else:
        return True

# Generated at 2022-06-21 18:13:26.913239
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    func_tree = ast.parse(
        '''
        def x(self):
            return super()
        '''
    )
    cls_tree = ast.parse(
        '''
        class Y(object):
            def x():
                return super()
        '''
    )
    func_node = func_tree.body[0]
    cls_node = cls_tree.body[0]
    nt = SuperWithoutArgumentsTransformer(None) #type: ignore
    nt.visit_FunctionDef(func_node)
    nt.visit_ClassDef(cls_node)

# Generated at 2022-06-21 18:13:33.750877
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_pattern
    import ast
    # we have a `Call` node whose func is a `Name` node with id == 'super' and no args
    call_node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    # its parent is a class definition node
    class_node = ast.ClassDef(name='Test', bases=[], keywords=[], body=[call_node], decorator_list=[])
    # its parent is a module node
    module_node = ast.Module(body=[class_node])
    # we compile it and print the result
    print(compile_pattern(module_node, target=SuperWithoutArgumentsTransformer))
    # expected output:
    #
    # class Test:


# Generated at 2022-06-21 18:13:40.628454
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cls(object):
            pass
        
        class SubCls(Cls):
            def func(self):
                super()
    """

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    expected_code = """
        class Cls(object):
            pass
        
        class SubCls(Cls):
            def func(self):
                super(Cls, self)
    """

    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-21 18:13:42.584650
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    tr = SuperWithoutArgumentsTransformer({})
    tree = tr.visit(tree)

# Generated at 2022-06-21 18:13:48.474808
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class Foo:
            def bar(self):
                super()
    '''

    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    assert isinstance(tree.body[0], ast.ClassDef)
    assert isinstance(tree.body[0].body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.args[0], ast.Name)
    assert tree.body[0].body[0].body[0].value.args[0].id == 'Foo'

# Generated at 2022-06-21 18:13:56.995723
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import os
    sys.path.append(os.path.abspath('.'))
    sys.path.append(os.path.abspath('./test_dir'))
    from .context import Context
    
    f = open('test_dir/test_file.py').read()
    tree = ast.parse(f)
    SuperWithoutArgumentsTransformer(Context(2, 7)).visit(tree)
    assert(str(tree) == str(ast.parse(f.replace('super()', 'super(Cls, self)'))))

# Generated at 2022-06-21 18:13:57.867973
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-21 18:14:06.211376
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Example of non-working code
    s = "super().method()"
    super_arg_node = ast.parse(s)
    s = "class A(B):\n    def method(self):\n        super().method()"
    cls_node = ast.parse(s)
    cls_node.body[0].body.append(super_arg_node.body[0])
    super_module = SuperWithoutArgumentsTransformer(cls_node)
    super_module.visit(cls_node)

    # Fix is added

# Generated at 2022-06-21 18:14:07.087830
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:41.772319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = \
    """
    class Cls:
        def __init__(self):
            super()
    """
    expected = \
    """
    class Cls:
        def __init__(self):
            super(Cls, self)
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer()(tree)
    assert(expected == astor.to_source(tree))

# Generated at 2022-06-21 18:14:46.933177
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # compile the code
    code = textwrap.dedent('''\
        class Foo:
            def __init__(self):
                super().__init__()
        ''')
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    output = compile(tree, '<test>', 'exec')
    ns = {'Foo': None}
    exec(output, ns)

    # ensure the class works
    inst = ns['Foo']()  # type: ignore
    assert isinstance(inst, ns['Foo'])

# Generated at 2022-06-21 18:14:47.909881
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:57.424784
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object

    code = dedent("""
    class A:
        def __init__(self):
            super()
    """)

    code_obj = source_to_code_object(code, 'file.py')
    module = ast.parse(code_obj)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(module)
    module = transformer.generic_visit(module)

    assert (
        astor.to_source(module) ==
        """
    class A:

        def __init__(self):
            super(A, self)
    """.strip()
    )

# Generated at 2022-06-21 18:15:06.074032
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # ast_string = 'super()'
    # tree = ast.parse(ast_string)
    # new_tree = ast.parse(ast_string)
    # SuperWithoutArgumentsTransformer(tree).visit(new_tree)
    # assert ast.dump(new_tree) == 'With()'

    ast_string = 'super()'
    tree = ast.parse(ast_string)
    new_tree = ast.parse(ast_string)
    SuperWithoutArgumentsTransformer(tree).visit(new_tree)
    assert ast.dump(new_tree) == ast_string


# Generated at 2022-06-21 18:15:08.365301
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3


# Generated at 2022-06-21 18:15:22.062664
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from parser.typed_ast_visitor import TypedAstVisitor
    test_samples = [('super()', 'super(Cls, self)'),
                    ('super(1)', 'super(1)'),
                    ('super()', 'super(Cls, self)')]
    tree_from_str = lambda code: ast.parse(code).body[0]
    sample_from_str = lambda code: (ast.dump(tree_from_str(code)), code)

    for (before, after) in test_samples:
        before, after = sample_from_str(before), sample_from_str(after)
        transformer = SuperWithoutArgumentsTransformer(tree=before)
        assert transformer._tree_changed
        visitor = TypedAstVisitor()
        visitor.visit(transformer.ast)
        print

# Generated at 2022-06-21 18:15:32.832925
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = """
        class A:
            def f(self):
                super()
        """
    expected_output = """
        class A:
            def f(self):
                super(A, self)
        """
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.visit(ast.parse(input_code)).body[0].body[0].value.func.args[1].id == 'self'

    input_code = """
        class A:
            @staticmethod
            def f():
                super()
        """
    expected_output = """
        class A:
            @staticmethod
            def f():
                super(A, cls)
        """
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:15:33.429075
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:42.426458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_node

    source = '''
    class A:
        def __init__(self):
            super()
    '''
    sut = SuperWithoutArgumentsTransformer()
    node = source_to_node(source)

    result = sut.visit(node)

    assert isinstance(result, ast.ClassDef)
    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.FunctionDef)
    assert isinstance(result.body[0].body[0], ast.Expr)
    assert isinstance(result.body[0].body[0].value, ast.Call)
    assert isinstance(result.body[0].body[0].value.func, ast.Name)

# Generated at 2022-06-21 18:16:52.693470
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...parser import PythonParser
    from ...source import Source
    from ...utils.helpers import get_ast_node

    parser = PythonParser()
    source = Source('super()', 'test.py')
    source.lines[0] = 'super()'
    tree = parser.parse(source)

    ref = 'super(Cls, self)'

    for node in get_ast_node(tree, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
            SuperWithoutArgumentsTransformer().visit(node)

            assert ref == source.lines[0]

# Generated at 2022-06-21 18:17:03.595349
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.node_values = []
            self.node_types = []

    visitor = NodeVisitor()

    cls_tree = ast.parse('class Test: a = super; b = super()')
    func_tree = ast.parse('def test(): a = super; b = super()')

    meta_transformer = SuperWithoutArgumentsTransformer(cls_tree)
    meta_transformer.visit(cls_tree)
    ast.NodeTransformer().visit(cls_tree)
    ast.NodeVisitor().visit(cls_tree)

    meta_transformer = SuperWithoutArgumentsTransformer(func_tree)
    meta_transformer.visit(func_tree)
    ast.NodeTransformer().vis

# Generated at 2022-06-21 18:17:13.780296
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as std_ast
    from typing import cast
    from typed_ast import ast3 as typed_ast
    from typed_ast import traverse

    # The following AST is from the python2.7 version of typed_ast
    content = '''
    class Foo:
        def foo(self):
            super().__init__()
    '''

    tree = std_ast.parse(content)
    node = tree.body[0].body[0].body[0]


    # The following AST is from the python3.8 version of typed_ast
    expected_content = '''
    class Foo:
        def foo(self):
            super(Foo, self).__init__()
    '''

    expected_tree = std_ast.parse(expected_content)
    expected_node = expected_tree.body[0].body

# Generated at 2022-06-21 18:17:23.942193
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """This test is to make sure super() is working properly.

    super() will be replaced with super(Cls, self) or super(Cls, cls)
    if super() is being used in a class definition.

    Args:

    Returns:

    Raises:
    """
    src = """
    class Foo:
        def __init__(self):
            super()
    """

    tree = ast.parse(src)
    tr = SuperWithoutArgumentsTransformer(tree)
    tr.run()

    tree.body[0].body[0].body[0].args = [ast.Name(id='Foo'),
                                         ast.Name(id='self')]
    assert(tr.tree == tree)

# Generated at 2022-06-21 18:17:27.865496
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def __init__(self):
                super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree_to_code(tree).strip() == '''
        class A:
            def __init__(self):
                super(A, self)
    '''.strip()



# Generated at 2022-06-21 18:17:39.123098
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()', mode='exec').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 0

    transformer = SuperWithoutArgumentsTransformer()
    node = transformer.visit(node)
    assert isinstance(node.value.args[0], ast.Name)
    assert node.value.args[0].id == 'Cls'
    assert isinstance(node.value.args[1], ast.Name)
    assert node.value.args[1].id == 'self'
    transformer.generic_visit(node)  # type: ignore

# Generated at 2022-06-21 18:17:41.243127
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .context import Context
    from .mock_node import MockNode


# Generated at 2022-06-21 18:17:43.126748
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import assert_transformation
    assert_transformation(SuperWithoutArgumentsTransformer, 'super()')

# Generated at 2022-06-21 18:17:46.437685
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class MyTestClass(ast.NodeVisitor):
        def __init__(self):
            self._expected_value = None

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and len(node.args) == 0:
                node.args = [ast.Name(id="MyClass"), ast.Name(id='self')]

        def generic_visit(self, node):
            pass


# Generated at 2022-06-21 18:17:48.489860
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import CodeTransformer

    # Write code