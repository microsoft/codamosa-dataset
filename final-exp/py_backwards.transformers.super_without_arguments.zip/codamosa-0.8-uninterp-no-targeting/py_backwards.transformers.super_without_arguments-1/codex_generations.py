

# Generated at 2022-06-21 18:08:05.720809
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_transform
    code = 'super()'
    expected = 'super(Class, self)'
    assert_transform(SuperWithoutArgumentsTransformer, code, expected)

# Generated at 2022-06-21 18:08:06.339422
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:07.363323
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:12.910488
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class X:
        def __init__(self):
            super()
    '''
    expected = '''
    class X:
        def __init__(self):
            super(X, self)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    assert astor.to_source(tree) == expected

# Generated at 2022-06-21 18:08:15.360231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..transformers.base import BaseCodeTransformer
    from ..utils.helpers import get_ast

# Generated at 2022-06-21 18:08:18.366400
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:19.026890
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:27.982351
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import cmp_ast
    from .. import compile_to_ast as c
    code = 'super()'
    expected_ast = c.suf.Call(
        func=c.suf.Name(id='super'),
        args=[c.suf.Name(id='Cls'),
              c.suf.Name(id='self')],
    )

    actual_ast, _ = SuperWithoutArgumentsTransformer(c.parse(code)).visit_Call(c.parse(code, mode='eval')[0])
    assert cmp_ast(expected_ast, actual_ast)

# Generated at 2022-06-21 18:08:30.137251
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from . import apply_transformer
    

# Generated at 2022-06-21 18:08:37.620979
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # pylint: disable=no-member
    src = 'super()'
    module = ast.parse(src)
    tree = SuperWithoutArgumentsTransformer().visit(module)

    assert tree
    assert isinstance(tree.body[0].value, ast.Call)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:08:45.030807
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    transformed_code = transformer.result()

    assert transformed_code.replace(' ', '') == \
        'super(Cls, self)'.replace(' ', '')

# Generated at 2022-06-21 18:08:49.984116
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.parse("""def test(self):
        super()""", mode='eval')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert transformer.generic_visit(node) == ast.Name(id='super').value

# Generated at 2022-06-21 18:08:50.366890
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:58.036898
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..node_transformer import NodeTransformer

    class SomeClass(object):
        def __init__(self):
            super()

    class SomeOtherClass(object):
        def some_method(self):
            super()

    # Note that super() has zero arguments.
    assert inspect.getsource(SomeClass) == inspect.getsource(SomeOtherClass)

    # Note that super() has two arguments.
    transformer = NodeTransformer()
    transformer.visit(ast.parse(inspect.getsource(SomeClass)))
    source = transformer.get_updated_source()
    assert source == inspect.getsource(SomeClass).replace('super()', 'super(SomeClass, self)')

# Generated at 2022-06-21 18:09:03.781358
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import has_method_declaration, has_class_declaration
    from ..utils.testing import assert_transformation, load_and_save
    from ..exceptions import MethodNotFound
    
    s = """super()"""
    assert_transformation(SuperWithoutArgumentsTransformer, s, s)
    

# Generated at 2022-06-21 18:09:04.789734
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:11.034860
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "super().foo()"
    expected_code = "super(Cls, self).foo()"

    tree = ast.parse(code)
    tree.body[0].func.func.value = ast.Name(id="Cls")

    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)

    assert transformer.tree_changed is True
    assert ast.dump(tree) == expected_code


# Generated at 2022-06-21 18:09:19.474412
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import inspect
    from .conftest import get_ast, get_func
    from textwrap import dedent

    code = dedent(inspect.getsource(test_SuperWithoutArgumentsTransformer))

    tree = get_ast(code)
    func = get_func(tree, 'test_SuperWithoutArgumentsTransformer')

    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)

    func = get_func(new_tree, 'test_SuperWithoutArgumentsTransformer')
    assert len(func.body) == 2
    line = func.body[0]
    assert isinstance(line, ast.Expr) and isinstance(line.value, ast.Call)
    assert line.value.func.id == 'super' and len(line.value.args) == 2

# Generated at 2022-06-21 18:09:21.910345
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..node_utils import compile_func


# Generated at 2022-06-21 18:09:23.006602
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:32.310396
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree.body[0].value.func.id == 'super'
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'cls'


# Generated at 2022-06-21 18:09:38.946057
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List
    from ..utils.helpers import get_ast

    snippet1 = '''
    class A:
        def __init__(self):
            super()
    '''
    snippet2 = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
    snippet3 = '''
    class A:
        def __init__(self):
            super()
        @classmethod
        def method2(cls):
            super()
    '''
    snippet4 = '''
    class A:
        def __init__(self):
            super()
        @classmethod
        def method2(cls):
            super(A, cls)
    '''

# Generated at 2022-06-21 18:09:42.676025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):

        def test_super_without_args(self):
            tree = ast.parse('super()')
            transformer = SuperWithoutArgumentsTransformer(tree)
            transformer.run()
            self.assertEqual(
                ast.dump(transformer.tree),
                'Expr(value=Call(func=Name(id=super, ctx=Load()), \
args=[Name(id=cls, ctx=Load()), Name(id=self, ctx=Load())], keywords=[], \
starargs=None, kwargs=None))'
            )

# Generated at 2022-06-21 18:09:50.299523
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    tree = ast.parse('super()')
    node = tree.body[0].value

    # Exercise
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    # Verify
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-21 18:09:51.753356
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:02.059868
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testutils import assert_code

    code1 = """
    class Base:
        def __init__(self, x):
            self._x = super()
    """
    code2 = """
    class Base:
        def __init__(self, x):
            self._x = super(Base, self)
    """
    assert_code(SuperWithoutArgumentsTransformer, code1, code2)

    code1 = """
    class Base:
        @classmethod
        def find(cls):
            a = super()
    """
    code2 = """
    class Base:
        @classmethod
        def find(cls):
            a = super(Base, cls)
    """
    assert_code(SuperWithoutArgumentsTransformer, code1, code2)


# Generated at 2022-06-21 18:10:04.811001
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast.parse('super()'))
    assert transformer._tree_changed == True

# Generated at 2022-06-21 18:10:06.270072
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor, typed_ast

    # Given

# Generated at 2022-06-21 18:10:18.175080
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Before:
    # class Cls:
    #     def __init__(self, age: int) -> None:
    #         super().__init__(age)
    #
    # After:
    # class Cls:
    #     def __init__(self, age: int) -> None:
    #         super(Cls, self).__init__(age)
    node = ast.parse(textwrap.dedent('''
        class Cls:
            def __init__(self, age: int) -> None:
                super().__init__(age)
    '''))
    node = SuperWithoutArgumentsTransformer(node).visit(node)

# Generated at 2022-06-21 18:10:28.840383
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    import inspect
    from .. import ast_transformer
    from ..utils.tree import get_closest_parent_of

    class TestClass(ast_transformer.BaseNodeTransformer):
        target = (2, 7)
        def _replace_super_args(self, node):
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except ast_transformer.NodeNotFound:
                print('super() outside of function')
                return

            try:
                cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
            except ast_transformer.NodeNotFound:
                print('super() outside of class')
                return


# Generated at 2022-06-21 18:10:34.873987
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:10:43.682115
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    src = '''
        class A(object):
            def f(self):
                super()
        '''

    expected_src = '''
        class A(object):
            def f(self):
                super(A, self)
        '''

    tree = source_to_ast(src)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    expected_tree = source_to_ast(expected_src)
    assert ast.dump(tree, annotate_fields=False) == ast.dump(expected_tree, annotate_fields=False)

# Generated at 2022-06-21 18:10:47.536236
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(3)
    transformer.visit(ast.parse("class A: def __init__(self): super()"))
    assert "super(A, self)" in str(transformer.tree)

# Generated at 2022-06-21 18:10:56.668247
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from .codegen import CodeGenerator

    tree = parse('super()').body[0]
    visitor = SuperWithoutArgumentsTransformer(tree, {}, CodeGenerator())
    visitor.visit(tree)
    assert CodeGenerator().visit(tree) == 'super(Cls, self)'

    tree = parse('super(x)').body[0]
    visitor = SuperWithoutArgumentsTransformer(tree, {}, CodeGenerator())
    visitor.visit(tree)
    assert CodeGenerator().visit(tree) == 'super(x)'

# Generated at 2022-06-21 18:11:07.559288
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    tree = ast.parse('super()')
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse('super(__cls__, __self__)'))

    tree = ast.parse('super(1)')
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert not transformer._tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse('super(1)'))

    tree = ast.parse('super()')
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)


# Generated at 2022-06-21 18:11:10.904303
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    src = """a"""

    tn = TreeNode(src)
    tn.attach(SuperWithoutArgumentsTransformer())

    expected_src = """a"""

    tn.compile()
    assert tn.src == expected_src


# Generated at 2022-06-21 18:11:21.998450
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse(textwrap.dedent("""
    class Cls:
        def __init__(self):
            super()
    """))
    tree_changed = False
    SuperWithoutArgumentsTransformer(tree, tree_changed).visit(tree)

# Generated at 2022-06-21 18:11:23.057722
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from visitors.tests.tester import Tester

# Generated at 2022-06-21 18:11:23.587707
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:25.146846
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:41.552782
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.compat import StringIO

    class TestNodeTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.AST, buf: StringIO=None) -> None:
            super(TestNodeTransformer, self).__init__(tree)
            self._buf = buf or StringIO()

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
            output = ast.fix_missing_locations(self.generic_visit(node))  # type: ignore
            ast.dump(output, self._buf)
            return output


# Generated at 2022-06-21 18:11:42.846430
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:53.925687
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .helpers import collect_source_code
    from ..utils.helpers import compile_source
    from ..parsers.ast_parser import parse
    from .unpacking_transformer import UnpackingTransformer
    tree = parse(collect_source_code(__file__, 10, 7))
    tree = UnpackingTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    code = compile_source(tree, __file__)
    assert code == "class Cls(object):\n    def __init__(self, *args, **kwargs):\n        super(Cls, self).__init__(*args, **kwargs)\n        super(Cls, cls).__init__(*args, **kwargs)\n\n"

# Generated at 2022-06-21 18:12:00.049879
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_tree = ast.parse("""
        class A:
            def __init__(self):
                super()
            def f(self):
                super()
    """)
    expected_tree = ast.parse("""
        class A:
            def __init__(self):
                super(A, self)
            def f(self):
                super(A, self)
    """)

    assert SuperWithoutArgumentsTransformer().visit(ast_tree) == expected_tree

# Generated at 2022-06-21 18:12:11.202294
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import copy

    node_call = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    node_func = ast.FunctionDef(name='some_func', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)],
                                                                     vararg=None,
                                                                     kwonlyargs=[],
                                                                     kw_defaults=[],
                                                                     kwarg=None,
                                                                     defaults=[]),
                                body=[], decorator_list=[],
                                returns=None)
    node_class = ast.ClassDef(name='SomeClass', bases=[], keywords=[], body=[node_func], decorator_list=[])

    expected = copy.deepcopy(node_call)


# Generated at 2022-06-21 18:12:12.480642
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_src_from_func

# Generated at 2022-06-21 18:12:13.531038
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes

# Generated at 2022-06-21 18:12:19.441857
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from ..transformers.ast2to3 import Ast2to3Transformer
    from ..transformers.super import SuperWithoutArgumentsTransformer

    class MethodTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: pyast.FunctionDef) -> pyast.FunctionDef:
            for body_node in node.body:
                if (isinstance(body_node, pyast.Expr) and
                        isinstance(body_node.value, pyast.Call) and
                        isinstance(body_node.value.func, pyast.Name) and
                        body_node.value.func.id == 'super'):
                    return node


# Generated at 2022-06-21 18:12:20.521367
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:31.499860
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)
    tree = ast.parse('class C: def __init__(self): super()')
    tree.body[0].body.body[0].value = node
    transformer = SuperWithoutArgumentsTransformer()
    node = transformer.visit(tree)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.ClassDef)
    assert isinstance(node.body[0].body[0], ast.FunctionDef)
    assert isinstance(node.body[0].body[0].body[0], ast.Expr)
    assert isinstance(node.body[0].body[0].body[0].value, ast.Call)

# Generated at 2022-06-21 18:12:51.089239
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from .. import parse


# Generated at 2022-06-21 18:12:53.913267
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """In python 2.7, following code doesn't run.
    
    class A(object):
        def test(self):
            super()
            pass
    A().test()
    """

# Generated at 2022-06-21 18:12:55.105380
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast import parse

    # Given

# Generated at 2022-06-21 18:12:57.252158
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from copy import copy
    import ast
    from ..utils.helpers import get_ast
    from ..exceptions import NodeNotFound


# Generated at 2022-06-21 18:12:59.912625
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import get_test_case_for_transformer_class

# Generated at 2022-06-21 18:13:05.366591
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
            class A:
                def f(self):
                    super()
                def g(cls):
                    super()
            """
    module = compile(code, '<test>', 'exec')
    module = ast.fix_missing_locations(module)

    transformer = SuperWithoutArgumentsTransformer()
    module = transformer.visit(module)
    assert transformer.tree_changed

    # check that cls or self as the first argument was added
    for cls in module.body:
        for method in cls.body:
            if method.name in ('f', 'g'):
                assert method.args.args[0].arg == 'self'
                assert method.body[0].args[0].id == 'A'
                assert method.body[0].args[1].id == method.args.args

# Generated at 2022-06-21 18:13:14.819178
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer.run(tree)
    assert ast.dump(tree) == 'Super(Name(id="Cls", ctx=Load()), Name(id="cls", ctx=Load()))'

    tree = ast.parse('def func(nm): super()')
    SuperWithoutArgumentsTransformer.run(tree)

# Generated at 2022-06-21 18:13:17.461276
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_transform


# Generated at 2022-06-21 18:13:18.775100
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:27.503964
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class B():
    def foo():
        super()
    '''
    tree = ast.parse(code)
    expected_code = '''class B():
    def foo():
        super(B, self)
    '''
    expected_tree = ast.parse(expected_code)
    # Check AST before transformation
    assert ast.dump(tree) == ast.dump(expected_tree)

    # Check AST after transformation
    transform = SuperWithoutArgumentsTransformer()
    transform.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:14:15.412382
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'super()'
    module = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(module)

    assert isinstance(module.body[0], ast.Expr)
    assert isinstance(module.body[0].value, ast.Call)
    assert isinstance(module.body[0].value.func, ast.Name)
    assert module.body[0].value.func.id == 'super'
    assert len(module.body[0].value.args) == 2
    assert isinstance(module.body[0].value.args[0], ast.Name)
    assert module.body[0].value.args[0].id == 'Cls'
    assert isinstance(module.body[0].value.args[1], ast.Name)

# Generated at 2022-06-21 18:14:16.290500
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:23.693522
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_transformer
    source = """
    class Parent:
        def method(self):
            super()
    """
    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert run_transformer(source, SuperWithoutArgumentsTransformer) == """
    class Parent:
        def method(self):
            super(Parent, self)
    """

# Generated at 2022-06-21 18:14:33.719760
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    program_ast = ast.parse("""
    class Cls(object):
       def bar(self):
           super().bar()
    class Cls(object):
        def __init__(self):
            super().__init__()
    """)

    program_expect = ast.parse("""
    class Cls(object):
       def bar(self):
           super(Cls, self).bar()
    class Cls(object):
        def __init__(self):
            super(Cls, self).__init__()
    """)

    tr = SuperWithoutArgumentsTransformer()
    tr.visit(program_ast)
    assert ast.dump(program_expect) == ast.dump(program_ast), 'SuperWithoutArgumentsTransformer not working!'

# Generated at 2022-06-21 18:14:34.246824
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:34.727323
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:38.719887
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    assert_equal(t._replace_super_args(ast.Call(ast.Name(id='bla'), [], [] )), None)

# Verify that SuperWithoutArgumentsTransformer compiles correctly

# Generated at 2022-06-21 18:14:40.448332
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from collections import namedtuple

    # test case 1

# Generated at 2022-06-21 18:14:41.042901
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:42.328747
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import as_tuple
    import astor


# Generated at 2022-06-21 18:16:18.973468
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    before_code = """
        class A:
            def f(self):
                super()
    """
    after_code = """
        class A:
            def f(self):
                super(A, self)
    """
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast.parse(before_code))
    assert after_code == transformer.result



# Generated at 2022-06-21 18:16:19.843116
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:30.337546
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..testing_utils import auto_transform, AssertNoChanges
    import pytest
    from .base import BaseNodeTransformer
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')


# Generated at 2022-06-21 18:16:32.655778
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from .. import print_tree as pt


# Generated at 2022-06-21 18:16:43.924519
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from .helpers import get_visitor
    from .helpers import full_parse
    from .helpers import assert_source_equal
    from .helpers import dump_tree

    source = """
        class S:
            def method(self):
                super().method(2)
        
        class C(S):
            def method(self):
                super().method(2)
                super()
        """
    expected_source = """
        class S:
            def method(self):
                super().method(2)
        
        class C(S):
            def method(self):
                super().method(2)
                super(C, self)
        """

    tree = full_parse(source)

# Generated at 2022-06-21 18:16:55.170313
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print('Testing class SuperWithoutArgumentsTransformer')

    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))

    node = ast.parse('super(a, b)')
    SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))

    node = ast.parse('class A(object):\n    pass')
    SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))

    node = ast.parse('class A(object):\n    def __init__(self):\n       super()')
    SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))


# Generated at 2022-06-21 18:17:02.800544
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast

    res: ast.Call
    with_args: ast.Call
    res = SuperWithoutArgumentsTransformer.visit_Call(None, ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))
    assert_equal_ast(res, with_args)
    with_args = ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[])

# Generated at 2022-06-21 18:17:11.995659
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code_ast, _ = test_utils.build_ast('super()')
    tree = codegen.to_source(SuperWithoutArgumentsTransformer(code_ast).visit(code_ast))
    assert tree == 'super(Cls, cls)'
    code_ast, _ = test_utils.build_ast('super(a, b, c)')
    tree = codegen.to_source(SuperWithoutArgumentsTransformer(code_ast).visit(code_ast))
    assert tree == 'super(a, b, c)'

# Generated at 2022-06-21 18:17:23.380178
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

# Generated at 2022-06-21 18:17:27.196737
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..utils.helpers import node_to_string
    code = "super()"
    node = ast3.parse(code)
    SuperWithoutArgumentsTransformer(code, node).visit(node)
    expected_code = "super(Class, self)"
    assert node_to_string(node) == expected_code