

# Generated at 2022-06-21 18:08:16.866307
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target = SuperWithoutArgumentsTransformer
        target_version = (2, 7)

        def _test_transformer(self, before: ast.AST, after: ast.AST) -> None:
            fnode = after  # type: ast.AST
            fname = fnode.name
            if fname == 'method':
                clsname = 'MyClass'
            else:
                clsname = 'Cls'
            self.assertEqual(len(fnode.body), 1)
            self.assertTrue(isinstance(fnode.body[0], ast.Expr))
            expr = fnode.body[0]

# Generated at 2022-06-21 18:08:22.421362
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import parse

    source = 'super()'
    expected = 'super(Cls, self)'
    
    tree = parse(source)
    
    transformer = SuperWithoutArgumentsTransformer(tree)
    result = transformer.visit(tree)
    
    assert expected == to_source(result)

# Generated at 2022-06-21 18:08:34.479884
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    tester = Tester(SuperWithoutArgumentsTransformer)
    tester.test(
        """
        class A:
            def b(self):
                super().b()
        """,
        """
        class A:
            def b(self):
                super(A, self).b()
        """
    )

    tester.test(
        """
        class A:
            def b(self):
                super().b()

            @classmethod
            def c(cls):
                super().c()
        """,
        """
        class A:
            def b(self):
                super(A, self).b()

            @classmethod
            def c(cls):
                super(A, cls).c()
        """
    )


# Generated at 2022-06-21 18:08:38.902078
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils import run_transformer
    from .call_expression_cleanup import CallExpressionCleanupTransformer


# Generated at 2022-06-21 18:08:50.544291
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import astunparse
    import textwrap

    class MyTrans:
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.func = ast.Name(id='super', ctx=node.func.ctx)
            return node

    class SuperTrans(SuperWithoutArgumentsTransformer, MyTrans):
        pass

    tree = ast.parse(textwrap.dedent('''\
        class A(object):
            def foo(self):
                super()
                super().foo()
                super(B)
        '''))


    SuperTrans().visit(tree)

# Generated at 2022-06-21 18:08:52.572439
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:55.029421
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:01.727338
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_root_node

    source = """class Cls(object):
    def __init__(self):
        super()
    def func():
        super()"""

    root = ast.parse(source)
    node = get_root_node(root)
    SuperWithoutArgumentsTransformer(source, root).visit(node)

    source_after = """class Cls(object):
    def __init__(self):
        super(Cls, self)
    def func():
        super(Cls, cls)"""

    assert ast.dump(root) == ast.dump(ast.parse(source_after))

# Generated at 2022-06-21 18:09:03.185040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:09:13.537798
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code

    assert_transformed_code(
        SuperWithoutArgumentsTransformer,
        """
        class A:
            x = super()
            def __init__(self):
                self.y = super()
        """,
        """
        class A:
            x = super(A, self)
            def __init__(self):
                self.y = super(A, self)
        """
    )


# Generated at 2022-06-21 18:09:28.824864
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import sys
    sys.path.append("../../")
    from python_to_python.transformers.super_without_arguments import SuperWithoutArgumentsTransformer
    from python_to_python.utils.tree import get_sub_nodes

    # arrange

# Generated at 2022-06-21 18:09:30.063852
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:09:37.173628
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_node
    from ..utils.ast_builder import AstBuilder
    ab = AstBuilder()
    node = get_node("""
    class C(object):
        def f(self):
            return super()
    """)
    assert isinstance(node.body[0].body[0].body[0], ast.Return)
    new_node = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(new_node.body[0].body[0].body[0], ast.Return)
    assert isinstance(new_node.body[0].body[0].body[0].value, ast.Call)

# Generated at 2022-06-21 18:09:49.480923
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    class TestSuperWithoutArgumentsTransformer_visit_Call(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            assert isinstance(node, ast.Call)
            assert isinstance(node.func, ast.Name)
            assert node.func.id == 'super'
            assert not node.args
            # --
            self._replace_super_args(node)
            return node

    # --
    code = """
    class B:
        def f(self):
            super()
    """

    tree = ast.parse(code)
    TestSuperWithoutArgumentsTransformer_visit_Call().visit(tree)
    result = astor.to_source(tree)

# Generated at 2022-06-21 18:09:51.062287
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .test_helpers import roundtrip


# Generated at 2022-06-21 18:09:52.023224
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:01.733836
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Sample(ast.NodeTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(ast.parse('class A():\n    def b():\n        pass'))
    transformer.visit(node)
    assert transformer.tree_changed is True
    assert ast.dump(node) == 'Module(body=[Expr(value=Call(func=Name(id=\'super\', ctx=Load()), args=[Name(id=\'A\', ctx=Load()), Name(id=\'b\', ctx=Load())], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-21 18:10:04.941962
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.visit(ast.parse('''super()''')) == ast.parse('''super(cls, self)''')

# Generated at 2022-06-21 18:10:05.550966
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:17.085309
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_ast
    module_node, = source_to_ast('''
        class B(object):
            def m(self):
                super()
    ''')
    node_transformer = SuperWithoutArgumentsTransformer(module_node, (.5, 29))
    node_transformer.visit(module_node)
    module_node_transformed, = source_to_ast('''
        class B(object):
            def m(self):
                super(B, self)
    ''')
    # print(ast.dump(node_transformer.module))
    compare_ast(module_node_transformed, node_transformer.module)



# Generated at 2022-06-21 18:10:30.796915
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test case 1
    trans = SuperWithoutArgumentsTransformer(ast.parse('super()'))
    node = ast.parse('super()')
    named_node = ast.fix_missing_locations(trans.visit(node))
    assert named_node.body[0].value.args[0].id == 'Cls'
    assert named_node.body[0].value.args[1].id == 'self'
    assert named_node.body[0].value.args[1].id == 'self'
    # Test case 2
    trans = SuperWithoutArgumentsTransformer(ast.parse('super().bar()'))
    node = ast.parse('super().bar()')
    named_node = ast.fix_missing_locations(trans.visit(node))

# Generated at 2022-06-21 18:10:31.365304
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:33.310670
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:10:37.482174
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astmonkey import transformers
    from ..utils.helpers import ast_from_str, dump_ast, equivalent_source


# Generated at 2022-06-21 18:10:43.018458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    sut = SuperWithoutArgumentsTransformer()
    sut._tree_changed = False
    node = ast.parse('super()').body[0]
    sut.visit(node)
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'
    assert sut._tree_changed


# Generated at 2022-06-21 18:10:45.998022
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
    '''
    module_node = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(module_node)

    assert(module_node)

# Generated at 2022-06-21 18:10:51.713638
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def a(self):
            super()
    """
    expected = """
    class A:
        def a(self):
            super(A, self)
    """
    tt = TranspileTest(SuperWithoutArgumentsTransformer)
    tt.test(code, expected)

# Generated at 2022-06-21 18:10:56.715185
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    result = SuperWithoutArgumentsTransformer().visit(node)
    assert result.body[0].value.args[0].id == 'Cls'
    assert result.body[0].value.args[1].id == 'self'



# Generated at 2022-06-21 18:11:02.533364
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast_node_types

    t = SuperWithoutArgumentsTransformer()
    node = ast.parse('super()')
    t.visit(node)
    assert get_ast_node_types(node.body[0].value.args[0]) == ['Name']
    assert get_ast_node_types(node.body[0].value.args[1]) == ['Name']

# Generated at 2022-06-21 18:11:03.532754
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:21.818984
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..visitors.validator import is_valid_node
    from ..visitors.validator import validate_tree
    from ..utils.helpers import get_node_of_type

    source = """
    class A():
        def __init__(self):
            super().__init__()
    """
    tree = source_to_nodes(source)

    SuperWithoutArgumentsTransformer.run(tree)
    validate_tree(tree)

    assert len(get_node_of_type(tree, ast.arguments)[0].args) == 2
    assert get_node_of_type(tree, ast.arguments)[0].args[0].arg == 'A'

# Generated at 2022-06-21 18:11:22.318713
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:28.701285
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node_ = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[]
    )

    rewrited_node_ = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[
            ast.Name(id='Cls', ctx=ast.Load()),
            ast.Name(id='self', ctx=ast.Load())
        ],
        keywords=[]
    )

    class_ = ast.ClassDef(name='Cls', bases=[], body=[], decorator_list=[], keywords=[])

# Generated at 2022-06-21 18:11:40.080687
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

    # super() outside of function
    super_outside_func = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    assert transformer.visit(super_outside_func) == super_outside_func

    # super() outside of class
    class_outside = ast.ClassDef(name='Abc', bases=[], keywords=[], body=[
        ast.FunctionDef(name='__init__', decorator_list=[], args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]), returns=None, body=[
            ast.Pass()
        ]),
        super_outside_func
    ], decorator_list=[])
    assert transformer.visit(class_outside) == class_outside

    # super() inside of class


# Generated at 2022-06-21 18:11:51.951514
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import textwrap
    import typed_astunparse
    from typed_ast import ast3
    from darglint.config import Config
    from darglint.transformers.super_without_arguments import SuperWithoutArgumentsTransformer
    from darglint.transformers.class_method_without_self import ClassMethodWithoutSelfTransformer

    class Tests(object):

        def test_super_in_a_class_without_arguments(self):
            tree = ast3.parse(textwrap.dedent(
                """
                class A(object):
                    def __init__(self):
                        super().__init__()
                """
            ))
            Transformer = SuperWithoutArgumentsTransformer(Config(), tree)
            Transformer.visit(tree)


# Generated at 2022-06-21 18:11:57.785953
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from ..utils.tree import ast2tree
    from ..transformers import Context, BaseNodeTransformer

    tree = ast2tree(parse("super()"))
    for node in tree.iter_subtrees(ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
            SuperWithoutArgumentsTransformer(Context.create(tree)).visit(node)
            break

    assert tree.to_string() == "super(Cls, cls)"



# Generated at 2022-06-21 18:12:09.505246
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[])

    node = SuperWithoutArgumentsTransformer(ast.Module([ast.FunctionDef(name='foo', body=[node],
                                                                          args=ast.arguments(args=[ast.Name(id='self', ctx=ast.Param())],
                                                                                              vararg=None,
                                                                                              kwonlyargs=[],
                                                                                              kw_defaults=[],
                                                                                              kwarg=None,
                                                                                              defaults=[]))]),
                                            {}).visit(node)

    assert isinstance(node.args[0], ast.Attribute)


# Generated at 2022-06-21 18:12:14.323200
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    code = '''
super()
'''

    tree = ast.parse(code)
    node = tree.body[0]
    SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node, ast.Expr)

    node = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node, ast.Module)


# Generated at 2022-06-21 18:12:25.227861
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from compile import compile_src
    code = """
    class Base(object):
        def __init__(self, name):
            self.name = name
            
        def method(self):
            super()
            
        @classmethod
        def cls_method(cls):
            super()
    """
    expected_code = """
    class Base(object):
        def __init__(self, name):
            self.name = name
            
        def method(self):
            super(Base, self)
            
        @classmethod
        def cls_method(cls):
            super(Base, cls)
    """
    tree = compile_src(code, '<test>', 'exec')
    #print(ast.dump(tree))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer

# Generated at 2022-06-21 18:12:34.545599
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseTestTransformer
    from ..utils.helpers import is_valid_ast, tree_to_str

    class Test(BaseTestTransformer):
        transformer = SuperWithoutArgumentsTransformer

        def test_transformer(self):
            code = """
            class Test():
                def __init__(self):
                    super()

                @classmethod
                def cm(cls):
                    super()
            """

            result = """
            class Test():
                def __init__(self):
                    super(Test, self)

                @classmethod
                def cm(cls):
                    super(Test, cls)
            """
            self.assertEqual(tree_to_str(self.transform(code)), tree_to_str(result))

# Generated at 2022-06-21 18:12:56.910912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    expected_code = 'super(Cls, self)'

    tree = ast.parse(textwrap.dedent(code))
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    compiled_code = compile(tree, '', 'exec')

    ns = {}
    exec(compiled_code, ns)
    assert compiled_code == '\nclass Cls(object):\n\tdef __init__(self):\n\t\t' + expected_code


# Generated at 2022-06-21 18:13:00.375587
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cls:
            def __init__(self):
                super()
        """
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "class Cls(object):\n    def __init__(self):\n        super(Cls, self)"

# Generated at 2022-06-21 18:13:02.502126
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_ast_str as str_sta


# Generated at 2022-06-21 18:13:03.088386
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:08.304513
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    transpiled_node = SuperWithoutArgumentsTransformer(node)
    assert transpiled_node == ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[])

# Generated at 2022-06-21 18:13:12.401291
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import io
    from contextlib import contextmanager

    @contextmanager
    def redirect_stdout(new_stdout):
        old_stdout, sys.stdout = sys.stdout, new_stdout
        try:
            yield
        finally:
            sys.stdout = old_stdout


# Generated at 2022-06-21 18:13:19.021718
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.ast_builder import build

    code = """
    class A:
        def func(self):
            res = super()
    """
    tree = build(code)
    compiler = SuperWithoutArgumentsTransformer(tree)
    compiler.visit()

    expected = """
    class A:
        def func(self):
            res = super(A, self)
    """
    assert compiler._tree.to_source() == expected

# Generated at 2022-06-21 18:13:21.086630
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.source import generate_code
    from ..utils.compare import expect_ast

    node = ast.parse('super()')

    SuperWithoutArgumentsTransformer().visit(node)

    expect_ast(node, 'super(Cls, self)')

    generate_code(node) # generate_code should not raise exception

# Generated at 2022-06-21 18:13:30.675944
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "super()"
    tree = ast.parse(code)
    visitor = SuperWithoutArgumentsTransformer(tree=tree, filename='<string>')
    visitor.visit(tree)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert isinstance(tree.body[0].value.args, list)
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].value.args[1], ast.Name)
    visitor.update_tree()
    updated_code = ast.unparse(tree)

# Generated at 2022-06-21 18:13:38.321440
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    
    source = """
    class A:
        def func(self):
            return super()
    """
    expected = """
    class A:
        def func(self):
            return super(A, self)
    """
    
    module, _ = ast3.parse(source)
    tree = SuperWithoutArgumentsTransformer().visit(module)

    # We check the result of compilation using the dump function
    assert ast3.dump(tree) == expected

# Generated at 2022-06-21 18:14:14.220042
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Test(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.AST) -> None:
            self._tree = tree
            self._tree_changed = Fals

# Generated at 2022-06-21 18:14:15.358267
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import setup_ast_parser
    from .. import test_utils


# Generated at 2022-06-21 18:14:17.984914
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Arrange
    node = ast.Call(
        func=ast.Name(id='super'),
        args=[])

    # Act
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(node)

    # Assert
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'

# Generated at 2022-06-21 18:14:19.878044
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..transformers.unpacking_assignment_transformer import UnpackingAssignmentTransformer


# Generated at 2022-06-21 18:14:30.453096
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # When:
    trnsf = SuperWithoutArgumentsTransformer()

    # Given function def:

# Generated at 2022-06-21 18:14:35.555107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Foo:
        def __init__(self):
            super().__init__()
    '''
    tree = ast.parse(code)
    transform = SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(transform, '<test>', 'exec'), globals())
    assert Foo.__init__.__module__ == '<test>'
    del globals()['Foo']

# Generated at 2022-06-21 18:14:36.563295
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:45.553960
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:57.061943
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Unit test for constructor of class SuperWithoutArgumentsTransformer
    """
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import get_close_by_name_first
    from ..exceptions import NodeNotFound
    from astor import dump as astor_dump

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
        super()
        To:
        super(Cls, self)
        super(Cls, cls)
            
        """
        target = (2, 7)


# Generated at 2022-06-21 18:15:05.357105
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    module = ast.parse('''class Cls:
        def func(self):
            super()
        def func2(cls):
            super()
    ''')

    v = SuperWithoutArgumentsTransformer(module)
    v.run()

    assert len(module.body[0].body[0].body[0].args) == 2
    assert module.body[0].body[0].body[0].args[1].id == 'self'
    assert module.body[0].body[1].body[0].args[1].id == 'cls'

# Generated at 2022-06-21 18:16:30.950274
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, FunctionDef, arguments, ClassDef
    from .base import NodeTestCase

    class Test(NodeTestCase):
        target = SuperWithoutArgumentsTransformer
        target_version = (2, 7)
        node = ast.Call(ast.Name(id='super'), [], [])

        def test_change(self):
            res = self.transform()
            self.assertIsInstance(res, Call)

        def test_change_in_function(self):
            res = self.transform(ast.FunctionDef(arguments([], [], [], [], None, []), []))

            self.assertIsInstance(res, FunctionDef)
            self.assertIsInstance(res.body[0], Call)

# Generated at 2022-06-21 18:16:32.450709
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .helper import get_ast

    # Test super inside of class

# Generated at 2022-06-21 18:16:35.582745
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(tree=node)
    transformer.visit(node)
    assert str(node) == "super(SomeClass, self)"


# Generated at 2022-06-21 18:16:43.358270
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test(ast.NodeTransformer):
        def visit_Name(self, node):
            return node
        def visit_Attribute(self, node):
            return self.visit(node.value)

    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree, '__main__')
    new_tree = transformer.visit(tree)
    assert Test().visit(new_tree).body[0].value.args[0].id == '__main__'
    


# Generated at 2022-06-21 18:16:44.375217
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:45.744469
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import code_to_ast

# Generated at 2022-06-21 18:16:51.633081
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class A(object):
            def __init__(self):
                assert type(super()) is super'''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))


if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:16:55.336608
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer(tree, 'abc')
    transformer.visit(tree)

    assert transformer._tree_changed is True

# Generated at 2022-06-21 18:17:01.285607
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
    '''

    expected_code = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
    tt = ast.parse(code)
    SuperWithoutArgumentsTransformer(tt).visit(tt)
    assert ast.dump(tt) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-21 18:17:04.843687
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.helpers import node_to_string
