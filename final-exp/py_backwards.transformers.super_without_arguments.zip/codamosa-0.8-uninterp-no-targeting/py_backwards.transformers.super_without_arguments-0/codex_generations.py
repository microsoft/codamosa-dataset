

# Generated at 2022-06-21 18:08:14.477813
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that SuperWithoutArgumentsTransformer detects super() without arguments and replaces it with super(<classname>, <self>)."""
    code = """
        class Foo:
            def __init__(self):
                super()
            def bar(self):
                def foo():
                    super()
                foo()
    """
    tree = ast.parse(dedent(code))  # to get the correct lineno and col_offset
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert code ==  ast.unparse(tree)
    code = """
        class Foo:
            def __init__(self):
                super(Foo, self)
            def bar(self):
                def foo():
                    super(Foo, self)
                foo()
    """
    tree = ast.parse(dedent(code))

# Generated at 2022-06-21 18:08:22.231614
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    import sys
    import textwrap
    
    
    class TestTransformer(ast3.NodeTransformer):
        def visit_Call(self, node):
            # call super(...).visit_Call(...)
            return super().visit_Call(node)
    
    
    
    
    
    
    
    
    
    
    
    
    class TestTransformer(ast3.NodeTransformer):
        def visit_Call(self, node):
            # call super(...).visit_Call(...)
            return super().visit_Call(node)

    src = r"""
    super()
    """
    expected_out = r"""
    super(A, self)
    """
    tree = ast3.parse(textwrap.dedent(src))
    transformer

# Generated at 2022-06-21 18:08:23.331264
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:35.680339
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    f = ast.parse('super()').body[0]
    f.body = [ast.Expr(f)]
    r = SuperWithoutArgumentsTransformer(ast.parse('class A: def b(): super()'), target_versions={(2, 7)}).visit(f)
    assert isinstance(r, ast.Expr)
    assert isinstance(r.value, ast.Call)
    assert isinstance(r.value.func, ast.Name)
    assert r.value.func.id == 'super'
    assert isinstance(r.value.args[0], ast.Name)
    assert r.value.args[0].id == 'A'
    assert isinstance(r.value.args[1], ast.Name)
    assert r.value.args[1].id == 'b'

    f = ast.parse

# Generated at 2022-06-21 18:08:42.440305
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tt = TranspileTestCase()
    tt.assert_transform('super()', """
    super(Cls, self)
    """)

    tt.assert_transform('super(Cls, self)', """
    super(Cls, self)
    """)

    tt.assert_transform('super(Cls, cls)', """
    super(Cls, cls)
    """)


# Generated at 2022-06-21 18:08:43.481213
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..sixer import Sixer
    from typed_ast import ast3, parse


# Generated at 2022-06-21 18:08:55.310022
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests `SuperWithoutArgumentsTransformer` with a sample Python code:
    class A:
        def __init__(self, a):
            super()
            super()
    
    """
    tree = ast.parse('class A:\n'
                     '    def __init__(self, a):\n'
                     '        super()\n'
                     '        super()')
    transpiled_tree = SuperWithoutArgumentsTransformer().visit(tree)

    expected_tree = ast.parse('class A:\n'
                     '    def __init__(self, a):\n'
                     '        super(A, self)\n'
                     '        super(A, self)')

    # Comparing line by line for better error messages

# Generated at 2022-06-21 18:08:57.146808
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .transpiler import Transpiler
    from ..utils.helpers import string_to_ast_node


# Generated at 2022-06-21 18:09:04.350999
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from .. import test_utils as utils
    code = """
    class Test(object):
        def __init__(self):
            super()
    """
    expected_code = """
    class Test(object):
        def __init__(self):
            super(Test, self)
    """
    tree = ast.parse(code)
    transform(tree, SuperWithoutArgumentsTransformer)
    utils.assert_codemod(tree, expected_code)

# Generated at 2022-06-21 18:09:10.159299
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_snippet = """super()"""
    expected_code = """super(Cls, self)"""
    tree = ast.parse(code_snippet)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    compiled_code = compile(tree, '', 'exec')
    scope = {}
    exec(compiled_code, scope)
    assert scope['__c'].__str__() == expected_code

# Generated at 2022-06-21 18:09:13.554262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile

# Generated at 2022-06-21 18:09:14.917886
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:09:19.139367
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestVisitor(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.AST, **config: Any) -> None:
            super().__init__(tree, **config)
            self.lines: List[int] = []

        def _replace_super_args(self, node: ast.Call) -> None:
            self.lines.append(node.lineno)


# Generated at 2022-06-21 18:09:26.169039
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import cst_to_ast

    tree = cst_to_ast("""
        class Foo:
            def foo(self):
                super()
    """)

    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.visit(tree)
    result = compile(tree, '<test>', 'exec')

    assert result.co_names[-1] == 'super'
    assert result.co_names[-2] == 'Foo'

# Generated at 2022-06-21 18:09:33.482346
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import cst_to_ast
    from .method import MethodTransformer
    from .class_ import ClassTransformer
    from .fill_arguments_with_self import FillArgumentsWithSelfTransformer
    from .typed_ast_convertor import CSTNodeConvertor
    from .fill_arguments_with_cls import FillArgumentsWithClsTransformer
    from ..run import run


# Generated at 2022-06-21 18:09:40.339690
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''class A:
                   def b(cls):
                       super()
               '''
    expected_ast = ast.parse("""class A:
                                    def b(cls):
                                        super(A, cls)
                                """)
    transformer = SuperWithoutArgumentsTransformer(code)
    transformer.run()
    assert ast.dump(expected_ast) == ast.dump(transformer.result_tree)

# Generated at 2022-06-21 18:09:41.037654
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:47.440328
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("""
    class A(object):
        def __init__(self):
            super()

    """)

    expected = ast.parse("""
    class A(object):
        def __init__(self):
            super(A, self)
    """)

    c = SuperWithoutArgumentsTransformer()
    c.visit(node)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 18:09:51.301630
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'super()'
    t = ast.parse(code)
    SuperWithoutArgumentsTransformer().generic_visit(t)
    assert 'super(X, cls)' == astor.to_source(ast.fix_missing_locations(t)).strip()

# Generated at 2022-06-21 18:10:01.698283
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Unit test for constructor of class SuperWithoutArgumentsTransformer
    import unittest
    from typed_ast import ast3 as ast
    from ..utils.transform import get_lambda_ast
    from ..transformers.super_without_arguments import SuperWithoutArgumentsTransformer
    
    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_simple(self):
            tree = ast.parse("""
            class X(object):
                def __init__(self):
                    super()
            """)
            
            SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-21 18:10:08.159757
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(None)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 18:10:11.877947
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import parse_to_ast, ast_to_text, compile_from_text
    from ..utils.helpers import run_in_both_versions


# Generated at 2022-06-21 18:10:19.873117
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from ..utils.helpers import compile_source
    from ..tree_transformer import TreeTransformer

    source = textwrap.dedent("""
        class MyClass:
            def my_method():
                super()

    """)

    expected_result = textwrap.dedent("""
        class MyClass:
            def my_method(self):
                super(MyClass, self)

    """)
    result = compile_source(source, TreeTransformer(SuperWithoutArgumentsTransformer))
    assert result == expected_result

# Generated at 2022-06-21 18:10:20.856495
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:30.940092
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from textwrap import dedent

    code_str = dedent("""
    class BaseClass:
        def __init__(self):
            print("Constructor of Base class called")

    class ChildClass(BaseClass):
        def __init__(self):
            print("Constructor of child class called")
            super()
    """)
    # Create the AST tree
    tree = ast.parse(code_str)
    # Create a transformer class
    transformer = SuperWithoutArgumentsTransformer()
    # Apply the transform on the tree
    transformer.visit(tree)
    transformed_code = compile(tree, '<string>', 'exec')
    # Execute the compiled code
    exec(transformed_code)

# Generated at 2022-06-21 18:10:42.879182
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_ast = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(module_ast)
    assert ast.dump(module_ast) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Queue', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

    module_ast = ast.parse("class A: super()")
    SuperWithoutArgumentsTransformer().visit(module_ast)

# Generated at 2022-06-21 18:10:47.602848
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'

    expected_code = """class A(object):
    def __init__(self):
        super(A, self)
"""
    SimpleTestCase(
        SuperWithoutArgumentsTransformer,
        expected_code,
        code
    ).run_tests()



# Generated at 2022-06-21 18:10:48.873302
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:00.375664
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import setup_ast_node_mock as mock
    
    node = mock.MockASTNode()
    transpiler = SuperWithoutArgumentsTransformer(node)
    transpiler._tree = mock.MockASTNode()
    transpiler._tree.body = [mock.MockASTNode(name="class")]
    transpiler._tree.body.FunctionDef = mock.MockASTNode()
    transpiler._tree.body.FunctionDef.args = mock.MockASTNode()
    transpiler._tree.body.FunctionDef.args.args = [mock.MockASTNode(name="arg")]

    node.Call = []
    node.Call.func = mock.MockASTNode(name="func")
    node.Call.func.id = "super"

# Generated at 2022-06-21 18:11:10.606857
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as su

    source = '''
    class Foo():
        def __init__(self):
            super().__init__()
        
        @classmethod
        def test(cls):
            super().test()
    '''

    expected_result = '''
    class Foo():
        def __init__(self):
            super(Foo, self).__init__()
        
        @classmethod
        def test(cls):
            super(Foo, cls).test()
    '''

    tree = ast.parse(su(source))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert su(expected_result) == su(transformer.result())

# Generated at 2022-06-21 18:11:21.392540
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...testing import assert_equal_ast
    from ..utils.source import source_to_ast


# Generated at 2022-06-21 18:11:25.030360
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('''super()''').body[0]
    transformer = SuperWithoutArgumentsTransformer(None)

    result = transformer.visit_Call(node)

    assert isinstance(result, ast.Call)
    assert result.args[0].id == 'Cls'


# Generated at 2022-06-21 18:11:25.759691
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO
    assert False

# Generated at 2022-06-21 18:11:32.905767
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .fixtures import SuperWithoutArgumentsTransformer_visit_Call as fixture
    from ..utils import cst_to_ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transform = SuperWithoutArgumentsTransformer.visit_Call

        def test_default_1(self):
            tree = cst_to_ast(fixture)
            self.visitor(tree)
            self.assertEqual(tree, cst_to_ast(fixture))

# Generated at 2022-06-21 18:11:33.580963
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:34.208214
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:11:37.883517
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import print_ast
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:11:41.120851
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    super() outside of function or class is allowed
    """
    code = """
    super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '', 'exec') is not None



# Generated at 2022-06-21 18:11:44.495730
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer.run(node)
    assert astor.to_source(node) == "super(Cls, self)"


# Generated at 2022-06-21 18:11:48.978357
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_str
    from .fixtures.super_without_arguments import code
    from ast import check_source

    result = compile_to_str(code, target=2)

    assert check_source(result, mode='exec')

# Generated at 2022-06-21 18:12:15.570808
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from collections import Counter
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')

    class Dummy:
        pass

    dummy_func_def = Dummy()
    dummy_func_def.args = Dummy()
    dummy_func_def.args.args = [Dummy()]
    dummy_func_def.args.args[0].arg = 'self'

    class DummyParent:
        pass

    dummy_parent = DummyParent()
    dummy_parent.body = [dummy_func_def]

    tree.body[0].func.parent = dummy_parent
    tree.body[0].func.parent.body = [dummy_func_def]

    dummy_cls = Dummy()
    dummy_cls.name = 'Test'


# Generated at 2022-06-21 18:12:26.729329
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_tree
    from ..visitor import NodeTransformerErrorVisitor
    from ..utils.helpers import is_same_function
    import textwrap

    src = textwrap.dedent('''
    class A:
        def a(self):
            super()
    ''')

    tree = source_to_tree(src)
    new_tree = SuperWithoutArgumentsTransformer().visit(tree)

    src = textwrap.dedent('''
    class A:
        def a(self):
            super(A, self)
    ''')

    expected_tree = source_to_tree(src)
    assert is_same_function(expected_tree.body[0].body[0], new_tree.body[0].body[0])

    src = textwrap.ded

# Generated at 2022-06-21 18:12:35.564250
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import testing

    source = """
        class A(object):
            def method(self):
                return super()
    """
    expected_code = """
        class A(object):
            def method(self):
                return super(A, self)
    """
    module, _ = testing.modules_from_strings(source)
    t = SuperWithoutArgumentsTransformer(module)
    t.run()
    assert testing.modules_are_the_same(module, expected_code)

    source = """
        class A(object):
            def method():
                return super()
    """
    expected_code = """
        class A(object):
            def method():
                return super(A, cls)
    """
    module, _ = testing.modules_from_strings(source)
    t = SuperWithoutArg

# Generated at 2022-06-21 18:12:45.162002
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    node = tree.body[0].value
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer._replace_super_args = lambda _: None
    transformer.visit_Call(node)
    assert ast.dump(tree, annotate_fields=False) == '''\
Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))
'''



# Generated at 2022-06-21 18:12:55.827306
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # method visit_Call of class SuperWithoutArgumentsTransformer
    # should replace super() with arguments
    node = ast.Call(func=ast.Name(id='super'), args=[])
    transformer = SuperWithoutArgumentsTransformer(None)
    func_def = ast.FunctionDef(args=ast.arguments(args=[ast.Name(id='self', ctx=ast.Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[node], decorator_list=[], returns=None)
    cls_def = ast.ClassDef(bases=[], keywords=[], body=[func_def], decorator_list=[])
    transformer._replace_super_args(node)

    assert isinstance(node.args[0], ast.Name)

# Generated at 2022-06-21 18:12:57.774524
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse("super()")

# Generated at 2022-06-21 18:13:02.248966
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def compile_node(node: ast.AST) -> str:
        tree_transformer = SuperWithoutArgumentsTransformer()
        tree_transformer.visit(node)
        return str(node)

    # this is the AST node we will be testing

# Generated at 2022-06-21 18:13:12.478776
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    data = '''
        super().foo
    '''
    tree = ast.parse(data)
    expected = '''
        super(Cls, self).foo
    '''
    tree_expected = ast.parse(expected)
    tree_changed = False

    class Cls:
        pass

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
                
        """
        def visit_Call(self, node: ast.Call) -> ast.Call:
            nonlocal tree_changed
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id=Cls), ast.Name(id='self')]

# Generated at 2022-06-21 18:13:24.189186
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test(ast.NodeVisitor):
        def visit_Call(self, node):
            if node.args:
                return node.args[0]
            else:
                return node

    for code in (
        'super()',  # Test normal call without arguments
        'super.meth()',  # Test call of super method without arguments
        'super().meth()',  # Test call of super method without arguments
    ):
        class Cls(ast.NodeTransformer):
            def visit_Call(self, node):
                node.args = [node.args[0] if node.args else node]
                return node

        tree = ast.parse(code)
        SuperWithoutArgumentsTransformer(tree).visit(tree)
        ast.fix_missing_locations(tree)
        Test().visit(tree)

# Generated at 2022-06-21 18:13:32.757415
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        def compile_source(self, source: str, target: str) -> str:
            tree = ast.parse(source)
            node = SuperWithoutArgumentsTransformer()
            node.visit(tree)
            fixed_source = compile(tree, '<test>', 'exec').strip()
            self.assertEqual(fixed_source, target)
            return fixed_source

        def test_invalid_usage(self):
            # Invalid usage of super() in function scope
            with self.assertRaises(NodeNotFound):
                self.compile_source("""
                def foo():
                    super()""", "")
            # Invalid usage of super() in function scope in class
            with self.assertRaises(NodeNotFound):
                self.compile_

# Generated at 2022-06-21 18:14:01.747351
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def __init__(self):
                return super()
    """

    expected_code = """
        class A:
            def __init__(self):
                return super(A, self)
    """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    expected_tree = ast.parse(expected_code)
    assert are_asts_equal(tree, expected_tree)

# Generated at 2022-06-21 18:14:03.422181
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast27

# Generated at 2022-06-21 18:14:08.252324
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    expected_code = """super(Cls, self)"""
    tree = ast.parse(code)
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-21 18:14:15.888800
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    class MyVisitor(ast.NodeVisitor):
        def visit_FunctionDef(self, node):
            self.result = node

    input_code = """
        def method(self):
            super()
        """
    visitor = MyVisitor()
    visitor.visit(ast.parse(input_code))
    func_def_node = visitor.result
    transformer = SuperWithoutArgumentsTransformer()

    # When
    transformer.visit(func_def_node)

    # Then
    assert func_def_node.body[0].value.args[0].id == 'Cls'
    assert func_def_node.body[0].value.args[1].id == 'self'

# Generated at 2022-06-21 18:14:23.555760
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
    class Cls:
        def __init__(self):
            super()
        def f(self):
            super()
    """
    expected_output = """
    class Cls:
        def __init__(self):
            super(Cls, self)
        def f(self):
            super(Cls, self)
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    output = astor.to_source(tree)
    assert output == expected_output

# Generated at 2022-06-21 18:14:33.908531
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given that I have a Call node to super() with no arguments
    import ast as pyast
    node = pyast.parse('super()', 'dummy.py', 'eval').body[0]  # Call(func='super', args=[])

    # And a ClassDef node
    classdef = pyast.parse('class Classname(object): ...', 'dummy.py', 'eval').body[0]  # type: pyast.ClassDef
    
    # And a FunctionDef node
    functiondef = pyast.parse('def function(classname): ...', 'dummy.py', 'eval').body[0]  # type: pyast.FunctionDef

    # And a tree with these nodes
    tree = pyast.parse('class Classname(object): def function(classname): super()', 'dummy.py', 'eval')



# Generated at 2022-06-21 18:14:43.692144
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_utils import generate_test_ast
    from ..utils.test_utils import wrap_in_fn_and_class

    tree = generate_test_ast(
        """
        super()    
        """
    )

    tree = wrap_in_fn_and_class(tree)

    finder = SuperWithoutArgumentsTransformer()
    finder.visit(tree)
    finder.leave(tree)

    # assert
    assert isinstance(tree.body[0].body[0].value.args[0], ast.Name)
    assert tree.body[0].body[0].value.args[0].id == 'Cls'
    assert isinstance(tree.body[0].body[0].value.args[1], ast.Name)
    assert tree.body[0].body[0].value

# Generated at 2022-06-21 18:14:45.327793
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Test SuperWithoutArgumentsTransformer constructor
    """
    SuperWithoutArgumentsTransformer()


# Generated at 2022-06-21 18:14:53.648353
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    tree = source_to_ast.parse('''
        class A:
            def __init__(self):
                super().__init__()
    ''')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_ast.to_source(tree) == '''
        class A:
            def __init__(self):
                super(A, self).__init__()
    '''

# Generated at 2022-06-21 18:15:01.592546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    tree = ast.parse('class Cls(object):\n    def __init__(self):\n        super()\n')
    transformer = SuperWithoutArgumentsTransformer(tree)

    # Act
    transformer.run()
    compiled_code = compile(tree, '<string>', 'exec')
    exec(compiled_code)

    # Assert
    assert transformer.tree_changed
    assert transformer.log == ["C4366: 'super' call without arguments is illegal, use 'super(Cls, self)' instead"]

# Generated at 2022-06-21 18:15:49.869699
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Dummy(ast.AST):
        fields = ()
        _attributes = ()
    class A(ast.AST):
        fields = ()
        _attributes = ('name', 'args')
    class B(ast.AST):
        fields = ('args', 'body')
        _attributes = ('name', 'args', 'body')
        def __init__(self, *args, **kwargs) -> None:
            self.args = Dummy()
            ast.AST.__init__(self, *args, **kwargs)
    class C(ast.AST):
        fields = ('body',)
        _attributes = ('name', 'bases', 'body')

# Generated at 2022-06-21 18:15:51.776742
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    from .. import transform


# Generated at 2022-06-21 18:15:56.939632
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Test:
        def method(self):
            return super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert_ast_eq(tree, '''
    class Test:
        def method(self):
            return super(Test, self)
    ''')

# Generated at 2022-06-21 18:16:04.032301
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import expect_source

    source = """
        class ParentClass(object):
            def __init__(self):
                super().__init__()
                
        class Class(ParentClass):
            def __init__(self):
                super().__init__()
                
    """
    expect_source(SuperWithoutArgumentsTransformer, source, """
        class ParentClass(object):
            def __init__(self):
                super(ParentClass, self).__init__()

        class Class(ParentClass):
            def __init__(self):
                super(Class, self).__init__()

    """)

# Generated at 2022-06-21 18:16:10.106523
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('''
    class Cls:

        def __init__(self):
            self.x = 1
            super()
            
        def foo(self):
            pass
    ''')
    t = SuperWithoutArgumentsTransformer(tree)
    t.run()
    assert len(t.tree.body[0].body[0].body) == 3
    assert isinstance(t.tree.body[0].body[0].body[2], ast.Call)
    assert t.tree.body[0].body[0].body[2].func.id == 'super'
    assert isinstance(t.tree.body[0].body[0].body[2].args[0], ast.Name)

# Generated at 2022-06-21 18:16:18.810658
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    t = TestTransformer()
    node = ast.parse('super()')
    ast.fix_missing_locations(node)
    tree_changed = t.visit(node)

    assert node.body[0].value.args[0].id == 'Cls'
    assert node.body[0].value.args[1].id == 'self'
    assert tree_changed == True

# Generated at 2022-06-21 18:16:20.054854
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit tests for class SuperWithoutArgumentsTransformer
    """

# Generated at 2022-06-21 18:16:27.470418
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_cases = [
        ('super()', 'super(Cls, self)'),
        ('super(Mcls)', 'super(Mcls)'),
    ]
    for raw, ref in test_cases:
        node = ast.parse(raw)
        transformer = SuperWithoutArgumentsTransformer(node)
        tree_changed = transformer.visit(node)
        assert not tree_changed, 'Unit test case: {}'.format(raw)
        assert ast.dump(node) == ref



# Generated at 2022-06-21 18:16:30.078500
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from utils.helpers import get_node_of_type
    from utils.tree import compile_ast_tree, generate_code


# Generated at 2022-06-21 18:16:32.996376
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.helpers import ast_to_source