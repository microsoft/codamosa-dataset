

# Generated at 2022-06-21 18:08:10.413899
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test tree
    module_node = ast.Module([
        ast.ClassDef(
            name='foo',
            bases=[ast.Name(id='object')],
            body=[
                ast.FunctionDef(
                    name='__init__',
                    args=ast.arguments([ast.arg(arg='self', annotation=None)], None, None, []),
                    body=[ast.Assign([ast.Name(id='a')], ast.Num(n=1))],
                    decorator_list=[],
                    returns=None
                )
            ],
            decorator_list=[]
        )
    ])

    # Transform tree
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(module_node)

    # Check result
    assert new_tree.body[0].body[0].body

# Generated at 2022-06-21 18:08:18.798251
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .unittest_transformer_util import should_transform_to

    code = '''
        class Foo:
            def bar(self):
                super()
    '''
    should_transform_to(SuperWithoutArgumentsTransformer, code, '''
        class Foo:
            def bar(self):
                super(Foo, self)
    ''')

    code = '''
        class Foo:
            def bar(self):
                class Baz:
                    def foobar(self):
                        super()
    '''
    should_transform_to(SuperWithoutArgumentsTransformer, code, '''
        class Foo:
            def bar(self):
                class Baz:
                    def foobar(self):
                        super(Baz, self)
    ''')

    code

# Generated at 2022-06-21 18:08:20.986563
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:23.779500
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.helpers import node_to_str

# Generated at 2022-06-21 18:08:24.894563
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:34.009280
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    t = SuperWithoutArgumentsTransformer()
    func = """
        def foo(self):
            super()
        """
    if t.target <= (3, 7):
        expected_output = """
        def foo(self):
            super(Foo, self)
        """
    else:
        expected_output = """
        def foo(self):
            super()
        """
    assert compile(func) == expected_output


SUPER_TRANSFORMERS: Tuple[Type[BaseNodeTransformer], ...] = (
    SuperWithoutArgumentsTransformer,
)

# Generated at 2022-06-21 18:08:43.380404
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import parse
    tree = parse('''
        super()
    ''')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert str(tree) == '''
        super(Cls, self)
    '''

    tree = parse('''
        class Foo(object):
            def foo(self):
                super()
    ''')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert str(tree) == '''
        class Foo(object):
            def foo(self):
                super(Foo, self)
    '''

# Generated at 2022-06-21 18:08:51.160649
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u

    transpiled_code = u('''
    class Foo:
        def bar(self):
            super()
    ''')

    expected_code = u('''
    class Foo:
        def bar(self):
            super(Foo, self)
    ''')

    tree = ast.parse(transpiled_code)
    SuperWithoutArgumentsTransformer.run(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-21 18:08:58.372541
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    tree = ast3.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    SuperWithoutArgumentsTransformer.write_on_disk(tree, "test_SuperWithoutArgumentsTransformer_before.py")
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    SuperWithoutArgumentsTransformer.write_on_disk(tree, "test_SuperWithoutArgumentsTransformer_after.py")
    assert open("test_SuperWithoutArgumentsTransformer_after.py", "r").read() == "super(Cls, self)\n"

# Generated at 2022-06-21 18:09:09.981050
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    cls = ast.ClassDef(name='Cls', body=[
        ast.FunctionDef(name='__init__', args=ast.arguments(
            args=[ast.arg(arg='self', annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ), body=[
            ast.Expr(value=ast.Call(
                func=ast.Name(id='super', ctx=ast.Load()),
                args=[],
                keywords=[],
                starargs=None,
                kwargs=None,
            ))
        ])
    ])


# Generated at 2022-06-21 18:09:12.943423
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:13.587426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True

# Generated at 2022-06-21 18:09:24.502673
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from ..utils.helpers import get_node_of_class
    from ..utils import compile_source
    from textwrap import dedent
    
    code = dedent('''
        class Test:
            def __init__(self):
                super()
                
        class Test2(Test):
            def __init__(self):
                super()
    ''')
    
    tree = compile_source(code, '<string>', 'exec').body
    tree = transform(tree, SuperWithoutArgumentsTransformer)
    
    cls1 = get_node_of_class(tree, 0, ast.ClassDef)
    assert isinstance(cls1.body[0], ast.FunctionDef)
    assert len(cls1.body[0].body) == 1

# Generated at 2022-06-21 18:09:35.173422
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fixtures import *

    input = """super()"""
    expected = """super(Cls, self)"""

    cls = ast.parse("class Cls(object): pass")
    tree = ast.parse(input)
    tree.body.insert(0, cls)
    tree.body.append(ast.parse("""def method(self):\n    {0}\n""".format(input)))
    tree = SuperWithoutArgumentsTransformer(tree).visit()
    assert compile(tree, "<test>", "exec")

    expected = "class Cls(object): pass\n\ndef method(self):\n    {0}\n".format(expected)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-21 18:09:46.196741
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('''
        class MyClass:
            def my_method(self):
                my_super = super()
                my_super.blah()
    ''')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert ast.dump(tree.body[0].body[0].body[0].value) == \
        "Call(func=Name(id='super', ctx=Load()), args=[Name(id='MyClass', " \
        "ctx=Load()), Name(id='self', ctx=Load())], keywords=[])"

# Generated at 2022-06-21 18:09:47.251497
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_astunparse

# Generated at 2022-06-21 18:09:55.151622
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_BaseNodeTransformer import patch
    transformer = SuperWithoutArgumentsTransformer(None, patch('abc', None))
    new = transformer.visit_Call(ast.Call(func=ast.Name(id='super'), args=[]))
    assert type(new) == ast.Call
    assert new.func.id == 'super'
    assert type(new.args[0]) == ast.Name
    assert new.args[0].id == 'Cls'
    assert type(new.args[1]) == ast.Name
    assert new.args[1].id == 'self'

    new = transformer.visit_Call(ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='a')]))

# Generated at 2022-06-21 18:10:02.856007
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse('''
        class A:
            def method(self):
                return super()
    ''')

    tr = SuperWithoutArgumentsTransformer(module)
    tr.visit(module)

    assert isinstance(module.body[0].body[0].body[0].value.func, ast.Attribute)
    assert module.body[0].body[0].body[0].value.func.attr == '__init__'
    assert isinstance(module.body[0].body[0].body[0].value.func.value, ast.Name)
    assert module.body[0].body[0].body[0].value.func.value.id == 'super'

# Generated at 2022-06-21 18:10:11.671169
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Foo:
        def function(self):
            super()

    node = ast.parse(inspect.getsource(Foo))
    func_node = node.body[0].body[0]
    assert not len(func_node.args.args)
    SuperWithoutArgumentsTransformer(node).visit(node)
    assert len(func_node.args.args) == 2
    assert func_node.args.args[0].arg == 'Foo'
    assert func_node.args.args[1].arg == 'self'

# Generated at 2022-06-21 18:10:13.549461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    # Input code

# Generated at 2022-06-21 18:10:18.568455
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import assert_transformed_ast

    source = '''
    class a(b):
        def c(d):
            super()
    '''
    expected = '''
    class a(b):
        def c(d):
            super(a, d)
    '''
    assert_transformed_ast(SuperWithoutArgumentsTransformer, source, expected)

# Generated at 2022-06-21 18:10:29.180063
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # 1 - test case
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse(
        "class A:\n"
        "    def f(self):\n"
        "        super()\n"
    )
    transformer.visit(tree)
    assert str(tree) == (
        "class A:\n"
        "    def f(self):\n"
        "        super(A, self)\n"
    )

    # 2 - test case
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse(
        "class A:\n"
        "    def f(self):\n"
        "        class B:\n"
        "            def f(self):\n"
        "                super()\n"
    )
    transformer.visit(tree)


# Generated at 2022-06-21 18:10:33.792493
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # fixture
    class Transformer(SuperWithoutArgumentsTransformer):
        # Overwrite public method
        @staticmethod
        def is_applicable(major_ver: int, minor_ver: int) -> bool:
            return True


# Generated at 2022-06-21 18:10:45.017203
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.node_utils import get_name_node, get_args_node
    import sys
    # Given
    call = ast.Call()
    call.func = ast.Name()
    call.func.id = 'super'
    call.args = []

    cls = ast.ClassDef('C')

    func = ast.FunctionDef('f')
    func.args.args = [ast.arg('self')]

    func.body = [call]
    cls.body = [func]

    tree = ast.Module([cls])

    # When
    transformer = SuperWithoutArgumentsTransformer(tree, sys.version_info)
    transformer.visit(tree)
    arg0 = get_args_node(call)
    arg1 = get_args_node

# Generated at 2022-06-21 18:10:57.158006
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    from .. import compile_to_ast
    from .. import print_ast

    tree = get_ast(source_code='super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert print_ast(tree) == compile_to_ast(source_code='super(Cls, self)')

    tree = get_ast(source_code='super()', mode='exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert print_ast(tree) == compile_to_ast(source_code='super(Cls, self)')

    tree = get_ast(source_code='super()', mode='eval')
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-21 18:10:59.287515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ...tests.utils import assert_transformed
    from ..utils import dump


# Generated at 2022-06-21 18:11:04.011467
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    print(astunparse.unparse(tree))

    tree = ast.parse("super(self)")
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    print(astunparse.unparse(tree))

# Generated at 2022-06-21 18:11:12.870225
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as ast3
    from typed_ast import ast3 as ast3
    from darglint.transforms.classes import SuperWithoutArgumentsTransformer

    class Test(unittest.TestCase):
        def test_visit_Call_super_without_args(self):
            tree = ast.parse('''
            class A:
                def f(self):
                    super()
            ''')

            tr = SuperWithoutArgumentsTransformer(tree)
            assert(tr.tree_changed is True)


# Generated at 2022-06-21 18:11:22.634703
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    nd1 = ast.Name(id="super", ctx=ast.Load())
    nd2 = ast.Call(func=nd1, args=[ast.Name(id='cls')])
    nd3 = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.arg(arg="self")], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[nd2], decorator_list=[], returns=None)

    t = SuperWithoutArgumentsTransformer(ast.parse(''), {'foo': nd3})
    t.visit_Call(nd2)
    assert t._tree_changed



# Generated at 2022-06-21 18:11:33.487692
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class MockVisitor:
        def __getattr__(self, name):
            return lambda node: node

    mock_visitor = MockVisitor()
    tree = ast.parse('super()')

    transformer = SuperWithoutArgumentsTransformer(tree, mock_visitor)
    result = transformer.visit(tree)

    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.Call)
    assert isinstance(result.body[0].func, ast.Name)
    assert result.body[0].func.id == 'super'
    assert isinstance(result.body[0].args[0], ast.Name)
    assert result.body[0].args[0].id == 'Cls'
    assert isinstance(result.body[0].args[1], ast.Name)
   

# Generated at 2022-06-21 18:11:36.182675
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:40.726932
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .base import BaseNodeTransformer
    source = source_to_unicode("""
    super()
    """)
    module = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 18:11:49.666958
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_original = """
         class Cls:
            def __init__(self):
                super()
    """
    code_modified = """
         class Cls:
            def __init__(self):
                super(Cls, self)
    """
    tree = ast.parse(code_original)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    code_modified_transformed = str(astor.to_source(transformer.tree))
    assert code_modified in code_modified_transformed


# Generated at 2022-06-21 18:11:54.333322
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class A(object):\n    def __init__(self):\n        super()\n')
    SuperWithoutArgumentsTransformer(tree).run()
    assert ast.dump(tree) == '''<_ast.Module object at 0x7faafaf7add8>'''


# Generated at 2022-06-21 18:11:55.411906
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:56.624370
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:08.164959
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class DummyTree:
        pass
    tree = DummyTree()

    code = 'super()'
    func_body = ast.parse(code).body[0]
    func = ast.FunctionDef()
    func.body = [func_body]
    func.args = ast.arguments()
    func.args.args = [ast.arg('self', None)]
    cls = ast.ClassDef()
    cls.name = 'Cls'
    module = ast.Module()
    module.body = [cls, func]
    tree._ast = module

    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.visit(module)

    expected_code = 'super(Cls, self)\n'

# Generated at 2022-06-21 18:12:17.254348
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import get_node_of_type, get_ast_of_code

    root_node = get_ast_of_code('super()')
    assert isinstance(root_node, ast.Module)

    call_node = get_node_of_type(root_node, ast.Call)
    assert isinstance(call_node, ast.Call)

    assert len(call_node.args) == 0
    assert call_node.func.id == "super"

    transformer = SuperWithoutArgumentsTransformer(root_node)
    transformer.visit(root_node)

    assert len(call_node.args) == 2
    assert isinstance(call_node.args[0], ast.Name)
    assert call_node.args[0].id == "Cls"

# Generated at 2022-06-21 18:12:24.403998
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast

    tree = ast.parse('super()')
    node = tree.body[0].value

    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)

    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-21 18:12:26.309712
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-21 18:12:34.049266
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .fixtures import SuperWithoutArgumentsTransformer

    tree = ast3.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)

    expected = ast3.parse("super(__class__, __self__)")
    print(ast3.dump(tree, include_attributes=True))
    print(ast3.dump(expected, include_attributes=True))
    assert ast3.dump(tree, include_attributes=True) == ast3.dump(expected, include_attributes=True)


# Generated at 2022-06-21 18:12:39.474465
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    cls = ast.ClassDef(
        name='C',
        body=[ast.FunctionDef(
            name='__init__',
            args=ast.arguments(
                args=[ast.arg(arg='self')],
                defaults=[],
                vararg=None,
                kwarg=None,
            ),
            body=[ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='super'),
                    args=[],
                    keywords=[],
                    starargs=None,
                    kwargs=None
                )
            )],
            decorator_list=[],
            returns=None
        )]
    )
    tree = ast.Module(body=[cls])


# Generated at 2022-06-21 18:12:49.779432
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:54.980047
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_pipeline
    line = 'super()'
    node = ast.parse(line, mode='single').body[0]
    SuperWithoutArgumentsTransformer(ast.parse('')).visit(node)
    print(compile_pipeline(node, line, target=(2, 7)))



# Generated at 2022-06-21 18:12:55.875475
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:00.558113
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_in_out_string
    code = """
            class Meta(type):
                pass

            class Cls(metaclass=Meta):
                def meth(self):
                    super()
    """
    expected_code = """
            class Meta(type):
                pass

            class Cls(metaclass=Meta):
                def meth(self):
                    super(Cls, self)
    """
    assert run_in_out_string(code, SuperWithoutArgumentsTransformer) == expected_code

# Generated at 2022-06-21 18:13:09.931888
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .ast_helper import generate_dummy_func_ast
    from .helpers import assert_equal_ast

    # Prepare function with super()
    func_ast = generate_dummy_func_ast(
        body=ast3.parse('super()').body,
    )
    # super() should be replaced with super(Cls, self)
    expected = generate_dummy_func_ast(
        body=ast3.parse('super(Cls, self)').body,
    )
    transformer = SuperWithoutArgumentsTransformer()
    assert_equal_ast(transformer.visit(func_ast), expected)
    assert transformer._tree_changed is True

# Generated at 2022-06-21 18:13:14.795151
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_transform

    # Non target node
    code = 'super(cls, self)'
    assert_transform(SuperWithoutArgumentsTransformer, code, code)
    code = 'super().method()'
    assert_transform(SuperWithoutArgumentsTransformer, code, code)

    # Target node
    code = 'super()'
    output = 'super(Cls, cls)'
    assert_transform(SuperWithoutArgumentsTransformer, code, output)

# Generated at 2022-06-21 18:13:15.426612
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:27.343192
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import Compiler
    COMPILER = Compiler()

    source = '''
    class Foo:
        def __init__(self):
            super()
    '''

    expected_result = '''
    class Foo:
        def __init__(self):
            super(Foo, self)
    '''

    tree = COMPILER.ast_from_string(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    result = COMPILER._compile_ast(tree)
    assert result == expected_result

    source = '''
    def Foo():
        def __init__(self):
            super()
    '''


# Generated at 2022-06-21 18:13:34.420087
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:13:38.024830
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer._replace_super_args(tree.body[0].value)
    assert ast.dump(tree) == \
"""Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"""

# Generated at 2022-06-21 18:13:45.621104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse(
        'foo = super()\n'
        'bar = super()\n'
    )

    cls = SuperWithoutArgumentsTransformer()
    cls.visit(tree)

    print(ast.dump(tree))

# Generated at 2022-06-21 18:13:55.155020
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    src = """
    class Point(object):
        def __init__(self, x, y):
            super().__init__()
            self.x = x
            self.y = y
    """
    expected_result = """
    class Point(object):
        def __init__(self, x, y):
            super(Point, self).__init__()
            self.x = x
            self.y = y
    """
    tree = ast.parse(src)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, '', 'exec')

    exec(result)


# Generated at 2022-06-21 18:14:01.244613
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test case SuperWithoutArgumentsTransformer.visit_Call
    """

    # Arrange
    input_node = ast.Call()
    input_node.func = ast.Name()
    input_node.func.id = 'super'
    input_node.args = []

    # Act
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit_Call(input_node)

    # Assert
    assert transformer._replace_super_args.called



# Generated at 2022-06-21 18:14:06.884819
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
        class Foo:
            def bar(self):
                super()
        """)
    
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    expected = ast.parse("""
        class Foo:
            def bar(self):
                super(Foo, self)
        """)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:14:12.110731
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_equal
    from .. import ast_converter
    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    assert_code_equal(ast_converter.to_code(SuperWithoutArgumentsTransformer().visit(node)), 'super(Cls, self)')

# Generated at 2022-06-21 18:14:20.498139
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = parse('super()')
    node = tree.body[0]

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    node = transformer.visit(node)

    assert transformer._tree_changed
    assert type(node) is ast.Expr
    assert type(node.value) is ast.Call
    assert type(node.value.func) is ast.Name
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2
    assert type(node.value.args[0]) is ast.Name
    assert type(node.value.args[1]) is ast.Name



# Generated at 2022-06-21 18:14:31.917227
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..parser import Parser

    code = """
    class C():
        def __init__(self):
            super()
    """

    _tree = Parser().parsetoast(code)
    classExample = _tree.body[0]
    initExample = classExample.body[0]
    superExample = initExample.body[0].value

    assert(superExample.func.id == 'super' and len(superExample.args) == 0)

    result = SuperWithoutArgumentsTransformer().visit(initExample.body[0])
    assert(result.value.func.id == 'super' and len(result.value.args) == 2)

    result = initExample.body[0]

# Generated at 2022-06-21 18:14:40.687785
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input_code = '''
        class Spam:
            def foo(self):
                super()
                
        class Eggs(Spam):
            def bar(self):
                super()
    '''
    expected_transformed_code = '''
        class Spam:

            def foo(self):
                super(Spam, self)

        class Eggs(Spam):

            def bar(self):
                super(Eggs, self)
    '''
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(input_code))
    assert ast.dump(ast.parse(input_code)) == ast.dump(ast.parse(expected_transformed_code))

# Generated at 2022-06-21 18:14:51.350407
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:54.085395
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast
    from ..transpile import Transpiler
    import ast

# Generated at 2022-06-21 18:14:57.570019
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer
    mod = '''def f(x):
        super()
    '''
    t = run_transformer(SuperWithoutArgumentsTransformer, mod)
    assert t == "def f(x):\n    super(__main__, x)"

# Generated at 2022-06-21 18:14:59.015178
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:00.254496
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:07.966807
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast_helper import ast_from_code
    code = 'class A:\n  def __init__(self):\n    super()\n'
    tree = ast_from_code(code)
    visitor = SuperWithoutArgumentsTransformer(tree)
    visitor.visit(tree)
    code2 = 'class A:\n  def __init__(self):\n    super(A, self)\n'
    tree2 = ast_from_code(code2)
    #print(ast.dump(visitor.tree))
    #print(ast.dump(tree2))
    assert ast.dump(visitor.tree) == ast.dump(tree2)

# Generated at 2022-06-21 18:15:21.777892
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    # test super(Cls, self)
    code_super1 = '''
    class Test:
        def __init__(self):
            super()
    '''
    old_tree_super1 = ast.parse(code_super1)
    new_tree_super1 = SuperWithoutArgumentsTransformer().visit(old_tree_super1)

    assert isinstance(new_tree_super1.body[0].body[0].value.args[0], ast.Name)
    assert new_tree_super1.body[0].body[0].value.args[0].id == 'Test'

    assert isinstance(new_tree_super1.body[0].body[0].value.args[1], ast.Name)

# Generated at 2022-06-21 18:15:30.374558
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():


    # Input program
    input_program = """
    class Foo:
        def __init__(self):
            super().__init__()

    class Bar(object):
        def __init__(self):
            super().__init__()

    """
    # Output program
    output_program = """
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()

    class Bar(object):
        def __init__(self):
            super(Bar, self).__init__()

    """
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.visit(input_program) == output_program

# Generated at 2022-06-21 18:15:37.774335
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from textwrap import dedent
    code = dedent('''
    class Foo:
        def __init__(self, bar):
            super()
    ''')
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == dedent('''
    class Foo:

        def __init__(self, bar):
            super(Foo, self)
    ''').strip()

# Generated at 2022-06-21 18:15:40.437266
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test(SuperWithoutArgumentsTransformer):
        _tree = None
        _tree_changed = False
        def generic_visit(self, node):
            return node

# Generated at 2022-06-21 18:16:03.447436
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import six
    from typed_ast.ast3 import parse
    from ..utils.tree import get_string_repr, substring_is_in_node, node_is_in_tree
    from darglint.utils.helpers import get_class_name
    from darglint.transformers.super_without_arguments import SuperWithoutArgumentsTransformer
    from darglint.exceptions import NodeNotFound

    # Arguments:

    # node
    def test_SuperWithoutArgumentsTransformer_visit_Call__node():
        from typed_ast.ast3 import Call
        from typed_ast.ast3 import Name
        from typed_ast.ast3 import Load
        node = Call(func=Name(id='super', ctx=Load()))

        transformer = SuperWithoutArgumentsTransformer(node)

# Generated at 2022-06-21 18:16:09.551430
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..utils import compile_

    node = get_ast('''
    class MyClass(object):
        def __init__(self):
            super()
    ''')

    # does not raise an exception
    MyClass = node.body[0]
    SuperWithoutArgumentsTransformer(node).visit(MyClass)
    compile_(SuperWithoutArgumentsTransformer(node).visit(MyClass))

    node = get_ast('''
    class MyClass(object):
        def __init__(self, cls):
            super()
    ''')

    # raises an exception
    MyClass = node.body[0]
    SuperWithoutArgumentsTransformer(node).visit(MyClass)

# Generated at 2022-06-21 18:16:20.409878
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super().property')
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert hasattr(node, 'body')
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.func, ast.Attribute)
    assert isinstance(node.body[0].value.func.value, ast.Call)
    assert isinstance(node.body[0].value.func.value.func, ast.Name)
    assert node.body[0].value.func.value.func.id == 'super'
    assert len(node.body[0].value.func.value.args) == 2

# Generated at 2022-06-21 18:16:29.972135
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    func = node.body[0].value
    cls = ast.ClassDef(name='cls')
    func_def = ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg(arg='self')]), body=[ func ])
    cls_def = ast.Module(body=[cls, func_def])
    cls.body.append(func_def)

    transformer = SuperWithoutArgumentsTransformer(cls_def)
    transformer.visit(cls_def)

    assert len(func.args) == 2
    assert func.args[0].id == 'cls'
    assert func.args[1].id == 'self'

# Generated at 2022-06-21 18:16:31.030457
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:32.227842
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:41.406458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests import helpers
    import astor
    a = ''' 
    class A:
        def f(self):
            super()
                '''
    b = ''' 
    class A:
        def f(self):
            super(A, self)
                '''
    before = astor.parse_file(helpers.get_fixture_path(a))
    after = astor.parse_file(helpers.get_fixture_path(b))
    transformer = SuperWithoutArgumentsTransformer(before)
    transformed = transformer.visit(before)
    assert astor.to_source(transformed) == astor.to_source(after)

# Generated at 2022-06-21 18:16:52.346623
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    result = astor.to_source(node)
    assert 'super(Cls, self)' in result

    node = ast.parse('super()')
    func = ast.FunctionDef(name='f', args=ast.arguments(args=[ast.arg(arg='x', annotation=None)], defaults=[], kw_defaults=[], kwarg=None, vararg=None))
    node.body = [func]
    node.body.insert(0, ast.ClassDef(name='Cls', bases=[], body=[], decorator_list=[], keywords=[]))
    SuperWithoutArgumentsTransformer().visit(node)
    result = astor.to_source(node)

# Generated at 2022-06-21 18:16:54.447159
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import testutils


# Generated at 2022-06-21 18:16:56.194275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from . import compile_
    from . import NodeTransformerError
    

# Generated at 2022-06-21 18:17:40.862034
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> bool
    arg_visitor = SuperWithoutArgumentsTransformer(None)
    
    tree = ast.parse("""
        class Test:
            def test(self):
                super()
    """)
    func = tree.body[0].body[0]
    func.body[0].args = [ast.Name(id='Cls'), ast.Name(id='self')]
    assert arg_visitor.visit(tree) == ast.parse("""
        class Test:
            def test(self):
                super(Cls, self)
    """)
    return True

# Generated at 2022-06-21 18:17:41.392511
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:44.593542
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import compile_to_ast

    code = 'super()'
    tree = compile_to_ast(code)

    transformer = SuperWithoutArgumentsTransformer(tree)
    result = transformer.visit(tree)

    expected = 'super(Cls, self)'
    result = compile_to_str(result)

    assert result == expected

# Generated at 2022-06-21 18:17:53.259128
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Arguments of method visit_Call
    node = ast.Call(ast.Name(id="super"), [])

    # Execute the code to transform
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit_Call(node)

    # Asserts
    assert new_node is not None
    assert len(new_node.args) == 2
    assert isinstance(new_node.args[0], ast.Name)
    assert new_node.args[0].id == 'Cls'
    assert isinstance(new_node.args[1], ast.Name)
    assert new_node.args[1].id == 'self'

# Generated at 2022-06-21 18:18:02.872255
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node_0 = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[])
    node_1 = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[ast.Name(id='arg', ctx=ast.Param())], keywords=[])

    node_2 = ast.Call(func=ast.Name(id='nothing', ctx=ast.Load()), args=[], keywords=[])
    node_3 = ast.Call(func=ast.Name(id='nothing', ctx=ast.Load()), args=[ast.Name(id='arg', ctx=ast.Param())], keywords=[])
