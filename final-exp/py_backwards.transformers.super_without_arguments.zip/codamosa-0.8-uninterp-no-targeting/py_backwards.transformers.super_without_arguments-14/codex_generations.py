

# Generated at 2022-06-21 18:08:09.475384
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class Cls:\n    def foo(self):\n        super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert str(tree) == 'class Cls:\n    def foo(self):\n        super(Cls, self)'


# Generated at 2022-06-21 18:08:19.343151
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import asttools
    from ..testing import assert_source_equal
    from .visitor import FakeTree
    
    tree = ast.parse('''
    class A:
        def f(self):
            super()
    ''')
    
    node = tree.body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(FakeTree(node))
    transformer.visit(node)

# Generated at 2022-06-21 18:08:21.139982
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile


# Generated at 2022-06-21 18:08:23.928892
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    '''
    unit test for constructor of class SuperWithoutArgumentsTransformer
    '''
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:08:29.892315
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.test_visitor import transform

    code = "super()"
    result = "super(Cls, self)"
    transform(SuperWithoutArgumentsTransformer, code, result)

    code = "super()"
    result = "super(Cls, cls)"
    transform(SuperWithoutArgumentsTransformer, code, result, is_classmethod=True)

# Generated at 2022-06-21 18:08:42.036989
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..transformers.typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    import inspect
    from typed_ast import ast3 as typed_ast

    class Dummy(BaseNodeTransformer):
        t2 = 3

        def v(self):
            pass

        @classmethod
        def cm(cls): pass

        def __init__(self):
            self.test = 2

    tr = SuperWithoutArgumentsTransformer(typed_ast.parse('super()'))
    assert isinstance(tr, SuperWithoutArgumentsTransformer)
    tr.visit(tr._tree)

    class C:
        def method(self):
            super()

    code = inspect.getsource(C)
    tree = typed_ast.parse(code)
    tr = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-21 18:08:49.564217
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_src = '''
         class Cls(object):
             def __init__(self):
                 super()
    '''
    expected_output_src = '''
        class Cls(object):
            def __init__(self):
                super(Cls, self)
    '''
    actual_output = transform(SuperWithoutArgumentsTransformer, input_src)
    expected_output = ast.parse(expected_output_src)
    assert compare_ast(actual_output, expected_output)

# Generated at 2022-06-21 18:08:52.187726
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super().__init__(self)')
    func = node.body[0].value.func
    assert isinstance(func, ast.Name) and func.id == 'super'

# Generated at 2022-06-21 18:09:00.405872
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    from ..utils.test_utils import transforms_to, get_test_node, get_test_tree

    node = get_test_node("""
        class Foo:
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
    """)

    tree = get_test_tree(node)
    trans = SuperWithoutArgumentsTransformer()
    trans._tree = tree

    transformed = ("""
        class Foo:
            def __init__(self, *args, **kwargs):
                super(Foo, self).__init__(*args, **kwargs)
    """)

    transforms_to(trans, node, transformed)

# Generated at 2022-06-21 18:09:06.674223
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import (
        assert_tree,
        parse_ast_tree,
        build_an_ast_from_source_code,
        get_ast_node,
        basic_py2_source_code_for_transformation_test,
        basic_py2_node_class_def,
        basic_py2_node_function_def,
        basic_py2_node_name,
        basic_py2_node_call,
        basic_py2_node_arguments,
        basic_py2_node_arg,
    )

    tree = parse_ast_tree(basic_py2_source_code_for_transformation_test)

    class_node = get_ast_node(build_an_ast_from_source_code('class MyClass: pass'), ast.ClassDef)


# Generated at 2022-06-21 18:09:10.828208
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import _to3

# Generated at 2022-06-21 18:09:17.654742
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse("super()")
    SuperWithoutArgumentsTransformer(module).visit(module)
    assert ast_to_dict(module) == {'body': [{'args': [{'id': 'Cls'}, {'id': 'self'}],
                                             'func': {'id': 'super'},
                                             'keywords': [],
                                             'starargs': None,
                                             'kwargs': None}],
                                     'col_offset': 0,
                                     'lineno': 1,
                                     'type': 'Module'}

# Generated at 2022-06-21 18:09:19.442887
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:30.934162
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    inp = """class A(object):
    def f(self):
        super()"""
    expected = """class A(object):
    def f(self):
        super(A, self)"""
    tree = ast.parse(inp)
    SuperWithoutArgumentsTransformer().visit(tree)
    out = compile(tree, filename="", mode="exec")
    assert expected == '\n'.join(line.rstrip() for line in out.co_consts[0].co_code.co_consts[1].split('\n'))

    inp = """class A(object):
    def f(self):
        super()
    @classmethod
    def g(cls):
        super()"""

# Generated at 2022-06-21 18:09:31.850070
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:09:34.599189
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    cls = ast.parse('super()').body[0].value
    transformer = SuperWithoutArgumentsTransformer()
    assert isinstance(transformer.visit(cls), ast.Call)



# Generated at 2022-06-21 18:09:36.081906
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor


# Generated at 2022-06-21 18:09:37.074062
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile

# Generated at 2022-06-21 18:09:44.035710
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.test_transformer import generate_code_and_ast

    generate_code_and_ast(
        SuperWithoutArgumentsTransformer,
        """
        class Test(object):
            def test_method(self):
                super()
        """,
        """
        class Test(object):
            def test_method(self):
                super(Test, self)
        """
    )



# Generated at 2022-06-21 18:09:53.609062
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code, code_to_ast
    from ..utils.tree import ast_to_object, object_to_ast, print_tree
    from .base import BaseNodeTransformer
    
    class SubTransformer(BaseNodeTransformer):
        def __init__(self, *args):
            super(SubTransformer, self).__init__(*args)
            self._tree = None
            self._changed = False
            
        @property
        def tree_changed(self):
            return self._changed
            
        @tree_changed.setter
        def tree_changed(self, value):
            self._changed = value
            
        @property
        def tree(self):
            return self._tree
            
        @tree.setter
        def tree(self, value):
            self._tree

# Generated at 2022-06-21 18:10:04.164828
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    t = SuperWithoutArgumentsTransformer(target_version=(2, 7))

    # Visit Call(Name(id='super', ctx=Load()))
    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    actual = t.visit_Call(node)
    assert isinstance(actual, ast.Call)
    assert isinstance(actual.func, ast.Name)
    assert actual.func.id == 'super'
    assert len(actual.args) == 2
    assert isinstance(actual.args[0], ast.Name)
    assert actual.args[0].id == 'Cls'
    assert isinstance(actual.args[1], ast.Name)

# Generated at 2022-06-21 18:10:15.542908
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import List
    from .utils import get_node, get_node_as_str_from_str
    
    t = SuperWithoutArgumentsTransformer()
    
    node = get_node('''super()''')
    t.visit(node)
    assert get_node_as_str_from_str('''super(__class__, self)''', node) == node

    node = get_node('''super(arg)''')
    t.visit(node)
    assert get_node_as_str_from_str('''super(arg)''', node) == node

    node = get_node('''super(arg)''')
    t.visit(node)
    assert get_node_as_str_from_str('''super(arg)''', node) == node

# Generated at 2022-06-21 18:10:17.025273
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from .transformers import ClassRenamerTransformer, BaseClassToGenericClassTransformer
    from ..converter import PythonConverter


# Generated at 2022-06-21 18:10:25.337601
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile, parse

    def test(py2code: str, py3code: str) -> None:
        tree = parse(py3code)
        SuperWithoutArgumentsTransformer(tree).visit(tree)
        code = compile(tree, '<test>', 'exec')
        exec(code, {})

    test(
        py2code="""
            class C(object):
                def __init__(self):
                    super()
        """,
        py3code="""
            class C(object):
                def __init__(self):
                    super()
        """
    )

# Generated at 2022-06-21 18:10:26.305487
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:34.073791
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class TestNode:
        def __init__(self, id_):
            self.id = id_

    func = TestNode('func')
    cls = TestNode('cls')
    tree = ast.FunctionDef(TestNode('func'), TestNode('args'),
                           TestNode('body'), TestNode('decorators'),
                           TestNode('returns'))

    def_super = ast.FunctionDef(TestNode('super'), TestNode('args'),
                                TestNode('body'), TestNode('decorators'),
                                TestNode('false'))


# Generated at 2022-06-21 18:10:39.187193
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing_utils import assert_transformation
    from .. import transforms

    assert_transformation(
        transforms.SuperWithoutArgumentsTransformer,
        'class foo:\n    def bar():\n        super()',
        'class foo:\n    def bar():\n        super(foo, self)'
    )

# Generated at 2022-06-21 18:10:45.200374
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class Cls(object):
        def __init__(self):
            super()
    """
    expected_output = """
    class Cls(object):
        def __init__(self):
            super(Cls, self)
    """

    tree = ast.parse(input)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected_output))


# Generated at 2022-06-21 18:10:51.574460
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = '''class A:
        def f(self):
            super()
        '''
    expected = '''class A:
        def f(self):
            super(A, self)
        '''
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    result = compile(tree, '', 'exec')
    assert expected == result

# Generated at 2022-06-21 18:10:52.161030
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:10:58.656830
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:09.250501
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse(
        ''' class CClass(object):
            def m_method(self):
                super()
    '''
    )

    super_class = node.body[0]
    super_method = super_class.body[0]
    super_func = super_method.body[0]

    SuperWithoutArgumentsTransformer().visit(super_func)

    assert len(super_func.args.args) == 2

    assert isinstance(super_func.args.args[0], ast.Name)
    assert super_func.args.args[0].id == 'CClass'

    assert isinstance(super_func.args.args[1], ast.Name)
    assert super_func.args.args[1].id == 'self'

# Generated at 2022-06-21 18:11:10.761024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import refactor
    from ast_helper import parse


# Generated at 2022-06-21 18:11:12.611514
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse
    from ..utils.source import Source


# Generated at 2022-06-21 18:11:23.447939
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from lib2to3.pgen2.tokenize import generate_tokens
    from lib2to3.pgen2.parse import Parser
    from typed_ast import ast3 as ast
    from ..parsers.python import PythonParser
    from ..transpilers.python.super_without_arguments import SuperWithoutArgumentsTransformer
    import io
    import tokenize

    code = io.StringIO('super()')
    tokens = tokenize.tokenize(code.readline)
    parser = Parser()
    tree = parser.parse(tokens)
    transpiler = PythonParser(tree, debug=True)
    transpiler.register_transformer(SuperWithoutArgumentsTransformer)
    transpiler.transpile()

    assert(isinstance(tree, ast.Module))

# Generated at 2022-06-21 18:11:28.751063
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A():
            def __init__(self):
                super()
    '''
    tree = ast.parse(code)
    t = SuperWithoutArgumentsTransformer(tree=tree, target=(2, 7))
    t.visit(tree)

    assert 'super(A, self)' == code_gen.to_source(tree)

# Generated at 2022-06-21 18:11:33.312020
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor import dump_tree, parse_tree
    from .inline_functions import InlineFunctionsTransformer
    from .remove_classes import RemoveClassesTransformer
    from typing import Dict

    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:11:39.360713
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_some
    from .common import parse_ast
    from .test_CommonSuperclassTransformer import test_CommonSuperclassTransformer_visit_ClassDef
    from .test_ClassAssignmentTransformer import test_ClassAssignmentTransformer_visit_Assign
    from .test_InitDefinitionTransformer import test_InitDefinitionTransformer_visit_ClassDef

# Generated at 2022-06-21 18:11:42.259815
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source

# Generated at 2022-06-21 18:11:51.910542
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_string

    source = source_to_unicode('''
    class A:
        def __init__(self):
            super()
            super(A)
    ''')
    expected_source = source_to_unicode('''
    class A:
        def __init__(self):
            super(A, self)
            super(A)
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).run()
    assert node_to_string(tree) == expected_source

# Generated at 2022-06-21 18:12:05.220355
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import typed_astunparse
    from ..fixer_util import fixer_helper


# Generated at 2022-06-21 18:12:14.162837
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..transformers.base import AutoNumberingTransformer
    from ..transformers.base import DunderAllTransformer
    from ..transformers.base import ImplicitIndentationTransformer
    from ..transformers.base import ModuleTransformer
    from ..transformers.base import NumberingTransformer
    from ..transformers.base import SuiteTransformer
    from .base import TransformerError
    from .base import UnsupportedNodeType
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

    from typed_ast import ast3 as ast


    class Test(unittest.TestCase):
        def setUp(self):
            self._transformer = SuperWithoutArgumentsTrans

# Generated at 2022-06-21 18:12:24.959022
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    import textwrap
    code = textwrap.dedent('''\
        class Foo:
            def bar(self):
                super()
        ''')
    tree = ast3.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert code == ast3.unparse(tree)
    code = textwrap.dedent('''\
        class Foo:
            def bar(self):
                super().x()
        ''')
    tree = ast3.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert code == ast3.unparse(tree)

# Generated at 2022-06-21 18:12:31.177341
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import as_tuple
    from ..utils import get_ast
    from ..node_utils import get_func_args_names, get_cls_name, get_func_name, get_args_of_call

    sample_code = '''class A:
        def foo(self, a):
            super()
    '''
    et = get_ast(sample_code)
    node = get_closest_pare

# Generated at 2022-06-21 18:12:32.626834
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test constructor of class BaseNodeTransformer"""
    BaseNodeTransformer(0, 0)



# Generated at 2022-06-21 18:12:38.715061
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with pytest.raises(TypeError):
        transformer = SuperWithoutArgumentsTransformer(None)
    transformer = SuperWithoutArgumentsTransformer(ast.parse('f()'))
    assert not transformer._tree_changed
    tree = ast.parse('class foo(object):\n    def __init__(self):\n        super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(transformer._tree)
    assert transformer._tree_changed
    tree = ast.parse('class foo(object):\n    def __init__(self):\n        super(foo).__init__()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(transformer._tree)
    assert not transformer._tree_changed

# Generated at 2022-06-21 18:12:39.633392
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:12:44.059003
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .regression.test_super_without_arguments import node, expected
    from .base import BaseNodeTest
    t = SuperWithoutArgumentsTransformer()
    t.visit(node)
    BaseNodeTest.compare_nodes(expected, node)

# Generated at 2022-06-21 18:12:51.731800
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """
    class Cls(object):
        def __init__(self):
            super()
    """
    ast_tree = ast.parse(source)
    log = []
    SuperWithoutArgumentsTransformer(ast_tree, log).visit(ast_tree)
    target = """
    class Cls(object):
        def __init__(self):
            super(Cls, self)
    """
    assert astor.to_source(ast_tree).strip() == target.strip()

# Generated at 2022-06-21 18:12:55.312623
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .unittest_tools import assert_errors_in, assert_passthrough

    tree = ast.parse("super()")
    assert_errors_in(
        SuperWithoutArgumentsTransformer, tree,
        "super() outside of function",
    )


# Generated at 2022-06-21 18:13:18.602075
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:19.674965
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:23.743854
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_code_equal

    code = """
    class A:
        def f(self):
            super()
    """
    tree = ast.parse(code)

# Generated at 2022-06-21 18:13:26.542806
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..utils.tree import check_equal_ast


# Generated at 2022-06-21 18:13:30.171938
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A(object):
        def foo(self):
            super()
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert code == compile(tree, 'test', 'exec')



# Generated at 2022-06-21 18:13:37.891254
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_for
    from ..utils.functools import qualname
    from .helpers import node_ast

    # A simple test
    s = '''
    class Test:
        def __init__(self):
            super()
    Test()
    '''
    ast_ = node_ast(s)
    assert qualname(ast_.body[0].body[0].body[0].value) == qualname(ast.Call)
    compile_for(ast.parse(s))

# Generated at 2022-06-21 18:13:44.649899
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing SuperWithoutArgumentsTransformer
    """
    import ast
    import logging
    import astor
    from .. import transform
    from .. import utils
    from ..py27 import Py27Transformer

    logger = logging.getLogger(__name__)

    code = '''
    class A:
        def __init__(self, x):
            super().__init__()
    x = A()
    '''
    print(code)
    root = ast.parse(code)
    Py27Transformer(logger).visit(root)
    SuperWithoutArgumentsTransformer(logger).visit(root)
    print(astor.to_source(root))
    print(transform(code, Py27Transformer, True))
    print(transform(code, SuperWithoutArgumentsTransformer, True))

# Generated at 2022-06-21 18:13:56.321030
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super() -> super(Cls, self)
    example1 = '''class Cls:
    def __init__(self):
        super()
    '''
    tree1 = ast.parse(example1)
    SuperWithoutArgumentsTransformer().visit(tree1)
    assert tree1.body[0].body[0].value.args[0].id == 'Cls'
    assert tree1.body[0].body[0].value.args[1].id == 'self'

    # super() -> super(Cls, cls)
    example2 = '''class Cls:
    @classmethod
    def method(cls):
        super()
    '''
    tree2 = ast.parse(example2)
    SuperWithoutArgumentsTransformer().visit(tree2)

# Generated at 2022-06-21 18:13:58.284259
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Unit test for SuperWithoutArgumentsTransformer
    """
    import ast as pyast

# Generated at 2022-06-21 18:14:00.392068
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    """
    from .. import compile_source

# Generated at 2022-06-21 18:14:55.450925
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    #TODO: write unit test
    pass

# Generated at 2022-06-21 18:15:02.277559
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
some = super()
    '''
    module = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(module)
    assert str(module) == '''
Module(body=[Assign(targets=[Name(id='some', ctx=Store())], value=Call(func=Name(id='super', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])
    '''

# Generated at 2022-06-21 18:15:11.111500
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_string
    from ..utils.helpers import get_ast

    node = get_ast(compile_string('''
        class A:
            def __init__(self):
                super().__init__()

        class B(A):
            def __init__(self):
                super().__init__()

        class C:
            def __init__(self):
                super.__init__()

        class D(A):
            def __init__(self):
                super.__init__()
    ''', 3))

    node = SuperWithoutArgumentsTransformer().visit(node)
    assert node.body[0].body[0].value.args[0].id == 'A'
    assert node.body[1].body[0].value.args[0].id == 'B'

# Generated at 2022-06-21 18:15:13.108065
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:24.874618
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...scope import Scope
    from ...codegen import CodeGenerator

    # No Change
    node = ast.parse('super()', '<test>', 'exec')
    tree = Scope.build(node)
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_node = transformer.visit(node)
    assert CodeGenerator().visit(new_node) == 'super()'

    # No Change
    node = ast.parse('super(1, 2, 3)', '<test>', 'exec')
    tree = Scope.build(node)
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_node = transformer.visit(node)
    assert CodeGenerator().visit(new_node) == 'super(1, 2, 3)'


# Generated at 2022-06-21 18:15:32.425108
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class Foo:
        def __init__(self):
            super()
    
        @classmethod
        def foo(cls):
            super()'''

    node = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(node).visit(node)
    assert transformer._tree_changed == True
    assert transformer._tree != node
    # TODO: сделать тесты на трансформеры

# Generated at 2022-06-21 18:15:33.477113
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:35.775061
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.tree import tree
    import typed_astunparse


# Generated at 2022-06-21 18:15:43.186480
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_
    from ..utils.helpers import generate_input_output


# Generated at 2022-06-21 18:15:51.832144
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transformers import SuperWithoutArgumentsTransformer

    arr_arg_node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[])

    class_node = ast.ClassDef(name="C", body=[], bases=[], keywords=[], decorator_list=[])
    func_node = ast.FunctionDef(name="func", args = ast.arguments(args=[ast.arg(arg="self", annotation=None)]), body=[ast.Expr(value=arr_arg_node)], decorator_list=[])
    body = [class_node, func_node]

    module_node = ast.Module(body=body)

    c = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:18:07.468971
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    expected = ast.parse('super(Cls, self)')
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0], ast.ClassDef)
    assert isinstance(tree.body[0].body[0].body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0].body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].body[0].body[0].value, ast.Call)