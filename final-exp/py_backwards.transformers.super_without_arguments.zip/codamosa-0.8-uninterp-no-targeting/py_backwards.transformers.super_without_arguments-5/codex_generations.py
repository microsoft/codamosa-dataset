

# Generated at 2022-06-21 18:08:05.300250
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
    class Cls:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert len(tree.body[0].body[0].body[0].args) == 2

# Generated at 2022-06-21 18:08:12.264284
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """super()"""
    output = """super(Cls, self)"""
    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == output

    input = """super()"""
    output = """super(Cls, cls)"""
    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == output

# Generated at 2022-06-21 18:08:12.974275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import run_transformer

# Generated at 2022-06-21 18:08:13.547079
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:08:14.180905
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:08:22.080895
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tr = SuperWithoutArgumentsTransformer()
    class ExpectedTransform:
        def __init__(self, target, value):
            self._target = target
            self._value = value

        def __eq__(self, other):
            if not isinstance(other, ExpectedTransform):
                return NotImplemented
            else:
                return other._target == self._target and other._value == self._value

    class A:
        @staticmethod
        def method_a(a):
            return super() + 1

        @staticmethod
        def method_b(b):
            return super(A, b)
        
        @staticmethod
        def method_c(c):
            return super(c)

        @staticmethod
        def method_d():
            return c + super()
        

# Generated at 2022-06-21 18:08:33.760021
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test 1
    current_ast = ast.parse('super()')
    expected_ast = ast.parse('super(Cls, self)')
    class_ast = ast.parse('class Cls(object):\n    def f():\n        super()')
    function_ast = ast.parse('def f():\n    super()')
    node = class_ast.body[0].body[0].body[0]
    tree = {'Cls': class_ast, 'f': function_ast}
    transformer = SuperWithoutArgumentsTransformer(current_ast, tree)
    transformed_ast = transformer.visit(node)
    assert ast.dump(transformed_ast) == ast.dump(expected_ast)
    assert transformer._tree_changed

    # test 2
    current_ast = ast.parse('super()')

# Generated at 2022-06-21 18:08:35.431946
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:41.647447
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Cls:  # noqa
        def method(self):
            return super()  # noqa

    tree = ast.parse(inspect.getsource(Cls))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    # for debugging:
    # import typed_ast.ast3
    # typed_ast.ast3.dump(tree)

# Generated at 2022-06-21 18:08:48.722843
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    code ='''class Test(object):
        def __init__(self):
            super()
    '''
    node = ast.parse(code)
    SuperWithoutArgumentsTransformer(node).visit(node)
    code_after = astor.to_source(node)
    expected_code = '''class Test(object):
        def __init__(self):
            super(Test, self)
    '''

    assert code_after == expected_code

# Generated at 2022-06-21 18:08:58.507177
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    s = """
    class Parent:
        def __init__(self):
            super()
    """
    t = """
    class Parent:
        def __init__(self):
            super(Parent, self)
    """
    v = SuperWithoutArgumentsTransformer().visit(ast.parse(s))
    assert ast.dump(ast.parse(t)) == ast.dump(v)

# Generated at 2022-06-21 18:09:02.033646
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()
    node = ast.Call() # type: ast.Call
    assert t.visit_Call(node) == node

# Generated at 2022-06-21 18:09:05.071868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import UnitTestTransformer
    transformer = UnitTestTransformer([SuperWithoutArgumentsTransformer])
    transformer.generic_visit(ast.parse("super()"))
    assert transformer._tree_changed

# Generated at 2022-06-21 18:09:08.568528
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    root = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(root)
    assert str(tree.body[0].value) == 'super(Cls, self)'

# Generated at 2022-06-21 18:09:17.920945
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from Checkers.BaseChecker import BaseChecker
    from Checkers.Types import Types
    f = open('super', 'r')  # open() returns a file object
    code = f.read()
    tree = ast.parse(code)

    checker = BaseChecker(tree, 'super')
    checker._transformer = SuperWithoutArgumentsTransformer()
    checker.run()

    assert len(checker.warnings) == 0
    assert not checker._transformer.is_changed()
    assert checker.types == Types.OK

    # test the case where there is a warning
    f = open('super_warn', 'r')  # open() returns a file object
    code = f.read()
    tree = ast.parse(code)

    checker = BaseChecker(tree, 'super')
    check

# Generated at 2022-06-21 18:09:20.457588
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import parse
    from . import dump
    from io import StringIO

# Generated at 2022-06-21 18:09:32.106570
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from typed_ast.ast3 import AST
    from typed_ast import ast3 as ast
    from typed_ast.encoding import cst_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..compat import get_metaclass
    from ..utils.Tree import from_ast

    def test_call_super_without_arguments():
        class MyTransformer(ast.NodeTransformer):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self._tree = None

            def visit_Call(self, node: ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                    node

# Generated at 2022-06-21 18:09:40.340819
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = dedent('''\
    class Cls:
        def method(self):
            super()
    ''')
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    code2 = dedent('''\
    class Cls:
        def method(self):
            super(Cls, self)
    ''')
    tree2 = ast.parse(code2)
    assert strip_without_whitespace(dumps(tree)) == strip_without_whitespace(dumps(tree2))

# Generated at 2022-06-21 18:09:47.205553
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from . import tools as ast_tools

    tree = ast.parse('foo(2)')
    node = tree.body[0].value

    tr = SuperWithoutArgumentsTransformer()
    tr.visit(tree)

    assert ast_tools.node_deep_equal(node, ast.Call(func=ast.Name(id='foo'), args=[ast.Num(n=2)], keywords=[]))



# Generated at 2022-06-21 18:09:52.072540
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
      class A:
        def __init__(self, x):
          self.x = super().__init__(x)
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    assert "super(A, self).__init__(x)" in str(tree).strip()



# Generated at 2022-06-21 18:09:57.916098
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import run_all_nodes

    t = SuperWithoutArgumentsTransformer()
    run_all_nodes(t)

# Generated at 2022-06-21 18:10:09.981850
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.try_to_compile import try_compile
    from .base import BaseNodeTransformer

    code = '''
    class A:
        def foo(self):
            super().bar(42)
    '''
    node = try_compile(code, mode='exec')

    assert isinstance(node, ast.Module)
    subnode = node.body[0]
    assert isinstance(subnode, ast.ClassDef)
    subnode = subnode.body[0]
    assert isinstance(subnode, ast.FunctionDef)
    subnode = subnode.body[0]
    assert isinstance(subnode, ast.Expr)
    subnode = subnode.value
    assert isinstance(subnode, ast.Call)

    transformer = SuperWithoutArgumentsTransformer(tree=node)
   

# Generated at 2022-06-21 18:10:13.890472
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .remove_unused_imports import RemoveUnusedImportsTransformer
    from .target_version_selector import TargetVersionTransformer

    code = '''
    from typing import Callable
    import blah

    def foo():
        pass
    
    class X:
        def __init__(self):
            super().__init__()
            pass

        def bar(self):
            super().foo()
    '''

    tree = parse(code)
    tree = TargetVersionTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    tree = BaseNodeTransformer().visit(tree)
    tree = RemoveUnusedImportsTransformer().visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 18:10:25.436076
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast as to_ast
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target = SuperWithoutArgumentsTransformer.target
        Transform = SuperWithoutArgumentsTransformer

        def test_simple(self):
            tree = to_ast("""
            class Foo:
                def __init__(self):
                    super()
            """)
            self.check_ast(tree)

            tree = to_ast("""
            class Foo:
                def __init__(self):
                    super().__init__()
            """)
            self.check_ast(tree)

            tree = to_ast("""
            class Foo:
                def __init__(self):
                    super().__init__()
            """)
            self.check_ast(tree)


# Generated at 2022-06-21 18:10:26.477132
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor


# Generated at 2022-06-21 18:10:29.741211
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:10:41.940812
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    from ..utils.source import source_to_ast

    from ..utils.message import Message

    class TestTransformer(BaseNodeTransformerTest):
        target_transformer = SuperWithoutArgumentsTransformer
        transformers = [SuperWithoutArgumentsTransformer]

        def test_basic(self):
            code = """
                class C:
                    def f(self):
                        super()
            """
            tree = source_to_ast(code)
            self.check_tree(tree)

            node = tree.body[0].body[0].body[0]
            self.assertIsInstance(node, ast.Expr, 'super() should be replaced by super(Cls, self)')


# Generated at 2022-06-21 18:10:45.534587
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_with_line_numbers import SourceWithLineNumbers as Src
    from ..utils.helpers import ast_from_code, dump_ast
    from ..utils.ast_helpers import ensure_equal_asts, ensure_equal_source


# Generated at 2022-06-21 18:10:51.907253
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    code = """
        class C:
            def __init__(self, *args, **kwargs):
                super()
        """

    module = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)
    compiled = compile(module, '', 'exec')
    assert 'super(C, self)' in str(compiled)

# Generated at 2022-06-21 18:11:02.989998
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    node = ast.Call(
        func=ast.Name(id='super'),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None)
    cls = ast.ClassDef(name='Cls',
        bases=[ast.Name(id='object')],
        body=[node],
        decorator_list=[])
    func = ast.FunctionDef(name='func',
        args=ast.arguments(args=[ast.Name(id='self')], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
        body=[],
        decorator_list=[])
    cls.body.append(func)
    tree = ast.Module(body=[cls])

# Generated at 2022-06-21 18:11:16.684168
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse

    input = 'class A:\n    def a(self):\n        super()'
    output = 'class A:\n    def a(self):\n        super(A, self)\n'

    tree = ast.parse(input)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    result = unparse(tree)
    assert result == output

# Generated at 2022-06-21 18:11:25.998047
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  from typed_ast import ast3 as ast
  from .base import BaseNodeTransformer
  from .utils import compare_ast
  from .list_comprehensions import ListComprehensionsTransformer

  # Compare AST's
  class MyTest(BaseNodeTransformer):
    target = (2, 7)

    def _replace_super_args(self, node: ast.Call) -> None:
      try:
        func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
      except NodeNotFound:
        warn('super() outside of function')
        return

      try:
        cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
      except NodeNotFound:
        warn('super() outside of class')
        return


# Generated at 2022-06-21 18:11:34.097961
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from utils import round_trip, transform, compare_ast
    from typed_ast import ast3 as ast
    node = ast.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    result = ast.parse("super(Cls, self)")
    compare_ast(node, result)
    result = "super(Cls, self)"
    round_trip(result, SuperWithoutArgumentsTransformer)
    result = "super(cls, cls)"
    round_trip(result, SuperWithoutArgumentsTransformer)



# Generated at 2022-06-21 18:11:40.584742
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer({
        'a.py':"""
            class A:
                def __init__(self):
                    super()
                def method(self):
                    super()
        """
    }, fixtures_prefix).result == {
        'a.py':"""
            class A:
                def __init__(self):
                    super(A, self)
                def method(self):
                    super(A, self)
        """
    }, fixtures_prefix

# Generated at 2022-06-21 18:11:51.723386
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
foo = super()
bar = super.__init__()
    """
    ref = """
foo = super(Foo, self)
bar = super(Foo, self).__init__()
"""
    expected_output = astor.to_source(ast.parse(ref), """(astor.py:1:0:0)""")

    class Foo:
        def __init__(self):
            foo = super()
            bar = super.__init__()

    tree = ast.parse(inspect.getsource(Foo))
    super().generic_visit(tree)
    assert astor.to_source(tree, """(astor.py:1:0:0)""") == expected_output

# Generated at 2022-06-21 18:11:58.900179
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class A:

        def __init__(self, x, y):
            super()
            pass
    """
    expected_output = """
    class A:

        def __init__(self, x, y):
            super(A, self)
            pass
    """
    from .. import ast_converter
    from ..ast_transformer import ASTTransformerFactory
    import ast

    a = ast.parse(input)
    atf = ASTTransformerFactory()
    atf.register_transformer(SuperWithoutArgumentsTransformer)
    new_tree = atf.apply(a)
    ret = ast_converter.py__ast_to_py(new_tree)
    print(ret)
    assert ret == expected_output


# Generated at 2022-06-21 18:12:00.464216
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(2, 7)

# Generated at 2022-06-21 18:12:09.156056
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    cls_name = 'Cls'
    method_name = 'do_something'
    tree = ast.parse(
        f"class {cls_name}:\n"
        f"    def {method_name}(self):\n"
        f"        super()\n"
    )

    assert SuperWithoutArgumentsTransformer.validate(tree)

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()

    assert f"super({cls_name}, self)" in ast.dump(tree)

# Generated at 2022-06-21 18:12:18.152383
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import inspect
    import ast
    import typed_astunparse
    from typed_ast import ast3 as typed_ast

    class DummyNode(typed_ast.AST):
        _fields = ()
        _attributes = ()
        def __init__(self):
            pass

    def test_call(func: ast.AST,
                  lineno: int,
                  col_offset: int,
                  func_name: str,
                  node_cls: type,
                  node_attr: str,
                  expect_success: bool):
        node = DummyNode()
        node.func = func
        node.lineno = lineno
        node.col_offset = col_offset
        arg = typed_ast.Name(id='arg1', ctx=typed_ast.Load())
        node.args = [arg]

       

# Generated at 2022-06-21 18:12:20.520501
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .base import BaseNodeTransformerTestCase
    

# Generated at 2022-06-21 18:12:36.509072
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:38.046524
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:48.883166
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import print_ast
    from .base import BaseNodeTransformer
    
    class MockTransformer(BaseNodeTransformer):
        tree_changed = None
        
        def _replace_super_args(self, node: ast.Call) -> None:
            node.args = [ast.Name(id='cls'), ast.Name(id='self')]
            
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self._replace_super_args(node)
                self.tree_changed = True
            return self.generic_visit(node)  # type: ignore
    
    tree = ast.parse

# Generated at 2022-06-21 18:12:55.827762
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "class Cls(object):\n\tdef __init__(self, data):\n\t\tself.data = data\n\t\tsuper()\n"

    tree = ast.parse(code, '', mode='exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert str(tree) == "class Cls(object):\n    def __init__(self, data):\n        self.data = data\n        super(Cls, self)\n"

# Generated at 2022-06-21 18:13:06.873410
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer(None)

    node = ast.Call()
    ret = t.visit_Call(node)

    assert ret is None
    assert ret is node

    node = ast.Call(func=ast.Name(id='super'))
    ret = t.visit_Call(node)

    assert ret is None
    assert ret is node

    node = ast.Call(func=ast.Name(id='super'), args=[])
    ret = t.visit_Call(node)

    assert ret is None
    assert ret is node
    assert ret.func.id == 'super'
    assert len(ret.args) == 2
    assert isinstance(ret.args[0], ast.Name)
    assert ret.args[0].id == 'Cls'

# Generated at 2022-06-21 18:13:12.881615
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code

    source = """
        class A:
          def __init__(self):
            super().__init__()
        """
    code = source_to_code(source)
    tree = ast.parse(code)

    SuperWithoutArgumentsTransformer().visit(tree)
    assert code_to_source(tree) == """
        class A:
          def __init__(self):
            super(A, self).__init__()
        """

# Generated at 2022-06-21 18:13:17.553796
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    trans_super = SuperWithoutArgumentsTransformer()
    new_tree = trans_super.visit(tree)
    test_ast = ast.parse("super(Cls, self)")
    assert ast.dump(new_tree) == ast.dump(test_ast)

# Generated at 2022-06-21 18:13:18.872497
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:27.200042
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from transform import transform_tree
    import os
    import re
    import astunparse

    with open(os.path.abspath(__file__), 'r') as f:
        code = f.read()

    # Test that the transformer works
    tree = ast3.parse(code)
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(tree)
    trans_code = astunparse.unparse(tree)
    assert re.search(r"super\(Cls, func\)", trans_code)

# Generated at 2022-06-21 18:13:33.859271
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree_changed = False

        def generic_visit(self, node):
            return node
    test_transformer = TestTransformer()

    # Edge Cases
    test_node = ast.Call()
    assert test_transformer.visit_Call(test_node) is test_node
    assert test_transformer._tree_changed == False

    # Normal Cases
    test_node = ast.Call(func=ast.Name(id='super'),
                         args=[])
    assert test_transformer.visit_Call(test_node) is test_node
    assert test_transformer._tree_changed == False

    # Normal Cases(2)

# Generated at 2022-06-21 18:14:14.726031
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )

    new_node = SuperWithoutArgumentsTransformer(None).visit_Call(node)

    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.args, list)
    assert isinstance(new_node.args[0], ast.Name)
    assert new_node.args[0].id == 'Cls'
    assert isinstance(new_node.args[1], ast.Name)
    assert new_node.args[1].id in ('self', 'cls')

# Generated at 2022-06-21 18:14:19.631262
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import my_code_to_ast
    from ..utils.tree import print_tree_from_node, print_tree
    from ..exceptions import NodeNotFound, TreeError

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def generic_visit(self, node):
            return node


# Generated at 2022-06-21 18:14:25.306579
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from ..utils.ast_helpers import tree_to_str

    code = """
a = super().b
    """

    tree = parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    expected = """
a = super(Cls, self).b
    """
    assert tree_to_str(tree) == expected

# Generated at 2022-06-21 18:14:26.307868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:14:30.254268
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A(B):
        def __init__(self):
            super().__init__()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer.success == True
    assert transformer.changed == True


# Generated at 2022-06-21 18:14:32.045496
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:38.614028
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")
    node = tree.body[0]

    transformer = SuperWithoutArgumentsTransformer(tree, None)
    result = transformer.visit_Call(node)

    assert result == ast.Call(
        func=ast.Name(id='super'),
        args=[
            ast.Name(id='Cls'),
            ast.Name(id='self')
        ],
        keywords=[],
        starargs=None,
        kwargs=None,
    )



# Generated at 2022-06-21 18:14:39.904168
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transform = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:14:41.473971
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import check_transformer


# Generated at 2022-06-21 18:14:46.314559
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Foo:
        def bar(self):
            super()
    """
    tree = ast.parse(code, mode='exec')
    
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    
    expected_code = """
    class Foo:
        def bar(self):
            super(Foo, self)
    """
    expected_tree = ast.parse(expected_code, mode='exec')
    assert ast.dump(tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)

# Generated at 2022-06-21 18:15:54.867363
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes


# Generated at 2022-06-21 18:16:00.795266
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestSuperWithoutArgumentsTransformer(BaseTest):
        target = (2, 7)
        transformer = SuperWithoutArgumentsTransformer
        path = 'test_super'
        name = path + '.py'
        input = """
            class Root(object):
                def f(self):
                    super()
        """
        output = """
            class Root(object):
                def f(self):
                    super(Root, self)
        """
    a = TestSuperWithoutArgumentsTransformer()
    a.run_test()

# Generated at 2022-06-21 18:16:08.054543
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that super() transforms correctly to super(Cls, self)"""

    from typed_ast import ast3 as ast

    transformer = SuperWithoutArgumentsTransformer(ast.parse('super()'))
    assert transformer._tree_changed

    node = transformer.visit(transformer._tree)
    transformer.generic_visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)

    call_node = node.body[0].value
    assert isinstance(call_node.func, ast.Name)
    assert call_node.func.id == 'super'
    assert len(call_node.args) == 2

# Generated at 2022-06-21 18:16:09.629973
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..utils.ast3_helpers import parse_function
    from ..imports.helpers import is_super_import_needed
    

# Generated at 2022-06-21 18:16:11.303116
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:16:17.549495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import wrap_in_function_ast, compare_ast
    from .. import transform

    code = '''super()'''
    expected = '''super(__cls__, __self__)'''
    tree = wrap_in_function_ast(code)
    res = transform(ast.parse(expected), 2, 7)

    compare_ast(res, tree, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:16:28.125111
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:38.297545
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, FunctionDef, ClassDef, arguments, NameConstant

    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-21 18:16:42.006756
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()', 'exec')
    SuperWithoutArgumentsTransformer().visit(tree)

    expected = ast.parse('super(__class__, self)', 'exec')
    assert ast.dump(expected) == ast.dump(tree)

# Generated at 2022-06-21 18:16:53.792703
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
            class Test:
                def __init__(self):
                    super()
    '''
    expected = '''
            class Test:
                def __init__(self):
                    super(Test, self)
    '''
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))
    result = compile(t.tree, '', 'exec')
    assert expected == ''.join(line.rstrip() + '\n' for line in result.co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_code.co_lnotab.decode('utf-8').splitlines())
    print(result)

#Unit test for transformation of code