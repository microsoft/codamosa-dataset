

# Generated at 2022-06-21 18:08:10.157823
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def check_super(code):
        tree = ast.parse(dedent(code))
        tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
        assert tree.body[0].value.args[0].id == 'self'
        assert tree.body[0].value.args[1].id == 'Cls'

    check_super("""
    class Cls:
        def __init__(self):
            super()
    """)

    check_super("""
    class Cls:
        def __init__(self):
            (super())
    """)

    check_super("""
    class Cls:
        def __init__(self):
            [super()]
    """)


# Generated at 2022-06-21 18:08:11.375440
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:15.064724
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_psrc

    s = source_to_unicode('''
        class A:
            def f(self): super()
    ''')
    node = compile_psrc(s, 2.7)
    assert source_to_unicode(node) == source_to_unicode('''
        class A:
            def f(self): super(A, self)
    ''')
    # print(source_to_unicode(node))

# Generated at 2022-06-21 18:08:27.936584
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..utils.builder import build
    from ..utils.test_utils import assert_asts_equivalent

    # Constructed AST of:
    # class A:
    #   def foo(self):
    #     super()
    #     super()

# Generated at 2022-06-21 18:08:29.258798
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:08:30.347343
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:38.185843
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class MyClass:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)  # type: ignore
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    expected_tree = ast.parse(
        """
    class MyClass:
        def __init__(self):
            super(MyClass, self)
    """
    )
    assert are_asts_equal(tree, expected_tree)



# Generated at 2022-06-21 18:08:39.047976
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:40.933821
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:47.976153
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import setup_and_compile, assert_equal_source
    setup_and_compile(SuperWithoutArgumentsTransformer)
    assert_equal_source(
        '''
        class Cls(object):
            def __init__(self, x):
                super(Cls, self).__init__()
        ''',
        """
        class Cls(object):
            def __init__(self, x):
                super().__init__()
        """,
    )

# Generated at 2022-06-21 18:09:00.703495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_python_node
    from .UnpackingGeneralizedTransformer import UnpackingGeneralizedTransformer

    source = """
        class MyClass:
            def __init__(self, x):
                super().__init__(x, 2)

        class MyClass(object):
            def __init__(self, x):
                super().__init__(x, 2)
            def my_method(self, y):
                super().__init__(y, x)
    """

# Generated at 2022-06-21 18:09:05.349155
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import get_node
    from typed_ast import ast3 as ast

    tree = get_node("class Dummy: def __init__(self): super()")
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            call_node = node

    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)

    assert call_node.args[0].id == 'Dummy'
    assert call_node.args[1].id == 'self'

# Generated at 2022-06-21 18:09:10.206203
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    node = tree.body[0].value

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    node = transformer.visit(node)

    assert ast.dump(node, include_attributes=False) == "Call(Name(id='super'), [Name(id='Cls'), Name(id='self')], [])"

# Generated at 2022-06-21 18:09:11.183820
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:15.066313
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .types import SuperWithoutArgumentsTransformer
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Attribute
    from ..utils.tree import parse_str

    import astunparse


# Generated at 2022-06-21 18:09:20.224317
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src

    class_value = "class A(object):\n  def f(self, a): super()"
    class CheckerSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self.visited = False
        def visit_Call(self, node):
            self.visited = True
            return super().visit_Call(node)

    tree = compile_src(class_value, 2, 7)
    checker = CheckerSuperWithoutArgumentsTransformer()
    checker.visit(tree)
    assert checker.visited

# Generated at 2022-06-21 18:09:24.388406
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    module = ast.parse(code)
    cls = ast.ClassDef()
    func = ast.FunctionDef(name='__init__')
    func.args = ast.arguments(args=[ast.arg(arg='self')], vararg=None, kwarg=None, kwonlyargs=[], defaults=[],
                              kw_defaults=[])
    cls.body = [func]
    module.body = [cls]
    wrapper = SuperWithoutArgumentsTransformer(module)
    wrapper.visit(module)
    wrapper.replace()
    expected = "super(__main__.Cls, self)"
    assert get_source(module) == expected



# Generated at 2022-06-21 18:09:25.966044
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-21 18:09:34.638598
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast

    class Test:
        def foo(self):
            super()
        def bar(cls):
            super()

    tree = get_ast(Test, 2)
    tree_transformed = TransformFromAST().visit(tree)

    class Test:
        def foo(self):
            super(Test, self)
        def bar(cls):
            super(Test, cls)

    tree_expected = get_ast(Test, 2)

    assert ast.dump(tree_transformed, annotate_fields=False) == ast.dump(tree_expected, annotate_fields=False)

# Generated at 2022-06-21 18:09:43.873590
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from ..pysource import to_source
    code = dedent('''
    class C(object):
        def __init__(self):
            super().__init__()
    ''')
    expected_code = dedent('''
    class C(object):
        def __init__(self):
            super(C, self).__init__()
    ''')
    root = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(root)
    assert to_source(tree) == expected_code

# Generated at 2022-06-21 18:09:52.468984
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test1(SuperWithoutArgumentsTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return self.generic_visit(node) # type: ignore

    class Test2(SuperWithoutArgumentsTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return self.generic_visit(node) # type: ignore


# Generated at 2022-06-21 18:09:56.214241
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(tree, ast.Module)



# Generated at 2022-06-21 18:10:01.951420
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast

    class Foo:
        def foo(self):
            super()

    tree = get_ast(Foo)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    expected = "class Foo:\n\n    def foo(self):\n        super(Foo, self)"
    assert __file__.replace('.py', '') in str(tree)
    assert expected in str(tree)



# Generated at 2022-06-21 18:10:07.592113
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with open(r"./tests/fixtures/node_transformers-transformers/super_without_arguments.py") as module_file:
        string_module = module_file.read()
    tree_module = ast.parse(string_module)
    node_transformer = SuperWithoutArgumentsTransformer(tree_module)
    assert str(node_transformer._tree) == string_module

# Generated at 2022-06-21 18:10:08.160640
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:17.229838
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class A(B.C):
        def __init__(self):
            super()

        def method(self):
            super()
    """
    expected_output = """
    class A(B.C):
        def __init__(self):
            super(A, self)

        def method(self):
            super(A, self)
    """
    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_output.strip()

# Generated at 2022-06-21 18:10:19.082290
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:10:24.333238
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # super() outside of function
    source = "super(Cls, self)"
    expected = "super(Cls, cls)"
    tree = ast.parse(source)
    node = tree.body[0].value
    Super.visit_Call(node)
    assert astor.to_source(node) == expected

    # super() outside of class
    source = "super(Cls, cls)"
    expected = "super(Cls, cls)"
    tree = ast.parse(source)
    node = tree.body[0].value
    Super.visit_Call(node)
    assert astor.to_source(node) == expected

    # super() outside of function and outside of class
    source = "super()"
    expected = "super()"
    tree = ast.parse(source)
    node

# Generated at 2022-06-21 18:10:29.892799
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = dedent("""\
        class Bar:
            def func(self):
                super()
            """)
    expected_code = dedent("""\
        class Bar:
            def func(self):
                super(Bar, self)
            """)
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-21 18:10:33.450092
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    t = ast3.parse("super()")
    SuperWithoutArgumentsTransformer().visit(t)
    assert str(t) == "super(Cls, self)"

# Generated at 2022-06-21 18:10:38.351433
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:10:40.624542
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ...tests.lib.compile import compile_for_test

    compile_for_test(**vars())

# Generated at 2022-06-21 18:10:46.673931
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # We don't test the case where super() is outside of a class/function because right now it's only triggered as a warning.
    # This will be changed when we add options to optionally raise warnings as errors in the future.

    code: str = """
        class Test:
            def test(self):
                super()
        """
    c = SuperWithoutArgumentsTransformer()
    c.visit(ast.parse(code))
    assert """
        class Test:
            def test(self):
                super(Test, self)
        """ == astor.to_source(c.root)

# Generated at 2022-06-21 18:10:58.446424
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from compiler.ast import Call, Name, FunctionDef, ClassDef, Assign

    def test_case(node: ast.Call, expected: ast.Call) -> None:
        transformer = SuperWithoutArgumentsTransformer()

        transformed_node = transformer.visit(node)
        print(ast.dump(transformed_node))
        print(ast.dump(expected))
        assert ast.dump(transformed_node) == ast.dump(expected)


# Generated at 2022-06-21 18:10:59.545811
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:08.149528
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .. import helpers

    node = ast3.parse('super()')

    class TestChooser(helpers.BaseChooser):
        def _choose_node(self, node: ast3.AST) -> bool:
            return isinstance(node, ast3.Call)

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        chooser = TestChooser()

    t = TestSuperWithoutArgumentsTransformer()
    t.visit(node)

    assert len(node.body[0].body[0].value.args) == 2

# Generated at 2022-06-21 18:11:10.451704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Tests the constructor of SuperWithoutArgumentsTransformer
    """
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer is not None


# Generated at 2022-06-21 18:11:12.156772
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import compile_tree, assert_tree


# Generated at 2022-06-21 18:11:16.492841
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.mock_tree import build_module

    t = SuperWithoutArgumentsTransformer(build_module('super()'))
    node = t.visit(t._tree)
    assert str(node) == 'super(__main__, self)'


# Generated at 2022-06-21 18:11:25.322624
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A(object):
            def __init__(self):
                super()
        
        class B(A):
            def __init__(self):
                super()
                super()
    '''
    tree = ast.parse(code)  # type: ignore
    SuperWithoutArgumentsTransformer().visit(tree)
    expected = ast.parse('''
        class A(object):
            def __init__(self):
                super(A, self)
        
        class B(A):
            def __init__(self):
                super(B, self)
                super(B, self)
    ''')  # type: ignore
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:11:40.117797
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    # given
    code = "super()"
    expected_code = "super(Cls, self)"

    # when
    tree = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    actual_code = source_to_unicode(tree)

    # then
    assert actual_code == expected_code

# Generated at 2022-06-21 18:11:45.979326
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...utils import cst_to_ast
    code = "super()"
    expected_code = "super(Cls, self)"
    tree = cst_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert expected_code == to_code(transformer._tree)

# Generated at 2022-06-21 18:11:53.468615
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing the SuperWithoutArgumentsTransformer."""
    code = """
    class MyClass():
        def __init__(self):
            super()
            super()
    """
    expected_code = """
    class MyClass():
        def __init__(self):
            super(MyClass, self)
            super(MyClass, self)
    """
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-21 18:11:54.335912
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:02.452219
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.unparsing import Unparser
    expected = (
        "def test_func():\n"
        "    super(Cls, self).test_method()  # type: ignore\n"
    )

    module = ast.parse(
        "def test_func():\n"
        "    super().test_method()  # type: ignore\n"
    )
    tree = SuperWithoutArgumentsTransformer(module)
    tree.visit(module)
    assert isinstance(module, ast.Module)
    assert Unparser(module).unparse() == expected

# Generated at 2022-06-21 18:12:12.404194
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_ast_str as stas
    from .unicode_literals import UnicodeLiteralsTransformer
    from .absolute_import import AbsoluteImportTransformer
    from .print_function import PrintFunctionTransformer

    # Test for super() with no arguments
    cls = sta('''
        class Useless(object):
            def __init__(self):
                super().__init__()
    ''')
    cls = UnicodeLiteralsTransformer().visit(cls)
    cls = AbsoluteImportTransformer().visit(cls)
    cls = PrintFunctionTransformer().visit(cls)
    cls = SuperWithoutArgumentsTransformer().visit(cls)

# Generated at 2022-06-21 18:12:17.506525
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    transformer = SuperWithoutArgumentsTransformer('')

    # super()
    expected = ast.Call(
        func=ast.Name(id='super'),
        args=[
            ast.Name(id='Cls'),
            ast.Name(id='self'),
        ],
        keywords=[],
    )
    expected.lineno = 1
    expected.col_offset = 0

# Generated at 2022-06-21 18:12:18.818872
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    # Before

# Generated at 2022-06-21 18:12:30.192927
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Test case 1
    tree = ast.parse("""
    class A:
        def f(self):
            super()
    """)

    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-21 18:12:35.271381
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from py2py3 import ast_transformer
    import ast
    class_ = ast.ClassDef(
        name='Test',
        bases=[],
        body=[],
        decorator_list=[]
    )
    method = ast.FunctionDef(
        args=ast.arguments(args=[ast.Name(id='self')], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
        body=[
            ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))
        ],
        decorator_list=[],
        name='__init__',
        returns=None,
    )
    class_.body.append(method)

# Generated at 2022-06-21 18:12:53.591427
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    test_source = '''class C(object):
    def foo(self):
        super()
    def bar(cls):
        super()
'''
    ast_tree = source_to_ast(test_source)
    SuperWithoutArgumentsTransformer().visit(ast_tree)

# Generated at 2022-06-21 18:12:55.825760
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as to_str
    from ..utils.source import source_to_ast as to_ast

# Generated at 2022-06-21 18:12:59.791956
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    s = "super()"
    tree = ast.parse(s)
    node = tree.body[0].value

    expected = "super(type(self), self)"
    i = SuperWithoutArgumentsTransformer(tree)
    i.visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected))
    assert i._tree_changed == True


# Generated at 2022-06-21 18:13:03.295594
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Cls:
        def func(self):
            super()
    '''
    new_code = '''
    class Cls:
        def func(self):
            super(Cls, self)
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert ast.dump(tree) == ast.dump(ast.parse(new_code))

# Generated at 2022-06-21 18:13:11.115764
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object
    import astor

    source = '''
        class A:
            def __init__(self):
                super()
    '''
    result = '''
        class A:
            def __init__(self):
                super(A, self)
    '''

    tree = ast.parse(source)

    transformer = SuperWithoutArgumentsTransformer(tree, code=source_to_code_object(source))
    transformer.run()

    assert astor.to_source(tree) == result



# Generated at 2022-06-21 18:13:13.459141
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:14.421225
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:22.360891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Foo:
            def __init__(self):
                super().__init__()
    """
    expected_code = """
        class Foo:
            def __init__(self):
                super(Foo, self).__init__()
    """
    tr = SuperWithoutArgumentsTransformer()
    tr.visit(ast.parse(code))
    result = ast.dump(tr.tree)
    expected = ast.dump(ast.parse(expected_code))
    assert result == expected

# Generated at 2022-06-21 18:13:29.719106
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input = ast.parse('''
        class A:
            def __init__(self):
                super()
    ''') 
    expected = ast.parse('''
        class A:
            def __init__(self):
                super(A, self)
    ''') 
    node = input.body[0]
    transformer = SuperWithoutArgumentsTransformer(input)
    node = transformer.visit(node)
    assert ast.dump(node, include_attributes=False) == ast.dump(expected.body[0], include_attributes=False)

# Generated at 2022-06-21 18:13:40.534816
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from typed_ast import ast3 as ast

    code = '''
    class A:
        def f(self):
            super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astor.to_source(tree) == code.replace('super()', 'super(A, self)')

    code = '''
    class A:
        def f(self):
            super()

        @staticmethod
        def f(self):
            super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astor.to_source(tree) == code.replace('super()', 'super(A, self)')


# Generated at 2022-06-21 18:14:03.117083
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from . import _fixtures

    code = source_to_unicode(inspect.getsource(_fixtures))
    tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)

    code = compile(new_tree, '<test>', 'exec')

    new_code = inspect.getsource(code)
    assert new_code == source_to_unicode(inspect.getsource(_fixtures))

# Generated at 2022-06-21 18:14:05.579983
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import normalize_code


# Generated at 2022-06-21 18:14:09.086488
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import roundtrip
    code = """
    class Foo():
        def method(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    roundtrip(tree)

# Generated at 2022-06-21 18:14:18.819322
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode

    # Case 1: super() in class
    # Before
    before_source = '''
        class A:
            def __init__(self):
                super()
    '''
    expected_source = '''
        class A:
            def __init__(self):
                super(A, self)
    '''
    # Action
    actual_source = SuperWithoutArgumentsTransformer(before_source).visit()
    # Assert
    assert source_to_unicode(expected_source) == source_to_unicode(actual_source)
    # Case 2: super() in function in class
    # Before
    before_source = '''
        class A:
            def method(self):
                def foo():
                    super()
    '''
    expected_

# Generated at 2022-06-21 18:14:29.548441
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import transform_and_compare

    example = """
            class A:
                def __init__(self):
                    super().__init__()
            class B(A):
                def __init__(self):
                    super().__init__()
            
            class C:
                def __init__(self):
                    super(C, self).__init__()
            
            class D(C):
                def __init__(self):
                    super().__init__()
            """

# Generated at 2022-06-21 18:14:35.859039
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..transformers.superwithoutargumentstransformer import SuperWithoutArgumentsTransformer

    tree = ast.parse('super()')
    tree_changed = False
    transformer = SuperWithoutArgumentsTransformer(tree, tree_changed)
    node = tree.body[0]
    node = transformer.visit_Call(node)
    expected = ast.parse('super(Cls, self)')
    expected = expected.body[0]
    assert node == expected



# Generated at 2022-06-21 18:14:37.201834
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:46.022888
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    CODE_1 = '''
    class A:
        def func(self):
            super() #for class B
    '''

    res = SuperWithoutArgumentsTransformer().visit(ast.parse(CODE_1))

    node_func_class = '''
        func(self):
            super(B, self) #for class B
    '''
    assert ast.dump(res.body[0].body[0]) == ast.dump(ast.parse(node_func_class).body[0])

    CODE_2 = '''
    class A:
        def func(self):
            def func2(self):
                super() #for class B
    '''

    res = SuperWithoutArgumentsTransformer().visit(ast.parse(CODE_2))


# Generated at 2022-06-21 18:14:46.640779
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-21 18:14:51.803928
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_string
    src = '''
    class Foo:
        def foo(self):
            super()
    '''
    assert compile_string(src, 'test', 2) == '''
    class Foo:
        def foo(self):
            super(Foo, self)
    '''

# Generated at 2022-06-21 18:15:28.701631
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    # The sample code

# Generated at 2022-06-21 18:15:33.045119
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # arranges
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_type
    from ..utils.helpers import array_from_dotted_path
    from ..utils.ast_helpers import compare_trees


# Generated at 2022-06-21 18:15:42.270906
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .helpers import build_ast_from_code
    from ..utils.tree_compare import are_asts_equal

    code = """
    class A:
        def __init__(self):
            super()

    class B(A):
        def __init__(self):
            super()
    """
    tree = build_ast_from_code(code, (2, 7))
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    expected_code = """
    class A:
        def __init__(self):
            super(A, self)

    class B(A):
        def __init__(self):
            super(B, self)
    """
    expected_tree = build_ast_from_code(expected_code, (2, 7))


# Generated at 2022-06-21 18:15:48.486662
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Given
    code = "class MyClass(object):\n    def __init__(self):\n        super()\n"
    expected_output = "class MyClass(object):\n    def __init__(self):\n        super(MyClass, self)\n"
    tree = ast.parse(code)

    # When
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    # Then
    assert ast.dump(tree) == expected_output

# Generated at 2022-06-21 18:15:50.230568
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:51.337962
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:59.978912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = astor.to_source(ast.parse(textwrap.dedent('''\
        class Cls(object):
            def __init__(self):
                super()
    ''')))
    expected_result = astor.to_source(ast.parse(textwrap.dedent('''\
        class Cls(object):
            def __init__(self):
                super(Cls, self)
    ''')))
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    result = astor.to_source(tree).strip()
    assert result == expected_result


# Generated at 2022-06-21 18:16:07.486856
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Foo:
            def __init__(self):
                super(Foo, self).__init__()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(code))

    code = """
        class Foo:
            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("""
        class Foo:
            def __init__(self):
                super(Foo, self)
    """))


# Generated at 2022-06-21 18:16:18.682892
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:16:29.208424
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call(
        func = ast.Name(id = "super"),
        args = [],
    )
    cls = ast.ClassDef(name = "C", body = [
        ast.FunctionDef(
            name = "f",
            args = ast.arguments(args=[ast.arg(arg="self", annotation=None)], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]),
            body = [
                node
            ]
        )
    ])
    module = ast.Module(body=[cls])

    SuperWithoutArgumentsTransformer(module).transform()

    assert isinstance(node.args[0], ast.Name) and node.args[0].id == "C"

# Generated at 2022-06-21 18:17:56.286445
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.example_code import SUPER_NO_ARGS
    
    code_before = SUPER_NO_ARGS