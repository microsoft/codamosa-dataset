

# Generated at 2022-06-21 18:08:04.855756
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# vim: set tabstop=4 shiftwidth=4 textwidth=79 cc=72,79:

# Generated at 2022-06-21 18:08:06.580038
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:08:17.497259
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    r"""Test case to test SuperWithoutArgumentsTransformer
    To test, run:
        python3 -m doctest -v pynsource/transformers/super_without_arguments.py
    """
    from pynsource.parsers import pythonparser
    from pynsource.pygraph import PyGraph

    the_input_code = r"""
    class Foo:
        def bar():
            super()
    """
    the_expected_output_code = r"""
    class Foo:
        def bar():
            super(Foo, self)
    """

    the_graph = PyGraph()
    the_parser = pythonparser.PythonParser(the_graph)
    the_parser.ParseSourceCode(the_input_code)
    transformer = SuperWithoutArgumentsTransformer(the_graph)
    transformer.run()
   

# Generated at 2022-06-21 18:08:29.814955
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    code = 'super()'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])"

    code = 'super(None, None)'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='None', ctx=Load()), Name(id='None', ctx=Load())], keywords=[])"

# Generated at 2022-06-21 18:08:31.704156
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import astor
    from .utils import compile_to_ast


# Generated at 2022-06-21 18:08:39.511018
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Compiles:
    #   super()
    # To:
    #   super(Cls, self)
    #   super(Cls, cls)
    from typed_ast import ast3 as ast
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    expected = 'super(Cls, self)'
    assert compile(tree, '<>', 'exec') == compile(expected, '<>', 'exec')

# Generated at 2022-06-21 18:08:47.230255
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import PythonCode
    from ..parsers.ast_parser import ASTParser

    code = '''
    class Test():
        def __init__(self):
            super()
    '''

    parser = ASTParser(PythonCode(code), [SuperWithoutArgumentsTransformer])
    parser.parse()

    assert str(parser.tree) == ast.dump(ast.parse('''
    class Test():
        def __init__(self):
            super(Test, self)
    '''))

# Generated at 2022-06-21 18:08:58.155351
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls:
        def func(self):
            super()
    """
    tree = ast.parse(code)
    walker = SuperWithoutArgumentsTransformer(tree)
    walker.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 18:09:06.548746
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast_node, parse

    code = 'class A(object):\n    def k(self):\n        super()\n'
    new_code = 'class A(object):\n    def k(self):\n        super(A, self)\n'
    tree = parse(code)
    node = get_ast_node(tree, 'super', lambda x: isinstance(x, ast.Call))
    SuperWithoutArgumentsTransformer(tree).visit(node)

    assert ast.dump(tree) == new_code

# Generated at 2022-06-21 18:09:16.187938
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class SuperWithoutArgumentsTransformerSub(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node):
            SuperWithoutArgumentsTransformer._replace_super_args(self, node)
            return node

    source = """\
    class A:
        def __init__(self):
            super()
    """
    expected_result = """\
    class A:
        def __init__(self):
            super(A, self)
    """
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformerSub()
    tree = transformer.visit(tree)
    result = compile(tree, filename='', mode='exec')
    exec(result)

    assert A.__init__.__code__.co_argcount == 2

# Generated at 2022-06-21 18:09:25.257025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transformers import SuperWithoutArgumentsTransformer
    source = """
    class Cls:
        def __init__(self):
            super()
    """
    expected = """
    class Cls:
        def __init__(self):
            super(Cls, self)
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 18:09:30.111614
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
super()
"""
    parsed = ast.parse(input)
    changed = SuperWithoutArgumentsTransformer().visit(parsed)
    expected = """
super(__class__, self)
"""
    assert astor.to_source(changed) == expected

# Generated at 2022-06-21 18:09:35.022229
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    code = dedent('''
    class A:
        def __init__(self):
            super()
    ''')
    node = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(node)
    assert "G0 = super(A, self)" in ast.dump(node)

# Generated at 2022-06-21 18:09:44.394545
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('def func(): super()')
    transformer.visit(tree)
    assert isinstance(tree.body[0].body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].body[0].value.args[1], ast.Name)
    assert tree.body[0].body[0].value.args[0].id == 'func'
    assert tree.body[0].body[0].value.args[1].id == 'self'
    assert transformer.tree_changed

# Generated at 2022-06-21 18:09:44.752605
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:09:53.994428
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    root = ast.parse('super()')
    cls = ast.ClassDef(
        name='A',
        bases=[],
        body=[
            ast.FunctionDef(
                name='f',
                args=ast.arguments(
                    args=[ast.arg(arg='self', annotation=None)],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]
                ),
                body=[ast.Expr(value=root)],
                decorator_list=[],
                returns=None
            )
        ],
        decorator_list=[]
    )


# Generated at 2022-06-21 18:09:58.727824
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[])
    t = SuperWithoutArgumentsTransformer()
    visitor = t.visit(node)
    assert visitor is not None
    assert len(node.args) == 2

# Generated at 2022-06-21 18:10:00.871982
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node


# Generated at 2022-06-21 18:10:06.904532
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class Cls(object):
            def __init__(self):
                super()
    '''
    tree = ast.parse(code)
    to_3_3(tree)

    assert 'super(Cls, self)' in dump_ast(tree)
    assert 'super(Cls, cls)' not in dump_ast(tree)

# Generated at 2022-06-21 18:10:13.944632
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast

    ast_tree = source_to_ast("""
    class A:
        def func(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast_tree)

    assert str(ast_tree) == source_to_ast("""
    class A:
        def func(self):
            super(A, self)
    """)

# Generated at 2022-06-21 18:10:20.593639
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_python


# Generated at 2022-06-21 18:10:30.796302
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """class A(object):
        def __init__(self):
            super()"""
    tree = ast.parse(code, mode="exec")
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    compiled = compile(tree, filename="<test>", mode="exec")
    output = ""
    exec(compiled, {"__name__": "__main__", "__file__": "<test>"}, {"output": output})
    assert output == ""
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 5:
        code += """class B(object, metaclass=type):
    def __new__(cls):
        super()"""
        tree = ast.parse(code, mode="exec")
        t = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-21 18:10:40.262191
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    module = ast.parse("super()")

    class SuperWithoutArgumentsTransformerSub(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:  # type: ignore
            node.args.insert(0, ast.Str(s='Ast'))
            node.args.append(ast.Str(s='Super without arguments'))

    SuperWithoutArgumentsTransformerSub(module).run()
    assert module.body[0].value.args[0].s == 'Ast'  # type: ignore


# Generated at 2022-06-21 18:10:46.262044
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
    class A(object):
        def foo(self):
        super()
    """
    expected_code = """
    class A(object):
        def foo(self):
            super(A, self)
    """
    node = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(node, {})
    transformer.visit(node)
    expected = ast.parse(expected_code)  # type: ignore
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-21 18:10:58.121933
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = dedent('''\
        class A:
            def __init__(self):
                super()''')

# Generated at 2022-06-21 18:10:58.657127
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:11:05.636636
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import get_ast
    root = get_ast('''
        class Foo(object):
            def bar(self):
                super()
                class Bar(object):
                    def baz(self):
                        super()
    ''')
    SuperWithoutArgumentsTransformer(root).run()
    assert [node.lineno for node in ast.walk(root) if isinstance(node, ast.Name)] == [3, 8, 10, 10]  # type: ignore

# Generated at 2022-06-21 18:11:13.367787
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .. import compile_php, compile_to_ast

    class SampleTransformer(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'method':
                node.func.id = 'func'
                self._tree_changed = True
            return node

    code1 = source_to_unicode('''
    class Cls():
        def method(self):
            super()
    ''')
    tree1 = compile_to_ast(code1, parser='auto')

    SampleTransformer(tree1).run()

# Generated at 2022-06-21 18:11:15.250762
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import parse


# Generated at 2022-06-21 18:11:23.267134
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..unicode_literals_transformer import UnicodeLiteralsTransformer
    from ..function_annotations_transformer import FunctionAnnotationsTransformer
    from ..absolute_import_transformer import AbsoluteImportTransformer

    transformer = FunctionAnnotationsTransformer()
    code = """"""
    tree = ast.parse(code)
    transformer.visit(tree)
    transformer = UnicodeLiteralsTransformer()
    transformer.visit(tree)
    transformer = AbsoluteImportTransformer()
    transformer.visit(tree)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)



# Generated at 2022-06-21 18:11:37.466492
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.parser.parser import parse
    from ..utils.parser.source_code import SourceCode
    from .base import NodeTransformer

# Generated at 2022-06-21 18:11:44.267828
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from ..utils.test_utils import assert_transform
    from ..utils.tree import build_ast

    code = dedent("""
    class C(object):
        def f(self):
            super()
    """)
    expected_code = dedent("""
    class C(object):
        def f(self):
            super(C, self)
    """)
    tree = build_ast(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_transform(expected_code, tree)

    code = dedent("""
    class C(object):
        def f(self):
            super()

        @classmethod
        def g(cls):
            super()
    """)

# Generated at 2022-06-21 18:11:53.368334
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Compile the following code:
    #     class A:
    #         def foo(self):
    #             super().do()
    code = ast.parse("class A:\n def foo(self):\n super().do()")
    tree = SuperWithoutArgumentsTransformer().visit(code)

    # Check that we have
    #     class A:
    #         def foo(self):
    #             super(A, self).do()
    assert ast.dump(tree) == ast.dump(ast.parse("class A:\n def foo(self):\n super(A, self).do()"))


# Generated at 2022-06-21 18:11:53.905208
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-21 18:11:54.887688
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:05.959350
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    
    # Example 1:
    input_src = '''
        class Vehicle:

            def __init__(self, model, year):
                self.model = model
                self.year = year
        
            def start(self):
                print('Engine starting')

            def stop(self):
                print('Engine stopping')

        class Car(Vehicle):
            
            
            def __init__(self, model, year):
                super().__init__(model, year)

            def start(self):
                super().start()
                print('Car starting')

    '''


# Generated at 2022-06-21 18:12:07.914916
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u


# Generated at 2022-06-21 18:12:15.837479
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .._compat import source_to_unicode
    from ..utils.helpers import get_ast_node

    transformer = SuperWithoutArgumentsTransformer()

    tree = get_ast_node("""
        class A(object):
            def a(self):
                super()
    """)

    transformer.visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A(object):
            def a(self):
                super(A, self)
    """)

    tree = get_ast_node("""
        class A(object):
            def a(self):
                super()
            @classmethod
            def b(cls):
                super()
    """)

    transformer.visit(tree)

# Generated at 2022-06-21 18:12:16.413248
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:19.902500
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_str
    assert compile_str('super()', (2, 7), __debug__, {}, '<test>', 'exec', SuperWithoutArgumentsTransformer).strip() == 'super(__class__, self)'

# Generated at 2022-06-21 18:12:53.049179
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.helpers import assert_source_equal
    
    src = '''\
    class A:
        def a(self):
            super()
    '''
    
    expected_src = '''\
    class A:
        def a(self):
            super(A, self)
    '''
    
    nodes = source_to_nodes(src)
    node = nodes[0]
    assert isinstance(node, ast.ClassDef)
    
    transformer = SuperWithoutArgumentsTransformer()
    res = transformer.visit(node)
    assert_source_equal(ast.fix_missing_locations(res), expected_src)

# Generated at 2022-06-21 18:12:53.912642
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:12:57.368620
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ...testing.utils import assert_transformation, load_example_module
    from ...state import _module_state

    assert_transformation(
        SuperWithoutArgumentsTransformer,
        load_example_module("super_without_arguments")
    )
    _module_state.cleanup()

# Generated at 2022-06-21 18:12:58.138412
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:13:09.098528
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer."""

    # Simple case
    tree = ast.parse('super().foo()')  # type: ignore
    loop_transformer = SuperWithoutArgumentsTransformer()
    new_tree = loop_transformer.visit(tree)  # type: ignore
    expected_tree = ast.parse('super(Cls, self).foo()')  # type: ignore
    assert ast.dump(new_tree) == ast.dump(expected_tree)

    # Complex case
    tree = ast.parse('foo.super().foo()')  # type: ignore
    loop_transformer = SuperWithoutArgumentsTransformer()
    new_tree = loop_transformer.visit(tree)  # type: ignore

# Generated at 2022-06-21 18:13:10.000486
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor


# Generated at 2022-06-21 18:13:15.276176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import refactor
    code = """
        class A: 
            def f(self): pass
        class B(A):
            def f(self):
                super()   
    """
    tree = refactor(code, SuperWithoutArgumentsTransformer)
    assert str(tree).strip() == """\
        class A: 
            def f(self): pass
        class B(A):
            def f(self):
                super(B, self)
    """

# Generated at 2022-06-21 18:13:16.965688
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3

# Generated at 2022-06-21 18:13:26.061303
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    code = """class MyClass():
        def __init__(self):
            super()
    """
    # Stage 1: Build AST
    module = ast.parse(code)
    # Stage 2: Transform
    SuperWithoutArgumentsTransformer().visit(module)  # pragma: no cover
    # Stage 3: Get modified code back into Python syntax
    res = astor.to_source(module)  # pragma:  no cover
    print(res)
    assert res.strip() == """class MyClass():
    def __init__(self):
        super(MyClass, self)""".strip()

# Generated at 2022-06-21 18:13:28.642370
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import set_parent_nodes

    transformer = SuperWithoutArgumentsTransformer(None)

# Generated at 2022-06-21 18:14:20.052080
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(None)


# Generated at 2022-06-21 18:14:27.599434
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that SuperWithoutArgumentsTransformer transforms super() to super(cls, self)"""
    code = 'super()'
    expected_code = 'super(cls, self)'
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    execute_code = compile(tree, '<string>', 'exec')
    namespace = {}
    exec(execute_code, namespace, namespace)
    assert namespace['super'].__name__ == expected_code

# Generated at 2022-06-21 18:14:30.493784
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ... import ast_transformer
    tree = ast_transformer(
        """
        def func(self):
            super()
        """
        , 'SuperWithoutArgumentsTransformer'
    )

# Generated at 2022-06-21 18:14:37.767427
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]
    transformer = SuperWithoutArgumentsTransformer(ast.parse('class Cls:\n def f():\n self\n super()'))
    assert transformer.visit(node) == ast.parse('super(Cls, self)').body[0]
    assert transformer.tree == ast.parse('class Cls:\n def f():\n self\n super(Cls, self)')

    node = ast.parse('super(Cls, self)').body[0]
    transformer = SuperWithoutArgumentsTransformer(ast.parse('class Cls:\n def f():\n self\n super(Cls, self)'))
    assert transformer.visit(node) == ast.parse('super(Cls, self)').body[0]

# Generated at 2022-06-21 18:14:43.543999
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_node
    from ..utils.compare_ast import compare_ast

    source = """if super():
    pass"""

    transpiled_code = """if super(__class__, self):
    pass"""

    expected_ast = source_to_node(transpiled_code)
    node = source_to_node(source)
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert compare_ast(node, expected_ast)

# Generated at 2022-06-21 18:14:44.385704
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:14:46.171688
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    sys.path.insert(0, '../')
    from compiler.transformer.tree import ast_tree

# Generated at 2022-06-21 18:14:48.652404
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .tools import parse_and_transform
    

# Generated at 2022-06-21 18:15:00.103790
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.fake_context import FakeContext

    class DummyNodeTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    transformer = SuperWithoutArgumentsTransformer(tree=ast.parse('super()'), ctx=FakeContext())
    try:
        assert transformer._replace_super_args(ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)) == None
    except Exception as e:
        raise e
    except:
        assert False, 'Unexpected exception was raised'

    # Unit test for visit of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:15:08.302290
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():                                                                                                         # noqa: E501
    from ..utils.pyversion import PythonVersion
    from ..utils.helpers import get_ast

    node = get_ast("super()").body[0].value                                                                                                                     # noqa: E501
    transformer = SuperWithoutArgumentsTransformer(PythonVersion(2, 7), get_ast("class A: pass"))                                                               # noqa: E501
    node = transformer.visit(node)                                                                                                                              # noqa: E501
    assert node.args[0].id == 'A'                                                                                                                                # noqa: E501
    assert isinstance(node.args[1], ast.Name)                                                                                                                    # noqa: E501

# Generated at 2022-06-21 18:16:54.291822
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
    '''
    module = ast.parse(code)
    refactored = SuperWithoutArgumentsTransformer().visit(module)
    expected = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
    assert ast.dump(refactored) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 18:16:56.025826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing import generate_transformer_test
    return generate_transformer_test(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-21 18:17:02.134598
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    p = SuperWithoutArgumentsTransformer()
    p._tree = ast.parse("super()")
    p.visit(p._tree)

    assert p._tree_changed
    assert ast.dump(p._tree, annotate_fields=False) == 'Module(body=[Expr(value=Call(func=Name(id=super), args=[Name(id=Cls), Name(id=self)], keywords=[]))])'

# Generated at 2022-06-21 18:17:07.693426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    # testing for raising the super() to super(Cls, self)
    code = '''
        class A:
            def method(self):
                super()
        '''
    tree = ast3.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True
    assert transformer._tree.body[0].body[0].name == "method"
    assert transformer._tree.body[0].body[0].decorator_list == []
    assert transformer._tree.body[0].body[0].body[0].value.args[1].id == "self"

# Generated at 2022-06-21 18:17:12.787989
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """SuperWithoutArgumentsTransformer(ast.parse('super()')) should be ast.parse('super(Cls, self)')"""
    test_code = 'super()'
    expected_code = 'super(Cls, self)'
    tree = ast.parse(test_code)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)

    # Check that the resulting AST compiles
    codeob = compile(tree, '<test>', 'exec')
    exec(codeob, {}, {})

    assert astor.to_source(tree).strip() == expected_code

# Generated at 2022-06-21 18:17:13.670160
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:25.028967
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from typed_ast.ast3 import parse

    test_ast = parse(u('''
        class B:
            def __init__(self):
                super(B, self).__init__()
    '''))

    node = test_ast.body[0]
    assert isinstance(node, ast.ClassDef)

    node = node.body[0]
    assert isinstance(node, ast.FunctionDef)

    node = node.body[0]
    assert isinstance(node, ast.Expr)

    node = node.value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Attribute)
    assert isinstance(node.func.value, ast.Call)

# Generated at 2022-06-21 18:17:30.792820
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast

    code = '''
        def test(self):
            super()
        '''
    tree = compile_to_ast(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    node = tree.body[0].body[0]
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2

# Generated at 2022-06-21 18:17:31.793662
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-21 18:17:32.757098
# Unit test for constructor of class SuperWithoutArgumentsTransformer