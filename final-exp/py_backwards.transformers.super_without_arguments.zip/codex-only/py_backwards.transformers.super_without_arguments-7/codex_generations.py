

# Generated at 2022-06-23 23:10:30.992910
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    from ..utils.source import Source
    from ..transformers import SuperWithoutArgumentsTransformer, ClassMethodsTransformer

    source = Source('''
        def foo(self):
            super()
    ''')

    module_node = ast.parse(source.text)
    SuperWithoutArgumentsTransformer(module_node, source).visit(module_node)
    ClassMethodsTransformer(module_node, source).visit(module_node)

    returned_ast = ''
    sys.stdout = open(os.devnull, 'w')  # This line is to stop print statement from appearing in returned_ast
    ast.fix_missing_locations(module_node)
    returned_ast = ast.unparse(module_node, '', '', include_attributes=False)

# Generated at 2022-06-23 23:10:32.207607
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(None, None).target == (2, 7)

# Generated at 2022-06-23 23:10:39.764878
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    source = """
    class Foo:
        def __init__(self):
            super()
        def __new__(cls):
            super()
    """
    expected = """
    class Foo:
        def __init__(self):
            super(Foo, self)
        def __new__(cls):
            super(Foo, cls)
    """
    tree = ast3.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, '<test>', 'exec')
    assert expected == result.co_consts[0]

# Generated at 2022-06-23 23:10:43.199235
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_transformation
    from ..utils.testing import generate_visitor_test
    from typed_ast import ast3 as ast

    assert_transformation(
        SuperWithoutArgumentsTransformer,
        generate_visitor_test(ast.Call)
    )

# Generated at 2022-06-23 23:10:49.612338
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseTreeTransformerTestCase

    class TestSuperWithoutArgumentsTransformer(
        BaseTreeTransformerTestCase
    ):
        def test_super_without_arguments_inside_function(self):
            before = '''
            class Foo:
                def __init__(self):
                    super()
            '''
            after = '''
            class Foo:
                def __init__(self):
                    super(Foo, self)
            '''
            self.assertTransformedAstEqual(before, after, 2)


# Generated at 2022-06-23 23:10:59.423970
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('''
    class Cls:
        def method(self):
            super()
    ''')
    rn = SuperWithoutArgumentsTransformer(tree)
    rn.visit(tree)


# Generated at 2022-06-23 23:11:00.260071
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    import os


# Generated at 2022-06-23 23:11:05.987417
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""
    source = """
    class Foo:
        def __init__(self):
            super().__init__()
    """
    expected = """
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert expected == astor.to_source(tree)

# Generated at 2022-06-23 23:11:11.980267
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import assert_code_equal, assert_tree_equal
    from ..testing import make_fixture_tree
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 23:11:19.501352
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    # test transforming super()
    tree = ast.parse("super()")
    t.visit(tree)
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert isinstance(tree.body[0].value.args[1], ast.Name)
    assert tree.body[0].value.args[1].id == 'self'

    # test super() inside of a class

# Generated at 2022-06-23 23:11:22.341953
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import get_ast

    code = 'super()'
    tree = get_ast(code, SuperWithoutArgumentsTransformer)
    assert tree.body[0].value.args[0].id == "Cls"
    assert tree.body[0].value.args[1].id == "self"

# Generated at 2022-06-23 23:11:31.187439
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Statement: super()
    node1 = ast.Call()
    node1.func = ast.Name()
    node1.func.id = 'super'
    node1.func.ctx = ast.Load()
    node1.args = []

    # Tree
    tree1 = ast.Module()
    tree1.body = []
    tree1.body.append(node1)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree1)
    assert tree1.body[0].args[0].id == 'Cls'
    assert tree1.body[0].args[1].id == 'self'

# Generated at 2022-06-23 23:11:41.302129
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    class_ = node.body[0]
    assert isinstance(class_, ast.Expr)
    node = class_.value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not len(node.args)
    SuperWithoutArgumentsTransformer(node).visit_Call(node)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'C'
    assert isinstance(node.args[1], ast.Name)

# Generated at 2022-06-23 23:11:41.998524
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:47.805520
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Test that the constructor for SuperWithoutArgumentsTransformer raises
    a TypeError if the version arg is not a tuple.
    """
    # Try with a list
    with pytest.raises(TypeError):
        _ = SuperWithoutArgumentsTransformer([1, 7])


# Generated at 2022-06-23 23:11:53.571064
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(Cls, self)' == ast.dump(tree)

    tree = ast.parse('cls.super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'cls.super(Cls, cls)' == ast.dump(tree)



# Generated at 2022-06-23 23:12:04.347776
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import parse

    code = (
        'class A:\n'
        ' def __init__(self):\n'
        '  super()\n'
        '  super()\n'
        '  super(A, self)\n'
        '  super(A)\n'
    )

    expected = (
        'class A:\n'
        ' def __init__(self):\n'
        '  super(A, self)\n'
        '  super(A, self)\n'
        '  super(A, self)\n'
        '  super(A)\n'
    )

    tree = parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert_code_equal(str(tree), expected)

# Generated at 2022-06-23 23:12:09.391455
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
        class A:
            def method1(self):
                super()
            def method2(self):
                super(A, self)
            def method3(self):
                super(self)
            def method4(self):
                super(self, A)
            def method5(self):
                super("abc")
            def method6(self):
                super("abc", "def")
        """)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-23 23:12:12.568531
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.code_generation import SourceGenerator


# Generated at 2022-06-23 23:12:17.645634
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Code to test
    code = """\
    class A:
        def __init__(self):
            super()
    """
    # Expected output
    output = """\
    class A:
        def __init__(self):
            super(A, self)
    """

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))
    assert output == t.result()

# Generated at 2022-06-23 23:12:19.546192
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_first_of_type


# Generated at 2022-06-23 23:12:22.632824
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Foo():
        def bar():
            super()
    """


# Generated at 2022-06-23 23:12:23.592605
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-23 23:12:24.561841
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:28.512477
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test that the function visit_Call visit all ast.Call nodes."""
    from . import clean_ast

    t = ast.parse("""class A:
    def __init__(self):
        super()""")
    node = t.body[0].body[0]
    node = SuperWithoutArgumentsTransformer().visit(node)
    expected = clean_ast.parse("""class A:
    def __init__(self):
        super(A, self)""")
    assert clean_ast.dump(node) == clean_ast.dump(expected)



# Generated at 2022-06-23 23:12:31.612104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transform = SuperWithoutArgumentsTransformer()
    program = parse('super()') # type: ignore
    transform.visit(program)
    assert str(program) == 'super(__module__, cls)'
    # TODO: fix this test

# Generated at 2022-06-23 23:12:32.125453
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:12:42.391459
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import as_tuple

    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)
    cls = ast.ClassDef(name='C', bases=[], keywords=[], starargs=None, kwargs=None, body=[], decorator_list=[])
    func = ast.FunctionDef(name='f', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)],
                                                        vararg=None, kwarg=None, defaults=[]),
                           body=[node], decorator_list=[], returns=None)
    cls.body.append(func)

    trans = SuperWithoutArgumentsTransformer()
    trans.visit(cls)


# Generated at 2022-06-23 23:12:51.257215
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import BufferTestCase
    from typed_ast import ast3

    class Test(BufferTestCase):
        target_version = (2, 7)
        transformer = SuperWithoutArgumentsTransformer

        def test_super_outside_function(self) -> None:
            snippet = """
                super()
            """
            desired = """
                super(__class__, self)
            """
            self.assertCodeTransformation(snippet, desired)

        def test_super_outside_class(self) -> None:
            snippet = """
                def foo():
                    super()
            """
            desired = """
                def foo():
                    super(__class__, self)
            """
            self.assertCodeTransformation(snippet, desired)


# Generated at 2022-06-23 23:12:53.469474
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    global my_testcase

    # test case 1

# Generated at 2022-06-23 23:13:04.706510
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import generate_test_case_from_func
    from ..exceptions import Arian
    from ..utils.ast_transformer import AstTransformer
    from ..utils.helpers import render_ast
    from asttokens import ASTTokens
    from typing import cast
    from astunparse import unparse

    def a_function():
        class A:
            def method(self):
                super().method()

        class B(A):
            def method(self):
                super().method()

    ast_transformer = AstTransformer(SuperWithoutArgumentsTransformer)
    with Arian(ast_transformer=ast_transformer) as fake:
        a_function()

    generator = generate_test_case_from_func(a_function, transformer=ast_transformer)


# Generated at 2022-06-23 23:13:16.068461
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    code = dedent("""
    class Foo(object):
        def bar(self):
            super()
    """)
    keywords = dict(
        ClassDef=ast.ClassDef,
        FunctionDef=ast.FunctionDef,
        Call=ast.Call,
        Name=ast.Name,
    )
    tree = parse(code, mode='exec', feature_version=transformer.target)
    tree = transformer.visit(tree, initialize=True)

# Generated at 2022-06-23 23:13:26.024891
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
    class Foo:
        def f(self):
            bar()
            baz()
    '''
    tree = ast.parse(code)
    transf = SuperWithoutArgumentsTransformer(tree)
    transf.visit(tree)

# Generated at 2022-06-23 23:13:26.420242
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:27.989520
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:13:29.791271
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  from ..utils.source import source_to_code_object, source_to_ast

# Generated at 2022-06-23 23:13:39.170183
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import compileto

    source = """
        class MyClass:
            def method(self):
                super()
    """
    expected = """
        class MyClass:
            def method(self):
                super(MyClass, self)
    """
    assert compileto(source, SuperWithoutArgumentsTransformer) == expected

    source = """
        class MyClass:
            def method(self):
                super().method()
    """
    expected = """
        class MyClass:
            def method(self):
                super(MyClass, self).method()
    """
    assert compileto(source, SuperWithoutArgumentsTransformer) == expected

    source = """
        class MyClass:
            def method(self):
                return super()
    """

# Generated at 2022-06-23 23:13:40.982940
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert (ast.parse("super()").body[0]) == (SuperWithoutArgumentsTransformer(ast.parse("super()")).tree.body[0])

# Generated at 2022-06-23 23:13:42.521359
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(ast.dump(tree), str)

# Generated at 2022-06-23 23:13:46.901379
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import cst_to_ast
    from ..utils.test_utils import get_test_cases
    from textwrap import dedent

    cases = get_test_cases('super_without_arguments')
    for case in cases:
        tree = cst_to_ast(dedent(case['code']))
        transformer = SuperWithoutArgumentsTransformer(tree)
        transformer.run()
        assert dedent(case['expected_code']).strip() == astor.to_source(tree).strip()

# Generated at 2022-06-23 23:13:49.721577
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import run_local_tests

    tests = [
        ('super()', 'super(Cls, self)'),
        ('self.super()', 'self.super(Cls, self)'),
        ('super(foo)', 'super(foo)'),
        ('super(foo, *args)', 'super(foo, *args)'),
    ]


# Generated at 2022-06-23 23:13:55.851943
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    node = ast3.parse('super()')
    assert (isinstance(node, ast3.Module))
    node = node.body[0]
    assert (isinstance(node, ast3.Expr))
    node = node.value
    assert (isinstance(node, ast3.Call))
    node = node.func
    assert (isinstance(node, ast3.Name))
    assert (node.id == 'super')

# Generated at 2022-06-23 23:13:57.298272
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_astunparse

# Generated at 2022-06-23 23:14:00.913021
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as _ast
    from typed_ast.ast3 import parse
    from ..utils.ast_builder import ast_from_str, ast_to_str
    from ..utils.helpers import get_first_of_type_from_ast


# Generated at 2022-06-23 23:14:05.413641
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:10.904387
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls:
        def __init__(self):
            super().__init__()

        @classmethod
        def method(cls):
            super().method()

        @staticmethod
        def method2():
            super().method2()

        def method3():
            super().method3()
    """
    expected_code = """
    class Cls:
        def __init__(self):
            super(Cls, self).__init__()

        @classmethod
        def method(cls):
            super(Cls, cls).method()

        @staticmethod
        def method2():
            super(Cls, cls).method2()

        def method3():
            super().method3()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTrans

# Generated at 2022-06-23 23:14:11.796963
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:15.218758
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer(ast.Module(body=[])).visit_Module(node) # type: ignore
    assert node == ast.parse('super(Cls, self)')

# Generated at 2022-06-23 23:14:25.511935
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import copy
    import sys

    if sys.version_info < (3, 8):
        from typing import get_type_hints
    else:
        from typing import get_origin, get_args

    from typed_ast import ast3 as typed_ast

    from typed_astunparse import unparse
    from typed_astunparse.unparser import Unparser

    from typed_python import ast3 as typed_python
    from typed_python.compiler.type_annotation.rules import SuperWithoutArgumentsTransformer

    def foo():
        super()

    class A:
        def bar(self):
            super()

    class B(A):
        def bar(self):
            super()

    class C(A):
        def baz(cls):
            super()


# Generated at 2022-06-23 23:14:29.485629
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    print(ast.dump(tree))
    SuperWithoutArgumentsTransformer().visit(tree)
    print(ast.dump(tree))
    expected_output = "Module(body=[Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"
    assert(ast.dump(tree) == expected_output)


# Generated at 2022-06-23 23:14:31.073125
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import normalize_ast, should_transform_to


# Generated at 2022-06-23 23:14:33.846997
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor, typing
    if not typing.TYPE_CHECKING:
        from ..utils.code_gen import cst_to_ast


# Generated at 2022-06-23 23:14:36.550157
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import _ast as ast
    from typed_ast import ast3 as typed_ast
    from ..utils import dump


# Generated at 2022-06-23 23:14:38.950903
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer(ast.parse('super()'), {})
    assert t.result() == ast.parse('super(C, self)')



# Generated at 2022-06-23 23:14:45.462865
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    from ..utils.helpers import run_on_lines

    s = Source("""
    super()
    super(Cls)
    super(Cls, self)
    """)
    tree = run_on_lines(s, SuperWithoutArgumentsTransformer)
    ns = Source("""
    super(Cls, self)
    super(Cls)
    super(Cls, self)
    """)
    assert tree == ns.tree

# Generated at 2022-06-23 23:14:54.316805
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..mini_lambda import compile_to_ast as to_ast
    from textwrap import dedent

    tests = {
        "super()":
            'super(Cls, self)',
        "super(Cls, super())":
            'super(Cls, cls)',
        "super(super()).func()":
            'super(self).func()',
        "super(super()).func(super())":
            'super(self).func(self)',
    }
    for source, expect in tests.items():
        group = dedent('''
        class Cls:
            def func():
                @add_method
                def method(self):
                    {}
        ''').format(source)
        tree = to_ast(group)
        tree = SuperWithoutArgumentsTransformer(tree).visit

# Generated at 2022-06-23 23:15:04.375344
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse(
        """
foo()
    def foo():super()
    class bar:
        def baz(self):super()
        @classmethod
        def boing(cls):super()
    @classmethod
    def qux(cls):super()

""")

    result = ast.dump(SuperWithoutArgumentsTransformer(tree, None).visit(tree))


# Generated at 2022-06-23 23:15:05.800164
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from .test_generator import generate_code_str

# Generated at 2022-06-23 23:15:16.098054
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .. import transforms
    from ..utils.helpers import get_ast, compile_func

    source = '''
    class Cls:
        def __init__(self):
            super()
    '''
    tree = get_ast(source)
    transformer = transforms.SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert compile_func(tree)

    source = '''
    class Cls:
        @classmethod
        def __init__(cls):
            super()
    '''
    tree = get_ast(source)
    transformer = transforms.SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert compile_func(tree)


# Generated at 2022-06-23 23:15:25.751262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Ensure that SuperWithoutArgumentsTransformer creates the correct AST with no arguments"""
    super_noargs = ast.parse(
        'class Foo:\n'
        '    def __init__(self):\n'
        '        super()\n'
    )
    tree = SuperWithoutArgumentsTransformer().visit(super_noargs)

# Generated at 2022-06-23 23:15:32.093784
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .. import compile_src
    from .helpers import assert_equal_ignore_whitespace

    src = """
        class Foo(object):
            def baz(self):
                super()
    """

    expected = """
        class Foo(object):
            def baz(self):
                super(Foo, self)
    """
    tree = compile_src(source_to_unicode(src), 2, 7)
    d = SuperWithoutArgumentsTransformer()
    d.visit(tree)
    assert_equal_ignore_whitespace(expected, compile_src(tree, 2, 7))


# Generated at 2022-06-23 23:15:38.303431
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    program = '''
        class Foo(object):
            def __init__(self):
                super()
                pass

        class Bar(object):
            def __init__(self):
                super().__init__()
                pass
    '''
    tree = ast.parse(program)
    SuperWithoutArgumentsTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-23 23:15:39.249551
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:41.356676
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .test_helpers import get_node

    # py2

# Generated at 2022-06-23 23:15:42.311254
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:44.180797
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .basic import BasicTransformer

# Generated at 2022-06-23 23:15:53.226361
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_constructor(self):
            tree = ast.parse("super()\nclass X: pass")
            tree = SuperWithoutArgumentsTransformer().visit(tree)
            self.assertEqual(ast.dump(tree),
                             "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='X', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None)), ClassDef(name='X', bases=[], keywords=[], body=[Pass()], decorator_list=[])])")

# Generated at 2022-06-23 23:15:59.825644
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assertASTEqual

    # function def

# Generated at 2022-06-23 23:16:03.764330
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import ast

    from ..transformers.super_without_arguments import SuperWithoutArgumentsTransformer


# Generated at 2022-06-23 23:16:04.735468
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:05.349713
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:06.334203
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:06.886503
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:16:08.719633
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import transform
    from ..utils.helpers import get_ast


# Generated at 2022-06-23 23:16:17.648952
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..six import StringIO

    class Output(object):
        def __init__(self):
            self.out = StringIO()

    output = Output()

    class Foo(object):
        def __init__(self):
            self._tree_changed = False

        def generic_visit(self, node):
            ast.NodeVisitor.generic_visit(self, node)
            return node

    class TestSuite(object):
        def run(self, result=None):
            if result:
                pass
            self._tree_changed = True

    visitor = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-23 23:16:25.547325
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
            class A:
                def m(self):
                    super()
                                
        """)  # type: ast.AST
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:16:35.803366
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input = """
    class Foo(object):
        def __init__(self):
            super().__init__() # comment
            
        def bar(self, something):
            super().bar(something)
            
    def something():
        super().__init__()
        
    class Bar(object):
        def __init__(self, something):
            super(Bar, self).__init__()
    """

# Generated at 2022-06-23 23:16:41.620901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    node = compile_to_ast("""
        class Test:
            def test(self):
                super()
    """)
    SuperWithoutArgumentsTransformer().visit(node)
    assert isequal(node, """
        class Test:
            def test(self):
                super(Test, self)
    """)



# Generated at 2022-06-23 23:16:43.562770
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:16:44.184763
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:49.624532
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # We test if the super() calls are being replaced with the proper syntax
    from .test_base import BaseTestTransformer, NodeTestCase

    class TestTransformer(SuperWithoutArgumentsTransformer, BaseTestTransformer):
        pass


# Generated at 2022-06-23 23:16:56.385291
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astor import to_source
    from textwrap import dedent

    from ..utils.fake_context import FakeContext
    from ..utils.source import split_lines
    from ..utils.helpers import unindent

    context = FakeContext()

    code = dedent(r'''
    class Cls:
        def __init__(self):
            self.var = super()
    ''')

    expected = dedent(r'''
    class Cls:
        def __init__(self):
            self.var = super(Cls, self)
    ''')

    tree = ast.parse(code)

    node_transformer = SuperWithoutArgumentsTransformer(tree, context)
    node_transformer.visit(tree)

    assert to_source(tree) == expected

# Generated at 2022-06-23 23:17:01.919634
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .ast_helper import compile_to_ast
    code = """
super()
"""
    module = compile_to_ast(code)

    foo = module.body[0]

    assert isinstance(foo, ast.Expr)
    assert isinstance(foo.value, ast.Call)
    assert isinstance(foo.value.func, ast.Name)

# Generated at 2022-06-23 23:17:08.621763
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_node

    code = 'super()'
    expected = 'super(Cls, self)'

    node = ast.parse(code)  # type: ignore
    visitor = SuperWithoutArgumentsTransformer(tree=node)
    visitor.visit(node)
    actual = ast.fix_missing_locations(visitor.tree)  # type: ignore
    actual = ast.unparse(actual)

    assert_node(actual, expected)

# Generated at 2022-06-23 23:17:09.604992
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile

# Generated at 2022-06-23 23:17:10.588659
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:12.037538
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:20.430645
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_code_equal

    code_test_module = """
        class SomeClass:
            def __init__(self):
                super()
    """

    code_expected_module = """
        class SomeClass:
            def __init__(self):
                super(SomeClass, self)
    """

    code_test_module_class = """
        class SomeClass:
            def __init__(self):
                super()
    """

    code_expected_module_class = """
        class SomeClass:
            def __init__(self):
                super(SomeClass, self)
    """

    ast_module = ast.parse(code_test_module)
    ast_module_class = ast.parse(code_test_module_class)


# Generated at 2022-06-23 23:17:29.639345
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    target = (2, 7)

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return

            try:
                cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
            except NodeNotFound:
                warn('super() outside of class')
                return

            node.args = [ast.Name(id=cls.name), ast.Name(id=func.args.args[0].arg)]


# Generated at 2022-06-23 23:17:37.590907
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_transformer, ast_equal
    t = SuperWithoutArgumentsTransformer()

    code_before = '''
    class MyClass:
        def __init__(self):
            super()
    '''

    code_after = '''
    class MyClass:
        def __init__(self):
            super(MyClass, self)
    '''

    tree_before = ast.parse(code_before)
    tree_after = ast.parse(code_after)

    run_transformer(t, tree_before)
    assert ast_equal(tree_before, tree_after)

# Generated at 2022-06-23 23:17:44.857955
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Input:
    input = """
    class X:
        def x(self):
            super()
    """
    tree = ast.parse(input)
    node = tree.body[0].body[0].body[0].value

    # Run the transformer:
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    # Check the result:
    assert_equal(
        dump_tree(node),
        dump_tree(ast.Call(
            func=ast.Name(id='super'),
            args=[ast.Name(id='X'), ast.Name(id='self')],
            keywords=[]
        ))
    )

# Generated at 2022-06-23 23:17:50.446118
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]
    transformer = SuperWithoutArgumentsTransformer()
    result = transformer.visit(node)
    expected = ast.parse("""
super(Cls, self)
super(Cls, cls)
""").body[0]
    assert result.__class__ is expected.__class__
    assert result.__dict__ == expected.__dict__

# Generated at 2022-06-23 23:17:56.023838
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    import astor  # type: ignore

    node = astor.parse_file('tests/samples/super_without_args.py')

    t = SuperWithoutArgumentsTransformer()
    t.visit(node)
    assert astor.to_source(node).strip() == 'class A(object):\n    def __init__(self):\n        super(A, self)'

# Generated at 2022-06-23 23:18:04.084719
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import parse
    from .to_target import to_target
    from ..utils.source import Source

    source = Source("""
    class A:
        def __init__(self):
            super()
        def f(self):
            super()
    """)
    tree = parse(source)
    to_target(tree, (2, 7))
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source.getvalue() == """
    class A:
        def __init__(self):
            super(A, self)

        def f(self):
            super(A, self)
    """

# Generated at 2022-06-23 23:18:05.498556
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:14.966552
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .common import CompilerTestCase

    class TestCase(CompilerTestCase):
        def test_not_replacing(self):
            code: str = 'super(Cls, self)'
            result: str = source_to_unicode(SuperWithoutArgumentsTransformer(code).result())
            self.assertCodeEqual(code, result)

        def test_replacing(self):
            code: str = '''
            class Cls:
                def func(self):
                    super()
            '''
            result: str = source_to_unicode(SuperWithoutArgumentsTransformer(code).result())

# Generated at 2022-06-23 23:18:23.371374
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_node_rewrite_assertions import assert_rewrite_result

    tree = TestVisitor().visit(ast.parse('''
        class Foo():
            def bar(self):
                super()
        class Foo2():
            def foo2(cls, a, b):
                super()
    '''))

    visitor = SuperWithoutArgumentsTransformer(tree)
    visitor.visit(tree)
    assert_rewrite_result(tree, '''
        class Foo():
            def bar(self):
                super(Foo, self)
        class Foo2():
            def foo2(cls, a, b):
                super(Foo2, cls)
    ''')

# Generated at 2022-06-23 23:18:33.590335
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake_ast import AstForTest
    from ..compiler import TreeCompiler
    import textwrap

    input = AstForTest.compiler.parse(textwrap.dedent('''
        class A(object):
            def bar(self):
                super().foo()
    '''))
    expected = AstForTest.compiler.parse(textwrap.dedent('''
        class A(object):
            def bar(self):
                super(A, self).foo()
    '''))

    tree_compiler = TreeCompiler()
    tree_compiler.compile_node(input)

    transformer = SuperWithoutArgumentsTransformer(tree_compiler._tree)
    transformer.visit(transformer.tree)

    assert expected == transformer.tree

# Generated at 2022-06-23 23:18:37.698120
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer() 
    """
        def method(self):
            super()
    """
    tree = ast.parse("""
        def method(self):
            super()  
    """)
    transformer.visit(tree)
    expected = """
        def method(self):
            super(self)  
    """
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 23:18:41.521842
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests the constructor of class SuperWithoutArgumentsTransformer."""
    my_class = SuperWithoutArgumentsTransformer()
    assert isinstance(my_class, BaseNodeTransformer)
    assert my_class.target[0] == 2
    assert my_class.target[1] == 7


# Generated at 2022-06-23 23:18:43.998358
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_utils import generate_visitor_test

    generate_visitor_test(SuperWithoutArgumentsTransformer, '_replace_super_args')

# Generated at 2022-06-23 23:18:51.786261
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.python_source import Source
    from typed_ast import ast3 as ast
    
    tree = ast.parse(Source("""
        class Test:
            def test(self):
                super()
            def test(cls):
                super()
    """))

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree == ast.parse(Source("""
        class Test:
            def test(self):
                super(Test, self)
            def test(cls):
                super(Test, cls)
    """))

# Generated at 2022-06-23 23:18:59.442745
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unittest_utils import assert_code_equal
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target_class = SuperWithoutArgumentsTransformer
        target_version = (2, 7)

        def test_transform(self):
            self.assert_transform(
                '''
                class Foo(object):

                    def func(self):
                        super()
                    def func(cls):
                        super()
    
                ''',
                '''
                class Foo(object):

                    def func(self):
                        super(Foo, self)
                    def func(cls):
                        super(Foo, cls)
    
                '''
            )

# Generated at 2022-06-23 23:19:02.265261
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test constructor of SuperWithoutArgumentsTransformer
    code = """super()"""
    tree = ast.parse(code)
    d = SuperWithoutArgumentsTransformer()
    tree = d.visit(tree)
    compiler.parse(compiler.ast_to_code(tree))

# Generated at 2022-06-23 23:19:03.125311
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:08.028823
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from textwrap import dedent
    source = dedent('''
        class A:
            def foo(self):
                super()
    ''')
    tree = ast3.parse(source)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    expected = dedent('''
        class A:
            def foo(self):
                super(A, self)
    ''').strip()
    assert ast3.dump(tree) == expected

# Generated at 2022-06-23 23:19:16.376115
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.example_code import NO_SELF_IN_SUPER_CALL_TREE
    from ..utils.example_code import NO_SELF_IN_SUPER_CALL_TRANSFORMED_TREE
    transformer = SuperWithoutArgumentsTransformer(NO_SELF_IN_SUPER_CALL_TREE)
    transformer.visit_Call(NO_SELF_IN_SUPER_CALL_TRANSFORMED_TREE.body[0].body[0])
    assert str(NO_SELF_IN_SUPER_CALL_TREE) == str(NO_SELF_IN_SUPER_CALL_TRANSFORMED_TREE)

# Generated at 2022-06-23 23:19:21.233171
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class ABC:
            def __init__(self):
                super()._init()
        '''

    expected_code = '''
        class ABC:
            def __init__(self):
                super(ABC, self)._init()
          '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, filename="<ast>", mode="exec")
    exec(result)

    tree = ast.parse(expected_code)
    result = compile(tree, filename="<ast>", mode="exec")
    exec(result)



# Generated at 2022-06-23 23:19:23.937065
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    T = SuperWithoutArgumentsTransformer.__name__
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree, include_attributes=False) == "{0}(super(Cls, cls))".format(T)

# Generated at 2022-06-23 23:19:33.897570
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..loader import load_module
    from ..utils.helpers import cst_to_ast

    module = load_module('test_data.super_without_arguments_transformer')
    sut = SuperWithoutArgumentsTransformer(tree=cst_to_ast(module))
    sut.visit(sut.tree)

    assert sut.tree.body[0].body[0].value.func.args[0].id == 'A'
    assert sut.tree.body[0].body[1].value.func.args[0].id == 'A'
    assert sut.tree.body[0].body[2].value.func.args[0].id == 'B'
    assert sut.tree.body[0].body[3].value.func.args[0].id == 'B'

# Generated at 2022-06-23 23:19:38.837487
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.tree_builder import build_ast

    tree = build_ast("""
    class A:
        def __init__(self):
            super().__init__()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree == build_ast("""
    class A:
        def __init__(self):
            super(A, self).__init__()
    """)

# Generated at 2022-06-23 23:19:44.535708
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import search_all_node

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node):
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-23 23:19:45.388230
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:51.367160
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
        class X():
            def fun(self):
                super()
    """

    tree = parse(code)
    SuperWithoutArgumentsTransformer(tree).run()

    assert format_ast(tree) == dedent("""\
        class X:
            def fun(self):
                super(X, self)
    """)



# Generated at 2022-06-23 23:19:53.403422
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    node = ast3.parse('super()')
    SuperWithoutArgumentsTransformer(None).visit(node)

# Generated at 2022-06-23 23:19:56.586764
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast2ast import compile_ast, compare_asts
    import astor


# Generated at 2022-06-23 23:20:04.036610
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse, dump
    from .base import BaseNodeTransformer
    class T(BaseNodeTransformer):
        target = (2, 7)
        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                try:
                    func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
                except NodeNotFound:
                    warn('super() outside of function')
                    return

                try:
                    cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
                except NodeNotFound:
                    warn('super() outside of class')
                    return


# Generated at 2022-06-23 23:20:05.077150
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:11.018924
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    edit = transformer.get_edited()
    assert edit[0]._fields == ('args', 'keywords', 'starargs', 'kwargs')
    assert (edit[0].args[0].id, edit[0].args[1].id) == ('Cls', 'self')

# Generated at 2022-06-23 23:20:12.583270
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..compile import compile_src


# Generated at 2022-06-23 23:20:14.112960
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:20:23.923916
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from typed_ast import ast27

    code = '''
    class A():
        def __init__(self):
            super()
    '''
    # expected output
    expected_code = '''
    class A():
        def __init__(self):
            super(A, self)
    '''
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    assert ast27.dump(new_node) == expected_code.strip('\n')
    assert transformer._tree_changed == True

