

# Generated at 2022-06-23 23:10:05.991588
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor


# Generated at 2022-06-23 23:10:06.746108
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:10.247396
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class A():
        def __init__(self):
            super()
    '''
    node = ast.parse(code)
    t = SuperWithoutArgumentsTransformer(node)
    t.visit(node)

# Generated at 2022-06-23 23:10:17.482931
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # set up source code and expected result
    src = """
        class Example:
            def __init__(self):
                super()
            def example(self):
                super()
        """
    exp = """
        class Example:
            def __init__(self):
                super(Example, self)
            def example(self):
                super(Example, self)
        """
    # parse and transform code
    module = ast.parse(src)
    SuperWithoutArgumentsTransformer().visit(module)
    # check transformed code
    assert ast.dump(module) == exp

# Generated at 2022-06-23 23:10:19.583450
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree=node).visit(node)
 
    assert str(node) == 'super(__, self)'

# Generated at 2022-06-23 23:10:22.084672
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    tester = SuperWithoutArgumentsTransformer()
    node = ast.parse("super()")
    tester.visit(node)

    assert astunparse.unparse(node) == "super(Cls, cls)"


# Generated at 2022-06-23 23:10:31.640255
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import get_node_name
    from ..utils.compat import get_filenames_from_dir
    from .unpacking import UnpackingTransformer

    for filename in get_filenames_from_dir('../tests/fixtures/super_transformer'):
        content = open(filename).read()
        tree = parse(content)
        SuperWithoutArgumentsTransformer().visit(tree)

        # See https://github.com/serge-sans-paille/python-modernize/issues/39
        UnpackingTransformer().visit(tree)

        exec(compile(tree, filename=filename, mode='exec'), {}, {})


# Generated at 2022-06-23 23:10:36.099876
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        ast.parse("super()")
    except SyntaxError:
        pass
    else:
        assert False
    assert ast.parse(
        "super()",
        feature_version=SuperWithoutArgumentsTransformer.target).body[0].value.args[1].id == "self"

# Generated at 2022-06-23 23:10:44.858374
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # 1. test with args -> returns node unchanged as it shouldn't be visited
    tree = ast.parse('super(1,2)')
    transformer = SuperWithoutArgumentsTransformer(tree)
    result = transformer.visit(tree)
    expected = ast.parse('super(1,2)')
    assert result == expected

    # 2. test without args but outside function -> returns node unchanged as it shouldn't be visited
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    result = transformer.visit(tree)
    expected = ast.parse('super()')
    assert result == expected
    
    # 3. test without args inside of a class but outside of a function -> returns node unchanged as it shouldn't be visited
    tree = ast.parse('class Cls:super()')
    transformer = Super

# Generated at 2022-06-23 23:10:47.523011
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List
    from typed_ast import ast3 as ast
    from ..utils.helpers import run_transformer_on_single_file


# Generated at 2022-06-23 23:10:58.083747
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assertCodeEqual(compile(tree, '', 'exec'), 'super(Cls, self)')

    tree = ast.parse('super().meth()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assertCodeEqual(compile(tree, '', 'exec'), 'super(Cls, self).meth()')

    tree = ast.parse('super().meth(a=1, b=2)')
    SuperWithoutArgumentsTransformer().visit(tree)
    assertCodeEqual(compile(tree, '', 'exec'), 'super(Cls, self).meth(a=1, b=2)')

    tree = ast.parse('super(A, self).meth()')


# Generated at 2022-06-23 23:11:05.987203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ...utils import ctx_to_str, node_copy

    tree = ast3.parse('class A:\n    def b(self):\n        super()')
    expected = ast3.parse('class A:\n    def b(self):\n        super(A, self)')

    SuperWithoutArgumentsTransformer(tree, {}).visit(tree)
    assert ctx_to_str(tree) == ctx_to_str(expected)

    tree = ast3.parse('class A:\n    @classmethod\n    def b(cls):\n        super()')
    expected = ast3.parse('class A:\n    @classmethod\n    def b(cls):\n        super(A, cls)')


# Generated at 2022-06-23 23:11:08.765694
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer_on_string
    from ..common import PYTHON_VERSION
    result = run_transformer_on_string('super()', SuperWithoutArgumentsTransformer)
    if PYTHON_VERSION == 2:
        assert result == 'super(Cls, self)'
    elif PYTHON_VERSION == 3:
        assert result == 'super(Cls, cls)'

# Generated at 2022-06-23 23:11:09.777370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast_preprocessor


# Generated at 2022-06-23 23:11:13.780172
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object
    from ..utils.helpers import get_tree
    from ..utils.tree import dump_tree


# Generated at 2022-06-23 23:11:14.366301
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:15.422811
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:24.585628
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Super(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id='cls'), ast.Name(id='self')]
            return self.generic_visit(node)  # type: ignore

    tree = ast.parse('class A(object):\n  def __init__(self):\n    super()')
    tree = Super().visit(tree)

# Generated at 2022-06-23 23:11:25.984184
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import parse


# Generated at 2022-06-23 23:11:36.969151
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:41.836556
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import compile_to_python, parse_to_ast, transform

    source = '''
x = super()
'''

    tree = parse_to_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    new_source = compile_to_python(tree)

    assert new_source == '''x = super(__name__, self)'''

# Generated at 2022-06-23 23:11:54.051863
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_ast
    assert_transformed_ast(
        SuperWithoutArgumentsTransformer,
        before="""
            class A:
                def __init__(self):
                    super()
            class B(A):
                def __init__(self):
                    super().__init__()
            class C(A):
                def __init__(self):
                    super().method()
        """,
        after="""
            class A:
                def __init__(self):
                    super(A, self)
            class B(A):
                def __init__(self):
                    super(A, self).__init__()
            class C(A):
                def __init__(self):
                    super(A, self).method()
        """
    )

# Generated at 2022-06-23 23:12:05.205551
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Given
    code = """
    class Cls:
        def method(self):
            super()
            
        @classmethod
        def clsm(cls):
            super()
    """
    expected_code = """
    class Cls:
        def method(self):
            super(Cls, self)
            
        @classmethod
        def clsm(cls):
            super(Cls, cls)
    """
    source_tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    # When
    node_transformer = SuperWithoutArgumentsTransformer(source_tree)
    node_transformer.visit(source_tree)
    actual_code = to_code(source_tree)
    actual_tree = ast.parse(actual_code)

    #

# Generated at 2022-06-23 23:12:08.738426
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    node = ast.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    node = astor.to_source(node)
    assert node == "super(Cls, self)"


# Generated at 2022-06-23 23:12:09.320058
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:13.612846
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None

    module = ast.parse('super()')
    with override_allowed_symbols(allowed_symbols(module, '2.7')):
        assert_equal(str(module), 'super(Cls, self)')



# Generated at 2022-06-23 23:12:15.822083
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object, code_object_to_ast

# Generated at 2022-06-23 23:12:16.712945
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:17.523216
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:12:27.676044
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from typed_ast import ast3 as ast
    from .. import utils
    from ..skip import SkipNode

    # When node.func.id == 'super' and not len(node.args)
    # Because node.func.id == 'super' is True, then the rest of the if statement is evaluated
    # Because not len(node.args) is True, then the body of the if statement is executed
    # The method _replace_super_args is executed
    # The method get_closest_parent_of is executed and doesn't raise any exceptions
    # The method get_closest_parent_of is executed and doesn't raise any exceptions
    # The method _replace_super_args is executed
    # The attribute _tree_changed is updated
    # The method visit_Call returns the ast.Call object 'node' back to the caller
    tree

# Generated at 2022-06-23 23:12:28.241433
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:35.171552
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_node as parse
    from .helpers import select_node, dump_node

    source = u('''
        class A(object):
            def __init__(self):
                super().__init__()
                    
        class B(A):
            def __init__(self):
                super().__init__()
                    
        class C(A):
            def __init__(self, a, b):
                super().__init__()
                
        def foo(self):
            super(A, self).__init__()
                
        super(A).__init__()
    ''')


# Generated at 2022-06-23 23:12:36.208683
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:41.605856
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse, compare_trees
    from ..exceptions import NodeNotFound

    root = parse('super()')
    node = root.body[0]

    def _get_func_and_class(tree: ast.AST, node: ast.Call) -> Tuple[ast.FunctionDef, ast.ClassDef]:
        tree_pt = get_closest_parent_of(tree, node, ast.FunctionDef)
        tree_pc = get_closest_parent_of(tree, node, ast.ClassDef)
        return tree_pt, tree_pc

    tree_pt, tree_pc = _get_func_and_class(root, node)
    transformer = SuperWithoutArgumentsTransformer(root)
    transformer.visit_Call(node)

# Generated at 2022-06-23 23:12:50.723974
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..py34 import Py34Tree

    source_code = dedent('''
        class Bar(object):
            pass
    ''')

    tree = Py34Tree.from_code(source_code)
    SuperWithoutArgumentsTransformer(tree).visit(tree.tree.body[0].body[0])

    expected_output = dedent('''
        class Bar(object):
            pass
    ''')
    actual_output = tree.code
    assert actual_output == expected_output

    source_code = dedent('''
        class Bar(object):
            def foo(self):
                super()
    ''')

    tree = Py34Tree.from_code(source_code)
    SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:54.275790
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(t)
    assert astor.to_source(t) == 'super(Cls, self)\n'


# Generated at 2022-06-23 23:13:02.183052
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..node_utils import get_fstring_args
    from typing import List

    tree = astor.parse_file('tests/fixtures/super_without_arguments.py')
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit(tree)
    code = astor.to_source(tree)
    args: List[str] = get_fstring_args(code)
    assert args == ['super(Cls, self)', 'super(Cls, cls)']

# Generated at 2022-06-23 23:13:08.775819
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_ast

    tree = compile_ast("""
        class A:
            def __init__(self):
                super()

        class B(A):
            def __init__(self):
                super().__init__()
    """)

    SuperWithoutArgumentsTransformer().visit(tree)


# Generated at 2022-06-23 23:13:09.471479
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:20.287909
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
  from typed_ast import ast3 as ast, parse
  from . import NodeTransformerTestCase, get_source
  from .transformer_test_case import STANDARD_MIN_VERSION
  
  class TestNodeTransformer(NodeTransformerTestCase):

    def test_call_on_super_with_args(self):
      ast_node = ast.parse('super(Cls, self)')
      transformer = SuperWithoutArgumentsTransformer()
      new_ast_node = transformer.visit(ast_node)
      self.assertEqual(get_source(new_ast_node), 'super(Cls, self)')
      self.assertFalse(transformer.tree_changed())

    def test_call_on_super_without_args(self):
      ast_node = ast.parse('super()')
      transformer = SuperWithout

# Generated at 2022-06-23 23:13:30.662440
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    # Test of visit_Call

    code = "super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    expected = "super(Cls, self)"
    assert Parser().parsetext(code).totext() == Parser().parsetext(expected).totext()

    code = "super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    expected = "super(Cls, self)"
    assert Parser().parsetext(code).totext() == Parser().parsetext(expected).totext()

    code = "super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()

# Generated at 2022-06-23 23:13:32.282157
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    # Test when super() is inside a function

# Generated at 2022-06-23 23:13:32.835380
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:34.241659
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:42.099596
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    class1_input = """class ClassA(object):
        def __init__(self, *args):
            self.args = args
            super()
            super().__init__(1, 2, 3)
            """
    class1_correct = """class ClassA(object):
        def __init__(self, *args):
            self.args = args
            super(ClassA, self)
            super(ClassA, self).__init__(1, 2, 3)
            """
    class1 = ast.parse(class1_input)
    class2 = SuperWithoutArgumentsTransformer().visit(class1)
    assert astor.to_source(class2) == class1_correct

# Generated at 2022-06-23 23:13:48.699351
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import Factory
    from .compile_node import compile_to_str

    ast_factory = Factory()
    ast_factory.register(SuperWithoutArgumentsTransformer)

    call = ast_factory.Call(args=[], lineno=1, col_offset=0)
    call.func = ast_factory.Name(id='super', ctx=ast.Load(), lineno=1, col_offset=0)


# Generated at 2022-06-23 23:13:58.518992
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import test_tree, tree_to_str
    from ..utils.helpers import is_typed_ast_node

    tree = test_tree(ast.parse("""
    def f(a):
        super() + super()

    class C:
        def f(a):
            super() + super()
            def f(a):
                super() + super()
    """))

    SuperWithoutArgumentsTransformer(tree).visit(tree)


# Generated at 2022-06-23 23:13:59.397734
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import get_ast


# Generated at 2022-06-23 23:14:03.614791
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse
    import astor
    code = 'super()'
    expected_code = 'super(Cls, self)'
    tree = ast.parse(code)
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer._replace_super_args(node)
    code = unparse(tree)
    assert code == expected_code

# Generated at 2022-06-23 23:14:05.709096
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')

    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert  ast.dump(tree) == ast.dump(ast.parse('super(Cls, self)'))

# Generated at 2022-06-23 23:14:15.641736
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code1 = "super()"
    code2 = """class ClassA:
        def func1(self):
            super()"""
    tree1 = ast.parse(code1)
    tree2 = ast.parse(code2)
    node_transformer1 = SuperWithoutArgumentsTransformer(tree1)
    node_transformer2 = SuperWithoutArgumentsTransformer(tree2)
    node_transformer1.visit()
    node_transformer2.visit()
    assert node_transformer1.tree_changed()
    assert node_transformer2.tree_changed()
    expected1 = "super(Cls, self)"
    expected2 = """class ClassA:
        def func1(self):
            super(Cls, self)"""
    assert expected1 == to_source(node_transformer1.tree) 

# Generated at 2022-06-23 23:14:18.950134
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object
    from ..utils.helpers import get_ast as _get_ast
    

# Generated at 2022-06-23 23:14:26.766287
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .base import BaseNodeTransformer_visit_Call as test_BaseNodeTransformer_visit_Call
    from .base import NodeTreeEndomondo

    source = """
    if type(foo) == int:
        super()
    """
    tree = ast.parse(source_to_unicode(source))
    endomondo = NodeTreeEndomondo(tree)
    node = tree.body[0].body[0]

    transformer = SuperWithoutArgumentsTransformer(tree, endomondo)
    test_BaseNodeTransformer_visit_Call(transformer, node, 'super(Cls, self)')

# Generated at 2022-06-23 23:14:36.203521
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    cls = ast.parse('class Foo: def foo(self): super()')
    func = ast.parse('def foo(self): super()')
    node_without_args = ast.parse('super(args)')
    node_with_args = ast.parse('super()')
    result_without_args = ast.parse('super(Foo, self)')
    result_with_args = ast.parse('super(Foo, self)')
    result_in_class_definition = ast.parse('class Foo: def foo(self): super(Foo, self)')
    result_in_func_definition = ast.parse('def foo(self): super(Foo, self)')

    tree = ast.parse('super(args)')

# Generated at 2022-06-23 23:14:46.687351
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_compare import are_asts_equal
    from ..utils.source_code import get_ast
    from ..utils.helpers import get_code_from_module

    code = get_code_from_module(SuperWithoutArgumentsTransformer)
    module_ast = get_ast(code)


# Generated at 2022-06-23 23:14:55.043811
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast

    source = 'super()'
    tree = get_ast(source)

    SuperWithoutArgumentsTransformer().visit(tree)

    expected_source = 'super(Cls, self)'

    assert ast.dump(tree) == ast.dump(get_ast(expected_source))

    source = 'super()'
    tree = get_ast(source)

    def func():
        return super()

    tree.body[0].value = func()

    SuperWithoutArgumentsTransformer().visit(tree)

    expected_source = 'def func():\n    return super(Cls, self)'

    assert ast.dump(tree) == ast.dump(get_ast(expected_source))

    source = 'super()'
    tree = get_ast(source)


# Generated at 2022-06-23 23:15:02.960194
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..converter import CodeConverter as CC
    module = ast.parse("""class Foo():
        def method(self):
            super()
        @classmethod
        def class_method(cls):
            super()
    """)
    converter = CC(2, 7)
    converter.visit(module)
    assert converter.result == """class Foo():
        def method(self):
            super(Foo, self)
        @classmethod
        def class_method(cls):
            super(Foo, cls)
    """

# Generated at 2022-06-23 23:15:04.865510
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""


# Generated at 2022-06-23 23:15:05.424186
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:15.517837
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code: str = 'super()'
    node: ast.Module = ast.parse(code)
    tree: SuperWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer()
    tree.visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.func, ast.Attribute)
    assert isinstance(node.body[0].value.func.value, ast.Name)
    assert node.body[0].value.func.value.id == 'super'
    assert isinstance(node.body[0].value.func.attr, ast.Name)

# Generated at 2022-06-23 23:15:25.304108
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    new_code = astor.to_source(tree)
    print(code)
    print(new_code)
    assert code != new_code

    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    new_code = astor.to_source(tree)
    print(code)
    print(new_code)
    assert code != new_code

    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    new_code = astor.to_source(tree)
    print(code)

# Generated at 2022-06-23 23:15:27.745473
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from .transformers import TransformerSequence

    ts = TransformerSequence()
    ts.register_transformer(SuperWithoutArgumentsTransformer)
    res = ts.transform_code('super()')

    assert res == 'super(cls, self);'

# Generated at 2022-06-23 23:15:28.963495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src

# Generated at 2022-06-23 23:15:29.749976
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_source

# Generated at 2022-06-23 23:15:36.315824
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .. import compile
    from .visit import NodeTransformer
    from .base import BaseNodeTransformer
    from ..utils.context import Context
    import sys 

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.func = ast.Name(id='ASD')
            return node

    code = '''
        class A:
            def f(self):
                super()
    '''

    tree = compile(code, '<test>', 'exec')
    ctx = Context()

# Generated at 2022-06-23 23:15:40.801959
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_code_compiler import SourceCodeCompiler
    from ..utils.helpers import load_module, dump_module

    setattr(ast, 'Call', ast.Call)  # fix mypy error. Should not be needed after https://github.com/python/mypy/issues/2087 is resolved

# Generated at 2022-06-23 23:15:46.442373
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import u
    tree = ast.parse(u('''
        class Cls(SuperCls):
            def f(self):
                super()
    '''))

    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert str(tree) == u('''
        class Cls(SuperCls):

            def f(self):
                super(Cls, self)
    ''')


# Generated at 2022-06-23 23:15:55.423391
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
               class foo(object):
                   def __init__(self):
                       super()

               class bar(foo):
                   def __init__(self):
                       foo.__init__(self)
                       super()
               """

    # pylint: disable=unused-variable
    import typed_ast.ast3
    from ... import utils
    from ...tokenize import generate_tokens
    from .demo_typed_ast import parse
    from .demo_typed_ast import dump

    parsed = parse(code)
    tokens = [t for t in generate_tokens(code)]

    assert isinstance(parsed, typed_ast.ast3.Module)

    tree = utils.typed_ast_to_real_ast(parsed)
    tree = SuperWithoutArgumentsTrans

# Generated at 2022-06-23 23:15:56.450663
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:16:00.671382
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super()
    code = """
    super()
    """
    expected_code = """
    super(Cls, self)
    """
    n = SuperWithoutArgumentsTransformer()
    n.visit(ast.parse(code))
    assert ast.dump(ast.parse(expected_code)) == ast.dump(n.visit(ast.parse(code)))

# Generated at 2022-06-23 23:16:05.339010
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(ast_tree)
    func_body = ast.Module(body=tree.body)
    code = compile(func_body, '', 'exec')
    exec(code)



# Generated at 2022-06-23 23:16:06.334129
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:07.308048
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:16.705785
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
        class A:
            def method(self):
                super()
        class B(A):
            def method(self):
                super()
        class C(A):
            @classmethod
            def method(cls):
                super()
    
    """
    expected_output = """
        class A:
            def method(self):
                super(A, self)
        class B(A):
            def method(self):
                super(B, self)
        class C(A):
            @classmethod
            def method(cls):
                super(C, cls)
        """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree, include_attributes=False) == expected_output

# Generated at 2022-06-23 23:16:24.570275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = dedent('''
        class Parent(object):
            def __init__(self):
                super().__init__()
                
        class Child(Parent):
            def __init__(self):
                super().__init__()
    ''')

    new_code = dedent('''
        class Parent(object):
            def __init__(self):
                super(Parent, self).__init__()
                
        class Child(Parent):
            def __init__(self):
                super(Child, self).__init__()
    ''')

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformed_tree = transformer.visit(tree)
    expected_tree = ast.parse(new_code)
    assert_equal_ignore_linenos

# Generated at 2022-06-23 23:16:34.778879
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.source_code import SourceCode
    from .dummy_context import DummyContext
    from .base import BaseNodeTransformer
    from ..exceptions import NodeNotFound
    import pytest

    class Dummy(BaseNodeTransformer):
        def __init__(self, context: DummyContext):
            super().__init__(context)

        def _visit_children(self, node: ast.AST) -> ast.AST:
            return node

    class TestTransformer(BaseNodeTransformer):
        def __init__(self, context: DummyContext):
            super().__init__(context)
            self._dummy = Dummy(context)

        @property
        def tree_changed(self) -> bool:
            return self._dummy.tree_changed

       

# Generated at 2022-06-23 23:16:42.325441
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..unit_tests.utils import compile_to_str, should_transform_unchanged
    
    class TestTransformer(SuperWithoutArgumentsTransformer):
        def _get_func_def(self, node):
            return ast.FunctionDef(name='test', body=[self._tree])
    
    

# Generated at 2022-06-23 23:16:43.976127
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List, cast
    from ..utils.source import Source
    from ..utils.helpers import code_equal


# Generated at 2022-06-23 23:16:44.532034
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:54.489840
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import string_to_module
    from .base import BaseNodeTransformer

    class Test(BaseNodeTransformer):
        target = (2, 7)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id='Cls'), ast.Name(id='self')]

            return self.generic_visit(node)

    src = """
    class A(object):
        def __init__(self):
            super()
    """
    module = string_to_module(src)

    transformer = Test()

# Generated at 2022-06-23 23:16:55.285886
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:05.543979
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .helper import get_ast_tree
    from .helper import parse_ast_tree
    from .helper import compare_ast_trees

    transformer = SuperWithoutArgumentsTransformer(None)
    transformer.visit = transformer.visit_Call

    tree = get_ast_tree('super()')
    tree = parse_ast_tree(tree, transformer)
    new_tree = get_ast_tree('super(Cls, self)')
    new_tree = parse_ast_tree(new_tree)

    assert compare_ast_trees(tree, new_tree)

    tree = get_ast_tree('""".\nsuper()\n"""')
    tree = parse_ast_tree(tree, transformer)

# Generated at 2022-06-23 23:17:07.621031
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that the SuperWithoutArgumentsTransformer correctly transforms a simple class"""

# Generated at 2022-06-23 23:17:17.231224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..upy_ast import upy_ast
    from ..utils.helpers import get_ast_node
    from ..utils.ast import print_ast_node
    from .base import BaseUpyTransformer
    def test1():
        test_tree = upy_ast.parse('''
        class ClassNameA(object):
            def __init__(self):
                super()
        ''')
        transformer = SuperWithoutArgumentsTransformer(test_tree)
        assert transformer._tree_changed == True
        assert print_ast_node(get_ast_node(test_tree, ast.Call)) == "super(ClassNameA, self)"

# Generated at 2022-06-23 23:17:19.710543
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test for SuperWithoutArgumentsTransformer class"""

    from .. import compile as compile_
    from ..utils.grammar import grammar

    compiler = compile_.Compile()
    compiler.update_rules(grammar)
    compiler.register_transformers(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-23 23:17:25.970064
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    with open("tests/fixtures/nodes_transformer/super_without_arguments.py") as file:
        tree_before = ast.parse(file.read())

    with open("tests/fixtures/nodes_transformer/super_without_arguments_after.py") as file:
        tree_after = ast.parse(file.read())

    transformer = SuperWithoutArgumentsTransformer(tree_before)
    transformer.run()

    assert ast.dump(tree_before, include_attributes=False) == ast.dump(tree_after, include_attributes=False)

# Generated at 2022-06-23 23:17:27.032201
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:29.455309
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node


# Generated at 2022-06-23 23:17:34.455014
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    '''
    It tests the visit_Call method of class SuperWithoutArgumentsTransformer.
    '''
    from typed_ast import parse
    node = parse('''class Foo(object):
    def __init__(self):
        super()
        super(object)''')
    SuperWithoutArgumentsTransformer().visit(node)


# Generated at 2022-06-23 23:17:36.133814
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-23 23:17:44.892482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code1 = """
    class A:
        def __init__(self):
            super().__init__()
    """
    code2 = """
    class A:
        def __init__(self):
            super().__init__()
    """

    expected_code1 = """
    class A:
        def __init__(self):
            super(A, self).__init__()
    """
    expected_code2 = """
    class A:
        def __init__(self):
            super(A, self).__init__()
    """

    tree1 = ast.parse(code1)
    tree2 = ast.parse(code2)

    transformer = SuperWithoutArgumentsTransformer(tree1)
    transformer1 = SuperWithoutArgumentsTransformer(tree2)


# Generated at 2022-06-23 23:17:50.493841
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
    class C:
        def f(self):
            return super().f()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    expected = """
    class C:
        def f(self):
            return super(C, self).f()
    """
    assert astor.to_source(tree) == expected



# Generated at 2022-06-23 23:17:51.124245
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass # ~line 127

# Generated at 2022-06-23 23:17:55.528371
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with open('tests/data/super_without_arguments/in.py') as code_in:
        tree = ast.parse(code_in.read())

    result = str(tree)
    with open('tests/data/super_without_arguments/out.py') as code_out:
        assert(result == code_out.read())

# Generated at 2022-06-23 23:17:57.104137
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from . import ast_helpers


# Generated at 2022-06-23 23:17:58.055892
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:03.410285
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0].value
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == "Cls"
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == "self"

# Generated at 2022-06-23 23:18:04.360797
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:07.794516
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..ast_manipulation import get_ast, get_code
    from astor.code_gen import to_source
    from .test_utils import assert_code_equal


# Generated at 2022-06-23 23:18:13.996720
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing_utils import assert_source

    code = '''
    class Test:
        def method(self):
            super()
    '''
    expected_code = '''
    class Test:
        def method(self):
            super(Test, self)
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(target=None)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert_source(tree, expected_code)



# Generated at 2022-06-23 23:18:19.942966
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .unpacking import UnpackingTransformer

    code = """
    class cls:
        def method(self):
            super()
    """
    module = ast.parse(code)
    UnpackingTransformer().visit(module)
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.run()
    assert module is not None
    assert len(ast.walk(module)) == 9
    assert transformer._tree_changed is True
    assert isinstance(module.body[0], ast.ClassDef)
    assert isinstance(module.body[0].body[0], ast.FunctionDef)
    assert isinstance(module.body[0].body[0].body[0], ast.Expr)
    assert isinstance(module.body[0].body[0].body[0].value, ast.Call)

# Generated at 2022-06-23 23:18:22.133834
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast as c2a

    # Method with super() outside of a class

# Generated at 2022-06-23 23:18:27.951342
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('class Test(object):\n    def foo(self):\n        super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformed_tree: ast.AST = transformer.visit(tree)
    assert 'super(Test, self)' in transformed_tree.body[0].body[0].body[0].body[0].s


# Generated at 2022-06-23 23:18:34.864922
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_transformer = SuperWithoutArgumentsTransformer()
    code_transformer.parse(
        "def A():\n"
        "    super()\n"
        "\n"
        "class B:\n"
        "    def C():\n"
        "        super()\n"
    )
    assert code_transformer.to_source() == "def A():\n" \
        "    super(B, self)\n" \
        "\n" \
        "class B:\n" \
        "    def C():\n" \
        "        super(B, cls)\n"

# Generated at 2022-06-23 23:18:43.909633
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import setup_ast_parser
    setup_ast_parser()

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast.parse('''class A(object):
        def __init__(self):
            super()
    '''))
    transformer.visit(ast.parse('''
    class A(object):
        def test(cls):
            super()
    '''))
    transformer.visit(ast.parse('''
    def test():
        super()
    '''))

# Generated at 2022-06-23 23:18:48.134566
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(Cls, self)" in astor.to_source(tree)
    assert "super(Cls, cls)" in astor.to_source(tree)

# Generated at 2022-06-23 23:18:57.506546
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import build_ast_from_code
    from .base import BaseNodeTransformer

    class TestNodeTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id="Cls"), ast.Name(id="self")]

            return self.generic_visit(node)

    def test_transformer(code_str: str, expect_str: str) -> None:
        tree = build_ast_from_code(code_str)
        transformer = TestNodeTransformer('test', tree, {})

# Generated at 2022-06-23 23:18:58.965619
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:07.165669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("""
    super()
    """)
    SuperWithoutArgumentsTransformer(ast.parse("""
    class SuperNoArgs:
        def __init__(self):
            super()
    """)).visit(node)
    assert "super(SuperNoArgs, self)" in astunparse.unparse(node)

    node = ast.parse("""
    super()
    """)
    SuperWithoutArgumentsTransformer(ast.parse("""
    class SuperNoArgs2:
        def __init__(self):
            super(SuperNoArgs2, self)
    """)).visit(node)
    assert "super(SuperNoArgs2, self)" in astunparse.unparse(node)

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:19:13.232744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = '''
        class Cls:
            def method(self):
                super()
        '''
    tree = ast.parse(source)
    fixer = SuperWithoutArgumentsTransformer(tree)
    fixer.visit(tree)
    assert fixer._tree_changed is True
    fixed = ast.parse('''
        class Cls:
            def method(self):
                super(Cls, self)
        ''')
    assert tree == fixed

# Generated at 2022-06-23 23:19:21.415944
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test to ensure SuperWithoutArgumentsTransformer.visit_Call() works correctly."""

    # Prepare test data
    data = """
        class Cls(object):
            def __init__(self, cls):
                self.cls = cls
    """
    data = ast.parse(data)
    node = data.body[0].body[0]
    node.args.args[0].arg = 'self'  # type: ignore
    node.args.args[0].arg = 'self'
    node.args.args[0].arg = 'self'

    # Do the test
    transformer = SuperWithoutArgumentsTransformer(data)
    node = transformer.visit(node)
    node = ast.fix_missing_locations(node)

    # Ensure the test result is correct
    data = ast.dump

# Generated at 2022-06-23 23:19:24.884305
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
            class A:
                def method(self):
                    super()
            """
    expected = """
            class A:
                def method(self):
                    super(A, self)
            """
    tree = ast.parse(source)  # type: ignore
    ast.fix_missing_locations(tree)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert ast.unparse(tree) == expected

# Generated at 2022-06-23 23:19:32.476328
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.python_ast import generate_ast

    code = """
        class MyClass(SuperClass):
            def __init__(self, arg1):
                super().__init__()
"""
    expected_code = """
        class MyClass(SuperClass):
            def __init__(self, arg1):
                super(MyClass, self).__init__()
"""
    tree = generate_ast(code)
    SuperWithoutArgumentsTransformer(tree).run()
    assert generate_code(tree).strip() == expected_code.strip()

# Generated at 2022-06-23 23:19:35.267831
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as parse


# Generated at 2022-06-23 23:19:42.689628
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[])
    expected = ast.Call(func=ast.Name(id='super', ctx=ast.Load()),
                        args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[])


# Generated at 2022-06-23 23:19:48.190247
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import testing
    from .. import utils
    # from .. import pprint

    code = '''
    class Cls:
        def method(self):
            super()
    '''
    tree = utils.parse_code_to_ast(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    testing.assert_func_eq(utils.dump_ast, tree, code.replace('super()', 'super(Cls, self)'))

# Generated at 2022-06-23 23:19:58.616024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse
    tree = parse("class Test: def test(self): super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "class Test:\n    def test(self):\n        super(Test, self)"

    tree = parse("class Test: def test(self): super()\nclass Test2: def test2(self): super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "class Test:\n    def test(self):\n        super(Test, self)\nclass Test2:\n    def test2(self):\n        super(Test2, self)"

    tree = parse("class Test: def test(self): pass")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str

# Generated at 2022-06-23 23:20:03.507506
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    code = 'class Demo(super):\ndef __init__(self):\n    super().__init__()'
    tree = ast3.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-23 23:20:07.567877
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    
    class DummyTransformer(SuperWithoutArgumentsTransformer):
        @property
        def tree_changed(self) -> bool:
            return self._tree_changed

    # Case: super() inside method