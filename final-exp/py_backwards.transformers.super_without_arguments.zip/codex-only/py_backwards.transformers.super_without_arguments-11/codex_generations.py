

# Generated at 2022-06-23 23:10:08.314185
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Method to test the constructor of class SuperWithoutArgumentsTransformer"""

    transformer = SuperWithoutArgumentsTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer._tree is None



# Generated at 2022-06-23 23:10:09.585171
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..bst import parse
    from .base import BaseNodeTest
    

# Generated at 2022-06-23 23:10:14.487077
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_code_for_tests import super_without_arguments_source
    from ..utils.source_code_for_tests import super_without_arguments_expected_source

    tree = ast.parse(super_without_arguments_source)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert ast.dump(tree) == super_without_arguments_expected_source

# Generated at 2022-06-23 23:10:18.015561
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert 'super(Cls, cls)' == \
        str(SuperWithoutArgumentsTransformer.run_on('super()', target='2.7', 
        class_body='class Foo: def foo(): pass'))

# Generated at 2022-06-23 23:10:19.654562
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer.__doc__ is not None


# Unit test: super() -> super(Cls, self)

# Generated at 2022-06-23 23:10:22.591235
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_python import Function
    from typed_ast import ast3
    from typed_python.compiler.global_ast_transformer import GlobalASTTransformer

    SuperWithoutArgumentsTransformer.transform_all_functions(GlobalASTTransformer, [Function])


if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:10:25.390441
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast, run_code
    
    class TestNodeTransformer(SuperWithoutArgumentsTransformer):
        pass

# Generated at 2022-06-23 23:10:30.668312
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    source = dedent("""
    class A:
        pass
    """)
    expected_result = dedent("""
    class A:
        pass
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_result))

# Generated at 2022-06-23 23:10:40.196082
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unittest_tools import assert_transform

    assert_transform(
        SuperWithoutArgumentsTransformer,
        "super()",
        "super(Cls, self)"
    )

    assert_transform(
        SuperWithoutArgumentsTransformer,
        """class D(C):
        def f(self):
            super()
        @classmethod
        def g(cls):
            super()
        @staticmethod
        def h():
            super()
    """,
        """class D(C):
        def f(self):
            super(D, self)
        @classmethod
        def g(cls):
            super(D, cls)
        @staticmethod
        def h():
            super(D, self)
    """
    )


# Generated at 2022-06-23 23:10:43.687356
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestNodeTransformer(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.AST:
            return ast.parse("f()").body[0].value

    # 2.7 super() in function

# Generated at 2022-06-23 23:10:49.574388
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .. import compile_
    from ..visitor import PrintVisitor

    source = source_to_unicode('''
        class Foo:
            def bar(self):
                super()
        ''')

    module_node = compile_(source, '<test>', 'exec')
    SuperWithoutArgumentsTransformer().visit(module_node)
    assert PrintVisitor().visit(module_node) == source_to_unicode('''
        class Foo:
            def bar(self):
                super(Foo, self)
        ''')

# Generated at 2022-06-23 23:10:53.219825
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()", '<string>', 'exec')
    SuperWithoutArgumentsTransformer(tree=tree).run()
    got = ast.dump(tree)
    want = ""
    assert want == got



# Generated at 2022-06-23 23:11:02.237080
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arguments are not provided
    node = ast.parse('''
    class A:
        def __init__(self):
            super().__init__()
    ''')
    SuperWithoutArgumentsTransformer(node).visit(node)
    assert node == ast.parse('''
    class A:
        def __init__(self):
            super(A, self).__init__()
    ''')

    # Arguments are provided
    node = ast.parse('''
    class A:
        def __init__(self):
            super(A, self).__init__(1)
    ''')
    SuperWithoutArgumentsTransformer(node).visit(node)

# Generated at 2022-06-23 23:11:09.861818
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import parse_ast_tree, build_ast_tree, compare_ast_trees

    tree = parse_ast_tree('class A():  super()')
    expected_tree = parse_ast_tree('class A():  super(A, self)')
    node = tree.body[0].body[0]
    SuperWithoutArgumentsTransformer(tree).visit(node)
    compare_ast_trees(expected_tree, tree)

    tree = parse_ast_tree('def f(self):  class A():  super()')
    expected_tree = parse_ast_tree('def f(self):  class A():  super(A, cls)')
    node = tree.body[0].body[0].body[0]
    SuperWithoutArgumentsTransformer(tree).visit(node)


# Generated at 2022-06-23 23:11:21.134614
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.fake_ast import generate_fake_call
    
    def check(node: ast.Call, expected_tree_changed: bool, expected_node: ast.Call):
        t = SuperWithoutArgumentsTransformer()
        t.visit(generate_fake_call(node))
        assert t._tree_changed == expected_tree_changed
        assert node == expected_node

    node = ast.Call(ast.Name(id='super', ctx=ast.Load()), [], [])
    check(node, True, ast.Call(ast.Name(id='super', ctx=ast.Load()), [], []))


# Generated at 2022-06-23 23:11:26.750617
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """ Example of usage

    class Cls:
        def method(self):
            super()
    """

    tree = ast.parse(dedent(test_SuperWithoutArgumentsTransformer_visit_Call.__doc__))
    transformer_cls = SuperWithoutArgumentsTransformer(tree)
    transformer_cls.visit(tree)

    expected_tree = ast.parse(dedent('''
    class Cls:
        def method(self):
            super(Cls, self)
    '''))

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:11:37.767610
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    from . import get_node_of_class
    import textwrap
    example = textwrap.dedent('''\
        class Cls(object):

            def method(self):
                super()
    ''')
    expected = textwrap.dedent('''\
        class Cls(object):

            def method(self):
                super(Cls, self)
    ''')
    tree = get_ast(example)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    node = get_node_of_class(tree, ast.Call)
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'
    assert example != expected

# Generated at 2022-06-23 23:11:45.895414
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import top_level_parser
    from ..utils.helpers import dump_tree
    from ..exceptions import NotImplementedForTargetVersion

    try:
        t = top_level_parser('super()')
    except NotImplementedForTargetVersion:
        assert True
        return


# Generated at 2022-06-23 23:11:48.630517
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source
    from .helpers import assert_transformation, get_ast


# Generated at 2022-06-23 23:11:50.305218
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import literal_eval


# Generated at 2022-06-23 23:11:57.572201
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    class FakeVisitor:
        tree = None

    class FakeCodeConverter:
        def __init__(self, source, target):
            self._source = source
            self._target = target

        def convert_tree(self, tree):
            visitor = SuperWithoutArgumentsTransformer(tree, self._source, self._target)
            visitor.visit(tree)
            return tree

    fake_source = (3, 7)
    fake_target = (3, 7)
    fake_cc = FakeCodeConverter(fake_source, fake_target)
    fake_visitor = FakeVisitor()

# Generated at 2022-06-23 23:12:00.270944
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .syntax_3to2 import fix_missing_locations, parse

# Generated at 2022-06-23 23:12:10.320610
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import check_transformer
    from ..utils.testing import check_source_transformation
    from ..utils.testing import assert_source_equals
    from ..utils.testing import source_to_ast
    import sys

    # Make sure this test runs on 3.9
    sys.modules['typed_ast.ast3'] = typed_ast.ast3

    check_transformer(SuperWithoutArgumentsTransformer)

    # We need this because <2.7 doesn't have the zero-arg super() syntax
    check_source_transformation(SuperWithoutArgumentsTransformer,
                                'super().__init__()',
                                'super(MyClass, self).__init__()')

    # Make sure this test runs on 3.9
    sys.modules['typed_ast.ast3'] = typed_ast.ast

# Generated at 2022-06-23 23:12:19.913497
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import inspect

    tree = ast.parse('super()')

    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 0

    cls = SuperWithoutArgumentsTransformer(tree)
    cls.visit(tree)
    node = tree.body[0].value
    args = node.args
    assert isinstance(node, ast.Call)
    assert len(args) == 2
    assert isinstance(args[0], ast.Name)
    assert args[0].id == 'super'
    assert isinstance(args[1], ast.Name)
    assert args[1].id == 'self'

    tree = ast.parse('super()')

    node = tree.body[0].value

# Generated at 2022-06-23 23:12:25.127774
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_without_arguments = SuperWithoutArgumentsTransformer(2, 7)
    node = ast.parse("super()").body[0] # type: ignore
    expected = "super(__outer_name__(), self)"
    super_without_arguments.visit(node)

    assert to_source(node) == expected


# Generated at 2022-06-23 23:12:28.495671
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast

    class TestTree:
        tree: ast.Module = None
        parent: ast.ClassDef = None
        func: ast.FunctionDef = None

    tree = TestTree()

# Generated at 2022-06-23 23:12:35.308649
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast, dump_ast
    tree = get_ast(r"""
        class TestClass(object):
            def TestMethod(self):
                super()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

# Generated at 2022-06-23 23:12:42.036089
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    code = """
        class A:
            def a(self):
                super().a()
    """
    expected_code = """
        class A:
            def a(self):
                super(A, self).a()
    """
    tree = ast.parse(code)

    # When
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    # Then
    assert expected_code.strip() == astunparse.unparse(tree).strip()



# Generated at 2022-06-23 23:12:48.244645
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code

    code = """
    class Foo:
        def __init__(self):
            super()
    """
    expected_code = """
    class Foo:
        def __init__(self):
            super(Foo, self)
    """

    node = source_to_code(code)
    SuperWithoutArgumentsTransformer().visit(node)
    result_code = code_to_source(node)

    assert result_code == expected_code

# Generated at 2022-06-23 23:12:54.259424
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import round_trip

    src = 'class C:\n def __init__(self):\n  super().__init__()'
    module = round_trip(src, SuperWithoutArgumentsTransformer)
    assert str(module) == 'class C:\n def __init__(self):\n  super(C, self).__init__()'

    func = module.body[0].body[0]
    assert isinstance(func, ast.FunctionDef)
    assert isinstance(func.args.args[0], ast.arg)
    assert func.args.args[0].arg == 'self'

# Generated at 2022-06-23 23:13:05.468367
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.helpers import get_ast_node_at
    from ..utils.tree import tree_to_str
    import textwrap

    code = textwrap.dedent('''\
        a = super()
        class A:
            a = super()
            def b():
                a = super()
        ''')
    tree = ast.parse(code)

    expected_code = textwrap.dedent('''\
        a = super(A, self)
        class A:
            a = super(A, self)
            def b(self):
                a = super(A, self)
        ''')
    expected_tree = ast.parse(expected_code)

    transpiler = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:13:06.960316
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor


# Generated at 2022-06-23 23:13:18.389457
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_tree_unchanged

    node = SuperWithoutArgumentsTransformer(None)
    node._replace_super_args = lambda *args: None

    node.visit_Call(ast.parse('super()'))
    assert_tree_unchanged('super()', 'super()')

    node.visit_Call(ast.parse('super(1)'))
    assert_tree_unchanged('super(1)', 'super(1)')

    node.visit_Call(ast.parse('super(a)'))
    assert_tree_unchanged('super(a)', 'super(a)')

    node.visit_Call(ast.parse('super(1, 2, 3)'))

# Generated at 2022-06-23 23:13:22.252836
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_python_with_typed_ast as run
    from typed_ast import ast3 as ast
    from .return_stmt_transformer import ReturnStmtTransformer
    from ..utils.tree_compare import assert_code_equivalent


# Generated at 2022-06-23 23:13:32.409880
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cl1(object):
            def __init__(self):
                super()
    
        class Cl2(object):
            def method(self):
                super()
    """
    expected_code = """
        class Cl1(object):
            def __init__(self):
                super(Cl1, self)
    
        class Cl2(object):
            def method(self):
                super(Cl2, self)
    """
    code = code.split("\n")
    expected_code = expected_code.split("\n")
    expected_code = map(str.strip, expected_code)
    code = map(str.strip, code)
    node = ast.parse("\n".join(code))
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-23 23:13:33.717859
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src
    import ast

# Generated at 2022-06-23 23:13:34.286966
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:36.101571
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_setup import setup_test_transformer


# Generated at 2022-06-23 23:13:44.383017
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer
    from ..transformers.super import SuperWithArgumentsTransformer
    from ..transformers.methods_to_functions import MethodsToFunctionsTransformer

    source = """
    class MyClass:
        def __init__(self, a):
            super().__init__(a)
        def __init__(self):
            super().__init__()
        def __init__(self, a, b, c):
            super().__init__(a, b, c)
        def my_method(self):
            super().my_method()
    """


# Generated at 2022-06-23 23:13:44.879399
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:45.906623
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    # Test class with super()

# Generated at 2022-06-23 23:13:49.929602
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from ast import Call, Name, FunctionDef, arguments, ClassDef
    src = 'super()'
    tree = ast.parse(src)
    node = tree.body[0]  # type: Call
    assert isinstance(node, Call)

    func = FunctionDef(name='test', args=arguments(args=[ast.arg(arg='self', annotation=None)]), body=[node],
                       decorator_list=[], returns=None)
    cls = ClassDef(name='Test', bases=[], keywords=[], body=[func], decorator_list=[])
    func.parent = cls
    node.parent = func

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit(node)
    assert len(node.args) == 2

# Generated at 2022-06-23 23:13:57.712274
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    ast_tree = ast.parse('super()')
    cls = ast_tree.body[0]
    SuperWithoutArgumentsTransformer(ast_tree).visit(cls)
    assert cls.args[0].id == 'Cls'
    assert cls.args[1].id == 'self'

    ast_tree = ast.parse('super()')
    func = ast_tree.body[0]
    SuperWithoutArgumentsTransformer(ast_tree).visit(func)
    assert func.args[0].id == 'cls'
    assert func.args[1].id == 'self'

# Generated at 2022-06-23 23:14:05.534787
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse("super()", mode="exec")
    module.body[0] = SuperWithoutArgumentsTransformer().visit(module.body[0])
    assert isinstance(module.body[0], ast.Expr)
    assert isinstance(module.body[0].value, ast.Call)
    assert isinstance(module.body[0].value.func, ast.Name)
    assert module.body[0].value.func.id == 'super'
    assert isinstance(module.body[0].value.args[0], ast.Name)
    assert module.body[0].value.args[0].id == 'Cls'
    assert isinstance(module.body[0].value.args[1], ast.Name)
    assert module.body[0].value.args[1].id == 'self'




# Generated at 2022-06-23 23:14:15.640783
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed

    assert_transformed(
        """
        class A:
            def __init__(self):
                super()
        """,
        """
        class A:
            def __init__(self):
                super(A, self)
        """
    )
    assert_transformed(
        """
        class A:
            def __init__(self, a):
                super()
        """,
        """
        class A:
            def __init__(self, a):
                super(A, self)
        """
    )

# Generated at 2022-06-23 23:14:21.632944
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    # Before
    node_1: ast.Call = ast.parse('super()').body[0]
    # After
    node_2: ast.Call = ast.parse('super(Cls, self)').body[0]

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node_1)

    assert node_1 == node_2

# Generated at 2022-06-23 23:14:26.132404
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class C:
          def __init__(self):
            super().__init__()
    '''
    tree = compile_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    new_code = compile_to_code(tree)
    assert new_code == code



# Generated at 2022-06-23 23:14:30.385911
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse

    source = '''
        class Base:
            def __init__(self):
                super()
        '''

    # Create the AST tree from source
    tree = parse(source)

    # Instantiate ClassTransformer
    t = SuperWithoutArgumentsTransformer()

    # Apply the transformer and get the modified AST tree
    new_tree = t.visit(tree)

    assert new_tree is not None
    assert t._tree_changed is True

# Generated at 2022-06-23 23:14:41.013424
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test1 = ast.parse("super()")
    test2 = ast.parse("super(x, y, z)")
    test3 = ast.parse("super(x)")
    test4 = ast.parse("super('x')")

    t = SuperWithoutArgumentsTransformer()

    t.visit(test1)
    assert ast.dump(test1) == "Call(Name(id='super', ctx=Load()), [Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], [], None, None)"

    t.visit(test2)

# Generated at 2022-06-23 23:14:49.838651
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = astroid.parse('''
        class A(object):
            def f(self):
                super()
    ''')
    tree.body[0].body[0].args.args[0].arg = 'self'
    
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    node = tree.body[0].body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'A'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:14:57.001589
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    root = ast.parse('super()')
    node = root.body[0]
    SuperWithoutArgumentsTransformer(root, 2).visit(node)
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self' or node.args[1].id == 'cls'
    print('SuperWithoutArgumentsTransformer_visit_Call test passed')


# Generated at 2022-06-23 23:15:03.829820
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ... import ast_parse
    from ...utils import dump_tree

    tree = ast_parse("super()")
    SuperWithoutArgumentsTransformer(tree).run()
    assert dump_tree(tree) == (
        "(ModuleNone\n"
        "  (Expr\n"
        "    (Call\n"
        "      (Name(id='super')\n"
        "      (Name(id='Cls'))\n"
        "      (Name(id='self')))))"
    )



# Generated at 2022-06-23 23:15:13.711870
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
    class Class:
        def func(self):
            super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = ast.dump(tree, include_attributes=True)

# Generated at 2022-06-23 23:15:21.619251
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import python_minifier.transformer.base

    # Init
    super_without_arguments_transformer = python_minifier.transformer.base.SuperWithoutArgumentsTransformer()
    super_without_arguments_transformer._tree = ast.parse("super()")

    # Run
    super_without_arguments_transformer.visit_Call(super_without_arguments_transformer._tree.body[0])

    # Assert
    assert str(super_without_arguments_transformer._tree) == "super(node_1, node_2)"

# Generated at 2022-06-23 23:15:27.444946
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object
    import ast
    code = '''class A(object):
    def foo(self):
        super()
'''

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert code_object_to_source(compile(tree, '', 'exec')) == \
        '''class A(object):
    def foo(self):
        super(A, self)
'''

# Generated at 2022-06-23 23:15:28.323115
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:37.216797
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.helpers import node_lineno
    from ..utils.helpers import node_col_offset

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree = source_to_ast.parse(source_to_code.dedent('''\
                class A:
                    def a():
                        pass
                class B(A):
                    def b():
                        super()
                    def c(self):
                        super()
                '''))
            self._tree_changed = False

    t = TestTransformer()

    t.visit(t._tree)


# Generated at 2022-06-23 23:15:39.446073
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)
    node = ast.parse('super()')
    transformer.visit(node)



# Generated at 2022-06-23 23:15:49.377557
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from ..utils.helpers import assert_source

    input_code = textwrap.dedent("""
    class Foo():
        def __init__(self):
            super()

        def bar(self):
            super()

        def foo(cls):
            super()
    """)
    expected_ast = textwrap.dedent("""
    class Foo():
        def __init__(self):
            super(Foo, self)

        def bar(self):
            super(Foo, self)

        def foo(cls):
            super(Foo, cls)
    """)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast.parse(input_code))
    transformed_ast = ast.fix_missing_locations(transformer.tree)
    assert_source

# Generated at 2022-06-23 23:15:49.960232
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:57.906138
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..unit_test_utils import transform, \
        create_class, create_func, create_super, \
        assert_node, assert_code

    # Test a class with a super() call in its constructor
    cls = create_class('Cls')
    constructor = create_func('__init__', create_super(), cls)
    cls.body.append(constructor)
    tree = create_class('Cls2', cls)

    assert_code(tree, """
    class Cls2(Cls):
        def __init__(self):
            super(Cls, self)

    class Cls(object):
        def __init__(self):
            pass
    """)

    transform(tree, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-23 23:15:58.904415
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:59.748829
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:02.367433
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(None)
    assert 'cls' == transformer._function_to_param_name('__init__')

# Generated at 2022-06-23 23:16:12.613008
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_all_nodes_of
    from ..exceptions import NodeNotFound

    class Dummy(ast.AST): pass
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)

    # Check that there is only one super
    try:
        super_ = get_all_nodes_of(tree, ast.Call)
    except NodeNotFound:
        assert False

    assert len(super_) == 1
    assert super_[0].func.id == 'super'
    assert len(super_[0].args) == 2

    # Check that the method was replaced
    assert super_[0].args[0].id == 'Dummy'

# Generated at 2022-06-23 23:16:13.102995
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Fixme
    pass

# Generated at 2022-06-23 23:16:17.621857
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_tree_to_code import to_source
    from ..utils.fake_ast import get_fake_ast
    from ..main import compile
    code = 'super()'
    tree = get_fake_ast(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree.body[0])
    assert to_source(tree) == 'super(Test, self)'
    assert compile(code) == 'super(Test, self)'

# Generated at 2022-06-23 23:16:25.542663
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
        class Dummy:
            def __init__(self):
                super()
            def test_method(self):
                super()
        Dummy()
        '''
    expected_code = '''
        class Dummy:
            def __init__(self):
                super(Dummy, self)
            def test_method(self):
                super(Dummy, self)
        Dummy()
        '''
    code = dedent(code).strip()
    expected_code = dedent(expected_code).strip()
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))

    assert t._tree_changed is True
    assert astunparse.unparse(t.root).strip() == expected_code
    t = SuperWithoutArgumentsTransformer()
    t

# Generated at 2022-06-23 23:16:26.691742
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3


# Generated at 2022-06-23 23:16:33.502045
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = ''' 
    class A(object):
        def __init__(self):
            self.a = super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert (
        code_gen.to_source(tree).strip() == '\nclass A(object):\n    def __init__(self):\n        self.a = super(A, self)\n'
    )

# Generated at 2022-06-23 23:16:38.856350
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code_in = """
    class MyClass(object):
        def method(self):
            super()
    """
    code_out = """
    class MyClass(object):
        def method(self):
            super(MyClass, self)
    """
    tree_in = ast.parse(code_in)
    tree_out = ast.parse(code_out)
    SuperWithoutArgumentsTransformer().visit(tree_in)
    assert ast.dump(tree_in) == ast.dump(tree_out)

# Generated at 2022-06-23 23:16:41.519466
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..converter import py_to_py
    from ..parser import mod_parser


# Generated at 2022-06-23 23:16:48.405564
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
    class Foo(object):
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert isinstance(tree.body[0].bases[0], ast.Call)
    assert isinstance(tree.body[0].bases[0].func, ast.Name)
    assert tree.body[0].bases[0].func.id == 'super'

# Generated at 2022-06-23 23:16:55.585410
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import check_node_transformation
    from ..utils.test_utils import check_node_not_changed


# Generated at 2022-06-23 23:16:57.130282
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.helpers import get_ast

# Generated at 2022-06-23 23:17:08.097017
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_result = """
        class Cls:
            def __init__(self):
                self.A = super(Cls, self)

        class Cls2:
            def __init__(self, cls):
                self.A = super(Cls2, cls)
    """
    assert_expected = """
        class Cls:
            def __init__(self):
                self.A = super(Cls, self)

        class Cls2:
            def __init__(cls):
                self.A = super(Cls2, cls)
    """

    tree = ast.parse(assert_result)
    super_transformer = SuperWithoutArgumentsTransformer(tree)
    super_transformer.run()
    result = astor.to_source(tree)

    assert result == assert_expected

# Generated at 2022-06-23 23:17:16.355789
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    code = """
        class MyClass(object):
            def my_func(self):
                super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer.run_to_ast(tree)
    func_ = tree.body[0].body[0]
    assert type(func_.body[0].value.args[0]) is ast.Name
    assert func_.body[0].value.args[0].id == 'MyClass'
    assert type(func_.body[0].value.args[1]) is ast.Name
    assert func_.body[0].value.args[1].id == 'self'

# Generated at 2022-06-23 23:17:17.391055
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.fake_tree import FakeTree, Node
    tree = FakeTree()

# Generated at 2022-06-23 23:17:20.481735
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls:
        def method(self):
            super()
    """
    expected = """
    class Cls:
        def method(self):
            super(Cls, self)
    """
    # Run
    module, _ = run_transformer(SuperWithoutArgumentsTransformer, code)
    # Assert
    assert str(module) == expected

# Generated at 2022-06-23 23:17:25.593783
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import create_module

    tree = create_module('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    super()
    transformer.run()
    assert transformer.result_tree.body[0].value.value.args == [
        ast.Name(id='Cls', ctx=ast.Load()),
        ast.Name(id='self', ctx=ast.Load()),
    ]

# Generated at 2022-06-23 23:17:35.775000
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    func = ast.FunctionDef(name='test', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)],
                                                           vararg=None, kwonlyargs=[], kw_defaults=[],
                                                           kwarg=None, defaults=[]),
                         body=[node],
                         decorator_list=[],
                         returns=None)

    cls = ast.ClassDef(name='Test', bases=[], keywords=[], body=[func], decorator_list=[])

    result = list(ast.walk(SuperWithoutArgumentsTransformer().visit(cls)))
    assert len(result) == 4
    assert result[0].__class__ is ast.ClassDef
    assert result[1].__class__ is ast.FunctionDef
    assert result

# Generated at 2022-06-23 23:17:42.845129
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from ..utils import compile_source

    code = textwrap.dedent('''
    class A:
        def __init__(self):
            super()
            self.x = super()
            
    ''')

    module = compile_source(code, __name__, SuperWithoutArgumentsTransformer)
    assert module is not None

    first_super = module.body[0].body[0].value
    assert isinstance(first_super, ast.Call)

    second_super = module.body[0].body[1].value
    assert isinstance(second_super, ast.Call)

# Generated at 2022-06-23 23:17:52.061608
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    x = 3
    y = 5
    tree = ast.parse('class Foo: def foo(self): super().bar(x)')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.ClassDef)
    assert isinstance(tree.body[0].body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast.Name)
    assert tree.body[0].body[0].body[0].value.func.id

# Generated at 2022-06-23 23:17:57.057204
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)
    node = ast.Call(
        func=ast.Name(id='super'),
        args=[],
        keywords=[],
    )
    new_node = transformer.visit_Call(node)
    assert new_node.args == [ast.Name(id='Cls'), ast.Name(id='self')]

# Generated at 2022-06-23 23:18:07.279535
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    from typed_ast import ast3 as ast
    from .._transformer_registry import TransformerRegistry

    class Outer:
        class Inner:
            def method(self):
                super()
            def other_method():
                super()
            @classmethod
            def cm(cls):
                super()
            @staticmethod
            def sm():
                super()

        def func(self):
            super()

    tree = ast.parse(dedent('''\
        class MyCls:
            def func(self):
                super()
            def other_method():
                super()
            @staticmethod
            def sm():
                super()
            @classmethod
            def cm(cls):
                super()
        '''))

    # When
    tr = TransformerRegistry()

# Generated at 2022-06-23 23:18:08.331946
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:09.303082
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:11.014783
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-23 23:18:14.148380
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from . import TransformationError
    from .utils import should_raise
    
    class SuperNaT(SuperWithoutArgumentsTransformer): pass

    # this should not raise

# Generated at 2022-06-23 23:18:22.874694
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from .base import Module

    code = '''
        class A:
            def __init__(self):
                super()
    
        class B:
            def __init__(self):
                super()

            @staticmethod
            def name():
                super()

            @classmethod
            def type(cls):
                super()

            @property
            def test(self):
                pass

        class C:
            def __init__(self, a: int):
                super()

            def method(self, b: int):
                super()

        class D(C):
            def __init__(self, a=0, b=0):
                super()

            def method(self, b: int):
                super()
        '''


# Generated at 2022-06-23 23:18:24.661311
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test method visit_Call of class SuperWithoutArgumentsTransformer
    """

# Generated at 2022-06-23 23:18:28.975431
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.nodetree import NodeTree

    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])


# Generated at 2022-06-23 23:18:35.698539
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    class A:
        def f(self):
            super()
    """

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).visit()
    result = compile(tree, '', 'exec')
    ns = {}
    exec(result, ns)
    assert ns['A'].__qualname__ == 'A'
    assert ns['A'].f.__qualname__ == 'A.f'
    try:
        ns['A']().f()
    except TypeError:
        pass  # OK
    else:
        assert False

# Generated at 2022-06-23 23:18:45.258743
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast3 import parse
    from ..exceptions import UnsupportedCallArgument

    tree = parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    node = tree.body[0].value
    transformer.visit(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Attribute)
    assert isinstance(node.func.value, ast.Name)
    assert isinstance(node.func.attr, ast.Name)
    assert node.func.value.id == 'super'
    assert node.func.attr.id == '__new__'
    with pytest.raises(UnsupportedCallArgument):
        transformer.visit(node)


# Generated at 2022-06-23 23:18:54.984276
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Cls(object):
        def f(self):
            return super()

    module = ast.parse(inspect.getsource(Cls))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(module)

    for node in ast.walk(module):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'super':
            assert len(node.args) == 2
            assert isinstance(node.args[0], ast.Name) and node.args[0].id == 'Cls'
            assert isinstance(node.args[1], ast.Name) and node.args[1].id == 'self'
            break
    else:
        assert False, 'super() not found'

# Generated at 2022-06-23 23:19:03.447250
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import cast
    from typing import List
    from astunparse import unparse
    from .node_tools import node_string_equals

    transform = SuperWithoutArgumentsTransformer()

    # Test simple function
    code = """
        class C:
            def __init__(self):
                super()

    """
    tree = ast.parse(code)
    transform.visit(tree)
    code_transformed = unparse(cast(List[ast.stmt], tree.body[0].body))
    assert node_string_equals(code_transformed, """
        class C:
            def __init__(self):
                super(C, self)
    """)

    # Test simple function
    code = """
        class C:
            def __init__(self):
                super(arg)

    """

# Generated at 2022-06-23 23:19:04.212156
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:09.292727
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """
super()
"""
    module = ast.parse(text=source)
    SuperWithoutArgumentsTransformer().visit(node=module)
    assert ast.dump(node=module) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))])"

# Generated at 2022-06-23 23:19:14.390442
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing_utils import generate_code
    from ..errors import UnsupportedFeature
    from .test_helpers import build_and_run_passes

    class TestPass(BasePass):
        def visit_ClassDef(self, node: ast.ClassDef):
            node.bases.append(ast.Name(id='Parent'))
            return node


# Generated at 2022-06-23 23:19:21.698094
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.helpers import compare_source

    src1 = 'super()'
    src2 = 'super(Cls, self)'
    tree = source_to_ast(src1)
    cls = ast.ClassDef(name='Cls', body=[ast.FunctionDef(name='foo', body=[ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))])])
    tree.body.append(cls)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    src = ast_to_source(tree)
    compare_source(src, src2)

# Generated at 2022-06-23 23:19:22.309600
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:31.216877
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert tree_to_str(tree) == "super(Cls, cls)"

    tree = ast.parse('super(foo)')
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit(tree)
    assert transformer._tree_changed is False
    assert tree_to_str(tree) == "super(foo)"

    tree = ast.parse('""")\nsuper()\n"""')
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit(tree)
    assert transformer._tree_changed is False

# Generated at 2022-06-23 23:19:33.238904
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:19:41.345559
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_equal_ignore_ws

    src = """
        super()
    """

    expected = """
        super(Foo, self)
    """

    # NodeTransformer does not have a public API to set the tree,
    # so we have to monkeypatch it
    import types
    def set_tree(self, tree: ast.AST) -> None:
        self._tree = tree

    SuperWithoutArgumentsTransformer.set_tree = types.MethodType(set_tree, SuperWithoutArgumentsTransformer)

    class_node = ast.parse("class Foo: pass").body[0]
    func_node = ast.parse("def foo(): super()").body[0]
    root = ast.parse(src)
    root.body.append(class_node)

# Generated at 2022-06-23 23:19:42.254485
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:19:44.208333
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerModule(SuperWithoutArgumentsTransformer):
        module = ModuleType('SuperWithoutArgumentsTransformerModule')


# Generated at 2022-06-23 23:19:47.247947
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unittest_transformer_support import transform_from_repl
    from ..transforms.superwithoutargument import SuperWithoutArgumentsTransformer
    from ..runtime import DummyContextManager


# Generated at 2022-06-23 23:19:57.101334
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    source = '''
        class Cls:
            def __init__(self):
                super()

            @classmethod
            def foo(cls):
                super()

            @staticmethod
            def bar():
                super()
        '''

    expected_1 = '''
        class Cls:
            def __init__(self):
                super(Cls, self)

            @classmethod
            def foo(cls):
                super(Cls, cls)

            @staticmethod
            def bar():
                super(Cls, cls)
        '''

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert str(tree) == expected_1

# Generated at 2022-06-23 23:20:04.319773
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    tree = ast.parse('class A(object):\n'
                     '  def run(self):\n'
                     '    super().run()\n')
    SuperWithoutArgumentsTransformer().visit(tree)


# Generated at 2022-06-23 23:20:15.511419
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing.utils import build_call, build_class, build_function, build_name, build_super

    class_node = build_class(
        build_method(build_call(build_super())),
        build_method(
            build_call(build_super()),
            name='clsmethod',
        ),
    )

    function_node = build_function(
        build_call(build_super()),
    )

    literal_node = build_call(build_super())

    assert list(SuperWithoutArgumentsTransformer(class_node).visit(class_node).body[0].body)[0].args == [
        build_name('Cls'),
        build_name('self'),
    ]