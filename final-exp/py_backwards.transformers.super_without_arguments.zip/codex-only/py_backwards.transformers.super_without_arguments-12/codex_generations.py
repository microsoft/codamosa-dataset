

# Generated at 2022-06-23 23:10:20.886231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    transformer = SuperWithoutArgumentsTransformer(None)

    # super() -> super(Cls, self)
    node = ast3.parse('super()')
    transformer.visit(node)
    assert str(node).strip('\n') == 'super(Cls, self)'

    # super(X, Y) -> super(X, Y)
    node = ast3.parse('super(X, Y)')
    transformer.visit(node)
    assert str(node).strip('\n') == 'super(X, Y)'

# Generated at 2022-06-23 23:10:27.144358
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for SuperWithoutArgumentsTransformer()"""

    node = ast.parse('''
        class Foo:
            def __init__(self):
                pass
            def Test(self):
                super()
    ''')
    t = SuperWithoutArgumentsTransformer(node)
    t.visit(node)
    assert(len(node.body[0].body[1].body[0].args) == 2)

# Generated at 2022-06-23 23:10:31.919887
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    code = """
    class Foo:
        def bar(self):
            super()
    """
    module_ast = ast.parse(code)
    t = SuperWithoutArgumentsTransformer(module_ast)
    t.visit(module_ast)
    assert astor.to_source(module_ast) == """
    class Foo:
        def bar(self):
            super(Foo, self)
    """

# Generated at 2022-06-23 23:10:32.816561
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:36.931721
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    expected = """super(Cls, self)"""
    assert astor.to_source(tree).strip() == expected


# Generated at 2022-06-23 23:10:41.646539
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='C', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))])"



# Generated at 2022-06-23 23:10:49.543639
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_restricted
    from . import parse

    ast_tree = parse("""
    class Foo():
        def meth1(self):
            super()
        def meth2(self):
            return super()
        @staticmethod
        def meth3():
            return super()
        @classmethod
        def meth4(cls):
            return super()
    """)

    expected_ast_tree = parse("""
    class Foo():
        def meth1(self):
            super(Foo, self)
        def meth2(self):
            return super(Foo, self)
        @staticmethod
        def meth3():
            return super(Foo, self)
        @classmethod
        def meth4(cls):
            return super(Foo, cls)
    """)

    gen = compile_restricted

# Generated at 2022-06-23 23:10:54.323444
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast
    transformer = SuperWithoutArgumentsTransformer(get_ast('super()'))
    node: ast.Call = transformer._tree.body[0].value

    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'



# Generated at 2022-06-23 23:11:03.163763
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    from typed_ast import ast27
    from ast_helper import get_ast
    from mypy_boto3_builder.type_annotations.fake import FakeAnnotations
    

# Generated at 2022-06-23 23:11:03.924191
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:04.729651
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:11.875515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests of SuperWithoutArgumentsTransformer
    """
    # Arrange
    import typed_ast.ast3 as ast
    from typed_ast.transforms.super_without_arguments import SuperWithoutArgumentsTransformer
    from typed_ast.py_ast_to_lamb import generate_lamb
    from typing import Any


# Generated at 2022-06-23 23:11:17.969513
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_str = '''
    class Test:
        def test1(self):
            super()
    '''
    actual_str = '''
    class Test:
        def test1(self):
            super(Test, self)
    '''
    test_tree = ast.parse(test_str)
    actual_tree = ast.parse(actual_str)
    SuperWithoutArgumentsTransformer().visit(test_tree)
    assert ast.dump(test_tree) == ast.dump(actual_tree)

# Generated at 2022-06-23 23:11:20.016760
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("super()")
    SuperWithoutArgumentsTransformer(node).recursive_run()



# Generated at 2022-06-23 23:11:27.782427
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse
    from copy import copy
    from ..utils.trees import ASTNodeFactory

    node_factory = ASTNodeFactory()
    node_factory.create_subscription = True


# Generated at 2022-06-23 23:11:29.678126
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast, compare_ast
    global_ns = {}

# Generated at 2022-06-23 23:11:40.210784
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..compat import builtins
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import cst

    tree = ast.parse(cst('''
        class A:
            def __init__(self):
                super()
    '''))
    fun = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    transformer = SuperWithoutArgumentsTransformer(
        tree,
        builtins.Builtins(),
    )

    tree = transformer.visit(tree)
    assert tree.body[0].body[0].args[0].id == 'A'

# Generated at 2022-06-23 23:11:45.805547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Compile function without arguments
    def test_func():
        super().__str__()

    tree = ast.parse(inspect.getsource(test_func))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(test_func, self).__str__()' in astor.to_source(tree).strip()

    # Compile function with one static argument
    def test_func_2(arg):
        super().__str__()

    tree = ast.parse(inspect.getsource(test_func_2))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(test_func_2, self).__str__()' in astor.to_source(tree).strip()

    # Compile function with one static argument and one dynamic argument

# Generated at 2022-06-23 23:11:54.130813
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer"""
    import unittest
    import inspect
    import ast
    import astunparse

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def _compile_source(self, source: str) -> ast.Module:
            return compile(source, '<string>', 'exec')

        def test_visit_Call(self):
            transformer = SuperWithoutArgumentsTransformer()

            # Tests are taken from docs

# Generated at 2022-06-23 23:11:58.089243
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit(node)
    assert str(node) == 'super(Cls, self)'

# Generated at 2022-06-23 23:11:58.804557
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:01.800899
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test that the SuperWithoutArgumentsTransformer works as expected
    """

    # Add an import statement to test that the function adds the import when necessary

# Generated at 2022-06-23 23:12:08.402210
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import roundtrip
    from typed_ast import ast3 as ast

    class Dummy(ast.AST):
        _fields = ('func', 'args')

    class Dummy2(ast.AST):
        _fields = ('name', )

    func_def = Dummy(func=Dummy2(name='super'), args=[])
    class_def = Dummy2(name='Cls')
    func = Dummy2(name='func')

# Generated at 2022-06-23 23:12:10.176402
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""


# Generated at 2022-06-23 23:12:14.912895
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_str = """
    super()
    """
    code_ast = ast.parse(code_str)
    SuperWithoutArgumentsTransformer(code_ast).visit(code_ast)
    code_gen = compile(code_ast, '', 'exec')
    eval(code_gen)

# Generated at 2022-06-23 23:12:15.494306
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:22.099378
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ...utils.testing import check_transform, test_transform, check_ok
    from . import base

    # class Foo(object):
    #     def __init__(self):
    #         super()

# Generated at 2022-06-23 23:12:23.457680
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_str

# Generated at 2022-06-23 23:12:25.223442
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as a
    from typed_ast import parse

# Generated at 2022-06-23 23:12:25.822353
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:31.352082
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer=SuperWithoutArgumentsTransformer(None)
    input = ast.parse("super()").body[0]
    input.lineno = 0
    input.col_offset = 0
    expected = ast.parse("super(cls, cls)").body[0]
    expected.lineno = 0
    expected.col_offset = 0
    actual = transformer.visit_Call(input)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 23:12:41.327762
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import test_utils
    from typed_ast import ast3 as ast

    code = """
    class Foo:
        def method(self):
            super()
    """
    module_node = test_utils.build_module(code, __name__)
    transformer = SuperWithoutArgumentsTransformer()
    new_module = transformer.visit(module_node)

    assert transformer.tree_changed is True
    assert transformer.code_changed is False
    assert type(new_module.body[0].body[0].body[0].value) is ast.Call
    assert new_module.body[0].body[0].body[0].value.func.id == 'super'
    assert type(new_module.body[0].body[0].body[0].value.args[0]) is ast.Name
    assert new_

# Generated at 2022-06-23 23:12:46.351866
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import parse
    from ..utils.helpers import compare_source
    code = """
        super().method()
    """
    tree = parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    result = compare_source(tree, """
        super(Cls, cls).method()
    """)
    assert result



# Generated at 2022-06-23 23:12:53.887200
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:00.998566
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context

    source = 'super()'
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(Context(), source, tree)
    new_tree = transformer.visit(tree)
    assert new_tree.body[0].value.args[0].id == 'Cls'
    assert new_tree.body[0].value.args[1].id == 'self'

# Generated at 2022-06-23 23:13:01.840113
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:13:05.417978
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()', '<test>', 'eval').body
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert 'super(Cls, self)' == astor.to_source(node).strip()

# Generated at 2022-06-23 23:13:06.564319
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:14.430681
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code_equals
    assert_transformed_code_equals(
        """
        class MyClass(object):
            def __init__(self):
                super().f()
            def __something__(self):
                super().f()
        """,
        """
        class MyClass(object):
            def __init__(self):
                super(MyClass, self).f()
            def __something__(self):
                super(MyClass, self).f()
        """
    )

# Generated at 2022-06-23 23:13:22.612830
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
        class A:
            def __init__(self):
                super().__init__()
    """
    tree = ast.parse(source)
    Transformer = SuperWithoutArgumentsTransformer(tree)
    Transformer.visit(tree)

# Generated at 2022-06-23 23:13:23.642523
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:32.010677
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(node)
    new = transformer.visit(node)

    assert new.body[0].value.func.id == 'super'
    assert isinstance(new.body[0].value.args[0], ast.Name)
    assert new.body[0].value.args[0].id == 'Cls'
    assert isinstance(new.body[0].value.args[1], ast.Name)
    assert new.body[0].value.args[1].id == 'self'



# Generated at 2022-06-23 23:13:38.846954
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.source import Source
    from ..compiler import compile_src
    src = Source("""
    class A(object):
        def f(self):
            return super().f()
    """)
    t = compile_src(src, 3, validate_asts=False)
    s = SuperWithoutArgumentsTransformer()
    tree = ast.parse(str(t))
    tree = s.visit(tree)
    src2 = Source(t)
    assert src == src2
    assert s._tree_changed == True

# Generated at 2022-06-23 23:13:44.859876
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    ast_string = """super()"""
    node = ast.parse(ast_string)

    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit_Call(node.body[0].value)
    assert transformer.tree_changed

    ast.fix_missing_locations(node)
    assert ast.dump(node) == """Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None)"""



# Generated at 2022-06-23 23:13:47.966841
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code_before = 'super()'
    code_after = 'super(Cls, self)'

    tree = ast.parse(code_before)
    tree.body[0].func.value = ast.ClassDef(name='Cls', body=[])
    tree.body[0].func.args = [ast.Name(id='self', ctx=ast.Param())]

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree.body[0])

    assert code_after == astor.to_source(tree)

# Generated at 2022-06-23 23:13:52.633047
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.fake_grammar import make_call_node
    from .. import transforms
    
    
    class SuperWithoutArgumentsTransformerWrapper(transforms.SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree_changed = False


# Generated at 2022-06-23 23:13:55.290306
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.helpers import make_together

# Generated at 2022-06-23 23:14:00.247863
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_str
    from ..utils.helpers import assert_code_equal

    code = 'super()'
    expected_code = 'super(__class__, self)'
    
    tree = compile_str(code, '<test>', 'exec')
    
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    
    assert_code_equal(tree, expected_code)

# Generated at 2022-06-23 23:14:00.763197
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:01.824634
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from .. import tree
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:14:06.191166
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    code = """
    class X:
        def __init__(self):
            super()
    """
    expected = """
    class X:
        def __init__(self):
            super(X, self)
    """

    module = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(module)
    actual = astor.to_source(module)

    assert actual == expected

# Generated at 2022-06-23 23:14:11.188390
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import assert_equal_ignore_ws

    code = """class A:
        def run(self):
            super()
    """

    assert_equal_ignore_ws(
        SuperWithoutArgumentsTransformer().visit(ast.parse(code)),
        """class A:
        def run(self):
            super(A, self)
    """
    )

# Generated at 2022-06-23 23:14:21.812957
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Tests that SuperWithoutArgumentsTransformer.visit_Call()
    replaces super() without argument by super(cls, self) or super(cls, cls)
    """
    class Transformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree : ast.AST) -> None:
            super().__init__(tree)
            self.func_count = 0
            self.added_args_count = 0

        @classmethod
        def _replace_super_args(
            cls,
            node : ast.Call
        ) -> None:
            node.args = [ast.Name(id="Test"), ast.Name(id="Test")]
            cls.added_args_count += 1


# Generated at 2022-06-23 23:14:26.923580
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class A:
        def m1(self):
            super()
    """

    expect_output = """
    class A:
        def m1(self):
            super(A, self)
    """

    output = compile(input, '', 'exec')
    output = str(ast.fix_missing_locations(output))
    output = output.strip()

    assert output == expect_output.strip()

# Generated at 2022-06-23 23:14:28.394571
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from .. import dumptree
    from .. import dumpcode


# Generated at 2022-06-23 23:14:38.157115
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import unparse
    from ..utils.tree import build_ast

    nodes = [
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                   value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()),
                                  args=[], keywords=[], starargs=None, kwargs=None)),

        ast.Call(func=ast.Name(id='super', ctx=ast.Load()),
                 args=[], keywords=[], starargs=None, kwargs=None)
    ]

    expected = [
        'a = super(__class__, self)',
        'super(__class__, self)'
    ]

    tree = build_ast(nodes)

# Generated at 2022-06-23 23:14:38.841588
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:43.317261
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find_all_instances_of, get_closest_parent_of
    from ...basic import STATICMETHOD_BODY_IS_SUITABLE
    from typing import List


# Generated at 2022-06-23 23:14:44.483752
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:53.587807
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Without self
    before = """
        class Cls(object):
            def method(self):
                s = super()
    """
    after = """
        class Cls(object):
            def method(self):
                s = super(Cls, self)
    """
    assert SuperWithoutArgumentsTransformer(before).result == after

    # With self
    before = """
        class Cls(object):
            def method(self):
                s = super(self)
    """
    after = """
        class Cls(object):
            def method(self):
                s = super(Cls, self)
    """
    assert SuperWithoutArgumentsTransformer(before).result == after

    # Without self and cls

# Generated at 2022-06-23 23:14:56.304893
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast_helper import ast_to_text
    from typed_ast.ast3 import parse
    from . import apply_transformer


# Generated at 2022-06-23 23:14:56.907342
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:14:58.754265
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_code_equal


# Generated at 2022-06-23 23:15:07.712885
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    class NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.nodes = {"Call":[]}
            self.types = []
        
        def visit(self, node):
            self.types.append(type(node))
            if isinstance(node, ast.Call):
                self.nodes["Call"].append(node)
            super().generic_visit(node)


    visitor = NodeVisitor()
    tree = ast.parse('super()')
    visitor.visit(tree)
    assert len(visitor.nodes["Call"]) == 1
    assert len(visitor.types) == 2
    assert visitor.types[0] == ast.Module
    assert visitor.types[1] == ast.Expr

    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-23 23:15:16.590775
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # super()
    node = ast.parse('super()')
    invalid = node.body[0]
    assert_equals(invalid.value.func.id, 'super')
    assert_equals(len(invalid.value.args), 0)

    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit(node)

    assert_equals(invalid.value.func.id, 'super')
    assert_equals(len(invalid.value.args), 2)
    assert_equals(invalid.value.args[0].id, 'Cls')
    assert_equals(invalid.value.args[1].id, 'self')

# Generated at 2022-06-23 23:15:25.746946
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import setup_ast_parser
    setup_ast_parser()
    from typed_ast import ast3
    from typed_ast import parse
    import os

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(cur_dir,'test_files/test_SuperWithoutArgumentsTransformer')
    fname = os.path.join(test_dir, 'test_fname.py')

    with open(fname, 'r') as f:
        input_code = f.read()


    node = parse(input_code)

    cnode = SuperWithoutArgumentsTransformer().visit(node)

    assert ast.dump(cnode) == ast.dump(parse(result_code))

# Generated at 2022-06-23 23:15:29.895564
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .common import _assert_ast, compile_to_ast
    source = 'class A: def f(x): super()'
    expected_ast = compile_to_ast(source)
    assert isinstance(expected_ast, ast.Module)
    t = SuperWithoutArgumentsTransformer()
    t.visit(expected_ast)
    _assert_ast(expected_ast, source)

# Generated at 2022-06-23 23:15:34.280020
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer(None)
    node = ast.parse(
        """
super()
        """
    )
    expected = ast.parse(
        """
super(Cls, self)
        """
    )
    node = t.visit_Call(node.body[0].value)
    assert ast.dump(node) == ast.dump(expected.body[0].value)

# Generated at 2022-06-23 23:15:44.510347
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing.utils import build_example_ast
    from ..testing.tester import assert_node_replacement
    from ..testing.example_code import python_code

    example_ast = build_example_ast(python_code)

# Generated at 2022-06-23 23:15:53.841447
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src

    tree = compile_src('super()')
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.ClassDef)
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.FunctionDef)
    assert len(tree.body[0].body[0].body) == 1
    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast.Name)

# Generated at 2022-06-23 23:15:55.143372
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    parsed = ast.parse("super()", "<test>", "exec")
    tree_changed, new_tree = SuperWithoutArgumentsTransformer().visit(parsed)
    assert compare_ast(parsed, new_tree) == True # type: ignore

# Generated at 2022-06-23 23:15:55.525816
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:56.780676
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer._replace_super_args('super()') == "super(cls, self)"

# Generated at 2022-06-23 23:15:57.806459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..transpile import transpile

# Generated at 2022-06-23 23:16:08.086385
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast

    tree = ast.parse("super(Foo, self)")
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == "Foo"
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == "self"

    tree = ast.parse("super(Foo, cls)")
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)

# Generated at 2022-06-23 23:16:09.942346
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from .. import dump


# Generated at 2022-06-23 23:16:11.952452
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Cls():
        def __init__(self):
            super()
    assert Cls()



# Generated at 2022-06-23 23:16:15.203740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(module)

    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].value.args[1], ast.Name)

# Generated at 2022-06-23 23:16:23.013166
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_string

    code = """
        class MyClass(object):
            def a(self):
                super()
            def b(cls):
                super()
    
    """

# Generated at 2022-06-23 23:16:32.325912
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    sys.path.append('.')
    import numpy as np
    from typed_ast import ast3 as ast
    from type_inference_programs.pythran_to_python.transformers import SuperWithoutArgumentsTransformer

    transformer = SuperWithoutArgumentsTransformer()

    # Test 1
    class TestCall:
        def __init__(self) -> None:
            class B:
                def __init__(self) -> None:
                    pass
                def foo(self) -> None:
                    pass
            class A(B):
                def __init__(self) -> None:
                    super().__init__()

                def foo(self) -> None:
                    super(B, self).foo()
            pass

    tree: ast.AST = ast.parse(inspect.getsource(TestCall))
   

# Generated at 2022-06-23 23:16:33.686749
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typing
    import astor


# Generated at 2022-06-23 23:16:40.728784
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from json import loads
    from .. import transform

    src = '''
        class A(object):
            def __init__(self):
                super().__init__()
                return super()
    '''
    expected_result = '''
        class A(object):
            def __init__(self):
                super(A, self).__init__()
                return super(A, self)
    '''
    tree = ast.parse(src)
    transform(tree, SuperWithoutArgumentsTransformer)
    result = compile(tree, '', 'exec')
    result = loads(repr(result))
    expected_result = loads(repr(expected_result))
    assert expected_result == result

# Generated at 2022-06-23 23:16:51.292644
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree):
            self.result = None
            self.tree = tree
            super().__init__(tree)
    

# Generated at 2022-06-23 23:16:55.553047
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
    class A:
        def __init__(self):
            super()
    '''
    expect_code = '''
    class A:
        def __init__(self):
            super(A, self)
    '''

    # when
    actual_code = SuperWithoutArgumentsTransformer().visit(ast.parse(code))

    # then
    assert ast.dump(ast.parse(expect_code)) == ast.dump(actual_code)

# Generated at 2022-06-23 23:16:56.712241
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformerTest
    

# Generated at 2022-06-23 23:17:00.822769
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    source = """
    class C:
        def __init__(self):
            super()
        
        def foo(self):
            super()
    """

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected = """
    class C:
        def __init__(self):
            super(C, self)
        
        def foo(self):
            super(C, self)
    """

    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:17:01.460184
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-23 23:17:02.116945
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:12.817938
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import astunparse
    import sys
    from python2to3.fixer_base import BaseFix
    from python2to3.main import StdoutRefactoringTool

    class NullFix(BaseFix):
        def match(self, node):
            return False

        def transform(self, node, results):
            return node

    class Main(StdoutRefactoringTool):
        def refactor(self, files, fixer_names, options):
            super(Main, self).refactor(files, fixer_names, options)

        def print_output(self):
            for i in self.output:
                print(i)

    rt = Main([NullFix(None)], {'print_function': True}, {'print_function': True}, None, True)


# Generated at 2022-06-23 23:17:13.713742
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:17:18.698118
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    sample = astor.code_to_ast(
        '''
        class Foo:
            def __init__(self):
                super().__init__()
        ''', 
        return_ast=True
    )
    transformer = SuperWithoutArgumentsTransformer(sample)
    transformer.visit()
    output = astor.to_source(sample).strip()

    assert output == 'class Foo:\n    def __init__(self):\n        super(Foo, self).__init__()'



# Generated at 2022-06-23 23:17:24.293609
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import load_module_for_xformation

    code_before = """
    class Cls:
        def __init__(self):
            super()
    """

    code_after = """
    class Cls:
        def __init__(self):
            super(Cls, self)
    """
    ast_before = load_module_for_xformation(code_before)
    ast_after = load_module_for_xformation(code_after)
    transformer = SuperWithoutArgumentsTransformer(ast_before)
    transformer.visit(ast_before)
    assert astor.to_source(ast_before) == code_after

# Generated at 2022-06-23 23:17:34.594258
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_utils import generate_ast

    source1_tree = generate_ast("super()")
    source2_tree = generate_ast("super(self)")
    source3_tree = generate_ast("super(Cls, self)")
    
    class TestClass(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                no1 = ast.Name(id = "Cls")
                node.args = [no1, ast.Name(id = "self")]
                return node
    
    SuperWithoutArgumentsTransformer.visit_Call(TestClass(), source1_tree)

# Generated at 2022-06-23 23:17:42.765515
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input = """
foo()
super()
    """
    expected = """
foo()
super(Cls, self)
    """
    tree = ast.parse(input)
    cls = ast.ClassDef(name='Cls', body=[ast.FunctionDef(name='foo', args=ast.arguments(), body=[])])
    tree.body.insert(0, cls)
    tree.body.append(ast.FunctionDef(name='foo', args=ast.arguments(), body=[ast.Expr(ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))]))
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:17:44.140540
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.helpers import get_func_ast


# Generated at 2022-06-23 23:17:44.845021
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:48.974861
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def test(self):
            super(A)
    """

    tree = ast.parse(code)
    new_tree = SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(new_tree, "<test>", "exec"))  # noqa

# Generated at 2022-06-23 23:17:55.354907
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor  # type: ignore
    import sys
    from ..utils.ast_builder import build_ast

    code: str = 'super()'
    sys.version_info = (3, 7, 2)
    root: ast.Module = build_ast(code)

    transformer: SuperWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer()
    transformer.visit(root)

    assert astor.to_source(root) == 'super(<unknown>, self)'

# Generated at 2022-06-23 23:17:56.360963
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:06.647985
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_isolated
    from yatiml.tests.utils import dump_ast_tree

    class SuperWithoutArgumentsTransformerTest(SuperWithoutArgumentsTransformer):
        _tree_changed = False
        _tree = None

        def _replace_super_args(self, node: ast.Call):
            node.args = [ast.Name(id='FakeName')]

    source = """
        class SuperTest(Super):
            def __init__(self, arg):
                super().__init__()

        class Parent:
            def __init__(self):
                super().__init__()
    """


# Generated at 2022-06-23 23:18:11.651913
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_equal
    assert_code_equal(
        '''
        class Foo:
            def bar(self):
                super().bar()
        ''',
        '''
        class Foo:
            def bar(self):
                super(Foo, self).bar()
        ''',
        transformers=[SuperWithoutArgumentsTransformer]
    )

# Generated at 2022-06-23 23:18:12.211276
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:18.989761
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    import inspect

    class Super(ast.AST):
        _fields = ('value',)
        value = None

    class ClsArg(ast.AST):
        _fields = ('arg',)
        arg = None

    class FuncArg(ast.AST):
        _fields = ('arg',)
        arg = None

    class Args(ast.AST):
        _fields = ('args',)
        args = None

    class FunctionDef(ast.AST):
        _fields = ('args',)
        args = None

    class ClassDef(ast.AST):
        _fields = ('name',)
        name = None

    class Call(ast.AST):
        _fields = ('func', 'args')
        func = None
        args = None



# Generated at 2022-06-23 23:18:20.562506
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 23:18:21.727682
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:18:32.412520
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target = (2, 7)
        transformer = SuperWithoutArgumentsTransformer

        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.transformer_class = self.transformer

        def test_super_with_args(self):
            node = ast.parse('super(A, B)')
            self.check_not_changed(node)

        def test_super_without_args(self):
            node = ast.parse('def f():\n\tsuper()')
            expected = 'def f():\n\tsuper(Cls, self)'
            self.check(node, expected)

    Test.main()

# Generated at 2022-06-23 23:18:36.411842
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:18:40.106875
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    code = '''
        def bar():
            super()
    '''

    ast = source_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast)
    assert transformer.tree_changed

# Generated at 2022-06-23 23:18:44.346666
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_code_equal

    code = 'super()'
    expected = 'super(Cls, self)'

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(2, 7).visit(tree)
    assert_code_equal(expected, tree)

# Generated at 2022-06-23 23:18:52.476084
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """\
super()"""
    exp_res = """\
super(Cls, self)"""
    check_transformer(SuperWithoutArgumentsTransformer, code, exp_res, is_class=True)

    code = """\
super()"""
    exp_res = """\
super(Cls)"""
    check_transformer(SuperWithoutArgumentsTransformer, code, exp_res, is_method=False)

    code = """\
super()"""
    exp_res = """\
super()"""
    check_transformer(SuperWithoutArgumentsTransformer, code, exp_res)

# Generated at 2022-06-23 23:18:56.147933
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super()
    node = ast.parse('super()', mode='eval')

    actual = SuperWithoutArgumentsTransformer().visit(node)
    expected = ast.parse('super(cls, self)', mode='eval')

    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 23:19:04.505499
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    global_ns = ast.parse('class A: pass')
    local_ns = {}
    SuperWithoutArgumentsTransformer(global_ns, local_ns).visit(global_ns)
    exec(compile(global_ns, filename="", mode="exec"), local_ns)
    assert isinstance(local_ns['A'], type)

    global_ns = ast.parse('class A: def f(self): super()')
    local_ns = {}
    SuperWithoutArgumentsTransformer(global_ns, local_ns).visit(global_ns)
    exec(compile(global_ns, filename="", mode="exec"), local_ns)
    assert isinstance(local_ns['A'], type)

    global_ns = ast.parse('class A: def f(self): pass')
    local_ns = {}


# Generated at 2022-06-23 23:19:08.626958
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u

    test_cases = [
        u("super")
    ]

    for code in test_cases:
        tree = ast.parse(code)
        SuperArgumentsTransformer(tree).visit(tree)

        assert u(tree) == u("super(Cls, self)")

# Generated at 2022-06-23 23:19:11.940010
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_transformation
    assert_transformation(SuperWithoutArgumentsTransformer,
                          'super()',
                          'super(__name__, __name__)',
                          type='module',
                          )

# Generated at 2022-06-23 23:19:12.959868
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:19.640534
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..node_transformer import NodeTransformer
    import pprint

    source = '''
    class Cls:
        def __init__(self):
            super()
    '''
    tree = ast.parse(source)

    transformer = NodeTransformer()
    transformer.visit(tree)

    target = '''
    class Cls:
        def __init__(self):
            super(Cls, self)
    '''
    target_tree = ast.parse(target)

    assert ast.dump(tree) == ast.dump(target_tree)

# Generated at 2022-06-23 23:19:20.837159
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    assert(t.target == (2, 7))

# Generated at 2022-06-23 23:19:21.570260
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:22.471543
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    c1 = "super()"

# Generated at 2022-06-23 23:19:23.566050
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:19:31.801464
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from astor.code_gen import to_source
    from typed_ast.ast3 import parse
    import re

    code = '''class A:
    def __init__(self, x):
        super()
    def foo(self):
        super()'''

    expected = '''class A:
    def __init__(self, x):
        super(A, self)
    def foo(self):
        super(A, self)'''

    parsed = parse(code)
    SuperWithoutArgumentsTransformer().visit(parsed)

    assert to_source(parsed) == re.sub(r'<.*>', '', to_source(parse(expected)))



# Generated at 2022-06-23 23:19:33.487851
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:38.461804
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    from aiida_verdi.utils.aiidadb import get_migrator
    migrator = get_migrator(silent=True)

    class DummySuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        _tree = migrator.migration_script._trees[0]

    # When
    transformer = DummySuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:19:39.108162
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:40.258944
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..transpile import Transpiler


# Generated at 2022-06-23 23:19:42.114313
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    from ..utils.helpers import generate_code_for_ast_node
    from ..utils.compatibility import module_type_store
    from .. import refactor
    from ..refactor import RefactoringTool


# Generated at 2022-06-23 23:19:51.998772
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ... import compile_to_ast as to_ast
    from .super import SuperTransformer
    # Setup code
    def func1():
        super()

    def func2():
        super()
        super()

    def func3():
        super().__init__()
        super().method()

    def func4():
        super(Cls, self).__init__()
        super(Cls, self).method()

    tree1 = to_ast(''.join(inspect.getsourcelines(func1)[0]))
    tree2 = to_ast(''.join(inspect.getsourcelines(func2)[0]))
    tree3 = to_ast(''.join(inspect.getsourcelines(func3)[0]))

# Generated at 2022-06-23 23:19:54.770946
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import test
    from .test_base import BaseTestTransformer

    class Test(BaseTestTransformer):
        transformer = SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:59.190622
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ...parse import parse
    transformer = SuperWithoutArgumentsTransformer()
    tree = parse(''' 
    class Cls:
        def method(self):
            super()
    ''')
    transformer.visit(tree)

# Generated at 2022-06-23 23:20:00.149328
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:02.444909
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:13.788809
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    original_tree = ast.parse(u'''
    class A:
        def __init__(self):
            self.a = super() # 1

        def b(self):
            self.a = super()

    class B:
        def __init__(self):
            super() # 2

    class C(A):
        def __init__(self):
            super() # 1

        def b(self):
            self.a = super()

    class D(B):
        def __init__(self):
            super() # 2

        def b(self):
            self.a = super()
    ''')

    tree = SuperWithoutArgumentsTransformer.run(original_tree)

# Generated at 2022-06-23 23:20:25.147015
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import builtins
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from ...utils.helpers import get_node_of_class
    from ...utils.tree import node_to_str

    from .base import BaseNodeTransformer
    from .base import get_default_tree

    class DummyTransformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__(tree=get_default_tree())

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self._replace_super_args(node)
                return self.generic_visit(node)
