

# Generated at 2022-06-23 23:10:22.784531
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_code_writer import SourceCodeWriter
    from ..utils.helpers import get_ast_tree, dump_ast


# Generated at 2022-06-23 23:10:31.563481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    node = ast.parse('''
        class Cls:
            def __init__(self):
                super()
    ''')
    transformer.visit(node)
    assert transformer._tree_changed == True
    assert isinstance(node.body[0].body[0].body[0].args[0], ast.Name)
    assert node.body[0].body[0].body[0].args[0].id == 'Cls'
    assert isinstance(node.body[0].body[0].body[0].args[1], ast.Name)
    assert node.body[0].body[0].body[0].args[1].id == 'self'


# Generated at 2022-06-23 23:10:40.891035
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pyversion = (3, 7)

    from typed_ast import ast3 as ast  # noqa
    from ..utils.ast_factory import ast_call
    from ..utils.ast_factory import ast_function_def
    from ..utils.ast_factory import ast_class_def

    tree: ast.Module = ast.Module([
        ast_class_def('Cls'),
        ast_function_def('f', args=[ast.arg('self', None)], body=[
            ast_call('super'),
        ]),
    ])


# Generated at 2022-06-23 23:10:48.522561
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()),
                    args=[], keywords=[], starargs=None, kwargs=None)
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree=None, future_features=None)
    super_without_arguments_transformer.visit_Call(node=node)
    assert super_without_arguments_transformer._tree_changed == True
    assert node == ast.Call(func=ast.Name(id='super', ctx=ast.Load()),
                            args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[], starargs=None, kwargs=None)

# Generated at 2022-06-23 23:10:56.981829
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class SuperClass:
            pass
        
        class Test(SuperClass):
            def test(self):
                super()
                pass
    '''
    expected_code = '''
        class SuperClass:
            pass
        
        class Test(SuperClass):
            def test(self):
                super(Test, self)
                pass
    '''
    tree = ast.parse(textwrap.dedent(code))
    trans = SuperWithoutArgumentsTransformer(tree)
    trans.run()
    assert trans._tree_changed
    new_code = astunparse.unparse(tree)
    assert new_code == expected_code

# Generated at 2022-06-23 23:11:04.965223
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object, source_to_ast
    from ..utils.helpers import assert_equal, print_result

    code = '''
super()
'''

    expected_code = '''
super(__main__, __main__)
'''

    code_obj = source_to_code_object(code)
    tree = source_to_ast(code)

    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    result_code_obj = compile(new_tree, '<string>', 'exec')

    assert_equal(expected_code, result_code_obj)

    print_result(code, expected_code, result_code_obj)


# Generated at 2022-06-23 23:11:12.058415
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import astunparse
    from collections import deque

    from typed_ast import ast3 as ast
    from ..utils.tree import get_all_of

    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        CODE = """
        class A:
            def f(self):
                super()
            def g(self):
                super
        """

        def test_super(self):
            tree = ast.parse(self.CODE)
            transformer = SuperWithoutArgumentsTransformer(tree, {'A'})
            transformer.run()
            print(astunparse.dump(tree))

            call = deque(get_all_of(tree, ast.Call))[0]
            func = call.func
            self.assertIsInstance(func, ast.Attribute)

# Generated at 2022-06-23 23:11:13.077394
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:11:13.657794
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:14.585009
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:15.882902
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast_helpers import parse, assert_equal_ast

# Generated at 2022-06-23 23:11:24.949222
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from tree_sitter import Language, Parser, Node

    code = '''
        class A:
            def __init__(self):
                super()
    '''
    tree = Parser().parse(Language('python'), code)

    SuperWithoutArgumentsTransformer().visit(tree.root_node)
    expected = []
    actual = []
    for node in tree.root_node.descendants:
        if node.type == 'function_call':
            if len(node.children) == 3:
                actual.append(node.children[2])
                expected.append(Node(tree._language, 'Name', [0,3], [0,3], b'A', None))
                actual.append(node.children[1])

# Generated at 2022-06-23 23:11:35.976492
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    import unittest

    class TestCase(unittest.TestCase):
        pass
    f = open("test.py", "r")
    sample_code = f.read()
    f.close()
    sample_tree = ast.parse(sample_code)
    sample_transformer = SuperWithoutArgumentsTransformer(sample_tree)
    sample_transformer.visit(sample_tree)

    with open('output.txt', 'w') as output_file:
        output_file.write(astor.to_source(sample_tree))

    f = open("output.txt", "r")
    sample_code = f.read()
    f.close()
    expected_code = ""
    with open("expected.py", "r") as expected_file:
        expected_code = expected_file

# Generated at 2022-06-23 23:11:44.672860
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    class A:
        def __init__(self, x):
            super()
            super(int, cls).__init__(x)  # this shouldn't be transformed
    """

    tree = ast.parse('super()')
    funcdef = tree.body[0]
    node = funcdef.body[0]
    node.args = []
    funcdef.args.args = [ast.arg(arg='a', annotation=None)]
    cls = ast.ClassDef(name='A', bases=[], keywords=[], body=[funcdef], decorator_list=[])
    cls.body[0].decorator_list = []
    tree = ast.Module(body=[cls])
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)


# Generated at 2022-06-23 23:11:48.089760
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class F(ast.NodeVisitor):
        def generic_visit(self, node: ast.Call) -> ast.Call:
            return node


# Generated at 2022-06-23 23:11:50.882810
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...parsers.python import PythonParser
    from .base import BaseNodeTransformerTestCase


# Generated at 2022-06-23 23:11:58.171682
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    a = ast.parse('super()', '<test>', 'exec')
    cls = ast.ClassDef(name='C', body=[ast.FunctionDef(name='__init__', args=ast.arguments(args=[ast.Name(id="self", ctx=ast.Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))], decorator_list=[], returns=None)])
    body = cls.body
    cls.body = []
    tree = ast.Module(body=[cls] + body)
    orig = astor.to_source(tree)


# Generated at 2022-06-23 23:12:01.335728
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import sys
    import io
    import unittest


# Generated at 2022-06-23 23:12:03.535524
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import parse_ast_tree
    from ..utils.node_test import NodeTest

# Generated at 2022-06-23 23:12:04.109795
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:09.145327
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Arrange
    node_tree = ast.parse('super()')

    # Arrange - Act
    SuperWithoutArgumentsTransformer(node_tree).visit(node_tree)

    # Assert
    expected_tree = ast.parse('super(MyClass, self)')
    assert ast.dump(node_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:12:10.508860
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:18.576942
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from nth_compat_ast import parse

    tree = parse('super()')
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert node.func.id == 'super'
    assert not node.args

    SuperWithoutArgumentsTransformer().visit(tree)

    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert node.func.id == 'super'
    assert len(node.args) == 2
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'



# Generated at 2022-06-23 23:12:19.680885
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:30.162863
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    parser = ast.PyCF_ONLY_AST.parse
    node = parser("""
        class D(C):
            def f(self):
                super()
    """, filename="<ast>")
    node = SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-23 23:12:30.804105
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:38.574803
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def test_func():
        super()
    
    class TestClass(object):
        def test_method(self):
            super()

    class TestClass2(TestClass):
        pass

    transformers = [
        SuperWithoutArgumentsTransformer
    ]
    expected = [
        """def test_func():
    super(TestClass2, self)""",
        """class TestClass(object):
    def test_method(self):
        super(TestClass, self)"""
    ]
    result = get_transformed_code(transformers, [
        TestClass2, test_func
    ])
    assert expected == result

# Generated at 2022-06-23 23:12:39.492612
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:49.259628
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_code = dedent("""
    class Test:
        def __init__(self):
            super()
            print(super)
        @classmethod
        def __classmethod__(cls):
            super()
    """)

    expected_result = dedent("""\
    class Test:
        def __init__(self):
            super(Test, self)
            print(super)
        @classmethod
        def __classmethod__(cls):
            super(Test, cls)
    """)

    node = ast.parse(super_code)
    result = SuperWithoutArgumentsTransformer(tree=node, target=(2,7)).visit(node)
    assert ast.dump(node, include_attributes=True) == ast.dump(result, include_attributes=True)
    assert ast.dump

# Generated at 2022-06-23 23:12:53.894567
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        super()
        '''
    ast_tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer(tree=ast_tree)
    transformer.run()

    expected_code = '''
        super(Cls, self)
        '''
    compare_ast(ast_tree, expected_code)

# Generated at 2022-06-23 23:12:59.182078
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing import assert_transformation
    
    assert_transformation(
        SuperWithoutArgumentsTransformer,
        """
        class Foo:
            def bar(self):
                super()
        """,
        """
        class Foo:
            def bar(self):
                super(Foo, self)
        """
    )

# Generated at 2022-06-23 23:13:10.218021
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def run(tree: ast.AST) -> str:
        class T(ast.NodeTransformer):
            def visit_Name(self, node: ast.Name) -> ast.AST:
                return ast.Name(id=node.id.lower())

            def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
                node.name = node.name.lower()
                return self.generic_visit(node)

            def visit_ClassDef(self, node: ast.ClassDef) -> ast.AST:
                node.name = node.name.lower()
                return self.generic_visit(node)

        return SuperWithoutArgumentsTransformer(tree).visit(T().visit(tree)).as_string()

    def assert_code(before: str, after: str) -> None:
        assert run

# Generated at 2022-06-23 23:13:17.712399
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A(object):
            def __init__(self):
                super().__init__()

        class B(A):
            def __init__(self):
                super().__init__()
    """
    tree = ast.parse(code)
    super_trans = SuperWithoutArgumentsTransformer()
    super_trans.visit(tree)
    assert super_trans.tree_changed is True
    new_code = compile(tree, '', 'exec')
    exec(new_code)

# Generated at 2022-06-23 23:13:23.636222
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    import textwrap

    code = textwrap.dedent('''
    class A(object):
        def __init__(self):
            super()
    ''')

    # Compiles code and then compares the AST
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer.run_id('test1', tree)
    code2 = compile(tree, 'test1', 'exec')

    code_expected = textwrap.dedent('''
    class A(object):
        def __init__(self):
            super(A, self)
    ''')
    assert code2 == compile(code_expected, 'test1', 'exec')



# Generated at 2022-06-23 23:13:33.330596
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.scope import CoreScope
    from ..utils.helpers import fake_position_info

    root = ast.parse(dedent("""
        class foo(object):
            def method(self):
                super()
    """))

    tree = CoreScope(root, [])
    tree.register_visitor(SuperWithoutArgumentsTransformer('2.7'))
    tree.visit()
    tree.recalculate_parent_for_all()
    root = tree.root
    foo = root.body[0]
    method = foo.body[0]
    super_ = method.body[0]

    assert isinstance(super_.args[0], ast.Name)
    assert super_.args[0].id == 'foo'
    assert isinstance(super_.args[1], ast.Name)
    assert super

# Generated at 2022-06-23 23:13:35.966576
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    transformer.visit(tree)
    assert transformer._tree_changed == True


# Generated at 2022-06-23 23:13:36.904732
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:42.098058
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    class Cls:
        def __init__(self):
            super()
    """
    tree = ast.parse(source)  # type: ast.Module
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert isinstance(tree.body[0].body[0].body[0].args[0], ast.Name)
    assert isinstance(tree.body[0].body[0].body[0].args[1], ast.Name)

# Generated at 2022-06-23 23:13:42.799194
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:47.836531
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    tree = compile('super()', '', 'exec', ast.PyCF_ONLY_AST)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert astunparse.unparse(node) == 'super(Cls, self).__init__()'

# Generated at 2022-06-23 23:13:50.250725
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..migrators import SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:56.495604
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super().__init__()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    expected_result = """
    class A:
        def __init__(self):
            super(A, self).__init__()
    """
    assert expected_result == astor.to_source(tree).strip()

# Generated at 2022-06-23 23:13:57.572933
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:02.667583
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    target = '''
    class Foo:
        def __init__(self):
            super().__init__()
    '''
    expected = '''
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()
    '''
    tree = ast.parse(target)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    actual = astunparse.unparse(tree)

    assert expected == actual

# Generated at 2022-06-23 23:14:03.328903
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:09.140534
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_for_version

    code = """super()"""

    tree = compile_for_version(code, (2, 7))

    node: ast.Call = tree.body[0].value.func
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2

    node: ast.Name = node.args[0]
    assert isinstance(node, ast.Name)
    assert node.id == 'Cls'

    node: ast.Name = node.args[1]
    assert isinstance(node, ast.Name)
    assert node.id == 'self'

# Generated at 2022-06-23 23:14:11.708407
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    result = SuperWithoutArgumentsTransformer(tree).result()
    assert ast.dump(result) == ast.dump(ast.parse('super(__class__,self)'))

# Generated at 2022-06-23 23:14:20.113684
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import test_utils
    from .base import BaseNodeTransformer

    node = test_utils.ext_parse(
        """
        super()
        def test():
            super()
        
        class Test():
            def test(self):
                super()
        """
    )
    tree = SuperWithoutArgumentsTransformer(node).visit(node)
    assert test_utils.dump_python_source(tree) == "super(Test, self)\ndef test():\n    super(Test, self)\nclass Test():\n    def test(self):\n        super(Test, cls)"

# Generated at 2022-06-23 23:14:28.796412
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    
    class TreeBuilder:
        def __init__(self, tree: ast.AST) -> None:
            self.t = tree
            self.last_node = tree
        
        def add_node(self, node, parent, key: str) -> None:
            setattr(getattr(self.t, parent), key, node)
            self.last_node = node
        
        def add_child_node(self, node, key: str):
            self.add_node(node, 'last_node', key)
    
    tb = TreeBuilder
    
    tb.add_child_node = add_child_node
    tb.add_node = add_node
    
    get_closest_parent_of = get_closest_parent_of

# Generated at 2022-06-23 23:14:37.932488
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree, include_attributes=False) == "Module(body=[FunctionDef(name='__main__', args=arguments(args=[arg(arg='__main__')], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[], kwargannotation=None, returns=None), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='__main__', ctx=Load()), Name(id='__main__', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

# Generated at 2022-06-23 23:14:42.348998
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Test(SuperWithoutArgumentsTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return self.generic_visit(node)  # type: ignore

    code = """
    class Test:
        def method(self):
            a = super()
            a = super().__init__()
            a = super(self)
            a = super.__init__(self)
    """
    tree = ast.parse(code)
    Test().visit(tree)
    assert compile(tree, '', 'exec')

# Generated at 2022-06-23 23:14:47.931334
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.parse('super()').body[0]
    obj = SuperWithoutArgumentsTransformer()
    result = obj.visit_Call(node)
    expected = ast.Call(args=[ast.Name(id='foo'), ast.Name(id='bar')], func=ast.Name(id='super'))
    assert result == expected



# Generated at 2022-06-23 23:14:50.263663
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import test_node
    from ..conversions import PreliminaryNodeTransformer


# Generated at 2022-06-23 23:15:00.524107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def do_test(test_input, expected):
        module = ast.parse(test_input)
        c = SuperWithoutArgumentsTransformer()
        new_module = c.visit(module)

        print("INPUT:")
        print(test_input)
        print("OUTPUT:")
        print(ast.dump(new_module))

        assert ast.dump(new_module) == expected

    # A class with a constructor with super() and no arguments
    test_input = """
        class MyClass(MySuperClass):
            def __init__(self):
                super().__init__()
    """


# Generated at 2022-06-23 23:15:02.251923
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Get root
    from ..utils.builder import build

# Generated at 2022-06-23 23:15:07.380859
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    a = ast.parse('super()')
    # we don't have a class here
    a_tree = ast.fix_missing_locations(a)
    a_tree = t.visit(a_tree)
    assert ast.dump(a_tree) == 'Module(body=[Expr(value=Call(func=Name(id=\'super\', ctx=Load()), args=[], keywords=[]))])'



# Generated at 2022-06-23 23:15:17.216802
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('''class Cls:
    def method(sefl):
        super()
    @staticmethod
    def static_method():
        super()
    @classmethod
    def class_method(cls):
        super()''')

    SuperWithoutArgumentsTransformer().run(tree)

    expected = ast.parse('''class Cls:
    def method(sefl):
        super(Cls, sefl)
    @staticmethod
    def static_method():
        super(Cls, cls)
    @classmethod
    def class_method(cls):
        super(Cls, cls)
''')
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 23:15:26.430368
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
a = super()
"""
    expected_code = """
a = super(Cls, self)
"""
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    assert ast.dump(tree) == expected_code

    code = """
a = super()
"""
    expected_code = """
a = super(Cls, cls)
"""
    tree = ast.parse(code)
    tree = ClassDefWithMetaTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    assert ast.dump(tree) == expected_code


# Generated at 2022-06-23 23:15:31.106957
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..transpile import transpile
    assert transpile("super()") == "super(Cls, self)"
    assert transpile("super().method()") == "super(Cls, self).method()"
    assert transpile("super().__getattribute__()") == "super(Cls, self).__getattribute__()"
    assert transpile("super().__get__()") == "super(Cls, self).__get__()"
  

# Generated at 2022-06-23 23:15:34.482383
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_to_test = '''
super()
    '''

    expected_output = '''
super(cls, self)
    '''

    transformer = SuperWithoutArgumentsTransformer()
    actual_output = transformer.visit(ast.parse(code_to_test))
    actual_output = ast.unparse(actual_output)

    assert actual_output == expected_output

# Generated at 2022-06-23 23:15:44.605582
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # super()
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert astor.to_source(tree) == "super(__class__, self)\n"

    # super().pippo()
    tree = ast.parse('super().pippo()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert astor.to_source(tree) == "super(__class__, self).pippo()\n"

    # super() + with arguments, should not be changed
    tree = ast.parse('super(Cls, arg)')
    transformer = SuperWithoutArgumentsTransformer(tree)


# Generated at 2022-06-23 23:15:47.453904
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class DummyTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree_changed = False
            self._tree = None


# Generated at 2022-06-23 23:15:48.900377
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..codegen import CodeGenerator


# Generated at 2022-06-23 23:15:51.623761
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert "super(Cls, self)" == codegen.to_source(tree)

# Generated at 2022-06-23 23:15:59.030851
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]
    assert node.__class__.__name__ == 'Expr'
    assert node.value.__class__.__name__ == 'Call'

    cls = ast.parse('class Cls: super()').body[0]
    assert cls.__class__.__name__ == 'ClassDef'

    cls = ast.parse('class Cls: def method(self): super()').body[0]
    assert cls.__class__.__name__ == 'ClassDef'
    method = cls.body[0]

    assert method.__class__.__name__ == 'FunctionDef'

    transformer = SuperWithoutArgumentsTransformer(cls, cls.body[0], [])
    node = transformer.visit(node)

# Generated at 2022-06-23 23:15:59.889402
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO
    pass


# Generated at 2022-06-23 23:16:04.917782
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    assert isinstance(node, ast.Call)
    x = SuperWithoutArgumentsTransformer()
    x.visit_Call(node)
    assert isinstance(node, ast.Call)



# Generated at 2022-06-23 23:16:14.745060
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    
    from nuitka.ast.VariableRefNodes import ExpressionTargetVariableRef
    from nuitka.ast.AssignmentNodes import ExpressionTargetVariableRefAssignment
    from nuitka.ast.ConstantRefNodes import ExpressionConstantRef
    from nuitka.ast.ComparisonNodes import ExpressionComparisonIsNOT
    from nuitka.ast.AttributeNodes import ExpressionAttributeLookup
    from nuitka.ast.OperatorNodes import ExpressionOperationNOT
    from nuitka.ast.CallNodes import ExpressionCallNoKeywords
    from nuitka.ast.Statements import StatementReturn
    from nuitka.ast.FunctionNodes import ExpressionFunctionBody
    from nuitka.ast.ClassNodes import ExpressionClassBody
    from nuitka.ast.ClassNodes import ExpressionClassBody

# Generated at 2022-06-23 23:16:22.535962
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.codegen import to_source
    from .base import BaseNodeTransformerTest

    code = """
            class A:
                def f(self):
                    super()
                    super(A, self)
                    super().f()
                def g(self):
                    class B:
                        def f(self):
                            super()
                            super(A, self)
                            super(A, cls)
                    a = A()
                    a.f()
            """

    class Test(BaseNodeTransformerTest):
        def create_transformer(self) -> BaseNodeTransformer:
            return SuperWithoutArgumentsTransformer()


# Generated at 2022-06-23 23:16:30.098195
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import textwrap
    tree = ast.parse(textwrap.dedent('''\
        class A:
            def f(self):
                super()
        '''))
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:16:37.109274
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestNodeTransformer(SuperWithoutArgumentsTransformer):
        pass

    node = ast.Call(
        func=ast.Name(id='super'), 
        args=[], keywords=[])

    tree = ast.parse('class A:\n def test(self):\n  super()')
    tree = TestNodeTransformer(tree).visit(tree)

    expected = ast.Call(
        func=ast.Name(id='super'), 
        args=[ast.Name(id='A'), ast.Name(id='self')], keywords=[])
    assert tree.body[0].body[0].body[0].value == expected

# Generated at 2022-06-23 23:16:45.961230
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from .. import compile_ast

    src = """
        class Foo:
            def __init__(self):
                super().__init__()

        foo = Foo()
    """

    expected = """
        class Foo:
            def __init__(self):
                super(Foo, self).__init__()

        foo = Foo()
    """

    tree = source_to_ast(src)
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.visit(tree)

    my_ast = compile_ast(tree)
    assert expected == my_ast

# Generated at 2022-06-23 23:16:49.451419
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    node = ast.parse("super()")
    x = SuperWithoutArgumentsTransformer()
    x.visit(node)
    assert astunparse.unparse(node) == "super(ClassDef, arg_1)"


# Generated at 2022-06-23 23:16:50.491783
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:54.566661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    code = textwrap.dedent('''\
        class Foo:
            def foo(self):
                super()
    ''')
    # When
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    # Then
    assert isinstance(ast.dump(tree), str)

# Generated at 2022-06-23 23:16:58.946447
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import ast
    sys.version_info = (3, 5)
    ast25 = ast.parse('for i in (1, ')
    ast35 = ast.parse('for i in (1, ')
    SuperWithoutArgumentsTransformer().visit(ast35)
    assert str(ast35) == str(ast25)

# Generated at 2022-06-23 23:17:05.544723
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    
    tree = ast.parse('super()')
    node = tree.body[0].value
    SuperWithoutArgumentsTransformer._replace_super_args(None, node)

    assert type(node.args[0]) == ast.Name
    assert node.args[0].id == 'Cls'

    assert type(node.args[1]) == ast.Name
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:17:06.620885
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:16.597746
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transform

    assert_transform(
        SuperWithoutArgumentsTransformer,
        '''
        super()
        class A:
            def __init__(self):
                super()
        ''',
        '''
        super(A, self)
        class A:
            def __init__(self):
                super(A, self)
        '''
    )

    assert_transform(
        SuperWithoutArgumentsTransformer,
        '''
        super()
        class A(B):
            def __init__(self):
                super()
        ''',
        '''
        super(A, self)
        class A(B):
            def __init__(self):
                super(A, self)
        '''
    )


# Generated at 2022-06-23 23:17:17.811508
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code import SourceCode
    from ..utils.helpers import dump_ast

# Generated at 2022-06-23 23:17:19.596150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert "super(Cls, self)" == astor.to_source(tree)

# Generated at 2022-06-23 23:17:25.289216
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()").body[0]
    res = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(res, ast.Call)
    assert isinstance(res.func, ast.Name)
    assert res.func.id == 'super'
    assert isinstance(res.args[0], ast.Name)
    assert res.args[0].id == 'Cls'
    assert isinstance(res.args[1], ast.Name)
    assert res.args[1].id == 'self'

# Generated at 2022-06-23 23:17:35.600489
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import astor
    from .test_programs.super_without_arguments import program

    class TestSuperWithoutArgumentsTransformerVisitCall(unittest.TestCase):
        def test_method(self) -> None:
            tree = ast.parse(program)
            node = tree.body[0]
            self.assertTrue(isinstance(node, ast.FunctionDef))

            transformer = SuperWithoutArgumentsTransformer(tree)
            new_node = transformer.visit(node)

            self.assertIsNot(node, new_node)
            self.assertTrue(transformer._tree_changed)

# Generated at 2022-06-23 23:17:40.008232
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import dump,  parse

    tree = parse("""
    class A:
        def foo(self):
            super()""")
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    dumped = dump(tree)
    assert dumped == """
    class A:
        def foo(self):
            super(A, self)"""

# Generated at 2022-06-23 23:17:46.120966
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    for ver in [2, 7]:
        tree = ast.parse('''
            class Fruit(object):

                def __init__(self, name):
                    pass

                def peel(self, times):
                    super()

            def main():
                pass
        ''')
        node = tree.body[0]
        node = cast(ast.ClassDef, node)
        node = node.body[1]
        node = cast(ast.FunctionDef, node)
        node = node.body[0]
        node = cast(ast.Expr, node)
        node = node.value
        node = cast(ast.Call, node)
        assert 'super()' == ast.dump(node)

        transformer = SuperWithoutArgumentsTransformer(tree, ver)
        transformer.visit(tree)


# Generated at 2022-06-23 23:17:56.222450
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    entry_point = 'tree_transform.transformers.builtin.SuperWithoutArgumentsTransformer'
    args = ['i', 'hello', 'world']

    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer(target_version=2.7).visit(tree)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'i'

    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer(target_version=2.7).visit(tree)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'i'

# Generated at 2022-06-23 23:18:06.553839
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test method visit_Call of class SuperWithoutArgumentsTransformer.
    """
    from .. import Compiler
    from typed_ast import ast3 as ast

    tree = ast.parse("""
        class Foo:
            def func(self):
                super()
        """)
    compiler = Compiler()
    compiler.visit(tree)
    assert compiler.output == """
        class Foo:
            def func(self):
                super(Foo, self).__init__()
        """

    tree = ast.parse("""
        class Foo:
            def func(cls):
                super()
        """)
    compiler = Compiler()
    compiler.visit(tree)

# Generated at 2022-06-23 23:18:15.558784
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer"""
    from typing import List
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest
    from .super_without_arguments import SuperWithoutArgumentsTransformer

    class Test(BaseNodeTransformerTest):
        @property
        def transformer(self) -> SuperWithoutArgumentsTransformer:
            return super().transformer

        def test_super(self):
            """Test super()"""
            input = '''super()'''
            expected_output = '''super(Cls, self)'''
            tree = ast.parse(input, mode='eval')
            node = tree.body
            node = self.transformer.visit(node)
            output = self.compile_node_or_string(node)

# Generated at 2022-06-23 23:18:24.619152
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformer
    from .code_blocks import CodeBlocksTransformer
    from .exceptions import ExceptionsTransformer
    from .function_annotations import FunctionAnnotationsTransformer
    from ..utils.ast_builder import module
    from ..utils.helpers import assert_code_equal
        
    class TestTransformer(BaseNodeTransformer):
        visitors = [
            CodeBlocksTransformer,
            SuperWithoutArgumentsTransformer,
            ExceptionsTransformer,
            FunctionAnnotationsTransformer,
        ]

    code = '''
        class X:
            def __init__(self):
                super()
    '''
    expected_code = '''
        class X:
            def __init__(self):
                super(X, self)
    '''

# Generated at 2022-06-23 23:18:26.175063
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:27.232511
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:34.590780
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from inspect import cleandoc
    from ..parser import parse
    from ..utils.helpers import get_first_of_node_type

    code = cleandoc(
        '''
        class X(object):
            def __init__(self):
                super()
        '''
    )

    tree = parse(code)
    new_tree = SuperWithoutArgumentsTransformer().visit(tree)
    super_call = get_first_of_node_type(new_tree, ast.Call)
    assert super_call.args[0].id == 'X'
    assert super_call.args[1].id == 'self'

# Generated at 2022-06-23 23:18:43.608912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import Source
    from ..transform import TransformationsRunner

    class DummyTransformer(TransformationsRunner):
        pass

    source = Source("""
        class C:
            def __init__(self):
                super()
                super().abc()
                super(A, B)
        """)
    module = ast.parse(source)
    DummyTransformer(module).run()
    assert isinstance(module.body[0].body[0].value.args[0].id, str)
    assert isinstance(module.body[0].body[0].value.args[1].id, str)
    assert isinstance(module.body[0].body[1].value.func.args[0].id, str)

# Generated at 2022-06-23 23:18:50.683952
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode, source_to_ast
    from ast import parse

    class_def = parse(source_to_unicode('''
    class Cls:
        def __init__(self, value):
            super().__init__()
    ''')).body[0]

    translator = SuperWithoutArgumentsTransformer({})
    translator.visit(class_def)


# Generated at 2022-06-23 23:18:59.541276
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...testing.utils import build_failure, build_program
    from ...testing.golden_path import get_golden_path

    source = 'from builtins import super; class A(object): def f(self): super()'
    with build_failure(source, "super() outside of class") as result:
        build_program(source, [SuperWithoutArgumentsTransformer])

    source = 'class A(object): def f(): super()'
    with build_failure(source, "super() outside of function") as result:
        build_program(source, [SuperWithoutArgumentsTransformer])

    source = 'class A(object): def f(self): super()'
    golden_path = get_golden_path('super_without_arguments', 'visit_Call.py')

# Generated at 2022-06-23 23:19:07.570640
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import setup_module_transformer, run_unit_test
    from ..utils.helpers import get_python_node_for_text

    node_1 = get_python_node_for_text('super()')
    node_2 = get_python_node_for_text('super(A, self)')
    node_3 = get_python_node_for_text('super(A, cls)')
    node_4 = get_python_node_for_text('super(A, b)')

    transformer = setup_module_transformer()
    transformer.add_module_transformer(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-23 23:19:17.448536
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump_ast
    import sys

    class DummySuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
    
        @classmethod
        def _transform(cls, tree: ast.AST, target: tuple) -> ast.AST:
            return cls(tree, target).visit(tree)

    tree = ast.parse('''
        class A:
            def func(self):
                super()
    ''')

    result = ast.parse('''
        class A:
            def func(self):
                super(A, self)
    ''')

    print(sys.version)
    print(dump_ast(DummySuperWithoutArgumentsTransformer._transform(tree, (2, 7))))

# Generated at 2022-06-23 23:19:22.025486
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    sample = '''
            class Foo(object):
                def bar(self):
                    super()
            '''
    expected = '''
            class Foo(object):
                def bar(self):
                    super(Foo, self)
            '''
    test_ast = ast.parse(sample)
    expected_ast = ast.parse(expected)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(test_ast)
    assert astor.to_source(test_ast) == astor.to_source(expected_ast)

# Generated at 2022-06-23 23:19:24.458723
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
        class A:
            def b(self):
                super()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()
    code = compile(tree, '', 'exec')
    exec(code)

# Generated at 2022-06-23 23:19:28.920536
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:30.237943
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import parse_to_ast


# Generated at 2022-06-23 23:19:39.246243
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    class Transformer(SuperWithoutArgumentsTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            node = super().generic_visit(node)
            return node

    tree = ast.parse('''
        def __init__(self):
            super()
    ''')
    tree_expected = ast.parse('''
        def __init__(self):
            super(Root, self)
    ''')

    tree_transformed = Transformer().visit(tree)

    assert astor.to_source(tree_transformed) == astor.to_source(tree_expected)


if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:19:39.633244
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:19:44.291229
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
print(super())
    """
    with_arguments = """
print(super(Not, this))
    """
    expected = """
print(super(Cls, self))
    """
    node = ast.parse(code, mode='eval')
    node_with_arguments = ast.parse(with_arguments, mode='eval')

    node_transformer = SuperWithoutArgumentsTransformer(node_with_arguments)
    node_transformer.visit(node)

    assert ast.dump(node) == ast.dump(ast.parse(expected, mode='eval'))

# Generated at 2022-06-23 23:19:53.317198
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_example_source, dedent
    import sys

    src = get_example_source(__file__, sys._getframe().f_code.co_name)

    from .. import fix_code
    from typed_ast import parse
    from .base import BaseNodeTransformer

    tree = parse(dedent(src))
    transpiler = BaseNodeTransformer()
    transpiler.visit(tree)

    code_fixed_str = fix_code(src)

    assert code_fixed_str == dedent('''\
        class Cls(object):
            def foo(self):
                super(Cls, self).foo()
        ''')

# Generated at 2022-06-23 23:19:55.000676
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from .transpile import transpile


# Generated at 2022-06-23 23:20:02.030085
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    module = ast.parse("""
        class Test:
            def __init__(self):
                super().__init__()
            def func(self) -> None:
                super().func()
        """)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(module)
    transformed_ast = astor.to_source(module)
    expected_ast = """class Test:
    def __init__(self):
        super(Test, self).__init__()

    def func(self):
        super(Test, self).func()

"""
    assert transformed_ast == expected_ast

# Generated at 2022-06-23 23:20:13.363334
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.parse import parse
    from ..utils.visit import visit_and_modify
    parse_tree = parse("super()")
    visit_and_modify(parse_tree, SuperWithoutArgumentsTransformer)
    assert(isinstance(parse_tree, ast.Module))
    assert(isinstance(parse_tree.body[0], ast.ClassDef))
    assert(parse_tree.body[0].name == 'MyClass')
    assert(isinstance(parse_tree.body[0].body[0], ast.FunctionDef))
    assert(isinstance(parse_tree.body[0].body[0].body[0], ast.Expr))
    assert(isinstance(parse_tree.body[0].body[0].body[0].value, ast.Call))

# Generated at 2022-06-23 23:20:15.258998
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import parse_to_ast_node


# Generated at 2022-06-23 23:20:17.152403
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-23 23:20:27.106290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import List
    import astor
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    input_source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')

    tree = ast.parse(input_source)
    m = SuperWithoutArgumentsTransformer()
    m.visit(tree)
    assert isinstance(tree.body[0].body[0].body[0], ast.Call)
    assert m.tree_changed is True  # tree was actually changed

    expected_source = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
