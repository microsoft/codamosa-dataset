

# Generated at 2022-06-23 23:10:14.843033
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def _test_func_pos(self):
            return 1, 1
    

# Generated at 2022-06-23 23:10:20.006029
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode_str
    from .. import compile_string

    code = source_to_unicode_str('''
        class C:
            def __init__(self):
                super()
    ''')
    module = compile_string(code, 'main', '2.7')

    assert module.body[0].body[0].args.args[1].arg == 'self'



# Generated at 2022-06-23 23:10:22.468059
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_converter
    from ..utils.helpers import compare_source


# Generated at 2022-06-23 23:10:24.343938
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from ..utils.helpers import node_to_str


# Generated at 2022-06-23 23:10:33.131035
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..transformers import TransformError
    from .. import ast_transformer
    from ..parser import parse_ast

    code = 'class MyClass(object):\n    def __init__(self):\n        super()\n'
    new_code = 'class MyClass(object):\n    def __init__(self):\n        super(MyClass, self)\n'
    tree = parse_ast(code, mode='exec')
    transformer = ast_transformer.ASTTransformer(tree)
    transformer.register_transformer(SuperWithoutArgumentsTransformer)
    transformer.run()
    assert ast.dump(tree) == ast.dump(parse_ast(new_code, mode='exec'))


# Generated at 2022-06-23 23:10:33.691736
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:35.378398
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:37.583214
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .utils import NodeTransformerTestCase

    class Test(NodeTransformerTestCase):
        transformer = SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:40.323086
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    node = ast.parse("super()")
    new_node = SuperWithoutArgumentsTransformer().visit(node)

    assert astor.to_source(new_node).strip() == "super(Cls, self)"



# Generated at 2022-06-23 23:10:41.685199
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test if SuperWithoutArgumentsTransformer works as intended."""

# Generated at 2022-06-23 23:10:49.574856
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    import unittest


# Generated at 2022-06-23 23:10:57.613802
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import parse
    import textwrap

    code = '''
    class Cls:
        def __init__(self):
            super().__init__()
    '''
    
    expected_ast = parse(textwrap.dedent('''
    class Cls:
        def __init__(self):
            super(Cls, self).__init__()
    '''))

    actual_ast = parse(code)
    transformer = SuperWithoutArgumentsTransformer(actual_ast, None)
    transformer.visit(actual_ast)

    assert_ast_equals(actual_ast, expected_ast)

# Generated at 2022-06-23 23:11:02.592912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_for_version
    transform_source = compile_for_version(
        '''" "super(Cls, self)" "''',
        transformer_class=SuperWithoutArgumentsTransformer,
        version=2.7)
    node = ast.parse(transform_source)
    expected = ast.parse('" "super(Cls, self)" "')
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 23:11:03.959316
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes


# Generated at 2022-06-23 23:11:11.313461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from . import compile_func
    from .. import transform
    from .. import ast_converter
    node = ast.parse('super()').body[0]

# Generated at 2022-06-23 23:11:21.424231
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from typed_ast import ast3 as ast
    from vyper.exceptions import StructureException
    from vyper.typing import FunctionType, ListType, MappingType

    from .base import BaseNodeTransformer

    def rec(tree: ast.AST) -> ast.AST:
        transformer = BaseNodeTransformer()
        transformer.visit(tree)
        return tree

    source = textwrap.dedent("""
    class X:
        def f(self):
            super()
            super()
            super()
        def g(self):
            super()
    """)


# Generated at 2022-06-23 23:11:28.627716
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast

    cls = source_to_ast("""
    class A(object):
        def __init__(self):
            super()
    """)
    tr = SuperWithoutArgumentsTransformer(cls)
    tr.visit(cls)
    assert isinstance(cls.body[0].body[0].value.args[0], ast.Name)
    assert cls.body[0].body[0].value.args[0].id == 'A'

    cls = source_to_ast("""
    class A(object):
        def __init__(self, x):
            super()
    """)
    tr = SuperWithoutArgumentsTransformer(cls)
    tr.visit(cls)

# Generated at 2022-06-23 23:11:29.677648
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:40.210201
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_tree

    code = '''
    class Test:
        def __init__(self):
            super()
    '''

# Generated at 2022-06-23 23:11:45.225688
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import SampleBase
    from ..utils.python_source_parser_helper import load_ast_tree

    class Sample(SampleBase):
        target = (2, 7)
        transformers = [SuperWithoutArgumentsTransformer]

        def __init__(self):
            super().__init__()

    class Parent:
        def __init__(self):
            pass

    class Child(Parent):
        def __init__(self):
            super()
        
    tree = load_ast_tree(Child)
    node = tree.body[-1].body[0].value.args[0].value
    assert isinstance(node, ast.Name)
    assert node.id == 'Child'

# Generated at 2022-06-23 23:11:46.252876
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:55.081465
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import Lark
    from ..utils.helpers import tree_to_str

    # Given
    source = '''
        class C:
            def f(self):
                super()
    '''
    # When
    targets = (2, 7)
    expected = '''
        class C:
            def f(self):
                super(C, self)
    '''
    tree = Lark.parse(source)
    node_transformer = SuperWithoutArgumentsTransformer(tree, targets)
    node_transformer.visit(node_transformer.tree.children[0])
    # Then
    assert tree_to_str(node_transformer.tree) == expected

# Generated at 2022-06-23 23:11:56.953267
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transform = SuperWithoutArgumentsTransformer(42)

# Generated at 2022-06-23 23:11:59.571506
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    See tests/fixtures/transformer/super_without_args.py
    """
    pass

# Generated at 2022-06-23 23:12:05.291858
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
            class SuperCls(object):
                def __init__(self):
                    super()
        '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert len(tree.body[0].body[0].args.args) == 2
    assert tree.body[0].body[0].args.args[0].arg == 'self'

# Generated at 2022-06-23 23:12:16.124420
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code_equals

    assert_transformed_code_equals(
        SuperWithoutArgumentsTransformer,
        """
        foo(super())
        """,
        """
        foo(super(Foo, self))
        """,
    )
    assert_transformed_code_equals(
        SuperWithoutArgumentsTransformer,
        """
        def foo():
            super()
        """,
        """
        def foo():
            super(Foo, self)
        """,
    )

# Generated at 2022-06-23 23:12:21.402762
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import parse
    from ..utils.helpers import run_test
    code = """
        class SomeClass:
            def some_func(self):
                super()
    """
    tree = parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    result = run_test(tree)
    assert result == """
        class SomeClass:
            def some_func(self):
                super(SomeClass, self)
    """

# Generated at 2022-06-23 23:12:23.692641
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Setup
    from .. import tree, register
    register(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-23 23:12:29.670051
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code_to_ast import source_code_to_ast
    tree = source_code_to_ast.parse(
        """
        class A:
            def my_func(self):
                super()

            def my_func(cls):
                super()
        """
    )
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-23 23:12:31.686563
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that super() without arguments is transformed to
    super(Cls, self)
    """

# Generated at 2022-06-23 23:12:34.384190
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    cls = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(cls)
    assert transformer._tree_changed is True

# Generated at 2022-06-23 23:12:36.697985
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_
    class A(object):
        def f(self):
            super()
    assert compile_(A, '2.7')

# Generated at 2022-06-23 23:12:46.178194
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from ..utils import helpers
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from ..utils.source import Source

    code = dedent("""
    class A:
        def method(self):
            super(A, self).method()
    """)
    source = Source(code, path='./test.py')
    tree = source.parse()
    assert helpers.node(source.tree, 'class A:')
    helpers.apply_transformer(tree, SuperWithoutArgumentsTransformer)  # type: ignore
    with TemporaryDirectory() as tmp_dir:
        output = transform.compile(source, tmp_dir=tmp_dir)
        assert helpers.node(output.tree, 'class A:')

# Generated at 2022-06-23 23:12:48.434570
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-23 23:12:56.767590
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:00.133522
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    tree = ast.parse("super(String, self).upper()")
    new_tree = SuperWithoutArgumentsTransformer().visit(tree)
    print(astor.to_source(new_tree))

# Generated at 2022-06-23 23:13:11.287351
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..utils.test_utils import should_transform, should_not_transform
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit_Call(ast.parse('super()', mode='eval').body)
    should_not_transform(transformer, 'super()')
    should_not_transform(transformer, 'super(a)')
    should_not_transform(transformer, 'super(a, b)')
    should_transform(transformer, 'super()', 'super(ClassName, instance)')
    should_transform(transformer, 'super()', 'super(ClassName, cls)')
    should_transform(transformer, 'super()', 'super(ClassName, class_)')

# Generated at 2022-06-23 23:13:21.198261
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    code = dedent('''
    class A(object):
        def func(self):
            super().func()
            
            class B(A):
                def func(self):
                    super().func()
                    self.a = 1
                @classmethod
                def cls_func(cls):
                    super().func()
                    self.a = 1
    ''')
    # SuperWithoutArgumentsTransformer.visit_Call(node) returns node,
    # so we can use assertEqual to test it.

# Generated at 2022-06-23 23:13:29.275993
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .transformer import Compiler

    class TestClass:
        def __init__(self, arg):
            self.arg = arg

        def test(self):
            super().__init__(self.arg)

    tree = ast.parse(inspect.getsource(TestClass))
    Compiler.compile_root(tree)
    exec(
        compile(tree, filename='<string>', mode='exec'),
        {},
        {'arg': 'ARG'}
    )
    obj = TestClass('ARG')
    assert obj.arg == 'ARG'

# Generated at 2022-06-23 23:13:31.018857
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from typed_astunparse import unparse

# Generated at 2022-06-23 23:13:31.985725
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass # TODO: Implement test


# Generated at 2022-06-23 23:13:32.834327
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:41.901686
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    program = """
        class Foo:
            def __init__(self):
                super()
    """
    tree = ast.parse(program)
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.run()

# Generated at 2022-06-23 23:13:48.706881
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astroid
    from python_ta.transforms.type_inference_visitor import TypeInferenceVisitor
    from typing import List

    class Cls(object):
        def method(self):
            super()
            d = super()
            e = {'a': super()}

    source = inspect.getsource(Cls.method)
    tree = astroid.parse(source)
    visitor = TypeInferenceVisitor().visit(tree)
    tree = SuperWithoutArgumentsTransformer(type_map=visitor.type_map).visit(tree)
    assert [node.__class__ for node in tree.body[0].body] == [
        ast.Expr, ast.Assign, ast.Assign, ast.Dict]

# Generated at 2022-06-23 23:13:58.518134
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as typed_ast
    tree = typed_ast.parse('super()')
    assert isinstance(tree, typed_ast.Module)
    assert isinstance(tree.body[0], typed_ast.Expr)
    assert isinstance(tree.body[0].value, typed_ast.Call)
    assert isinstance(tree.body[0].value.func, typed_ast.Name)
    assert tree.body[0].value.func.id == 'super'
    # assert isinstance(tree.body[0].value.args[0], typed_ast.Name)
    # assert isinstance(tree.body[0].value.args[1], typed_ast.Name)
    # assert isinstance(tree.body[0].value.args[2], typed_ast.Name)
    # assert tree.

# Generated at 2022-06-23 23:13:59.736936
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import transform

# Generated at 2022-06-23 23:14:06.981361
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode_python2
    from ..utils.source import source_to_unicode_python3

    source = source_to_unicode_python2("""
        class A(object):
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    code = compile(tree, "<test>", "exec")
    globs = {}
    exec(code, globs)
    A = globs['A']
    assert A.__init__.__func__(A())

    source = source_to_unicode_python3("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
   

# Generated at 2022-06-23 23:14:09.033753
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast, dump_ast


# Generated at 2022-06-23 23:14:09.936724
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:14:20.380333
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    cls = "class A:"
    func = "def f(self):"
    tree = ast.parse("{}\n{}\n{}\n".format(cls, func, node))
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    assert_equal("{}\n{}\nsuper(A, self).\n".format(cls, func), dump_python_source(tree))

    node = ast.parse("super()")
    func = "def f(cls):"
    tree = ast.parse("{}\n{}\n{}\n".format(cls, func, node))
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)

# Generated at 2022-06-23 23:14:25.380984
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..renamer.codegen import to_source

    # foo = super()
    code = """\
foo = super()
"""
    node = ast.parse(code, mode='exec')
    SuperWithoutArgumentsTransformer(node).visit(node)
    assert to_source(node) == """foo = super(Cls, self)"""

    # foo = super()

# Generated at 2022-06-23 23:14:31.912199
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest

    class VisitCall(unittest.TestCase):
        def test_should_replace_super(self):
            source = 'class Foo: def method(self): super()'
            expected_result = 'class Foo: def method(self): super(Foo, self)'

            tree = ast.parse(source)
            SuperWithoutArgumentsTransformer().visit(tree)
            self.assertEqual(expected_result, astor.to_source(tree).strip())

        def test_should_not_replace_super_with_args(self):
            source = 'class Foo: def method(self): super(Foo)'
            expected_result = 'class Foo: def method(self): super(Foo)'

            tree = ast.parse(source)
            SuperWithoutArgumentsTransformer().visit(tree)
           

# Generated at 2022-06-23 23:14:42.585020
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    super_node = ast.Name(id='super')
    call_node = ast.Call(func=super_node, args=[])

    class ChildClass(ast.AST):
        _fields = ('bodies',)
        def __init__(self, bodies: List[ast.AST]):
            self.bodies = bodies

    function_node = ast.FunctionDef(name='test_function', args=ast.arguments(args=[ast.arg(arg='self')]), body=[], 
                                    decorator_list=[], returns=None)
    class_node = ast.ClassDef(name='Cls', bases=[], keywords=[], body=[function_node], decorator_list=[])

    # Test 1: Test if correct arguments are added to super call if super is called inside a class and a

# Generated at 2022-06-23 23:14:48.484225
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
    class Parent(object):
        def method(self):
            super()
    """
    tree = ast.parse(code)
    c = SuperWithoutArgumentsTransformer(tree, None)
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            c.visit_Call(node)
    assert len(tree.body[0].body[0].body[0].args) == 2

# Generated at 2022-06-23 23:14:51.099120
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ... import parse
    from .unpacking import UnpackingTransformer
    from .star_arguments_to_args_kwargs import StarArgumentsToArgsKwargsTransformer


# Generated at 2022-06-23 23:15:01.223951
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    """
    import textwrap
    from .. import ast_transformer
    from ..utils.helpers import dump_ast

    code = textwrap.dedent('''\
        class Cls:
            def func(arg):
                super()
        ''')
    expected_transformed_code = textwrap.dedent('''\
        class Cls:
            def func(arg):
                super(Cls, arg)
        ''')

    tree = ast.parse(code)
    assert dump_ast(tree) == code

    transformer = ast_transformer(ast.parse(code), SuperWithoutArgumentsTransformer)
    assert dump_ast(tree) == expected_transformed_code

# Generated at 2022-06-23 23:15:04.577132
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_2_7 = 'super()'
    expected_2_7 = 'super(Cls, self)'
    code_3_7 = 'super()'
    expected_3_7 = 'super(Cls, self)'

    # @formatter:off

# Generated at 2022-06-23 23:15:14.330046
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_restricted
    code = '''class A(object):
    def __init__(self, foo):
        super()
        pass
    '''
    tree = compile_restricted(code, 'file.py', 'exec')
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:15:14.941777
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:23.953823
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astmonkey import transformers
    from ..utils import helper
    from ..visitors.base import initialize_visitor
    from ..exceptions import NodeNotFound

    @initialize_visitor
    class SuperWithoutArgumentsTransformerTester(SuperWithoutArgumentsTransformer):
        """Test class"""

    tree_before = helper.file_to_ast('tests/fixtures/methodvisitcall_before.py', transformer_classes=[transformers.CallTransformer])
    SuperWithoutArgumentsTransformerTester(tree_before).visit()
    tree_after = helper.file_to_ast('tests/fixtures/methodvisitcall_after.py')
    assert helper.compare_ast(tree_before, tree_after)

# Generated at 2022-06-23 23:15:28.700476
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .base import BaseNodeTransformer

    source = source_to_unicode("""
    class A:
        def f(self):
            super()
    """)
    tree = ast.parse(source)

    transformer = SuperWithoutArgumentsTransformer(tree, None)
    transformer.visit(tree)

    source_out = source_to_unicode(str(tree))
    source_expected = source_to_unicode("""
    class A:
        def f(self):
            super(A, self)
    """)

    assert source_out == source_expected

# Generated at 2022-06-23 23:15:34.331933
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse(
        'class Klass:\n'
        '    def fun(self):\n'
        '        super()'
    )
    node = node.body[0].body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(None)
    new_node = transformer.visit(node)
    new_node = ast.fix_missing_locations(new_node)
    assert ast.dump(new_node) == 'Expr(value=Call(func=Attribute(value=Name(id=super, ctx=Load()), attr=__init__, ctx=Load()), args=[Name(id=Klass, ctx=Load()), Name(id=self, ctx=Load())], keywords=[], starargs=None, kwargs=None))'  # noqa:

# Generated at 2022-06-23 23:15:35.400160
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:15:37.625835
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.source import source_to_unicode
    from .identity import IdentityTransformer


# Generated at 2022-06-23 23:15:47.501206
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    cls = ast.ClassDef(name='Foo', bases=[], keywords=[], body=[
        ast.FunctionDef(
            name='foo',
            args=ast.arguments(args=[ast.arg(arg='self', annotation=None)], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]),
            body=[
                ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))
            ],
            decorator_list=[],
            returns=None
        )
    ])

# Generated at 2022-06-23 23:15:49.004296
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-23 23:15:51.370740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():  
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert str(tree) == 'super(Cls, self)'

# Generated at 2022-06-23 23:15:52.016647
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:55.718220
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer(node).visit(node)
    assert str(node) == 'super(Cls, self)'

    node = ast.parse('super(Class)')
    node = SuperWithoutArgumentsTransformer(node).visit(node)
    assert str(node) == 'super(Class)'

# Generated at 2022-06-23 23:16:00.827130
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call(ast.Name(id="super"), [])
    node1 = ast.FunctionDef(name="a", args=ast.arguments(args=[ast.arg(arg="self", annotation=None)]), returns=None,
                            body=[node], decorator_list=[])
    node2 = ast.ClassDef(name="b", bases=[], keywords=[], body=[node1], decorator_list=[])
    tree = ast.Module(body=[node2])
    trans = SuperWithoutArgumentsTransformer(tree)
    assert trans._tree_changed
    assert str(node.args[-1].id) == "self"

# Generated at 2022-06-23 23:16:08.119305
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source

    source = Source('''
        class A(object):
            def __init__(self):
                super()
    ''')

    result = '''
        class A(object):
            def __init__(self):
                super(A, self)
    '''

    # This replaces super() with super(cls_name, self)
    t = SuperWithoutArgumentsTransformer().visit(source.tree)

    source.tree = t

    assert source.dumps() == result

# Generated at 2022-06-23 23:16:09.991211
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""


# Generated at 2022-06-23 23:16:10.959166
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:15.580415
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_ast
    from . import get_first_expr_name

    tree = compile_ast("""
        class X(object):
            def method(self):
                super()
    """)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert get_first_expr_name(tree) == 'super(X, self)'



# Generated at 2022-06-23 23:16:22.854805
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call
    

# Generated at 2022-06-23 23:16:26.079358
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    transpiled_code = SuperWithoutArgumentsTransformer().visit(
        ast.parse("super()")
    )
    assert "super(Cls, self)" in transpiled_code or "super(Cls, cls)" in transpiled_code

# Generated at 2022-06-23 23:16:36.343217
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Module([ast.ClassDef(name='BaseClass')])
    tree = ast.parse('super()')
    node.body.append(tree.body[0])
    node.body.append(ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg(arg='self')])))
    node.body[1].body = [tree.body[0], ast.Pass()]

    t = SuperWithoutArgumentsTransformer()
    new_node = t.visit(node)


# Generated at 2022-06-23 23:16:47.423909
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse(textwrap.dedent('''\
    class C:
        def f():
            super()
        def f2():
            super(C, self)
        def f3():
            super(__class__, self)
        def f4(cls):
            super(C, cls)
        super()
    '''))
    SuperWithoutArgumentsTransformer(node).run()
    expected = ast.parse(textwrap.dedent('''\
    class C:
        def f():
            super(C, self)
        def f2():
            super(C, self)
        def f3():
            super(__class__, self)
        def f4(cls):
            super(C, cls)
        super(C, self)
    '''))

# Generated at 2022-06-23 23:16:52.074969
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import Node, print_pretty

    from .base import BaseTest
    import sys

    class Test(BaseTest):
        target = (2, 7)
        transformer = SuperWithoutArgumentsTransformer


# Generated at 2022-06-23 23:16:59.552643
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    tree.insert(1, ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg('self', None)])))
    tree.insert(1, ast.ClassDef(name='Cls', body=[]))
    SuperWithoutArgumentsTransformer(tree).run()
    expected_tree = ast.parse('super(Cls, self)')
    expected_tree.insert(1, ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg('self', None)])))
    expected_tree.insert(1, ast.ClassDef(name='Cls', body=[]))
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:17:10.489852
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    
    from ..utils.source import source_to_unicode_node
    from ..utils.compare_ast import compare_ast
    from ..utils.source import source_to_ast as to_ast
    
    tree = to_ast.parse('super()')
    node = tree.body[0].value
    SuperWithoutArgumentsTransformer._replace_super_args(None, node)
    
    result = to_ast.parse('super(__class__, self)')
    assert compare_ast(tree, result)
    
    tree = to_ast.parse('super(cls=__class__, self=self)')
    node = tree.body[0].value
    SuperWithoutArgumentsTransformer._replace_super_args(None, node)
    

# Generated at 2022-06-23 23:17:12.727756
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import CompileToStr


# Generated at 2022-06-23 23:17:18.102039
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import _ast as ast
    from ..utils.ast_builder import build_ast

    tree = build_ast('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(build_ast('''
        class A:
            def __init__(self):
                super(A, self)
    '''))

# Generated at 2022-06-23 23:17:18.874240
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:27.378327
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
      def _replace_super_args(self, node: ast.Call) -> None:
        pass
      def visit_Call(self, node: ast.Call) -> ast.Call:
        return self.generic_visit(node)  # type: ignore
    # Testing node ast.Module
    module0 = ast.Module() # type: ignore
    assert module0.body == []
    # Testing node ast.Call
    call0 = ast.Call() # type: ignore
    assert call0.func is None
    assert call0.args == []
    assert call0.keywords == []
    assert call0.starargs is None
    assert call0.kwargs is None
    module0.body.append(call0)
   

# Generated at 2022-06-23 23:17:33.499681
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import build_ast_from_source
    import ast

    tree = build_ast_from_source('super()', ast.Call)
    tree = SuperWithoutArgumentsTransformer(tree).visit()
    assert get_node_name(tree.func) == 'Super'
    assert get_node_name(tree.args[0]) == 'Name'

# Generated at 2022-06-23 23:17:43.133989
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test the SuperWithoutArgumentsTransformer.
    """
    sample = """
    class A:
        def __init__(self):
            super()

    class B(A):
        def __init__(self):
            super()

    class C(A):
        def __init__(self, a):
            super()
     """
    tree = ast.parse(sample)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    sample = """
    class A:
        def __init__(self):
            super(A, self)

    class B(A):
        def __init__(self):
            super(B, self)

    class C(A):
        def __init__(self, a):
            super(C, self)
     """

    assert astor.to_

# Generated at 2022-06-23 23:17:49.025330
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src
    import ast

    # Test replacement of super() calls outside of functions
    tree = ast.parse("""
    class A:
        pass
    super()
    """)
    assert isinstance(tree.body[1], ast.Expr)
    callback = SuperWithoutArgumentsTransformer(tree).visit_Call
    assert callback(tree.body[1].value) == tree.body[1].value

    # Test replacement of super() calls outside of classes
    tree = ast.parse("""
    def foo():
        super()
    """)
    assert isinstance(tree.body[0].body[0].value, ast.Call)
    callback = SuperWithoutArgumentsTransformer(tree).visit_Call

# Generated at 2022-06-23 23:17:52.395206
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    sys.path.append('.')
    from typed_astunparse import unparse
    from iron_python_ast.ast_node_classes import AST


# Generated at 2022-06-23 23:18:02.448625
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[], keywords=[], starargs=None, kwargs=None,
    )
    tree = ast.parse('class A:\n def __init__(self):\n  super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    transformed_node = tree.body[0].body[0].body[0]
    assert isinstance(transformed_node, ast.Call)
    assert (
        type(transformed_node) == type(node) == ast.Call
    ), 'type mismatch: %s != %s' % (type(transformed_node), type(node))

# Generated at 2022-06-23 23:18:12.533879
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    from typed_ast import ast3 as ast
    import astunparse
    import textwrap
    from .base import BaseNodeTransformer

    tree = ast.parse(textwrap.dedent('''\
    class Spam:
        def eggs(self):
            super()

        @classmethod
        def ham(cls):
            super()
    '''))

    transformer = SuperWithoutArgumentsTransformer(tree)
    # Exercise
    actual_tree = transformer.visit(tree)
    # Verify
    expected_tree = textwrap.dedent('''\
    class Spam:
        def eggs(self):
            super(Spam, self)

        @classmethod
        def ham(cls):
            super(Spam, cls)
    ''')
    expected_tree = ast.parse

# Generated at 2022-06-23 23:18:17.293483
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()', '<test>', 'eval').body
    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit(node)
    pragmas = [pragma.args[0].value for pragma in transformer.get_additional_imports()]
    assert pragmas == []
    assert transformer.get_tree_changed()
    assert transformer._tree == ast.parse('super(Cls, self)', '<test>', 'eval')


# Generated at 2022-06-23 23:18:18.750011
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astor.code_gen import to_source


# Generated at 2022-06-23 23:18:19.668249
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:21.490984
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ...py_versions import AST_2_7

# Generated at 2022-06-23 23:18:32.144221
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class DummySuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        pass

    class DummyClass:
        def __init__(self, class_name, method_name):
            self.class_name = class_name
            self.method_name = method_name
            self.tree_changed = False

        def run(self):
            node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
            method_def = ast.FunctionDef(name=self.method_name, args=None, body=[node], decorator_list=[], returns=None)
            class_def = ast.ClassDef(name=self.class_name, bases=[], keywords=[], body=[method_def], decorator_list=[])


# Generated at 2022-06-23 23:18:32.773063
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List


# Generated at 2022-06-23 23:18:36.258345
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..transpilers.super_without_arguments_transformer import SuperWithoutArgumentsTransformer
    from ..utils.tree import make_tree
    import unittest
    import astunparse


# Generated at 2022-06-23 23:18:37.384904
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_source


# Generated at 2022-06-23 23:18:42.486110
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from typed_ast.ast3 import parse as _parse
    import logging
    import traceback
    from ..utils.helpers import setup_logger
    from ..main import update_file

    logging.basicConfig(level=logging.DEBUG)
    logger = setup_logger(name='transformer', output_level=logging.DEBUG)


# Generated at 2022-06-23 23:18:44.790738
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    assert SuperWithoutArgumentsTransformer(None).visit_Call(ast.Call(func=ast.Name(id='super'), args=[], keywords=[])) \
           == ast.Call(func=ast.Name(id='super'), args=[], keywords=[])

# Generated at 2022-06-23 23:18:54.935568
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class MyTestClass(ast.NodeTransformer):
        def generic_visit(self, node):
            return ast.NodeTransformer.generic_visit(self, node)

    class Function:
        def __init__(self, args):
            self.args = args

    class ClassDef:
        def __init__(self, name):
            self.name = name

    class Tree:
        def __init__(self, node):
            self.node = node

    class Call:
        def __init__(self, func, args):
            self.func = func
            self.args = args

    class Name:
        def __init__(self, id):
            self.id = id

    class Arguments:
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-23 23:18:58.897066
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    ast_node = ast.parse(dedent('''
    class Cls:
        def meth(self):
            super()
    '''))
    assert SuperWithoutArgumentsTransformer.compile(ast_node) == dedent('''
    class Cls:
        def meth(self):
            super(Cls, self)
    ''')



# Generated at 2022-06-23 23:19:05.094155
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parser_py import parse
    from ..rewriter_py import PyTreeRewriter
    from ..utils import dump_tree
    
    tree = parse("""class A:
    def __init__(self):
        super()
        
    @classmethod
    def b(cls):
        super()
    """)
    transformer = PyTreeRewriter(tree)
    transformer.register_transformer(SuperWithoutArgumentsTransformer)

    transformer.rewrite()
    assert dump_tree(tree) == """class A:
    def __init__(self):
        super(A, self)
        
    @classmethod
    def b(cls):
        super(A, cls)
    """

# Generated at 2022-06-23 23:19:09.210983
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # 1. Init
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)

    # 2. Compare with expected result
    expected_result = ast.dump(ast.parse("super(Cls, self)"))
    actual_result = ast.dump(node)
    assert actual_result == expected_result

# Generated at 2022-06-23 23:19:14.972524
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
	script_content = 'class A:\n\tdef f(self):\n\t\tsuper()'
	tree = ast.parse(script_content, mode='exec')
	SuperWithoutArgumentsTransformer().visit(tree)
	assert tree[0].body[0].body[0].args[0].id == "A"
	assert tree[0].body[0].body[0].args[1].id == "self"

# Generated at 2022-06-23 23:19:22.540925
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import wrap_in_class

    class_str = ('class Cls:\n'
                 "    def func_method(self):\n"
                 "        super()\n")
    expected_class_str = ('class Cls:\n'
                          "    def func_method(self):\n"
                          "        super(Cls, self)\n")
    class_ast = wrap_in_class(class_str)
    expected_class_ast = wrap_in_class(expected_class_str)

    class_ast = SuperWithoutArgumentsTransformer().visit(class_ast).body[0]
    assert ast.dump(class_ast, include_attributes=False) == ast.dump(expected_class_ast, include_attributes=False)


# Generated at 2022-06-23 23:19:31.621447
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    sample = inspect.cleandoc("""
    class Test:
        def __init__(self):
            super()
            
    """)
    Root = ast.parse(sample)
    SuperWithoutArgumentsTransformer().visit(Root)
    code1 = compile(Root, '', 'exec')
    exec(code1)

    sample = inspect.cleandoc("""
    class Test:
        def __init__(self, x):
            super()
    """)
    Root = ast.parse(sample)
    SuperWithoutArgumentsTransformer().visit(Root)
    code2 = compile(Root, '', 'exec')
    exec(code2)


# Generated at 2022-06-23 23:19:40.734847
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    def a(self):
        super()
    def b(self, *args):
        super()
    def c(self, *args, **kwargs):
        super()
    def d(self, arg):
        super()
    def e(self, arg, **kwargs):
        super()
    def f(self, arg, *args):
        super()
    def g(self, arg, *args, **kwargs):
        super()

# Generated at 2022-06-23 23:19:43.549586
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    root = ast.parse('''if super(): pass''')
    transformer = SuperWithoutArgumentsTransformer(root)
    new_root = transformer.visit(root)

    expected_root = ast.parse('''if super(Cls, self): pass''')

    assert ast.dump(new_root) == ast.dump(expected_root)

# Generated at 2022-06-23 23:19:49.434076
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import _generate_ast_code_from_tree
    from ..utils import _get_node_line_number

    tree = ast.parse("super()")
    assert SuperWithoutArgumentsTransformer().visit(tree)

    assert tree is not None
    assert _generate_ast_code_from_tree(tree) == "super(Cls, self)"
    assert _get_node_line_number(tree, ast.Call) == 1

# Generated at 2022-06-23 23:19:51.182619
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:52.089187
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:53.050015
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:01.938240
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_source_1 = '''
    class A:
        def __init__(self):
            super()
            super(A, self)
    '''

    class_source_2 = '''
    class A:
        def __init__(self):
            super()
    '''

    class_source_3 = '''
    class A:
        def __init__(self):
            super(B, self)
    '''

    expected_source_1 = '''
    class A:
        def __init__(self):
            super(A, self)
            super(A, self)
    '''

    expected_source_2 = '''
    class A:
        def __init__(self):
            super(A, self)
    '''


# Generated at 2022-06-23 23:20:03.561185
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typing
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:20:04.177321
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:08.715983
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.tree_helpers import get_node_text as get

    module = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(module)
    assert get(module) == 'super(C, self)'
    assert SuperWithoutArgumentsTransformer._tree_changed == True

# Generated at 2022-06-23 23:20:09.359502
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:10.122181
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:11.294598
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:16.404924
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from darglint.transformers.helper import Arguments
    from .base import BaseNodeTransformer

    # create argument for the function call
    arg_name = ast.Name(id='a', ctx=ast.Load())
    # ast.Load() returns the value of the node
    arguments = [ast.arg(arg=arg_name, annotation=None)]

    # create function name
    super_name = ast.Name(id='super', ctx=ast.Load())

    # create super() function
    super_call = ast.Call(func=super_name, args=[], keywords=[])

    # create function call arguments