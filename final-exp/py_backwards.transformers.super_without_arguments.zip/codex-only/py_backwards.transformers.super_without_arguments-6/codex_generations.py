

# Generated at 2022-06-23 23:10:09.082437
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:18.010194
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import make_call, make_arg, make_name, make_assign
    cls_name = 'Cls'

# Generated at 2022-06-23 23:10:25.106358
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class C:
        def foo(self, other): pass
        def bar(self, cls): pass
        def baz(self): pass
        def qux(self, foo): pass
    f = C().foo
    b = C().baz
    q = C().qux

    # Test case 1: If the super() call has no arguments, then add the current class name as the first argument and the method name as the second argument.

# Generated at 2022-06-23 23:10:26.528026
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:10:35.662481
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_base import BaseNodeTransformerTestCase, transform, OK

    class Test(BaseNodeTransformerTestCase):
        def test_empty(self):
            tree = ast.parse('super()')
            new_tree = transform(tree, SuperWithoutArgumentsTransformer)

            self.assertEqual(OK, new_tree)
            self.assertEqual('super(Cls, self)\n', to_source(new_tree))

            tree = ast.parse('super()', mode='eval')
            new_tree = transform(tree, SuperWithoutArgumentsTransformer)

            self.assertEqual(OK, new_tree)
            self.assertEqual('super(Cls, cls)', to_source(new_tree))


# Generated at 2022-06-23 23:10:40.092832
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
            super()
        """
    expected_code = """
            super(Cls, self)
        """
    actual_code = astor.to_source(ast.parse(code)).strip()
    expected_code = astor.to_source(ast.parse(expected_code)).strip()
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree, '').visit(tree)
    assert actual_code == expected_code



# Generated at 2022-06-23 23:10:42.583703
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert (SuperWithoutArgumentsTransformer(None, None, None).__class__.__name__
            == "SuperWithoutArgumentsTransformer")

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:10:47.881404
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    root = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(root)
    assert ast.dump(root, include_attributes=True) == \
"""Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))
"""

# Generated at 2022-06-23 23:10:56.441303
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_snippet
    snippet = compile_snippet("""
        class A:
            def __init__(self):
                super()
        A()
        """)
    assert snippet == """
        class A:
            def __init__(self):
                super(A, self)
        A()
        """

    snippet = compile_snippet("""
        class A:
            def __init__(self):
                super(test)
        A()
        """)
    assert snippet == """
        class A:
            def __init__(self):
                super(test)
        A()
        """

# Generated at 2022-06-23 23:11:01.553223
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""class Foo:
                def foo(self):
                    super()
""")  # Notice the super() without arguments

    result = SuperWithoutArgumentsTransformer(tree).result()
    assert ast.dump(result) == ast.dump(
        ast.parse("""class Foo:
                def foo(self):
                    super(Foo, self)
"""))  # The super() has now been transformed to super(Foo, self)

# Generated at 2022-06-23 23:11:06.017522
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import test_utils
    from ..test_utils.test_node_visitor import recompile

    transformer = SuperWithoutArgumentsTransformer(None)
    test_utils.assert_transformer_output(
        transformer,
        {'super().foo()'},
        '''
        class BaseObject:
            def foo(self):
                return 1
        class Child(BaseObject):
            def foo(self):
                return super(Child, self).foo()
        ''')

# Generated at 2022-06-23 23:11:07.011574
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-23 23:11:14.889879
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import util
    from ..transformer import Transformer
    from .pep563 import PEP563Importer

    importer = PEP563Importer()

    # Transform to get the local namespace
    tree = ast.fix_missing_locations(ast.parse("""
        class Test:
            def __init__(self):
                super()
            
            @classmethod
            def test(cls):
                super()
        """))
    trans = Transformer(importer)
    trans.transform(tree)

    trans = SuperWithoutArgumentsTransformer(tree)
    trans.transform()
    source = util.unparse(tree)
    exec(source)  # noqa: S101

    assert isinstance(Test, type)

# Generated at 2022-06-23 23:11:21.259729
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def test_method(parent):
        node = ast.Call(func=ast.Name(id='super'), args=[])
        transformer = SuperWithoutArgumentsTransformer(parent, 2, 7)  # type: ignore
        transformer.visit_Call(node)
        return transformer._tree_changed

    class Mock(ast.AST):

        def __init__(self, name):
            self.name = name

    node = Mock('Class')

    assert not test_method(node)
    assert node.name == 'Class'

# Generated at 2022-06-23 23:11:22.128028
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_restricted


# Generated at 2022-06-23 23:11:24.210518
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from .test_helpers import get_tree_equal
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:11:35.874593
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    from .test_BaseNodeTransformer import BaseNodeTransformerTestCase

    class TestSuperWithoutArgumentsTransformer(BaseNodeTransformerTestCase, unittest.TestCase):
        transformer = SuperWithoutArgumentsTransformer

        def test_super_outside_of_cls(self):
            self.assert_conversion(
                self.transformer,
                'super()',
                'super()',
                'super() outside of class'
            )

        def test_super_outside_of_method(self):
            self.assert_conversion(
                self.transformer,
                '''
                class C:
                    pass
                super()''',
                '''
                class C:
                    pass
                super()''',
                'super() outside of function'
            )


# Generated at 2022-06-23 23:11:44.604711
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_source
    from .base import BaseNodeTransformerTest


    class Test(BaseNodeTransformerTest):
        @property
        def transformer(self) -> BaseNodeTransformer:
            return SuperWithoutArgumentsTransformer



# Generated at 2022-06-23 23:11:45.752512
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:11:54.093268
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("""
    super()
    """).body[0]

    expected = ast.parse("""
    super(Cls, self)
    """).body[0]

    tree = ast.parse("""
    class Cls:
        def func(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse("""
    class Cls:
        def func(self):
            super(Cls, self)
    """))

# Generated at 2022-06-23 23:11:55.243184
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:00.863388
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseNodeTest
    from ..utils.builder import build

    tree = build('''
super().foo()
    ''')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    BaseNodeTest.should_have_code(tree, '''
super(Cls, self).foo()
    ''')

# Generated at 2022-06-23 23:12:11.560899
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    node = ast.parse('super()', mode='eval').body
    newnode = t.visit(node)
    assert ast.dump(newnode) == 'Call(Name(id=\'super\', ctx=Load()), [Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], [])'

    t = SuperWithoutArgumentsTransformer()

    node = ast.parse('super(x)', mode='eval').body
    newnode = t.visit(node)

# Generated at 2022-06-23 23:12:20.312742
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .common import get_node_of_type, get_func_first_arg

    class Dummy(ast.AST):
        def __eq__(self, d) -> bool:
            return True

    tree = ast.parse("class A(B):\n\tdef f(self):\n\t\tsuper()\n\t@classmethod\n\tdef f(cls):\n\t\tsuper()")
    node = get_node_of_type(tree, ast.ClassDef) # type: ast.ClassDef
    cls_name = node.name
    node = get_node_of_type(tree, ast.FunctionDef) # type: ast.FunctionDef
    func_name = node.name

# Generated at 2022-06-23 23:12:30.287622
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    
    from typed_ast import ast3 as ast
    from ..utils.helpers import deep_parse

    class Foo:
        pass

    # Should warn and do nothing
    tree = deep_parse('''super()''')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree.body[0].value.args == []

    # Should warn and do nothing
    tree = deep_parse('''def foo():
        super()''')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree.body[0].body[0].value.args == []

    # Should warn and do nothing
    tree = deep_parse('''super()''', mode='eval')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree.body.value.args == []

# Generated at 2022-06-23 23:12:32.369950
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astroid
    from astroid import scoped_nodes
    from ..utils.helpers import get_node

    from ..exceptions import NodeNotFound


# Generated at 2022-06-23 23:12:33.638868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:12:42.437691
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code_to_ast import source_code_to_ast

    class SuperWithoutArgumentsTransformerSubclass(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._version = 3.6
            self._tree = source_code_to_ast("""
from a import b as c
from a import b as d
""")

    transformer = SuperWithoutArgumentsTransformerSubclass()
    transformer.visit(transformer._tree)
    assert transformer._tree_changed == True
    assert transformer._tree.body[0].names[0].asname == 'c'
    assert transformer._tree.body[1].names[0].asname == 'd'

# Generated at 2022-06-23 23:12:43.068439
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:49.377470
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake import FakeTree
    from ..utils import transformer

    # super()
    tree = FakeTree()
    tree.append_node('ClassDef', 'Cls')
    tree.add_child('ClassDef', 'FunctionDef', 'f')
    tree.append_node('Name', 'super')
    
    transformer.print_tree(tree, 'Name')
    trans = SuperWithoutArgumentsTransformer(tree)
    trans.visit_Call(tree.children[0])
    transformer.print_tree(tree, 'Call')

# Generated at 2022-06-23 23:12:49.943961
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:55.378482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    transformer = BaseNodeTransformer.register_transformer(SuperWithoutArgumentsTransformer)
    tree = ast3.parse('class C:\n def __init__(self):\n  super()')
    transformer.visit(tree)
    assert str(tree) == 'class C:\n def __init__(self):\n  super(C, self)'



# Generated at 2022-06-23 23:13:06.449356
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode_str
    from ..utils.helpers import bytecode_to_str

    # Check code generation
    tree = ast.parse(source_to_unicode_str("""
    class Foo:
        def __init__(self):
            super()
            """), mode='exec')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 23:13:10.161342
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')  # type: ignore
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree == ast.parse('super(Cls, self)')  # type: ignore

# Generated at 2022-06-23 23:13:12.274916
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import FunctionDef, ClassDef, Call, Name, parse


# Generated at 2022-06-23 23:13:13.413495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:14.092303
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:22.469477
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def test_func(self):
        super()

    # Loads node
    node = ast.parse("super()")
    node = node.body[0]

    # Put node in function
    func = ast.FunctionDef(name='test_func', args=ast.arguments(), body=[node], decorator_list=[], returns=None)
    node = func

    # Put node in class
    class_ = ast.ClassDef(name='ClassName', bases=[], keywords=[], body=[node], decorator_list=[])
    node = class_

    # Parse the tree
    tree = ast.parse(
        "class ClassName:\n    def test_func(self):\n        super()\n"
    )

    #
    sut = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-23 23:13:32.580048
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call(
        ast.Name(id='super'),
        [],
        [],
        None,
        None
    )

    cls = ast.ClassDef(
        'Cls',
        [],
        [],
        [],
        [],
        [],
        None
    )

    func = ast.FunctionDef(
        'func',
        ast.arguments(
            [
                ast.arg('self', None)
            ],
            None,
            None,
            []
        ),
        [],
        [],
        [],
        None,
        None
    )

    result = SuperWithoutArgumentsTransformer._replace_super_args(node, cls, func)


# Generated at 2022-06-23 23:13:41.672942
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import generate_code_from_ast
    import textwrap
    code = textwrap.dedent('''
    class Cls():
        def __init__(self):
            super()
    ''')
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:13:48.553370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    from ..transpilers.helpers import get_transformed_ast, get_source_code


# Generated at 2022-06-23 23:13:49.129042
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:49.658820
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:13:54.892144
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_example_path
    from ..utils import get_assert_string
    code = get_assert_string(get_example_path('super.py'))

    ast_tree = ast.parse(code)
    test_tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(test_tree)

    assert ast_tree == test_tree

# Generated at 2022-06-23 23:13:56.401508
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:13:57.804562
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor


# Generated at 2022-06-23 23:14:04.009020
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode, source_to_ast

    code = """
        class Cls:
            def method(self):
                super()
    """

    tree = source_to_ast(source_to_unicode(code))
    node_transformer = SuperWithoutArgumentsTransformer(tree)

    with pytest.raises(NodeNotFound):
        node_transformer.visit(tree)

    assert str(node_transformer.tree) == """
        class Cls:
            def method(self):
                super(Cls, self)
    """



# Generated at 2022-06-23 23:14:09.447374
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Test(object):
            def test(self):
                super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '', 'exec')
    ns = {}
    exec(compiled, ns)
    assert 'Test' in ns
    assert hasattr(ns['Test'], 'test')


# Generated at 2022-06-23 23:14:19.827482
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import cst_to_ast
    from .base import BaseNodeTransformer
    import astunparse
    import sys

    class A(BaseNodeTransformer): pass
    class B(A): pass

    A.target = sys.version_info

    node = cst_to_ast("""
    class X:
        def __init__(self):
            super()
    """)
    A().visit(node)
    assert astunparse.unparse(node) == "class X:\n    def __init__(self):\n        super(X, self)"

    node = cst_to_ast("""
    class X:
        def __init__(self):
            super()
    """)
    A().visit(node)

# Generated at 2022-06-23 23:14:20.821353
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:26.416939
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import tree_from, extract_node
    from ..codegen import to_source

    code = '''
        class A:
            def test(self):
                super()
    '''

    tree = tree_from(code)
    node = extract_node(tree, Call)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert transformer.tree_changed
    assert to_source(node) == 'super(A, self)'

# Generated at 2022-06-23 23:14:27.849322
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    import astor


# Generated at 2022-06-23 23:14:32.579804
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import generate_equivalent_code
    code = 'super().__init__()'
    expected_code = 'super(C, self).__init__()'
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    new_code = generate_equivalent_code(tree)
    assert new_code == expected_code

# Generated at 2022-06-23 23:14:33.276935
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:34.264941
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:40.371861
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse(
        """
        class Cls:
            def method(self):
                super()

            class Inner:
                def inner_method(self):
                    super()
        """
    )

    SuperWithoutArgumentsTransformer().visit(node)

    assert 'super(Cls, self)' in astor.to_source(node)
    assert 'super(Inner, self)' in astor.to_source(node)

# Generated at 2022-06-23 23:14:43.748164
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import get_func_body

    node = ast.parse('super()')
    xform = SuperWithoutArgumentsTransformer()

    new_node = xform.visit(node)
    func_body = get_func_body(new_node)
    assert astor.to_source(func_body[0]).strip() == 'super(Cls, self)'



# Generated at 2022-06-23 23:14:53.067756
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    import inspect
    import textwrap
    from ..utils.ast_helpers import ast_to_source
    from ..visitor import NodeTransformerVisitor

    module_code = textwrap.dedent("""
        class A:
            def __init__(self):
                super()
                
        class B(A):
            def __init__(self, param):
                super()
        """)

    tree = ast.parse(module_code)

    visitor = NodeTransformerVisitor()
    visitor.visit(tree)


# Generated at 2022-06-23 23:15:02.160500
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        def test_super_without_arguments(self):
            tree = ast.parse("class A:super()")
            transformer = SuperWithoutArgumentsTransformer()
            transformer.visit(tree)

            self.assertEqual(
                ast.dump(tree),
                "Module(body=[ClassDef(name='A', bases=[], keywords=[], body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='A', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))], decorator_list=[])])")
    unittest.main()

# Generated at 2022-06-23 23:15:10.116720
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    nodes = astor.code_to_ast.parse_file('tests/fixtures/super_without_arguments.py')
    node = nodes.body[2].body[0].body[1].body[0]
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 0

    SuperWithoutArgumentsTransformer().visit(nodes)
    node = nodes.body[2].body[0].body[1].body[0]
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2
    assert isinstance(node.value.args[0], ast.Name)
    assert isinstance(node.value.args[1], ast.Name)

# Generated at 2022-06-23 23:15:20.421184
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    code = 'super()'
    tree = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    tree = ast.fix_missing_locations(tree)
    compiled = compile(tree, '<string>', 'exec')
    assert eval(compiled) == 'super(Test, self)'
    code = 'super(Cls, self)'
    tree = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    tree = ast.fix_missing_locations(tree)

# Generated at 2022-06-23 23:15:27.070682
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import astunparse
    import sys

    transformer = SuperWithoutArgumentsTransformer(2, 7, None)

    tree = ast.parse('''
        class A:
            def f(self):
                super()

        class B:
            def f(cls):
                super()
    ''')

    transformer.visit(tree)

    lines = astunparse.unparse(tree).split('\n')
    assert lines[5] == '        super(A, self)'
    assert lines[11] == '        super(B, cls)'



# Generated at 2022-06-23 23:15:28.085911
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from astmonkey import transformers


# Generated at 2022-06-23 23:15:32.719799
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0].value, ast.Call)
    assert node.body[0].value.func.id == 'super'
    assert len(node.body[0].value.args) == 2
    assert node.body[0].value.args[0].id == 'Cls'
    assert node.body[0].value.args[1].id == 'self'


# Generated at 2022-06-23 23:15:33.483175
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import _ast as ast


# Generated at 2022-06-23 23:15:33.981821
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:44.416723
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer, TransformerResult
    from .parent import ParentNodeTransformer

    class TestTransformer(BaseNodeTransformer):

        def visit_Call(self, node: ast.Call) -> TransformerResult:
            return node

    node = ast.parse(
        "super()",
        mode="exec"
    )

    trans = TestTransformer()
    trans.visit(node)

    trans = ParentNodeTransformer()
    trans.visit(node)

    trans = SuperWithoutArgumentsTransformer()
    node = trans.visit(node)

    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)

# Generated at 2022-06-23 23:15:53.718992
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    import textwrap
    from .base import BaseNodeTransformer
    from .mktree import mktree
    from .super_without_arguments import SuperWithoutArgumentsTransformer

    astnode = ast.parse(textwrap.dedent('''\
        class Cls:
            def __init__(self):
                super()
    
        class Cls2:
            def __init__(self):
                super(Cls2, self)
    
        class Cls3:
            def __init__(self):
                super(Cls3, whatever)
        '''))
    tree = mktree(astnode)

    node_transformer = SuperWithoutArgumentsTransformer(tree)
    tree_changed = node_transformer.run()

    assert tree_changed is True

# Generated at 2022-06-23 23:16:00.290711
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node_input = ast.Call(
        func=ast.Name(id='super'),
        args=[],
        keywords=[]
    )
    node_output = ast.Call(
        func=ast.Name(id='super'),
        args=[ast.Name(id='Cls'), ast.Name(id='self')],
        keywords=[]
    )
    tree_input = ast.parse("def func(self):\n    super()\n")
    tree_output = ast.parse("def func(self):\n    super(Cls, self)\n")
    tree_input.body[0].body.append(node_input)
    tree_output.body[0].body.append(node_output)

# Generated at 2022-06-23 23:16:02.064085
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    # 1.

# Generated at 2022-06-23 23:16:12.340109
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code import SourceCode
    from ..utils.ast2 import parse

    src = """
    class A(object):
        def __init__(self):
            super().__init__()
    """
    tree = parse(src)
    transformer = SuperWithoutArgumentsTransformer(SourceCode(src, tree=tree))
    tree = transformer.visit(tree)
    assert len(tree.body) == 1
    class_def = tree.body[0]
    assert isinstance(class_def, ast.ClassDef)
    assert len(class_def.body) == 1
    func_def = class_def.body[0]
    assert isinstance(func_def, ast.FunctionDef)
    assert len(func_def.body) == 1
    call = func_def.body[0]
   

# Generated at 2022-06-23 23:16:12.632961
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:13.143172
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:13.528370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:20.599255
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_source = '''
    class Base:
        def __init__(self):
            super().__init__()

    class Transformed(Base):
        def __init__(self):
            super().__init__()
    '''

    transformed_class_source = '''
    class Base:
        def __init__(self):
            super(Base, self).__init__()

    class Transformed(Base):
        def __init__(self):
            super(Transformed, self).__init__()
    '''
    
    class_ast = compile(class_source, filename="<ast>", mode="exec", flags=ast.PyCF_ONLY_AST)

# Generated at 2022-06-23 23:16:23.488762
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor; from pprint import pprint


    tree: ast.Module
    transpiled_tree: ast.Module
    code: str
    super_arg: ast.Name



# Generated at 2022-06-23 23:16:33.154998
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Tests:
        super()
    To:
        super(Cls, self)
        super(Cls, cls)
            
    """
    from utils.helpers import get_node_name

    test_code = "super()"
    expected_code = "super(Cls, self)"
    module = ast.parse(test_code)
    node = get_node_name("super()", module)
    assert isinstance(node, ast.Call)
    func = get_node_name("super", node)
    assert isinstance(func, ast.Name)
    assert node.func.id == "super" and not len(node.args)
    transformer = SuperWithoutArgumentsTransformer(module, {})
    new_node = transformer.visit(node)

# Generated at 2022-06-23 23:16:35.504425
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object
    from ..compiler import compile_
    from .base import BaseNodeTransformer


# Generated at 2022-06-23 23:16:36.298538
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:40.392466
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)
    transformer = get_transformer(ast.parse(code))
    tr = transformer(code)
    assert source(tr(tree)) == 'super(Cls, cls)'

# Generated at 2022-06-23 23:16:44.746987
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:16:48.439320
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    assert unparse(node) == 'super(Cls, self)'

    node = ast.parse('super()')
    node.body[0].args = [ast.Name(id='a', ctx=ast.Load())]
    SuperWithoutArgumentsTransformer().visit(node)
    assert unparse(node) == 'super(Cls, a)'


# Generated at 2022-06-23 23:16:52.119772
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing_utils import run_test_ast_transformer
    from ..utils.venv_utils import build_venv, destroy_venv

    venv_path = build_venv()
    try:
        run_test_ast_transformer(SuperWithoutArgumentsTransformer, venv_path)
    finally:
        destroy_venv(venv_path)

# Generated at 2022-06-23 23:16:56.881684
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    visitor = SuperWithoutArgumentsTransformer()
    node = visitor.visit_Call(node.body[0].value)

    assert visitor._tree_changed
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:17:07.765183
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "class Test: def test(self): super()"
    assert get_fixed_code(code, 2, 7) == "class Test: def test(self): super(Test, self)"
    code = "class Test: def test(): super()"
    assert get_fixed_code(code, 2, 7) == "class Test: def test(): super(None, None)"
    code = "class Test: def test(arg): super()"
    assert get_fixed_code(code, 2, 7) == "class Test: def test(arg): super(Test, arg)"
    code = "def test(): super()"
    assert get_fixed_code(code, 2, 7) == "def test(): super(None, None)"
    code = "def test(arg): super()"

# Generated at 2022-06-23 23:17:17.347823
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from typing import Callable
    from typed_ast import ast27, ast3 as ast
    Module = ast27.Module
    FunctionDef = ast27.FunctionDef
    Name = ast27.Name
    arguments = ast27.arguments
    Call = ast27.Call
    ClassDef = ast27.ClassDef
    Subscript = ast27.Subscript
    Load = ast27.Load
    Index = ast27.Index
    Tuple = ast27.Tuple
    Attribute = ast27.Attribute
    compiled = ['super()', 'super()[0]', 'super().foo', 'super().foo()']
    expected = ['super(Cls, self)', 'super(Cls, self)[0]', 'super(Cls, self).foo', 'super(Cls, self).foo()']

# Generated at 2022-06-23 23:17:24.731544
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as python_ast
    import parser
    import typing

    class SuperNode(python_ast.AST):
        _fields = ()

    class CallNode(python_ast.AST):
        _fields = ('args', 'func')
        args = typing.List[python_ast.AST]
        func = SuperNode

    class FunctionDef(python_ast.AST):
        _fields = ('args',)
        args = python_ast.arguments

    class Arguments(python_ast.AST):
        _fields = ('args',)
        args = typing.List[python_ast.arg]

    class Arg(python_ast.AST):
        _fields = ('arg',)
        arg = str

    class ClassDef(python_ast.AST):
        _fields = ('name',)
        name = str


# Generated at 2022-06-23 23:17:25.806642
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:26.509974
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:32.195825
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    src = """class Foo():
    def __init__(self):
        super().__init__()
    """

    dest = """class Foo():
    def __init__(self):
        super(Foo, self).__init__()
    """

    node = ast.parse(src)
    SuperWithoutArgumentsTransformer().visit(node)

    assert astor.to_source(node) == dest

# Generated at 2022-06-23 23:17:38.794676
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import (FunctionDef)

    tree = ast.parse("""
        class Foo:
            def __init__(self):
                super()
        """)

    node = tree.body[0].body[0]
    assert isinstance(node, FunctionDef)

    sut = SuperWithoutArgumentsTransformer(tree=tree)
    sut.visit(node)

    tree.body[0].body[0].body[0].func.args[0].id == 'Foo'



# Generated at 2022-06-23 23:17:46.648884
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    example_input = """
    class A:
        def __init__(self):
            super().__init__()
        
        def __init__(self, cls):
            super().__init__()
        
        def __init__(self, self):
            super().__init__()
    
    super().__init__()
    """
    expected_output = """
    class A:
        def __init__(self):
            super(A, self).__init__()
        
        def __init__(self, cls):
            super(A, cls).__init__()
        
        def __init__(self, self):
            super(A, self).__init__()
    
    super(A, self).__init__()
    """

# Generated at 2022-06-23 23:17:57.151213
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests that class SuperWithoutArgumentsTransformer works as intended"""
    from .. import compile_to_ast
    from .test_helpers import assert_parses_to_correct_ast

    source = """
        class MyClass(object):
            def method(self):
                super()
                super(MyClass)
                super(MyClass, self)
    """        

# Generated at 2022-06-23 23:18:05.898999
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
for i in range(10):
    class A(object):
        def foo(self):
            super().foo()
    # comment
    def bar():
        super().bar()
        # comment
    '''
    parser = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(parser)
    transformer.visit(parser)
    m = ast.parse('''
for i in range(10):
    class A(object):
        def foo(self):
            super(A, self).foo()
    # comment
    def bar():
        super(A, self).bar()
        # comment
    ''')
    assert ast.dump(parser) == ast.dump(m)

# Generated at 2022-06-23 23:18:15.249386
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    cls = node.body[0].value
    func = node.body
    setattr(cls, 'name', 'C')
    setattr(func[0], 'args', ast.arguments(args=[ast.Name(id='self', ctx=ast.Param(), lineno=1, col_offset=0)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]))
    setattr(func[0], 'name', 'func')
    setattr(node, 'body', func)
    args = node.body[0].value.args
    assert isinstance(args, ast.Call)
    assert len(args.args) == 0
    SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance

# Generated at 2022-06-23 23:18:24.266754
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    code = 'class A:\n    def f(self):\n        super()'
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    print(astor.to_source(tree))

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    print(astor.to_source(tree))

    code = 'class A:\n    @classmethod\n    def f(self):\n        super()'
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    print(astor.to_source(tree))


# Generated at 2022-06-23 23:18:34.590777
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..transformers.base import TransformerSequence
    from ..transformers.base import FunctionDefTransformer
    from ..transformers.base import ClassDefTransformer
    from ..transformers.base import ArgumentsTransformer

    ts = TransformerSequence()
    ts.append(FunctionDefTransformer())
    ts.append(ClassDefTransformer())
    ts.append(ArgumentsTransformer())
    ts.append(SuperWithoutArgumentsTransformer())

    source = """class Foo(object):
    def __init__(self):
        super()

    def bar(self):
        super()"""


# Generated at 2022-06-23 23:18:40.151889
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''super()'''
    tree = ast.parse(code)
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)
    super_without_arguments_transformer.run()

    expected_code = '''super(MyClass, self)'''
    expected_tree = ast.parse(expected_code)

    assert ast.dump(tree) == ast.dump(expected_tree)

# Unit tests for method _replace_super_args of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:50.684861
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.codegen import to_source
    from ..utils.helpers import dedent_source

    def compile_strip(src: str) -> str:
        return to_source(SuperWithoutArgumentsTransformer(dedent_source(src)).visit(ast.parse(dedent_source(src))))

    assert compile_strip('''
    class A:
        def a(self):
            super().a()
        def b(self):
            super().b()
    ''') == '''
    class A:
        def a(self):
            super(A, self).a()
        def b(self):
            super(A, self).b()
    '''


# Generated at 2022-06-23 23:18:59.591112
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from typed_ast.ast3 import Name, Call, Num, Assign, Module, Tuple, FunctionDef, Load, Store, Num, NameConstant, ClassDef


# Generated at 2022-06-23 23:19:07.665324
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .utils import maybe_fix_missing_locations, NodeTransformerTestCase

    class Test(NodeTransformerTestCase):
        target = SuperWithoutArgumentsTransformer
        target_version = (2, 7)

        def test_it(self):
            code = """
            class Foo(object):
                def foo(self):
                    super()
                def bar(cls):
                    super()
            """
            expected_code = """
            class Foo(object):
                def foo(self):
                    super(Foo, self)
                def bar(cls):
                    super(Foo, cls)
            """
            ast_tree = maybe_fix_missing_locations(ast3.parse(code))
            super_trans = self.transform(ast_tree)
            code = compile

# Generated at 2022-06-23 23:19:08.668310
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


# Generated at 2022-06-23 23:19:15.462882
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..utils.mock_tree import build_mock_tree
    from ..utils.helpers import get_ast

    code = '''
    class Cls:
        def f(self):
            super()
    '''
    t = build_mock_tree(get_ast(code))
    t.apply(SuperWithoutArgumentsTransformer)
    assert str(t) == '''
    class Cls:
        def f(self):
            super(Cls, self)
    '''

# Generated at 2022-06-23 23:19:22.855502
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import astor
    from copy import deepcopy
    from ..utils.test_utils import generate_call_to_test

    class TestVisitCall(unittest.TestCase):
        def test_with_raise(self):
            source = '''
            class C:
                def f(self):
                    super()
            '''
            expected = '''
            class C:
                def f(self):
                    super(C, self)
            '''
            tree = ast.parse(source)
            SuperWithoutArgumentsTransformer(tree).recursive_run()
            self.assertEqual(astor.to_source(tree).strip(), expected.strip())


# Generated at 2022-06-23 23:19:26.245814
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Example:
        def example_function(self):
            super()
    """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))


# Generated at 2022-06-23 23:19:29.414574
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transpile_node(tree, SuperWithoutArgumentsTransformer)
    assert transpile_func(tree) == 'super(__class__, self)'


# Generated at 2022-06-23 23:19:39.244796
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test with simple working code and assert the output is as expected
    code = """
        class X:
            def __init__(self):
                super()

        @classmethod
        def test(cls):
            super()
    """
    expected_code = """
        class X:
            def __init__(self):
                super(X, self)

        @classmethod
        def test(cls):
            super(X, cls)
    """
    assert SuperWithoutArgumentsTransformer(code).get_new_code() == expected_code

    # Test with simple invalid code and assert that the code does not change

# Generated at 2022-06-23 23:19:42.447712
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .helper import represent
    from .helper import get_ast

    cases = [
        'super()',

        '''
         class Cls:
             def method(self):
                 super()
        '''
    ]

    for case in cases:
        root = get_ast(case)
        transformer = SuperWithoutArgumentsTransformer()
        transformer.visit(root)
        assert case != represent(root)

# Generated at 2022-06-23 23:19:46.854813
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Create instance of the SuperWithoutArgumentsTransformer
    super_args_transformer = SuperWithoutArgumentsTransformer(None)

    # Create a node for the type ast.Call
    node = ast.Call(func=ast.Name(id="super"), args=[])

    # Modify node
    result = super_args_transformer.visit_Call(node)

    # Check the result
    assert(isinstance(result, ast.Call) and isinstance(result.func, ast.Name) and isinstance(result.args[0], ast.Name) and isinstance(result.args[1], ast.Name) and result.func.id == "super" and result.args[0].id == "Cls" and result.args[1].id == "self")

# Generated at 2022-06-23 23:19:52.687233
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    code = '''
        class Bar():
            def foo():
                super()
        '''
    expected = '''
        class Bar():
            def foo():
                super(Bar, foo)
        '''
    tree = ast.parse(code)
    t.visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 23:20:01.692832
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # test 1
    source = '''super()'''
    expected = '''super(Cls, self)'''
    tree = ast.parse(dedent(source))
    SuperWithoutArgumentsTransformer(tree).run()
    assert format_code(tree) == dedent(expected)

    # test 2
    source = '''f(super())'''
    expected = '''f(super(Cls, self))'''
    tree = ast.parse(dedent(source))
    SuperWithoutArgumentsTransformer(tree).run()
    assert format_code(tree) == dedent(expected)

    # test 3
    source = '''@dec
    def f():
        super()
    '''
    expected = '''@dec
    def f():
        super(Cls, self)
    '''
   

# Generated at 2022-06-23 23:20:02.293238
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:20:04.771559
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import compile_func, dump_tree
    import sys


# Generated at 2022-06-23 23:20:15.984121
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')

    class DummyClass:
        def foo(self):
            super()

    cls = DummyClass()
    transformer = SuperWithoutArgumentsTransformer(tree, cls)
    transformer()

    assert transformer._tree_changed
    assert tree._fields == ('body',)
    assert tree.body[0]._fields == ('name', 'bases', 'body', 'decorator_list')
    assert tree.body[0].name == 'DummyClass'
    assert tree.body[0].bases == []
    assert tree.body[0].body[0]._fields == ('name', 'args', 'body', 'decorator_list')
    assert tree.body[0].body[0].name == 'foo'
    assert tree.body[0].body[0].args._