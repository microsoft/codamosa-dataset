

# Generated at 2022-06-23 23:10:15.877223
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
        class A:
            def __init__(self, val):
                super().__init__(val)
        """)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(A, self).__init__(val)" in astor.to_source(tree).strip()

# Generated at 2022-06-23 23:10:17.145690
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import UnitTestTransformer


# Generated at 2022-06-23 23:10:23.750913
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:26.097890
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object
    from ..utils.node import node_to_format_string

# Generated at 2022-06-23 23:10:27.049139
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-23 23:10:36.400740
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast import parse, Call, Name
    from typed_ast import ast3
    ast_tree = parse('super()')
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(ast_tree)
    assert type(ast_tree.body[0].value) is Call
    assert ast_tree.body[0].value.args[1].id == 'self'

    tree = ast3.parse('super()')
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(tree)
    assert type(tree.body[0].value) is Call
    assert type(tree.body[0].value.args[0]) is Name
    assert type(tree.body[0].value.args[1]) is Name
    assert tree.body[0].value.args[1].id == 'self'


# Unit

# Generated at 2022-06-23 23:10:36.849358
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:10:45.442801
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import transform, inspect_tree
    # Test that super() is transformed when used in a method
    tree = transform("""
    class Test:
        def method(self):
            super()
    """, SuperWithoutArgumentsTransformer)
    assert len(tree.body[0].body[0].body[0].args) == 2
    # Test that super() is transformed when used in a function outside class
    tree = transform("""
    def method():
        super()
    """, SuperWithoutArgumentsTransformer)
    assert len(tree.body[0].body[0].args) == 2
    # Test that super() is transformed when used in a inner class method

# Generated at 2022-06-23 23:10:50.450146
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ast_helper import assert_source

    source = 'super()'
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_source(astor.to_source(tree), 'super(Cls, self)')



# Generated at 2022-06-23 23:10:53.121661
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import to_source
    import astunparse
    
    
    

# Generated at 2022-06-23 23:10:54.135626
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:57.614458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .helpers import build_visitor_test_case

    code = """super()"""
    expected = """super(Cls, self)"""

    module, _ = build_visitor_test_case(SuperWithoutArgumentsTransformer, code, expected, 1)

# Generated at 2022-06-23 23:11:02.275832
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    code = """class Foo:
        def bar(self):
            super()
    """
    tree = ast.parse(code)
    t.visit(tree)
    exec(compile(tree, filename='', mode='exec'), globals())
    assert Foo.__init__.__func__.__defaults__ == ()

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:11:09.929533
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""class Cls():
    def __init__(self, a):
        super()""")
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert isinstance(tree.body[0], ast.ClassDef)
    assert tree.body[0].name == "Cls"
    assert isinstance(tree.body[0].body[0], ast.FunctionDef)
    assert tree.body[0].body[0].name == "__init__"
    assert tree.body[0].body[0].args.args[0].arg == "self"
    assert tree.body[0].body[0].body[0].func.id == "super"
    assert tree.body[0].body[0].body[0].args[0].id == "Cls"
    assert tree

# Generated at 2022-06-23 23:11:12.061999
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:19.925553
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast

    example_1 = compile_to_ast("""
    class A:
        def __init__(self):
            super().__init__()
    """)
    t_1 = SuperWithoutArgumentsTransformer(tree=example_1)
    t_1.visit(example_1)
    assert t_1._tree_changed is True
    assert isinstance(example_1.body[0].body[0].value.func.args[0], ast.Name)
    assert isinstance(example_1.body[0].body[0].value.func.args[1], ast.Name)

# Generated at 2022-06-23 23:11:21.355080
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test if the class SuperWithoutArgumentsTransformer exists"""
    assert SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:31.684367
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import run_test_driver
    from . import set_up_transformers_with_clone
    from .test_BaseNodeTransformer import test_BaseNodeTransformer_with_class

    class TD(run_test_driver.TestDriver):

        def test_missing_args(self):
            code = """
            class C:
                def __init__(self):
                    super()
            """
            expect = """
            class C:
                def __init__(self):
                    super(C, self)
            """
            self.diff_source_files(code, expect, set_up_transformers_with_clone(SuperWithoutArgumentsTransformer,
                                                                               test_BaseNodeTransformer_with_class))


# Generated at 2022-06-23 23:11:33.506235
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    obj = SuperWithoutArgumentsTransformer({}, {})

# Generated at 2022-06-23 23:11:43.136564
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import fix_py27_ast
    from typed_ast import ast3 as ast
    from astunparse import unparse
    node = ast.parse('super()')
    fix_py27_ast(node)
    code = unparse(node)
    assert code == 'super(Cls, self)'

    node = ast.parse('super().f()')
    fix_py27_ast(node)
    code = unparse(node)
    assert code == 'super(Cls, self).f()'

    node = ast.parse('''class C:
    def m(self):
        super().f()''')
    fix_py27_ast(node)
    code = unparse(node)

# Generated at 2022-06-23 23:11:51.823023
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import make_test_tree

    src = """def f():
    super()"""
    expected_result = """def f():
    super(Cls, f)"""

    tree = make_test_tree(src)

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit()

    result = tree.body[0].body[0].value
    assert isinstance(result, ast.Call)
    assert result.func.id == 'super'
    assert result.args[0].id == 'Cls'


# Generated at 2022-06-23 23:11:52.795485
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:54.023556
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:12:05.162190
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def __init__(self):
                super()
        class B:
            def __init__(self, x):
                super()
        class C:
            def __init__(self, x, y=1, *args, **kwargs):
                super()
        class D:
            def __init__(self, x, y=1, *, z = 1):
                super()
    '''

# Generated at 2022-06-23 23:12:09.081647
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """super()"""
    expect = """super(Cls, self)"""
    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    output = astor.to_source(tree)
    assert expect == output

# Generated at 2022-06-23 23:12:14.961572
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import textwrap
    code = textwrap.dedent("""
    class A(object):
        def f(self):
            super()
    """)
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '<>', 'exec', dont_inherit=True)  # type: ignore

# Generated at 2022-06-23 23:12:18.234557
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_nested_ast as stna
    from ..utils.source import source_to_ast_node as stan

# Generated at 2022-06-23 23:12:23.974847
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    result = transformer.visit(node)
    assert transformer._tree_changed == True
    assert result.body[0].value.args[0].id == 'Cls'
    assert result.body[0].value.args[1].id == 'self'


# Generated at 2022-06-23 23:12:25.877057
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass



# Generated at 2022-06-23 23:12:30.773353
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse("""
        class Cls:
            def meth(self):
                super()
    """)

    tr = SuperWithoutArgumentsTransformer()
    tr.visit(module)
    expected = """
        class Cls:
            def meth(self):
                super(Cls, self)
    """  # noqa
    assert dump_ast(module) == expected



# Generated at 2022-06-23 23:12:31.575559
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:39.144686
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Foo:
        def method_1(self):
            super()

        def method_2(cls):
            super()

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast.parse(dedent(Foo.__doc__)))

    assert transformer._tree_changed is True
    assert transformer._tree == ast.parse(dedent(
        """
        class Foo:
            def method_1(self):
                super(Foo, self)
            
            def method_2(cls):
                super(Foo, cls)
        """))


# Generated at 2022-06-23 23:12:48.980977
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import to_source

    module = ast.parse('super()')
    SuperWithoutArgumentsTransformer(target_version=(2, 7)).visit(module)
    assert to_source(module) == 'super(Cls, self)'

    module = ast.parse('super().some_method')
    SuperWithoutArgumentsTransformer(target_version=(2, 7)).visit(module)
    assert to_source(module) == 'super(Cls, self).some_method'

    module = ast.parse('super().some_method()')
    SuperWithoutArgumentsTransformer(target_version=(2, 7)).visit(module)
    assert to_source(module) == 'super(Cls, self).some_method()'

    module = ast.parse('super()[var]')
    SuperWithoutArg

# Generated at 2022-06-23 23:12:56.995774
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..fixes.fix_super_without_arguments import SuperWithoutArgumentsTransformer
    tree = ast.parse('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:13:08.104463
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test method visit_Call of class SuperWithoutArgumentsTransformer"""
    from pprint import pprint
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import generate_class_node

    source = source_to_unicode('''
    class A(object):
        def __init__(self):
            super()
    ''')

    tree = ast.parse(source)
    treestr = tree_to_str(tree)

    print('===== Before SuperWithoutArgumentsTransformer =====')
    pprint(treestr)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    treestr = tree_to_str(tree)


# Generated at 2022-06-23 23:13:19.224035
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_
    from .utils import get_node_of_type

    code = """
    class A:
        def __init__(self):
            super()
    
    class B:
        def __init__(self):
            super().__init__()
            
    """
    tree = compile_(code, '<test>', 'exec')
    nodes = [get_node_of_type(tree, ast.Call, index=i) for i in [0, 1]]
    names = ['A', 'B']
    func_names = ['__init__', '__init__']

    for i, node in enumerate(nodes):
        assert isinstance(node.func, ast.Attribute)
        assert isinstance(node.func.value, ast.Name)

# Generated at 2022-06-23 23:13:21.155521
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:13:31.471109
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # pylint: disable=too-many-lines
    from ..test_utils import assert_transformation, transformation_fixture

    # py2:
    #  class Cls(object):
    #      def __init__(self):
    #          super()
    #
    #  class Cls(object):
    #      def __new__(cls):
    #          super()
    #
    #
    # py3:
    #  class Cls:
    #      def __init__(self):
    #          super()
    #
    #  class Cls:
    #      def __new__(cls):
    #          super()
    #

# Generated at 2022-06-23 23:13:40.580936
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_source_equal
    from ..utils.source import Source
    from ..utils.tree import get_node_of_type
    import typed_astunparse

    class Cls(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = [ast.Name(id=node.func.id), ast.Num(n=3.14)]
            return self.generic_visit(node)  # type: ignore

    source = Source("""
    class Cls:
        def foo(self):
            super()
        def bar(cls):
            super()
        
    """)

    tree = source.ast
    transformer = Cls()
    transformer.visit(tree)



# Generated at 2022-06-23 23:13:43.260262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert (str(SuperWithoutArgumentsTransformer(None, None).visit(ast.parse('super()').body[0])) == 
        str(ast.parse('super(Cls, cls)').body[0]))

# Generated at 2022-06-23 23:13:49.293017
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    import textwrap

    source = textwrap.dedent("""\
        class A(object):
            def foo(self):
                super()
            def bar(cls):
                super()""")

    expected_output = textwrap.dedent('''\
        class A(object):
            def foo(self):
                super(A, self)
            def bar(cls):
                super(A, cls)''')

    tree = ast.parse(source)
    node = tree.body[0]
    SuperWithoutArgumentsTransformer(ast.fix_missing_locations(tree), source).visit(node)
    BaseNodeTransformerTest.compare(expected_output, tree)

# Generated at 2022-06-23 23:13:58.424723
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import Call
    import typed_ast.ast3 as ast
    from ..utils.helpers import compare_ast

    transformer = SuperWithoutArgumentsTransformer()

    node = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.arg(arg='foo', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    super_ = Call(func=ast.Name(id='super'), args=[], keywords=[])
    node.body.append(super_)

    transformer.visit(node)


# Generated at 2022-06-23 23:14:01.873506
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class A: def __init__(self): super()'
    tree = ast.parse(code)
    xf = SuperWithoutArgumentsTransformer(tree)
    assert str(tree) == 'class A:\n    def __init__(self):\n        super(A, self)'

# Generated at 2022-06-23 23:14:04.106680
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Tests the constructor of class SuperWithoutArgumentsTransformer
    """
    # Constructor should set target attribute to (2, 7)
    trans = SuperWithoutArgumentsTransformer()
    assert trans.target == (2, 7)

# Generated at 2022-06-23 23:14:13.624398
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_node_as_string
    from .base import BaseNodeTransformerTester

    # Test case 1
    class Test_1(BaseNodeTransformerTester):
        node = get_node_as_string('''
        class A:
            def meth(self):
                super()
        ''')

        # The expected result.
        expected_node = get_node_as_string('''
        class A:
            def meth(self):
                super(A, self)
        ''')
        # The node to test.
        node_to_test = node

        def create_transformer(self) -> BaseNodeTransformer:
            return SuperWithoutArgumentsTransformer()

        def get_node_to_test(self) -> ast.AST:
            return self.node_to

# Generated at 2022-06-23 23:14:14.666005
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:16.233147
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import compile_source
    from .super_module import SuperModuleTransformer


# Generated at 2022-06-23 23:14:17.952900
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:19.460083
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import tree

# Generated at 2022-06-23 23:14:28.328658
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_node = ast.Call(
        func=ast.Name(id='super'))
    super_node_expected = ast.Call(
        func=ast.Name(id='super'),
        args=[ast.Name(id='cls'), ast.Name(id='self')])

    function_node = ast.FunctionDef(
        name='func',
        args=ast.arguments(
            args=[ast.arg(
                arg='self',
                annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kwarg=None,
            kw_defaults=[],
            defaults=[]),
        body=[ast.Return(value=super_node)],
        decorator_list=[],
        returns=None)

# Generated at 2022-06-23 23:14:34.849284
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_equal_ast
    from ..utils.source import put_in_class

    source = '''
    class A():
        def __init__(self):
            super()
    '''

    expected = '''
    class A():
        def __init__(self):
            super(A, self)
    '''

    tree = ast.parse(put_in_class(source))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-23 23:14:42.450656
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodetree
    from .unpacking_transformer import UnpackingTransformer
    from .base import BaseNodeTransformer
    from ..utils import tree
    import ast as pyast
    from random import randint
    from ..parser import ParserError
    from .. import exceptions

    class TestTransformer(UnpackingTransformer, BaseNodeTransformer):
        def visit_Expr(self, node: pyast.Expr) -> pyast.Expr:
            return node


# Generated at 2022-06-23 23:14:44.371335
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_isolated
    from .. import untransform


# Generated at 2022-06-23 23:14:45.365352
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:54.248361
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.samples import CallSample1, CallSample2
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_label, get_node_names
    from ..utils.visitor import TreeVisitor

    tree = get_ast(locals(), globals())
    x = SuperWithoutArgumentsTransformer()
    x.visit(tree)

    assert len(x.generic_visit.mock_calls) == 0
    assert len(x.visit_Call.mock_calls) == 2

    n = tree.body[0].body[0].body[0]
    assert get_node_label(n) == 'Call'
    assert get_node_names(n.args) == ['cls', 'self']


# Generated at 2022-06-23 23:15:01.173830
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast

    class SuperWithoutArgumentsTransformer_visit_Call(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:
            pass

    tree = get_ast('''
    class C:
        def f(self):
            super()
    ''')
    SuperWithoutArgumentsTransformer_visit_Call().visit(tree)

# Test for method visit of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:07.674475
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Name, Call, FunctionDef, Load, ClassDef

    test_ast = ast.parse('''
    class Test(object):
        def __init__(self):
            super()
    ''', mode='eval')

    expected = ast.parse('''
    class Test(object):
        def __init__(self):
            super(Test, self)
    ''', mode='eval')

    SuperWithoutArgumentsTransformer().visit(test_ast)

    assert compare_ast(test_ast, expected) == True

# Generated at 2022-06-23 23:15:12.476932
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.python import python_node_from_str, python_str_from_node

    tree = python_node_from_str('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert python_str_from_node(tree) == "super(Cls, self)"

# Generated at 2022-06-23 23:15:18.972864
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """class Foo:
    def __init__(self):
        super().__init__()"""
    expected_code = """class Foo:
    def __init__(self):
        super(Foo, self).__init__()"""
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:15:25.626648
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_basic(self):
            code = """
            class A:
                def test(self):
                    super()
            """
            tree = ast.parse(code)

            SuperWithoutArgumentsTransformer().visit(tree)

            self.assertEqual(
                compile(tree, filename="<ast>", mode="exec").co_code,
                b'|\x01\x00\x00d\x00\x00S'
            )

    unittest.main()

# Generated at 2022-06-23 23:15:28.151773
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    super()
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert astor.to_source(tree) == '''
    super(Cls, self)
    '''

# Generated at 2022-06-23 23:15:35.747741
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    class Dummy(ast.NodeTransformer):
        def visit_Raise(self, node: ast.Raise) -> ast.Raise:
            if isinstance(node.exc, ast.Call):
                if getattr(node.exc.func, 'id', None) == 'super':
                    node.exc.args = [ast.Name(id='Cls'), ast.Name(id='cls')]
                    return node
            return node

    tree = ast.parse('class Cls(object): def __init__(self): super()')
    tree = SuperWithoutArgumentsTransformer(tree)
    tree = Dummy(tree)
    assert compile(tree, '', 'exec')

# Generated at 2022-06-23 23:15:42.312862
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():  # noqa: WPS450
    """Unit test for method visit_Call."""
    # Setup
    node_tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(node_tree)
    node = node_tree.body[0]

    # Run
    result = transformer.visit_Call(node)

    # Assert
    assert result.func.id == 'super'
    assert result.args[0].id == 'Cls'
    assert result.args[1].id == 'self'

# Generated at 2022-06-23 23:15:49.184786
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing SuperWithoutArgumentsTransformer' constructor
    """
    # test 1
    node_test_one = ast.parse('super()')
    SuperWithoutArgumentsTransformer(node_test_one)
    # test 2
    node_test_two = ast.parse('super(Cls, self)')
    SuperWithoutArgumentsTransformer(node_test_two)
    # test 3
    node_test_three = ast.parse('super(Cls, cls)')
    SuperWithoutArgumentsTransformer(node_test_three)

# Generated at 2022-06-23 23:15:52.659985
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # 'test1'
    tree = ast.parse('super()')
    tree.body[0].value.args.append(ast.Name(id='test'))
    SuperWithoutArgumentsTransformer(tree, 'name').visit(tree)
    assert dump_ast(tree) == "Call(Name(id='super'), [Name(id='name'), Name(id='self')], [], None, None)"

    # 'test2'

# Generated at 2022-06-23 23:15:56.276848
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
            
    class B(A):
        def __init__(self):
            super()
            
    '''
    tree = ast.parse(code)
    transpiler = SuperWithoutArgumentsTransformer()
    new_tree = transpiler.visit(tree)


# Generated at 2022-06-23 23:15:56.786789
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:16:06.706241
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # class A(object):
    #     def foo(self):
    #         super()
    code = "class A(object):\n    def foo(self):\n        super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert tree.body[0].body[0].body[0].value.func.id == 'super'
    assert isinstance(tree.body[0].body[0].body[0].value.args[0], ast.Name)
    assert tree.body[0].body[0].body[0].value.args[0].id == 'A'

# Generated at 2022-06-23 23:16:14.397619
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code, get_ast
    from ..utils.helpers import assert_equal_code

    source = source_to_code('''
        class Foo:
            def __init__(self):
                super()
    ''')

    expected_result = source_to_code('''
        class Foo:
            def __init__(self):
                super(Foo, self)
    ''')

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(get_ast(source))
    assert_equal_code(transformer._tree_code, expected_result)

# Generated at 2022-06-23 23:16:21.890613
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Testing 'super()'
    input_code = """
        class Foo:
            def __init__(self):
                super()
    """
    compare(input_code, SuperWithoutArgumentsTransformer)

    # Testing 'super()' but not in function
    input_code = """
        def func():
            super()
    """
    compare(input_code, SuperWithoutArgumentsTransformer)

    # Testing 'super()' but not in class
    input_code = """
        class Foo:
            def __init__():
                pass
        super()
    """
    compare(input_code, SuperWithoutArgumentsTransformer)

    # Testing 'super(cls)'
    input_code = """
        class Foo:
            def __init__(self):
                super(Foo)
    """

# Generated at 2022-06-23 23:16:22.735530
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:30.208345
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from _ast import Call
    from ..utils.fake import Function, Name

    class Cls(ast.AST):
        name: str
        _fields: tuple = ('name')

    func = Function(args=[Name(id='self')], body=[])
    cls = Cls(name='Cls')

    class Tree:
        def __init__(self, func, cls):
            self.func = func
            self.cls = cls

    t = Tree(func, cls)

    node = Call(func=Name(id='super'), args=[], keywords=[])
    node.func = func
    func.body.append(node)
    cls.body.append(func)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(cls)


# Generated at 2022-06-23 23:16:33.064888
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse('super().__init__()')
    SuperWithoutArgumentsTransformer().visit(module)
    assert str(module) == 'super(Cls, self).__init__()'

# Generated at 2022-06-23 23:16:38.115921
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    """
    This unit test checks whether the visit_Call method of the
    SuperWithoutArgumentsTransformer class correctly replaces the argument of
    the super() call with the arguments expected by Python 3.

    The "original" code:
        class A:
            def foo():
                self.bar = super()

    The desired code:
        class A:
            def foo():
                self.bar = super(A, self)

    """

    # First, we create the origin trees that we will compare with the results
    # later.

# Generated at 2022-06-23 23:16:48.797854
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    import textwrap
    import unittest
    from typed_ast import ast3 as typed_pyast
    from conversion.test.test_transformer import MockTransformer
    from conversion.test.test_transformer_base import TestTransformerBase

    class MockModule(pyast.AST):
        _fields = ("body",)

        def __init__(self, body: list):
            self.body = body

    class TestTransformer(unittest.TestCase):
        def test_super(self) -> None:
            transformer = MockTransformer(SuperWithoutArgumentsTransformer)
            tree = pyast.parse(textwrap.dedent("""\
                class Foo:
                    def __init__(self):
                        super()
            """))
            node = tree.body[0]
            transformer.vis

# Generated at 2022-06-23 23:16:50.216590
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    c = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:16:53.507528
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_transformed_ast
    program = """
    class A:
        def __init__(self):
            super().__init__()
    """
    module = ast.parse(program)
    result = get_transformed_ast(module, SuperWithoutArgumentsTransformer)
    assert isinstance(result[0].body[0].body[0].value.args[0], ast.Name)
    assert result[0].body[0].body[0].value.args[1].id == 'self'

# Generated at 2022-06-23 23:16:54.375615
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:55.888840
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:16:58.726812
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code import SourceCode
    from ..utils.tree import module_to_str
    from ..utils.helpers import c2to3


# Generated at 2022-06-23 23:16:59.678870
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:06.862568
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .. import util
    code = '''
    class MyClass():
        def __init__(self):
            super()
            super()
    cls = MyClass()
    '''
    tree = util.parse_code_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree, {})
    transformer.visit(tree)
    names = util.get_code_names(tree)
    assert 'super' not in names



# Generated at 2022-06-23 23:17:10.046507
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('c = super()')
    print(ast.dump(tree))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:17:17.269717
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer."""
    node = ast.parse('super(Test, self)')
    transformer = SuperWithoutArgumentsTransformer(ast.parse('super()'))
    new_node = transformer.visit(node)
    assert new_node == ast.parse('super(Test, self)')

    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(ast.parse('super()'))
    new_node = transformer.visit(node)
    assert new_node == ast.parse('super(Cls, self)')

# Generated at 2022-06-23 23:17:24.612373
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast

    module = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(module)
    new_ast = transformer.visit(module)

    assert isinstance(new_ast, ast.Module)
    assert len(new_ast.body) == 1
    assert isinstance(new_ast.body[0], ast.Expr)

    expr = new_ast.body[0]
    assert isinstance(expr.value, ast.Call)
    assert isinstance(expr.value.func, ast.Name)
    assert expr.value.func.id == "super"
    assert len(expr.value.args) == 2

    assert isinstance(expr.value.args[0], ast.Name)
    assert expr.value.args[0].id == "Cls"

   

# Generated at 2022-06-23 23:17:33.088777
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    code = '''
        class Cls:
            def __init__(self):
                super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

    code = '''
        class Cls:
            def __init__(self, arg):
                super(arg)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

# Generated at 2022-06-23 23:17:37.344383
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # given
    from typed_ast import ast3 as ast
    from .test_utils import NodeTransformerTestCase

    class TestSuperWithoutArgumentsTransformer(NodeTransformerTestCase):
        transformer = SuperWithoutArgumentsTransformer

        def test_simple(self):
            code = "super()"

# Generated at 2022-06-23 23:17:39.870056
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert ast.dump(tree) == "super(Cls, self)"

# Generated at 2022-06-23 23:17:43.960013
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source
    from .. import compile_string
    source = Source("""
        class Foo:
            def bar(self):
                super()
    """)
    tree = compile_string(source.src, 2)
    SuperWithoutArgumentsTransformer(tree, source).visit(tree)
    assert 'super(Foo, self)' in source.src

# Generated at 2022-06-23 23:17:49.987601
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    b = ast.parse('class A():\n    def f(self):\n        super()', mode='exec')
    superWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer(Context(), b)
    superWithoutArgumentsTransformer.visit(b)
    assert str(b) == 'class A():\n    def f(self):\n        super(A, self)'


# Generated at 2022-06-23 23:17:52.646306
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    SuperWithoutArgumentsTransformer().visit(ast.parse("""
    class A(object):
        def __init__(self):
            super()
    """))

# Generated at 2022-06-23 23:18:02.722298
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def compile_tree(body: str) -> ast.Module:
        return ast.parse(dedent(body))
    
    def check_transformation(before: ast.AST, after: ast.AST) -> None:
        transformer = SuperWithoutArgumentsTransformer(before)
        transformer.visit(before)
        assert transformer.tree == after
    
    def get_func(b: str) -> ast.FunctionDef:
        return compile_tree(b).body[0]

    def get_cls(b: str) -> ast.ClassDef:
        return compile_tree(b).body[0]
    
    def get_super_call(b: str) -> ast.Call:
        return compile_tree(b).body[0].body[0].value


# Generated at 2022-06-23 23:18:12.771495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import inspect
    import types
    import os
    import astor

    def get_name_of_var(var):
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        return [var_name for var_name,
                var_val in callers_local_vars if var_val is var]

    tree = ast.parse(open(os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'data', 'test_super_without_arguments.py'), 'r').read())
    SuperWithoutArgumentsTransformer.run(tree)

# Generated at 2022-06-23 23:18:13.462494
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:21.821004
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    code1 = """
        super()
    """

    code2 = """
        def a():
            super()
    """

    code3 = """
        class B:
            def a():
                super()
    """

    exp1 = """
        super(, self)
    """

    exp2 = """
        def a():
            super(, a)
    """

    exp3 = """
        class B:
            def a():
                super(B, a)
    """

    for code, exp in ((code1, exp1), (code2, exp2), (code3, exp3)):
        tree = ast.parse(code)
        transformer = SuperWithoutArgumentsTransformer()
        new_tree = transformer.visit(tree)
        assert ast.dump(new_tree) == exp

# Generated at 2022-06-23 23:18:29.201308
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test visit_Call of SuperWithoutArgumentsTransformer"""
    import astor
    from .. import transforms

    s = """
    class A(object):
        def foo(self):
            return super()
    """
    t = """
    class A(object):
        def foo(self):
            return super(A, self)
    """
    result = transforms.SuperWithoutArgumentsTransformer.run_on_string(s)
    assert astor.to_source(ast.parse(t)) == result

# Generated at 2022-06-23 23:18:34.468275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile

    code = '''
        class A(object):
            def f(self):
                super()
            @staticmethod
            def g():
                super()
        class B(A):
            def f(self):
                super()
            @staticmethod
            def g():
                super()
        class C(B):
            def f(self):
                super()
            @staticmethod
            def g():
                super()
    '''


# Generated at 2022-06-23 23:18:43.430283
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def check(input, expected):
        visitor = SuperWithoutArgumentsTransformer()
        assert isinstance(input, ast.Call)
        visitor.visit(input)
        assert repr(input) == repr(expected)

    # With empty arguments
    node = ast.parse('super()').body[0]
    expected = ast.Expr(ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='A'), ast.Name(id='self')], keywords=[]))
    check(node, expected)

    # With arguments
    node = ast.parse('super(1)').body[0]
    expected = ast.Expr(ast.Call(func=ast.Name(id='super'), args=[ast.Num(n=1)], keywords=[]))
    check(node, expected)

# Generated at 2022-06-23 23:18:53.945741
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()').body[0]
    tree = ast.parse('class Cls(object):\n\tdef func(self):\n\t\treturn super()')
    SuperWithoutArgumentsTransformer(tree).visit(node)

# Generated at 2022-06-23 23:19:01.252754
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code =  '''
        class A:
            def __init__(self):
                # super()
                super(A, self)
                super()
                super(Other, self)
    
    '''

    expected_code = '''
        class A:
            def __init__(self):
                # super()
                super(A, self)
                super(A, self)
                super(Other, self)
    
    '''

    tree = ast.parse(textwrap.dedent(code))
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    actual_code = astor.to_source(tree).strip()

    print(actual_code)

    assert expected_code == actual_code

# Generated at 2022-06-23 23:19:02.120688
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:08.668733
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        def method(self):
            super()
    """
    module, _ = compile_source(code, mode='exec')
    assert module is not None

    new_module = ast.parse('\n'.join(code.split('\n')[1:-1]))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(new_module)

    assert transformer._tree_changed

    module, _ = compile_source(
        code='\n'.join([code.split('\n')[0]] + transformer.result() + [code.split('\n')[-1]]),
        mode='exec'
    )
    assert module is not None



# Generated at 2022-06-23 23:19:18.293900
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Case 1: super() in function outside class
    tree = ast.parse(
        '''
        def foo():
            super()
        '''
    )
    result = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(result, ast.Module)

    # Case 2: super() in inner function
    tree = ast.parse(
        '''
        class A:
            def foo():
                super()
        '''
    )
    result = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(result, ast.Module)

    # Case 3: super() in function in class
    tree = ast.parse(
        '''
        class A:
            def foo():
                super()
        '''
    )

# Generated at 2022-06-23 23:19:24.698315
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse(
        """
        class Cls: 
            def func(self):
                super().method()
        """
    )
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:19:25.437459
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:35.932690
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Foo:
        def __init__(self):
            super()
    """

    node = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(node)
    node = transformer.visit(node)

    transformer.generic_visit(node)
    assert transformer._tree_changed

    body = list(node.body)
    assert isinstance(body[0], ast.ClassDef)

    body = list(body[0].body)
    assert isinstance(body[0], ast.FunctionDef)

    body = list(body[0].body)
    assert isinstance(body[0], ast.Expr)

    body = body[0].value
    assert isinstance(body, ast.Call)

    func = body.func
    assert isinstance(func, ast.Name)
   

# Generated at 2022-06-23 23:19:36.508404
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:41.638218
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Foo:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    compiled_tree = tree.body[0].body[0].body[0]
    assert isinstance(compiled_tree, ast.Expr)
    call = compiled_tree.value
    assert isinstance(call, ast.Call)
    assert isinstance(call.func, ast.Attribute) and call.func.attr == '__init__'
    assert isinstance(call.func.value, ast.Name) and call.func.value.id == 'super'
    assert call.args == [ast.Name(id='Foo'), ast.Name(id='self')]

# Generated at 2022-06-23 23:19:42.654046
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code

# Generated at 2022-06-23 23:19:46.968481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    # before
    before = ast.parse("a = super()")
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(before)
    # after
    after = ast.parse("a = super(cls, self)")
    transformer.visit(after)
    # assert
    assert before == after

# Generated at 2022-06-23 23:19:56.832316
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from ..utils.source import source_to_unicode

    cases = [
        ('super(Cls, self)', 'super(Cls, self)'),
        ('super()', 'super(Cls, self)'),
    ]

    tf = SuperWithoutArgumentsTransformer(None, None)
    tf._tree = pyast.parse(source_to_unicode('''
        class Cls:
            def fn(self):
                super()
    '''))
    for code, result in cases:
        node = pyast.parse(source_to_unicode(code))
        tf.visit(node)
        assert pyast.dump(node) == result

test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-23 23:19:59.069663
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    d = {"__builtins__": __builtins__, "super": super}

# Generated at 2022-06-23 23:20:10.172707
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test(ast.NodeVisitor):
        def __init__(self, func_name: str) -> None:
            self._func_name = func_name

        def visit_Call(self, node: ast.Call) -> None:
            if isinstance(node.func, ast.Name) and node.func.id == 'super':
                assert 'cls' in self._func_name
                assert isinstance(node.args[0], ast.Name) and node.args[0].id == 'Cls'
                assert isinstance(node.args[1], ast.Name) and node.args[1].id == 'cls'

    tree = ast.parse('class Cls:\n    def foo(self): super()\n    @classmethod\n    def bar(cls): super()\n')
    transformer = SuperWithout

# Generated at 2022-06-23 23:20:15.206395
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = """class A:
    def __init__(self):
        super()
    """
    expected_code = """class A:
    def __init__(self):
        super(A, self)
    """
    utils.assert_conversion(SuperWithoutArgumentsTransformer, input_code, expected_code)