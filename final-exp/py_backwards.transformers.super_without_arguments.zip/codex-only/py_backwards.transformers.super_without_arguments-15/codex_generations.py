

# Generated at 2022-06-23 23:10:20.692107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import ast_transformer   # type: ignore
    from ..utils import get_asts

    print("\nin test_SuperWithoutArgumentsTransformer")
    transpiler = ast_transformer.AstTranspiler([SuperWithoutArgumentsTransformer])

    file_name = "data.py"
    asts = get_asts(file_name)
    print("Original AST:")
    print(ast.dump(asts[0]))
    new_ast = transpiler.transpile_asts(file_name, asts)
    print("New AST:")
    print(ast.dump(new_ast[0]))

    # write the new AST to data2.py
    new_file = open("data2.py", "w")

# Generated at 2022-06-23 23:10:30.999671
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    '''It tests the method visit_Call of the class SuperWithoutArgumentsTransformer.'''
    from astor import parse
    from .base import BaseNodeTransformer
    from .utils import NodeTransformerTestCase
    from ..utils.helpers import get_parent_of_type
    from ..exceptions import NodeNotFound
    from ..exceptions import NodeUnsupportedError

    class ClazzTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            self._tree_changes = True
            return

    class Test(NodeTransformerTestCase):
        def test_it(self):
            root_node = parse("super()")
            c = ClazzTransformer(root_node)
            c.visit(root_node)

            self.assertEqual(len(c._changes['Call']), 1)

    test

# Generated at 2022-06-23 23:10:37.501208
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)
    node = ast.parse('super()', mode='eval')
    node = transformer.visit(node)

    assert ast.dump(node, annotate_fields=False) == "[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))]"

# Generated at 2022-06-23 23:10:45.184845
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_node_from_func
    code = """
        class X:
            def __init__(self):
                super().__init__()
    """
    node = get_node_from_func(code, lambda x: x.body[0].body[0].value.func)
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.check_and_transform(node)
    assert isinstance(node.value.args[0], ast.Name)
    assert node.value.args[0].id == 'X'
    assert isinstance(node.value.args[1], ast.Name)
    assert node.value.args[1].id == 'self'

# Generated at 2022-06-23 23:10:56.036925
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astroid
    from python_ta.transforms.type_inference_visitor import TypeInferer
    from python_ta.transforms.unpacked_tuples_visitor import TupleUnpackingAsignment

    code = '''
    class A:
        def __init__(self):
            super()
    '''
    ast_module, _ = astroid.extract_node(code)
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    inferer = TypeInferer()
    inferer.visit(tree)
    tu_transformer = TupleUnpackingAsignment()
    tu_transformer.visit(tree)
    result = compile(tree, filename='<ast>', mode='exec')

    ns = {}
    exec(result, ns)

# Generated at 2022-06-23 23:11:01.836628
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    This function tests the SuperWithoutArgumentsTransformer function by passing in a
    python file and converting the legacy super() to compatible super().
    """
    code = """
    class Super_Without_Args:
        def __init__(self, foo):
            super()
            
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))



# Generated at 2022-06-23 23:11:08.649685
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseNodeTransformerTester
    from .. import settings
    from typed_ast import ast3 as ast
    from .super import SuperWithoutArgumentsTransformer

    settings.warnings_by_type['super_outside_class'] = 'ignore'
    settings.warnings_by_type['super_outside_function'] = 'ignore'

    class SuperWithoutArgumentsTransformerTester(BaseNodeTransformerTester):
        @property
        def node_transformer_class(self) -> Type[BaseNodeTransformer]:
            return SuperWithoutArgumentsTransformer

        def test_renames_super(self):
            node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None,
                            kwargs=None)
            expected = ast.Call

# Generated at 2022-06-23 23:11:09.851042
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_convertion import SourceConvertor


# Generated at 2022-06-23 23:11:12.391348
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:16.565605
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    from ..utils.testing import generate_test_snippet
    import astor

    class Test(BaseNodeTransformerTest):
        target_version = (2, 7)
        node_transformer = SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:24.584922
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    """
        class DummyClass(object):
            def dummy_method(self):
                super()
                super()
    """
    dummy_code = ast.parse("""class DummyClass(object):
    def dummy_method(self):
        super()
        super()""")
    expected_code = ast.parse("""class DummyClass(object):
    def dummy_method(self):
        super(DummyClass, self)
        super(DummyClass, self)""")
    dummy_code = SuperWithoutArgumentsTransformer().visit(dummy_code)
    assert get_ast(dummy_code) == get_ast(expected_code)

# Generated at 2022-06-23 23:11:35.927408
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class Test:
    def test(self):
        super()
    '''
    ast_tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(ast_tree)
    new_ast = transformer.visit(ast_tree)
    # the test transformer shouldn't change anything
    assert astor.to_source(ast_tree) == astor.to_source(new_ast)

    code = '''class Test:
    def test(self):
        super()
        super()
    '''
    ast_tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(ast_tree)
    new_ast = transformer.visit(ast_tree)
    # the test transformer shouldn't change anything

# Generated at 2022-06-23 23:11:40.631995
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def f(self):
                super().f()
    """
    expected_code = """
        class A:
            def f(self):
                super(A, self).f()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-23 23:11:43.069869
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .util import expect_content

    code = """
        class Parent(object):
            pass

        class Child(Parent):
            def __init__(self):
                super()
    """

    expect_content(code, code.replace('super()', 'super(Parent, self)'))

# Generated at 2022-06-23 23:11:46.489623
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from .helpers import get_ast_diff, get_node_line
    from ..utils.helpers import clear_source_code_warnings

    # Prepare

# Generated at 2022-06-23 23:11:52.750140
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.node_utils import parse_node

    node = parse_node("""
    class A:
        def b():
            super()
    """)
    t = SuperWithoutArgumentsTransformer()
    t.visit(node)
    assert(str(node) == '''
    class A(object):
        def b(self):
            super(A, self)
    ''')


# Generated at 2022-06-23 23:11:58.352414
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast as ast_util

    code = (
        'class Foo:\n'
        '    def __init__(self):\n'
        '        super()\n'
    )
    expected = (
        'class Foo:\n'
        '    def __init__(self):\n'
        '        super(Foo, self)\n'
    )

    tree = ast_util.parse_module(code)
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.run()
    assert_equal(
        ast_util.compile_from_ast(tree),
        expected
    )

# Generated at 2022-06-23 23:11:59.378133
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:09.556325
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestVisitor(ast.NodeVisitor):
        def __init__(self, call_name: str):
            self.found = False
            self.call_name = call_name

        def visit_Call(self, node: ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == self.call_name and not len(node.args):
                self.found = True

    code = '''
            class Test:
                def method(self):
                    super()
                def method2(self):
                    super.get_super()
            '''
    tree = ast.parse(code, 'test.py')
    v = TestVisitor('super')
    v.visit(tree)
    assert v.found == True
    v.found = False
    v.call_name

# Generated at 2022-06-23 23:12:19.351510
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    node = ast3.parse("""
    class Foo:
        def __init__(self):
            print(super())
        def foo(self) -> int:
            print(super())

    class Bar:
        def __init__(self):
            print()
        def foo(self) -> int:
            print()

    foo = Foo()
    bar = Bar()
    """)
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-23 23:12:29.669444
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import make_call, make_function_def, make_class_def, ast_to_str

    class_def = make_class_def(
        bases=[],
        name='Cls',
        body=[
            make_function_def(
                name='__init__',
                body=[
                    make_call(
                        func=make_call(
                            func=make_call(func=make_call())
                        )
                    )
                ]
            )
        ]
    )
    assert ast_to_str(class_def) == 'class Cls:\n    def __init__(self):\n        super().super().super().super()'
    SuperWithoutArgumentsTransformer(class_def).run()

# Generated at 2022-06-23 23:12:39.415450
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.fake_tree import FakeTree
    from ..managers.manager import Manager
    from .manager_fake import FakeManager
    from .super_without_arguments import SuperWithoutArgumentsTransformer
    from ..modules.main import MainTransformer
    from ..modules.print_function import PrintFunctionTransformer

    manager = Manager(
        transforms=[MainTransformer, PrintFunctionTransformer, SuperWithoutArgumentsTransformer],
        tree=FakeTree
    )


# Generated at 2022-06-23 23:12:40.547042
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:45.670668
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast, compare_ast

    code = "super()"
    expected_code = "super(Cls, self)"
    tree = get_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree, {'Cls': 'Cls'})
    transformer.visit(tree)
    assert compare_ast(tree, expected_code)

# Generated at 2022-06-23 23:12:53.399374
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.node_utils import compile_func, extract_node

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse('super()'))

    # super() -> super(Cls, self)
    node = extract_node('super()', ast.Call)
    t.visit(node)
    assert compile_func(node) == 'super(Cls, self)'

    # super().__init__() -> super(Cls, self).__init__()
    node = extract_node('super().__init__()', ast.Call)
    t.visit(node)
    assert compile_func(node) == 'super(Cls, self).__init__()'

    # super(Cls, self).__init__() -> super(Cls, self).__init__()

# Generated at 2022-06-23 23:13:04.665738
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import Any, List, Union
    class Classtest_SuperWithoutArgumentsTransformer_visit_CallFoo(SuperWithoutArgumentsTransformer):
        def __init__(self):
            super().__init__()
            self.tree_changed: bool = False

        def visit_Call(self, node: ast.Call) -> Union[ast.AST, Any]:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                try:
                    func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
                except NodeNotFound:
                    warn('super() outside of function')
                    return


# Generated at 2022-06-23 23:13:16.014681
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class InheritedNodeTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self.transformation_executed = False


# Generated at 2022-06-23 23:13:25.974907
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_ast
    from .unwrap_literals import UnwrapLiteralsTransformer
    from .unwrap_callables import UnwrapCallablesTransformer

    source = """
    class Cls:
        def method(self):
            super()
    """
    source = source_to_unicode(source)
    tree = compile(source, '<test>', 'exec', ast.PyCF_ONLY_AST)
    tree = UnwrapCallablesTransformer().visit(tree)
    tree = UnwrapLiteralsTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    print_ast(tree)

# Generated at 2022-06-23 23:13:34.333827
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # get AST for python
    import sys
    import os
    import astor
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../tests/python_files/super_without_args.py")
    with open (path) as f:
        tree = ast.parse(f.read())

    SuperWithoutArgumentsTransformer(tree).visit(tree)
    diff = astor.to_source(tree)

    # get AST for python3
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../tests/python_files/super_without_args_py3.py")
    with open (path) as f:
        tree3 = ast.parse(f.read())

    #

# Generated at 2022-06-23 23:13:43.076807
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from ..utils.fake import FakeTreeBuilder
    from ..utils.helpers import compile_source
    from ..utils.tempdir import TemporaryDirectory
    builder = FakeTreeBuilder()
    builder.add_file('super.py', textwrap.dedent('''\
    class Cls(object):
        def __init__(self):
            super()   
        @classmethod
        def cls_method(cls):
            super()
        @staticmethod
        def static_method():
            super()
        @property 
        def property(self):
            super() 
    '''))
    with TemporaryDirectory() as dirpath:
        builder.write(dirpath)
        source = compile_source('super.py', dirpath)
        transformer = SuperWithoutArgumentsTransformer(source)
        transformer.vis

# Generated at 2022-06-23 23:13:45.635185
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .utils import roundtrip_unparse

    source = "class A:super()"
    tree = ast.parse(source)
    tree2 = roundtrip_unparse(tree)
    assert tree2 == "class A:\n super(A, self)\n"

# Generated at 2022-06-23 23:13:46.103751
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:47.354909
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from . import tree_to_str
    from ..utils.helpers import reset_warnings

    reset_warnings()


# Generated at 2022-06-23 23:13:56.713079
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    super() case
    """
    from typed_ast import ast3 as ast

    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()', mode='exec')
    transformer.visit(tree)

    assert transformer._tree_changed
    expected = ast.Module(body=[ast.Expr(value=ast.Call(
        func=ast.Name(id="super"),
        args=[
            ast.Name(id="Test", ctx=ast.Load()),
            ast.Name(id="self", ctx=ast.Load())
        ],
        keywords=[],
    ))])

    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 23:14:02.960793
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    from ..basic import BasicTransformer
    code = '''
    class A:
        def __init__(self):
            super().meth(1)
    '''
    expected = '''
    class A:
        def __init__(self):
            super(A, self).meth(1)
    '''
    tree = ast.parse(code)
    BasicTransformer.apply(tree)
    # When
    SuperWithoutArgumentsTransformer.apply(tree)
    # Then
    actual = compile(tree, '', 'exec')
    assert expected == actual

# Generated at 2022-06-23 23:14:08.663138
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    n = '''super()'''

    result = SuperWithoutArgumentsTransformer().visit(compile(n, '', 'exec'))
    if result is None:
        raise AssertionError('result is None')

    expected = '''super(Cls, self)'''

    assert result.body[0].body[0].value.args[0].id == \
        compile(expected, '', 'exec').body[0].body[0].value.args[0].id
    assert result.body[0].body[0].value.args[1].id == \
        compile(expected, '', 'exec').body[0].body[0].value.args[1].id



# Generated at 2022-06-23 23:14:18.948756
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_
    from ..utils import code_to_ast


# Generated at 2022-06-23 23:14:21.493665
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.scope import scoped
    import astor
    from ..utils.ast_helper import ast_load


# Generated at 2022-06-23 23:14:24.257260
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast, replace_ast_node, get_ast_node, source_to_ast


# Generated at 2022-06-23 23:14:29.625715
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from ..utils.matchers import exact_src
    from .local_upgrades import LocalVarUpgrader
    from .base import Transformer
    from .base import BaseNodeTransformer
    from .base import get_transformed_ast

    transformer = SuperWithoutArgumentsTransformer()
    tree = parse('super()')
    tree = transformer.visit(tree)
    src = get_transformed_ast(tree)
    assert src == 'super(Cls, cls)'
    return



# Generated at 2022-06-23 23:14:36.647693
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_jig import expect_conversion, expect_unchanged

    expect_conversion(
        """
        class foo:
            def __init__(self):
                super()
        """,
        """
        class foo:
            def __init__(self):
                super(foo, self)
        """
    )
    expect_unchanged(
        """
        class foo:
            def __init__(self):
                super(foo, self)
        """
    )
    expect_unchanged(
        'super()'
    )

# Generated at 2022-06-23 23:14:38.333295
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as stdlib_ast
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 23:14:40.914932
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import memory_size
    from .. import rewrite_ast


# Generated at 2022-06-23 23:14:42.584760
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""


# Generated at 2022-06-23 23:14:44.880733
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from .. import helpers
    from .. import print_tree
    from .. import parse


# Generated at 2022-06-23 23:14:53.889051
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test case 1: super() outside class
    tree = ast.parse('''
        def foo() -> None:
            super()
    ''')
    transformer = SuperWithoutArgumentsTransformer(tree.body[0].body[0], tree)
    transformer.visit(tree.body[0].body[0])
    assert not tree.body[0].body[0].args

    # test case 2: super() outside function
    tree = ast.parse('''
        class Foo:
            super()
    ''')
    transformer = SuperWithoutArgumentsTransformer(tree.body[0].body[0], tree)
    transformer.visit(tree.body[0].body[0])
    assert not tree.body[0].body[0].args

    # test case 3: super() inside func and class

# Generated at 2022-06-23 23:15:00.771251
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from nuitka.tree.Builder import PythonTree
    import ast
    node = PythonTree(
        ast.Call(
            func=ast.Name(id='super', ctx=ast.Load()),
            args=[],
            keywords=[],
            starargs=None,
            kwargs=None
        )
    )
    transformer = SuperWithoutArgumentsTransformer(2,7)
    transformer.visit_Call(node)
    assert node.as_string().startswith('super(')

# Generated at 2022-06-23 23:15:09.133409
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from typed_ast import ast3 as ast

    for code in [
        textwrap.dedent('''
            class A:
                def f(self):
                    super()
        '''),
        textwrap.dedent('''
            def f(self):
                super()
        '''),
        textwrap.dedent('''
            def F():
                super()
        '''),
    ]:
        global_node = ast.parse(code)
        node = global_node.body[0]
        # noinspection PyTypeChecker
        transformer = SuperWithoutArgumentsTransformer(global_node)
        node = transformer.visit(node)  # type: ignore
        assert transformer._tree_changed == True
        assert code != ast.unparse(node)

# Generated at 2022-06-23 23:15:19.558895
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from . import UnsupportedBuiltin

    def run_test(code: str, expected: str):
        module = ast.parse(code)
        transformer = SuperWithoutArgumentsTransformer(module)
        transformer.visit(module)
        assert transformer._tree_changed == True
        assert ast.dump(module) == expected

    # Simple test case
    code = """
    class A:
        def __init__(self):
            super()
    """
    expected = """
    class A:
        def __init__(self):
            super(A, self)
    """
    run_test(code, expected)

    # Test case with another scope

# Generated at 2022-06-23 23:15:26.392496
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    tree = ast.parse("""
    class Foo:
        def bar(self):
            super()
    """)
    SuperWithoutArgumentsTransformer.run_on_tree(tree)
    tree = ast.parse("""
    class Foo:
        def bar(self):
            pass
    """)
    SuperWithoutArgumentsTransformer.run_on_tree(tree)
    expected_code = """
    class Foo:
        def bar(self):
            super(Foo, self)
    """
    assert astor.to_source(tree).strip() == expected_code.strip()

# Generated at 2022-06-23 23:15:32.648880
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)

    super(SuperWithoutArgumentsTransformer, SuperWithoutArgumentsTransformer).visit_Call(
        SuperWithoutArgumentsTransformer(), node)

    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:15:36.747922
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
    class B(A):
        def foo(self):
            super()
    '''
    expected_code = '''
    class A:
        def __init__(self):
            super(A, self)
    class B(A):
        def foo(self):
            super(B, self)
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-23 23:15:38.230055
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_node


# Generated at 2022-06-23 23:15:43.357558
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree_before = 'super()'
    tree_after = 'super(cls, cls)'

    test_node = ast.parse(tree_before)
    transformer = SuperWithoutArgumentsTransformer(tree_before, tree_after)
    transformer.visit(test_node)

    assert transformer._tree_changed
    assert ast.dump(test_node) == tree_after


# Generated at 2022-06-23 23:15:50.596463
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    import typing
    
    code = '''
    class A:
        def f(self):
            super()
    '''
    tree = parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert typing.cast(typed_ast.ast3.Module, tree).body[0].body[0].body[0].args[0].id == 'A'

# Generated at 2022-06-23 23:15:55.888799
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.ast_builder import build_ast
    from .. import fixer_logic
    from ..version import version_info, version
    from ..defaults import FUNCTION_SIG
    code = '''
        class Dummy():
            def __init__(self):
                super()
    '''
    ast_tree = build_ast(code=code)
    fixer_logic.FixerLogic.logic(
        major_version=version_info[0],
        minor_version=version_info[1],
        tree=ast_tree,
        function_sig=FUNCTION_SIG
    )

    assert code != astor.to_source(ast_tree)
    assert 'super(Dummy, self)' in astor.to_source(ast_tree)

# Generated at 2022-06-23 23:15:56.709899
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:06.569165
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from typed_ast import ast3
    from astor.code_gen import to_source
    from ..common import run_transformer_test
    from ..utils.helpers import compare_source_code

    transformer = SuperWithoutArgumentsTransformer()
    result = run_transformer_test(transformer)

    assert isinstance(result, ast3.ClassDef)
    assert isinstance(result.body[0], ast3.FunctionDef)
    assert isinstance(result.body[1], ast3.FunctionDef)
    assert isinstance(result.body[2], ast3.FunctionDef)
    assert isinstance(result.body[3], ast3.FunctionDef)


# Generated at 2022-06-23 23:16:16.118828
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from nuitka.nodes.AssignNodes import (
        StatementAssignmentVariable,
    )
    from nuitka.nodes.BuiltinRefNodes import ExpressionBuiltinSuper
    from nuitka.nodes.FunctionNodes import (
        ExpressionFunctionBody,
        ExpressionFunctionCall,
        ExpressionFunctionCreation,
    )
    from nuitka.nodes.MethodNodes import ExpressionFunctionRef
    from nuitka.nodes.OperatorNodes import ExpressionOperationBinary
    from nuitka.nodes.ParameterSpecs import ParameterSpec
    from nuitka.nodes.StatementNodes import StatementsSequence
    from nuitka.nodes.VariableRefNodes import ExpressionTargetVariableRef


# Generated at 2022-06-23 23:16:19.834596
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = dedent("""\
        super()
        """)

    tree = ast.parse(code)

    transform = SuperWithoutArgumentsTransformer(tree).visit(tree)

    code_after = dedent("""\
        super(__RegenerateMagicClass, self)
        """)

    assert astor.to_source(tree) == code_after

# Generated at 2022-06-23 23:16:25.580013
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import (
        ast3 as ast,
    )

    tree = ast.parse('super()')
    parent_class = ast.ClassDef(name='Cls', body=[])
    function = ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)]), body=[tree])
    parent_class.body.append(function)
    tree = ast.Module(body=[parent_class])
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(tree)

# Generated at 2022-06-23 23:16:26.104282
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:27.775929
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:34.904321
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A(object):
        def __init__(self, name=None):
            super(A, self).__init__()

        def __new__(cls, name=None):
            return super(A, cls).__new__(A)
    """
    tree = ast.parse(code)
    result = SuperWithoutArgumentsTransformer().visit(tree)
    assert(
        compile(result, '<string>', 'exec').co_code ==
        compile(code, '<string>', 'exec').co_code
    )

# Generated at 2022-06-23 23:16:42.418810
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    class_node = ast.ClassDef(
        name='Test',
        body=[
            ast.FunctionDef(
                name='test',
                args=ast.arguments(
                    args=[
                        ast.Name(id='self')
                    ]
                ),
                body=[
                    ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None))
                ]
            )
        ]
    )

    t.visit(class_node)
    node = class_node.body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len

# Generated at 2022-06-23 23:16:48.167810
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from _ast import Not, parse, dump, Call

    from typed_ast import ast3

    from typed_ast import conversion
    from typed_ast import util

    source = '''
    class MyClass(object):
        def __init__(self):
            super().__init__()

    class Child(MyClass):
        def __init__(self):
            super().__init__()
    '''

    expected = '''
    class MyClass(object):
        def __init__(self):
            super(MyClass, self).__init__()

    class Child(MyClass):
        def __init__(self):
            super(Child, self).__init__()
    '''

    module = conversion.ast_to_object(util.parse(source))
    assert not isinstance(module, util.Module)
   

# Generated at 2022-06-23 23:16:52.396980
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast

    tree = compile_to_ast("""
        class SuperCls(object):
            def foo(self):
                super()
    """)

    SuperWithoutArgumentsTransformer().visit(tree)

    tree_text = ''.join(ast.unparse(tree))

    assert 'class SuperCls(object):\n    def foo(self):\n        super(SuperCls, self)' in tree_text

# Generated at 2022-06-23 23:16:54.502244
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer().load_ast(ast.parse("super()")) == \
           SuperWithoutArgumentsTransformer().load_ast(ast.parse("super(Cls, self)"))

# Generated at 2022-06-23 23:16:55.602414
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:05.133905
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code='''
        def func(self):
            super()

        class Cls:
            def func(self):
                super()

            @classmethod
            def func2(cls):
                super()
    '''
    expected_code ='''
        def func(self):
            super(Cls, self)

        class Cls:
            def func(self):
                super(Cls, self)

            @classmethod
            def func2(cls):
                super(Cls, cls)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))


# Generated at 2022-06-23 23:17:15.436849
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from python_transpiler.test_utils import init_test_config, assert_transpiled, assert_source_code
    init_test_config()
    
    assert_transpiled(
        "super()",
        "super(Cls, self)",
        prepare_visitor=lambda f, t, o, e: SuperWithoutArgumentsTransformer(e)
    )
    assert_transpiled(
        "super(__class__, self)",
        "super(__class__, self)",
        prepare_visitor=lambda f, t, o, e: SuperWithoutArgumentsTransformer(e)
    )


# Generated at 2022-06-23 23:17:21.594598
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typing as t

    source = '''super()'''
    expected = '''super(Cls, self)'''

    tree = ast.parse(source)  # type: ignore
    cls = ast.ClassDef(name='Cls', body=[ast.FunctionDef(name='__init__', body=[ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))])])
    tree.body.append(cls)

    tree = SuperWithoutArgumentsTransformer().visit(tree)  # type: ignore
    assert ast.dump(tree) == ast.dump(ast.parse(expected))  # type: ignore

# Generated at 2022-06-23 23:17:31.603861
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestSuperWithoutArgumentsTransformer_visit_Call(unittest.TestCase):
        def _test(self, input: str, expected: str) -> None:
            self._t(input, expected)

        def _t(self, input: str, expected: str) -> None:
            input_tree: ast.Module = ast.parse(input)

            transformer = SuperWithoutArgumentsTransformer(input_tree)
            result = transformer.visit(input_tree)

            diff = Sequencer(relativize_to=__file__).get_diff(
                expected_tree=ast.parse(expected),
                actual_tree=result,
            )
            self.assertEqual(
                diff,
                '',
                msg=diff,
            )

        def test_001(self) -> None:
            self

# Generated at 2022-06-23 23:17:32.676816
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:38.889466
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    py3_code = """
        def __init__(self):
            super().__init__(a, b)
    """
    py2_code = """
        def __init__(self):
            super(Cls, self).__init__(a, b)
    """
    tree = ast.parse(py3_code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected_tree = ast.parse(py2_code)
    assert expected_tree == tree

# Generated at 2022-06-23 23:17:46.705043
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..tests.test_utils import compile_to_ast
    import sys
    import textwrap

    code1 = '''
    class A:
        def a(self):
            super()

    class B(A):
        def a(self):
            super()        
    '''
    code2 = '''
    class A:
        def a(self, arg):
            super()

    class B(A):
        def a(self, arg):
            super()        
    '''
    code3 = '''
    class A:
        def a(self):
            super(A, self)

    class B(A):
        def a(self):
            super(B, self)        
    '''

# Generated at 2022-06-23 23:17:47.834690
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:49.512339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_code_equal


# Generated at 2022-06-23 23:17:52.029604
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transpiler import Transpiler


# Generated at 2022-06-23 23:18:02.128902
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import parse, roundtrip
    from textwrap import dedent

    with pytest.raises(NodeNotFound):
        node = parse('super()').body[0]
        assert not isinstance(node.value, ast.Call)
        SuperWithoutArgumentsTransformer().visit(node)

    with pytest.raises(NodeNotFound):
        node = parse('super()').body[0].body[0]
        assert not isinstance(node.value, ast.Call)
        SuperWithoutArgumentsTransformer().visit(node)

    source = dedent("""
        class A:
            def a(self):
                super()
    """)
    tree = parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:18:12.251086
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import build_tree


# Generated at 2022-06-23 23:18:19.882104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    
    # Compiles: super()
    # To: super(Cls, self)
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    func = ast.FunctionDef(name='method', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)]), body=[
        node
    ], decorator_list=[])
    cls = ast.ClassDef(name='Cls', bases=[], keywords=[], body=[
        func
    ])
    module = ast.Module(body=[
        cls
    ])
    transformer.visit(module)

# Generated at 2022-06-23 23:18:30.759341
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestClass(object):
        def __init__(self):
            a, b = 1, 2
            super()

        class TestClass2(object):
            pass

    code = inspect.getsource(TestClass)

    # Testing initialization of SuperWithoutArgumentsTransformer with class TestClass
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    exec(compile(tree, filename="<ast>", mode='exec'))

    class TestClass(object):
        def __init__(self):
            a, b = 1, 2
            super(TestClass, self)

        class TestClass2(object):
            pass

    code = inspect.getsource(TestClass)
    expected_output = ast.parse(code)


# Generated at 2022-06-23 23:18:33.752482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tr = SuperWithoutArgumentsTransformer()
    tree = ast.parse(code)
    tr.visit(tree)
    assert tr.compiled_node.body[0].value.args[1].id == 'self'

# Generated at 2022-06-23 23:18:40.859379
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..ast_transformer import compile_to_ast, transform_ast
    from .first_arg_of_classmethod_decorator import FirstArgOfClassmethodDecoratorTransformer
    from .first_arg_of_staticmethod_decorator import FirstArgOfStaticmethodDecoratorTransformer
    from .empty_bases_of_class import EmptyBasesOfClassTransformer
    from .empty_kwonlyargs_of_function import EmptyKwonlyargsOfFunctionTransformer
    from .empty_kw_defaults_of_function import EmptyKw_defaultsOfFunctionTransformer
    from .empty_vararg_of_function import EmptyVarargOfFunctionTransformer
    from .empty_posonlyarg_of_function import EmptyPosonlyargOfFunctionTransformer
    from .float_power import FloatPowerTransformer

# Generated at 2022-06-23 23:18:51.353285
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    from ..unparse import Unparser
    from typed_ast import ast3 as ast

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:
            node.args = [ast.Name(id='Cls'), ast.Name(id='self')]

    source = '''
        class A:
            def __init__(self):
                super()
        class B(A):
            def __init__(self):
                super()
                
            def method(self):
                def func(arg):
                    super()                
    '''
    tree = compile(source, '<string>', 'exec', ast.PyCF_ONLY_AST)
    TestTransformer().visit(tree)
    unparse_code

# Generated at 2022-06-23 23:18:57.349873
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import as_tuple
    from ..utils.source import source_to_unicode

    source = """
        class A(object):
            def m(self):
                super()
    """
    expected_result = """
        class A(object):
            def m(self):
                super(A, self)
    """
    tree = as_tuple(ast.parse(source_to_unicode(source)))
    SuperWithoutArgumentsTransformer(tree).visit(tree)  # type: ignore
    assert expected_result == as_tuple(tree).body[0].body[0].body[0]

# Generated at 2022-06-23 23:18:58.492520
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:00.814263
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, filename="", mode="exec"))

# Generated at 2022-06-23 23:19:08.455794
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Foo:
        def __init__(self):
            super()

    class Foo:
        def __init__(self):
            super().__init__()

    class Bar(Foo):
        def __init__(self):
            super()

    class Bar(Foo):
        def __init__(self):
            super().__init__()

    class Bar(Foo):
        def __init__(self):
            super(Bar, self)

    class Bar(Foo):
        def __init__(self):
            super(Bar, cls).__init__()

    class Bar(Foo):
        def __init__(self):
            super(Bar, self).__init__()

    class Bar(Foo):
        def __init__(self):
            super(Bar, cls).__init__()

# Generated at 2022-06-23 23:19:09.332151
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:15.111781
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Should fail
    node = ast.parse('super')

    transformer_instance = SuperWithoutArgumentsTransformer()
    transformer_instance.visit_Call(node)
    assert transformer_instance._tree_changed == False
    
    # Should now work
    node = ast.parse('super()')
    transformer_instance = SuperWithoutArgumentsTransformer()
    transformer_instance.visit_Call(node)
    assert transformer_instance._tree_changed == True

# Generated at 2022-06-23 23:19:22.632312
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object
    from ..utils.helpers import get_ast

    code = """
    class Foo:
        def __init__(self, x):
            super().__init__(x)
    """
    tree = get_ast(code)
    assert SuperWithoutArgumentsTransformer().visit(tree)

    code2 = """
    class Foo:
        def __init__(self, x):
            super(Foo, cls).__init__(x)
    """
    tree2 = get_ast(code2)
    assert SuperWithoutArgumentsTransformer().visit(tree2)

    code3 = """
    class Foo(object):
        def __init__(self, x):
            super().__init__(x)
    """
    tree3 = get_ast

# Generated at 2022-06-23 23:19:23.709661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .utils import TreeSync


# Generated at 2022-06-23 23:19:33.759141
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "class Cls:\n" \
           "    def func(self):\n" \
           "        super()\n" \
           "class Cls2:\n" \
           "    def func(self):\n" \
           "        super().foo()\n" \
           "class Cls3:\n" \
           "    def func(self):\n" \
           "        super(Cls3)\n" \
           "class Cls4:\n" \
           "    def func(self):\n" \
           "        super(self)\n" \
           "    @property\n" \
           "    def foo(self):\n" \
           "        super()\n" \
           "super()\n"

    expected_code = "class Cls:\n" \
          

# Generated at 2022-06-23 23:19:35.451883
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..utils import code_equal

# Generated at 2022-06-23 23:19:39.494100
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    ast_node = ast3.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.visit(ast_node) == ast3.parse("super(Cls, self)")


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 23:19:40.143466
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call()

# Generated at 2022-06-23 23:19:45.538493
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
        """
        class Foo:
            pass
        
        class Bar(Foo):
            def __init__(self):
                super()
                
        class Bar(Foo):
            def bar(self):
                super()
        """
        tree = ast.parse('''
        class Foo:
            pass
        
        class Bar(Foo):
            def __init__(self):
                super()
                
        class Bar(Foo):
            def bar(self):
                super()
        ''')

        cls = tree.body[1]
        transformer = SuperWithoutArgumentsTransformer(tree)
        transformer.visit(cls)

        # Check the results

# Generated at 2022-06-23 23:19:53.270347
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree.body[0])

    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value.func.id == 'super'
    assert len(tree.body[0].value.args) == 2



# Generated at 2022-06-23 23:20:02.088600
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test for method visit_Call of class SuperWithoutArgumentsTransformer."""
    from typed_ast import ast3
    from HTMLTestRunner import HTMLTestRunner

    info = [
        {'call_node': ast3.parse('super()'), 'expected': ast3.parse('super(C, self)')},
        {'call_node': ast3.parse('super(a, **kw)').body[0].value, 'expected': ast3.parse('super(a, **kw)')},
    ]

    # type: ignore
    def test_method(call_node: ast3.Call, expected: ast3.Call) -> None:
        transformer = SuperWithoutArgumentsTransformer(ast3.parse('class C: def a(self): pass'))
        transformer.visit_Call(call_node)
        assert call_node

# Generated at 2022-06-23 23:20:05.826092
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    t.visit(tree)
    assert str(tree) == 'super(object, self)'


# Generated at 2022-06-23 23:20:16.598808
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import os
    sys.path.append(os.path.abspath(os.path.dirname(__file__)))
    import inspect
    from test_fixtures.test_super_without_arguments import A, B, C, D, E

    tree = inspect.getsource(A)
    expected_tree = inspect.getsource(B)

    assert SuperWithoutArgumentsTransformer(tree).result == expected_tree

    tree = inspect.getsource(C)
    expected_tree = inspect.getsource(D)

    assert SuperWithoutArgumentsTransformer(tree).result == expected_tree

    tree = inspect.getsource(E)
    expected_tree = inspect.getsource(E)

    assert SuperWithoutArgumentsTransformer(tree).result == expected_tree