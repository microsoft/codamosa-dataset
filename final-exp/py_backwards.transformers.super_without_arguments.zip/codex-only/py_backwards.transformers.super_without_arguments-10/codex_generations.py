

# Generated at 2022-06-23 23:10:26.292149
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:35.331769
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parsers.python import PythonParser
    node = ast.parse("super()", mode='exec')
    tree = PythonParser().parse_tree(node)
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_node = transformer.visit(node)
    # It should find the closet parent class (in this case ClassDef) and the 
    # closest parent function (in this case FunctionDef)
    assert isinstance(new_node.body[0].value.args[0], ast.Name)
    assert isinstance(new_node.body[0].value.args[1], ast.Name)
    assert new_node.body[0].value.args[0].id == 'ClassDef'
    assert new_node.body[0].value.args[1].id == 'FunctionDef'

# Generated at 2022-06-23 23:10:36.228630
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:39.870679
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree.body[0].value.args == [ast.Name(id='Cls', ctx=ast.Load()), ast.Name(id='self', ctx=ast.Load())]


# Generated at 2022-06-23 23:10:40.416400
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:41.819978
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_restricted


# Generated at 2022-06-23 23:10:45.297345
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # tests which do not require a widget
    test_code = 'super()'
    expected_code = 'super(cls, self)'
    root = ast.parse(test_code)
    SuperWithoutArgumentsTransformer(root).visit(root)
    assert to_source(root) == expected_code

# Generated at 2022-06-23 23:10:48.556294
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_equal
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer(node, ast.Module).visit(node)
    assert_code_equal(compile(node, '', 'exec'), 'super(Cls, self)\n')



# Generated at 2022-06-23 23:10:49.563126
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:56.891061
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    import unittest

    class Test(unittest.TestCase):

        def test_super(self) -> None:
            code = 'super()'
            tree = ast3.parse(code)
            transformer = SuperWithoutArgumentsTransformer(tree)
            transformer.run()
            transformed_code = compile(tree, '', 'exec')
            exec(transformed_code)
            self.assertEqual(code, 'super()')


# Generated at 2022-06-23 23:11:05.163758
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    # Test super() in class
    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert 'super(Cls, self)' in ast.dump(tree)

    # Test super() in classmethod
    tree = ast.parse('class A:\n    @classmethod\n    def a(cls):\n        super()')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert 'super(Cls, cls)' in ast.dump(tree)

    # Test super() in staticmethod
    tree = ast.parse('class A:\n    @staticmethod\n    def a():\n        super()')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
   

# Generated at 2022-06-23 23:11:12.183163
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    ast_tree = ast.parse(
        'class A:\n'
        '    def __init__(self):\n'
        '        super().__init__()\n'
    )
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast_tree)


# Generated at 2022-06-23 23:11:21.759438
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import inspect
    from typed_ast import ast3 as ast
    from ..utils.tree import node_to_str
    from .types import VisitorTestCase

    class Test(VisitorTestCase):
        transformer = SuperWithoutArgumentsTransformer

        def test_simple(self):
            tree = ast.parse("""
                class A:
                    def __init__(self):
                        super()
                """)
            self.check_transformation(tree, """
                class A:
                    def __init__(self):
                        super(A, self)
                """)

        def test_complex(self):
            tree = ast.parse("""
                class A:
                    def __init__(self):
                        super()

                class B:
                    def __init__(self):
                        super()
                """)
            self.check_

# Generated at 2022-06-23 23:11:25.632083
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor import dump
    from astor.code_gen import to_source

    code = """super()"""
    tree = ast.parse(code, mode='exec')
    SuperWithoutArgumentsTransformer().visit(tree)
    print(dump(tree, include_attributes=True))
    print(to_source(tree))

# Unit test

# Generated at 2022-06-23 23:11:26.612337
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:29.471134
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import FunctionDef, ClassDef, arguments, Name, Call, parse
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 23:11:40.036102
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from ..visitor import PythonTreeVisitor
    tree = ast.parse(textwrap.dedent('''
    class A:
        def __init__(self):
            super()
    '''))
    super_num = 0
    for node in PythonTreeVisitor().visit(tree):
        if isinstance(node, ast.Call) and\
           isinstance(node.func, ast.Name) and node.func.id == 'super':
            super_num += 1
    assert super_num == 1
    SuperWithoutArgumentsTransformer().visit(tree)
    super_num = 0

# Generated at 2022-06-23 23:11:45.617912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    cls = ast.ClassDef(
        name='Cls',
        bases=[],
        keywords=[],
        body=[ast.FunctionDef(
            name='foo',
            args=ast.arguments(
                args=[ast.arg(arg='self', annotation=None)],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]
            ),
            body=[ast.Expr(value=ast.Call(
                func=ast.Name(id='super', ctx=ast.Load()),
                args=[],
                keywords=[]
            ))],
            decorator_list=[],
            returns=None
        )]
    )


# Generated at 2022-06-23 23:11:55.189798
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SimpleSuperTransformerTests(unittest.TestCase):
        def test_super_wo_args(self):
            """Tests if super() can be found in the AST and fixed."""
            code = dedent('''
                class Foo:
                    def __init__(self):
                        super()
            ''')

            tree = ast.parse(code)
            SuperWithoutArgumentsTransformer().visit(tree)
            check_code = dedent('''
                class Foo:
                    def __init__(self):
                        super(Foo, self)
            ''')
            self.maxDiff = None
            self.assertEqual(check_code.strip('\n'), ast.dump(tree).strip('\n'))

# Generated at 2022-06-23 23:12:06.062241
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import compare_trees
    from ..utils import dedent_ftl
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformerRunTest

    source = dedent_ftl("""
        class A:
            def foo(self):
                super().bar()
    """)

    expected_tree = dedent_ftl("""
        class A:
            def foo(self):
                super(A, self).bar()
    """)

    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    assert compare_trees(expected_tree, new_tree)
    assert transformer.tree_changed == True  # type: ignore
    run_transformer = BaseNodeTransformerRunTest(source)

# Generated at 2022-06-23 23:12:10.078615
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()', mode='single').body[0]
    assert isinstance(node, ast.Expr)

    result = utils.run_visitor(node, SuperWithoutArgumentsTransformer())
    assert result == 'super(Cls, self)'

# Generated at 2022-06-23 23:12:12.035083
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_utils import assert_transformation


# Generated at 2022-06-23 23:12:15.396400
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)

    node = ast.parse('super()')
    transformer._replace_super_args(node.body[0].value)
    assert node == ast.parse('super(Cls, self)')

# Generated at 2022-06-23 23:12:19.719393
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import expect_to_compile
    expect_to_compile(
        r'''
        class A:
            def __init__(self):
                super().__init__()
        ''',
        2,
        r'''
        class A:
            def __init__(self):
                super(A, self).__init__()
        '''
    )

# Generated at 2022-06-23 23:12:23.924022
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert code_gen.to_source(tree) == "super(Cls, self)"


# Generated at 2022-06-23 23:12:32.685274
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..typeshed import FunctionDef, Name, ClassDef, arguments

    class DummyTransformer(BaseNodeTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:
            assert isinstance(node, ast.Call)
            node.args = [ast.Name(id=f'cls{id(node)}'), ast.Name(id=f'func{id(node)}')]

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if (
                isinstance(node.func, ast.Name)
                and node.func.id == 'super'
                and not len(node.args)
            ):
                self._replace_super_args(node)

            return node


# Generated at 2022-06-23 23:12:33.594522
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:35.163329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:12:45.534107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from .util import expect_transformation

    expect_transformation(
        SuperWithoutArgumentsTransformer,
        dedent('''
            class Cls(object):
                def meth(self):
                    super()
        '''),
        dedent('''
            class Cls(object):
                def meth(self):
                    super(Cls, self)
        '''),
    )


# Generated at 2022-06-23 23:12:53.164992
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
    class Cls:
        def __init__(self):
            super().__init__()
    """)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert tree.body[0].body[0].body[0].args[0].s == 'Cls'
    assert tree.body[0].body[0].body[0].args[1].id == 'self'
    assert tree.body[0].body[0].body[0].args[1].ctx.id == 'Load'



# Generated at 2022-06-23 23:12:55.197437
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import tree
    from .. import helpers


# Generated at 2022-06-23 23:12:58.445027
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
    class CM():
        def ff(self):
            super(CM, self)
    """)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert True

# Generated at 2022-06-23 23:13:06.858336
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_restricted
    from .. import untokenize

    source = source_to_unicode("""
        class Foo(object):
            def setUp(self):
                super()
    """)

    tree = compile_restricted(source, '<test>', 'exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    result = untokenize(tree).strip()

    assert result.strip() == """
        class Foo(object):
            def setUp(self):
                super(Foo, self)
    """.strip()

# Generated at 2022-06-23 23:13:16.561806
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('class C: x=super()', mode='eval')
    # print(ast.dump(tree))

    tree_changed = False
    cls = SuperWithoutArgumentsTransformer(tree, tree_changed)
    cls.visit(tree)
    # print(ast.dump(tree))

    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='C', ctx=Load()), Name(id='x', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:13:23.454589
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import tree
    from .. import utils
    from ..utils import helpers
    super_without_arguments_transformer = utils.run_transformer_on_single_file(tree, SuperWithoutArgumentsTransformer, 'test_transformers/helpers.py')
    assert super_without_arguments_transformer._tree.body[0].body[0].body[0].value.func.args[1].id == 'self'
    assert super_without_arguments_transformer._tree.body[0].body[1].body[0].value.func.args[1].id == 'cls'

# Generated at 2022-06-23 23:13:27.890619
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree, find_all_nodes, get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-23 23:13:28.429884
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:29.307692
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:30.413160
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:39.609514
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    t = SuperWithoutArgumentsTransformer()

    assert False == t.visit(ast.FunctionDef(name='func', lineno=1, col_offset=0,
        args=ast.arguments(args=[ast.arg(arg='self', annotation=None, lineno=1, col_offset=5)],
            vararg=None, kwarg=None, kwonlyargs=[], defaults=[], kw_defaults=[]),
        body=[ast.Expr(ast.Call(func=ast.Name(id='super', ctx=ast.Load(), lineno=2, col_offset=4),
            args=[], keywords=[], starargs=None, kwargs=None, lineno=2, col_offset=4))], decorator_list=[], returns=None))

    assert True

# Generated at 2022-06-23 23:13:41.106394
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode


# Generated at 2022-06-23 23:13:48.177588
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def __init__(self):
                super().__init__(1)
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert len(tree.body[0].body[0].body[0].args[1].args) == 2
    assert isinstance(tree.body[0].body[0].body[0].args[1].args[0], ast.Name)
    assert tree.body[0].body[0].body[0].args[1].args[0].id == "A"
    assert isinstance(tree.body[0].body[0].body[0].args[1].args[1], ast.Name)

# Generated at 2022-06-23 23:13:58.257616
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # assert super()
    before = 'assert super()'
    after = 'assert super(B, self)'

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(before))
    actual = compile(t.tree, '', 'exec')
    assert after in str(actual)
    # assert super() and super()
    before = 'assert super() and super()'
    after1 = 'assert super(B, self) and super(B, self)'
    after2 = 'assert super(B, self) and super(B, cls)'
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(before))
    actual = compile(t.tree, '', 'exec')
    assert (after1 in str(actual) or after2 in str(actual)) or after2 in str

# Generated at 2022-06-23 23:14:04.069232
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    x = """
    class Spam:
        def __init__(self):
            super()
        @classmethod
        def bar(cls):
            super()
    """
    y = """
    class Spam:
        def __init__(self):
            super(Spam, self)
        @classmethod
        def bar(cls):
            super(Spam, cls)
    """
    tree = ast.parse(x)
    new_tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(new_tree) == y

# Generated at 2022-06-23 23:14:10.208237
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    assert t._tree_changed is False
    assert t.visit(ast.parse('super()').body[0]) == ast.parse('super(Cls, self)').body[0]
    assert t._tree_changed is True
    assert t.visit(ast.parse('super()').body[0]) == ast.parse('super(Cls, self)').body[0]
    assert t._tree_changed is True # second call shouldn't change it

# Generated at 2022-06-23 23:14:12.574374
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.parse('foo()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert False

# Generated at 2022-06-23 23:14:14.286874
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:14:22.714691
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.unparser import Unparser

    source = source_to_unicode("""\
            class Parent:
                pass

            class Child(Parent):
                def __init__(self):
                    super()
                    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(Unparser(tree)) == source_to_unicode("""\
            class Parent:
                pass

            class Child(Parent):
                def __init__(self):
                    super(Child, self)
            """)

# Generated at 2022-06-23 23:14:25.469902
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(Cls, self)" == to_source(tree)

# Generated at 2022-06-23 23:14:29.966531
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    import textwrap
    from ..utils.helpers import line_parser

    # https://github.com/python/cpython/blob/3.8/Lib/test/test_super.py#L945-L957
    code = textwrap.dedent('''
        class A():
            def __init__(self):
                super()
    ''')
    expected = textwrap.dedent('''
        class A():
            def __init__(self):
                super(A, self)
    ''')
    result = SuperWithoutArgumentsTransformer().visit(line_parser(code))

    assert pyast.dump(pyast.parse(expected)) == pyast.dump(result)

# Generated at 2022-06-23 23:14:38.508140
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super(C,s).f()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0].value.func, ast.Call)
    assert tree.body[0].value.func.func.id == 'super'
    assert isinstance(tree.body[0].value.func.args[0], ast.Name)
    assert tree.body[0].value.func.args[0].id == 'C'
    assert isinstance(tree.body[0].value.func.args[1], ast.Name)
    assert tree.body[0].value.func.args[1].id == 's'

# Generated at 2022-06-23 23:14:39.148858
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:14:42.002111
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import get_name_node
    from ..utils.helpers import ast_to_str


# Generated at 2022-06-23 23:14:50.432570
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from compiler.ast import CallFunc, Name, Assign

    node_a = Name('a')
    node_b = CallFunc(Name('b'), [])

    # Example 1
    label = Assign(
        [AssName('foo', 'OP_ASSIGN')],
        node_b
    )
    expected = Assign(
        [AssName('foo', 'OP_ASSIGN')],
        CallFunc(Name('b'), [node_a])
    )

    result = SuperWithoutArgumentsTransformer().visit_Call(label)
    assert astor.to_source(expected).strip() == astor.to_source(result).strip()

# Generated at 2022-06-23 23:14:52.364976
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u


# Generated at 2022-06-23 23:15:01.420275
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_with_line_numbers import SourceWithLineNumbers
    source = SourceWithLineNumbers.from_string('''
    class Base(object):
        def __init__(self):
            super().__init__()
            
    class Cls(Base):
        def __new__(cls):
            super().__init__()
    ''')
    tree = ast.parse(str(source))
    transformer = SuperWithoutArgumentsTransformer(tree, source)
    transformer.visit(tree)
    result = str(source)
    assert result.count('super(Cls, self)') == 1
    assert result.count('super(Cls, cls)') == 1



# Generated at 2022-06-23 23:15:07.459568
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .visitor import NodeTransformer

    class Example(NodeTransformer):
        def __init__(self):
            super(Example, self).__init__()
            self.super_node = None

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self.super_node = node

            return node


# Generated at 2022-06-23 23:15:16.295809
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    node = ast.parse('''
        class A:
            def __init__(self):
                super()
    ''')
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.ClassDef)
    assert isinstance(node.body[0].body[0], ast.FunctionDef)
    assert isinstance(node.body[0].body[0].body[0], ast.Expr)
    assert node.body[0].body[0].body[0].value.args[0].id == 'A'

# Generated at 2022-06-23 23:15:19.119450
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tt = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tt)
    assert to_source(tt) == "super(__class__, self)"

# Generated at 2022-06-23 23:15:22.968062
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..lexer import tokenize
    from ..parser import python_ast
    from ..transformer import Transformer
    code = "super()"
    tree = python_ast(tokenize(code))
    Transformer(tree, [SuperWithoutArgumentsTransformer]).transform()
    assert code != tree.code

# Generated at 2022-06-23 23:15:23.705815
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:30.895289
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparser
    import textwrap
    from ..utils.source import Source


# Generated at 2022-06-23 23:15:37.404426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import parse, dump_ast
    
    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = parse(source)
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(tree)
    dumped = dump_ast(tree)

# Generated at 2022-06-23 23:15:47.312436
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    # Program: super()
    classDef = ast.ClassDef(name='Cls',
        body=[ast.FunctionDef(name='method', args=ast.arguments(args=[ast.arg(arg='self')]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))])],
    )

    expected = ast.ClassDef(name='Cls',
        body=[ast.FunctionDef(name='method', args=ast.arguments(args=[ast.arg(arg='self')]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[]))])],
    )

    node = SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:56.120317
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()
    call = ast.parse('super()').body[0].value
    cls_def = ast.parse('class Tst:\n def foo(self):\n  pass').body[0]

    assert isinstance(call, ast.Call)
    assert not len(call.args)
    assert isinstance(call.func, ast.Name)
    assert call.func.id == 'super'

    t._replace_super_args(call)

    assert isinstance(call.args[0], ast.Name)
    assert call.args[0].id == 'Tst'
    assert isinstance(call.args[1], ast.Name)
    assert call.args[1].id == 'self'

    new_call = ast.Call()

# Generated at 2022-06-23 23:16:01.365741
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class MyClass(object):
            def my_func(self):
                super()
        """
    expected_code = """
        class MyClass(object):
            def my_func(self):
                super(MyClass, self)
        """
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))

    assert(expected_code == astor.to_source(t.tree).strip())

# Generated at 2022-06-23 23:16:11.770387
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_from = \
    """
    class Cls(Super):
        def __init__(self):
            super()
    """
    code_to = \
    """
    class Cls(Super):
        def __init__(self):
            super(Cls, self)
    """
    node = parse(code_from)
    SuperWithoutArgumentsTransformer().visit(node)
    assert code_to == astor.to_source(node)

    code_from = \
    """
    class Cls(Super):
        @classmethod
        def another(cls):
            super()
    """
    code_to = \
    """
    class Cls(Super):
        @classmethod
        def another(cls):
            super(Cls, cls)
    """
    node = parse

# Generated at 2022-06-23 23:16:19.787902
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .helper import get_ast, assert_source
    from .test_BaseNodeTransformer import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_super_on_method(self):
            src = '''
            class Foo:
                def bar():
                    super()
            
            def foo():
                super()
            '''

            expected_result = '''
            class Foo:
                def bar():
                    super(Foo, self)
            
            def foo():
                super()
            '''

            tree = get_ast(src)

            transformer = SuperWithoutArgumentsTransformer(tree)
            tree = transformer.visit(tree)
            assert transformer.tree_changed == True


# Generated at 2022-06-23 23:16:20.268570
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:21.324935
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:29.333709
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from ..utils.ast_helpers import is_same_ast
    from .transformers.helpers import CompileUnitHelper
    from .transformers.tests.base_transformers_test import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target = (2, 7)

        def _test_code(self, source_code: str, expected_methods: List[str]):
            self._run_test(source_code)
            assert len(self._tested_methods) == len(expected_methods)
            for i in range(len(self._tested_methods)):
                assert is_same_ast(self._tested_methods[i], expected_methods[i])

        def test_should_replace_all_supers_without_args(self):
            source_code

# Generated at 2022-06-23 23:16:36.987910
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import AstBuilder
    from ..utils.helpers import compile_code_to_ast

    builder = AstBuilder()
    code = """
        class Foo():
            def __init__(self):
                super()
        """
    tested = SuperWithoutArgumentsTransformer(compile_code_to_ast(code), builder)
    expected = builder.parse_expr("""
        class Foo():
            def __init__(self):
                super(Foo, self)
    """)
    tested.visit(tested._tree)
    assert tested._tree == expected

# Generated at 2022-06-23 23:16:42.988390
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_parser import tree_from_ast
    from ..utils.helpers import print_ast

    # TODO: add tests
    code = '''super()'''
    tree = tree_from_ast(ast.parse(code))
    SuperWithoutArgumentsTransformer(tree).apply()
    print_ast(tree)

# Generated at 2022-06-23 23:16:47.802787
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_programs.super_without_args_transformer_test_program import program
    from astunparse import dump
    from ..utils.python import drop_final_newline

    node = program

    compiler = SuperWithoutArgumentsTransformer()
    new_node = compiler.visit_ClassDef(node)


# Generated at 2022-06-23 23:16:50.184230
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    output = astor.to_source(node)
    assert output == 'super(Cls, self)'

# Generated at 2022-06-23 23:16:53.152444
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    source = "super()"
    expected_source = "super(Cls, cls)"
    ast_tree = source_to_ast(source)
    SuperWithoutArgumentsTransformer(ast_tree).visit(ast_tree)
    result = compile(ast_tree, '', 'exec')
    assert(result.co_code == compile(expected_source, '', 'exec').co_code)

# Generated at 2022-06-23 23:16:55.681773
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import test_utils
    from . import base


# Generated at 2022-06-23 23:17:05.646137
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.tree import file_to_ast_tree
    from ..utils.helpers import get_unique_name

    # Prepare
    code = """
    class Foo:
        def __init__(self):
            super().__init__()
        def foo():
            return super()
    """
    expected_code = """
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()
        def foo():
            return super(Foo, cls)
    """

    # Run
    tree = file_to_ast_tree(code, __file__)
    SuperWithoutArgumentsTransformer().visit(tree)

    # Assert
    assert get_unique_name(tree) == get_unique_name(expected_code)

# Generated at 2022-06-23 23:17:13.779919
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    node_super = tree.body[0].value # type: ast.Call
    assert isinstance(node_super, ast.Call)

    SuperWithoutArgumentsTransformer(tree).run()

    node_super = tree.body[0].value # type: ast.Call
    assert isinstance(node_super.args[0], ast.Name)
    assert isinstance(node_super.args[1], ast.Name)
    assert node_super.args[0].id == 'Cls'
    assert node_super.args[1].id == 'self'

# Generated at 2022-06-23 23:17:15.830184
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..context import Context
    from ..utils import parse_code
    from ..utils import dump_tree
    import sys

    ctx = Context()

# Generated at 2022-06-23 23:17:19.230980
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transformers.base import BaseNodeTransformer
    from ..transformers.super_without_arguments import SuperWithoutArgumentsTransformer
    from ..utils.tree import get_closest_parent_of

    def test_no_parent():
        import typed_astunparse

# Generated at 2022-06-23 23:17:25.683245
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    node = ast.parse('super()').body[0]
    t.visit(node)
    expected = ast.parse('super(Cls, self)').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert node.value.func.id == expected.value.func.id
    assert node.value.args[0].id == expected.value.args[0].id
    assert node.value.args[1].id == expected.value.args[1].id

# Generated at 2022-06-23 23:17:29.270934
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert 'super(Cls, self)' in astunparse.unparse(tree)  # type: ignore

# Generated at 2022-06-23 23:17:39.544005
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import ctree as c_ast
    from ..utils import parse as ast_parse

    code = """
    class Class:
        def method(self):
            super()
    """
    tree = ast_parse.parse(code)

# Generated at 2022-06-23 23:17:47.080622
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.source import source_to_unicode
    from ..fixer_base import BaseFix

    class Fixer(BaseFix):
        PATTERN = ''
        def transform(self, root: ast.AST, metadatas: list) -> None:
            SuperWithoutArgumentsTransformer(root).run()

    source = '''
    class Test:
        def test(self):
            super()
    '''
    expected = '''
    class Test:
        def test(self):
            super(Test, self)
    '''
    root = astor.parse_string(source_to_unicode(source))
    Fixer().transform(root, [])
    assert expected == astor.to_source(root)


# Generated at 2022-06-23 23:17:51.770260
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    c = """
        super()
    """
    o = """
        super(Cls, self)
    """
    tree = ast.parse(c)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert fix(astunparse.unparse(tree)) == fix(o)

# Generated at 2022-06-23 23:18:01.894310
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .base import BaseNodeTransformerTest
    from ..utils.helpers import format_code
    from textwrap import dedent

    source = dedent("""
    class A:
        def foo(self):
            super()
    """)

    expected_transformed_source = dedent("""
    class A:
        def foo(self):
            super(A, self)
    """)

    tree = ast.parse(source_to_unicode(source))
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    transformed_source = format_code(ast.get_source(tree, source))
    assert expected_transformed_source == transformed_source

    class Test(BaseNodeTransformerTest):
        transformer = SuperWithoutArgumentsTransformer
        samples

# Generated at 2022-06-23 23:18:05.545153
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Testing of the SuperWithoutArgumentsTransformer.
    """
    import astor
    from ..utils.helpers import get_first_arg, get_second_arg, get_third_arg, get_fourth_arg


# Generated at 2022-06-23 23:18:06.784800
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:07.940062
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # assert SuperWithoutArgumentsTransformer()
    pass

# Generated at 2022-06-23 23:18:08.539236
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Not sure how to unit test this... I didn't do it :)"""

# Generated at 2022-06-23 23:18:14.944041
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..transformers.base import BaseNodeTransformer
    from ..transformers.SuperWithoutArgumentsTransformer import SuperWithoutArgumentsTransformer
    import typed_ast.ast3
    import textwrap
    import sys

    # Python code to test
    code = textwrap.dedent(
        """
        class TestClass:
            def test_method(self):
                super()
    """
    )

    node = typed_ast.ast3.parse(code)
    node = SuperWithoutArgumentsTransformer().visit(node)

    print(typed_ast.ast3.dump(node))
    print(node.body[0].body[0].value.args[0].id)
    assert node.body[0].body[0].value.args[0].id == 'TestClass'
    assert node.body[0].body

# Generated at 2022-06-23 23:18:17.918234
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    code = 'super().foo()'
    ctx = compile(code, '<test>', 'exec', target=SuperWithoutArgumentsTransformer.target)
    assert ctx == """\
if 1:
    super(__name__, self).foo()
"""

# Generated at 2022-06-23 23:18:22.874684
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("""
    class MyClass(object):
        def method(self, param):
            super()
    """).body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    source = astor.to_source(node)
    assert source == "def method(self, param):\n    super(MyClass, self)"

# Generated at 2022-06-23 23:18:26.836740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transformer import Transformer
    from ..utils.helpers import code_equal

    # expected code

# Generated at 2022-06-23 23:18:27.424318
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:18:28.438019
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:34.629821
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''if True:
                class Foo:
                    def __init__(self):
                        super()
            '''
    tree = ast.parse(code)
    expected_code = '''if True:
                class Foo:
                    def __init__(self):
                        super(Foo, self)
            '''
    expected_tree = ast.parse(expected_code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:18:43.663112
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .transformer2to3 import Python2to3Transformer

    t = Python2to3Transformer()
    t.tree = ast.parse('super().blah()')
    assert t.tree.to_source() == 'super().blah()'
    t.visit(t.tree)
    assert t.tree.to_source() == 'super(__class__, self).blah()'

    t.tree = ast.parse('def foo():\n    super().blah()\nsuper()')
    assert t.tree.to_source() == 'def foo():\n    super().blah()\nsuper()'
    t.visit(t.tree)

# Generated at 2022-06-23 23:18:44.829033
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:46.342688
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:18:56.148443
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    call = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )
    call_expected = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[ast.Name(id='Cls'), ast.Name(id='self')],
        keywords=[],
        starargs=None,
        kwargs=None
    )

# Generated at 2022-06-23 23:18:59.468874
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "super()"
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert ''.join(line for line in astor.to_source(tree).splitlines()) == "super(Cls, self)"

# Generated at 2022-06-23 23:19:07.538801
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    from ..utils.tree import node_to_str
    from ..utils.python_source_code_generator import to_source
    from .. import compile
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:19:08.549794
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:15.335411
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.fixtures import simple_module, simple_class, simple_method

    module = simple_module(
        simple_class(
            simple_method(
                body='''super() # type: ignore'''
            )
        )
    )
    expected = simple_module(
        simple_class(
            simple_method(
                body='''super(Foo, self) # type: ignore'''
            )
        )
    )
    assert SuperWithoutArgumentsTransformer.run_test(module, expected)



# Generated at 2022-06-23 23:19:17.756708
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert to_source(tree) == "super(Test, self)"

# Generated at 2022-06-23 23:19:18.434074
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:19.108376
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor


# Generated at 2022-06-23 23:19:25.443590
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    node.value.func.id = 'super'
    node.value.args = []
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 0
    node.value.func.id = 'super'
    node.value.args = [ast.Name(id="_")]
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 1
    node.value.func.id = 'super'
    node.value.args = [ast.Name(id="_"), ast.Name(id="_")]

# Generated at 2022-06-23 23:19:27.914114
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:28.493496
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:38.499968
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    ast1 = source_to_ast.parse_ast('super()', mode='eval')
    ast2 = source_to_ast.parse_ast('super()')

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast1)
    t.visit(ast2)


    assert isinstance(ast1.body, ast.Call)
    assert isinstance(ast1.body.func, ast.Attribute)
    assert isinstance(ast1.body.func.value, ast.Name)

    assert isinstance(ast2.body[0], ast.Expr)
    assert isinstance(ast2.body[0].value, ast.Call)
    assert isinstance(ast2.body[0].value.func, ast.Attribute)

# Generated at 2022-06-23 23:19:43.272978
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tt = ast.parse('super()')
    tt = SuperWithoutArgumentsTransformer().visit(tt)
    assert ast.dump(tt, include_attributes=True) == \
        "Call(args=[Name(id='Cls', ctx=Load(), lineno=1, col_offset=5, start_pos=5, end_pos=8)], func=Name(id='super', ctx=Load(), lineno=1, col_offset=1, start_pos=1, end_pos=6), keywords=[], starargs=None, kwargs=None, lineno=1, col_offset=1, end_pos=11)"

# Generated at 2022-06-23 23:19:44.277125
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-23 23:19:45.787600
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..converter import Converter
    from ..converter.utils import get_value


# Generated at 2022-06-23 23:19:56.506897
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.fake_tree import FakeTree, FakeFunctionDef
    from ..utils.helpers import get_ast
    from .base import BaseNodeTransformer, NodeTransformerError
    
    code_to_parse = """
        class Test():
            def foo(self):
                super()

            def bar(cls):
                super()

            def baz_1():
                super()

            def baz_2(self):
                super()

            def baz_3(cls):
                super()
    """
    tree = ast.parse(code_to_parse)
    node_transformer = SuperWithoutArgumentsTransformer()
    node_transformer.visit(tree)

# Generated at 2022-06-23 23:20:04.014661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code

    source = """
    class Parent:
        def foo(self):
            super().bar()
            
        def bar(self):
            pass

    class Child(Parent):
        def foo(self):
            super().bar()
            
        def bar(self):
            pass
    """
    expected = """
    class Parent:
        def foo(self):
            super(Parent, self).bar()
            
        def bar(self):
            pass

    class Child(Parent):
        def foo(self):
            super(Child, self).bar()
            
        def bar(self):
            pass
    """

    tree = to_ast(source)
    SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:13.940009
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.build_tree import build_ast_tree
    from ..utils.helpers import compare_code
    code = """class Test:
        def __init__(self) -> None:
            super()
        def t(self) -> None:
            super().foo()
    """
    tree = build_ast_tree(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    compare_code(tree, """class Test:
        def __init__(self) -> None:
            super(Test, self)
        def t(self) -> None:
            super(Test, self).foo()
    """)



# Generated at 2022-06-23 23:20:25.312379
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_program_equal
    from .test_helpers import get_func
    from typed_ast import ast3 as ast
    
    transformer = SuperWithoutArgumentsTransformer()
    name = ast.Name(id="foo")
    call = ast.Call(func=name, args=[])
    
    node = get_func(
        funcname='foo',
        args=[],
        code='''
        class A:
            def bar(self):
                super()
        '''
    )

    tree = ast.parse(node.code)
    tree.body[0].body[0].body[0].value = call
    
    new_tree = transformer.visit(tree)

    assert_program_equal(new_tree, node)

