

# Generated at 2022-06-23 23:10:16.902323
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:21.073366
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import tree_to_str
    source = '''
    class A:
        def meth(self):
            super()
    '''
    tree = ast.parse(source)
    trans = SuperWithoutArgumentsTransformer(tree)
    trans.run()
    assert tree_to_str(tree) == '''
    class A:
        def meth(self):
            super(A, self)
    '''

# Generated at 2022-06-23 23:10:31.039744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip, parse_ast

    code = """
        class Cls:
            def __init__(self):
                self.something = super().__new__()
    """
    tree = parse_ast(code)
    SuperWithoutArgumentsTransformer(tree).run()
    assert round_trip(tree) == """
        class Cls:
            def __init__(self):
                self.something = super(Cls, self).__new__()
    """

    code = """
        class Cls:
            def __init__(self):
                self.something = super()
    """
    tree = parse_ast(code)
    SuperWithoutArgumentsTransformer(tree).run()

# Generated at 2022-06-23 23:10:38.139745
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    sample_tree = ast.parse('super()')
    transformed_tree = ast.parse('super(Cls, self)')
    transformer = SuperWithoutArgumentsTransformer(sample_tree)
    
    # Success
    assert transformer.code == compile(transformed_tree, filename='<ast>', mode='exec')

    # Fail
    transformed_tree = ast.parse('super(Cls, self)')
    transformer = SuperWithoutArgumentsTransformer(sample_tree)

    assert transformer.code != compile(transformed_tree, filename='<ast>', mode='exec')

# Generated at 2022-06-23 23:10:41.533399
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .unparser import Unparser
    from ..parser import get_parser
    line = 'super()'
    parser = get_parser(line, target_versions=['2.7'])
    node = next(parser.parse())
    transformer = SuperWithoutArgumentsTransformer()
    newnode = transformer.visit(node)
    Unparser(newnode, target_versions=['2.7'])



# Generated at 2022-06-23 23:10:42.752796
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:49.315298
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_string
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        transformer = SuperWithoutArgumentsTransformer

        def _run_test(self, code: str, result: str):
            super()._run_test(code, code)

    # 1. super()
    code = '''
        class A:
            def x(self):
                super()
    '''
    result = '''
        class A:
            def x(self):
                super(A, self)
    '''
    Test().assert_result(code, result)

    # 2. super()
    code = '''
        class A:
            def x(self):
                super(A, self)
    '''

# Generated at 2022-06-23 23:10:51.644643
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..common.testing_support import TransformerTestCase
    from ..utils.helpers import make_tree


# Generated at 2022-06-23 23:10:54.305728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    target = """
            class Foo:
                def bar(self):
                    super()
            """
    expected = """
            class Foo:
                def bar(self):
                    super(Foo, self)
            """
    node = ast.parse(target)
    result = SuperWithoutArgumentsTransformer().visit(node)
    assert astor.to_source(result) == expected


# Generated at 2022-06-23 23:10:55.588216
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile

# Generated at 2022-06-23 23:10:56.530857
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:57.119105
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:05.329275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import node_factory
    from ..utils.source import Source
    from ..ast_transformer import ASTTransformer

    source = Source("""

    class Foo:
        def __init__(self):
            super().__init__()

    class Bar(Foo):
        def __init__(self):
            super().__init__()

    """)

    tree = node_factory.extract_ast(source)
    transformer = ASTTransformer(tree, {SuperWithoutArgumentsTransformer})
    transformer.transform()


# Generated at 2022-06-23 23:11:06.449708
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    

# Generated at 2022-06-23 23:11:09.861768
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

    tree = ast.parse('''
        class SuperClass:
            def __init__(self):
                # super() is here
                super()
    ''')  # type: ast.Module

    transformer.visit(tree)

    assert transformer._tree_changed is True

# Generated at 2022-06-23 23:11:13.214633
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_
    assert compile_("super()") == "super(Cls, self)"

# Generated at 2022-06-23 23:11:22.605877
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    tree = ast3.parse("""
    class C(object):
        def __init__(self):
            super()
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast3.Expr)
    assert isinstance(node.value, ast3.Call)
    assert isinstance(node.value.func, ast3.Name)
    assert node.value.func.id == 'super'
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert isinstance(node.value.func, ast3.Call)

################################################################################
#                                                                              #
#                           test_SuperWithoutArgumentsTransformer_visit_Call   #
#                                                                              #
########

# Generated at 2022-06-23 23:11:26.412695
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # create an instance of SuperWithoutArgumentsTransformer
    obj1 = SuperWithoutArgumentsTransformer(None)

    obj1.target = 2, 7
    obj1.version = (2, 7)
    obj1.visit_Call(None)

# Generated at 2022-06-23 23:11:30.437515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_output = """
    class Test(object):
        def __init__(self):
            f = super(Test, self)
            f = super(Test, cls)          
    """


# Generated at 2022-06-23 23:11:32.406616
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import astor
    from .unpacking import UnpackingTransformer

# Generated at 2022-06-23 23:11:35.683929
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fake_ast import FileInput
    from .helpers import get_node
    from ..utils.helpers import get_text_from_node
    import astor


# Generated at 2022-06-23 23:11:37.533170
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_node


# Generated at 2022-06-23 23:11:38.925103
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import cst_visitors


# Generated at 2022-06-23 23:11:46.631940
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    #  Test super() in a class
    test_tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(test_tree)
    assert ast.dump(new_tree) == "Module(body=[FunctionDef(name='<module>', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))], decorator_list=[], returns=None)])"

    # Test super() outside of a class
   

# Generated at 2022-06-23 23:11:52.446717
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'super()'
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '<test>', mode='exec')   # Check that code is valid.
    exec(compile(tree, '<test>', mode='exec'))    # Check that code is valid.



# Generated at 2022-06-23 23:11:53.358148
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:54.355398
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:00.549252
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from astmonkey import visitors
    from astmonkey.transformers import SuperWithoutArgumentsTransformer

    class Template(object):
        _tree = None  # type: ast.AST
        _transformer = None  # type: SuperWithoutArgumentsTransformer


# Generated at 2022-06-23 23:12:06.062290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unparser import Unparser

    src = """
        class Test:
            def __init__(self):
                super()
    """

    tree = compile(src, '<test>', 'exec', ast.PyCF_ONLY_AST)

    SuperWithoutArgumentsTransformer().visit(tree)

    assert Unparser(tree).code == """
        class Test:
            def __init__(self):
                super(Test, self)
    """

# Generated at 2022-06-23 23:12:13.041860
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_tree = transformer.visit(tree)
    code1 = compile(new_tree, '', mode='exec')
    ns = {}
    eval(code1, ns)
    assert ns['A'].__init__(ns['A']()) is None

# Generated at 2022-06-23 23:12:17.040608
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with open(join(dirname(__file__), 'SuperWithoutArgumentsTransformer.py')) as sut:
        node = ast.parse(sut.read())
        SuperWithoutArgumentsTransformer().visit(node)
        exec(compile(node, filename="<ast>", mode="exec"))

# Generated at 2022-06-23 23:12:26.956298
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "def foo(self):\n    super()"
    t = ast.parse(code)
    SuperWithoutArgumentsTransformer(t).visit(t)
    assert ast.dump(t) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='self', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Foo', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))], decorator_list=[], returns=None)])"
    assert SuperWithoutArgumentsTransformer(t).tree

# Generated at 2022-06-23 23:12:34.933746
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_mod_ast, assert_source_equal

    assert_mod_ast(SuperWithoutArgumentsTransformer,
        source = '''
            class Foo:
                def bar(self):
                    super()
        ''',
        expected = '''
            class Foo:
                def bar(self):
                    super(Foo, self)
        ''',
    )
    assert_source_equal(SuperWithoutArgumentsTransformer,
        source = '''
            class Foo:
                def bar(self):
                    super()
        ''',
        expected = '''
            class Foo:
                def bar(self):
                    super(Foo, self)
        ''',
    )

# Generated at 2022-06-23 23:12:35.960571
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:46.222825
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    
    class B:
        def __init__(cls):
            super()
    """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert len(tree.body) == 2
    assert len(tree.body[0].body) == 1
    assert len(tree.body[0].body[0].body) == 1
    assert tree.body[0].body[0].body[0].args[0].id == 'A'
    assert tree.body[0].body[0].body[0].args[1].id == 'self'
    assert len(tree.body[1].body) == 1
    assert len(tree.body[1].body[0].body)

# Generated at 2022-06-23 23:12:47.778422
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:48.993851
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile

# Generated at 2022-06-23 23:12:53.395107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)

    expected = ast.parse('super(Cls, self)')
    result = SuperWithoutArgumentsTransformer(tree, cls='Cls').visit(tree)

    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 23:13:04.654063
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    class A:
        def func(self):
            super()
            return super(B, self)

        @classmethod
        def mfunc(cls):
            cls.mfunc()  #Just some random node to make it more complex
            super()

    class B:
        def func(self):
            super()
            return super(B, self)

        @classmethod
        def mfunc(cls):
            cls.mfunc()  #Just some random node to make it more complex
            super()

    tree = ast3.parse(inspect.getsource(A))
    tree2 = ast3.parse(inspect.getsource(B))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer2 = SuperWithoutArgumentsTransformer(tree2)

# Generated at 2022-06-23 23:13:08.714273
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import expect_equal_source

    code = '''
    class Klass(object):
        def method(self):
            super()
    '''
    expect_equal_source(
        code,
        SuperWithoutArgumentsTransformer
    )



# Generated at 2022-06-23 23:13:09.360568
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:20.221646
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from ..testing_utils import assert_transformed_ast_is

    # Simple test
    class_ast = ast.parse('class A(B):\n    def method(self):\n        super()')
    class_ast_transformed = SuperWithoutArgumentsTransformer().visit(class_ast)
    assert_transformed_ast_is('class A(B):\n    def method(self):\n        super(A, self)', class_ast_transformed)

    # Test with more code
    class_ast = ast.parse('class A(B):\n    def method(self):\n        super()\n        super()')
    class_ast_transformed = SuperWithoutArgumentsTransformer().visit(class_ast)

# Generated at 2022-06-23 23:13:26.176686
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import parse
    from ..transforms.SuperWithoutArgumentsTransformer import SuperWithoutArgumentsTransformer

    tree = parse('super()')

    actual = SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected = parse('super(Cls, self)')

    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-23 23:13:34.267779
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_
    from typed_ast.ast3 import FunctionDef, ClassDef, Name, NameConstant, Expr
    from ..utils.tree import ast_to_str

    tree = ast.parse("super()")


# Generated at 2022-06-23 23:13:35.305338
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:43.790747
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests SuperWithoutArgumentsTransformer."""

    super_without_arguments_transformer = SuperWithoutArgumentsTransformer()

    # Tests on simple super()
    text = """
    class X():
        def __init__(self):
            super()
    """

    tree = ast.parse(text)
    super_without_arguments_transformer.visit(tree)
    assert dumps(tree) == """
    class X():
        def __init__(self):
            super(X, self)
    """

    # Tests on super() with no parent class
    tree = ast.parse('class X():\n    def __init__(self):\n        super()')
    super_without_arguments_transformer.visit(tree)

# Generated at 2022-06-23 23:13:46.074885
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    lhs = ast.parse('super()').body[0]
    rhs = (ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[])),)
    assert SuperWithoutArgumentsTransformer().visit(lhs) == rhs

# Generated at 2022-06-23 23:13:49.057723
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    code_from="""
    class Test(object):
        def get_super(self):
            return super()
    """
    code_to="""
    class Test(object):
        def get_super(self):
            return super(Test, self)
    """
    assert compile(code_from, 'file.py', 2, 7) == code_to

# Generated at 2022-06-23 23:13:52.590190
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    code = 'super()'
    module = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(module)
    expected_code = 'super(__main__.Cls, self)'
    assert expected_code == astor.to_source(module)

# Generated at 2022-06-23 23:13:59.021810
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from compiler import parse
    from ..utils.helpers import get_ast_node, get_func_code
    s = 'super()'
    cls = get_ast_node(s, SuperWithoutArgumentsTransformer, ast.Call)
    code = get_func_code(cls)
    ast = parse(code)
    cls2 = get_ast_node(code, SuperWithoutArgumentsTransformer, ast.Call)
    assert cls == cls2

# Generated at 2022-06-23 23:14:00.247701
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 23:14:00.762644
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:04.750371
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """
        class Foo:
            def foo(self):
                super().foo()
    """

    expected = """
        class Foo:
            def foo(self):
                super(Foo, self).foo()
    """

    module = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(source)
    transformer.visit(module)
    assert ast.dump(module) == expected

# Generated at 2022-06-23 23:14:10.469108
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from typed_ast import ast3 as typed_ast
    import textwrap
    source = textwrap.dedent('''
        class MyClass(object):
            def __init__(self):
                super()
            
            @classmethod
            def __clsinit__(cls):
                super()
    ''')
    tree: typed_ast.AST = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert isinstance(tree.body[0].body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].body[0].value.args[1], ast.Name)
    assert tree.body[0].body[1].value.args[0].id == 'MyClass'
    assert tree.body[0].body

# Generated at 2022-06-23 23:14:20.960050
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import CompileError
    import typing as tp
    from ..transformers import SuperWithoutArgumentsTransformer

    source = """
        class A:
            def __init__(self):
                super().__init__()

        class B:
            def __init__(self):
                super().__str__()
    """

    expected = """
        class A:
            def __init__(self):
                super(A, self).__init__()

        class B:
            def __init__(self):
                super(B, self).__str__()
    """

    node = ast.parse(source)
    SuperWithoutArgumentsTransformer(node).visit(node)
    assert CompileError.compile_node(expected, node=node) == ''



# Generated at 2022-06-23 23:14:25.551834
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    code = "class A:\n  def func(self):\n    super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected = "class A:\n    def func(self):\n        super(A, self)\n\n"
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 23:14:34.605429
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import assert_transformed_ast
    assert_transformed_ast(SuperWithoutArgumentsTransformer,
                           'super()',
                           'super(Cls, self)')

    assert_transformed_ast(SuperWithoutArgumentsTransformer,
                           'class A:\n    def __init__(self):\n        super()',
                           'class A:\n    def __init__(self):\n        super(A, self)')

    assert_transformed_ast(SuperWithoutArgumentsTransformer,
                           'class A:\n    @classmethod\n    def mthd(cls):\n        super()',
                           'class A:\n    @classmethod\n    def mthd(cls):\n        super(A, cls)')

# Generated at 2022-06-23 23:14:37.277169
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer()
    assert isinstance(super_without_arguments_transformer, ast.NodeTransformer)

# Generated at 2022-06-23 23:14:37.869316
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:43.811935
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .. import fixer_util

    tree = ast3.parse('super()')

    class SubSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            super().__init__(tree)
            self._tree_changed = False


    expected_tree = ast3.parse('super(Cls, self)')
    SubSuperWithoutArgumentsTransformer().visit(tree)
    assert fixer_util.compare_ast(tree, expected_tree)

    tree = ast3.parse('super(1)')
    expected_tree = ast3.parse('super(1)')
    SubSuperWithoutArgumentsTransformer().visit(tree)
    assert fixer_util.compare_ast(tree, expected_tree)

# Generated at 2022-06-23 23:14:47.700446
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    before = 'super()'
    after = 'super(Cls, self)'

    node = ast.parse(before)
    node = SuperWithoutArgumentsTransformer(node).visit(node)
    assert astor.to_source(node).strip() == after

# Generated at 2022-06-23 23:14:49.316539
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tester = AssertMyTransformer(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-23 23:14:56.738567
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_func_arg
    from ..utils.tree import get_func_body
    import typed_ast.ast3 as ast3

    def before():
        class A(object):
            def f(self):
                super().__init__()

    # Compile the python code to AST
    module_ast = compile_to_ast(before)
    transformer = SuperWithoutArgumentsTransformer(module_ast)
    transformer.visit(module_ast)
    after = module_ast
    
    assert isinstance(after, ast3.Module)
    assert len(after.body) == 1
    assert isinstance(after.body[0], ast3.ClassDef)
    assert len(after.body[0].body) == 1

# Generated at 2022-06-23 23:15:03.616746
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from typed_ast import ast3 as ast

    source = dedent('''
    class D(object):
        def method(self):
            super()
    ''')

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).run()

    expected = dedent('''
    class D(object):
        def method(self):
            super(D, self)
    ''')

    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 23:15:04.420784
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:04.903970
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:08.824058
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse(
        "super()"
    )
    transformer.visit(tree)
    codeobj = compile(tree, '', 'exec')
    namespace = {}
    exec(codeobj, namespace)
    assert namespace['a'] == 1

# Generated at 2022-06-23 23:15:10.399912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:15:20.374667
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..base import Compiler

    class TestCompiler(Compiler):
        def __init__(self):
            super().__init__(entry_point='test', tree=ast.parse('super()'))

    transformer = SuperWithoutArgumentsTransformer(TestCompiler())

    result = transformer.visit(transformer.tree)
    assert str(result) == 'super(__main__, self)'

    class TestCompiler(Compiler):
        def __init__(self):
            super().__init__(entry_point='test', tree=ast.parse('class A: super()'))

    transformer = SuperWithoutArgumentsTransformer(TestCompiler())

    result = transformer.visit(transformer.tree)
    assert str(result) == 'class A: super(A, cls)'

# Generated at 2022-06-23 23:15:22.704329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer"""
    import astor
    # Build AST

# Generated at 2022-06-23 23:15:25.777023
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def test(code, expected):
        tree = ast.parse(code)
        SuperWithoutArgumentsTransformer().visit(tree)
        assert ast.dump(tree) == ast.dump(ast.parse(expected))

    # Test 0, 1 or more super() args

# Generated at 2022-06-23 23:15:33.347181
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    class SuperWithoutArgumentsTransformerTest(unittest.TestCase):
        def test_superWithoutArgumentsTransformer(self):
            from typed_ast import ast3
            from astunparse import unparse
            from ..utils.validation import validate_ast
            import textwrap
            tree = ast3.parse(textwrap.dedent(
                """class Person:
                    def __init__(self):
                        super()
                    class Student(Person):
                        def __init__(self, name):
                            super()"""))
            validate_ast(tree)
            SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:15:42.407339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SUT(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.Module) -> None:
            super().__init__(tree)
            self._tree_changed = False

        def tree_changed(self) -> bool:
            return self._tree_changed

    # Testing
    code = """
        class foo:
            def __init__(self):
                super()    
            def foo(self):
                super()
        class bar(object):
            def __init__(self):
                pass
    """
    tree = ast.parse(code)
    sut = SUT(tree)
    sut.visit(tree)


# Generated at 2022-06-23 23:15:52.124785
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..scope.scope import Scope
    from ..scope.variable import Variable
    from ..scope.scope_provider import ScopeProvider
    from .transformer import Transformer
    from .syntax_error import SyntaxErrorTransformer

    tree = ast.parse('super()', mode='eval')
    scope = Scope(None, ScopeProvider(tree), [])
    scope.declare_variable(Variable('super', None))
    context = Context()

    transformer = Transformer(
        context=context,
        tree=tree,
        scope=scope,
        transformers=[
            SyntaxErrorTransformer,
            SuperWithoutArgumentsTransformer,
        ],
    )
    transformer.transform()

# Generated at 2022-06-23 23:15:56.385415
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import ast as PythonAst
    from ..converter import to_ast

    code = '''
super().foo
'''

    # Test setup
    mod = PythonAst.parse(code)
    c = to_ast(code)
    SuperWithoutArgumentsTransformer().visit(c)

    # Test
    assert PythonAst.dump(mod) == PythonAst.dump(c)

# Generated at 2022-06-23 23:15:59.087228
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'super()'
    expected_code = 'super(Cls, self)'

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    result = astor.to_source(tree)

    assert result == expected_code

# Generated at 2022-06-23 23:16:09.511409
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import os.path
    import textwrap
    from typed_astunparse import unparse
    from ..utils.tree import tree_from_src

    # TODO: type: ignore
    src = textwrap.dedent('''
        class MyClass:
            def __init__(self):
                super()
            def method(self):
                super()
    ''')

    tree = tree_from_src(src)
    SuperWithoutArgumentsTransformer(tree).run()

    # TODO: assert tree changed

    # TODO: type: ignore
    expected_src = textwrap.dedent('''
        class MyClass:
            def __init__(self):
                super(MyClass, self)
            def method(self):
                super(MyClass, self)
    ''')

# Generated at 2022-06-23 23:16:18.298072
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..tests.utils import get_node_of_type
    from ..utils.tree import print_tree
    from textwrap import dedent
    import sys
    import io

    node = ast.parse(dedent('''
    class Cls:
        def __init__(self):
            super()
            self.super_1 = super()
    '''))
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    SuperWithoutArgumentsTransformer(node).visit(node)
    print_tree(node)


# Generated at 2022-06-23 23:16:26.187193
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import sys
    from .test_transformer import get_tree
    root_node = get_tree(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-23 23:16:27.856755
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:32.834274
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    result = ast.dump(node)
    assert result == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])"

# Generated at 2022-06-23 23:16:35.161436
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_transformer

    transformer = ast_transformer.ASTTransformer()
    transformer.add_transformer(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-23 23:16:42.105973
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    node = ast.parse('super()').body[0]

    t = SuperWithoutArgumentsTransformer()
    t.visit(node)

    assert t._tree_changed
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert isinstance(node.value.args[0], ast.Name)
    assert node.value.args[0].id == 'Cls'
    assert isinstance(node.value.args[1], ast.Name)
    assert node.value.args[1].id == 'self'

# Generated at 2022-06-23 23:16:42.542419
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:52.908422
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    func_node = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.Name(id='self', ctx=ast.Param())],
                                                               defaults=[], vararg=None, kwonlyargs=[],
                                                               kw_defaults=[], kwarg=None),
                                body=[ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))],
                                decorator_list=[], returns=None)
    cls_node = ast.ClassDef(name='Cls', bases=[], keywords=[], body=[func_node], decorator_list=[])
    module_node = ast.Module(body=[cls_node])


# Generated at 2022-06-23 23:17:01.617680
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    transformer = SuperWithoutArgumentsTransformer(tree=None, filename=None)

    new_node = transformer.visit_Call(node)

    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.func, ast.Name)
    assert new_node.func.id == 'super'
    assert isinstance(new_node.args[0], ast.Name)
    assert new_node.args[0].id == 'Cls'
    assert isinstance(new_node.args[1], ast.Name)
    assert new_node.args[1].id == 'self'

# Generated at 2022-06-23 23:17:07.473511
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
            class MyClass:
                def __init__(self):
                    super()
        """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    expected_tree = ast.parse("""
            class MyClass:
                def __init__(self):
                    super(MyClass, self)
        """)
    assert expected_tree == tree

# Generated at 2022-06-23 23:17:08.477350
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:14.274005
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = dedent('''
    class A:
        def a(self):
            super()
    ''')
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    code2 = dedent('''
    class A:
        def a(self):
            super(A, self)
    ''')
    tree2 = ast.parse(code2)
    assert tree == tree2



# Generated at 2022-06-23 23:17:15.180319
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:22.590739
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import parse

    super_without_args = 'super()'

    # Tests for when super() is outside function def
    func_def = f'def f():\n    {super_without_args}\n'
    tree = parse(func_def)
    result = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert hasattr(result.body[0].body[0].value, 'args')
    assert result.body[0].body[0].value.args == []

    # Tests for when super() is inside function def
    cls_def = 'class Cls:\n    def f(self):\n        super()\n'
    tree = parse(cls_def)
    result = SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-23 23:17:27.589340
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class C():\n    def __init__(self):\n        super().foo()'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    expected_code = 'class C():\n    def __init__(self):\n        super(C, self).foo()'
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 23:17:37.780555
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_to_ast

    source1 = '''
    class A(object):
        def __init__(self):
            super()
    '''
    ast1 = compile_to_ast(source1)
    SuperWithoutArgumentsTransformer(2, ast1).visit(ast1)
    assert source_to_unicode(ast1) == '''
    class A(object):
        def __init__(self):
            super(A, self)
    '''

    source2 = '''
    class A(object):
        def __init__(self):
            pass

        def f(self):
            super()
    '''
    ast2 = compile_to_ast(source2)

# Generated at 2022-06-23 23:17:39.216727
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_filter


# Generated at 2022-06-23 23:17:40.134454
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:40.692186
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:17:47.701461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as sta
    from ..decompilation.decompile import decompile_func
    import astunparse
    from typing import Dict, Callable, Union, Optional
    
    match: Dict[Union[str, Callable[[ast.Call, ast.Call], bool]], Optional[Callable[[], None]]] = {
        astunparse.unparse(sta('''
        super()
        ''')).strip(): lambda: None,
    }

    for source, side_effect in match.items():
        ast_tree = sta(source)
        old_tree = ast_tree.body[0]

        visitor = SuperWithoutArgumentsTransformer()
        visitor.visit(ast_tree)

# Generated at 2022-06-23 23:17:58.012123
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ...tree import Module
    from ...codegen.python import to_python


# Generated at 2022-06-23 23:17:59.467576
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:18:00.615146
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:08.916177
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from ..parser.parser import parse
    from ..compiler.visitor import NodeTransformerSequence

    tree = parse(dedent('''\
        class A:
            def __new__(cls):
                super()
        '''))

    compiler = NodeTransformerSequence(
        [SuperWithoutArgumentsTransformer],
        [2, 7]
    )
    compiler.visit(tree)

    assert compile(tree, '', 'exec') == dedent('''\
        class A:
            def __new__(cls):
                super(A, cls)
        ''')

# Generated at 2022-06-23 23:18:15.642516
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.fake import _ASTNode, _ASTNodeNoLine
    sut = SuperWithoutArgumentsTransformer()
    tree = ast.Module()
    sut.visit(tree)
    assert tree == ast.Module()
    #
    tree = ast.Module(body=[
        ast.FunctionDef(
            name='f',
            args=ast.arguments(),
            body=[
                ast.Call(
                    func=ast.Name(id='super')
                ),
                ast.Break(),
            ],
            decorator_list=[],
        )
    ])
    sut.visit(tree)

# Generated at 2022-06-23 23:18:19.041728
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import setup_fixtures
    module, output = setup_fixtures(__file__)

    t = SuperWithoutArgumentsTransformer(None, module)
    t._tree = ast.parse(output)
    t.visit(t._tree)

    assert output == compile(t._tree, '', 'exec')

# Generated at 2022-06-23 23:18:29.838107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class MyClass:
        def __init__(self):
            self.a = 1
            self.b = 2

        def get_a(self):
            return self.a

    cls_node = ast.parse(inspect.getsource(MyClass))
    method_node = cls_node.body[1]
    assert method_node.body[0] == ast.Expr(ast.Call(ast.Name('super', ast.Load()), [], [], None, None))

    transformer = SuperWithoutArgumentsTransformer(cls_node)
    transformer.visit(cls_node)
    assert transformer.tree_changed

# Generated at 2022-06-23 23:18:32.586574
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("""class A:
        def __init__(self):
            super()
        """)
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-23 23:18:38.541458
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor.code_gen import to_source
    x = ast.parse('''class A:
    def b(self):
        print(self)
        super()
    def __init__(self):
        super().__init__()
''')
    expected = '''class A:
    def b(self):
        print(self)
        super(A, self)
    def __init__(self):
        super(A, self).__init__()
'''

    tree = SuperWithoutArgumentsTransformer().visit(x)
    assert expected == to_source(tree)

# Generated at 2022-06-23 23:18:43.610114
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Data:
        pass
    data = Data()
    data.tree = ast.parse("super()")
    data.transformed_tree = ast.parse("super(Cls, self)")
    SuperWithoutArgumentsTransformer(data.tree).generic_visit(data.tree)
    assert ast.dump(data.tree) == ast.dump(data.transformed_tree)


# Generated at 2022-06-23 23:18:52.279011
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    source = ast.parse('''class C(B):
    def f(self):
        super()
    @classmethod
    def g(cls):
        super()''')

    transformer = SuperWithoutArgumentsTransformer(source)
    transformer.visit(source)
    
    expected = ast.parse('''class C(B):
    def f(self):
        super(C, self)
    @classmethod
    def g(cls):
        super(C, cls)''')
    assert ast.dump(source) == ast.dump(expected), f"\n{ast.dump(source)}"

# Generated at 2022-06-23 23:18:56.309304
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
            class A:
                def __init__(self):
                    super()
            a = A()
        """)

    tr = SuperWithoutArgumentsTransformer(tree=tree)
    tr.visit(tree)
    assert 'super(A, self)' in unparse(tree)



# Generated at 2022-06-23 23:19:02.231321
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import assert_in, assert_not_in
    from ..utils.testing import fix, transform_src

    src = """
    class A:
        def __init__(self):
            super().__init__()
    """

    expected = """
    class A:
        def __init__(self):
            super(A, self).__init__()
    """

    assert_in(SuperWithoutArgumentsTransformer, transform_src(fix(src), src))
    assert_not_in(SuperWithoutArgumentsTransformer, transform_src(fix(expected), expected))



# Generated at 2022-06-23 23:19:07.337982
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transforms.SuperWithoutArgumentsTransformer import SuperWithoutArgumentsTransformer
    from ..utils.tree import get_call_name
    code = 'super()'
    tree = ast.parse(code)
    # replace the identifier of the call super with the class name
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(tree)
    assert get_call_name(tree.body[0].value) is None
    assert trans._tree_changed is True

# Generated at 2022-06-23 23:19:13.781818
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from py2to3.tests.test_transformer import transform
    from py2to3.tests.test_transformer import check

    code = """
        class C(object):
            def __init__(self):
                super()
                """
    
    check(transform(SuperWithoutArgumentsTransformer, code), """
        class C(object):
            def __init__(self, *args, **kwargs):
                super(C, self, *args, **kwargs)
                """)



# Generated at 2022-06-23 23:19:20.511520
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with open('./test/compiler/fixtures/super-without-arguments.py') as f:
        tree = ast.parse(f.read())

    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed

    with open('./test/compiler/expected/super-without-arguments.py', 'r') as f:
        expected_file_contents = f.read()

    expected_tree = ast.parse(expected_file_contents)
    assert ast.dump(new_tree, True) == ast.dump(expected_tree, True)

# Generated at 2022-06-23 23:19:21.479096
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Constructor of class SuperWithoutArgumentsTransformer is tested in test_BaseNodeTransformer
    pass



# Generated at 2022-06-23 23:19:27.179552
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.ast_maker import c_ast

    test_tree = c_ast.parse('''
    class Foo:
        def __init__(self):
            super().__init__()
    ''')
    transformed_tree = SuperWithoutArgumentsTransformer().visit(test_tree)

    expected_tree = c_ast.parse('''
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()
    ''')

    assert ast.dump(transformed_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:19:34.265290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class Test:
        def test(self):
            super()
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    fixed_code = compile(new_tree, "<string>", "exec")

    expected_code = '''class Test:
        def test(self):
            super(Test, self)
    '''

    assert fixed_code == compile(expected_code, "<string>", "exec")

# Generated at 2022-06-23 23:19:38.235779
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    t = SuperWithoutArgumentsTransformer()
    r = t.visit(tree)

    # build expected result
    expected = ast.parse('super(Cls, self)')

    assert ast.dump(r) == ast.dump(expected)

# Generated at 2022-06-23 23:19:41.252643
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from python_modernize.transformer import SuperWithoutArgumentsTransformer
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(node)
    assert astor.to_source(transformer.visit(node)) == "super(Cls, self)"

# Generated at 2022-06-23 23:19:47.141366
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""
    code = 'class A: def a(self): super()'
    tree = ast.parse(code)
    node = tree.body[0]
    new_node = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(new_node, ast.ClassDef)

# Generated at 2022-06-23 23:19:53.317487
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = ast.parse('''
    class A:
        def __init__(self):
            super()
    ''')
    node = t.body[0].body[0].body[0]
    tree_changed = False
    SuperWithoutArgumentsTransformer(t, tree_changed=tree_changed).visit(node)
    assert ast.dump(node) == 'super(A, self)'



# Generated at 2022-06-23 23:20:01.056331
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import load_fixture
    from ..visitor import AstroidVisitor
    from ..utils.ast_to_str import ast_to_str
    from .utils import transform_and_compare

    expected = load_fixture('_SuperWithoutArgumentsTransformer', 'target_visit_Call.py').read()

    source = load_fixture('_SuperWithoutArgumentsTransformer', 'source_visit_Call.py').read()
    tree = AstroidVisitor.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert ast_to_str(tree) == expected

# Generated at 2022-06-23 23:20:11.515197
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u
    from .string_to_ast import compile_ast as c

    code = u('''
            class Foo(object):
                def bar(self):
                    super()
            ''')
    tree = c(code)

    node: ast.Call = list(tree.body[0].body[0].body)[0]
    args = node.args

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert isinstance(args[0], ast.Name)
    assert args[0].id == 'Foo'
    assert isinstance(args[1], ast.Name)
    assert args[1].id == 'self'

# Generated at 2022-06-23 23:20:19.984116
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that it compiles super() to super(Cls, self)"""
    t = SuperWithoutArgumentsTransformer.__new__(SuperWithoutArgumentsTransformer)
    source = '''
                class Cls:
                    def fun(self):
                        super()
                '''
    tree = ast.parse(source)
    t.visit(tree)
    # removing the leading and trailing whitespaces. 
    assert astor.to_source(tree).replace(' ', '').strip() ==\
        '''classCls:deffun(self):super(Cls,self)'''