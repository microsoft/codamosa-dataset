

# Generated at 2022-06-23 23:10:20.509102
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from conftest import expect_func_changes



# Generated at 2022-06-23 23:10:28.950960
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    class TestNodeTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.AST) -> None:
            self._tree = tree
            self._tree_changed = False
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    func = ast.parse('def f():\n    super()\nclass A:\n    pass\n    ').body[0]
    transformer = TestNodeTransformer(func)
    transformer.visit(func)
    assert transformer._tree_changed == True

# Generated at 2022-06-23 23:10:33.244763
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module = ast.parse('super()')
    node = module.body[0]
    tree = SuperWithoutArgumentsTransformer().visit(module)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Call)


# Generated at 2022-06-23 23:10:38.297203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    import inspect
    from ..utils import get_default_args
    default_args = get_default_args(inspect.getfullargspec(SuperWithoutArgumentsTransformer)) # type: ignore
    print (default_args)

# Generated at 2022-06-23 23:10:41.341612
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """super()"""
    expected = """\
super(Cls, self)"""
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected


# Generated at 2022-06-23 23:10:46.549690
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    node = ast.parse('''class A(metaclass=type):
            def foo(self):
                super().bar()
    ''')
    SuperWithoutArgumentsTransformer().visit(node)
    node = ast.fix_missing_locations(node)
    compiled = compile(node, '', 'exec')
    # must raise: TypeError: super() takes at least 1 argument (0 given)
    try:
        exec(compiled)
    except TypeError:
        pass

# Generated at 2022-06-23 23:10:57.295203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source1 = \
    """
    class MyClass(object):
        def my_func(self):
            super()
    """

    source2 = \
    """
    class MyClass(object):
        def my_func(self):
            super(MyClass, self)
    """

    source3 = \
    """
    class MyClass(object):
        def my_func(self):
            super()
            super(MyClass, self)
    """

    source4 = \
    """
    class MyClass(object):
        def my_func(self):
            super()
            super(MyClass, self)
            super(MyClass, self)
            super(MyClass, self)
    """
    
    tree = ast.parse(source1)
    SuperWithoutArgumentsTransformer(tree).run()


# Generated at 2022-06-23 23:10:58.263589
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:59.204140
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:06.883132
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import should_transform
    source = '''
        class Cls:
            def method(self):
                super()
    '''
    expected = '''
        class Cls:
            def method(self):
                super(Cls, self)
    '''
    should_transform(SuperWithoutArgumentsTransformer, source, expected)

    source = '''
        class Cls:
            @classmethod
            def method(cls):
                super()
    '''
    expected = '''
        class Cls:
            @classmethod
            def method(cls):
                super(Cls, cls)
    '''
    should_transform(SuperWithoutArgumentsTransformer, source, expected)


# Generated at 2022-06-23 23:11:10.486559
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_string, fixer_log
    from ..utils import test_fixtures

    for fixture in test_fixtures.SUPER_WITHOUT_ARGUMENTS:
        fixer_log.clear()
        compile_string(fixture, transformers=[SuperWithoutArgumentsTransformer])
        assert not fixer_log.warnings
    return True

# Generated at 2022-06-23 23:11:12.657144
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:22.130152
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Arrange
    from typed_ast import ast3 as ast
    transformer = SuperWithoutArgumentsTransformer(tree=ast.parse('super()'))

    # Act
    node = transformer.visit(transformer._tree)

    # Assert
    assert isinstance(node, ast.FunctionDef)
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.func, ast.Name)
    assert node.body[0].value.func.id == 'super'
    assert isinstance(node.body[0].value.args[0], ast.Name)
    assert node.body[0].value.args[0].id == 'Cls'

# Generated at 2022-06-23 23:11:32.980558
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:39.414029
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Note:
    #   It's not possible to test `self._replace_super_args` because of `get_closest_parent_of`.
    #   This method is tested in test_tree.py.
    s = 'super()'
    tree = ast.parse(s)
    t = SuperWithoutArgumentsTransformer(tree)
    t.visit(tree)
    assert t._tree_changed
    assert str(tree) == "super(Cls, self)"

# Generated at 2022-06-23 23:11:41.013153
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing_utils import assertTypedEqual
    from .. import transforms


# Generated at 2022-06-23 23:11:46.028098
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Node to transform
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[])

    # The transformer
    transformer = SuperWithoutArgumentsTransformer('')

    # Transform the node
    node = transformer.visit(node)

    # Check results
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:11:55.464392
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "super()"
    class_name = "Example"
    func_name = "func"
    expected_results = "super(Example, func)"
    class ExampleClass(object):
        def func(self):
            return super()

    tree = ast_parse(code)
    code_transformer = SuperWithoutArgumentsTransformer(tree, {})
    code_transformer.visit(tree)
    actual_code = compile(tree, "<string>", "exec")
    exec(actual_code)
    assert actual_code.co_consts[1] == ast_parse(expected_results).body[0].value
    assert ExampleClass.func(ExampleClass()) == ast_parse(expected_results).body[0].value

# Generated at 2022-06-23 23:12:03.823572
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    from textwrap import dedent
    from typed_ast.ast3 import parse

    code = dedent("""
        class A:
            def b(self):
                assert isinstance(super(), A)
    """)

    tree = parse(code)
    super_ = tree.body[0].body[0].body[0].test.args[0].func

    # When
    SuperWithoutArgumentsTransformer(tree).visit(super_)

    # Then
    assert str(super_) == 'super(A, self)'



# Generated at 2022-06-23 23:12:11.701692
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from pathlib import Path
    from .test_fixtures import fixture_to_test_module
    from typed_astunparse import unparse

    test_path = Path(__file__).parent / "test_fixtures"
    for fixture_path in (test_path / "test_SuperWithoutArgumentsTransformer_visit_Call").glob("*"):
        tree = fixture_to_test_module(fixture_path)
        SuperWithoutArgumentsTransformer(tree).visit(tree)
        print(unparse(tree))
        print("*" * 40)

# Generated at 2022-06-23 23:12:20.368452
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super().__init__()
    """
    tree = ast.parse(code)
    trans = SuperWithoutArgumentsTransformer()
    tree = trans.visit(tree)

    assert isinstance(tree.body[0], ast.ClassDef)
    cdef = tree.body[0]
    assert isinstance(cdef.body[0], ast.FunctionDef)
    fdef = cdef.body[0]
    assert isinstance(fdef.body[0], ast.Expr)
    expr = fdef.body[0].value
    assert isinstance(expr, ast.Call)
    call = expr
    assert isinstance(call.func, ast.Name)
    assert call.func.id == 'super'

# Generated at 2022-06-23 23:12:27.341694
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class MyClass:
            def __init__(self):
                super()
        """

    expected_code = """
        class MyClass:
            def __init__(self):
                super(MyClass, self)
        """

    module = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.run()
    actual_code = compile(module, '', 'exec')

    assert actual_code.strip() == dedent(expected_code).strip()



# Generated at 2022-06-23 23:12:28.863741
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .analyzer import Analyzer
    from .unparser import Unparser

# Generated at 2022-06-23 23:12:31.010058
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source
    from ..utils.helpers import ast_from_code

# Generated at 2022-06-23 23:12:33.490446
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u
    from .. import transform
    from types import ModuleType
    m = ModuleType('<test>')

# Generated at 2022-06-23 23:12:44.022457
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from ..utils.source import source_to_unicode
    from .. import compile_restricted
    import sys

    tree = pyast.parse("""
        class A(object):
            def a(self):
                super()
                pass
    """)
    node = pyast.Call(
        func=pyast.Name(id='super'),
        args=[], keywords=[]
    )
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    assert new_node == pyast.Call(
        func=pyast.Name(id='super'),
        args=[pyast.Name(id='A'), pyast.Name(id='self')], keywords=[]
    )


# Generated at 2022-06-23 23:12:49.458028
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    source = """
    class Foo:
        def __init__(self):
            super()
    
    """
    expected = """
    class Foo:
        def __init__(self):
            super(Foo, self)
    
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).visit()
    transformed_source = astor.to_source(tree)
    assert expected == transformed_source

# Generated at 2022-06-23 23:12:53.204658
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    import astor
    from typing import Callable

    # test_simple: tests the transformer with simple input
    def test_simple() -> None:
        transformer = SuperWithoutArgumentsTransformer(None)

# Generated at 2022-06-23 23:13:04.405941
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .tools import check_on_input


# Generated at 2022-06-23 23:13:05.424726
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    

# Generated at 2022-06-23 23:13:10.568535
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .unpacking import *
    from .metaclass import *
    from .with_statement import *
    from .decorators import *
    from .future import *
    from .idioms import *
    from .util import *

# Generated at 2022-06-23 23:13:11.237152
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:13:14.598285
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert 'super(Cls, self)' in astor.to_source(tree)

# Generated at 2022-06-23 23:13:15.735464
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass



# Generated at 2022-06-23 23:13:16.840088
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


# Generated at 2022-06-23 23:13:17.915373
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:20.186930
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source

# Generated at 2022-06-23 23:13:21.070746
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:31.397023
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    cls_name = 'Cls'

    source, result = SuperWithoutArgumentsTransformer.test_from_files(
        SuperWithoutArgumentsTransformer,
        'test_SuperWithoutArgumentsTransformer_visit_Call',
        '''
        class Cls(object):
            def __init__(self):
                super().__init__()
            def test(self):
                super().test()
        ''',
        '''
        class Cls(object):
            def __init__(self):
                super(Cls, self).__init__()
            def test(self):
                super(Cls, self).test()
        '''
    )  # type: ast.Module

    assert type(result.body[0]) is ast.ClassDef
    assert result.body[0].name == cls_name



# Generated at 2022-06-23 23:13:40.541158
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import transform, compare_source

    source = '''
        class A:
            def __init__(self):
                super()

        class B:
            def __init__(self, cls):
                super()
       
        class C:
            def __init__(self, cls):
                def foo():
                    super()
    '''

    expected = '''
        class A:
            def __init__(self):
                super(A, self)

        class B:
            def __init__(self, cls):
                super(B, cls)
       
        class C:
            def __init__(self, cls):
                def foo():
                    super(C, cls)
    '''


# Generated at 2022-06-23 23:13:47.769950
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node_1 = ast.Call()
    node_1.func = ast.Name()
    node_1.args = []
    node_1.func.id = 'super'

    node_2 = ast.Call()
    node_2.func = ast.Name()
    node_2.args = [ast.Lambda()]

    node_3 = ast.FunctionDef()
    node_3.args = ast.arguments()
    node_3.args.args = []
    node_3.args.vararg = None
    node_3.args.kwonlyargs = []
    node_3.args.kw_defaults = []
    node_3.args.kwarg = None

    node_4 = ast.ClassDef()

# Generated at 2022-06-23 23:13:58.215822
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    def test_func(self):
        super()
        super(B, self)
    
    class A:
        def test_func(self):
            super()
            super(A, self)

    class B(A):
        def test_func(self):
            super()
            super(B, self)
            super(A, self)
    """
    tree = ast.parse('def test_func(self):\n    super()\n    super(B, self)\n\nclass A:\n    def test_func(self):\n        super()\n        super(A, self)\n\nclass B(A):\n    def test_func(self):\n        super()\n        super(B, self)\n        super(A, self)')  # noqa
    transformer = SuperWithout

# Generated at 2022-06-23 23:13:58.764313
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:00.017241
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:14:07.156594
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_BaseNodeTransformer import BaseNodeTransformer_basic_test_helper

    class TestTransformer(SuperWithoutArgumentsTransformer):
        pass

    def do_test(test_name: str, before: ast.AST, expected: ast.AST) -> None:
        BaseNodeTransformer_basic_test_helper(TestTransformer, test_name, before, expected)

    # noinspection PyTypeChecker
    do_test('super_inside_class_with_args',
            ast.parse('super(args)').body[0],
            ast.parse('super(args)').body[0],
            )

    # noinspection PyTypeChecker

# Generated at 2022-06-23 23:14:13.299623
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast as python_ast

    from typed_ast import ast3 as typed_ast

    from typed_ast.ast3 import ClassDef, FunctionDef, Name
    from typed_ast.ast3 import Assign, Load, Store, Call, arguments
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import arg
    from ..utils.fed import Fed
    from ..utils.helpers import module


# Generated at 2022-06-23 23:14:14.081173
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:14:21.410826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast27

    src = """
    class A():
        def __init__(self):
            super() 
        def f(self):
            super()
    """
    mod = ast27.parse(src)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(mod)
    assert mod.body[0].body[0].value.args[1].id == 'self'
    assert mod.body[0].body[1].body[0].value.args[1].id == 'self'


# Generated at 2022-06-23 23:14:27.194137
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Simple test to check if the super call has been transformed correctly
    transformer = SuperWithoutArgumentsTransformer()
    src = """
        class A:
            def f(self):
                super()
    """
    tree = ast.parse(src)
    transformer.visit(tree)
    assert transformer.tree_changed
    gen = ast.get_source_segment(tree)
    src_after = "".join(gen)

    assert src != src_after
    assert 'super(A, self)' in src_after

# Generated at 2022-06-23 23:14:28.256380
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 23:14:31.816194
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = "super()"
    expected = "super(cls, self)"

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    ast.fix_missing_locations(tree)

    assert astor.to_source(tree).strip() == expected

# Generated at 2022-06-23 23:14:35.438103
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.fake_ast import fake_ast, ast_to_source
    from ..fixers.remove_all_compare import RemoveAllCompareTransformer

# Generated at 2022-06-23 23:14:43.409034
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    # super should be replaced
    assert isinstance(new_tree.body[0].value, ast.Call)
    assert new_tree.body[0].value.func.id == 'super'
    assert len(new_tree.body[0].value.args) == 2
    assert isinstance(new_tree.body[0].value.args[0], ast.Name)
    assert isinstance(new_tree.body[0].value.args[1], ast.Name)

# Generated at 2022-06-23 23:14:45.317389
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.fakeparser import SimpleASTBuilder
    builder = SimpleASTBuilder()

# Generated at 2022-06-23 23:14:52.408793
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from python_modernize.fixes.super_without_arguments import SuperWithoutArgumentsTransformer

    code = """
    class A(object):
        def __init__(self):
            super()
        def foo(cls):
            super()
    class B(A):
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    fixed_code = astor.to_source(tree).strip()

# Generated at 2022-06-23 23:14:54.299245
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    from ..common import Filename
    from ..utils.helpers import normalize_code


# Generated at 2022-06-23 23:14:55.816022
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:05.520339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    # class MySuper:
    #     def __init__(self):
    #         return super()
    # class MySub(MySuper):
    #     def __init__(self):
    #         return super()
    tree = ast.parse('''
        class MySuper:
            def __init__(self):
                return super()
        class MySub(MySuper):
            def __init__(self):
                return super()''')
    transformer.visit(tree)
    exec(compile(tree, filename="", mode="exec"), globals())

# Generated at 2022-06-23 23:15:06.359833
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:16.903903
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    
    class Point:
       def __init__( self, x=0, y=0):
          self.x = x
          self.y = y
       def __str__(self):
          return "{0},{1}".format(self.x,self.y)
    
    class Point3D(Point):
       def __init__(self, x = 0, y = 0, z = 0):
        super().__init__(x, y)
        self.z = z
       def __str__(self):
          return "{0},{1},{2}".format(self.x, self.y,self.z)
    
    my_point = Point3D(1, 2, 3)
    print(my_point)
    """

    tree = ast.parse(code)
   

# Generated at 2022-06-23 23:15:23.953666
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Visit should return correct number of node in input tree.
    """
    source = '''class A:
    def a(self):
        super()
    def b(cls):
        super()'''
    expected = '''class A:
    def a(self):
        super(A, self)
    def b(cls):
        super(A, cls)'''
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-23 23:15:24.405050
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:25.664382
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse

    node = parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    assert new_node.body[0].value.value.args[0].id == 'Cls'

# Generated at 2022-06-23 23:15:33.129634
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .fake import FunctionDef, ClassDef, Name, Load, Call, Assign, AssignName, AssignAttr, Arguments, arg, Attribute, NameConstant, ListComp, comprehension


# Generated at 2022-06-23 23:15:37.531583
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # This code should compile fine
    exec('''if True:
        class A:
            foo = super(A).__init__
            bar = super(A)

        class B(A):
            def __init__(self):
                super().__init__()
        ''', globals(), locals())

# Generated at 2022-06-23 23:15:40.847632
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..transpile_test_case import TranspileTestCase
    from ..utils.helpers import ast_from_code
    from .example_visitor import ExampleVisitor


# Generated at 2022-06-23 23:15:46.851710
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    transformer = SuperWithoutArgumentsTransformer(True, ast.parse('def m1(): pass\nclass A:\n    def m2():\n        super()\n'))
    node = transformer.visit(node)
    assert astor.to_source(node) == "super(A, m2)"

# Generated at 2022-06-23 23:15:48.710319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that the SuperWithoutArgumentsTransformer class can be instantiated."""
    assert SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:15:49.483034
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import run_transformer

# Generated at 2022-06-23 23:15:50.406711
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:53.020710
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code_equals
    assert_transformed_code_equals(__file__, 'test_SuperWithoutArgumentsTransformer_visit_Call')

# Generated at 2022-06-23 23:15:59.829802
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import parse
    
    tree = parse('super()')
    tree.compile_class = True
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='<module>', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='cls', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

# Generated at 2022-06-23 23:16:00.856503
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:01.861926
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:09.235303
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from src.transformer import Transformer
    from ..utils.helpers import generate_src

    class Cls:
        def __init__(self):
            pass

        def __str__(self):
            return "str"

    tree = ast.parse(generate_src(SuperWithoutArgumentsTransformer.__module__, Cls))
    t = Transformer(tree, SuperWithoutArgumentsTransformer)
    t.apply()

    assert t.src == generate_src(SuperWithoutArgumentsTransformer.__module__, Cls, SuperWithoutArgumentsTransformer.target)

# Generated at 2022-06-23 23:16:18.079946
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    from ..testing.utils import build_annotation, build_call, build_funcdef, build_classdef

    class Test(unittest.TestCase):
        def test(self):
            tree = build_funcdef(
                args=build_annotation(
                    arg='self',
                    annotation='Cls'
                ),
                body=[
                    build_call(
                        func='super'
                    )
                ]
            )
            tree = build_classdef(
                name='Cls',
                body=[tree]
            )
            
            transformer = SuperWithoutArgumentsTransformer(tree)
            transformer.run()

# Generated at 2022-06-23 23:16:25.977793
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as py_ast
    import textwrap
    from ..utils.ast_helper import ast_source

    code = textwrap.dedent('''
        class Cls:
            def method(self):
                super()
    ''')
    tree = py_ast.parse(code)
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)

    def _node_found(node: py_ast.AST) -> bool:
        return isinstance(node, py_ast.Call) and len(node.args) == 2

    node_list = transformer.visit(node)
    node = next(filter(_node_found, node_list.body[0].body[0].body), None)
    assert isinstance(node, py_ast.Call)

# Generated at 2022-06-23 23:16:27.982870
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(2, 7)

# Generated at 2022-06-23 23:16:30.331184
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import ast
    import typed_ast.ast3 as typed_ast


# Generated at 2022-06-23 23:16:33.197804
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert 'super(cls, self)' == to_source(tree)

# Generated at 2022-06-23 23:16:34.354552
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import compile_func
    

# Generated at 2022-06-23 23:16:35.372675
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code


# Generated at 2022-06-23 23:16:36.176669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:16:44.395726
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing import assert_code_equal
    from ..testing import assert_transformed_ast_equal
    from ..testing import transform

    code = """
        class D:
            def m(self):
                return super()
    """
    ast_ = ast.parse(code)
    result = transform(ast_.body[0].body[0].body[0], SuperWithoutArgumentsTransformer)
    assert_transformed_ast_equal(result, code, '''
        class D:
            def m(self):
                return super(D, self)
    ''')

# Generated at 2022-06-23 23:16:54.371380
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_transformer_on_single_file
    from ..utils import get_ast_node
    rt = run_transformer_on_single_file
    gn = get_ast_node

    src = """
        class Cls:
            def __init__(self):
                super()
                super()
    """
    root = gn(rt(src, SuperWithoutArgumentsTransformer), ast.Module)

    cls = root.body[0]
    assert isinstance(cls, ast.ClassDef)
    assert cls.name == 'Cls'

    func = cls.body[0]
    assert isinstance(func, ast.FunctionDef)
    assert func.name == '__init__'

    call1, call2 = func.body

# Generated at 2022-06-23 23:16:55.241560
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:59.114193
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import round_trip
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    ret = transformer.visit(tree)
    assert round_trip(ret) == 'super(__main__, self)\n'
    assert transformer._tree_changed == True

# Generated at 2022-06-23 23:17:04.502354
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast 
    from ..utils import get_node
    from ..utils.helpers import get_code
    from .base import BaseNodeTransformer
    from .simple import SimpleNodeTransformer

    class Dummy(BaseNodeTransformer):
        def generic_visit(self, node):
            return node


# Generated at 2022-06-23 23:17:05.544157
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:15.784815
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super() outside of function
    code = 'super()'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '', mode='exec')

    # super() outside of class
    code = '''
        def method():
            super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '', mode='exec')

    # super() with arguments
    code = '''
        def method(foo):
            super(foo, bar)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert compile(tree, '', mode='exec')

    # Success

# Generated at 2022-06-23 23:17:16.271415
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:17:19.089788
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from . import deparse_to_string
    from .base import NodeTestCase


# Generated at 2022-06-23 23:17:20.615517
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import TestCaseAST

    cls = TestCaseAST()


# Generated at 2022-06-23 23:17:23.607163
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer(tree, "super()").run()
    expected = ast.parse("super(C, self)")
    assert ast.dump(tree, False) == ast.dump(expected, False)

# Generated at 2022-06-23 23:17:28.562580
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def meth(self):
            print(super())
    '''

    tree = ast.parse(dedent(code))
    SuperWithoutArgumentsTransformer().visit(tree)
    code = astor.to_source(tree)

    assert code == '''
    class A:
        def meth(self):
            print(super(A, self))
    '''

# Generated at 2022-06-23 23:17:38.842079
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    for python_version in range(2, 8):
        tree = ast.parse('super()')
        SuperWithoutArgumentsTransformer(tree, python_version=python_version).visit(tree)
        assert isinstance(tree.body[0], ast.Expr)
        assert isinstance(tree.body[0].value, ast.Call)
        assert isinstance(tree.body[0].value.func, ast.Name)
        assert tree.body[0].value.func.id == 'super'
        if python_version == 2:
            assert isinstance(tree.body[0].value.args[0], ast.Name)
            assert tree.body[0].value.args[0].id == 'C'
            assert isinstance(tree.body[0].value.args[1], ast.Name)
            assert tree.body

# Generated at 2022-06-23 23:17:41.157911
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transpile import transpile_code
    from ..transpile.tree import Module
    

# Generated at 2022-06-23 23:17:44.224376
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_ast = ast.parse('class C: def __init__(self): super()')
    transformer = SuperWithoutArgumentsTransformer(module_ast)
    module_ast_new = transformer.visit(module_ast)

    assert_source_code(module_ast_new, 'class C: def __init__(self): super(C, self)')

# Generated at 2022-06-23 23:17:52.062004
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(tree=None)
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)
    node.func.ctx = ast.Load()
    node.args = []
    node.keywords = []
    node.starargs = None
    node.kwargs = None

    with pytest.raises(NodeNotFound):
        transformer._replace_super_args(node)

    transformer._replace_super_args = lambda node: None
    assert transformer.visit_Call(node) == node

# Generated at 2022-06-23 23:18:02.128355
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import save_and_run_unevaluated_ast
    import unittest
    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_node_found(self):
            tree = ast.parse("""
            class A:
                def test(self):
                    super()
            """)
            tree = SuperWithoutArgumentsTransformer().visit(tree)
            self.assertEqual(save_and_run_unevaluated_ast(tree), 'test')

        def test_node_not_found(self):
            tree = ast.parse("""
            class A:
                def test(self):
                    pass
            """)
            tree = SuperWithoutArgumentsTransformer().visit(tree)
            self.assertEqual

# Generated at 2022-06-23 23:18:03.091188
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:07.578622
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().run(tree)

    assert 'super(A, self)' in astunparse.unparse(tree)



# Generated at 2022-06-23 23:18:11.608293
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast.Call) -> None:
            node.args = [ast.Num(n=1)]


# Generated at 2022-06-23 23:18:13.423898
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:16.200062
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from tests.fixtures.super_no_args import before, after

    transformer = SuperWithoutArgumentsTransformer({'2': before})
    transformer.visit(transformer._tree)

    assert ast.dump(transformer._tree['2']) == ast.dump(after)

# Generated at 2022-06-23 23:18:19.450462
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astmonkey import transformers
    module_node = ast.parse('class Test(): def Test(self): super()')
    transformer = transformers.SuperWithoutArgumentsTransformer()
    result = transformer.visit(module_node)
    assert result.body[0].body[0].value.args[0].id == 'Test'
    assert result.body[0].body[0].value.args[1].id == 'self'



# Generated at 2022-06-23 23:18:30.293276
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import pretty_format
    from ..utils.ast_compare import are_asts_equal
    from .super_without_arguments_transformer import SuperWithoutArgumentsTransformer
    from ..fixtures import super_without_arguments  # noqa: F401

    expected_output = """
    class A(object):

        def x(self):
            super(A, self).__init__()

        def y(cls):
            super(A, cls).__init__()

        def z(self):
            super(A, self)

        def zz(cls):
            super(A, cls)

    class B(object):

        def __init__(self):
            super(B, self).__init__()
    """

    input

# Generated at 2022-06-23 23:18:31.966647
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_func_args
    t = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:18:39.602917
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse("""
        class A(object):
            def __init__(self):
                super()
    
        class B(A):
            def __init__(self):
                super()
    
        class C(A):
            def __init__(self):
                super()
    """)
    transformer.visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

# Generated at 2022-06-23 23:18:40.595366
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:45.253339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
    class A(object):
        def __init__(self):
            super()
        def __new__(self):
            super()
    """)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0].body[0].body[0], ast.Call)

# Generated at 2022-06-23 23:18:51.304613
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    t = ast.parse("""
        class C(object):
            def method(self):
                super()
    """)
    expected = ast.parse("""
        class C(object):
            def method(self):
                super(C, self)
    """)

    # Exercise
    uut = SuperWithoutArgumentsTransformer()
    res = uut.visit(t)

    # Verify
    assert res == expected

# Generated at 2022-06-23 23:18:57.787955
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class C(object):
        def m(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert(len(tree.body[0].body[0].body[0].args.args) == 2)
    assert(tree.body[0].body[0].body[0].args.args[0].id == 'C')
    assert(tree.body[0].body[0].body[0].args.args[1].id == 'self')


# Generated at 2022-06-23 23:19:06.066424
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List
    from typed_ast import ast3 as ast

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return super().visit_Call(node)
        def visit_Name(self, node: ast.Name) -> List[ast.AST]:
            return []

    test_node1 = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
    )
    test_node2 = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[ast.Name(id='self', ctx=ast.Load())],
        keywords=[],
    )

    test_

# Generated at 2022-06-23 23:19:08.480182
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..processor import Processor
    from .lexical import ClassAndFunctionTransformer


# Generated at 2022-06-23 23:19:11.528245
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    s = "super()"
    out = """super(Cls, self)"""
    tree = ast.parse(s)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astunparse(tree).strip() == out

# Generated at 2022-06-23 23:19:17.617247
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class A:\n    def a(self):\n        super()'
    tree = ast.parse(code)
    # replaced tree
    expected_tree = ast.parse('class A:\n    def a(self):\n        super(A, self)')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    
    assert transformer._tree_changed == True
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:19:19.503990
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    """
    import typed_ast.ast3
    import astor
    from io import StringIO

# Generated at 2022-06-23 23:19:26.058742
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    class Node:
        def __init__(self):
            self.parent = self
            self.args = Node()
            self.args.args = []

    func = Node()
    func.args.args = [Node()]
    func.args.args[0].arg = 'self'

    cls = Node()
    cls.name = 'Cls'

    node = Node()
    node.args = []
    node.func = Node()

    tree = Node()
    tree.parent = None

    transformer = SuperWithoutArgumentsTransformer(None)

    transformer.visit_Call(node)
    assert node.args == []

    node.parent = func
    node.func.id = 'super'
    transformer.visit_Call(node)
    assert node.args == []

    node.parent = cls

# Generated at 2022-06-23 23:19:26.956154
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:37.249943
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.symbol_table import SymbolTable

    class MockSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        """Mock class for class SuperWithoutArgumentsTransformer"""

        def __init__(self, tree: ast.AST, symbol_table: SymbolTable):
            self._tree = tree
            self.symbol_table = symbol_table
            self._tree_changed = False

        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

        def get_tree(self) -> ast.AST:
            return self._tree

    class MockAST:
        """Mock class for class ast"""

        def __init__(self, name: str, args: ast.arguments) -> None:
            self.name = name
            self.args = args


# Generated at 2022-06-23 23:19:37.847717
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import parse


# Generated at 2022-06-23 23:19:43.655136
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def test_assertions(tree: ast.AST) -> None:
        '''
        This is a generic test function.
        It will be invoked multiple times by pytest
        with different arguments.
        '''
        SuperWithoutArgumentsTransformer(tree).visit(tree)

        # the following assert statements will fail if the transformations
        # made by the transformer are incorrect

# Generated at 2022-06-23 23:19:44.242042
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:51.452358
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(ast.parse('class foo: def bar(cls): super();')).visit(tree)
    assert tree == ast.parse('super(foo, cls)')
    #
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(ast.parse('class foo: def bar(cls): super();')).visit(tree)
    assert tree == ast.parse('super(foo, cls)')

# Generated at 2022-06-23 23:20:00.713116
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import cst_to_ast
    from ..transformers.base import BaseNodeTransformer
    from ..transformers.calls import RemovePositionalArgumentsTransformer
    from ..transformers.functions import InheritComprehensionsTransformer

    node = cst_to_ast.parse_module("""
    class A:
        def __init__(self, *args):
            super().__init__(*args)
    """)

    assert isinstance(node, ast.Module)

    # Nothing changed
    transformer = BaseNodeTransformer(tree=node)
    transformer.visit(node)
    assert not transformer.tree_changed

    # Ensure that the tree is cleaned first
    transformer = RemovePositionalArgumentsTransformer(tree=node)
    transformer.visit(node)

# Generated at 2022-06-23 23:20:06.806968
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'class A(object):\n    def __init__(self):\n        super()'
    expected_code = 'class A(object):\n    def __init__(self, cls):\n        super(A, cls)'

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 23:20:11.965759
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_str
    module_node, _ = compile_str('''
        class A(object):
            def method(self):
                super()
    ''')

    assert str(module_node) == '''
        class A(object):
            def method(self):
                return super(A, self)
    '''

# Generated at 2022-06-23 23:20:23.575203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def foo(self):
                super()
        '''
    ast_tree = ast.parse(code)
    tr = SuperWithoutArgumentsTransformer(ast_tree)
    node = ast_tree.body[0].body[0].body[0]  # type: ignore
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.args[0], ast.Name)
    assert node.value.args[0].id == 'A'
    assert isinstance(node.value.args[1], ast.Name)
    assert node.value.args[1].id == 'self'
    tr.visit(ast_tree)
    assert isinstance(node, ast.Expr)