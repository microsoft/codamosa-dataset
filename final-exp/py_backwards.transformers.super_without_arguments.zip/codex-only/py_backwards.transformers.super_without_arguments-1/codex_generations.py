

# Generated at 2022-06-23 23:10:20.950262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._changed = False

        def _replace_super_args(self, node: ast.Call) -> None:
            self._changed = True

    class DummyAST(ast.AST):
        _fields = ()

    class DummyFuncAST(ast.AST):
        _fields = ()
        args = DummyAST()

    class DummyClassAST(ast.AST):
        _fields = ()
        name = 'DummyClass'

    tree = DummyAST()
    func = DummyFuncAST()
    func.args.args = [DummyAST()]
    cls = DummyClassAST

# Generated at 2022-06-23 23:10:22.660295
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    import ast


# Generated at 2022-06-23 23:10:32.066674
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3

    class MyTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast3.AST) -> None:
            self._tree = tree
            self._tree_changed = False

    tree = ast3.parse('class A:\n'
                      '    def __init__(self):\n'
                      '        super()')
    transformer = MyTransformer(tree)  # type: ignore
    transformer.visit(tree)
    node = tree.body[0].body[0]
    assert isinstance(node.value, ast3.Call)
    assert isinstance(node.value.func, ast3.Attribute)
    assert isinstance(node.value.func.value, ast3.Name)

# Generated at 2022-06-23 23:10:41.424816
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .utils import compile_source, expect_source

    source = """
        class Foo:
            def __init__(self):
                super()

    """
    tree = compile_source(source, __name__)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    expect_source(tree, """
        class Foo:
            def __init__(self):
                super(Foo, self)

    """)

    source = """
        class Foo:
            def __init__(self):
                super()

        def outer():
            class Bar:
                def __init__(self):
                    super()

    """
    tree = compile_source(source, __name__)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 23:10:48.523190
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..bytecode import compile_ast
    import sys
            

# Generated at 2022-06-23 23:10:49.149594
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:51.497712
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert (
        SuperWithoutArgumentsTransformer._test_visit('super()',
                                                     'super(ClassName, self)'))



# Generated at 2022-06-23 23:11:00.957826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import Parser
    from ..printer import Printer
    from ast import parse
    from os import path
    from distutils.version import LooseVersion

    p = Parser()

    # string
    assert Printer().print_node(p.parse("super()")) \
        == "<Text node>\n" \
        "super(cls, self)\n" \
        "\n"

    # file

# Generated at 2022-06-23 23:11:05.141806
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("class Cls:\n  def x(self):\n      super()\n")
    expected = "class Cls:\n  def x(self):\n      super(Cls, self)\n"
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert(to_source(tree) == expected)

# Generated at 2022-06-23 23:11:12.158658
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.compilation import compile_parser_tree
    
    super_func = ast.Call(func=ast.Name(id="super"), args=[])
    node = ast.Call(func=super_func, args=[])
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert compile_parser_tree(tree) == "super(Cls, self)"

    super_func = ast.Call(func=ast.Name(id="super"), args=[])
    node = ast.Call(func=super_func, args=[])
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert compile_parser_tree(tree) == "super(Cls, self)"

# just in case we run this directly

# Generated at 2022-06-23 23:11:14.234195
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    """Unit test for constructor of class SuperWithoutArgumentsTransformer
    """
    import astor


# Generated at 2022-06-23 23:11:20.611132
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_call = ast.parse('super()').body[0].value
    assert isinstance(super_call, ast.Call)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(super_call)

    assert len(super_call.args) == 2
    assert isinstance(super_call.args[0], ast.Name)
    assert isinstance(super_call.args[1], ast.Name)

    assert super_call.args[1].id == 'self'


# Generated at 2022-06-23 23:11:28.142444
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from sys import version_info
    if version_info < (3, 7):
        return

    import pytest
    from typed_ast import ast3, parse
    from typed_ast.ast3 import parse
    from typed_ast.transforms.super_without_arguments import SuperWithoutArgumentsTransformer

    def compile_source(source: str, mode: str = 'exec') -> ast3.AST:
        return parse(source, mode, 'tranform_super')

    def test_super_without_args():
        source = """
        class Foo:
            def __init__(self):
                super() # comment
        """
        tree = compile_source(source)
        SuperWithoutArgumentsTransformer().visit(tree)


# Generated at 2022-06-23 23:11:30.438460
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_transformation, _get_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:11:31.633970
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:32.261939
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:40.212376
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    x = ast.parse('''class A:
        def __init__(self):
            super()
        def foo():
            def bar(): 
                super()
    ''')
    node = x.body[0]
    assert node.body[0].args[0].id == 'A'
    assert node.body[0].args[1].id == 'self'
    assert node.body[1].body[0].body[0].args[0].id == 'A'
    assert node.body[1].body[0].body[0].args[1].id == 'cls'

# Generated at 2022-06-23 23:11:42.503120
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    node = ast.parse('super()').body[0]
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer.visit(node)
    assert astor.to_source(node).strip() == 'super(Cls, self)'



# Generated at 2022-06-23 23:11:52.021502
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast
    from .base import NodeTransformer
    from .helpers import build_module, compare_ast

    class SuperTransformer(NodeTransformer):
        def visit_Call(self, node):
            return ast.Call(func=ast.Name(id="super", ctx=ast.Load()), args=[ast.Name(id="Cls", ctx=ast.Load())], keywords=[], starargs=None, kwargs=None)

    class SuperTransformer2(NodeTransformer):
        def visit_Call(self, node):
            return node


# Generated at 2022-06-23 23:11:55.152310
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Errors if not replaced
    assert SuperWithoutArgumentsTransformer._replace_super_args(None, ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[]
    )) is None

# Generated at 2022-06-23 23:11:59.809880
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    s = "super()"
    t = ast.parse(s)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(t)

    assert transformer._tree_changed
    assert str(t) == "super(__name__, __name__)"

# Generated at 2022-06-23 23:12:08.446262
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    code = """
        class Header(BaseHeader):
            def __init__(self, *args, **kwargs):
                super().__init__()
                self.attrs = {}
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    expected = """
        class Header(BaseHeader):
            def __init__(self, *args, **kwargs):
                super(Header, self).__init__()
                self.attrs = {}
    """

    assert astor.to_source(ast.fix_missing_locations(tree)) == expected.strip()

# Generated at 2022-06-23 23:12:12.758451
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .base import NodeTransformer
    from .base import GenericTransformer
    assert issubclass(SuperWithoutArgumentsTransformer, NodeTransformer)
    assert issubclass(SuperWithoutArgumentsTransformer, GenericTransformer)



# Generated at 2022-06-23 23:12:20.884168
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import typing

    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )

    arg = ast.arg(
        arg='my_arg',
        annotation=None
    )

    func = ast.FunctionDef(
        name='func',
        args=ast.arguments(
            args=[arg],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[ast.Expr(value=node)],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-23 23:12:25.818593
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Testing for the constructor of the class SuperWithoutArgumentsTransformer
    """
    target = (2, 7)
    tree = ast.parse('super()')
    assert SuperWithoutArgumentsTransformer(tree, target).tree == ast.parse('super(Cls, self)')

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:12:34.098727
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u
    import ast
    from copy import deepcopy
    from ..transpile import transpile

    node = ast.parse(u('''
        class A:
            def a(self):
                super()
    '''))

    tree = deepcopy(node)
    t = SuperWithoutArgumentsTransformer(tree, None)
    new_tree = t.visit(tree)

    assert ast.dump(node) != ast.dump(new_tree)
    assert ast.dump(ast.parse(u('''
        class A:
            def a(self):
                super(A, self)
    '''))) == ast.dump(transpile(new_tree))


# Generated at 2022-06-23 23:12:44.625527
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_transformer_helpers import transform, random_string
    from .test_lineno_wrapper import wrap_in_lineno

    class A(object):
        def method1(self):
            super()
        def method2(self):
            return super()
        def method3(self):
            super(self)
        def method4(self):
            return super(self)

    class B(A):
        def method1(self):
            super()
        def method2(self):
            return super()
        def method3(self):
            super(self)
        def method4(self):
            return super(self)

    class C(object):
        def method1(self):
            super()
        def method2(self):
            return super()

# Generated at 2022-06-23 23:12:45.959056
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:12:52.446544
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = """
        class A(object):
            def method(self):
                super()
    """

    expected_output = """
        class A(object):
            def method(self):
                super(A, self)
    """
    tree = ast.parse(input_code)
    SuperWithoutArgumentsTransformer().visit(tree)
    output_code = astor.to_source(tree)

    assert expected_output in output_code

# Generated at 2022-06-23 23:12:52.908270
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:57.017798
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse(
        """
        class Cls:
            def f(self):
                super()
        """
    )
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert 'super(Cls, self)' in str(tree)



# Generated at 2022-06-23 23:12:59.916927
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..exceptions import NodeNotFound


# Generated at 2022-06-23 23:13:03.617703
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from typing import List
    from ..utils.helpers import get_ast_node_names
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-23 23:13:14.879166
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[])

    func = ast.FunctionDef(name='m',
                           args=ast.arguments(args=[ast.arg(arg='self', annotation=None)],
                                              vararg=None,
                                              kwonlyargs=[],
                                              kw_defaults=[],
                                              kwarg=None,
                                              defaults=[]),
                           body=[], decorator_list=[], returns=None)
    cls = ast.ClassDef(name='A',
                       bases=[],
                       body=[],
                       decorator_list=[])

    tree = ast.Module(body=[cls, func])
   

# Generated at 2022-06-23 23:13:18.604972
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that the transformer works as designed."""
    from ast_converter import AstConverter
    
    # Test that super without arguments is transformed to super with arguments

# Generated at 2022-06-23 23:13:29.686803
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class DummySuper(ast.NodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            self._tree = tree
            self._tree_changed = False

    tree = ast.parse('class A(object):\n    def b(self):\n        super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    result = ast.dump(tree)

# Generated at 2022-06-23 23:13:30.494163
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:31.020492
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:32.673991
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import assert_source


# Generated at 2022-06-23 23:13:41.748441
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import parse

    # Simple case
    src = """
    class Base:
        def foo(self):
            super()
    """
    module = parse(src)
    xformer = SuperWithoutArgumentsTransformer(ast=module)
    xformer.visit(module)
    assert xformer._tree_changed

    # Check class method
    src = """
    class Base:
        def foo(cls):
            super()
    """
    module = parse(src)
    xformer = SuperWithoutArgumentsTransformer(ast=module)
    xformer.visit(module)
    assert xformer._tree_changed

    # Check with super() inside of class
    src = """
    class Base:
        super()
    """
    module = parse(src)

# Generated at 2022-06-23 23:13:42.639620
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..unit_tests.utils import check_node


# Generated at 2022-06-23 23:13:47.078788
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_convert, assert_not_converted, assert_reinstate_backup

    from_source = 'super()'
    to_source = 'super(__CLASS_NAME__, self)'

    assert_convert(from_source, to_source, SuperWithoutArgumentsTransformer)
    assert_not_converted(from_source, SuperWithoutArgumentsTransformer)
    assert_reinstate_backup(from_source, to_source, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-23 23:13:47.769272
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:48.951011
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:13:56.860470
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test visit_Call method of class SuperWithoutArgumentsTransformer"""
    from .. import tree
    from ..utils.source import source_to_nodes

    transformer: SuperWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer()
    source = """
        class A():

            def m(self):
                super()
    """
    tree = source_to_nodes(source)
    transformer.visit(tree)
    source_new = tree_to_code(tree, "# source")
    source_expected = "class A():\n\n    def m(self):\n        super(A, self)\n"
    assert source_new == source_expected

# Generated at 2022-06-23 23:14:04.981572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import ast_util
    from .. import test_util

# Generated at 2022-06-23 23:14:05.440785
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:09.240873
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List

    class Cls(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            self.generic_visit(node)
            return node


# Generated at 2022-06-23 23:14:19.637273
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing on 01_super_no_argument.py"""
    import astor
    from astor.code_gen import to_source

    with open('test/super/01_super_no_argument.py') as f:
        node = ast.parse(f.read())
    SuperWithoutArgumentsTransformer().visit(node)

    # Check the object type
    assert isinstance(node, ast.Module)
    # Check the content of the object

# Generated at 2022-06-23 23:14:28.431916
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test without arguments
    node_to_test = ast.parse('super()')
    node_to_test_expected = ast.parse('super(Cls, self)')
    transformer = SuperWithoutArgumentsTransformer(node_to_test)
    res = transformer.visit(node_to_test)
    transformer.generic_visit(node_to_test)
    assert ast.dump(res) == ast.dump(node_to_test_expected)

    # Test with arguments
    node_to_test = ast.parse('super(f, g)')
    node_to_test_expected = ast.parse('super(f, g)')
    transformer = SuperWithoutArgumentsTransformer(node_to_test)
    res = transformer.visit(node_to_test)

# Generated at 2022-06-23 23:14:29.245719
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    

# Generated at 2022-06-23 23:14:30.081872
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:14:35.872775
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    code = """class A:
        def __init__(self):
            super()
    """
    expected_code = """class A:
        def __init__(self):
            super(A, self)"""

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert astor.to_source(tree).strip() == expected_code

# Generated at 2022-06-23 23:14:46.488922
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    cls = ast.ClassDef(name='C', body=[
        ast.FunctionDef(name='x', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[
            ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))
        ])
    ])

    ast.fix_missing_locations(cls)

    t = SuperWithoutArgumentsTransformer(cls)
    cls = t.visit(cls)

    assert isinstance(cls.body[0].body[0].value, ast.Call)
   

# Generated at 2022-06-23 23:14:53.221058
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    #                                                           012345678901234567890123456789012
    source = '''class Cls:           \n\
        def test(self):          \n\
            super()              \n\
    '''
    expect = '''class Cls:           \n\
        def test(self):          \n\
            super(Cls, self)     \n\
    '''
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).run()
    assert astor.to_source(tree).strip() == expect.strip()

# Generated at 2022-06-23 23:15:03.399028
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:05.682025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as _ast
    from .test_helpers import make_fixture


# Generated at 2022-06-23 23:15:15.897407
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_to_test = dedent('''
    class MyClass:
        def __init__(self):
            super()
        def __init__(cls):
            super()
        def myfunc(self):
            super()
        def myfunc(cls):
            super()
    ''')
    tree = ast.parse(code_to_test)
    c = SuperWithoutArgumentsTransformer(tree)
    c.visit(tree)

# Generated at 2022-06-23 23:15:22.057064
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .. import transform
    input_code = """
    class Test:
        def __init__(self):
            super()
    """
    expected_code = """
    class Test:
        def __init__(self):
            super(Test, self)
    """
    tree = ast.parse(input_code)
    transform(tree, SuperWithoutArgumentsTransformer)
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-23 23:15:29.296820
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # These tests doesn't make sence in Python 3
    if sys.version_info >= (3, 0):
        return
    
    import textwrap
    from typed_astunparse import unparse
    from ..utils.source import Source

    tree = ast.parse("""
    class Foo:
        def __init__(self, bar=None):
            super()
    """)

    new_tree = SuperWithoutArgumentsTransformer().visit(tree)
    code = unparse(new_tree)
    assert code == textwrap.dedent("""
    class Foo:
        def __init__(self, bar=None):
            super(Foo, self)
    """)

    tree = ast.parse("""
    class Bar:
        def __init__(self):
            super()
    """)

    new_tree

# Generated at 2022-06-23 23:15:30.720072
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:37.217928
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.helpers import dump_ast
    from ..utils.compare import compare_ast

    contents = (
        'class A:\n'
        '    def f(self):\n'
        '        super().\n'  # this is where we change the tree
    )
    tree = sta(contents)
    trans = SuperWithoutArgumentsTransformer(tree=tree)
    trans.visit(tree)

# Generated at 2022-06-23 23:15:45.249215
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing the constructor of the class SuperWithoutArgumentsTransformer"""
    code = """
        class A:
            def m(self):
                super()
        """
    etree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(etree)
    transformer.visit(etree)
    assert transformer.tree_changed() == True
    code = """
        class A:
            def __init__(self):
                super()
    """
    etree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(etree)
    transformer.visit(etree)
    assert transformer.tree_changed() == False

# Generated at 2022-06-23 23:15:50.098433
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src
    src = """
    class Cls:
        def method(self):
            super()
    """
    expected = """
    class Cls:
        def method(self):
            super(Cls, self)
    """
    tree = compile_src(src, __name__, __file__)
    assert expected == tree_to_str(tree)

# Generated at 2022-06-23 23:15:51.370407
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .transformer_utils import transform


# Generated at 2022-06-23 23:15:55.763662
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from ..utils.test_utils import make_tree, to_source
    module = make_tree(ast.parse(dedent('''
        class MyClass:
            def my_func(self):
                super()
    ''')))
    SuperWithoutArgumentsTransformer(module).run()
    assert to_source(module) == dedent('''
        class MyClass:
            def my_func(self):
                super(MyClass, self)
    ''')

# Generated at 2022-06-23 23:15:56.573195
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:57.020322
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:00.366890
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    transformer = SuperWithoutArgumentsTransformer(ast.parse('super()'))
    transformer.visit(transformer.tree)
    expected = ast.parse('super(Cls, self)')
    assert transformer.tree == expected

# Generated at 2022-06-23 23:16:10.772486
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node1 = ast.Call(
        func=ast.Name(id='super'),
        args=[]
    )
    node2 = ast.Call(
        func=ast.Name(id='super'),
        args=[ast.Name(id='name')]
    )
    node3 = ast.Call(
        func=ast.Attribute(
            value=ast.Name(id='super'),
            attr='attr'
        ),
        args=[]
    )


# Generated at 2022-06-23 23:16:16.960327
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import dump_ast
    from ..transpiler import Transpiler
    ast_tree = ast.parse('super()')
    tree = Transpiler().visit(ast_tree)
    assert dump_ast(tree) == 'Expr(Call(Name(id=super, ctx=Load()), [Name(id=Cls, ctx=Load()), Name(id=self, ctx=Load())], [], None, None), None)\n'

# Generated at 2022-06-23 23:16:18.041566
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:25.939876
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from ..parser import parse
    from ..utils.tree import dump

    tree = parse(textwrap.dedent("""
    class Test:
        def test(self):
            super()
    """))

    tree = SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:16:36.222295
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    from ..utils import parse_to_functiondef
    from ..utils import compare_source
    from ..utils.ast_helper import compare_asts

    tree = get_ast(parse_to_functiondef('super()'))
    transformed = SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected = get_ast(parse_to_functiondef('super(Foo, self)'))
    assert compare_asts(transformed, expected) is True
    assert compare_source(transformed, 'super(Foo, self)') is True

    tree = get_ast(parse_to_functiondef('super()', is_classmethod=True))
    transformed = SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-23 23:16:37.606839
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:44.653094
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Base(object):
            def __init__(self, foo, bar):
                super()
                self.foo = foo
                self.bar = bar
    """
    r = BaseNodeTransformer.compile_string(code, SuperWithoutArgumentsTransformer)
    assert r == """
        class Base(object):
            def __init__(self, foo, bar):
                super(Base, self)
                self.foo = foo
                self.bar = bar
    """

# Generated at 2022-06-23 23:16:48.197032
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_string
    from .base import BaseNodeTransformer
    from . import ClassAndFunctionDefinitionTransformer, SuperWithoutArgumentsTransformer


# Generated at 2022-06-23 23:16:53.486269
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast import parse, Call

    tree = parse('super()')
    cls = tree.body[0]
    assert type(cls) == Call
    assert cls.func.id == 'super'
    assert not len(cls.args)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer.tree_changed

    cls = tree.body[0]
    assert type(cls) == Call
    assert cls.func.id == 'super'
    assert len(cls.args) == 2

# Generated at 2022-06-23 23:17:00.569227
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source_code = inspect.cleandoc('''
    class Example:
        def method(self):
            super()
            pass
        pass
    ''')
    expected_code = inspect.cleandoc('''
    class Example:
        def method(self):
            super(Example, self)
            pass
        pass
    ''')
    tree = ast.parse(source_code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-23 23:17:11.642623
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('''
        class C:
            def func(self):
                super()
            @classmethod
            def func2(cls):
                super()
        super()
    ''')
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-23 23:17:12.627750
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:13.331273
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:19.925174
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    code = """
        class Foo(object):
            def __init__(self):
                super(Foo,self).__init__()
                super().__init__()
                super()
                """

    expected_code = """
        class Foo(object):
            def __init__(self):
                super(Foo,self).__init__()
                super(Foo,self).__init__()
                super(Foo,self)
                """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert (astor.to_source(tree)).strip() == expected_code

# Generated at 2022-06-23 23:17:27.077067
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import make_tree, assert_tree
    
    # Making the tree for the code
    tree = make_tree('''
    class A(object):
        def foo(self):
            super()
    ''')

    # Expected tree
    expected_tree = make_tree('''
    class A(object):
        def foo(self):
            super(A, self)
    ''')

    # Making the transformer and applying it
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    # Comparing the expected and actual tree
    assert_tree(expected_tree, tree)

# Generated at 2022-06-23 23:17:30.216191
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from py2c.analyses.tree import tree_from_src
    from typed_ast import ast3
    from ..utils.helpers import get_name_node
    from ..utils.tree import pretty_print_ast


# Generated at 2022-06-23 23:17:32.676939
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse

# Generated at 2022-06-23 23:17:33.638833
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:17:34.591794
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:35.549785
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:44.432370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from nuitka.nodes.CallNodes import makeExpressionCall

    from nuitka.nodes.ModuleNodes import CompiledPythonModule
    from nuitka.nodes.ClassNodes import ExpressionClassBody
    from nuitka.nodes.FunctionNodes import ExpressionFunctionBody
    from nuitka.nodes.AssignNodes import (
        StatementAssignmentVariable,
        StatementAssignmentVariableName,
        StatementAssignmentVariableAttribute
    )
    from nuitka.nodes.BuiltinRefNodes import ExpressionBuiltinSuper
    from nuitka.nodes.BuiltinTypeNodes import makeRaiseExceptionReplacementExpression
    from nuitka.nodes.ComparisonNodes import ExpressionComparisonIs
    from nuitka.nodes.ConstantRefNodes import ExpressionConstantRef

# Generated at 2022-06-23 23:17:46.317589
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:17:53.879459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    class Test(BaseNodeTransformerTest):
        target_class = SuperWithoutArgumentsTransformer
        def test_super_in_class(self):
            source = '''
super()
            '''
            expect = '''
super(Cls, self)
            '''
            tree = ast.parse(source)
            tree = tree.body[0]
            self.check(tree, expect)


# Generated at 2022-06-23 23:18:03.863637
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.scope import Scope

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(
                self,
                tree: ast.AST,
                file: str,
                scope: Scope,
        ) -> None:
            self._tree = tree
            self._file = file
            self._scope = scope
            self._tree_changed = False

    node = ast.parse('super()')
    node = node.body[0].value
    scope = Scope(None, node.lineno, node.col_offset)
    transformer = TestSuperWithoutArgumentsTransformer(node, '<string>', scope)
    node = transformer.visit(node)

    # the length of arguments of the super() call should be 2 now

# Generated at 2022-06-23 23:18:10.397798
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call()

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert(str(tree) == 'super(Cls, self)')

    tree = ast.parse('super.foo()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert(str(tree) == 'super.foo()')

    tree = ast.parse('super(1,2)')
    SuperWithoutArgumentsTransf

# Generated at 2022-06-23 23:18:15.111545
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == 'Module(body=[Expr(value=Call(func=Name(id=\'super\', ctx=Load()), args=[Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-23 23:18:24.058148
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast.parse('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0].body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].body[0].value.args[1], ast.Name)
    assert tree.body[0].body[0].value.args[1].id == 'self'

    tree = source_to_ast.parse('''
    class A:
        def __init__(self):
            super().__init__()
    ''')
    tree = SuperWithoutArgumentsTransformer().visit(tree)


# Generated at 2022-06-23 23:18:26.320590
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..compiler import Compiler

# Generated at 2022-06-23 23:18:32.642436
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import sys
    import ast
    from python_transpiler.ast_compat import cmp_ast
    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_SuperWithoutArgumentsTransformer(self):
            tree = ast.parse("super()")
            node = tree.body[0].value
            SuperWithoutArgumentsTransformer(None, None).visit(node)
            self.assertEqual(len(node.args), 2)

# Generated at 2022-06-23 23:18:34.091210
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(
        tree=None, search_name=None, filename=None)

    assert transformer is not None



# Generated at 2022-06-23 23:18:41.107389
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Tests SuperWithoutArgumentsTransformer.visit_Call method
    """
    class TestAST:
        def __init__(self, name: str) -> None:
            self.name = name

    class TestNode:
        def __init__(self, args: TestAST) -> None:
            self.args = args

    class TestArgs:
        def __init__(self, args: TestAST) -> None:
            self.args = args

    class TestTree:
        def __init__(self, _t: TestAST, _f: TestNode, _c: TestNode) -> None:
            self._t = _t
            self._f = _f
            self._c = _c


# Generated at 2022-06-23 23:18:41.659572
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:52.179094
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    from .base import BaseNodeTransformer

    source = Source("""
    class A:
        def __init__(self):
            super().__init__()

    class B(A):
        def __init__(self):
            super().__init__()

    class C(A):
        def __init__(self):
            super(A, self).__init__()

        def foo(self):
            super().__init__()

    class D(C):
        def __init__(self):
            super().__init__()

        def foo(self):
            super().__init__()
    """)

    node_transformer = SuperWithoutArgumentsTransformer(source)
    node_transformer.visit(node_transformer.tree)


# Generated at 2022-06-23 23:18:56.551760
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import parse, compare_ast

    code_1 = """
super()
    """
    code_2 = """
super(Cls, self)
    """
    tree_1 = parse(code_1)
    tree_2 = parse(code_2)

    assert compare_ast(SuperWithoutArgumentsTransformer().visit(tree_1), tree_2)

# Generated at 2022-06-23 23:18:58.935668
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..compat import get_ast as ast
    from ..compat import parse_compat

# Generated at 2022-06-23 23:19:01.237168
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    from ..utils.helpers import node_to_string
    from .test_helpers import setup_tree


# Generated at 2022-06-23 23:19:01.759896
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:19:06.613947
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    >>> import typed_astunparse
    >>> import ast
    >>> ast_node = ast.parse("class Super(object):"
    ... "    def __init__(self):"
    ... "        super()").body[0].body[0]
    >>> actual = typed_astunparse.unparse(ast_node)
    >>> expected = 'def __init__(self): super(Super, self)'
    >>> actual == expected
    True
    """

# Generated at 2022-06-23 23:19:07.457086
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:17.277509
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from ..utils.ast_helpers import make_module, get_func_body_ast

    code = """
        class A:
            def f(self):
                super()
    """

    tree = make_module(code, pyast)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    func = tree.body[0].body[0]
    assert isinstance(get_func_body_ast(func), pyast.Expr)
    assert isinstance(get_func_body_ast(func).value, pyast.Call)
    assert isinstance(get_func_body_ast(func).value.func, pyast.Attribute)
    assert isinstance(get_func_body_ast(func).value.func.value, pyast.Name)

# Generated at 2022-06-23 23:19:21.318387
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Test(object):
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, filename='', mode='exec')
    ns = {}
    exec (result, ns)
    assert ns['Test'].__init__.__name__ == '__init__'

# Generated at 2022-06-23 23:19:27.345168
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..codegen import to_source
    from ..utils.fixtures import use_fixtures

    fixtures = (
        # Setup
        'a: int = 2',
        'b: int = 3',
        'def adder(x: int, y: int) -> int:',
        '    class Adder:',
        '        def add(self) -> int:',
        '            return super().adder(x, y)',
        '    return Adder().add()',
        # Test
        'c: int = adder(a, b)'
    )


# Generated at 2022-06-23 23:19:28.711231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-23 23:19:35.789540
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    # Before
    code = '''class Test():
    def __init__(self):
        super()'''

    expected_code = '''class Test():
    def __init__(self):
        super(Test, self)'''

    tree = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)  # type: ignore
    code = astor.to_source(tree)

    assert code == expected_code

# Generated at 2022-06-23 23:19:42.941965
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_base import NodeTestCase, build_visitor_test_case
    from typed_ast.ast3 import parse as ast_parse

    code = """
    class A:
        def f(self):
            super()

    class B(A):
        pass
    """
    visitor = build_visitor_test_case(SuperWithoutArgumentsTransformer, code)

    node: ast.Call = visitor.find_node(
        [ast.Call],
        lambda node: isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args),
    )
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2
   

# Generated at 2022-06-23 23:19:47.007272
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transforms.super_without_arguments import SuperWithoutArgumentsTransformer
    from ..utils.source import source_to_ast as sta
    import sys

    class MyTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            pass


# Generated at 2022-06-23 23:19:57.231468
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from .. import transforms
    from ..utils.testing import assert_ast_transformed

    for version in transforms.SUPPORTED_PYTHON_VERSIONS:
        if version < (3, 6):
            continue

        # noinspection PyUnusedLocal
        class A:
            def foo(self):
                super().something()

        tree = parse(inspect.getsource(A))
        assert_ast_transformed(SuperWithoutArgumentsTransformer, A.__name__, tree, version)

        # noinspection PyUnusedLocal
        class A:
            def foo(self):
                class B:
                    super().something()

        tree = parse(inspect.getsource(A))

# Generated at 2022-06-23 23:19:58.435838
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO: Test
    pass

# Generated at 2022-06-23 23:19:59.453462
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    # Create source

# Generated at 2022-06-23 23:20:04.176336
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that the following piece of code:
        class Foo:
            def foo(self):
                super()
    Works without errors
    """
    tree = ast.parse('class Foo:\n\tdef foo(self):\n\t\tsuper()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)



# Generated at 2022-06-23 23:20:05.665853
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:20:06.314529
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:16.243449
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class ExampleClass:
            def __init__(self):
                super()
    """

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    new_tree = transformer.visit(tree)
    new_code = compile(new_tree, '', 'exec')
    scope = {}
    exec(new_code, scope)

    target_tree = ast.parse("""
        class ExampleClass:
            def __init__(self):
                super(ExampleClass, self)
    """)

    assert ast.dump(new_tree, annotate_fields=False) == ast.dump(target_tree, annotate_fields=False)