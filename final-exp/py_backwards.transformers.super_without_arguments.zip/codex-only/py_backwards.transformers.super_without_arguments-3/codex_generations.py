

# Generated at 2022-06-23 23:10:13.483004
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    test_tree = astor.parse_file('test.py')
    transformer = SuperWithoutArgumentsTransformer(test_tree)
    transformer.visit(test_tree)
    assert transformer.tree_changed == True

    test_tree2 = astor.parse_file('test2.py')
    transformer2 = SuperWithoutArgumentsTransformer(test_tree2)
    transformer2.visit(test_tree2)
    assert transformer2.tree_changed == True

    test_tree3 = astor.parse_file('test3.py')
    transformer3 = SuperWithoutArgumentsTransformer(test_tree3)
    transformer3.visit(test_tree3)
    assert transformer3.tree_changed == True

# Generated at 2022-06-23 23:10:19.936560
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    
    # Arrange
    tree = ast.parse("super()")
    tree.body[0].func.col_offset = 5

    # Act
    transformer = SuperWithoutArgumentsTransformer(tree, False)
    transformer.visit(tree.body[0])

    # Assert
    assert transformer.tree_changed
    assert transformer.tree.body[0].func.col_offset == 5
    assert transformer.tree.body[0].args[0].id == 'Cls'
    assert transformer.tree.body[0].args[1].id == 'self'


# Generated at 2022-06-23 23:10:20.509827
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:22.225346
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:10:31.750328
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import cast
    import astor
    tree = ast.parse('super()')
    func = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.Name(id='self', ctx=ast.Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))], decorator_list=[])
    cls = ast.ClassDef(name='Bar', bases=[], keywords=[], body=[func], decorator_list=[])
    tree.body = [cls]
    transformer = SuperWithoutArgumentsTransformer(tree=cast(ast.Module, tree))
    transformer.visit

# Generated at 2022-06-23 23:10:37.216016
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    
    node = ast.Call(
        ast.Name(id='super'),
        args=[],
    )
    expected = ast.Call(
        ast.Name(id='super'),
        args=[
            ast.Name(id='Cls'),
            ast.Name(id='self'),
        ],
    )


# Generated at 2022-06-23 23:10:43.743563
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from . import run_test_node

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node: ast3.Call):
            node.args = [  # type: ignore
                ast3.Name(id='new_super_cls'),
                ast3.Name(id='new_super_self'),
            ]

    test_super_without_arguments_transformer = TestSuperWithoutArgumentsTransformer()

    # Test in a function
    node = ast3.parse(
        """
        class Cls:
            def __init__(self, cls):
                super()
        """,
        mode='exec'
    )
    test_super_without_arguments_transformer.visit(node)
    run

# Generated at 2022-06-23 23:10:49.653982
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''foo()'''
    tree = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree, None)
    tree = transformer.visit(tree)
    assert clean_ast(ast.dump(tree)) == clean_ast('''
Module(body=[
    Expr(value=Call(
        func=Name(id='foo', ctx=Load()),
        args=[],
        keywords=[]))])
    ''')

    code = '''super()'''
    tree = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree, None)
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:10:50.759911
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:00.277913
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # mock node
    class Cls(ast.AST):
        _fields = ('args', 'func')
        _attributes = ()
    class Node(Cls):
        def __init__(self):
            self.func = Cls()
            self.func.id = 'super'
            self.args = []

    # mock tree
    class Tree(object):
        def __init__(self):
            self.changed = False
            self.current_class = 'Cls'
            self.current_function = 'func'
    tree = Tree()

    # mock generic_visit
    def generic_visit(node: ast.Call) -> ast.Call:
        node.func = Cls()
        node.func.id = 'super'
        node.args = [Cls(), Cls()]
        return node



# Generated at 2022-06-23 23:11:01.699930
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    node = ast.parse('super()')
    t.visit(node)

# Generated at 2022-06-23 23:11:05.140999
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"

    t = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(t)

    compiled = compile(t, '<string>', mode='exec')
    exec(compiled, locals(), globals())
    print('ok')

# Generated at 2022-06-23 23:11:12.182945
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test the method visit_Call of class SuperWithoutArgumentsTransformer.

    Arguments:
        tree {ast.Module} -- The node tree to visit.

    Returns:
        bool -- Returns True if the visit was successful, otherwise raises an error.
    """

    from ..backport_ast import parse

    class_source = '''
    class MyClass:
        def __init__(self, other):
            self.other = other
            super()

    class MySecondClass(MyClass):
        def __init__(self, other):
            super()
            self.other = other
    '''

    cls = parse(class_source)
    node = cls.body[1]  # type: ast.ClassDef
    assert node.name == 'MyClass'

    transformer = SuperWithoutArgumentsTransformer(cls)


# Generated at 2022-06-23 23:11:13.532079
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast

# Generated at 2022-06-23 23:11:21.300825
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = dedent("""
    class Foo(object):
        def __init__(self):
            super()
            super()
            super.foo()
    """)
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    new_code = compile(tree, '', 'exec')

    expect_code = dedent("""
    class Foo(object):
        def __init__(self):
            super(Foo, self)
            super(Foo, self)
            super.foo()
    """)
    assert new_code == compile(expect_code, '', 'exec')

# Generated at 2022-06-23 23:11:26.088212
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Foo(object):
        def __init__(self, x):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    expected_code = """
    class Foo(object):
        def __init__(self, x):
            super(Foo, self)
    """
    expected_tree = ast.parse(expected_code)
    assert tree == expected_tree

# Generated at 2022-06-23 23:11:34.960212
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    input = """
    class Cls:
        def f(self):
            super()
    """
    tree = ast.parse(input)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert len(transformer.failed_import_stmts) == 0
    assert transformer._tree_changed
    assert tree.body[0].body[0].body[0].value.func.args[0].id == 'Cls'
    assert tree.body[0].body[0].body[0].value.func.args[1].id == 'self'

# Generated at 2022-06-23 23:11:36.081959
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse

# Generated at 2022-06-23 23:11:42.390360
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    source = Source("""
        class Cls(object):
            def foo(self):
                super()
    """)
    super_transformer = SuperWithoutArgumentsTransformer(source.tree)
    super_transformer.visit_Call(source.tree.body[0].body[0].body[0].value)
    assert source.dumps() == """
        class Cls(object):
            def foo(self):
                super(Cls, self)
    """



# Generated at 2022-06-23 23:11:54.092112
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    import ast
    import inspect
    import os

    compiler = compile_to_ast.compile_file(os.path.join(os.path.dirname(__file__), '../tests/fixtures/super.py'))
    callable_nodes: ast.stmt = compiler.tree.body[0]
    if inspect.isclass(callable_nodes.body[1].body[0]):
        callable_nodes = callable_nodes.body[1].body[0]
    else:
        callable_nodes = callable_nodes.body[1]

    call_node = callable_nodes.body[0]
    assert call_node.args[1].id == 'self'

# Generated at 2022-06-23 23:12:00.628831
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..compiler.transforms import SuperWithoutArgumentsTransformer

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree = None

        def visit(self, tree):
            self._tree = tree
            return self.generic_visit(tree)



# Generated at 2022-06-23 23:12:01.567037
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:07.963687
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes

    tree = source_to_nodes('''
        class ExampleClass():
            def __init__(self):
                super()
    ''')

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    result = transformer.visit(tree)

    assert result == source_to_nodes('''
        class ExampleClass():
            def __init__(self):
                super(ExampleClass, self)
    ''')

# Generated at 2022-06-23 23:12:18.235057
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Foo(ast.NodeVisitor):
        def __init__(self):
            self.text = ''

        def visit_Name(self, node):
            self.text += node.id

        def visit_Load(self, node):
            pass

    foo = Foo()
    call = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    call.lineno = 3
    call.col_offset = 2
    call.accept(foo)

    assert foo.text == 'super', 'Did not visit Name "super" in Call with no args'

    # After SuperWithoutArgumentsTransformer.visit_Call

# Generated at 2022-06-23 23:12:23.592262
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..ast_transformer import ASTTransformer
    from ..python_version import PythonVersionManager
    from ..revert_transformer import RevertTransformer
    from ..io_transformer import IOTransformer
    from .python_imports import PythonImportsTransformer
    from .base_classes import BaseClassesTransformer


# Generated at 2022-06-23 23:12:27.469176
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.module_parse import module_from_str
    from ..visitors.tree_iteration import PreOrderTreeIteration
    from ..visitors.subscriber import TreeChangedSubscriber

# Generated at 2022-06-23 23:12:36.747154
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class X:
            def __init__(self):
                super()

        class Y:
            def __init__(self):
                super()

        class Z:
            def __init__(self):
                super()

        class A:
            def __init__(self):
                super()
                super()
    """
    expected_code = """
        class X:
            def __init__(self):
                super(X, self)

        class Y:
            def __init__(self):
                super(Y, self)

        class Z:
            def __init__(self):
                super(Z, self)

        class A:
            def __init__(self):
                super(A, self)
                super(A, self)
    """

# Generated at 2022-06-23 23:12:37.788453
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:38.760793
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:47.627569
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    code = """
    class X():
        def method(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '', 'exec')
    globs = {}
    exec(compiled, globs)
    class_ = globs['X']
    assert class_.method.__code__.co_varnames == ('self', 'X', 'method')
    assert class_.method.__code__.co_argcount == 3
    assert astor.to_source(tree) == """
    class X():
        def method(self):
            super(X, self)
    """

# Generated at 2022-06-23 23:12:52.810007
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import List, Dict, Tuple
    from test.test_utils import assert_tree_unchanged, assert_tree_changed
    from ..utils.helpers import create_node
    tree = create_node(ast.Call, func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[])
    assert_tree_unchan

# Generated at 2022-06-23 23:13:03.884313
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test case 1.
    # Test super() outside of function
    super()

    # Test case 2.
    # Test super() outside of class
    super()

    # Test case 3.
    def foo():
        super()

    # Before
    assert foo.__code__.co_consts[0].co_consts == (None, None)

# Generated at 2022-06-23 23:13:04.506804
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:13:07.213367
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests SuperWithoutArgumentsTransformer"""
    from typed_ast.ast3 import parse
    from ..utils.helpers import get_ast


# Generated at 2022-06-23 23:13:11.561309
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    node = ast.parse('super()').body[0]
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    assert astor.to_source(new_node) == 'super(Cls, self)'


# Generated at 2022-06-23 23:13:21.328021
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from ast_helpers.transformer import ctx
    from ast_helpers.node_recipes import call, function
    body = [
        call(func='super'),
        call(func='super')
    ]
    tree = function(
        name='foo',
        decorator_list=[  ],
        args=ast.arguments(
            args = [
            ast.arg(arg='self', annotation=None)
            ],
            vararg=None,
            kwonlyargs=[
            ],
            kw_defaults=[
            ],
            kwarg=None,
            defaults=[
            ]
        ),
        returns=None,
        body=body
    )

# Generated at 2022-06-23 23:13:21.907785
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:27.031397
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
foo = super()
    """
    expected_code = """
foo = super(Cls, self)
    """

    module, _ = run_transformer(SuperWithoutArgumentsTransformer, code, "ast")
    assert to_source(module) == expected_code

# Generated at 2022-06-23 23:13:33.562439
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_tester import AstTester
    from .generic import GenericASTTraversal
    from .method_to_function import MethodToFunctionTransformer
    from .function_to_method import FunctionToMethodTransformer
    from .class_to_function import ClassToFunctionTransformer
    from .function_to_class import FunctionToClassTransformer
    from .super_without_arguments import SuperWithoutArgumentsTransformer
    from ..compiler.compiler import Compiler

    # "super()" in a method is replaced with "super(Cls, self)"

# Generated at 2022-06-23 23:13:41.510413
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..transpile import transpile_code

    code_to_test = '''
    
    class A:
        def x(self):
            super()
    '''
    expected_transformed_code = '''
    
    class A:
        def x(self):
            super(A, self)
    '''

    tree = get_ast(code_to_test)
    transpiler = SuperWithoutArgumentsTransformer()
    transpiler.visit(tree)
    actual_transformed_code = transpile_code(tree, code_to_test)

    assert actual_transformed_code == expected_transformed_code

# Generated at 2022-06-23 23:13:42.284605
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:13:43.709034
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..transformers.base import BaseNodeTransformer

# Generated at 2022-06-23 23:13:49.944259
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast

    node = compile_to_ast("super()")
    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit(node)

    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.func, ast.Name)
    assert node.body[0].value.func.id == 'super'
    assert isinstance(node.body[0].value.args[0], ast.Name)
    assert isinstance(node.body[0].value.args[1], ast.Name)
    assert node.body[0].value.args[0].id == 'A'
    assert node.body[0].value.args[1].id == 'self'


# Generated at 2022-06-23 23:13:56.495335
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
       class C(object):
            def m(self):
                super()
    """
    module_node = ast.parse(code)

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            transformer = SuperWithoutArgumentsTransformer(module_node)
            new_node = transformer.visit(node)
            return new_node
    TestTransformer().visit(module_node)


# Generated at 2022-06-23 23:14:01.567683
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast

    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    t = SuperWithoutArgumentsTransformer(node, 'test')
    t.visit(node)

    assert t._tree_changed is True
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'

# Generated at 2022-06-23 23:14:08.302344
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import astor
    from .ast_shortcuts import (
        func,
        cls,
        call_super,
        call_super_with_args
    )
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import get_nodes
    # input
    node = func(
        body=[
            call_super(),
            call_super_with_args()
        ]
    )
    # expected

# Generated at 2022-06-23 23:14:08.908422
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:14:13.169909
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as test_ast
    from ..utils.test_utils import transform, assert_conversion
    from .test_base import assert_transformation

    tree = test_ast.parse('super()', '<string>', 'exec')


# Generated at 2022-06-23 23:14:23.621582
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from astroid.builder import ASTNODE_CLASSES

    module_node = ASTNODE_CLASSES[ast.Module]()
    class_node = ASTNODE_CLASSES[ast.ClassDef](name='SampleClass')
    method_node = ASTNODE_CLASSES[ast.FunctionDef](name='sample_method')
    method_node.args = ASTNODE_CLASSES[ast.arguments]()
    method_node.args.args = [ASTNODE_CLASSES[ast.arg](arg='self')]
    super_call = ASTNODE_CLASSES[ast.Call](func=ASTNODE_CLASSES[ast.Name](id='super'))

    method_node.body = [super_call]
    class_node.body = [method_node]
    module_node.body

# Generated at 2022-06-23 23:14:29.165704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast_tools import ast_to_source
    from typed_ast import ast3 as ast

    class A:
        def __init__(self):
            super().__init__()
            super().__init__()

    a = A()
    tree = ast.parse(inspect.getsource(a.__class__))
    t = SuperWithoutArgumentsTransformer(tree)
    t.run()
    changed_tree = ast.parse(ast_to_source(t.tree))

# Generated at 2022-06-23 23:14:30.691656
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import PyNode
    from ..node_utils import dump_ast

# Generated at 2022-06-23 23:14:41.282176
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.helpers import get_name_node
    from ..utils.tree import get_node_of_class
    from textwrap import dedent


    code = dedent("""
    class Test:
        def __init__(self):
            super()
    """)

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    expected_code = dedent("""
    class Test:
        def __init__(self):
            super(Test, self)
    """)

    assert ast.unparse(tree) == expected_code


    code = dedent("""
    class Test:
        def __init__(self):
            super()
    """)



# Generated at 2022-06-23 23:14:47.602901
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..utils.fake_module import FakeModule
    from ..visitors.base import NodeTransformer

    class MyTransformer(NodeTransformer):
        def visit_Call(self, node):
            return ast.Name('foo', ast.Store())

    f = ast.parse("super()")
    t = MyTransformer()
    f2 = t.visit(f)
    assert f2.body[0].value.id == 'foo'

# Generated at 2022-06-23 23:14:55.641117
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node_tree = ast.parse('class MyClass(object): def __init__(self): super()')
    super_transformer = SuperWithoutArgumentsTransformer(node_tree)
    super_transformer.run()
    expected_tree = ast.parse('class MyClass(object): def __init__(self): super(MyClass, self)')
    assert ast.dump(node_tree) == ast.dump(expected_tree)

    node_tree = ast.parse('class MyClass(object): def test(cls): super()')
    super_transformer = SuperWithoutArgumentsTransformer(node_tree)
    super_transformer.run()
    expected_tree = ast.parse('class MyClass(object): def test(cls): super(MyClass, cls)')
    assert ast.dump(node_tree) == ast

# Generated at 2022-06-23 23:15:00.422649
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from .super_without_arguments import SuperWithoutArgumentsTransformer
    t = SuperWithoutArgumentsTransformer()
    f = ast.parse('super();').body[0]
    f = t.visit(f)
    assert astor.to_source(f) == 'super(Cls, self);'

# Generated at 2022-06-23 23:15:05.559793
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import assert_code_equal
    code = """
        class A:
            def __init__(self):
                super()
        """
    expected = """
        class A:
            def __init__(self):
                super(A, self)
        """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_code_equal(expected, tree)



# Generated at 2022-06-23 23:15:06.416213
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass # TODO: write this unit test

# Generated at 2022-06-23 23:15:16.907823
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:26.207727
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test1 compiling: super()
    test1 = '''
        class A:
            def __init__(self):
                super()
    '''
    test1_expected = '''
        class A:
            def __init__(self):
                super(A, self)
    '''
    tree1 = ast.parse(test1)
    SuperWithoutArgumentsTransformer().visit(tree1)
    assert ast.dump(tree1) == ast.dump(ast.parse(test1_expected))

    # test2 compiling: super.__init__()
    test2 = '''
        class A:
            def __init__(self):
                super.__init__()
    '''

# Generated at 2022-06-23 23:15:33.873104
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import shutil
    import tempfile

    if sys.version_info[0] == 2:
        raise SkipTest('Python 2 super() is not AST-transformable')

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, Call, Name, arg
    from typed_ast.transforms import SuperWithoutArgumentsTransformer
    from typed_ast.transforms.Transformer import TransformerError

    tree = ast.parse('super(); super();')
    transformer = SuperWithoutArgumentsTransformer()
    with pytest.raises(NodeNotFound):
        transformer.transform(tree)

    tree = ast.parse('class Cls:\n    def method(self):\n        super()\n        super()')
    tree.body[0].name = 'Cls'

# Generated at 2022-06-23 23:15:44.318503
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test when the node is a super() without arguments
    module = parse('super()')
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)
    assert module == parse('super(Cls, self)')

    # Test when the node is a super() with arguments
    module = parse('super(1)')
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)
    assert module == parse('super(1)')

    # Test when the node is a field access
    module = parse('a.super()')
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)
    assert module == parse('a.super()')

    module = parse('super()')
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.vis

# Generated at 2022-06-23 23:15:50.272827
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
        class A(object):
            def fn(self):
                return super().func()
        """
    tree = ast.parse(input)
    print(ast.dump(tree))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    res = ast.dump(tree)
    print(res)
    res = compile(tree, '<string>', 'exec')
    exec(res)
    assert expected_output == res

# Generated at 2022-06-23 23:15:51.198394
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:58.753176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import should_transform, should_not_transform

    should_transform(
            SuperWithoutArgumentsTransformer,
            """super()""",
            """super(Super, self)"""
    )
    should_transform(
            SuperWithoutArgumentsTransformer,
            """super()
            """,
            """super(Super, self)
            """
    )

    should_not_transform(
            SuperWithoutArgumentsTransformer,
            """super(Super, cls)"""
    )
    should_not_transform(
            SuperWithoutArgumentsTransformer,
            """super(Super, self)
            def foo():
                pass
            """
    )

# Generated at 2022-06-23 23:16:01.365773
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    from ..utils.source import Source
    from ..utils.helpers import ast_to_string


# Generated at 2022-06-23 23:16:11.770117
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import unittest
    from ..test.test_transformer import TestTransformer
    from ..test.test_transformer_generic_cases import TestTransformerGenericCases as TestTransformerGenCases
    from ..test.test_transformer_visit_Call_cases import TestTransformerVisitCallCases
    from .visit_Call import VisitCallTransformer
    from .super_without_arguments import SuperWithoutArgumentsTransformer
    from .import_relative_to_absolute import ImportRelativeToAbsoluteTransformer

    class TestSuperWithoutArgumentsTransformerVisitCallCases(TestTransformerVisitCallCases):
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-23 23:16:12.870149
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # assert True  # TODO: implement your test here
    pass

# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-23 23:16:14.041124
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.compare import compare_nodes


# Generated at 2022-06-23 23:16:19.573158
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_all_nodes

    code = '''
    class A:
        def __init__(self):
            super()
    '''
    expected_code = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
    tree = run_all_nodes(code, (2, 7), [SuperWithoutArgumentsTransformer])
    assert expected_code == tree.body[0].body[0].body[0].value.value.value.args[0].id


# Generated at 2022-06-23 23:16:21.501924
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformerTest
    import textwrap

    class SuperWithoutArgumentsTransformerTest(BaseNodeTransformerTest):
        tran

# Generated at 2022-06-23 23:16:22.935519
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typing
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:16:32.188611
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..errors import CompileError

    source = """
        class A():
            def foo(self):
                super()
        """
    with pytest.raises(CompileError):
        astor.to_source(ast.parse(source))
    
    source = """
        class A():
            def foo(self):
                super(self)
        """
    with pytest.raises(CompileError):
        astor.to_source(ast.parse(source))
    
    source = """
        class A():
            def foo(self):
                super(cls)
        """
    with pytest.raises(CompileError):
        astor.to_source(ast.parse(source))
        

# Generated at 2022-06-23 23:16:34.260021
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer"""
    # Arrange

# Generated at 2022-06-23 23:16:39.519458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    node_input = astor.code_to_ast("super()")
    node_expected = astor.code_to_ast("super(Cls, self)")

    tree = ast.parse(textwrap.dedent('''
        class Cls:
            def func(self):
                super()
        '''))

    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    node_actual = transformer.visit(node_input)

    assert node_actual == node_expected

# Generated at 2022-06-23 23:16:43.398495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import generate_test_ast
    tree = generate_test_ast('super()')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert 'super(__TestClass__, __test)' in str(tree)

# Generated at 2022-06-23 23:16:53.594163
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys, logging

    logging.basicConfig(
        format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s',
        level=logging.WARNING)
    t = SuperWithoutArgumentsTransformer()
    t._tree = ast.parse('''
        class A:
            def b(self):
                super()
        ''')
    t.visit(t._tree)

# Generated at 2022-06-23 23:16:55.561580
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .helper import get_ast


# Generated at 2022-06-23 23:17:05.896026
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_
    from ..exceptions import ParseError
    from .. import registry

    content = """
    from __future__ import annotations
    bar = 1
    class Foo:
        def __init__(self):
            super()
            pass
    """
    tree = compile_(source_to_unicode(content), '<test>', 'exec')
    reg = registry.Registry()
    reg.register_transformer(SuperWithoutArgumentsTransformer)
    reg.apply(tree)

# Generated at 2022-06-23 23:17:16.068773
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from .base import BaseNodeTransformer

    tree = parse_tree("""
        class A(object):
            def __init__(self):
                super()


        class B(A):
            def __init__(self):
                super().__init__()


        class C(A):
            def __init__(self, a):
                super().__init__(a)

        class D(object):
            def __init__(self):
                super()
    """)

    tree = SuperWithoutArgumentsTransformer.run(tree)
    assert isinstance(tree, ast.Module)
    classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]

# Generated at 2022-06-23 23:17:20.442245
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cls():
            def method(self):
                super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    expected = """
        class Cls():
            def method(self):
                super(Cls, self)
    """

    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-23 23:17:24.316783
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert ast.dump(tree) == 'Module(body=[Expr(value=Call(func=Name(id=\'super\', ctx=Load()), args=[Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-23 23:17:33.134325
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    node = ast.parse('super()')
    transformed = transformer.visit(node)
    # get list of node, sorted by line number
    source = list(ast.walk(node))
    source = sorted(source, key=lambda x: x.lineno)
    transformed = list(ast.walk(transformed))
    transformed = sorted(transformed, key=lambda x:x.lineno)
    assert type(source) == type(transformed)
    assert len(source) == len(transformed)
    for src, dst in zip(source, transformed):
        assert src.__dict__ == dst.__dict__

# Generated at 2022-06-23 23:17:34.820237
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..exceptions import TransformError
    from ..utils.helpers import get_ast


# Generated at 2022-06-23 23:17:36.498233
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .utils import do_test_tree, get_ast


# Generated at 2022-06-23 23:17:45.163521
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import parse
    node = parse("super()", "ast").body[0]
    tr = SuperWithoutArgumentsTransformer()
    tr.visit(node)
    assert tr._tree_changed == True
    assert ast.dump(node) == "Expr(value=Call(func=Name(id='super', ctx=Load()), \
args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))"

    node = parse("super(arg1, arg2)", "ast").body[0]
    tr = SuperWithoutArgumentsTransformer()
    tr.visit(node)
    assert tr._tree_changed == False

# Generated at 2022-06-23 23:17:47.881566
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import AutoNodeTransformer
    from ..transpilers import TranspilerPy
    from ..utils.code_gen import to_source


# Generated at 2022-06-23 23:17:48.815150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:59.241279
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    import unittest
    import astor
    from ..utils.ast_maker import AstMaker
    from ..transpilers.super_without_arguments import SuperWithoutArgumentsTransformer

    class TestSuperWithoutArgumentsTransformer_visit_Call(unittest.TestCase):
        maxDiff = None

        def test_empty_argument(self):
            source = dedent('''
            class A(object):
                def foo(self):
                    super()
            ''')
            tree = AstMaker.parse(source)
            super_class = AstMaker.parse(dedent('''
            super(A, self)
            '''))
            SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-23 23:18:00.762975
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:18:02.495889
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast

    maker = pyast.parse


# Generated at 2022-06-23 23:18:11.196727
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_transformer

    tree = ast.parse('super()')
    t = ast_transformer.TransformedTree()
    SuperWithoutArgumentsTransformer.apply(tree, t)
    assert t.tree == ast.parse('super(Cls, self)')

    tree = ast.parse('class A:\n  def __init__(self):\n    super().__init__()')
    t = ast_transformer.TransformedTree()
    SuperWithoutArgumentsTransformer.apply(tree, t)
    assert t.tree == ast.parse('class A:\n  def __init__(self):\n    super(A, self).__init__()')

# Generated at 2022-06-23 23:18:18.435855
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..binary_op_to_func import BinaryOpToFuncTransformer
    from ..unpacking_generalization import UnpackingGeneralizationTransformer
    from ..unpacking_ex import UnpackingExTransformer
    from ..unpacking_inherited import UnpackingInheritedTransformer
    from ..with_cleanup import WithCleanupTransformer
    from ..num_literals import NumLiteralsTransformer
    from ..raise_from import RaiseFromTransformer
    from ..raise_if_not import RaiseIfNotTransformer

# Generated at 2022-06-23 23:18:29.157971
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse
    from . import cst

    cst_node_1 = cst.parse_module("""class Foo:\n    def bar(self):\n        super()""")
    ast_node_1 = parse("""class Foo:\n    def bar(self):\n        super(Foo, self)""")

    transformer = SuperWithoutArgumentsTransformer()
    res_1 = transformer.visit(cst_node_1)
    assert isinstance(res_1, ast.Module)
    assert ast.dump(res_1) == ast.dump(ast_node_1)

    cst_node_2 = cst.parse_module("""class Foo:\n    @classmethod\n    def bar(cls):\n        super()""")

# Generated at 2022-06-23 23:18:34.448641
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Unit test for simple class
    input_code = """
        class A():
            def func(self):
                print(super())
    """
    expected_code = """
        class A():
            def func(self):
                print(super(A, self))
    """
    utils.run_test(input_code, expected_code, SuperWithoutArgumentsTransformer)

    # Unit test for class with constructor
    input_code = """
        class A():
            def __init__(self, b=2):
                self.b = b
            
            def func(self):
                print(super())
    """

# Generated at 2022-06-23 23:18:35.225752
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:42.132332
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    
    import ast

    class TestCase(unittest.TestCase):
        def test(self):
            self.maxDiff = None
            tree = ast.parse('class A:\n def m(self): super()', mode='exec')
            exp_tree = ast.parse('class A:\n def m(self): super(A, self)', mode='exec')

            transformer = SuperWithoutArgumentsTransformer(tree)
            tree = transformer.visit(tree)

            self.assertEqual(str(tree), str(exp_tree))
    
    unittest.main()

# Generated at 2022-06-23 23:18:49.899589
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as to_ast

    module = """if True:
        class A:
            def __init__(self):
                super()"""
    tree = to_ast(module)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert transformer._tree_changed is True

    module = 'super()'
    tree = to_ast(module)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is False

# Generated at 2022-06-23 23:18:50.792961
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer


# Generated at 2022-06-23 23:18:55.105629
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Test(ast.NodeTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

    tree = ast.parse('""')
    node = tree.body[0]
    result = Test().visit(node)
    assert result == node

# Generated at 2022-06-23 23:18:56.226008
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import ast_transformer


# Generated at 2022-06-23 23:19:00.451202
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import load_example_module
    from ..utils.helpers import compare_node
    example_tree = load_example_module('super_without_arguments.py')
    SuperWithoutArgumentsTransformer(example_tree).visit(example_tree)
    compare_node(example_tree, load_example_module('super_without_arguments.py', target=SuperWithoutArgumentsTransformer.target))

# Generated at 2022-06-23 23:19:02.885094
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def check(before: str, after: str) -> None:
        t = SuperWithoutArgumentsTransformer()
        t.visit(ast.parse(before))
        assert str(t._tree) == after


# Generated at 2022-06-23 23:19:04.335359
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.code_gen import cst_to_ast

    cst = "super()"

# Generated at 2022-06-23 23:19:13.967197
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    from typing import Callable
    from . import verify_ast, verify_source

    def compare(code_orig: str, code_result: str, version_tuple: tuple) -> Callable[[ast.AST], bool]:
        ast_orig = ast.parse(code_orig)
        tree = SuperWithoutArgumentsTransformer(ast_orig, version_tuple)
        ast_result = tree.root

        assert astunparse.unparse(ast_result) == code_result
        verify_source(code_orig, code_result, version_tuple)
        return verify_ast(ast_orig, ast_result)

    def no_change(code: str, version_tuple: tuple) -> Callable[[ast.AST], bool]:
        return compare(code, code, version_tuple)

    # TOD

# Generated at 2022-06-23 23:19:14.708979
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:17.985536
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_node

    code = """
    super()
    """

    new_code = """
    super(Cls, self)
    """

    AST = ast.parse(code)
    AST = SuperWithoutArgumentsTransformer().visit(AST)
    assert_node(AST, new_code)

# Generated at 2022-06-23 23:19:18.424395
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:23.153575
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast

    def assert_transformed(before, after):
        transformer = SuperWithoutArgumentsTransformer(ast.parse(before), None)
        transformer.visit(transformer._tree)
        assert transformer._tree == ast.parse(after)

    assert_transformed(
        'super()',
        'super(Foo, self)',
    )

    assert_transformed(
        'super(Foo)',
        'super(Foo, self)',
    )

# Generated at 2022-06-23 23:19:26.280896
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_programs.super_without_arguments import program
    from .test_programs.super_without_arguments import expected
    tree = program()
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    assert expected() == tree

# Generated at 2022-06-23 23:19:30.715167
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import Source
    from ..visitor import PythonVisitor
    class TestVisitor(PythonVisitor):
        def __init__(self, source: Source) -> None:
            super().__init__(source)
            self.transformer = SuperWithoutArgumentsTransformer(tree=self.tree)


# Generated at 2022-06-23 23:19:40.125521
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse

# Generated at 2022-06-23 23:19:41.499961
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Tests the SuperWithoutArgumentsTransformer class.
    """
    import astor

# Generated at 2022-06-23 23:19:44.982714
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(tree=None)
    source = 'super()'
    expected = "super(Cls, self)"

    node = ast.parse(source)
    node = get_closest_parent_of(node, node, ast.Expr)
    node = transformer.visit(node)

    assert ast.dump(node) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 23:19:45.920653
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:46.881000
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:54.901414
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_source
    import ast
    import textwrap
    expected_output = textwrap.dedent(
        """\
        class Foo:
            def __init__(self):
                super(Foo, self)
        """
    )
    output = compile_source(
        textwrap.dedent(
            """\
            class Foo:
                def __init__(self):
                    super()
            """),
        transforms=(SuperWithoutArgumentsTransformer,)
    )
    assert ast.dump(ast.parse(expected_output)) == ast.dump(ast.parse(output))

# Generated at 2022-06-23 23:20:01.168961
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..transpilers.typed_ast.unparser import Unparser
    """test_SuperWithoutArgumentsTransformer"""

    code = '''
        class A:
            def __init__(self):
                super()
    '''

    module: ast.Module = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(module)
    assert Unparser(tree).tostring() == '''
        class A:
            def __init__(self):
                super(A, self)
    '''

# Generated at 2022-06-23 23:20:08.770135
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    func_code = 'def test():\n    super()'
    cls_code = "class Test:\n    def __init__(self):\n        super()"
    assert SuperWithoutArgumentsTransformer(code).result == ''
    assert SuperWithoutArgumentsTransformer(func_code).result == 'def test():\n    super(Test, self)'
    assert SuperWithoutArgumentsTransformer(cls_code).result == 'class Test:\n    def __init__(self):\n        super(Test, self)'