

# Generated at 2022-06-23 23:10:15.257015
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_closest_parent_of
    from .base import BaseNodeTransformer
    from .base import BaseTreeTransformer

    class TestTransformer(BaseTransformer):

        def __init__(self):
            self._tree_changed = False

        def _get_closest_parent_of(self, node, types):
            try:
                return get_closest_parent_of(self._tree, node, types)
            except NodeNotFound:
                return None

    class TestNodeTransformer(BaseNodeTransformer):
        target = (2, 7)

        def __init__(self):
            self._tree_changed = False


# Generated at 2022-06-23 23:10:19.760383
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def meth():
                super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '', 'exec')
    ns = {}
    exec(compiled, ns)
    print(dir(ns['A'].meth))

# Generated at 2022-06-23 23:10:21.059426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-23 23:10:23.474882
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..basic_transformations import ClassDefNodeTransformer
    from ..utils.helpers import to_source


# Generated at 2022-06-23 23:10:32.579995
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_all_functions, get_func_ast, parse_ast

    src = """
    class A(object):
        def __init__(self):
            super()
        
        def foo(self):
            super()
    
    class B(object):
        def foo(self):
            pass

    def baz():
        super()
    """
    func_names = ['A', 'foo', 'baz']
    tree = parse_ast(src)
    functions = get_all_functions(tree)
    assert len(functions) == len(func_names)
    for func_ast in functions:
        func_name = func_ast.name

# Generated at 2022-06-23 23:10:39.503472
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A(object):
        def __init__(self):
            super()
    
    class B(object):
        def f(self):
            super()
    """

    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    expected = """
    class A(object):
        def __init__(self):
            super(A, self)

    class B(object):
        def f(self):
            super(B, self)
    """

    assert expected == codegen.to_source(tree)

# Generated at 2022-06-23 23:10:42.216763
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .. import compile_source
    from .. import module_to_dict


# Generated at 2022-06-23 23:10:50.013405
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .base import BasePythonToPythonCompiler
    from .unpacking import UnpackingTransformer
    from .function_default_argument import FunctionDefaultArgumentTransformer
    from .function_arguments import (
        FunctionArgumentsTransformer, 
        FunctionArgumentsTransformerV2,
    )
    from .function_annotations import FunctionAnnotationsTransformer
    from ..exceptions import UntranslatableSyntaxError

    test_source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)


# Generated at 2022-06-23 23:10:59.682529
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..transpilers.base import BaseCodeGenerator
    from ..transpilers.javascript import JavascriptCodeGenerator


# Generated at 2022-06-23 23:11:01.184693
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_result = SuperWithoutArgumentsTransformer().visit_Call(ast.parse("super()").body[0])
    assert isinstance(assert_result, ast.Call)

# Generated at 2022-06-23 23:11:02.414439
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:10.025555
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from . import my_ast

    node = ast.parse("super()", mode='exec')
    func_node = node.body[0]
    cls_node = ast.ClassDef(name='Cls', body=[func_node], decorator_list=[])
    node = ast.Module(body=[cls_node])

    # No changes
    transformer = SuperWithoutArgumentsTransformer()
    my_ast.copy_location(transformer, node)
    new_node = transformer.visit(node)
    assert new_node is not node
    assert new_node.body[0].body[0].args[0].value.id == 'Cls'
    assert new_node.body[0].body[0].args[1].id == 'self'



# Generated at 2022-06-23 23:11:19.093422
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import source_to_nodes
    from ..utils.test_utils import transform_and_compare

    source = """
        class Foo():
            def __init__(self):
                super()
                super()
    """
    expected = """
        class Foo():
            def __init__(self):
                super(Foo, self)
                super(Foo, self)
    """

    nodes = source_to_nodes(source)
    nodes = SuperWithoutArgumentsTransformer().visit_module(nodes)
    transform_and_compare(nodes, expected)

# Generated at 2022-06-23 23:11:27.963155
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from . import ASTNodeTransformerTestCase

    tree = ast.parse("""
x = super()
    """)
    
    result_tree = ast.parse("""
x = super(X, self)
    """)


# Generated at 2022-06-23 23:11:29.064132
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:30.487791
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:40.928577
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.helpers import compile_source
    from ..utils.source import Source
    from ..utils.tree import node_to_string as n
    from ..utils.tree import find_all_nodes
    from ..manipulation.cache import TreeCache
    
    source = u('''
        class Parent(object):
            def __init__(self):
                super(Parent, self).__init__()
    ''')
    
    tree = compile_source(source, '<test>', 'exec')
    cache = TreeCache()
    cache.insert(tree, Source(source))
    
    transformer = SuperWithoutArgumentsTransformer(tree, cache)
    transformer.run()
    

# Generated at 2022-06-23 23:11:47.907268
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(target_version=((2, 7),))
    tree = ast.parse("""
        class A:
            def __init__(self):
                super()
    """)
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:11:56.974417
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node_1 = ast.Call(func=ast.Name(id='super'), args=[])
    node_2 = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    node_3 = ast.Call(func=ast.Name(id='super'), keywords=[])
    node_4 = ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='a')], keywords=[])
    node_5 = ast.Call(func=ast.Name(id='super'), args=[ast.Name(id='a')], keywords=[ast.keyword(arg='b', value=ast.Name(id='B')), ast.keyword(arg='c', value=ast.Name(id='C'))])


# Generated at 2022-06-23 23:11:59.997954
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import transform, parse_unsupported_syntax


# Generated at 2022-06-23 23:12:09.743211
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from typing import Any

    class MyNodeVisitor(ast3.NodeVisitor):
        def visit_Call(self, node: ast3.Call) -> Any:
            if isinstance(node.func, ast3.Name) and node.func.id == "super" and not len(node.args):
                node.args = [
                    ast3.Name(id="Cls"),
                    ast3.Name(id="self"),
                ]
            return self.generic_visit(node)

    node = ast3.parse("super()").body[0]  # type: ast3.Call
    MyNodeVisitor().visit(node)
    assert str(node) == "super(Cls, self)"


# Generated at 2022-06-23 23:12:19.487738
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.ast_transformer_fixture import ast_transformer_fixture

    tree = ast.parse(
        """
        class A(object):
            def __init__(self):
                self.value = super().__new__(self)
            def __new__(cls, instance, size=1):
                return object.__new__(object)
        """
    )

    tree2 = ast.parse(
        """
        class A(object):
            def __init__(self):
                self.value = super(A, self).__new__(self)
            def __new__(cls, instance, size=1):
                return object.__new__(object)
        """
    )


# Generated at 2022-06-23 23:12:29.749101
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # A.0 test for super() outside of function
    module1 = ast.parse('super()')
    tree1 = SuperWithoutArgumentsTransformer().visit(module1)
    assert str(tree1) == 'super()'
    # A.0 test for super() outside of class
    module2 = ast.parse('class Foo\n    super()')
    tree2 = SuperWithoutArgumentsTransformer().visit(module2)
    assert str(tree2) == 'class Foo:\n    super()'
    # B.0 test for super() in function in class
    module3 = ast.parse('class Foo:\n    def __init__(self):\n        super()')
    tree3 = SuperWithoutArgumentsTransformer().visit(module3)

# Generated at 2022-06-23 23:12:33.110752
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit(node)
    expected = ast.parse("super(Cls, self)")
    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-23 23:12:40.203414
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import parse

    tree = parse('class C: def f(self): super()')
    visitor = SuperWithoutArgumentsTransformer(tree)
    visitor.run()

    call = tree.body[0].body[0].body[0]
    assert isinstance(call, ast.Expr)

    assert isinstance(call.value, ast.Call)
    assert call.value.func.id == 'super'
    assert call.value.func.value.id == 'C'
    assert call.value.args[0].id == 'self'

# Generated at 2022-06-23 23:12:48.452760
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cls:
            def __init__(self, x):
                super()
                self.x = x
                
        def func():
            super()

        obj = Cls(1)
        """

    expected_code = """
        class Cls:
            def __init__(self, x):
                super(Cls, self)
                self.x = x
                
        def func():
            super()

        obj = Cls(1)
        """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree, code).translate()
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 23:12:49.404452
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:52.850361
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import as_tuple
    from ..transformers.string_base import StringTransformerMixin

    class T(StringTransformerMixin, SuperWithoutArgumentsTransformer):
        pass


# Generated at 2022-06-23 23:13:03.936576
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code =   """
            class Foo():
                def bar(self):
                    super()

            def func():
                super()
            """

    tree = ast.parse(code)
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    tree = node_transformer.visit(tree)
    tree = ast.fix_missing_locations(tree)


# Generated at 2022-06-23 23:13:07.520694
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    test_source = 'super()'
    tree = ast.parse(test_source)
    tree = SuperWithoutArgumentsTransformer.run_pipeline(tree)
    expected_source = 'super(Cls, self)'
    expected_tree = ast.parse(expected_source)
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-23 23:13:18.880901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..transpile import transpile
    source = source_to_unicode('''
    class A:
        def __init__(self):
            super()
            
    class B(A):
        def __init__(self):
            super().__init__()
    ''')
    expected_source = source_to_unicode('''
    class A:
        def __init__(self):
            super(A, self)
            
    class B(A):
        def __init__(self):
            super(B, self).__init__()
    ''')
    tree = transpile(source, 2)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

# Generated at 2022-06-23 23:13:29.977247
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class Foo:
        def bar(self):
            super()

    class Foo:
        def bar(cls):
            super()
    '''

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()
    result = ast.dump(tree)

# Generated at 2022-06-23 23:13:39.170475
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..translator import Translator
    from ..utils.tree import parse_ast_tree, build_ast_tree
    from ..utils.helpers import get_ast_node
    tree = parse_ast_tree("super()")
    node = get_ast_node(tree, ast.Call)
    assert node.args == []
    translator = Translator(tree)
    # The parent of node is no ast.FunctionDef nor ast.ClassDef
    assert translator.tree_to_str() == (
        "super()"
    )
    tree = build_ast_tree("super()", 2, 7)
    node = get_ast_node(tree, ast.Call)
    assert node.args == []
    translator = Translator(tree)
    # The parent of node is ast.Function

# Generated at 2022-06-23 23:13:46.702653
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = '''
    class Foo:
        def foo(self):
            super()
    '''

    module = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(module)

# Generated at 2022-06-23 23:13:47.898871
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast as sta


# Generated at 2022-06-23 23:13:58.216621
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    code_compiled = 'super(Cls, self)'
    tree = ast.parse(code)
    tree_compiled = ast.parse(code_compiled)
    cls = ast.ClassDef(name='Cls', body=[
        ast.FunctionDef(
            name='__init__',
            args=ast.arguments(args=[ast.arg('self', None)], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]),
            body=[],
            decorator_list=[],
            returns=None,
        )
    ])
    tree.body.extend(cls.body)
    tree_compiled.body.extend(cls.body)

# Generated at 2022-06-23 23:14:02.888473
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                return self.generic_visit(node)
            raise AssertionError(str(ast.dump(node)))

# Generated at 2022-06-23 23:14:10.365302
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.context import Context
    from ..utils.helpers import get_ast_node, ast_equals
    source = '''
    class A:
        def __init__(self):
            super().__init__()
    '''
    tree = ast.parse(source)
    node = get_ast_node(tree, 'super')
    instance = SuperWithoutArgumentsTransformer(Context(), tree)
    assert isinstance(instance.visit_Call(node), ast.Call)
    assert ast_equals(tree, '''
    class A:
        def __init__(self):
            super(A, self).__init__()
    ''')

# Generated at 2022-06-23 23:14:15.848296
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src

    src = """
        class Cls(Super):
            def method(self):
                super()
    """

    expected = """
        class Cls(Super):
            def method(self):
                super(Cls, self)
    """

    tree = compile_src(src, 2, 7)
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert expected == tree_to_str(tree)

# Generated at 2022-06-23 23:14:21.097556
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # 2.7
    node = ast.parse('super()')
    expected = ast.parse('super(Cls, self)')

    class Cls:
        def __init__(self):
            super()

    SuperWithoutArgumentsTransformer(tree=node).visit(node)
    assert node == expected


# Generated at 2022-06-23 23:14:27.271381
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import parse, dump
    from ..utils.helpers import run_through_exactly_typed_ast_back_and_forth

    tree = parse('class A:   def foo(self): super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    res = dump(tree)
    assert res == "class A:\n    def foo(self):\n        super(A, self)"

    run_through_exactly_typed_ast_back_and_forth(res, tree)

# Generated at 2022-06-23 23:14:29.400362
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor 
    from astor.codegen import to_source
    from py2js.compiler import compile


# Generated at 2022-06-23 23:14:38.598737
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_
    module = compile_('super()', "<string>", 'exec')
    assert isinstance(module.body[0].value, ast.Call)
    assert isinstance(module.body[0].value.func, ast.Name)
    assert module.body[0].value.func.id == "super"
    assert len(module.body[0].value.args) == 2
    assert isinstance(module.body[0].value.args[0], ast.Name)
    assert module.body[0].value.args[0].id == "Cls"
    assert isinstance(module.body[0].value.args[1], ast.Name)
    assert module.body[0].value.args[1].id == "self"

# Generated at 2022-06-23 23:14:49.100980
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code

    assert_transformed_code(SuperWithoutArgumentsTransformer, '''
        class X:
            def y(a):
                super()
        ''', '''
        class X:
            def y(a):
                super(X, a)
        ''')

    assert_transformed_code(SuperWithoutArgumentsTransformer, '''
        class X:
            def __init__(self):
                super()
        ''', '''
        class X:
            def __init__(self):
                super(X, self)
        ''')


# Generated at 2022-06-23 23:14:58.756188
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class MockNode(ast.AST):
        def __init__(self) -> None:
            self.body = [ast.Expr(ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None))]  # type: ignore
    
    cls = ast.ClassDef(name='TestClass', bases=[], keywords=[], body=[MockNode()], decorator_list=[])
    tree = ast.Module(body=[cls])
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert tree.body[0].body[0].body[0].value.func.args[0].id == 'TestClass'

# Generated at 2022-06-23 23:15:04.249014
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    in_txt = """
super()
"""
    out_txt = """
super(Cls, self)
"""
    in_ast = astor.parse_file(astor.code_to_ast(in_txt))
    out_ast = astor.parse_file(astor.code_to_ast(out_txt))
    transformer = SuperWithoutArgumentsTransformer(in_ast)
    assert transformer.result == out_ast

# Generated at 2022-06-23 23:15:11.697253
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from . import AssertTransformedAST


# Generated at 2022-06-23 23:15:12.724015
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:14.105546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:15:21.664031
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast import parse
    from ..build import build
    from ..utils.helpers import assertion_message
    from ..utils.compat import unicode

    tests = [
        ('super()', ('super(Cls, self)', 'super(Cls, cls)')),
        ('super(arg)', tuple()),
    ]

    for test, expected in tests:
        tree = parse(test)
        SuperWithoutArgumentsTransformer(tree).visit(tree)

        test_ = unicode(tree)
        assert test_ in expected, assertion_message(test, expected, test_)

# Generated at 2022-06-23 23:15:22.125158
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-23 23:15:27.506668
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_it(self):
            code = """
            class A:
                def x(self):
                    super(A, self)
            """
            root = ast.parse(code)

            SuperWithoutArgumentsTransformer().visit(root)

            self.assertEqual(
                compile(root, filename="<ast>", mode="exec").co_code,
                compile(code, filename="<ast>", mode="exec").co_code
            )

    unittest.main()

# Generated at 2022-06-23 23:15:28.410569
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:37.309816
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code, source_to_ast
    from ..utils.helpers import print_ast
    from ..exceptions import InvalidPythonSource
    from .base import BaseNodeTransformer

    code = source_to_code("""
        def f():
            super()
    """)
    node = source_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer()
    with pytest.raises(InvalidPythonSource):
        transformer.visit(node)
    assert transformer.tree_changed is False

    code = source_to_code("""
        class A:
            def f():
                super()
    """)
    node = source_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer()
    with pytest.raises(InvalidPythonSource):
        transformer.vis

# Generated at 2022-06-23 23:15:41.403914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()
    # TODO: assert generated code
    # assert transformer.result() == expected

# Generated at 2022-06-23 23:15:48.666730
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    source = '''super()'''
    nodes = source_to_nodes(source)
    func_def_node = nodes[0]
    class_def_node = nodes[0]
    tree = ast.Module(type_ignores=[], body=[func_def_node, class_def_node])
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert isinstance(tree.body[0].body[0].value, ast.Call) # type: ignore

# Generated at 2022-06-23 23:15:49.282758
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:51.283302
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests:
    super() -> super(cls, self)
    """

# Generated at 2022-06-23 23:15:58.809420
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTestCase
    from ..utils.validator import from_code
    
    class Test(BaseNodeTestCase):
        target_versions = (2, 7)
        transformer = SuperWithoutArgumentsTransformer
        node = from_code('super()')

        def test_replace_super_args(self, node):
            func = ast.FunctionDef(name='f', args=ast.arguments(args=[ast.Name(id='self')]))
            cls = ast.ClassDef(name='C')
            tree = ast.Module(body=[cls, func])
            self._transformer._tree = tree
            self._transformer._replace_super_args(node)

# Generated at 2022-06-23 23:16:08.817152
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import build_ast
    node = ast.Call(
        func=ast.Name(id='super'),
        args=[],
        keywords=[])
    expected_node = ast.Call(
        func=ast.Name(id='super'),
        args=[ast.Name(id='Cls'), ast.Name(id='self')],
        keywords=[])
    tree = build_ast('''
        class Cls(object):
            def __init__(self):
                super()
    ''')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert expected_node == tree.body[0].body[0].value.args[0]

# Generated at 2022-06-23 23:16:12.753560
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..compiler import compile_src
    from .super_with_arguments import SuperWithArgumentsTransformer

    # Testing that 'super.x' is replaced with 'super(cls, self).x'

# Generated at 2022-06-23 23:16:19.479058
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from tempfile import NamedTemporaryFile
    from .base import BaseNodeTransformer
    from .base import TransformerResult
    import os
    import sys
    import re
    import astunparse
    import contextlib
    with contextlib.redirect_stdout(None):
        import pygments
        import pygments.lexers
        import pygments.formatters
    BaseNodeTransformer.NO_COLOR = True

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)


# Generated at 2022-06-23 23:16:27.951267
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..NodeTransformer import NodeTransformer

    class F(NodeTransformer):
        def visit_Call(self, node):  # type: ignore
            assert isinstance(node, ast.Call)
            node.func = ast.Name(id='print')
            return node

    # Make sure that it's not getting wiped out by the VisitCall method.
    class D(F):
        pass

    class NodeTransformerEmptyCall(NodeTransformer):
        def visit_Call(self, node):  # type: ignore
            assert isinstance(node, ast.Call)
            return node

    class NodeTransformerEmptyClass(NodeTransformer):
        def visit_ClassDef(self, node):  # type: ignore
            assert isinstance(node, ast.ClassDef)
            return node


# Generated at 2022-06-23 23:16:37.373244
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name) and tree.body[0].value.func.id == 'super'
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].value.args[1], ast.Name)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'self'

# Generated at 2022-06-23 23:16:38.701227
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:49.227864
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from .. import settings
    from ..utils.ast_factory import ast_call, ast_name, ast_class, ast_function
    from ..utils.helpers import ANY_VALUE, ANY_NODE_TYPE, assert_equal_signature

    test_tree = ast_class(
        'Cls',
        body=[
            ast_function(
                '__init__',
                args=ANY_NODE_TYPE,
                body=[
                    ast_call('super')
                ]
            )
        ]
    )

# Generated at 2022-06-23 23:16:50.293338
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:16:51.463840
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import find_nodes_by_type


# Generated at 2022-06-23 23:16:53.857200
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_visit_results_equal(
        SuperWithoutArgumentsTransformer(),
        'super()',
        '''
        class Cls:
            def meth(self):
                super = 42
                super()
        '''
    )

# Generated at 2022-06-23 23:16:57.882339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def f(self):
                super().hi()
    """
    module = ast.parse(code)
    SuperWithoutArgumentsTransformer(2, 7, module).visit(module)

    assert 'super(A, self).hi()' in astunparse.unparse(module)

# Generated at 2022-06-23 23:16:59.114461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:09.997677
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

        class ASTWrapper(ast.AST):
            """Wrapper class for AST to include filename"""
            _fields = ['tree']

            def __init__(self, tree: ast.AST, filename: str):
                self.tree = tree
                self.filename = filename

            def __iter__(self) -> ast.AST:
                """Returns a wrapper iterator of the AST"""
                return ASTIterWrapper(self.tree, self.filename)

            def __getitem__(self, key: int) -> ast.AST:
                """Returns a wrapper iterator of the AST"""
                return ASTWrapper(self.tree.body[key], self.filename)

        class ASTIterWrapper:
            """Wrapper iterator for AST"""
            def __init__(self, node, filename):
                self.iter = iter(node)

# Generated at 2022-06-23 23:17:19.023466
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from .base import BaseNodeTransformer
    from .super import SuperWithoutArgumentsTransformer
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import get_context_of_node
    from copy import deepcopy
    import astunparse

    code = '''
    class Cls:
        def method(self):
            super()
    '''
    tree = ast.parse(code)
    tree_copy = deepcopy(tree)
    transformer = SuperWithoutArgumentsTransformer(tree, Context())
    transformer.visit(tree)
    assert astunparse.unparse(tree_copy) == astunparse.unparse(tree)


# Generated at 2022-06-23 23:17:22.455520
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import inspect
    _tree = ast.parse(inspect.getsource(test_SuperWithoutArgumentsTransformer_visit_Call))
    _transformer = SuperWithoutArgumentsTransformer()
    _transformer.visit(_tree)
    assert str(_tree) == "class A(object):\n    def __init__(self):\n        super(A, self)\n"

# Generated at 2022-06-23 23:17:23.406539
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import compile_function


# Generated at 2022-06-23 23:17:33.548112
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import unittest

    from typed_ast import ast3 as typed_ast
    from typed_ast import convert
    from typed_ast.typed_ast3 import *
    from typed_ast.transforms import SuperWithoutArgumentsTransformer

    from .fixtures import *
    from plum import set_debug

    set_debug(True)


# Generated at 2022-06-23 23:17:41.495497
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast
    from ..utils.validation import validate_ast
    from .sample_asts.super_without_arguments import (
        python2_code,
        tree_after_transformation,
        expected_warnings,
    )

    tree = get_ast(python2_code)
    transformer = SuperWithoutArgumentsTransformer()
    if transformer.target[0] < 2:
        transformer.visit(tree)
    else:
        transformer.visit_module(tree)

    assert transformer.tree_changed
    assert validate_ast(tree, tree_after_transformation, expected_warnings)


# Generated at 2022-06-23 23:17:43.240214
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as _ast
    from ._test_utils import round_trip

# Generated at 2022-06-23 23:17:50.599752
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast

    """
    # super() -> super(__class__, self)
    """
    node = ast.Call(
        func=ast.Name(id='super',
                      ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)

    assert node.args[0].s == '__class__'
    assert node.args[1].s == 'self'
    return True
    


# Generated at 2022-06-23 23:17:58.577196
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from typed_ast import convert
    import textwrap
    from ..utils.helpers import get_first_of_type

    # type: ignore
    code = textwrap.dedent('''
    class A:
        def __init__(self):
            super()
    ''')
    tree: ast3.FunctionDef = get_first_of_type(convert(code), ast3.ClassDef)
    name: ast3.Name = get_first_of_type(tree, ast3.Name)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert name.id == 'A'

# Generated at 2022-06-23 23:17:59.287427
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:09.641277
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.python_version import PythonVersion

    tree = ast.parse('super()')
    
    transformer = SuperWithoutArgumentsTransformer(tree, PythonVersion(2, 7))
    tree = transformer.visit(tree)
    print(ast.dump(tree))
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)

    call = tree.body[0].value
    assert isinstance(call.func, ast.Name)
    assert call.func.id == 'super'
    assert len(call.args) == 2
    assert isinstance(call.args[0], ast.Name)

# Generated at 2022-06-23 23:18:10.335822
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:10.882834
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:18.247000
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from typed_ast import ast3 as typed_ast

    class TestNodeTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            super().__init__(typed_ast.parse('pass'))

    node = pyast.parse('super()').body[0]

    transformer = TestNodeTransformer()
    new_node = transformer.visit_Call(node)

    assert type(new_node) is typed_ast.Call
    assert type(new_node.func) is typed_ast.Name

    assert type(new_node.args[0]) is typed_ast.Name
    assert new_node.args[0].id == 'Cls'

    assert type(new_node.args[1]) is typed_ast.Name

# Generated at 2022-06-23 23:18:28.976963
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Testing that the method visit_Call is working properly
    # with a super() call with no arguments
    # The method should return the super() call with arguments
    # The arguments should be the name of the class and the name of the method
    from os import path
    from typed_ast import ast3
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import Str
    from mypy_boto3_builder.transpile.utils.helpers import parse_string_to_module
    from mypy_boto3_builder.transpile.utils.tree import get_all_of_type
    from mypy_boto3_builder.transpile.utils.tree import get_closest_parent_of
    from mypy_boto3_builder.transpile.utils.helpers import get_only

# Generated at 2022-06-23 23:18:37.445579
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:47.534643
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import List

    # Testing types, ignore warnings
    from . import ClassWithoutInitTransformer
    from . import BuiltinMethodTransformer
    from . import ClassAttributesToGettersSettersTransformer
    from . import MethodToFunctionTransformer
    from . import BuiltinFunctionsTransformer
    from . import FunctionGlobalStateTransformer
    from . import FunctionWithoutArgumentsTransformer
    from . import ClassWithoutInitTransformer

    # Testing types
    from ..utils.code_gen import CodeIO
    from ..utils.helpers import get_ast
    from ..transformer import Transformer
    from ..tree_compilation_error import TreeCompilationError


# Generated at 2022-06-23 23:18:53.463759
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse
    from ..utils.syntax_tree import parse_tree

    code = '''
        class MyClass(object):
            def __init__(self):
                super()
    '''
    tree = parse_tree(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    new_code = unparse(tree).strip()


# Generated at 2022-06-23 23:18:54.375634
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse

# Generated at 2022-06-23 23:19:02.130594
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_source_equal(
        SuperWithoutArgumentsTransformer.run_pipeline('''class A:
                                                        def m(self):
                                                            return super()'''),
        '''class A:
           def m(self):
               return super(A, self)''')

    assert_source_equal(
        SuperWithoutArgumentsTransformer.run_pipeline('''class A(B):
                                                        def m(self):
                                                            return super()'''),
        '''class A(B):
           def m(self):
               return super(A, self)''')

# Generated at 2022-06-23 23:19:04.046447
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse
    import operator
    from python_minifier.transformers.ast_helpers import print_ast
    from ..utils.helpers import assert_if_prints


# Generated at 2022-06-23 23:19:04.845496
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:19:09.955955
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    expect_code = """"""
    ast_tree = compile(code, "<test>", "exec", ast.PyCF_ONLY_AST)
    SuperWithoutArgumentsTransformer(ast_tree).visit(ast_tree) 
    if hasattr(ast_tree, 'body') and len(ast_tree.body):
        test_ast = ast_tree.body[0]
    else:
        test_ast = ast_tree
    # ensure we got back a ClassDef node
    assert isinstance(test_ast, ast.Module)
    codegen.to_source(ast_tree) == expect_code

# Generated at 2022-06-23 23:19:17.954077
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_example_dir, get_example_path
    from ..transpilers.base import BaseTranspiler
    from ..transpilers.compatibility import Python2Transpiler
    import ast

    code = get_example_path(get_example_dir(), 'super.py')
    with open(code) as f:
        root = ast.parse(f.read())

    t = Python2Transpiler(root)
    t.register_transformer(SuperWithoutArgumentsTransformer)
    t.transpile_method(BaseTranspiler.VISIT_CALL)
    print(ast.dump(root))

# Generated at 2022-06-23 23:19:24.337614
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import tree

    from ..utils.helpers import parse

    tree_ = tree.TreeGenerator(parse('''
        class A:
            def __init__(self):
                super()
    ''')).get_tree()

    transformer = SuperWithoutArgumentsTransformer(tree_)
    transformer.visit(tree_.body[0])

    assert transformer._tree_changed is True
    assert isinstance(tree_.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree_.body[0].body[0].body[0].value.func, ast.Name)
    assert tree_.body[0].body[0].body[0].value.func.id == 'super'
    assert len(tree_.body[0].body[0].body[0].value.args) == 2

# Generated at 2022-06-23 23:19:24.820923
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:35.131848
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    #  super() replaced with super(Cls, self)
    node = ast.Call(func=ast.Name(id='super'), args=[])
    func_def_node = ast.FunctionDef(name='_', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)]),
        body=[ast.Expr(value=node)])
    class_def_node = ast.ClassDef(name='Cls', bases=[], keywords=[], body=[func_def_node], decorator_list=[])

    tree = ast.Module(body=[class_def_node])
    tree_changed, new_tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert not tree_changed
    result = ast.dump(new_tree)
    expected = ast.dump(tree)
    assert result == expected

# Generated at 2022-06-23 23:19:42.601412
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from textwrap import dedent
    from typed_astunparse import unparse

    code = dedent("""
        from typing import Optional
        
        class A:
            def __init__(self):
                super()
                
        class B(A):
            def __init__(self):
                super()  # <-- these
                
        class C(A):
            def __init__(self, x: Optional[int]):
                super(C, self)  # <-- this is Ok
                
        class C:
            def __init__(self, x: Optional[int]):
                super()  # <-- not a class
    """)


# Generated at 2022-06-23 23:19:52.497836
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import register_transformer
    transformer = register_transformer(2.7, SuperWithoutArgumentsTransformer())
    # the result of the transformation is not the same for py2 and py3
    # that's why the test is implemented for both
    assert transformer.compile(ast.parse("""
    class MyClass:
        def __init__(self):
            super()
    """)).strip() == "class MyClass:\n    def __init__(self):\n        super(MyClass, self)"

    transformer = register_transformer(3.6, SuperWithoutArgumentsTransformer())

# Generated at 2022-06-23 23:20:01.557520
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast import ClassDef, FunctionDef
    from ..utils.helpers import generate_dummy_ast, compare_ast
    from .base import BaseNodeTransformer

    class Foo(BaseNodeTransformer):
        @classmethod
        def visit_Call(cls, node):
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not node.args:
                node.args = [ast.Name(id='foo'), ast.Name(id='bar')]
                cls.tree_changed = True

            return node


# Generated at 2022-06-23 23:20:05.238429
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import assert_equal_ast
    source = 'super()'
    assert_equal_ast(
        SuperWithoutArgumentsTransformer().visit(ast.parse(source)),
        ast.parse('super(Cls, self)')
    )

# Generated at 2022-06-23 23:20:10.330463
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        super()
    """
    tree = ast.parse(code)
    t = SuperWithoutArgumentsTransformer()
    new_tree = t.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse("""
        super(Cls, self)
    """))