

# Generated at 2022-06-23 23:10:27.858363
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    
    # Unit test for visit_Call()
    class DummySuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, test_node: ast.AST):
            self._tree = test_node
            self._tree_changed = False

        def generic_visit(self, node: ast.AST) -> ast.AST:
            node = copy.deepcopy(node)
            
            for field, old_value in ast.iter_fields(node):
                if isinstance(old_value, list):
                    new_values = []
                    for value in old_value:
                        if isinstance(value, ast.AST):
                            value = self.visit(value)
                            if value is None:
                                continue
                            elif not isinstance(value, ast.AST):
                                new

# Generated at 2022-06-23 23:10:37.380188
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Cls:
        def meth(self):
            super().unmeth()

    tree = ast.parse(inspect.getsource(Cls))
    SuperWithoutArgumentsTransformer(tree).visit(tree)


# Generated at 2022-06-23 23:10:39.407411
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as _ast
    from typed_ast import ast3
    from ..utils.helpers import as_tuple

    # -- CASE: super().

# Generated at 2022-06-23 23:10:41.340833
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_astunparse import unparse
    import ast
    import sys


# Generated at 2022-06-23 23:10:49.328289
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case = """
        
        class A(object):
            def method(self):
                return super().method() 
        """
    tree = ast.parse(test_case)
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    test_ast = ast.parse("""
        
        class A(object):
            def method(self):
                return super(A, self).method() 
        """)
    assert ast.dump(tree) == ast.dump(test_ast)

    # Testing a case where super() is not called within a class
    test_case = """        
        def method(self):
            return super()"""
    test_ast = ast.parse(test_case)
    tree = ast.parse(test_case)
    t = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:10:51.644399
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit tests for method visit_Call of class SuperWithoutArguments
    """
    # TODO (cpopa): implement
    pass


# Generated at 2022-06-23 23:10:56.983859
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test when super() called not in class
    code = """
    def foo():
        super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert code == astor.to_source(tree)

    # test when super() called not in method
    code = """
    class Abc:
        super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert code == astor.to_source(tree)

    # test when super() called in method
    code = """
    class Abc:
        def foo(self):
            super()
    """

# Generated at 2022-06-23 23:11:03.856303
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test method visit_Call of class SuperWithoutArgumentsTransformer with one test case.
    """
    # Arrange
    node = ast.Call(func=ast.Name(id="super", ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None)

    # Act
    transformer = SuperWithoutArgumentsTransformer(ast.parse("class A: def a(self): super()"), 2.7)
    new_node = transformer.visit_Call(node)

    # Assert
    assert new_node.args == [ast.Name(id='A'), ast.Name(id='self')]

# Generated at 2022-06-23 23:11:09.757897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from ..program import Program
        from .. import options as o

    code = dedent("""\
    class A(object):
        def baz(self):
            super()
    """)

    options = o.Options(target=(2, 7))
    program = Program(code, options)
    program.transform(SuperWithoutArgumentsTransformer)
    assert str(program.tree) == "class A(object):\n    def baz(self):\n        super(A, self)\n"

# Generated at 2022-06-23 23:11:21.006891
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..utils import compile_source
    module_node = compile_source(
        """
        class A:
            def __init__(self):
                super()
                self.super()
        """,
        target=SuperWithoutArgumentsTransformer.target,
        mode='exec',
    )  # type: ast3.Module
    visitor = SuperWithoutArgumentsTransformer(module_node)
    visitor.visit(module_node)

# Generated at 2022-06-23 23:11:28.379080
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    code = "super()"
    tree = ast3.parse(code)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert ast3.dump(tree) == "Module(body=[FunctionDef(name='<module>', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])), Return(value=None)], decorator_list=[], returns=None)])"

# Generated at 2022-06-23 23:11:29.421698
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:30.879535
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parser import PythonParser


# Generated at 2022-06-23 23:11:35.976511
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import test_utils
    from .. import trees
    
    class Test(metaclass=test_utils.SILMeta):
        def test_constructor(self):
            tree = trees.parse_new_syntax('super()')[0]
            transformer = SuperWithoutArgumentsTransformer(tree, '<>')

            assert transformer is not None

# Generated at 2022-06-23 23:11:40.338239
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..transpile import Transpiler
    transpiler = Transpiler()

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree, filename):
            super().__init__(tree, filename)


# Generated at 2022-06-23 23:11:41.218007
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:42.075536
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:11:44.569676
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast
    

# Generated at 2022-06-23 23:11:49.405466
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class MyTree(ast.AST):
        _fields = ("node",)

    test_tree = MyTree(SuperWithoutArgumentsTransformer.visit_Call(None, ast.Call(func=ast.Name(id="super"))))
    assert test_tree.node.func is not None

# Generated at 2022-06-23 23:11:51.212123
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-23 23:11:55.896141
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class A:
        def __init__(self):
            super()
    '''
    tree = ast.parse(code)
    tree2 = SuperWithoutArgumentsTransformer().visit(tree)
    expected = '''class A:
        def __init__(self):
            super(A, self)
    '''
    assert ast.dump(tree2) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:11:59.089436
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    check_visitor = BaseNodeTransformer()
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-23 23:12:06.747842
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import Source, SourceError
    from ..utils.parsing import parse_source

    source_code = 'super()'
    source = Source(source_code)
    tree = parse_source(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer.tree is tree
    assert transformer.tree.body[0].value.args[0].id == 'Cls'
    assert transformer.tree.body[0].value.args[1].id == 'self'
    assert transformer.tree_changed == True

# Generated at 2022-06-23 23:12:17.360348
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree: ast.Module) -> None:
            self._tree = tree
            self._tree_changed = False

        def tree_changed(self) -> bool:
            return self._tree_changed

    tree = ast.parse('super()')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert transformer.tree_changed()
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None)"


# Generated at 2022-06-23 23:12:22.297244
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import should_transform, should_not_transform

    should_transform(SuperWithoutArgumentsTransformer, "super()", "super(Cls, self)")
    should_not_transform(SuperWithoutArgumentsTransformer, "super(a)")
    should_not_transform(SuperWithoutArgumentsTransformer, "super.a()")

# Generated at 2022-06-23 23:12:27.300059
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test call of super() to cls parameter
    super_without_arguments_transform= SuperWithoutArgumentsTransformer()
    super_without_arguments_transform.visit(ast.parse('super()'))
    #test call of super() to self parameter
    super_without_arguments_transform= SuperWithoutArgumentsTransformer()
    super_without_arguments_transform.visit(ast.parse('super()'))

# Generated at 2022-06-23 23:12:36.551835
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    import sys
    import unittest
    from unittest.mock import patch

    class Test(unittest.TestCase):

        def _compile_source(self, source: str):
            tree = compile(source)
            SuperWithoutArgumentsTransformer(tree).visit(tree)
            return tree

        def test_super_without_args(self):
            source_template = \
            '''
            class Cls:
                def __init__(self):
                {0}
            '''
            super_template = '''
                super()
            '''

            source = source_template.format(super_template)
            expected_source = source_template.format('''
                super(Cls, self)
            ''')


# Generated at 2022-06-23 23:12:37.130671
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:12:47.246664
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    source = '''
        class C(object):
            def __init__(self):
                super()
    '''
    tree = ast.parse(source_to_unicode(source))
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    assert transformer.tree_changed

    source = '''
        class C(object):
            def __init__(self):
                super()
    '''
    tree = ast.parse(source_to_unicode(source))
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert transformer.tree_changed is False

    source = '''
        class C(object):
            def __init__(self):
                super(A)
    '''
    tree = ast

# Generated at 2022-06-23 23:12:54.499208
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    tree = ast.parse('super()')
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 0
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'

    trans = SuperWithoutArgumentsTransformer(tree)
    result = trans.visit(tree)

    assert result is tree
    assert trans._tree_changed

    assert result == ast.parse('super(Cls, self)')


# Generated at 2022-06-23 23:12:57.827367
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import parse

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert parse('super(Cls, self)').body[0] == tree.body[0]

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert parse('super(Cls, cls)').body[0] == tree.body[0]

# Generated at 2022-06-23 23:13:08.872516
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from nuitka.ast.nodes import ExpressionFunctionDef, FunctionBody
    from nuitka.ast.nodes import ParameterSpec
    from nuitka.ast.nodes import StatementExpressionOnly
    from nuitka.ast.nodes import StatementReturn
    from nuitka.ast.nodes import ExpressionCall
    from nuitka.ast.nodes import ExpressionClassBody
    from nuitka.ast.nodes import ExpressionClassDef
    from nuitka.ast.nodes import ExpressionVariableRef
    from nuitka.ast.nodes import ExpressionMethodCall
    from nuitka.ast.nodes import ExpressionSelectMetaclass
    from nuitka.ast.nodes import ExpressionOperationBinary
    from nuitka.ast.nodes import ExpressionOperationAND

# Generated at 2022-06-23 23:13:18.881892
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..tokenize import tokenize
    from ..parse import parse
    from .. import fix_missing_locations

    class DummyVisitor(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and len(node.args) == 2:
                assert isinstance(node.args[0], ast.Name)
                assert node.args[0].id == 'Cls'

                assert isinstance(node.args[1], ast.Name)
                assert node.args[1].id == 'self'

            self.generic_visit(node)


# Generated at 2022-06-23 23:13:25.793433
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import as_tuple
    from .base import BaseNodeTransformer
    from .nodes import NameNode
    from .nodes import CallNode
    from .nodes import FunctionDefNode
    from .nodes import ClassDefNode

    node = CallNode(
        func=NameNode(id='super'),
        args=[],
        keywords=[]
    )

# Generated at 2022-06-23 23:13:26.159097
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-23 23:13:34.268116
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_on_lines
    from ..utils.helpers import get_name_node, get_func_args_node
    from ..utils.source_tree import SourceTree

    source = \
    """
    class Foo(object):
        def foo():
            super()
    """
    source_tree = SourceTree(source)
    tree = source_tree.ast
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    cls = get_name_node(tree, 'Foo')
    func = get_name_node(tree, 'foo')
    args = get_func_args_node(func)
    super_call = \
        tree.body[0].body[0].body[0]

    assert isinstance(super_call, ast.Expr)

# Generated at 2022-06-23 23:13:37.538202
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import generate_code_and_compare_ast

    def test_case(src: str) -> None:
        generate_code_and_compare_ast(src, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-23 23:13:44.111753
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast
    import ast
    module_node = """
    class Foo:
        def __init__(self):
            super()

    class Bar(Foo):
        def __init__(self):
            super().__init__()
    """
    tree = source_to_ast(module_node)
    SuperWithoutArgumentsTransformer.run_on_tree(tree)
    assert "super(Foo, self)" in ast.dump(tree)
    assert "super(Foo, cls)" not in ast.dump(tree)
    assert "super" not in ast.dump(tree)

# Generated at 2022-06-23 23:13:50.157925
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...unit_tests.utils import compile_and_run_unittest
    from .fixer_utils import format_code
    node = ast.parse(format_code('''
    class A:
        def a(self):
            super()
            super().b
            super(C, self)
    
    class B(A):
        def b(self):
            super()
    
    def f():
        super()
    '''))
    expected = format_code('''
    class A:
        def a(self):
            super(A, self)
            super().b
            super(C, self)
    
    class B(A):
        def b(self):
            super(B, self)
    
    def f():
        super()
    ''')
    compile_and_run

# Generated at 2022-06-23 23:14:00.047183
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import compile_func, round_trip
    code1 = '''def f():
        super()'''
    code2 = '''def f():
        super(Cls, self)'''
    tree = compile_func(code1, 'f', 'exec')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert round_trip(tree) == code2
    code3 = '''def f():
        super()
        def g():
            super()'''
    code4 = '''def f():
        super(Cls, self)
        def g():
            super(Cls, self)'''
    tree2 = compile_func(code3, 'f', 'exec')
    transformer2 = SuperWithoutArgumentsTrans

# Generated at 2022-06-23 23:14:02.755017
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(0, 1)
    tree = ast.parse("""class Cls(object):
                            def func(self):
                                super()
                        """)
    transformer.visit(tree)
    assert transformer._tree_changed
    eval(compile(tree, "<test>", "exec"))

# Generated at 2022-06-23 23:14:03.413139
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import utils

# Generated at 2022-06-23 23:14:09.601527
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astunparse import unparse
    from ..utils.helpers import get_ast
    from .renamer import RenameClasses, RenameFunctions, RenameVariables
    from .remove_future_statements import RemoveFutureStatements
    from .remove_imports import RemoveImports
    from .remove_pass_statements import RemovePassStatements
    from typed_ast import ast3
    source = '''
    from __future__ import annotations
    class A:
        def b(self):
            super()
    '''
    tree = get_ast(source)
    tree = RenameClasses('A', 'B', tree)
    tree = RenameFunctions('b', 'd', tree)
    tree = RenameVariables('self', 'self2', tree)
    tree = RemoveFutureStatements(tree)
    tree

# Generated at 2022-06-23 23:14:16.104506
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode

    tree = ast.parse(source_to_unicode("""
    class A(object):
        def __init__(self):
            super()
    """))

    actual = SuperWithoutArgumentsTransformer(tree).result()
    expected = ast.parse(source_to_unicode("""
    class A(object):
        def __init__(self):
            super(A, self)
    """))

    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 23:14:26.376946
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Foo(object):
            def hook(self):
                super()
    """
    tree = ast.parse(code)
    transf = SuperWithoutArgumentsTransformer(tree)
    transf.run()

# Generated at 2022-06-23 23:14:30.540736
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast 
    # example code
    code = '''class Cls:
        def __init__(self):
            super()
        '''
    # ast3 test
    module = ast.parse(code)

    # walk to transform
    transformer = SuperWithoutArgumentsTransformer()
    new_module = transformer.visit(module)

    # compare ast before and after
    assert ast.dump(module) == ast.dump(new_module)

# Generated at 2022-06-23 23:14:41.103325
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..utils import tree
    from ..utils import helpers
    from .. import exceptions
    from . import base
    # Unit test for constructor of class SuperWithoutArgumentsTransformer
    # __init__(self) -> NoneType
    __DUMMY_12 = None
    assert SuperWithoutArgumentsTransformer().__class__ == SuperWithoutArgumentsTransformer
    # pass

    # Unit test for _replace_super_args(self, node: ast3.Call) -> NoneType
    # pass

    # Unit test for visit_Call(self, node: ast3.Call) -> ast3.Call
    __DUMMY_12 = None

# Generated at 2022-06-23 23:14:42.447798
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-23 23:14:52.087997
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from .base import BaseNodeTransformerTest
    from ..utils.helpers import dump_node_tree, load_node_tree, assert_node_tree

    class SuperWithoutArgumentsTransformerTest(BaseNodeTransformerTest):
        target_transformer = SuperWithoutArgumentsTransformer
        target_version = (2, 7)
        tree_transformer = SuperWithoutArgumentsTransformer

        def _load_transformed_tree(self) -> ast.AST:
            return load_node_tree(self.test_dir / 'super.py')

        def _load_source_tree(self) -> ast.AST:
            return source_to_nodes('''
                class A:
                    def func(self):
                        super()
            ''')

    instance = SuperWithoutArg

# Generated at 2022-06-23 23:15:02.252179
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import get_node_of_type

    # INPUT
    input = '''
    class A:
        def __init__(self):
            super()
    class B(A):
        def __init__(self):
            super()
    '''

    # EXPECTED
    expected = '''
    class A:
        def __init__(self):
            super(A, self)
    class B(A):
        def __init__(self):
            super(B, self)
    '''

    # TREE
    tree = ast.parse(input)  # type: ignore

    # TEST
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)

    transformer.finalize()
    assert transformer.tree

# Generated at 2022-06-23 23:15:10.183213
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Arrange
    input = '''
        class Foo:
            def __init__(self):
                super()
    '''
    expected1 = '''
        class Foo:
            def __init__(self):
                super(Foo, self)
    '''
    expected2 = '''
        class Foo:
            def __init__(self, self):
                super(Foo, self)
    '''
    tree = ast.parse(input)
    node = tree.body[0]
    func = node.body[0]
    call = func.body[0]

    # Act
    SuperWithoutArgumentsTransformer(tree).visit(call)

    # Assert
    assert ast.dump(tree) == ast.dump(ast.parse(expected1))

# Generated at 2022-06-23 23:15:20.508557
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def target(node):
        return ast.Call(ast.Name(id='super', ctx=ast.Load()), [], [], None, None)

    def visitor(node):
        return node

    tree = ast.parse(target.__code__)
    visitor = SuperWithoutArgumentsTransformer(tree=tree, target_version=(2, 7))
    visitor.visit(tree)
    assert isinstance(tree.body[0].body[0], ast.Expr)
    new_super = tree.body[0].body[0].value
    assert isinstance(new_super.func, ast.Name)
    assert new_super.func.id == 'super'
    assert len(new_super.args) == 2
    assert isinstance(new_super.args[0], ast.Name)
    assert new_super

# Generated at 2022-06-23 23:15:28.478197
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '\n'.join([
        'class A:',
        '    pass',
        '',
        'class B(A):',
        '    def m(self, x):',
        '        super()',
    ])

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '<test>', 'exec')

    a = type('A', tuple(), {})
    b = type('B', (a,), {'m': lambda self, x: super(b, self)})

    ns = {}
    exec(compiled, ns)
    assert type('B', (a,), {'m': lambda self, x: super(b, self)}) == ns['B']

# Generated at 2022-06-23 23:15:29.251089
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:15:38.063312
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class A: def __init__(self): super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "ClassDef(name='A', bases=[], keywords=[], body=[FunctionDef(name='__init__', args=arguments(args=[arg('self', None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='A', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)], decorator_list=[])"

# Generated at 2022-06-23 23:15:45.573457
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import ast_helpers
    import textwrap

    source = textwrap.dedent("""
    class Foo:
        def method(self):
            super()
    """)

    tree = ast.parse(source, mode='exec')
    SuperWithoutArgumentsTransformer().visit(tree)

    source = ast_helpers.to_source(tree)
    expected = textwrap.dedent("""
    class Foo:
        def method(self):
            super(Foo, self)
    """)

    assert source == expected



# Generated at 2022-06-23 23:15:48.211998
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_helpers import assert_transformed_code


# Generated at 2022-06-23 23:15:49.912264
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..utils.setup import setup_transformer

# Generated at 2022-06-23 23:15:55.718025
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    sut = SuperWithoutArgumentsTransformer()

    tree = ast.parse("""
super()
""", feature_version=3.8)  # typed_ast does not support 3.9 yet

    ref_tree = ast.parse("""
super(A, self)
""", feature_version=3.8)  # typed_ast does not support 3.9 yet

    call = next(ast.walk(tree))  # type: ignore
    sut.visit(call)

    assert_source_equal(tree, ref_tree)

# Generated at 2022-06-23 23:15:56.504126
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:04.468094
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_transform, parse_function, parse_class
    from ..tests.test_replacer import find_node_of_type

    def example():
        super()

    def expected():
        super(Example, self)

    st, fn = parse_function(example)
    st, cls = parse_class(expected)

    cn = find_node_of_type(fn, ast.Call)
    assert cn

    SuperWithoutArgumentsTransformer(st).visit(fn)

    assert_transform(fn, cls, lambda node: not isinstance(node, ast.ClassDef))



# Generated at 2022-06-23 23:16:06.194646
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import parse


# Generated at 2022-06-23 23:16:08.767005
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast_from_code
    from ..scope import Scope
    

# Generated at 2022-06-23 23:16:16.850800
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A(object):
            def __init__(self):
                super()
    
        class B(A):
            def __init__(self, value):
                super()
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert (
        astor.to_source(tree)
        ==
        '''
            class A(object):
    
                def __init__(self):
                    super(A, self)
    
            class B(A):
    
                def __init__(self, value):
                    super(B, self)
        '''
    )

# Generated at 2022-06-23 23:16:17.612658
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:23.370099
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_utils import source_to_tree

    tree = source_to_tree(
        path='test/fixtures/transforms/super_without_arguments.py'
    )

    node_transformer = SuperWithoutArgumentsTransformer()
    visit_node = TestVisitor(node_transformer)
    visit_node(tree)
    code = tree_to_code(tree)
    assert code == 'class Cls:\n    def foo(self):\n        super(Cls, self)'

# Generated at 2022-06-23 23:16:30.709168
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Tests that the method visit_Call of this class replaces super() by super(cls, self) inside
    # methods of classes when only called without arguments.
    from ..utils.source import source_to_unicode
    from ..utils import compile_source

    source = source_to_unicode("""
        class TestClass(object):
            def test(self):
                print(super())
    """)

    tree = compile_source(source, __name__ + '.test_SuperWithoutArgumentsTransformer_visit_Call()')
    assert isinstance(tree, ast.Module)

    cls = tree.body[0]
    assert isinstance(cls, ast.ClassDef)

    method = cls.body[0]
    assert isinstance(method, ast.FunctionDef)

    call = method.body[0]
   

# Generated at 2022-06-23 23:16:32.092090
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.node_utils import parse_node

# Generated at 2022-06-23 23:16:33.021226
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:16:35.718086
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    import typed_ast.ast3 as typed_ast
    import astor


# Generated at 2022-06-23 23:16:46.517198
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()
    tree = ast.parse("super()")
    t.visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])"
    t = SuperWithoutArgumentsTransformer()
    tree = ast.parse("super(p1, p2)")
    t.visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='p1', ctx=Load()), Name(id='p2', ctx=Load())], keywords=[])"

# Generated at 2022-06-23 23:16:53.457772
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(code).visit(tree)
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert isinstance(tree.body[0].value.args[1], ast.Name)
    assert tree.body[0].value.args[1].id == 'cls'


# Generated at 2022-06-23 23:17:03.791543
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert_code_equal(
        """
        class A:
            def b(self):
                super()
        """,
        """
        class A:
            def b(self):
                super(A, self)
        """,
        transformers=[SuperWithoutArgumentsTransformer]
    )

    assert_code_equal(
        """
        class A:
            def b(cls):
                super()
        """,
        """
        class A:
            def b(cls):
                super(A, cls)
        """,
        transformers=[SuperWithoutArgumentsTransformer]
    )


# Generated at 2022-06-23 23:17:14.321831
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def __init__(self):
                super()
        class B:
            def __init__(self, a):
                super()
        class C:
            def __init__(self, a, b):
                super(A, self)
        class D:
            def __init__(self, a, b):
                super(cls=A, self=self)
    '''

# Generated at 2022-06-23 23:17:21.560707
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import os
    sys.path.append(os.path.realpath('..'))
    from tests.utils import expect_no_warnings, expect_warning
    
    source = """
            class A:
                def f(self):
                    super()

            class C:
                def f(abc):
                    super()
        """
    expected_result = """
            class A:
                def f(self):
                    super(A, self)
                    
            class C:
                def f(abc):
                    super(C, abc)
        """
    tree = ast.parse(source)
    expect_no_warnings(SuperWithoutArgumentsTransformer, tree)
    assert(ast.dump(tree) == ast.dump(ast.parse(expected_result)))


# Generated at 2022-06-23 23:17:31.538293
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # fixture
    super_call_0 = ast.parse("super()").body[0].value
    super_call_1 = ast.parse("super(a, b)").body[0].value
    super_call_2 = ast.parse("super(a, b, c)").body[0].value
    # tests
    assert isinstance(super_call_0, ast.Call)
    assert isinstance(super_call_1, ast.Call)
    assert isinstance(super_call_2, ast.Call)
    assert isinstance(super_call_0.func, ast.Name)
    assert isinstance(super_call_1.func, ast.Name)
    assert isinstance(super_call_2.func, ast.Name)
    assert super_call_0.func.id == 'super'
    assert super

# Generated at 2022-06-23 23:17:33.041783
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import as_tuple


# Generated at 2022-06-23 23:17:34.013810
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:39.869613
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import transformer as parser
    from . import tests_common as common
    example = common.EXAMPLES[4]
    tree = parser.parse(example)

    visitor = SuperWithoutArgumentsTransformer(tree)
    visitor.run()
    new_example = common.dump_tree(visitor.tree)

    assert new_example != example
    assert new_example == common.dump_tree(parser.parse(common.EXAMPLES[24]))


# Generated at 2022-06-23 23:17:44.133396
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import TransformCode
    from .fixes import SuperWithoutArgumentsTransformer

    code = """
        def foo(self):
            super(A, self).__init__()
    """
    expected_code = """
        def foo(self):
            super(A, self).__init__()
    """
    t = TransformCode()
    t.register_transformer(SuperWithoutArgumentsTransformer)
    new_code = t.transform_code(code)

    assert new_code == expected_code

# Generated at 2022-06-23 23:17:54.204164
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest
    from ..utils.helpers import node_to_str, compile_to_ast

    class TestCase(unittest.TestCase):
        def test_it(self):
            src = 'super()'
            expected = 'super(Cls, self)'
            # First, compile src to AST
            tree = compile_to_ast(src)
            # Then, apply the transformer to the AST
            transformer = SuperWithoutArgumentsTransformer()
            with transformer.visit():
                tree.body[0].value.args[0] = ast.Name(id='self')
            # Finally, compile the transformed AST to source code, and compare
            # the result with `expected`
            self.assertEqual(
                node_to_str(tree),
                expected
            )

    unittest.main()

# Generated at 2022-06-23 23:17:57.607226
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == code

# Generated at 2022-06-23 23:17:58.189908
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:17:59.650785
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_str

# Generated at 2022-06-23 23:18:04.455459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "class A: def __init__(self): super()"
    expected = "class A: def __init__(self): super(A, self)"
    tree = ast.parse(code)
    t = SuperWithoutArgumentsTransformer()
    newtree = t.visit(tree)
    assert ast.dump(newtree) == expected



# Generated at 2022-06-23 23:18:05.543478
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:15.002268
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import astunparse

    class TestPlugin(unittest.TestCase):
        def test_method_parent(self):
            class MyTestPlugin(BaseNodeTransformer):
                class visitor(BaseNodeVisitor):
                    def visit_Call(self, node: ast.Call) -> ast.Call:
                        return node.func

                def visit_Call(self, node: ast.Call) -> ast.Call:
                    self.parent = self.visit(node.args[0])
                    return node

            code = '''
            class A:
                def __init__(self):
                    a = lambda x: x + 1
                    a(super())
            '''


# Generated at 2022-06-23 23:18:18.591916
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import load_example_snippets

    snippets = load_example_snippets()

    for tag, code in snippets.items():
        tree = ast.parse(code)
        SuperWithoutArgumentsTransformer(tree).visit(tree)
        print(astor.to_source(tree))
        break

# Generated at 2022-06-23 23:18:21.820644
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_tools import generate_test, assert_test
    print("\n"+"-"*80+"\n"+"test SuperWithoutArgumentsTransformer:")

    # before -------------------------------

# Generated at 2022-06-23 23:18:27.661189
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    inp = """
        def foo():
            super()
        """

    outp = """
        def foo():
            super(C, self)
        """

    tree = ast.parse(inp)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert_code_equal(compat.to_source(tree), outp)



# Generated at 2022-06-23 23:18:30.150890
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import tree
    from .. import compile_to_class
    from ..utils import helpers
    from ..exceptions import Py2CException

# Generated at 2022-06-23 23:18:31.120091
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:32.412006
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor


# Generated at 2022-06-23 23:18:33.632280
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from .classes import ClassTransformer


# Generated at 2022-06-23 23:18:35.183775
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:18:35.956451
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:18:38.199874
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # assertEqual(expected, SuperWithoutArgumentsTransformer(pyversion, tree).visit(node))
    raise SkipTest # TODO: implement your test here


# Generated at 2022-06-23 23:18:40.150070
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils import update_fields
    from ..utils.helpers import FakeTree


# Generated at 2022-06-23 23:18:41.950751
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing the constructor of class SuperWithoutArgumentsTransformer."""

# Generated at 2022-06-23 23:18:51.737092
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import _fixtures.nodes as nodes

    transformer = SuperWithoutArgumentsTransformer(tree=None)

    source = """
    super()
    """

    tree = compile(source, '<string>', "exec", _ast.PyCF_ONLY_AST)
    transformer.visit(tree)

    expected = ast.Module(
        body=[
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='super'),
                    args=[
                        ast.Name(id='Cls1'),
                        ast.Name(id='self'),
                    ],
                    keywords=[],
                    starargs=None,
                    kwargs=None,
                )
            )
        ]
    )

    assert tree == expected

# Generated at 2022-06-23 23:19:00.516492
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    module = ast.parse(code)
    module = SuperWithoutArgumentsTransformer.run(module)
    assert module is not None
    assert(len(module.body) == 1)
    assert(len(module.body[0].body) == 1)
    assert(len(module.body[0].body[0].args.args) == 1)
    assert(len(module.body[0].body[0].body) == 1)
    assert(len(module.body[0].body[0].body[0].value.args) == 2)
    assert(isinstance(module.body[0].body[0].body[0].value.func, ast.Name))
    assert(module.body[0].body[0].body[0].value.func.id == 'super')

# Generated at 2022-06-23 23:19:01.677687
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:19:06.837295
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)
    code = 'super()'
    tree = ast.parse(code)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    transformer.visit(node)
    assert isinstance(node.value, ast.Call)
    assert node.value.args == [ast.Name(id='Cls'), ast.Name(id='self')]
    assert node.value.func.id == 'super'


# Generated at 2022-06-23 23:19:09.453725
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typing import Callable, Tuple
    from typed_ast import ast3 as ast

    from ..utils.syntax_tree_visitor import visit_syntax_tree


# Generated at 2022-06-23 23:19:10.008440
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:19:13.658569
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Simple test case
    class ASTNodeInstance(ast.AST):
        _fields = ("a",)

    super_node = ASTNodeInstance(a=3)
    node = ASTNodeInstance(super_node)


# Generated at 2022-06-23 23:19:21.697715
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .helper import get_ast
    from .helper import compare_trees
    from .helper import ast_to_str
    from .helper import TreeInstance
    from .helper import textwrap

    module = get_ast(textwrap.dedent('''\
    class Foo:
        def __init__(self):
            super()
    '''))

    tree = TreeInstance(module)
    tree.register_transformer(SuperWithoutArgumentsTransformer)
    tree.apply_transforms()
    assert ast_to_str(module) == textwrap.dedent('''\
    class Foo:
        def __init__(self):
            super(Foo, self)
    ''')

    assert tree.has_changed

# Generated at 2022-06-23 23:19:26.134861
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code_tree = ast.parse('super()')
    code = compile(code_tree, '<string>', mode='exec')

    tree = get_ast(code)

    transformer = SuperWithoutArgumentsTransformer(tree, target=None)

    transformer.visit(tree)

    assert transformer._tree_changed == True
    assert ast.dump(tree) == ast.dump(ast.parse('super(Cls, self)'))

# Generated at 2022-06-23 23:19:29.294474
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from py2ts.utils.tree import dump_tree
    from typed_ast import ast3 as ast
    from py2ts.transformers.super_without_arguments import SuperWithoutArgumentsTransformer


# Generated at 2022-06-23 23:19:39.134553
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    """
    import inspect
    import textwrap
    import astor
    import ast

    module_ast, expected_ast = ast.parse(textwrap.dedent(inspect.cleandoc(
        '''
        class Test:
            def __init__(self):
                super()
        '''
    ))), ast.parse(textwrap.dedent(inspect.cleandoc(
        '''
        class Test:
            def __init__(self):
                super(Test, self)
        '''
    )))

    node_transformer = SuperWithoutArgumentsTransformer()
    node_transformer.visit(module_ast)
    

# Generated at 2022-06-23 23:19:44.793599
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from typed_astunparse import unparse

    tree = ast.parse("""
    class A:
        def __init__(self, a):
            super().__init__(a)
    """)

    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == "class A:\n\tdef __init__(self, a):\n\t\tsuper(A, self).__init__(a)\n"
    assert unparse(tree) == "class A:\n    def __init__(self, a):\n        super(A, self).__init__(a)\n"


# Generated at 2022-06-23 23:19:55.339516
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_tree
    from ..utils.tree import dump
    from ..utils import compile

    class DummyTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases.append(ast.Name('Dict', ast.Load()))
            return node

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            if node.name != 'hello':
                return node

            ast.Assign(
                targets=[
                    ast.Name('__super', ast.Store())
                ],
                value=ast.Call(
                    func=ast.Name(id='super'),
                    args=[],
                    keywords=[],
                )
            )


# Generated at 2022-06-23 23:19:56.335193
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-23 23:20:01.382248
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
            class A:
                def __init__(self):
                  super()
                  pass
    '''
    expected_code = '''
            class A:
                def __init__(self):
                  super(A, self)
                  pass
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 23:20:05.518836
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()

    # When
    transformer.visit(tree)
    # Then
    assert str(tree) == "super(__class__, self)"



# Generated at 2022-06-23 23:20:09.618328
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    expected = 'super(Cls, self)'
    result = astor.to_source(tree).strip()
    assert result == expected, result

# Generated at 2022-06-23 23:20:14.371264
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse(
        'super()'
    )
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert node.body[0].value.args[0].id == 'Cls'
    assert node.body[0].value.args[1].id == 'self'

# Generated at 2022-06-23 23:20:20.351740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class A:
        def test(self):
            super()
    """
    tree = ast.parse(input)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    output = """
    class A:
        def test(self):
            super(A, self)
    """
    assert str(tree) == output