

# Generated at 2022-06-22 18:38:28.645867
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    fake_parser = argparse.ArgumentParser()
    UnrecognizedArgument(option_strings=['-x'], dest='example', help='example help')

#
# Basic OptionsParsers
#

# Generated at 2022-06-22 18:38:33.070606
# Unit test for function add_fork_options
def test_add_fork_options():
    option = add_fork_options(prog)
    parser = argparse.ArgumentParser()
    assert option == parser._add_action(option)

# Generated at 2022-06-22 18:38:38.079569
# Unit test for function add_runtask_options
def test_add_runtask_options(): # pragma: no cover
    from optparse import OptionParser
    args = ['-e', 'a=b', '-e', 'c=d']
    opts = OptionParser().parse_args(args)
    assert opts.extra_vars == ['a=b', 'c=d']
    assert option_help_json(opts) == {'extra_vars': ['a=b', 'c=d']}



# Generated at 2022-06-22 18:38:49.114624
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class Parser(argparse.ArgumentParser):
        def exit(self, status=0, message=None):
            pass

    parser = Parser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction, nargs='?')
    parser.add_argument('--baz', action=PrependListAction, nargs=1)
    parser.add_argument('--qux', action=PrependListAction, nargs='*')
    parser.add_argument('--quux', action=PrependListAction, nargs=2)
    parser.add_argument('--corge', action=PrependListAction, const=42, nargs='?')

# Generated at 2022-06-22 18:38:52.485975
# Unit test for function add_fork_options
def test_add_fork_options():
    """
    add_fork_options in option_parsers module.
    These tests are partially to evaluate add_fork_options for different types of inputs.
    """

    # Invalid fork option
    parser_1 = argparse.ArgumentParser()
    end_result_1 = add_fork_options(parser_1)
    assert(end_result_1 == None)

    # Valid fork option
    parser_2 = argparse.ArgumentParser()
    end_result_2 = add_fork_options(parser_2)
    assert(end_result_2 == None)



# Generated at 2022-06-22 18:38:55.860060
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    options = parser.parse_args(['--task-timeout', '3600'])
    assert options.task_timeout == 3600
    options = parser.parse_args(['--task-timeout'])
    assert options.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-22 18:39:06.740271
# Unit test for function add_runas_options
def test_add_runas_options():

    def set_env(var, val):
        os.putenv(var, val)

    def test_env(var, val):
        os.environ[var] = val

    class util_test_args:

        @staticmethod
        def get(args, arg):
            return getattr(args, arg)

    class mocked_parser:

        def __init__(self):
            self._arg_group = {}
            self._group_name = None
            self._args = []

        def add_argument_group(self, group_name, *args):
            #print "adding group {}".format(group_name)
            self._group_name = group_name
            self._args.append(('add_argument_group', group_name, args))
            return self


# Generated at 2022-06-22 18:39:11.105212
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = Mock()
    add_vault_options(parser)
    parser.add_argument.assert_any_call('--vault-id', default=[], dest='vault_ids', action='append', type=str,
                        help='the vault identity to use')
    parser.add_mutually_exclusive_group.assert_called_once_with()
    base_group = parser.add_mutually_exclusive_group.return_value
    base_group.add_argument.assert_any_call('--ask-vault-password', '--ask-vault-pass', default=C.DEFAULT_ASK_VAULT_PASS, dest='ask_vault_pass', action='store_true',
                            help='ask for vault password')

# Generated at 2022-06-22 18:39:17.598061
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert parser.parse_args(['-b']).become
    assert parser.parse_args(['--become']).become
    assert parser.parse_args(['--become-method', 'sudo']).become_method == 'sudo'
    assert parser.parse_args(['--become-user', 'asdf']).become_user == 'asdf'



# Generated at 2022-06-22 18:39:23.115859
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == unfrackpath('/etc/ansible')
    assert unfrack_path()('/etc/ansible/') == unfrackpath('/etc/ansible')
    assert unfrack_path(True)('/etc/ansible:/etc/ansible') == [unfrackpath('/etc/ansible'), unfrackpath('/etc/ansible')]


# Generated at 2022-06-22 18:39:31.036130
# Unit test for function create_base_parser
def test_create_base_parser():
    ping_pong = '''command [options]

Command line tool for execution of Ansible playbooks.

General Options:
  -h, --help               show this help message and exit
  -v, --verbose            verbose mode (-vvv for more, -vvvv to enable
                           connection debugging)
  --version                show program's version number, config file
                           location, configured module search path, module
                           location, executable location and exit
'''
    argv = ['ping']
    parser = create_base_parser('ping', usage=None)
    result = parser.format_help()
    assert result == ping_pong



# Generated at 2022-06-22 18:39:38.940432
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
  g_output = None
  class Namespace:
    def __init__(self, items=None):
      self.items = items
  class Parser:
    def exit(self):
      global g_output
      g_output = self.message % self.args
  arg = Parser()
  arg.message = 'unrecognized arguments: %s'
  arg.args = '--non-existing_option'
  act = PrependListAction('--non-existing_option'.split(' '), 'items')
  act(arg, Namespace(), [], '--non-existing_option')
  assert g_output == 'unrecognized arguments: --non-existing_option'
  def assertEqual(a, b):
    assert a == b
  arg = Parser()
  arg.dest = 'items'

# Generated at 2022-06-22 18:39:39.952889
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser=argparse.ArgumentParser(description='add runtask options')
    add_runtask_options(parser)

# Generated at 2022-06-22 18:39:45.603199
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ansible-vault')
    add_vault_options(parser)
    args = parser.parse_args(['create', 'test.yml', '--vault-password-file', 'vault_pass.txt'])
    assert args.vault_password_files[0] == 'vault_pass.txt', "vault_password_files is not matching"


# Generated at 2022-06-22 18:39:50.007840
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_basedir_options(parser)
    options, args = parser.parse_known_args(['--playbook-dir', 'directory'])
    assert options.basedir == 'directory'


# Generated at 2022-06-22 18:39:58.843178
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('$')('$/tmp/abc') == '$/tmp/abc'
    # path should not contain ~/ when HOME is not set
    assert maybe_unfrack_path('$')('~/tmp/abc') == '$tmp/abc'
    # path should contain only ~/ when HOME is set
    home_tmp = os.environ.get('HOME') + '/tmp/abc'
    assert maybe_unfrack_path('$')(home_tmp) == '$' + home_tmp
    assert maybe_unfrack_path('$')('$tmp/abc') == '$tmp/abc'

# Generated at 2022-06-22 18:40:04.331801
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    assert parser.parse_args([]).check is False
    assert parser.parse_args([]).diff is C.DIFF_ALWAYS
    assert parser.parse_args(['-C']).check is True
    assert parser.parse_args(['-D']).diff is True
    assert parser.parse_args(['--syntax-check']).syntax is True



# Generated at 2022-06-22 18:40:06.337802
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # minimal instantiation and behavior test
    argparse.ArgumentParser()
    AnsibleVersion()


# Generated at 2022-06-22 18:40:13.340984
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog='test')
    add_verbosity_options(parser)
    arguments = ['-v', '-v', '-v', '-v', '-v', '-v', '-v', '-v', '-v', '-v', '-v', '-v', '-v']
    assert 1 == parser.parse_args(arguments).verbosity



# Generated at 2022-06-22 18:40:16.274967
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    ua = UnrecognizedArgument(['-u', '--unrecognized'], 'unrecognized')



# Generated at 2022-06-22 18:40:19.233868
# Unit test for function add_module_options
def test_add_module_options():
    prog=str('--module-path')
    usage=str('')
    desc=str('')
    epilog=str('')
    create_base_parser(prog,usage,desc,epilog)
    assert_equal(prog, parser.prog)
    assert_equal(usage, parser.usage)
    assert_equal(desc, parser.description)
    add_module_options(parser)
    assert_equal('-M', parser.module_path)



# Generated at 2022-06-22 18:40:27.461162
# Unit test for function add_vault_options
def test_add_vault_options():
    result = {}
    parser = argparse.ArgumentParser(description='Test for add_vault_options')
    add_vault_options(parser)
    args = parser.parse_args(args=[])
    result['vault_ids'] = args.vault_ids
    result['ask_vault_pass'] = args.ask_vault_pass
    assert list == type(result['vault_ids']), "add_vault_options returns unexpected task_timeout type in parsed args"
    assert not result['ask_vault_pass'], "add_vault_options returns unexpected ask_vault_pass in parsed args"

# Generated at 2022-06-22 18:40:34.473426
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    import tempfile
    p = create_base_parser(prog='test_add_verbosity_options', usage='', desc='', epilog='')
    with tempfile.NamedTemporaryFile() as tf:
        test_string = '--verbose -vvvv \n--verbose=4'
        tf.write(to_bytes(test_string))
        tf.flush()
        p.add_argument('--verbose', dest='verbosity', default=C.DEFAULT_VERBOSITY, action="count",
                       help="verbose mode (-vvv for more, -vvvv to enable connection debugging)")
        args = p.parse_args(['@{tf.name}'.format(tf=tf).split()])
        assert args.verbosity == 4, 'verbosity parameter did not set correctly'

# Generated at 2022-06-22 18:40:37.562929
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)
    assert parser.add_argument.call_args_list[0] == call('--force-handlers', default=C.DEFAULT_FORCE_HANDLERS, dest='force_handlers', action='store_true',
                        help="run handlers even if a task fails")
    assert parser.add_argument.call_args_list[1] == call('--flush-cache', dest='flush_cache', action='store_true',
                        help="clear the fact cache for every host in inventory")



# Generated at 2022-06-22 18:40:42.138069
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(args=[])
    assert args.inventory == []
    args2 = parser.parse_args(args=['-i', 'inven'])
    assert args2.inventory == ['inven']


# Generated at 2022-06-22 18:40:48.772575
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    (options, args) = parser.parse_known_args(['-M', '/foo:/bar'])
    assert options.module_path == ['/foo', '/bar']


# Generated at 2022-06-22 18:40:51.228209
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.print_help()



# Generated at 2022-06-22 18:40:59.941665
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        def __init__(self):
            self.name = None
        def __getattr__(self, key):
            if key == 'name':
                return self.__dict__[key]
    class Namespace1(object):
        def __init__(self):
            self.name = 1
    n = Namespace()
    n1 = Namespace1()

    assert ensure_value(n, 'name', 2) == 2
    assert n.name == 2

    assert ensure_value(n1, 'name', []) == 1
    assert n1.name == 1



# Generated at 2022-06-22 18:41:11.959571
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    class __Tmp:
        def error(self, msg):
            self.error_msg = msg

    class __Tmp2(argparse.ArgumentParser):
        _optionals = None
        _positionals = None

        def __init__(self):
            super(__Tmp2, self).__init__()
            self._optionals = __Tmp()

        def error(self, msg):
            self._optionals.error(msg)

    parser = __Tmp2()
    action = parser._add_action(UnrecognizedArgument('-h', '-h'))
    action(parser, None, None, '-h')
    if 'unrecognized arguments: -h' != parser._optionals.error_msg:
        raise AssertionError(parser._optionals.error_msg)
test_Unrecogn

# Generated at 2022-06-22 18:41:16.590658
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    # parser defaults to the number of cpus in the system
    args, extra_args = parser.parse_known_args(args=['-f', '2'])
    assert args.forks == 2



# Generated at 2022-06-22 18:41:23.173602
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.config.arguments import PrependListAction
    from ansible.config.argparse import _Namespace
    prepend_action = PrependListAction(option_strings=['-a'], dest='dest', default=[], help=None)
    namespace = _Namespace(dest=[])
    prepend_action(parser=None, namespace=namespace, values=['value1', 'value2'], option_string=None)
    assert namespace.dest == ['value1', 'value2']



# Generated at 2022-06-22 18:41:29.502748
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class MyParser(argparse.ArgumentParser):
        def error(self, msg):
            pass

    parser = MyParser()
    parser.add_argument('--val', type=int, action=PrependListAction, nargs='+')
    try:
        parser.parse_args(['--val', '1', '2', '3'])
    except BaseException as e:
        assert False, "Failed to instantiate PrependListAction: %s" % e



# Generated at 2022-06-22 18:41:36.210109
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    parser.add_argument('-T', '--timeout', dest='timeout', type=int, default=30, help='override the connection timeout in seconds')
    parser.add_argument('-W', '--websocket-workaround', action='store_true', default=False, dest='websocket_workaround', help='passing this option will enable the workaround, which is needed on some OS/Python combinations')
    parser.add_argument('-X', '--extra-vars', dest='extra_vars', action='append', type=parse_extra_vars, default=[], help='set additional variables as key=value or YAML/JSON')

# Generated at 2022-06-22 18:41:43.028261
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--z', action="store_true")
    parser.add_argument('--a', action="store_true")
    parser.add_argument('--m', action="store_true")

    expected = '''usage: <BLANKLN>

optional arguments:
  --a            
  --m            
  --z            
'''
    res = parser.format_help()
    assert expected == res


# Generated at 2022-06-22 18:41:52.913435
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_runas_prompt_options(parser)
    assert parser._actions[5].dest == 'become_password_file'
    assert parser._actions[5].metavar == 'BECOME_PASS_FILE'
    assert parser._actions[5].default == '/etc/ansible/become_pass'
    assert parser._actions[5].help == 'Become password file'
    assert parser._actions[5].type(0) == '/etc/ansible/become_pass'
    assert parser._actions[5].type('/path/to/file') == '/path/to/file'
    assert parser._actions[5].type('/path/to/file ') == '/path/to/file/'

# Generated at 2022-06-22 18:41:58.297737
# Unit test for function add_check_options
def test_add_check_options():
    from ansible.cli import CLI
    parser = CLI.base_parser(constants=C)
    add_check_options(parser)
    options = parser.parse_args(['--diff'])
    assert options.check == False
    assert options.syntax == False
    assert options.diff == C.DIFF_ALWAYS
    options = parser.parse_args(['--check', '--syntax-check'])
    assert options.check == True
    assert options.syntax == True
    assert options.diff == C.DIFF_ALWAYS



# Generated at 2022-06-22 18:42:01.432854
# Unit test for function add_output_options
def test_add_output_options():
    assert add_output_options(argparse.ArgumentParser()).one_line == True
    assert add_output_options(argparse.ArgumentParser()).tree == None
    assert add_output_options(argparse.ArgumentParser()).o == True
    assert add_output_options(argparse.ArgumentParser()).t == None

# Generated at 2022-06-22 18:42:12.256402
# Unit test for function add_connect_options
def test_add_connect_options():
    def _test_option(options, args):
        global DEFAULT_TRANSPORT, REMOTE_USER, DEFAULT_ASK_PASS, CONNECTION_PASSWORD_FILE
        DEFAULT_TRANSPORT = 'local'
        REMOTE_USER = 'ansible'
        DEFAULT_ASK_PASS = False
        CONNECTION_PASSWORD_FILE = '/path/to/.connpass'
        parser = argparse.ArgumentParser()
        add_connect_options(parser)
        options.update(dict((x, False) for x in ('ask_pass',)))
        data = copy.deepcopy(options)
        if args:
            data.update(dict(args=args))
        else:
            data['args'] = []

        opts = parser.parse_args(data['args'])
       

# Generated at 2022-06-22 18:42:13.300593
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    return parser


# Generated at 2022-06-22 18:42:18.022946
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    def tmp_func(option):
        parser = argparse.ArgumentParser()
        parser.add_argument('--foo', action=PrependListAction)
        opt = parser.parse_args([option])
        assert opt.foo == [option]

    tmp_func('1')
    tmp_func('--')
    tmp_func('-')



# Generated at 2022-06-22 18:42:19.469402
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    a = AnsibleVersion(('-v', '--version'), {}, None)
    assert a



# Generated at 2022-06-22 18:42:24.919557
# Unit test for function create_base_parser
def test_create_base_parser():
    parser1 = create_base_parser(prog='ansible', usage='', desc='', epilog='')
    parser2 = create_base_parser(prog='ansible-playbook', usage='', desc='', epilog='')
    parser3 = create_base_parser(prog='ansible-config', usage='', desc='', epilog='')
    parser4 = create_base_parser(prog='ansible-doc', usage='', desc='', epilog='')
    parser5 = create_base_parser(prog='ansible-galaxy', usage='', desc='', epilog='')
    parser6 = create_base_parser(prog='ansible-vault', usage='', desc='', epilog='')

# Generated at 2022-06-22 18:42:32.185271
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    r = PrependListAction(option_strings=['--foo'], dest='foo', nargs='*', const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)
    assert r.option_strings == ['--foo']
    assert r.dest == 'foo'
    assert r.nargs == '*'
    assert r.const is None
    assert r.default is None
    assert r.type is None
    assert r.choices is None
    assert r.required is False
    assert r.help is None
    assert r.metavar is None




# Generated at 2022-06-22 18:42:37.470658
# Unit test for function add_check_options
def test_add_check_options():
    """Unit test for function add_check_options"""
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    assert parser.parse_args("-C --syntax-check -D".split()) == argparse.Namespace(check=True, diff=True, syntax=True)



# Generated at 2022-06-22 18:42:43.885218
# Unit test for function add_runas_options
def test_add_runas_options():
    mock_parser = Mock()
    arguments = ['become_user']
    add_runas_options(mock_parser)
    mock_parser.add_argument_group.assert_called_with("Privilege Escalation Options", "control how and which user you become as on target hosts")
    for argument in arguments:
        assert mock_parser.add_argument_group.call_args[0][0].add_argument.call_args[1]['dest'] == argument


# Generated at 2022-06-22 18:42:49.016484
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    argument = parser
    assert argument == parser, 'add_vault_options() function is broken'


#
# Parser options related to configuration
#


# Generated at 2022-06-22 18:42:52.881910
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog="test")
    add_verbosity_options(parser)
    (options, args) = parser.parse_known_args(["-vvvv"])
    assert options.verbosity == 4

# Generated at 2022-06-22 18:42:57.871027
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(
                            prog="unit_test_arg_parser",
                            formatter_class=SortingHelpFormatter,
                            conflict_handler='resolve',
                        )
    add_fork_options(parser)
    test_args = ["-f", "10"]
    parsed_args = parser.parse_args(test_args)
    assert parsed_args.forks == 10



# Generated at 2022-06-22 18:43:04.651104
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    argv = ["-v", "--verbose"]
    known, unknown = parser.parse_known_args(argv)
    assert known.verbosity == 1
    argv = ["-vvvv"]
    known, unknown = parser.parse_known_args(argv)
    assert known.verbosity == 4



# Generated at 2022-06-22 18:43:14.325924
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from units.compat import mock
    from units.compat.mock import patch
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager, get_ini_config_value
    config_manager = ConfigManager()
    config_manager.add_cli_ini_option('ansible.cfg', 'inventory', 'inventory', 'path', 'STRING', 'Ansible inventory file', '/etc/ansible/hosts')
    config_manager.add_cli_ini_option('ansible.cfg', 'inventory', 'inventory_hostname', 'hostname', 'STRING', 'Ansible inventory hostname', 'localhost')

# Generated at 2022-06-22 18:43:22.919546
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)

    # --task-timeout
    options = parser.parse_args(['--task-timeout', '123'])
    assert options.task_timeout == 123

    # --task-timeout
    options = parser.parse_args(['--task-timeout', '-123'])
    assert options.task_timeout == -123



# Generated at 2022-06-22 18:43:26.483636
# Unit test for function add_runtask_options
def test_add_runtask_options():
    test = AnsibleModuleCmd()
    add_runtask_options(test)
    assert test.args.extra_vars == []
    test.parse_args(['-e', 'testvar=testval'])
    assert test.args.extra_vars == ['testvar=testval']



# Generated at 2022-06-22 18:43:36.507449
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """
    The function maybe_unfrack_path() has a hardcoded path prefixed to the string 'fhbNH'
    so we have to test this specific case.
    """
    os.chdir('/tmp')
    assert maybe_unfrack_path('@PREFIX@')('@PREFIX@/fhbNH') == '@PREFIX@/tmp/fhbNH'
    assert maybe_unfrack_path('@PREFIX@')('@PREFIX@/fhbNH') != '@prefix@/tmp/fhbNH'
    assert maybe_unfrack_path('@PREFIX@')('@PREFIX@/absPath') == '@PREFIX@/absPath'

# Generated at 2022-06-22 18:43:45.327106
# Unit test for function add_runas_options
def test_add_runas_options():
    opts = add_runas_options()
    args = ['--become',
            '--become-method', 'sudo',
            '--become-user', 'batman',
            '--become-ask-pass',
            '--become-ask-su-pass',
            '--ask-become-pass']
    parser = AnsibleOptions(opts)
    args = parser.parse(args)
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'batman'


# Generated at 2022-06-22 18:43:51.576152
# Unit test for function unfrack_path
def test_unfrack_path():
    data = unfrack_path()
    assert data('/test/path') == '/test/path'
    assert data('~/test/path') == os.path.expanduser('~/test/path')
    assert data('~/test/path1:~/test/path2') == [os.path.expanduser('~/test/path1'),
                                                os.path.expanduser('~/test/path2')]

#
# Common Parser
#

# Generated at 2022-06-22 18:43:59.110844
# Unit test for function version
def test_version():
    test_string = version(prog='test')
    assert test_string.startswith('test [core')
    assert 'configured module search path =' in test_string
    assert 'ansible python module location =' in test_string
    assert 'executable location =' in test_string
    assert 'python version =' in test_string
    assert 'jinja version =' in test_string
    assert 'libyaml =' in test_string



# Generated at 2022-06-22 18:44:02.097151
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(description='Test Parser')
    func = add_inventory_options(parser)
    parser.parse_args(['-i', 'inventory', '--list-hosts', '-l', 'limit'])


# Generated at 2022-06-22 18:44:13.894703
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible.module_utils._text import to_native

    C.DEFAULT_FORKS = '10'
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['--forks', '5'])
    assert args.forks == 5
    args = parser.parse_args([])
    assert args.forks == 10
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    try:
        parser.parse_args(['--forks', '-1'])
        assert False, "Expected a TypeError"
    except TypeError:
        # We expect a TypeError
        pass

# Generated at 2022-06-22 18:44:18.980509
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    argv = ['-P', '10', '-B', '20']
    options = parser.parse_args(argv)
    assert options.poll_interval == 10
    assert options.seconds == 20


#
# Functions to add options common to multiple parsers
#


# Generated at 2022-06-22 18:44:22.274381
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    inst = AnsibleVersion(option_strings=[])
    assert repr(inst).startswith('<AnsibleVersion')
    assert inst(None, None, None, None) is None

#
# Parsing helpers
#

# Generated at 2022-06-22 18:44:29.803351
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_inventory_options(parser)
    options = parser.parse_args(args=['-i','file.txt','--list-hosts','-l','pattern'])
    assert options.inventory == ['file.txt']
    assert options.listhosts is True
    assert options.subset == 'pattern'


# Generated at 2022-06-22 18:44:35.877502
# Unit test for function add_runas_options
def test_add_runas_options():
    """
    Verify that the add_runas_options function adds options to the parser.
    """
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args([])

    assert options.become_user == C.DEFAULT_BECOME_USER
    assert options.become_method == C.DEFAULT_BECOME_METHOD



# Generated at 2022-06-22 18:44:43.410134
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(description='test',
                                     formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action="store_true")
    parser.add_argument('-b', action="store_true")
    parser.add_argument('-cd', action="store_true")
    parser.add_argument('-ef', nargs=2, action="store_true")
    help_output = parser.format_help()
    # argparse arguements should be sorted like this
    # -a, -b, -cd, -ef
    assert help_output.find('-a') < help_output.find('-b')
    assert help_output.find('-b') < help_output.find('-cd')
    assert help_output.find('-cd') < help_

# Generated at 2022-06-22 18:44:50.620718
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    out, err = sys.stdout, sys.stderr
    try:
        sys.stdout = sys.stderr = open(os.devnull)
        parser = argparse.ArgumentParser()
        parser.add_argument('--version', action=AnsibleVersion, nargs=0)
        parser.prog = 'ansible-test'
        parser.parse_args(['--version'])
    finally:
        sys.stdout, sys.stderr = out, err



# Generated at 2022-06-22 18:44:53.647155
# Unit test for function add_fork_options
def test_add_fork_options():
   parser = argparse.ArgumentParser()
   add_fork_options(parser)
   options = parser.parse_args(["-f", "2"])
   assert options.forks == 2
   imports.uri

# Generated at 2022-06-22 18:45:01.952800
# Unit test for function version

# Generated at 2022-06-22 18:45:06.276949
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(args=['-B', '100', '-P', '15'])
    assert options.seconds == 100, "Poll interval did not match"
    assert options.poll_interval == 15, "Seconds value did not match"



# Generated at 2022-06-22 18:45:11.509387
# Unit test for function add_fork_options
def test_add_fork_options():
    # Arrange
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS)

    # Act
    add_fork_options(parser)

    # Assert
    parser.parse_args(['-f', '20'])


# Generated at 2022-06-22 18:45:23.371767
# Unit test for function add_subset_options
def test_add_subset_options():
    '''
    This tests the functionality of add_subset_options in
    ansible.cli.arguments module. This test case covers all possible
    combinations of arguments supplied to the function add_subset_options().
    '''
    test_parser = argparse.ArgumentParser()
    add_subset_options(test_parser)
    test_args = ['-t', '1',
                 '-t', '2',
                 '-t', '3',
                 '--skip-tags', '4',
                 '--skip-tags', '5',
                 '--skip-tags', '6',
                 '-t', '7',
                 '--skip-tags', '8']

    test_parse_args = test_parser.parse_args(test_args)

# Generated at 2022-06-22 18:45:29.037712
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', action=PrependListAction)
    parser.parse_args(['-f', 'foo', '-f', 'bar'])
    assert parser.parse_args(['-f', 'foo', '-f', 'bar']).f == ['bar', 'foo']
    assert parser.parse_args(['-f', 'foo', '-f', 'bar']).f != ['foo', 'bar']



# Generated at 2022-06-22 18:45:33.661094
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog="test")
    add_verbosity_options(parser)
    assert hasattr(parser, '_option_string_actions')
    for item in parser._option_string_actions:
        if item.dest == 'verbosity':
            assert item.default == C.DEFAULT_VERBOSITY
            assert item.help == "verbose mode (-vvv for more, -vvvv to enable connection debugging)"
        if item.option_strings[0] == '--version':
            assert item.action == 'version'



# Generated at 2022-06-22 18:45:38.904692
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion(option_strings=['--version'])
    parser = argparse.ArgumentParser()
    action(parser, 'foo', 'bar')
    assert parser.exit_called_with == '0'
# end of function test_AnsibleVersion___call__


# Generated at 2022-06-22 18:45:42.466009
# Unit test for function add_output_options
def test_add_output_options():

    class CallbackModule(object):
        def on_any(self, *args, **kwargs):
            pass

    class Test():

        def __init__(self):
            self.connection = 'local'
            self.forks = 1

    obj = Test()
    parser = create_base_parser('test')
    add_output_options(parser)
    add_verbosity_options(parser)
    args = parser.parse_args(['-t', 'test'])

    # Test all variable
    print(args)


#
# Main
#
if __name__ == '__main__':
    sys.exit(test_add_output_options())

# Generated at 2022-06-22 18:45:45.417572
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value = 'TEST_PATH'
    assert maybe_unfrack_path('TEST_PATH')(value) == 'TEST_PATH' + os.path.sep + value



# Generated at 2022-06-22 18:45:56.395368
# Unit test for function add_meta_options
def test_add_meta_options():
    from units.compat import unittest
    from units.compat.mock import patch, MagicMock

    class TestArgs(object):
        pass

    prog = "ansible-playbook"
    usage = "usage: ansible-playbook playbook.yml"
    desc = "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

    parser = create_base_parser(prog, usage, desc)
    add_meta_options(parser)

    # args.force_handlers = True
    args = TestArgs()
    args.force_handlers = True
    args.flush_cache = False
    with patch.object(parser, 'parse_args', return_value=args):
        with patch('ansible.cli.CLI.run'):
            parser.parse_args()
            parser.run

# Generated at 2022-06-22 18:46:06.523112
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class DummyAction:
        def __init__(self, name, option_strings):
            self.name = name
            self.option_strings = option_strings

    formatter = SortingHelpFormatter()
    actions = [DummyAction("action1", ["-a"]), DummyAction("action2", ["-b"]), DummyAction("action3", ["-c"])]

    test_output = formatter.add_arguments(actions)
    assert test_output.index("-a") > test_output.index("-b")
    assert test_output.index("-b") > test_output.index("-c")



# Generated at 2022-06-22 18:46:16.299317
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    ns = FakeNamespace()
    ensure_value(ns, 'v', [])
    if ns.v != []:
        raise AssertionError('Expected []')
    ensure_value(ns, 'v', [1,2,3])
    if ns.v != [1,2,3]:
        raise AssertionError('Expected [1,2,3]')
    ensure_value(ns, 'x', None)
    if ns.x != None:
        raise AssertionError('Expected None')
try:
    from unittest.case import TestCase
except ImportError:
    from .my_unittest import TestCase

# Generated at 2022-06-22 18:46:23.578038
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    for val in ['=>/p', '=>/p/p', '=>p', '=>p/p', '=/>/p', '=>/p/p', '=/>p']:
        assert maybe_unfrack_path('=>')(val) == '=>' + unfrackpath(val[2:])
    for val in ['/p', 'p', '/p/p', 'p/p']:
        assert maybe_unfrack_path('=>')(val) == val



# Generated at 2022-06-22 18:46:26.172826
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    assert parser.parse_args([]).forks == C.DEFAULT_FORKS
    assert parser.parse_args(['-f', '5']).forks == 5


# Generated at 2022-06-22 18:46:37.897635
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('foo')
    parser.add_argument('bar')
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')

    check_parser = argparse.ArgumentParser()
    SortingHelpFormatter().add_arguments(parser._actions)
    assert parser.format_help() == check_parser.format_help()

#
# Help constants
#


# Generated at 2022-06-22 18:46:41.081760
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '16'])
    assert args.forks, '16'
    args = parser.parse_args([])
    assert args.forks == C.DEFAULT_FORKS
test_add_fork_options.unittest = True



# Generated at 2022-06-22 18:46:47.581414
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_meta_options(parser)
    options, args = parser.parse_known_args(['--flush-cache'])
    assert options.flush_cache == True
    options, args = parser.parse_known_args()
    assert options.flush_cache == False
    options, args = parser.parse_known_args(['--force-handlers'])
    assert options.force_handlers == True
    options, args = parser.parse_known_args()
    assert options.force_handlers == False


# Generated at 2022-06-22 18:46:49.553529
# Unit test for function add_connect_options
def test_add_connect_options():
    add_connect_options(argparse.ArgumentParser())


# Generated at 2022-06-22 18:46:54.014118
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    with pytest.raises(SystemExit) as parser_error:
        parser.parse_args(['--foo'])
    assert parser_error.value.code == 2

# Generated at 2022-06-22 18:47:01.253971
# Unit test for function version
def test_version():
    """ test the version output """

# Generated at 2022-06-22 18:47:07.633523
# Unit test for function add_async_options
def test_add_async_options():
    """Unit test for function add_async_options"""
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args, remainder = parser.parse_known_args(['-B','10'])
    assert args.seconds == 10
    args, remainder = parser.parse_known_args([])
    assert args.seconds == 0



# Generated at 2022-06-22 18:47:11.795898
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    test_instance = argparse.ArgumentParser()
    add_tasknoplay_options(test_instance)
    assert test_instance.parse_args(['--task-timeout', '100'])
# EOF



# Generated at 2022-06-22 18:47:16.612477
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-f', action='store_true', help='foo')
    parser.add_argument('-b', action='store_true', help='bar')
    parser.get_help()


# Generated at 2022-06-22 18:47:25.348892
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    # SortingHelpFormatter is a subclass of HelpFormatter
    help_formatter = SortingHelpFormatter()
    # ArgumentParser uses help_formatter to format help
    parser.add_argument('--foo').help = help_formatter.format_help(parser)
    help_list = parser.format_help().split('\n')
    assert '--bar' in help_list[3]
    assert '--baz' in help_list[3]
    assert '--foo' in help_list[3]


# Generated at 2022-06-22 18:47:35.654933
# Unit test for function add_vault_options
def test_add_vault_options():
    base_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, add_help=False)
    add_vault_options(base_parser)
    options = base_parser.parse_args(args=['--vault-password-file', 'file1', '--ask-vault-pass', '--vault-password-file', 'file2'])
    assert options.vault_password_files == ['file1', 'file2']
    assert options.ask_vault_pass == True


#
# Functions to parse options, merge defaults, validate and generate AnsibleOptions
#


# Generated at 2022-06-22 18:47:43.866436
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.utils.path import unfrackpath
    from os.path import sep
    from os import pathsep
    assert unfrack_path()("foo") == unfrackpath("foo")
    assert unfrack_path(True)("foo" + pathsep + "bar") == [unfrackpath("foo"), unfrackpath("bar")]
    assert unfrack_path(True)("foo" + sep + "bar") == [unfrackpath("foo" + sep + "bar")]
    assert unfrack_path()("-") == "-"



# Generated at 2022-06-22 18:47:47.397998
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(description='test add parser')
    add_fork_options(parser)
    options = parser.parse_args('-f 1'.split())
    assert options.forks == 1



# Generated at 2022-06-22 18:48:00.061944
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='*')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='*', default=[1, 2, 3])

# Generated at 2022-06-22 18:48:09.808596
# Unit test for function add_vault_options
def test_add_vault_options():
    opt_parser = argparse.ArgumentParser()
    opt_parser.add_argument('--vault-password-file', '--vault-pass-file', default=[], dest='vault_password_files',
                            help="vault password file", type=unfrack_path(), action='append')
    opts = opt_parser.parse_args(['--vault-password-file', '/etc/ansible-test/.vault_pass.txt'])
    path = opts.vault_password_files[0]
    assert path == '/etc/ansible-test/.vault_pass.txt'



# Generated at 2022-06-22 18:48:20.045880
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class ActionClass:
        def __init__(self, option_strings=None):
            self.option_strings = option_strings
    argument_list = [
        (['-a', '--a'], []),
        (['-b', '--b'], []),
        (['-c', '--c'], []),
        (['--d'], []),
        (['--e'], []),
        (['--f'], []),
        (['-g'], []),
        (['-i'], []),
        (['-j'], []),
        (['-h', '--h'], [])
    ]
    real_action_list = []
    for argument_item in argument_list:
        option_strings = argument_item[0]

# Generated at 2022-06-22 18:48:28.180274
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)

    with pytest.raises(SystemExit):
        parser.parse_args(['-B', '5'])
    with pytest.raises(SystemExit):
        parser.parse_args(['-P', '5'])
    assert parser.parse_args([]) == argparse.Namespace(poll_interval=10, seconds=0)

