

# Generated at 2022-06-22 18:38:37.922254
# Unit test for function add_output_options
def test_add_output_options():
    msg = "Example of a unit test for add_output_options function."
    parser = argparse.ArgumentParser()
    assert isinstance(parser, argparse.ArgumentParser)
    add_output_options(parser)
    assert parser.get_default("tree") is None
    assert parser.get_default("one_line") is None
    assert parser.get_default("check") is None
    assert parser.get_default("diff") == C.DIFF_ALWAYS
    assert parser.get_default("forks") == C.DEFAULT_FORKS
    assert parser.get_default("listhosts") is None
    assert parser.get_default("subset") is None
    assert parser.get_default("flush_cache") is None
    assert parser.get_default("force_handlers") == C.DEFAULT_FORCE

# Generated at 2022-06-22 18:38:40.490056
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/my/path') == '@/my/path'



# Generated at 2022-06-22 18:38:43.368831
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    (args, leftover) = parser.parse_known_args(['--syntax-check'])
    assert args.syntax is True

# Generated at 2022-06-22 18:38:52.222053
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    assert parser, "Parser was not created"
    assert parser.prog == 'ansible-inventory', "Wrong name of parser"
    assert parser._positionals, "No positional options created"
    assert parser._optionals, "No optional options created"
    assert parser._actions, "No actions created"
    assert parser.format_help(), "Failed to format help message"
    assert parser.print_help(), "Failed to print help message"
    assert parser.parse_known_args(), "Failed to parse known arguments"
    assert parser.parse_args(), "Failed to parse arguments"



# Generated at 2022-06-22 18:38:55.833129
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

# Generated at 2022-06-22 18:38:57.686415
# Unit test for function add_subset_options
def test_add_subset_options():
    parser=argparse.ArgumentParser()
    add_subset_options(parser)
    parser.print_help()


# Generated at 2022-06-22 18:38:58.801942
# Unit test for function version
def test_version():
    assert version() == version(None)



# Generated at 2022-06-22 18:39:01.699464
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--append', action= PreendListAction, default=[])
    test_args = ['--append', 'foo', '--append', 'bar']
    args = parser.parse_args(test_args)
    assert args.append == ['bar', 'foo']



# Generated at 2022-06-22 18:39:06.921260
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    assert ensure_value(None, 'foo', None) is None
    ns = Namespace()
    ensure_value(ns, 'foo', 1)
    assert ns.foo == 1
    ensure_value(ns, 'foo', 2)
    assert ns.foo == 1
    ensure_value(ns, 'bar', 2)
    assert ns.bar == 2
# /Unit test for function ensure_value
#
#
# Base OptionParser
#

# Generated at 2022-06-22 18:39:18.322914
# Unit test for function add_subset_options
def test_add_subset_options():
    ''' 
    unit test for add_subset_options 
        test results will be in unittest_output.txt
    '''
    with open('unittest_output.txt', 'a') as f:
        f.write('starting unit test for add_subset_options().\n')
        print('starting unit test for add_subset_options().\n')
    parser = argparse.ArgumentParser(description='unit test for add_subset_options()')
    add_subset_options(parser)
    args = parser.parse_args('-t value1 --tags value2 --skip-tags valueA --skip-tags valueB'.split())

# Generated at 2022-06-22 18:39:26.123606
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('--version', action=AnsibleVersion)
    test_parser.prog = 'test_version.py'
    test_parser.parse_args(['--version'])
    sys.stderr.seek(0)
    # Exception: --version option will display Ansible version and exit the program immediately.
    try:
      test_parser.parse_args(['--version', '1']).fail_json(msg="--version option only accepts zero or no argument")
    except SystemExit:
      pass


# Generated at 2022-06-22 18:39:31.338379
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = create_base_parser('/bin/ansible')
    add_subset_options(parser)
    args = parser.parse_args(args=['playbook', '--tags', 'tag1', '--skip-tags', 'tag2'])
    assert args.tags == ['tag1']
    assert args.skip_tags == ['tag2']

#
# Parsers for each command
#


# Generated at 2022-06-22 18:39:35.582889
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog="test")
    add_check_options(parser)
    options, _ = parser.parse_known_args(args=['--check', '--syntax-check', '--diff'])
    assert options.check
    assert options.syntax
    assert options.diff
# end unit test


# Generated at 2022-06-22 18:39:43.103566
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace():
        def __init__(self):
            self.foo = None
    ns = Namespace()
    ensure_value(ns, 'foo', True)
    assert ns.foo is True
    ensure_value(ns, 'foo', False)
    assert ns.foo is True
    ensure_value(ns, 'bar', True)
    assert ns.bar is True

#
# Core Argument Parser
#

# Generated at 2022-06-22 18:39:48.123433
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    args = parser.parse_args([])
    ensure_value(args, 'foo', ['test_value'])
    assert args.foo == ['test_value']
    args = parser.parse_args(['--foo=bar'])
    ensure_value(args, 'foo', ['test_value'])
    assert args.foo == 'bar'



# Generated at 2022-06-22 18:39:51.695201
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', nargs="*", action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args('--test --unrecognized'.split())

#
# The parser's options
#

# Generated at 2022-06-22 18:39:52.390535
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    action = AnsibleVersion()



# Generated at 2022-06-22 18:39:56.705007
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_subset_options(parser)
    args = parser.parse_args(['--tags', 'syntax', '--skip-tags', 'foo,bar'])
    assert args.tags == ['syntax']
    assert args.skip_tags == ['foo', 'bar']


# Generated at 2022-06-22 18:39:58.659517
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    assert not hasattr(UnrecognizedArgument, 'help')



# Generated at 2022-06-22 18:40:00.334175
# Unit test for function version
def test_version():
    assert version() == version('ansible-console')


# Generated at 2022-06-22 18:40:08.601226
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    try:
        PrependListAction(
            option_strings=['--opt'],
            dest='opt',
            nargs=0,
            const=None,
            default=None,
            type=None,
            choices=None,
            required=False,
            help='help'
        )
    except ValueError:
        pass
    else:
        raise AssertionError("PrependListAction can't be constructed with nargs == 0")
    PrependListAction(
        option_strings=['--opt'],
        dest='opt',
        nargs=argparse.REMAINDER,
        const=None,
        default=None,
        type=None,
        choices=None,
        required=False,
        help='help'
    )

# Generated at 2022-06-22 18:40:19.748539
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # Tests for args
    UnrecognizedArgument(['-a', '--aa'], None, default='default value', help='help message')
    UnrecognizedArgument(['-a', '--aa'], None, default='default value')
    UnrecognizedArgument(['-a', '--aa'], None, help='help message')
    UnrecognizedArgument(['-a', '--aa'], None)
    UnrecognizedArgument(['-a', '--aa'], None, help='help message', default='default value')

    # Tests for kwargs
    UnrecognizedArgument(['-a', '--aa'], None, default='default value', help='help message', metavar='META')

# Generated at 2022-06-22 18:40:24.984257
# Unit test for function add_output_options
def test_add_output_options():
    #option -o
    parser=argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert args.one_line == True
    #option -t
    args = parser.parse_args(['-t', 'control'])
    assert args.tree == 'control'


# Generated at 2022-06-22 18:40:29.681564
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter,
                                     prog="test",
                                     description="Desc",
                                     epilog="Epilog")
    add_verbosity_options(parser)
    add_async_options(parser)
    args = parser.parse_args(["-v", "-B", "3"])
    assert args.verbosity == 1
    assert args.seconds == 3



# Generated at 2022-06-22 18:40:42.165572
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    def call_AnsibleVersion(args):
        # Note the use of a ModuleParser instead of an ArgumentParser
        # Note the internal use of the ExitParsingException
        class ExitParsingException(Exception):
            pass  # noqa

        class ModuleParser(argparse.ArgumentParser):
            def __init__(self):
                super(ModuleParser, self).__init__()
                self.exit_exception = ExitParsingException

            def exit(self, status=0, message=None):
                raise self.exit_exception(status, message)

        args = ['-v'] + args
        parsing_parser = ModuleParser()
        AnsibleVersion()(parsing_parser, None, None, '#')

# Generated at 2022-06-22 18:40:53.407770
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser('ansible')
    add_check_options(parser)
    # Test if -C/-check options can be parsed properly
    options, _ = parser.parse_known_args(['-C'])
    assert(options.check == True)
    # Test if --syntax-check can be parsed properly
    options, _ = parser.parse_known_args(['--syntax-check'])
    assert(options.syntax == True)
    # Test if -D/-diff can be parsed properly
    options, _ = parser.parse_known_args(['-D'])
    assert(options.diff == True)



# Generated at 2022-06-22 18:40:59.192690
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    p = ArgumentParser(prog='test_PrependListAction___call__')
    p.add_argument('--foo', '-f', action=PrependListAction, dest='foo', default=['initial'])
    _args = p.parse_args('-f first -f second -f third'.split())
    assert _args.foo == ['first', 'second', 'third', 'initial']
#
# Option Parsing
#

# Generated at 2022-06-22 18:41:05.936671
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    p.add_argument('-b','--bar', action=PrependListAction)
    p.add_argument('--foo', action=PrependListAction, nargs='+')
    p.add_argument('--baz', action=PrependListAction, nargs='*', default=[])
    p.add_argument('--qux', action=PrependListAction, nargs='+', default=[])
    ns = p.parse_args('--foo one1 two2 --foo three3 four4 --bar five5'.split(), default_values=['--bar', 'six6'])
    assert ns.bar == ['five5', 'six6']
    assert ns.foo == ['three3', 'four4', 'one1', 'two2']

# Generated at 2022-06-22 18:41:15.886282
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Test that there are no command line options with an empty argument list
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    assert not parser.parse_args([])
    # Also test that a mutually exclusive group was actually created
    runas_group = parser.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")
    add_runas_prompt_options(parser, runas_group)
    args = parser.parse_args(['-K', '--become-password-file', '~/.vault_pass.txt'])
    assert args.become_password_file == '~/.vault_pass.txt'
    assert args.become_ask_pass is False

# Generated at 2022-06-22 18:41:19.277433
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class_A = AnsibleVersion(('-v', '--version'))
    parser_A = mock.Mock()
    parser_A.prog='prog_A'
    print(class_A(parser_A,'namespace_A','values_A','option_string_A'))


# Generated at 2022-06-22 18:41:31.203162
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    subparsers = parser.add_subparsers()
    parser_args = subparsers.add_parser('args')
    parser_args.add_argument('foo')
    parser_args.add_argument('bar')
    parser_run = subparsers.add_parser('run')
    parser_run.add_argument('--version', action=AnsibleVersion, help='display the Ansible version')
    parser_run.add_argument('--extra-vars', metavar='EXTRA_VARS', help='set additional variables')
    parser_run.add_argument('--syntax-check', action='store_true', help='perform a syntax check on the playbook')

# Generated at 2022-06-22 18:41:33.579123
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    argparse.ArgumentParser()
    parser = AnsibleVersion()
    assert parser != False


#
# Actual option handling
#

# Generated at 2022-06-22 18:41:38.978086
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser=argparse.ArgumentParser()
    add_verbosity_options(parser)
    args=parser.parse_args(args=['-v'])
    assert args.verbosity == 1
    args=parser.parse_args(args=['-vv'])
    assert args.verbosity == 2


# Generated at 2022-06-22 18:41:47.265724
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_check_options(parser)
    args = parser.parse_args(args=['--check', '--syntax-check', '-D'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True



# Generated at 2022-06-22 18:41:56.062847
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    '''
    Test to ensure that the arguments get assigned correctly.
    '''
    test_action = UnrecognizedArgument(option_strings=None, dest=None, nargs=0, const=None, default=None)

    test_values = ['test']

    parser = argparse.ArgumentParser(description='argparse ArgumentParser')
    parser.add_argument('--test', action=test_action, help='test help')

    try:
        parser.parse_args(test_values)
    except SystemExit:
        pass # Expected exception
    else:
        assert False # Exception not raised



# Generated at 2022-06-22 18:41:57.693797
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-test')
    add_check_options(parser)
    args = parser.parse_args()
    assert args.check == False


# Generated at 2022-06-22 18:41:59.440056
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.parse_args(['--playbook-dir'])

# Generated at 2022-06-22 18:42:05.250862
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)

    # test that options are sorted alphabetically
    parser.add_argument("-b", help="b help")
    parser.add_argument("-a", help="a help")

    options = parser.parse_args(args=['--help'])
    assert options is None

#
# Main parser for `ansible` CLI
#

# Generated at 2022-06-22 18:42:07.560563
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    result = parser.parse_args('--become --become-method runas --become-user foo'.split())
    assert result.become is True
    assert result.become_method == "runas"
    assert result.become_user == "foo"


# Generated at 2022-06-22 18:42:12.476871
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='description')
    add_vault_options(parser)
    args = parser.parse_args(['--ask-vault-pass'])
    assert args.ask_vault_pass
    assert args.vault_password_files == []

    args = parser.parse_args(['--vault-password', 'password'])
    assert args.vault_password == 'password'

    args = parser.parse_args(['--vault-password-file', 'password.txt'])
    assert args.vault_password_files == ['password.txt']

    args = parser.parse_args(['--vault-password-file', 'password.txt', '--vault-password-file', 'password2.txt'])

# Generated at 2022-06-22 18:42:13.982716
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='test')
    add_vault_options(parser)
    return parser.parse_args(['--vault-id', 'test', '--ask-vault-password'])


# Generated at 2022-06-22 18:42:18.122263
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    add_verbosity_options(parser)
    args, _ = parser.parse_known_args()
    assert args.verbosity == C.DEFAULT_VERBOSITY



# Generated at 2022-06-22 18:42:21.595521
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])


#
# Utilities/classes
#

# Generated at 2022-06-22 18:42:28.440263
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print('\n===TESTING: AnsibleVersion')
    if __name__ == '__main__':
        print('===main')
    else:
        print('===not main')
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])
    print('===END OF TESTING: AnsibleVersion')



# Generated at 2022-06-22 18:42:33.929999
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    arg = UnrecognizedArgument(option_strings=['-x'])
    parser = argparse.ArgumentParser()
    parser.add_argument('-x', action=arg)
    try:
        parser.parse_args(["-x"])
        assert False
    except SystemExit as e:
        assert e.code == 2

#
# BaseParser
#

# Generated at 2022-06-22 18:42:38.289718
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    parser.parse_args(['-i', 'inventory_file_1', '-i', 'inventory_file_2', '--list-hosts'])


# Generated at 2022-06-22 18:42:42.393779
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser('')
    add_inventory_options(parser)
    options, _ = parser.parse_known_args()
    assert options.inventory is None
    assert options.listhosts is None
    assert not options.subset


# Generated at 2022-06-22 18:42:50.142646
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # create epilog for unit test
    epilog = "This is an epilog"
    description = "This is an description"
    # create parser for unit test
    parser = create_base_parser("test_parser", epilog=epilog, desc=description)
    # execute add_inventory_options function
    add_inventory_options(parser)
    options = parser.parse_args(["-i", "./hosts", "--list-hosts", "-l", "host", "--inventory", "./hosts,127.0.0.1"])
    # assert 'list_hosts' exists and is True
    assert options.listhosts is True
    # assert 'limit' exists and is 'host'
    assert options.subset == "host"

# Generated at 2022-06-22 18:42:52.433725
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    version = AnsibleVersion(None, None, "2.4.0", None)
    assert version is not None

#
# Options object
#

# Generated at 2022-06-22 18:42:57.414977
# Unit test for function add_runas_options
def test_add_runas_options():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    add_runas_options(parser)

    test_cases = [
        {'command': '-b'},
        {'command': '-b -K'},
        {'command': '-K -b'},
        {'command': '-K -b -S'},
        {'command': '-K -b -s'},
    ]

    for test_case in test_cases:
        arguments = test_case.get('command').split(" ")
        args = parser.parse_args(arguments)
        assert not args.ask_pass
        assert args.become
        assert args.become_method



# Generated at 2022-06-22 18:43:05.707554
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(
        prog="ansible",
        formatter_class=SortingHelpFormatter,
    )
    add_runas_options(parser)

    args = parser.parse_args([
        '-b',
        '--become-method=foo',
        '--become-user=bar',
    ])

    assert args.become
    assert args.become_method == 'foo'
    assert args.become_user == 'bar'



# Generated at 2022-06-22 18:43:18.434162
# Unit test for function create_base_parser
def test_create_base_parser():
    version_help = "show program's version number, config file location, configured module search path," \
                   " module location, executable location and exit"
    assert_list = ['--verbose', '-v', '--version', '-V']
    assert_val = ['--version', '-V']
    assert_desc = ['--version', '-V', 'show program\'s version number, config file location, configured module search path,',
                   ' module location, executable location and exit']
    assert_version = ['--version']
    assert_usage = ['--version', '-V', 'program\'s version number, config file location, configured module search path,',
                   ' module location, executable location and exit']
    assert_verbose = ['--verbose', '-v']


# Generated at 2022-06-22 18:43:21.631358
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    result = add_runas_prompt_options(parser=None)
    assert result is not None, 'Test should pass.'



# Generated at 2022-06-22 18:43:22.276946
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-22 18:43:29.189818
# Unit test for function add_vault_options
def test_add_vault_options():
    import pytest
    from ansible_test._internal.utils.tempdir import tempdir

    with tempdir() as path:
        parser = argparse.ArgumentParser()
        add_vault_options(parser)

        with open(path / 'pass.txt', 'w') as f:
            f.write('ansible')

        with pytest.raises(SystemExit):
            parser.parse_args(['--vault-id', "@{/dev/null}"])

        assert parser.parse_args(['--vault-id', 'default']).vault_ids == ['default']

        assert parser.parse_args(['--vault-password-file', '%s' % path / 'pass.txt']).vault_password_files == [path / 'pass.txt']

# Generated at 2022-06-22 18:43:38.868426
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()
    add_inventory_options(parser)
    parser.add_argument.assert_called_once_with(
        '-i', '--inventory', '--inventory-file',
        dest='inventory', action='append',
        help='specify inventory host path or comma separated host list. --inventory-file is deprecated'
    )
    parser.add_argument.assert_called_with(
        '--list-hosts', dest='listhosts', action='store_true',
        help='outputs a list of matching hosts; does not execute anything else'
    )
    parser.add_argument.assert_called_with(
        '-l', '--limit', default='all', dest='subset',
        help='further limit selected hosts to an additional pattern'
    )



# Generated at 2022-06-22 18:43:41.626892
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='foo', description='my foo program')
    parser.add_argument('-v', '--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert to_native(args.version) is None

# Generated at 2022-06-22 18:43:43.052387
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Test that no exception is thrown.
    parser = Mock()
    add_runas_prompt_options(parser)


# Generated at 2022-06-22 18:43:45.463509
# Unit test for function add_output_options
def test_add_output_options():
    """Test add_output_options()"""
    add_output_options(argparse.ArgumentParser())



# Generated at 2022-06-22 18:43:50.662421
# Unit test for function ensure_value
def test_ensure_value():
    class A:
        pass

    a = A()
    assert ensure_value(namespace=a, name="foo", value=[]) == []
    assert hasattr(a, "foo")
    assert ensure_value(namespace=a, name="foo", value=[]) == []
    assert hasattr(a, "foo")
    assert ensure_value(namespace=a, name="bar", value=[]) == []
    assert hasattr(a, "bar")
    assert ensure_value(namespace=a, name="foo", value=[]) == []

#
# Version information helpers
#

# Generated at 2022-06-22 18:43:59.769301
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    test_input = "--private-key=/tmp/test_key.pem -u user_test --timeout=100 --connection-password-file=/tmp/test_pass.txt"
    args = parser.parse_args(test_input.split(" "))
    assert args.private_key_file == '/tmp/test_key.pem'
    assert args.remote_user == 'user_test'
    assert args.timeout == 100
    assert args.connection_password_file == '/tmp/test_pass.txt'


# Generated at 2022-06-22 18:44:04.519884
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog='Test',
        description='Test description',
        confict_handler='resolve'
    )
    add_basedir_options(parser)
    assert hasattr(parser, 'playbook_dir') == True


# Generated at 2022-06-22 18:44:08.995426
# Unit test for function add_inventory_options
def test_add_inventory_options():
    temp_parser = argparse.ArgumentParser()
    add_inventory_options(temp_parser)
    (options, _) = temp_parser.parse_known_args()
    assert options.inventory == None
    assert options.listhosts == False
    assert options.subset == None
#
# Misc utility options
#

# Generated at 2022-06-22 18:44:12.949797
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path') == '/path'
    assert unfrack_path()('roles/myrole/meta/main.yml') == 'roles/myrole/meta/main.yml'
    assert unfrack_path()('') == ''



# Generated at 2022-06-22 18:44:23.297675
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    parser.add_argument('-a', action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args(['-a', '1'])
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    parser.add_argument('-a', action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args(['-a'])
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    parser.add_argument('-a', action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args(['--ask-vault-pass'])

# Generated at 2022-06-22 18:44:31.499376
# Unit test for function ensure_value
def test_ensure_value():
    class args:
        def __init__(self):
            self.v = None
    a  = args()
    ensure_value(a, 'v', None)
    assert a.v is None
    ensure_value(a, 'v', False)
    assert a.v is False
    ensure_value(a, 'v', 1)
    assert a.v == 1

#
# Base Options Parser
#

# Generated at 2022-06-22 18:44:34.528088
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser(description='parse something')
    parser.add_argument('--version', action=AnsibleVersion)

#
# Main parsing and processing
#


# Generated at 2022-06-22 18:44:39.572880
# Unit test for function ensure_value
def test_ensure_value():
    class TestModule(object):
        pass

    m = TestModule()
    m.foo = None
    ensure_value(m, 'foo', 'bar')
    assert m.foo == 'bar'

    m.foo = 'foo'
    ensure_value(m, 'foo', 'bar')
    assert m.foo == 'foo'


#
# main parser for ansible-playbook and ansible
#

# Generated at 2022-06-22 18:44:51.451984
# Unit test for function add_runtask_options
def test_add_runtask_options():

    parser = argparse.ArgumentParser(version='1.0.0', formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_runtask_options(parser)
    assert len(parser._actions) == 1
    assert parser._actions[0].dest == "extra_vars"
    assert parser._actions[0].type == maybe_unfrack_path('@')
    assert parser._actions[0].help == "set additional variables as key=value or YAML/JSON, if filename prepend with @"
    assert parser._actions[0].default == []
    assert parser._actions[0].action == "append"
    assert parser._actions[0].option_strings == ['-e', '--extra-vars']

    # test appending
    options, args = parser.parse_known_args

# Generated at 2022-06-22 18:44:55.407944
# Unit test for function create_base_parser
def test_create_base_parser():
    usage = "usage_string"
    parser = create_base_parser("prog", usage=usage)

    assert(parser.get_usage() == usage)
    assert(parser.prog == "prog")
    assert(isinstance(parser.formatter_class, argparse.HelpFormatter))


# Generated at 2022-06-22 18:44:55.975462
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass

# Generated at 2022-06-22 18:45:04.125361
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_connect_options(parser)
    result = parser.parse_args(['--private-key', 'test/path',
                                '-u', 'test_user', '-c', 'test_connection',
                                '-T', '2', '--ssh-common-args', 'test_ssh_common_args',
                                '--sftp-extra-args', 'test_sftp_extra_args',
                                '--scp-extra-args', 'test_scp_extra_args',
                                '--ssh-extra-args', 'test_ssh_extra_args',
                                '-k', '--connection-password-file', 'test_conn_pass_file'])
    assert result.private_key

# Generated at 2022-06-22 18:45:11.756863
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class TestCmd:
        def __init__(self, option_strings, help):
            self.option_strings = option_strings
            self.help = help

    opts = [
        TestCmd(option_strings='-b', help='sort_1'),
        TestCmd(option_strings='-a', help='sort_3'),
        TestCmd(option_strings='-c', help='sort_2'),
    ]
    f = SortingHelpFormatter()
    f.add_arguments(opts)
    txt = f.format_help()
    order_in_txt = [line.strip() for line in txt.strip().splitlines()]
    order_by_init = [opt.help for opt in opts]

    assert order_in_txt == order_by_init



# Generated at 2022-06-22 18:45:15.889872
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    import os
    import tempfile
    tmpfd, tmpfile = tempfile.mkstemp()
    os.close(tmpfd)
    try:
        parser = AnsibleOptionParser(version=version("test"))
        parser.add_option = lambda *a, **kw: setattr(parser, '_added', (a, kw))
        add_tasknoplay_options(parser)
        parser.parse_args(['--task-timeout', tmpfile])
        assert parser._added[0][0] == '--task-timeout'
        assert parser._added[0][1] == '-t'
    finally:
        os.remove(tmpfile)



# Generated at 2022-06-22 18:45:21.793676
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    add_inventory_options(parser)
    options = parser.parse_args([])
    assert options.inventory is None

    options = parser.parse_args(['-i', 'host1,host2', '-i', 'host3'])
    assert options.inventory == ['host1,host2', 'host3']



# Generated at 2022-06-22 18:45:28.954961
# Unit test for function add_output_options
def test_add_output_options():
    from ansible.utils import context_objects as co
    from ansible.utils.context_objects import AnsibleContext

    old_context = co._ansible_context
    co.set_defaults()
    co._ansible_context = AnsibleContext()
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options, args = parser.parse_known_args(["-t", "/tmp/file"])
    assert options.tree == "/tmp/file"
    co._ansible_context = old_context
    co.set_defaults()


# Generated at 2022-06-22 18:45:30.936433
# Unit test for function add_inventory_options
def test_add_inventory_options():
    assert add_inventory_options()

# Custom options

# Generated at 2022-06-22 18:45:34.886435
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers','--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True



# Generated at 2022-06-22 18:45:45.250761
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """Unit test to test the constructor of PrependListAction class. This test should
    be kept in sync with PrependListAction constructor
    """
    try:
        PrependListAction(['option_strings'], 'dest', 'nargs', 'const', 'default', 'type', 'choices', 'required', 'help', 'metavar')
    except ValueError as e:
        assert "nargs must be 2 to supply const" in to_native(e)
        # Skip testing appending const since it is deprecated
        return

    # Test exception when nargs is 0
    try:
        PrependListAction(['option_strings'], 'dest', 0)
    except ValueError as e:
        assert "nargs for append actions must be > 0" in to_native(e)
        return



# Generated at 2022-06-22 18:45:53.207281
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    parser.add_argument('--zzz')
    parser.add_argument('--aaa')
    parser.add_argument('-t', action='version', version='testing')

    output = parser.format_help()
    assert output.find('--aaa') < output.find('--zzz')


# Help about what is provided in the config

# Generated at 2022-06-22 18:46:03.587675
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(usage = 'test parser', desc ='test desc', epilog = 'test epilog')
    assert parser.format_help()
    assert parser.parse_args(['--version'])
    assert parser.parse_args(['-v'])
    assert parser.parse_args(['-vvv'])
    assert parser.parse_args(['-vvvv'])
    assert parser.parse_args(['-vvvvv'])
    assert parser.parse_args(['-vvvvvv'])
    assert parser.parse_args(['-vvvvvvv'])



# Generated at 2022-06-22 18:46:11.191392
# Unit test for function add_output_options
def test_add_output_options():
    parser = create_base_parser('ansible')
    add_output_options(parser)
    opts = parser.parse_args()
    assert opts.one_line == False
    assert opts.tree == None
    opts = parser.parse_args(['--one-line'])
    assert opts.one_line == True
    opts = parser.parse_args(['--tree', 'test'])
    assert opts.tree == 'test'


# Generated at 2022-06-22 18:46:14.816477
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    parser.parse_args(['--force-handlers', '--flush-cache'])


# Generated at 2022-06-22 18:46:19.056850
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog="test_add_tasknoplay_options")
    add_tasknoplay_options(parser)
    options = parser.parse_args()
    assert not options.task_timeout



# Generated at 2022-06-22 18:46:28.053398
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'action', 'bar')
    assert namespace.action == 'bar'
    ensure_value(namespace, 'action', 'foo')
    assert namespace.action == 'bar'
    ensure_value(namespace, 'action2', 'foo')
    assert namespace.action2 == 'foo'
    namespace.action2 = 'bar'
    assert namespace.action2 == 'bar'

    class Foo:
        def __getattribute__(self, name):
            if name == "action":
                raise Exception
            return super(Foo, self).__getattribute__(name)

    namespace = Foo()
    ensure_value(namespace, 'action', 'bar')
    assert namespace.action == 'bar'



# Generated at 2022-06-22 18:46:36.176825
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    data = [
        ('@/does_not_start_with_at_sign', '@/does_not_start_with_at_sign'),
        ('@/does_start_with_at_sign', '@' + unfrackpath('/does_start_with_at_sign')),
        ('@@/does_start_with_double_at_sign', '@@/does_start_with_double_at_sign'),
    ]
    for value, expected in data:
        assert maybe_unfrack_path('@')(value) == expected



# Generated at 2022-06-22 18:46:46.364878
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Set-up test
    p = argparse.ArgumentParser()
    p.add_argument('-a', action=PrependListAction)
    args = p.parse_args([])
    assert args.a is None
    args = p.parse_args(['-a', '1'])
    assert args.a == ['1']
    args = p.parse_args(['-a', '1', '-a', '2'])
    assert args.a == ['2', '1']
    args = p.parse_args(['-a', '1', '-a', '2', '-a', '3'])
    assert args.a == ['3', '2', '1']
    # Test with non-string types

# Generated at 2022-06-22 18:46:54.057578
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = create_base_parser('test_add_basedir_options')
    # When a playbook basedir is not set
    add_basedir_options(parser)
    basedir = C.config.get_config_value('PLAYBOOK_DIR')
    assert parser.parse_args(["--playbook-dir", basedir]).basedir == basedir

    # When a playbook basedir is not set
    add_basedir_options(parser)
    assert parser.parse_args(["--playbook-dir", ""]).basedir == ""



# Generated at 2022-06-22 18:46:59.036980
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-B', action="store_true", dest='B')
    parser.add_argument('-A', action="store_true", dest='A')
    parser.add_argument('-C', action="store_true", dest='C')
    # run the constructor
    SortingHelpFormatter(parser)


# Generated at 2022-06-22 18:47:04.624945
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog="test_prog")
    add_check_options(parser)
    opts = vars(parser.parse_args())
    assert opts["check"] == True
    assert opts["syntax"] == True
    assert opts["diff"] == True
    parser = argparse.ArgumentParser(prog="test_prog")
    add_check_options(parser)
    opts = vars(parser.parse_args(['--check']))
    assert opts["check"] == True
    assert opts["syntax"] is None
    assert opts["diff"] == C.DIFF_ALWAYS
    parser = argparse.ArgumentParser(prog="test_prog")
    add_check_options(parser)

# Generated at 2022-06-22 18:47:13.554355
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-d',
        action=PrependListAction,
        nargs=2,
        dest='opt'
    )

    parser.parse_known_args(['-d', '1', '2', '-d', '3', '4'])
    assert parser.parse_known_args(['-d', '1', '2', '-d', '3', '4'])[0].opt == ['3', '4', '1', '2']

#
# Option Parsing
#

# Generated at 2022-06-22 18:47:23.184016
# Unit test for function add_subset_options
def test_add_subset_options():
    def dummy_callback(option, opt_str, value, parser):
        parser.values.tags = None

    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_subset_options(parser)
    parser.add_argument('-S', '--skip-tasks', dest='skip_tasks', action='callback', callback=dummy_callback)

    options, _ = parser.parse_known_args(['-S', '-t', 'tag1,tag2'])
    assert options.tags is None

    options, _ = parser.parse_known_args(['--skip-tags', 'tag1,tag2', '-t', 'tag1,tag2'])
    assert options.tags == ['tag1,tag2']
    assert options.skip_tags == ['tag1,tag2']



# Generated at 2022-06-22 18:47:36.649722
# Unit test for function add_vault_options
def test_add_vault_options():
    from six.moves import cStringIO as StringIO
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.utils.path import unfrack_path

    fake_vault_pwd = '$6$salt$password'  # Shamelessly stolen from cli.py

    dummy_parser = argparse.ArgumentParser(description='test_add_vault_options', prog='test_add_vault_options')
    add_vault_options(dummy_parser)

    # Test 1, ask-vault-password specified but not password file, should set vault_ask_pass
    dummy_parser.parse_args(['--ask-vault-password'])

# Generated at 2022-06-22 18:47:40.248720
# Unit test for function unfrack_path
def test_unfrack_path():
    assert 'ansible' in unfrack_path(True)('ansible')
    assert 'ansible' in unfrack_path(False)('ansible')
assert test_unfrack_path()



# Generated at 2022-06-22 18:47:43.911549
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args(['-v', '-v', '-v'])
    assert options.verbosity == 3


# Generated at 2022-06-22 18:47:45.627332
# Unit test for function add_check_options
def test_add_check_options():
    parser=argparse.ArgumentParser()
    add_check_options(parser)
    assert parser.prog=='check'

# Generated at 2022-06-22 18:47:58.853521
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True)('-') == ['-']
    assert unfrack_path(pathsep=True)('some/path:/some/other/path') == ['some/path', '/some/other/path']
    assert unfrack_path(pathsep=False)('some/path') == 'some/path'
    assert unfrack_path(pathsep=False)('/some/path') == '/some/path'
    assert unfrack_path(pathsep=False)('some/path/') == 'some/path'
    assert unfrack_path(pathsep=False)('-') == '-'
    assert unfrack_path(pathsep=False)('~/path') == '~/path'


valid_file_types = ['auto', 'yaml', 'json', 'ini']



# Generated at 2022-06-22 18:48:08.498820
# Unit test for function add_meta_options
def test_add_meta_options():
    test_parser = Mock()
    add_meta_options(test_parser)
    assert test_parser.add_argument.call_args_list == [call(
        '--force-handlers',
        action='store_true',
        default=False,
        dest='force_handlers',
        help=u'run handlers even if a task fails'
    ),
        call(
            '--flush-cache',
            action='store_true',
            dest='flush_cache',
            help=u'clear the fact cache for every host in inventory'
        )]



# Generated at 2022-06-22 18:48:13.805629
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve',)
    add_vault_options(parser)


#
# Functions to get environment variables, config files and command line options
# (giving precedence to environment variables and finally to command line options)
#


# Generated at 2022-06-22 18:48:20.519299
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    ansible.errors.AnsibleError = Exception
    try:
        import __main__
        sys.argv = ['bin/ansible-playbook']
        # init parser
        parser = argparse.ArgumentParser()
        # create arg option_strings
        option_strings = ['-t']
        # create arg dest
        dest = 'test'
        # create arg action
        action = UnrecognizedArgument(option_strings=option_strings, dest=dest)
        # invoke action
        action(parser=parser, namespace='namespace', values='values')
    except Exception as e:
        assert 'unrecognized arguments: -t' in to_native(e)


# Generated at 2022-06-22 18:48:28.289063
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.error = lambda msg: msg
    parser.parse_args(['--foo', 'bar', '--baz'])
    try:
        parser.parse_args(['--foo', 'bar', '--baz'])
        assert False
    except SystemExit:
        assert True


# The below helps with 2to3 support