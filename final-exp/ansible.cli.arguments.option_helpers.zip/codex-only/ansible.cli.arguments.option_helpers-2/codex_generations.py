

# Generated at 2022-06-22 18:38:32.294652
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, args = parser.parse_known_args(['--check', '-D', '--syntax-check', '-C'])
    assert options.check
    assert options.syntax
    assert options.diff
    assert options.check_mode == '1'
    assert options.diff_mode == 'on'


# Generated at 2022-06-22 18:38:35.206665
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_meta_options(parser)



# Generated at 2022-06-22 18:38:38.866456
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog="ansible-playbook")
    add_meta_options(parser)
    return parser



# Generated at 2022-06-22 18:38:42.219869
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():

    class TestParser(argparse.ArgumentParser):
        def exit(self, status=0, message=None):
            raise SystemExit

    try:
        AnsibleVersion()(TestParser(), 'myprog', [], '-v')
    except SystemExit:
        pass



# Generated at 2022-06-22 18:38:50.047881
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # Mock the sys module, otherwise the unit test will parse real command line arguments
    class MockSysModule(object):
        def exit(self, value):
            self.value = value

    sys = MockSysModule()
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.add_argument('--invalid_argument', action=UnrecognizedArgument)
    parser.parse_args(['--invalid_argument', '--version'])
    assert sys.value == 1, "invalid exit code"



# Generated at 2022-06-22 18:38:54.302639
# Unit test for function ensure_value
def test_ensure_value():
    class Module:
        def __init__(self):
            self.var = None
    mod = Module()
    assert mod.var is None
    ensure_value(mod, 'var', 'foo')
    assert mod.var == 'foo'
    mod.var = 42
    ensure_value(mod, 'var', 'foo')
    assert mod.var == 42



# Generated at 2022-06-22 18:38:55.744551
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f','5'])
    assert args.forks == 5


# Generated at 2022-06-22 18:39:06.665214
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(
        prog="ansible",
        usage="usage: ansible <host-pattern> [options]",
        desc="Ansible command line tool for managing servers",
        epilog="copyright (c) 2018 Ansible Project"
    )
    assert parser.epilog == "copyright (c) 2018 Ansible Project"
    assert parser.description == "Ansible command line tool for managing servers"
    assert parser._optionals._group_actions[0].option_strings == ("-v", "--verbose")
    assert parser._optionals._group_actions[2].option_strings == ("-q", "--quiet")
    assert len(parser._actions) == 1
    assert parser._actions[0].option_strings == ("--version",)

# Generated at 2022-06-22 18:39:12.205183
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser('test_ansible_version')
    args = parser.parse_args(['-v', '-v', 'verbose-mode'])
    assert args.verbosity == 2
    assert args.verbose == 2
    assert args.subcommand == 'verbose-mode'
    
    



# Generated at 2022-06-22 18:39:15.163821
# Unit test for function ensure_value
def test_ensure_value():
    class Options:
        pass
    options = Options()
    options.foo = None
    ensure_value(options, 'foo', ['bar'])
    assert options.foo == ['bar']



# Generated at 2022-06-22 18:39:17.875026
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(args=['--syntax-check'])
    assert args.syntax is True

# Generated at 2022-06-22 18:39:24.718940
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class DummyArgs:
        __exit__ = None
    dummy_args = DummyArgs()
    dummy_args.prog = './test'
    a_v = AnsibleVersion(option_strings=['-V'], required=False, type=str, help=None)
    a_v(dummy_args, None, None, 'V')
    a_v.__call__(dummy_args, None, None, 'V')
    a_v.__call__(dummy_args, None, None)



# Generated at 2022-06-22 18:39:29.063577
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert parser.parse_args(["--task-timeout", "3600"]).task_timeout == 3600
    assert parser.parse_args([]).task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-22 18:39:31.077822
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = AnsibleVersion()
    assert ansible_version(None, None, None, 'ansible-playbook') == None



# Generated at 2022-06-22 18:39:35.656562
# Unit test for function create_base_parser
def test_create_base_parser():
    try:
        with open("/tmp/argparse_test.txt", "w") as f:
            parser = create_base_parser("test", epilog="test epilog", desc="test desc")
            parser.print_usage(file=f)
            parser.print_help(file=f)
        assert True
    except IOError:
        assert False


# Generated at 2022-06-22 18:39:47.122217
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """
    make sure we dont change non-beacon paths
    """
    assert maybe_unfrack_path('@')("not_beacon") == "not_beacon"
    assert maybe_unfrack_path('@')("@not_beacon") == "@not_beacon"

    """
    make sure we only expand values with a beacon
    """
    assert maybe_unfrack_path('@')("@@static") == "@@static"
    assert maybe_unfrack_path('@')("@roles/x/tasks") == "@roles/x/tasks"

    """
    make sure we dont expand values without leading /
    """
    assert maybe_unfrack_path('@')("@static/bar.yml") == "@static/bar.yml"



# Generated at 2022-06-22 18:39:57.322569
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    good_paths = (
        '/foo/bar/',
        '$HOME/.ansible/tmp/foo/bar/',
        '~/.ansible/tmp/foo/bar/',
        '$HOME/tmp/foo/bar/',
        '~/tmp/foo/bar/',
        '$HOME/tmp/foo/bar',
        '~/tmp/foo/bar'
    )
    for path in good_paths:
        assert maybe_unfrack_path(C.DEFAULT_LOCAL_TMP)(path) == C.DEFAULT_LOCAL_TMP + '/foo/bar/'
        assert maybe_unfrack_path(C.DEFAULT_REMOTE_TMP)(path) == C.DEFAULT_REMOTE_TMP + '/foo/bar/'
    # other paths are not modified

# Generated at 2022-06-22 18:40:00.093797
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible.module_utils.common.collections import ImmutableDict
    config = ImmutableDict()
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS, "forks default failed"
    options = parser.parse_args(['-f', '3'])
    assert options.forks == int(3), "forks int failed"


# Generated at 2022-06-22 18:40:05.244335
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action=PrependListAction, default=None)
    (options, args) = parser.parse_known_args(['--list', 'val1', '--list', 'val2'])
    test = ['val2', 'val1']
    assert options.list == test



# Generated at 2022-06-22 18:40:09.880187
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test.yml'])
    assert args.basedir == unfrackpath('test.yml')


# Generated at 2022-06-22 18:40:21.158283
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

    defaults = {'remote_user': C.DEFAULT_REMOTE_USER,
                'private_key_file': C.DEFAULT_PRIVATE_KEY_FILE,
                'scp_extra_args': None,
                'ssh_extra_args': None,
                'sftp_extra_args': None,
                'connection': C.DEFAULT_TRANSPORT,
                'timeout': C.DEFAULT_TIMEOUT,
                'ask_pass': C.DEFAULT_ASK_PASS,
                'connection_password_file': C.CONNECTION_PASSWORD_FILE,
                'ssh_common_args': None}


# Generated at 2022-06-22 18:40:22.105094
# Unit test for function add_basedir_options
def test_add_basedir_options():
    add_basedir_options(None)



# Generated at 2022-06-22 18:40:30.940216
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from ansible.utils.plugins import PluginLoader
    from ansible.plugins.action import ActionBase
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args()

    try:
        action = args.action_plugin
    except AttributeError:
        action = ActionBase

    loader = PluginLoader("ActionModule", action, C.config.get_config_value('ACTION_PLUGINS'))
    if loader.failed_to_load:
        try:
            action = args.action_plugin
        except AttributeError:
            action = ActionBase

        loader = PluginLoader("ActionModule", action, C.config.get_config_value('ACTION_PLUGINS'))

# Generated at 2022-06-22 18:40:39.008953
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible-doc')
    add_async_options(parser)
    options = parser.parse_args(['-B', '60'])
    assert options.seconds == 60
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL

    options = parser.parse_args(['-B', '60', '-P', '30'])
    assert options.seconds == 60
    assert options.poll_interval == 30



# Generated at 2022-06-22 18:40:43.112543
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(description="ansible-playbook")
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check
    assert args.syntax
    assert args.diff


# Generated at 2022-06-22 18:40:47.326081
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser()
    args = parser.parse_args(['--version'])
    assert args.verbosity == C.DEFAULT_VERBOSITY



# Generated at 2022-06-22 18:40:51.090100
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("program_name")
    args = parser.parse_args(["--verbose"])
    assert args.verbosity == 1
    assert args.version == False



# Generated at 2022-06-22 18:41:01.875183
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    from ansible.utils.path import unfrackpath
    import ansible.errors as errors
    from ansible.cli.gather_info import cli_setup_locations, info_help_formatter, config_info_callback

    setup_defaults = cli_setup_locations()
    info_parser = info_help_formatter(setup_defaults)

    # verify that options are sorted
    option_strings_before = [x.option_strings for x in info_parser._get_positional_actions()]
    config_info_callback(setup_defaults)
    option_strings_after = [x.option_strings for x in info_parser._get_positional_actions()]
    assert option_strings_before == option_strings_after

# Generated at 2022-06-22 18:41:13.636476
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    test_parser = argparse.ArgumentParser(prog="ansible")
    add_tasknoplay_options(test_parser)
    # test default
    with patch.dict(os.environ, {'ANSIBLE_TASK_TIMEOUT': '30'}, clear=True):
        assert test_parser.parse_args([])
    # test default as env var
    with patch.dict(os.environ, {'ANSIBLE_TASK_TIMEOUT': '30'}, clear=True):
        assert test_parser.parse_args([])
    # test default is overridable
    assert test_parser.parse_args(['--task-timeout', '0'])
    # test a negative value

# Generated at 2022-06-22 18:41:18.637299
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b'])
    assert args.become



# Generated at 2022-06-22 18:41:21.749429
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    PrependListAction(option_strings=['--a'], dest='a', nargs='+', default=[])
    p.print_help()  # should not raise an exception



# Generated at 2022-06-22 18:41:30.077362
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)
    assert_equals(parser.add_argument.call_count, 2)
    assert_call(parser.add_argument, 1, 0, '--force-handlers', default=C.DEFAULT_FORCE_HANDLERS, dest='force_handlers', action='store_true',
                help="run handlers even if a task fails")
    assert_call(parser.add_argument, 1, 1, '--flush-cache', dest='flush_cache', action='store_true',
                help="clear the fact cache for every host in inventory")


# Generated at 2022-06-22 18:41:35.802161
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('ansible-config')
    assert parser.description == "Show Ansible's config settings used by Ansible."
    assert parser.epilog is None
    assert '--version' in parser.format_usage()
    assert '--version' in parser.format_help()
    assert 'show program\'s version number, config file location, configured module search path,' \
        ' module location, executable location and exit' in parser.format_help()
    options = parser.parse_args([])
    assert options.help is False
    assert options.quiet is False
    assert options.verbosity == 0 # default verbosity level set to 0



# Generated at 2022-06-22 18:41:45.572826
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class DummyClass:
        def __init__(self, option_strings):
            self.option_strings = option_strings

    args = [
        ['-f', '--foo'],
        ['-b', '--bar'],
        ['-c', '--baz'],
    ]
    expected = [['-b', '--bar'], ['-c', '--baz'], ['-f', '--foo']]

    class DummyParser(object):
        def __init__(self):
            self.actions = []
            self.option_groups = []

        def add_argument(self, *args, **kwargs):
            action = DummyClass(kwargs['option_strings'])
            self.actions.append(action)

    parser = DummyParser()
    formatter = SortingHelpFormatter()

# Generated at 2022-06-22 18:41:47.369012
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    version = AnsibleVersion(option_strings=['--version'])



# Generated at 2022-06-22 18:41:51.013294
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    parser.parse_args(['--version'])



# Generated at 2022-06-22 18:41:57.458442
# Unit test for function ensure_value
def test_ensure_value():
    from ansible.utils.debug import disable_warnings
    from ansible.module_utils.common.collections import ImmutableDict
    class test_namespace(object):
        class ImmutableDict(dict):
            def __hash__(self):
                return id(self)
            def _immutable(self, *args, **kws):
                raise TypeError('object is immutable')
            __setitem__ = _immutable
            __delitem__ = _immutable
            clear = _immutable
            update = _immutable
            setdefault = _immutable
            pop = _immutable
            popitem = _immutable

        def __init__(self, dct=None):
            if dct is None:
                dct = {}
            self.__dict__ = self.ImmutableDict(dct)

   

# Generated at 2022-06-22 18:41:59.239128
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    return parser
# Test Case

# Generated at 2022-06-22 18:42:02.076936
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    action_list = ['-K', '--ask-become-pass']
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args, extra_args = parser.parse_known_args(action_list)
    assert args.become_ask_pass == True



# Generated at 2022-06-22 18:42:04.879679
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    argv = ['--list-hosts', '-i', '1', '-i', '2,3', '-l', '4']
    opts = parser.parse_args(args=argv)
    assert opts.listhosts
    assert opts.inventory == ['1', '2,3']
    assert opts.subset == '4'


# Generated at 2022-06-22 18:42:13.648025
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.parse_args('-M module/path -M other/path'.split())

    for action in parser._actions:
        if action.dest == 'module_path':
            assert [action.option_strings,
                    action.dest,
                    action.default,
                    action.type(action.default),
                    action.required,
                    action.help] == [['-M', '--module-path'],
                                     'module_path',
                                     None,
                                     'None',
                                     False,
                                     'prepend colon-separated path(s) to module library (default=None)']



# Generated at 2022-06-22 18:42:17.895174
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', action=UnrecognizedArgument)
    parser.error = mock.Mock()
    parser.parse_args(['-t'])
    parser.error.assert_called_with('unrecognized arguments: -t')



# Generated at 2022-06-22 18:42:20.973402
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='test_add_vault_options')
    add_vault_options(parser)
    results = parser.parse_args(['--vault-id', 'p1', '--vault-password-file', 'vault_password_file'])
    assert len(results.vault_ids) == 1 and results.vault_ids[0] == 'p1'
    assert len(results.vault_password_files) == 1 and results.vault_password_files[0] == 'vault_password_file'



# Generated at 2022-06-22 18:42:22.507863
# Unit test for function add_subset_options
def test_add_subset_options():
    (options, args) = create_parser([], subset=False).parse_args()
    assert options.tags == C.TAGS_RUN
    assert options.skip_tags == C.TAGS_SKIP



# Generated at 2022-06-22 18:42:27.653419
# Unit test for function add_connect_options
def test_add_connect_options():
    options = {}
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    parser.parse_args(args=[], namespace=options)
    assert options.get('ask_pass') is False
    assert options.get('connection_password_file') == C.CONNECTION_PASSWORD_FILE



# Generated at 2022-06-22 18:42:33.236982
# Unit test for function add_subset_options
def test_add_subset_options():
    """
    Test function add_subset_options
    """
    parser = argparse.ArgumentParser(description='Test runner')

    add_subset_options(parser)
    (options, args) = parser.parse_known_args()

    assert options.tags == C.TAGS_RUN
    assert options.skip_tags == C.TAGS_SKIP


# Generated at 2022-06-22 18:42:43.790659
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Create an action with a long option string and add it
    action = argparse.Action(option_strings=['--foobar'], dest='foobar')
    formatter = SortingHelpFormatter()
    formatter.add_argument(action)

    # Create an action with a short option string and add it
    action = argparse.Action(option_strings=['-f'], dest='foobar')
    formatter.start_section('Test section')
    formatter.add_argument(action)

    # Assert that the short option string appears before the long option string
    # When printing usage and help messages
    assert '[-f]' in formatter.format_usage()
    assert '[-f]' in formatter.format_help()


# Generated at 2022-06-22 18:42:54.138832
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    for path1 in [ u'/ab/cd/ef',
                   u'ssh://user@myhost.com/ab/cd/ef',
                   u'https://user@myhost.com/ab/cd/ef',
                   u'git://user@myhost.com/ab/cd/ef' ]:
        for path2 in [ u'ab/cd/ef',
                       u'~/ab/cd/ef',
                       u'$HOME/ab/cd/ef',
                       u'./ab/cd/ef' ]:
            assert maybe_unfrack_path(path1)(path2) == (path1 + u'/' + path2)


# Generated at 2022-06-22 18:42:57.067251
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    assert add_verbosity_options.__globals__['C'].DEFAULT_VERBOSITY == 0
    assert add_verbosity_options.__globals__['C'].DEFAULT_VERBOSITY == 0



# Generated at 2022-06-22 18:43:01.478032
# Unit test for function add_module_options
def test_add_module_options():
    test_parser = argparse.ArgumentParser()
    add_module_options(test_parser)
    assert test_parser.parse_args(['-M', 'a:b:c']).module_path == ['a', 'b', 'c']
    assert test_parser.parse_args([]).module_path == []
    assert test_parser.parse_args(['-M', 'a']).module_path == ['a']
    assert test_parser.parse_args(['-Ma:b:c']).module_path == ['a', 'b', 'c']



# Generated at 2022-06-22 18:43:04.815052
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # test the default :
    assert AnsibleVersion(default=True).__call__(parser=None, namespace=None, values=None, option_string=None)==None


# Generated at 2022-06-22 18:43:15.971252
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    from textwrap import dedent
    from ansible.utils.display import Display
    d = Display()
    my_stderr = d.StdoutNoop()
    my_stderr.pipe = False
    my_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, add_help=False)
    my_parser._optionals.title = "Options"
    my_parser._optionals.description = dedent("""\
        Here is an explanation of options.""")
    my_parser.add_argument("-d", "--debug", help="debug mode", action="store_true")
    my_parser.add_argument("-x", "--x", help="x", action="store_true")

# Generated at 2022-06-22 18:43:22.785896
# Unit test for function add_vault_options
def test_add_vault_options():
    # Test that the base group can only be divided into the mutually exclusive groups : ask-vault-password or vault-password-file
    # Test that the vault-password-file contains the correct path
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(["--ask-vault-password", "--vault-password-file=/home/user/vaultpw.txt", "--vault-password-file=/home/user/vault2.txt"])
    assert args.ask_vault_pass == True
    assert args.vault_password_files == ['/home/user/vaultpw.txt', '/home/user/vault2.txt']


# Generated at 2022-06-22 18:43:33.313923
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class Action(argparse.Action):
        def __init__(self, option_strings, dest, nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None):
            super(Action, self).__init__(option_strings=option_strings, dest=dest, nargs=nargs, const=const, default=default, type=type, choices=choices, required=required, help=help, metavar=metavar)

    class Parser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super(Parser, self).__init__(*args, formatter_class=SortingHelpFormatter, **kwargs)

    parser = Parser()

# Generated at 2022-06-22 18:43:39.677983
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = AnsibleOptionsParser()
    add_runas_options(parser)
    opt = parser.parse_args(['--become-method', 'su', '-b'])
    assert opt.become == True
    assert opt.become_user == None
    assert opt.become_method == 'su'
    opt = parser.parse_args(['--become-user', 'hongbin', '--ask-become-pass'])
    assert opt.become_user == 'hongbin'
    assert opt.become_pass == True



# Generated at 2022-06-22 18:43:47.302649
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    assert ensure_value(ns, 'foo', 'bar') == 'bar'
    assert ns.foo == 'bar'
    ns = Namespace()
    ns.foo = 'baz'
    assert ensure_value(ns, 'foo', 'bar') == 'baz'
    assert ns.foo == 'baz'


#
# general command line parsing
#

# Generated at 2022-06-22 18:43:50.318363
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(
        prog="test_add_fork_options",
        formatter_class=SortingHelpFormatter,
    )
    add_fork_options(parser)
    opts = parser.parse_args(["--forks", "10"])
    assert opts.forks == 10


# Generated at 2022-06-22 18:43:53.607980
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@/path") == "@" + unfrackpath("/path")
    assert maybe_unfrack_path("@")("/path") == "/path"


# Generated at 2022-06-22 18:43:59.202578
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args('-K'.split())
    assert args.become_ask_pass is True
    assert args.become_password_file is None
    args = parser.parse_args('--become-password-file=./test_become_pass_file'.split())
    assert args.become_ask_pass is False
    assert args.become_password_file == './test_become_pass_file'
    args = parser.parse_args('--become-password-file=./test_become_pass_file -K'.split())
    assert args.become_ask_pass is True
    assert args.become_password_file == './test_become_pass_file'

# Generated at 2022-06-22 18:44:04.997540
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == unfrackpath('/etc/ansible')
    assert unfrack_path(pathsep=True)('/etc/ansible:/etc/ansible') == [unfrackpath('/etc/ansible'), unfrackpath('/etc/ansible')]



# Generated at 2022-06-22 18:44:08.753269
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == unfrackpath('foo')
    assert unfrack_path()('-') == '-'
    assert unfrack_path(True)('foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]



# Generated at 2022-06-22 18:44:13.908241
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action=AnsibleVersion, nargs=0)
    args, unknown_args = parser.parse_known_args(['--version'])
    assert args.version.__class__.__name__ == "function"


#
# Utility functions for displaying version information
#

# Generated at 2022-06-22 18:44:25.264035
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument("--foo", action=UnrecognizedArgument)
    result = parser.parse_args("--foo".split(" "))



# Generated at 2022-06-22 18:44:28.373113
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='PROG')
    add_check_options(parser)
    return parser.parse_args([])



# Generated at 2022-06-22 18:44:34.680464
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)('/path/to/ansible') == ['/path/to/ansible']
    assert unfrack_path()('/path/to/ansible') == '/path/to/ansible'
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('/path/to/ansible:/path/to/more') == '/path/to/ansible'



# Generated at 2022-06-22 18:44:37.721866
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/test') == '@'+unfrackpath('/test')
# end Unit test for function maybe_unfrack_path


# Generated at 2022-06-22 18:44:44.202005
# Unit test for function version
def test_version():
    import os
    import re
    import sys
    import tempfile
    # Setup
    repo_path = os.path.join('tests', 'utils', 'fixtures', 'test_version', '.git')
    # test the version with and without a prog
    for prog in ['test_version', None]:
        version_str = version(prog)
        if prog is None:
            match_str = '^test_version \[core '
        else:
            match_str = '^%s \[core ' % prog
        assert re.match(match_str, version_str)
        # find ansible path
        if sys.platform == 'win32':
            # Where is ansible on Windows
            utils_path = os.path.join('lib', 'ansible')

# Generated at 2022-06-22 18:44:48.935214
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser('test')
    add_verbosity_options( parser )
    args = parser.parse_args()
    assert args.verbosity == C.DEFAULT_VERBOSITY

# Generated at 2022-06-22 18:44:53.618964
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    parser.add_argument('test',nargs=1,help="help")
    parser.add_argument('-o', '--one-line', dest='one_line', action='store_true',
                        help='condense output')
    parser.parse_args(args=['-e', '@/tmp/foo', '-o' ,'hello'])



# Generated at 2022-06-22 18:44:55.681290
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert options.flush_cache is None

# Generated at 2022-06-22 18:44:56.349681
# Unit test for function add_fork_options
def test_add_fork_options():
    assert add_fork_options(argparse.ArgumentParser)


# Generated at 2022-06-22 18:45:04.164578
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    argv = 'ansible-playbook --ask-become-pass playbook.yml'.split()
    args = parser.parse_args(argv)
    for attr in ['become_password_file', 'become_ask_pass']:
        assert getattr(args, attr)



# Generated at 2022-06-22 18:45:11.815019
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    test_parser = create_base_parser('TestArgParser')
    test_parser.add_argument('-v', '--verbose', dest='verbosity', default=C.DEFAULT_VERBOSITY, action="count",
                        help="verbose mode (-vvv for more, -vvvv to enable connection debugging)")
    assert test_parser.parse_args(['-v']).verbosity == 1
    test_parser = create_base_parser('TestArgParser')
    test_parser.add_argument('-v', '--verbose', dest='verbosity', default=C.DEFAULT_VERBOSITY, action="count",
                        help="verbose mode (-vvv for more, -vvvv to enable connection debugging)")
    assert test_parser.parse_args(['-vvv']).verbosity == 3
    test_parser

# Generated at 2022-06-22 18:45:14.765117
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.parse_args(['--playbook-dir', 'path'])



# Generated at 2022-06-22 18:45:20.612303
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    a = Namespace()
    ensure_value(a, 'bar', 'baz')
    assert a.bar == 'baz'

    b = Namespace()
    ensure_value(b, 'bar', [])
    b.bar.append('baz')
    assert b.bar == ['baz']


# -----------------------------------------

#
# Option Parser
#

# Generated at 2022-06-22 18:45:22.232428
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.task_timeout is C.TASK_TIMEOUT

# Generated at 2022-06-22 18:45:28.584802
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        description=None,
        conflict_handler='resolve',
    )
    parser.prog = 'ansible'
    add_verbosity_options(parser)
    opts = parser.parse_args(['-v'])
    assert opts.verbosity == 1
    opts = parser.parse_args(['-vvvvvvvv'])
    assert opts.verbosity == 7


# Generated at 2022-06-22 18:45:30.036696
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    AnsibleVersion()

#
# main option parser
#

# Generated at 2022-06-22 18:45:40.610585
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.cli import CLI
    from ansible.parsing.splitter import parse_kv
    action = PrependListAction(option_strings=('-e', '--extra-vars'),
                               dest='extra_vars',
                               type=parse_kv,
                               metavar='key=value')
    namespace = argparse.Namespace(extra_vars=[])
    action(parser=CLI, namespace=namespace, values='test=test')
    assert namespace.extra_vars == ['test=test']
    action(parser=CLI, namespace=namespace, values='test=test')
    assert namespace.extra_vars == ['test=test', 'test=test']



# Generated at 2022-06-22 18:45:46.891869
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    import tempfile
    test_dir = tempfile.mkdtemp()
    try:
        assert maybe_unfrack_path('/')('/' + test_dir) == test_dir
        assert maybe_unfrack_path('/')('$ANSIBLE_HOME/data') == '$ANSIBLE_HOME/data'
    finally:
        from shutil import rmtree
        rmtree(test_dir)
test_maybe_unfrack_path()



# Generated at 2022-06-22 18:45:56.331491
# Unit test for function add_output_options
def test_add_output_options():
    data = dict(
        one_line   = "add_output_options(): one_line",
        tree       = "add_output_options(): tree"
    )
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    parsed_args = parser.parse_args(["-o","-t","add_output_options(): tree"])

 
    assert (data['one_line'] == parsed_args.one_line)
    assert (data['tree'] == parsed_args.tree)



# Generated at 2022-06-22 18:46:02.523985
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args("-t tag1 --tags tag2 --skip-tags=skip1 --skip-tags=skip2".split())

    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-22 18:46:04.186166
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args()
    assert args.forks == C.DEFAULT_FORKS



# Generated at 2022-06-22 18:46:12.861387
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("ansible-console")
    # parser.format_usage()
    print("parser.prog = {0}".format(parser.prog))
    print("parser.usage = {0}".format(parser.usage))
    print("parser.epilog = {0}".format(parser.epilog))
    print("parser.description = {0}".format(parser.description))
    print("parser.version = {0}".format(parser.version))
    print("parser.formatter_class = {0}".format(parser.formatter_class))



# Generated at 2022-06-22 18:46:19.193594
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args()
    assert getattr(options, 'poll_interval',False)==15
    assert getattr(options, 'seconds',False)==0
    assert str(getattr(options, 'poll_interval')) == '15'



# Generated at 2022-06-22 18:46:23.278516
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '42'])
    assert args.task_timeout == 42, 'test_add_tasknoplay_options failed'



# Generated at 2022-06-22 18:46:35.365559
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class TestSortingHelpFormatter(object):
        def __init__(self):
            self.option_strings = ['a']
    test_list = [TestSortingHelpFormatter() for x in range(10)]
    test_list[0].option_strings = ['b']
    test_list[5].option_strings = ['c']
    test_list[9].option_strings = ['d']
    assert test_list[0].option_strings == ['a']
    assert test_list[5].option_strings == ['c']
    assert test_list[9].option_strings == ['d']
    result_list = SortingHelpFormatter().add_arguments(test_list)
    assert result_list[0].option_strings == ['a']
    assert result_list[5].option_strings == ['b']


# Generated at 2022-06-22 18:46:45.417645
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('-p', action=PrependListAction)
    args = arg_parser.parse_args('-p a -p b'.split(' '))
    assert args.p == ['a', 'b']
    # argparse doesn't provide a very clean way to get back to the original arguments.
    try:
        arg_parser.parse_args('-p a -p b -p c'.split(' '))
    except SystemExit as e:
        assert e.code == 2
        # The SystemExit exception object has a single attribute, code, which is used to specify the exit status.
        #       The default value for code is None, which indicates that the process exited without an error message.
        #       If the value is an integer (or equivalent), it

# Generated at 2022-06-22 18:46:50.326625
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['--check'])
    assert options.check
    options = parser.parse_args(['--syntax-check'])
    assert options.syntax
    options = parser.parse_args(['-D'])
    assert options.diff

#
# Options for dealing with extra config files
#

# Generated at 2022-06-22 18:47:01.295230
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    opts = parser._get_kwargs()
    # ['_get_kwargs', '_get_positional_actions', '_get_values', '_parse_known_args', '_subparsers']
    assert len(opts) == 52
    # ['_get_args', '_get_optional_actions', '_get_optional_groups', '_get_positional_actions', '_match_arguments_partial', '_option_string_actions', '_parse_known_args', '_parse_known_intermixed_args', '_parse_optional', '_parse_positional', '_parse_subcommand', '_parse_suboptions', '_pop_action', '_positional_actions', '_print_message',

# Generated at 2022-06-22 18:47:10.410325
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    return parser.parse_args(["-i", "file1","-i","file2","-i","file3","-i","file4","-i","file5","-i","file6","-i","file7","-i","file8","--list-hosts","-l","host1","host2","host3"])

# Unit test
if __name__ == "__main__":
    options = test_add_inventory_options()
    print(options)

# Generated at 2022-06-22 18:47:14.788851
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS



# Generated at 2022-06-22 18:47:22.008706
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser=argparse.ArgumentParser()
    add_inventory_options(parser)
    print(parser.print_help())
    test_args1=['-i','hosts']
    test_args2=['-l','dev']
    test_args3=['--list-hosts']
    args = parser.parse_args(test_args1)
    print(args)
    args = parser.parse_args(test_args2)
    print(args)
    args = parser.parse_args(test_args3)
    print(args)

# test_add_inventory_options()

# Generated at 2022-06-22 18:47:35.561191
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """ Unit test for function add_tasknoplay_options """
    # pylint: disable=unused-variable
    parser = argparse.ArgumentParser()

    add_tasknoplay_options(parser)
    args = parser.parse_known_args(['--task-timeout', '60'])
    assert args[0].task_timeout == 60

    args = parser.parse_known_args(['--task-timeout', '0'])
    assert args[0].task_timeout == 60

    args = parser.parse_known_args(['--task-timeout', '60.5'])
    assert args[0].task_timeout == 60

    args = parser.parse_known_args(['--task-timeout', 'a'])
    assert args[0].task_timeout == 60

    args = parser.parse_known

# Generated at 2022-06-22 18:47:39.687926
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    return parser.parse_known_args(['-b', '--become-method', 'sudo', "--become-user", 'root'])



# Generated at 2022-06-22 18:47:47.201882
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    opts = parser.parse_args(['--vault-id', 'alpha', '--vault-id', 'bravo', '--ask-vault-password',
                              '--vault-password-file', '/home/mfa/vault-pass', '--vault-password-file', '/home/mfa/vault-pass2'])
    assert opts.vault_ids == ['alpha', 'bravo']
    assert opts.ask_vault_pass is True
    assert opts.vault_password_files == ['/home/mfa/vault-pass', '/home/mfa/vault-pass2']

# Generated at 2022-06-22 18:47:49.891619
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    append_action = PrependListAction("-a", "append", const=23)



# Generated at 2022-06-22 18:47:59.487117
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
    )
    add_check_options(parser)
    options = parser.parse_args(['--check'])
    assert options.check
    assert not options.syntax
    assert not options.diff
    options = parser.parse_args(['--syntax-check'])
    assert not options.check
    assert options.syntax
    assert not options.diff
    options = parser.parse_args(['--diff'])
    assert not options.check
    assert not options.syntax
    assert options.diff


# Generated at 2022-06-22 18:48:04.662080
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    result = vars(parser.parse_args(["-C"]))

    assert result['check']
    assert not result['syntax']
    assert result['diff'] == C.DIFF_ALWAYS



# Generated at 2022-06-22 18:48:09.385661
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    p = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    p.add_argument('--foo')
    p.add_argument('bar')
    p.add_argument('--baz')
    p.print_help()



# Generated at 2022-06-22 18:48:19.132569
# Unit test for function add_vault_options
def test_add_vault_options():
    from ansible.module_utils.common.parameters import get_config_definition
    from ansible.module_utils.common.process import AnsibleProcess
    from ansible.utils.display import Display
    display = Display()
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter
    )
    parser = add_vault_options(parser)
    opts = parser.parse_args([])
    try:
        definition_cache = get_config_definition(C.config.get_config_definition('DEFAULT_VAULT_IDENTITY_LIST'))
        definition_cache.merge_with(opts)
    except AnsibleOptionsError as e:
        display.error(to_text(e))

# Generated at 2022-06-22 18:48:21.902568
# Unit test for function add_subset_options
def test_add_subset_options():
    pass


# Generated at 2022-06-22 18:48:27.664055
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', action=UnrecognizedArgument)
    try:
        parser.parse_args(['-v'])
    except SystemExit as e:
        assert isinstance(e, SystemExit)
        assert e.args[0] == 2
