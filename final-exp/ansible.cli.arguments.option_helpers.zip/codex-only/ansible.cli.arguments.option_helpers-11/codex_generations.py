

# Generated at 2022-06-22 18:38:25.474651
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.parse_args("")



# Generated at 2022-06-22 18:38:32.893157
# Unit test for function add_basedir_options
def test_add_basedir_options():
    # Test for unfrack_path
    assert unfrack_path() == unfrack_path(pathsep=False)
    assert unfrack_path(pathsep=True) == ['C:/Users/kscot/ansible/hacking/test/sanity/roles/role1', 'C:/Users/kscot/ansible/hacking/test/sanity/roles/role2', 'C:/Users/kscot/ansible/hacking/test/sanity/roles/role3']



# Generated at 2022-06-22 18:38:43.525160
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    #
    # Test code for method __call__ of class UnrecognizedArgument
    #
    # Note: Test case name is method name __call__. This is important for following reasons.
    # 1. This ensures testcase name is in sync with method name.
    # 2. This ensures testcase gets executed as part of unit test *test_option_parsers.py*
    #
    class TestArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            self.error_msg = message
            print(message)

        @property
        def error_msg(self):
            return self._error_msg

        @error_msg.setter
        def error_msg(self, msg):
            self._error_msg = msg

    # testcase 1
    test_argparser = TestArgumentParser()


# Generated at 2022-06-22 18:38:51.976851
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser =  argparse.ArgumentParser(
        prog='testprog',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_verbosity_options(parser)
    args = parser.parse_args([])
    assert args.verbosity == 0
    args = parser.parse_args(["-v"])
    assert args.verbosity == 1
    args = parser.parse_args(["-vv"])
    assert args.verbosity == 2
    args = parser.parse_args(["-vvvv"])
    assert args.verbosity == 4



# Generated at 2022-06-22 18:38:54.590623
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    assert parser
    return True


#
# Functions to make basic objects used by modules globally available
#

# these modules require some special handling as they are loaded early and
# need to respect the ANSIBLE_KEEP_REMOTE_FILES environment variable.
display = Display()
encrypt = VaultLib()
loader = DataLoader()


# Generated at 2022-06-22 18:38:59.676830
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='test')
    add_runtask_options(parser)
    result = parser.parse_args(['--extra-vars', 'test1=value1', '--extra-vars', 'test2=value2',
                                '--extra-vars', '@test.json', '--extra-vars', '@test.yaml'])
    assert result.__dict__['extra_vars'] == ["test1=value1", "test2=value2", "@test.json", "@test.yaml"]



# Generated at 2022-06-22 18:39:00.598180
# Unit test for function add_connect_options
def test_add_connect_options():
    g = add_connect_options


#
# Main CLI parser creation
#

# Generated at 2022-06-22 18:39:08.118924
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.constants import AnsibleDefaultVars
    from ansible.utils.color import colorize, hostcolor
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext
    import StringIO

    class Parser:
        def error(self, *args, **kwargs):
            raise Exception('there is an error')

    parser = Parser()

    namespace = argparse.Namespace()
    PrependListAction(['option_string'], 'dest')(parser, namespace, ['list_value'], 'option_string')

    namespace = argparse.Namespace()
    PrependListAction(['option_string'], 'dest')(parser, namespace, ['list_value'], 'option_string')

# Generated at 2022-06-22 18:39:15.559204
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # setup
    beacon = '@'
    non_beacon_value = 'foo'
    fracked_path_value = '/tmp/test/'
    # exercise
    actual = maybe_unfrack_path(beacon)(non_beacon_value)
    assert non_beacon_value == actual
    actual = maybe_unfrack_path(beacon)(beacon + fracked_path_value)
    assert beacon + unfrackpath(fracked_path_value) == actual


# Generated at 2022-06-22 18:39:18.219593
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/home/test/file') == '@' + unfrackpath('/home/test/file')


# Generated at 2022-06-22 18:39:22.170024
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, help='show Ansible version number and exit')
    assert getattr(parser, 'prog') == 'prog'


#
# print helpers
#


# Generated at 2022-06-22 18:39:27.566776
# Unit test for function add_inventory_options
def test_add_inventory_options():
    #Prepare
    parser = create_base_parser('add_inventory_options')
    # verify
    add_inventory_options(parser)
    args = parser.parse_args()

    # Assertion
    assert args.listhosts == False
    assert args.inventory == None
    assert args.subset == None



# Generated at 2022-06-22 18:39:30.685266
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, args = parser.parse_known_args()
    assert options.check is False
    assert options.syntax is False
    assert options.diff is True

# Generated at 2022-06-22 18:39:32.295123
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('/usr/bin/ansible')
    assert parser

# Generated at 2022-06-22 18:39:33.792402
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """Constructor of class SortingHelpFormatter doesn't fail."""
    SortingHelpFormatter()



# Generated at 2022-06-22 18:39:37.434714
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='foo', formatter_class=SortingHelpFormatter)
    add_basedir_options(parser)
    fn = '~/foo'
    args = parser.parse_args([f'--playbook-dir={fn}'])
    assert args.basedir == unfrackpath(fn)



# Generated at 2022-06-22 18:39:42.086758
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    opts = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert opts.force_handlers is True
    assert opts.flush_cache is True



# Generated at 2022-06-22 18:39:43.831707
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['--forks', '30'])
    assert options.forks == 30



# Generated at 2022-06-22 18:39:48.105797
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar',
                             '--ask-vault-password', '--vault-password-file', '/tmp/foo'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.ask_vault_pass
    assert args.vault_password_files == ['@/tmp/foo']
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar',
                              '--vault-password-file', '/tmp/foo'])
    assert args.vault_ids == ['foo', 'bar']
    assert not args.ask_vault_

# Generated at 2022-06-22 18:39:50.715497
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = add_basedir_options(argparse.ArgumentParser())
    options = parser.parse_args('--playbook-dir foo/bar'.split())
    assert options.basedir == 'foo/bar'


# Generated at 2022-06-22 18:39:53.921243
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    return parser
# Unit test added

# Generated at 2022-06-22 18:39:57.365457
# Unit test for function ensure_value
def test_ensure_value():
    m = argparse.Namespace()
    ensure_value(m, 'foo', 'bar')
    assert m.foo == 'bar'

    m = argparse.Namespace()
    ensure_value(m, 'foo', [])
    assert m.foo == []


#
# Fact discovery
#

# Generated at 2022-06-22 18:40:02.359742
# Unit test for function add_basedir_options
def test_add_basedir_options():
    test_parser = create_test_parser()
    add_basedir_options(test_parser)
    test_options = test_parser.parse_args(['--playbook-dir', '/tmp'])
    assert test_options.basedir == '/tmp', 'The base dir should be set to /tmp'


# Generated at 2022-06-22 18:40:07.515802
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = parser.parse_args(['-v','-v','--verbose','--verbose','--verbose','--verbose'])
    assert args.verbosity == 5



# Generated at 2022-06-22 18:40:13.340726
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # initialize a class
    vers = AnsibleVersion(option_strings=['--version'])
    # create a function call
    options = "ansible-playbook"
    values = None
    vers(options, values)
    # assert result
    assert vers.__call__(options, values) == 0

#
# Main Parser
#

# Generated at 2022-06-22 18:40:16.712432
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='argument parser')
    add_runas_options(parser)
    args = parser.parse_args()
    assert args.become_method == C.DEFAULT_BECOME_METHOD



# Generated at 2022-06-22 18:40:26.977260
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class Foo(object):
        def __init__(self, x):
            self.option_strings = x

    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-z')
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')

# Generated at 2022-06-22 18:40:31.306812
# Unit test for function create_base_parser
def test_create_base_parser():
    prog = "fakeprog"
    usage = "fake usage"
    desc = "fake desc"
    epilog = "fake epilog"

    parser = create_base_parser(prog, usage, desc, epilog)
    assert parser.prog == prog
    assert hasattr(parser, 'version')
    assert hasattr(parser, 'verbose')
    assert hasattr(parser, 'verbosity')



# Generated at 2022-06-22 18:40:40.492758
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='test_add_runas_options')
    add_runas_options(parser)
    options = parser.parse_args(['--become', '--become-method', 'pbrun', '--become-user', 'test_user'])
    assert options.become
    assert options.become_method == 'pbrun'
    assert options.become_user == 'test_user'

    options = parser.parse_args(['--ask-become-pass'])
    assert not options.become
    assert options.ask_become_pass



# Generated at 2022-06-22 18:40:47.843333
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    action = PrependListAction(
        option_strings=['--opt1', '--opt2'],
        dest='foo',
        nargs=1,
        const=None,
        default=None,
        type=None,
        choices=None,
        required=False,
        help='test',
        metavar=None)
    assert isinstance(action, argparse.Action)
    assert action.__dict__ == {
        'option_strings': ['--opt1', '--opt2'],
        'dest': 'foo',
        'nargs': 1,
        'const': None,
        'default': None,
        'type': None,
        'choices': None,
        'required': False,
        'help': 'test',
        'metavar': None}


# Generated at 2022-06-22 18:40:51.463999
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    cmdline = parser.parse_args(['--syntax-check'])
    assert cmdline.syntax_check == True

# Generated at 2022-06-22 18:40:54.642739
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options, _ = parser.parse_known_args()
    assert options.one_line is False
    assert options.tree is None


# Generated at 2022-06-22 18:40:56.254733
# Unit test for function add_inventory_options
def test_add_inventory_options():
    base_parser = create_base_parser('/fakepath', usage="foo")
    add_inventory_options(base_parser)
    base_parser.parse_args(['-i', '/fake/inventory', '--list-hosts'])



# Generated at 2022-06-22 18:41:02.872774
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfrack_path_cb = maybe_unfrack_path('@')
    assert to_native(unfrack_path_cb('@/path/to/library')) == '@/path/to/library'
    assert to_native(unfrack_path_cb('@@/path/to/library')) == '@@/path/to/library'
    assert to_native(unfrack_path_cb('@./path/to/library')) == '@./path/to/library'
    assert to_native(unfrack_path_cb('@@./path/to/library')) == '@@./path/to/library'



# Generated at 2022-06-22 18:41:05.095315
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    return parser



# Generated at 2022-06-22 18:41:12.504753
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    found_unexpected_errors = False
    try:
        PrependListAction(option_strings=['a', 'b'],
                          dest='dest', nargs=0, const=None, default=None, type=None,
                          choices=None, required=False, help=None, metavar=None)
    except ValueError:
        found_unexpected_errors = True
    assert not found_unexpected_errors

#
# Refactored options
#


# Generated at 2022-06-22 18:41:23.530922
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()

    # Regular add_inventory_options
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'myinventory', '--list-hosts', '-l', 'mylimit'])

    assert args.inventory == ['myinventory']
    assert args.listhosts
    assert args.subset == 'mylimit'

    # Test add_inventory_options with a positional
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    parser.add_positionals(('infile', 'outfile'))
    args = parser.parse_args(['-i', 'myinventory', '--list-hosts', '-l', 'mylimit', 'dummyfile', 'dummyfile2'])


# Generated at 2022-06-22 18:41:30.516082
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    args = add_verbosity_options(parser)
    args = parser.parse_args()
    assert args.verbosity == C.DEFAULT_VERBOSITY
    args = parser.parse_args(["-v"])
    assert args.verbosity == C.DEFAULT_VERBOSITY + 1
    args = parser.parse_args(["-vv"])
    assert args.verbosity == C.DEFAULT_VERBOSITY + 2
# Unit test end


# Generated at 2022-06-22 18:41:35.615710
# Unit test for function add_runtask_options
def test_add_runtask_options():
    writetmpfile = open('temp.txt','w')
    writetmpfile.write('{"a":1}')
    writetmpfile.close()

    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', 'a=2', '-e', 'b=@temp.txt'])
    assert args.extra_vars[0] == 'a=2'
    assert args.extra_vars[1] == "{'a': 1}"



# Generated at 2022-06-22 18:41:36.627289
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)


# Generated at 2022-06-22 18:41:46.034623
# Unit test for function version
def test_version():
    assert version('Ansible')
    assert version('Ansible') == version()

#
# Options that do not get written to the configuration file
#

# Generated at 2022-06-22 18:41:56.424825
# Unit test for function ensure_value
def test_ensure_value():
    # type: () -> None
    mock_namespace = argparse.Namespace()
    assert ensure_value(mock_namespace, 'test_attr', 'test_val') == 'test_val'
    assert mock_namespace.test_attr == 'test_val'
    mock_namespace.test_attr = 'new_test_val'
    assert ensure_value(mock_namespace, 'test_attr', 'new_new_test_val') == 'new_test_val'
    # check with default being a list
    assert ensure_value(mock_namespace, 'test_attr2', []) == []

#
# Option parsers for ansible-* tools
#

# Generated at 2022-06-22 18:42:07.144218
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    n = Namespace()
    # test that ensure_value(n, 'foo', 42) returns and sets n.foo to 42
    ensure_value(n, 'foo', 42)
    assert n.foo == 42
    # test that ensure_value(n, 'foo', 23) returns and leaves n.foo at 42
    ensure_value(n, 'foo', 23)
    assert n.foo == 42
    # test that ensure_value(n, 'bar', 42) returns and sets n.bar to 42
    ensure_value(n, 'bar', 42)
    assert n.bar == 42


#
# Common Parser
#

# Generated at 2022-06-22 18:42:16.135395
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_connect_options(parser)
    result = parser.parse_args(args=[])
    assert result.connection == 'smart'
    assert result.private_key_file == '~/.ssh/id_rsa'
    assert result.remote_user == 'root'
    assert result.timeout == 10
    assert result.ssh_common_args is None
    assert result.ssh_extra_args is None
    assert result.scp_extra_args is None
    assert result.sftp_extra_args is None


# Generated at 2022-06-22 18:42:18.443519
# Unit test for function create_base_parser
def test_create_base_parser():
    #assert(create_base_parser("foo").prog == "foo")
    assert(isinstance(create_base_parser("foo"), argparse.ArgumentParser))



# Generated at 2022-06-22 18:42:23.129866
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, help='foo')
    # Use argument '--foo'
    args = parser.parse_args(['--foo'])
    assert args.foo == True
    # Try to use argument '--bar'
    args = parser.parse_args(['--bar'])
    # This should fail
    assert args.foo == True
    # The following call will fail, which means the test is successful
    #args = parser.parse_args(['--foo --bar'])


# Generated at 2022-06-22 18:42:32.421983
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    if 'test' not in current_dir:
        print('test_maybe_unfrack_path must be run from the test directory')
        sys.exit(1)
    if maybe_unfrack_path('~')('~/test/unit') != '~' + os.path.expanduser('~/test/units'):
        print('maybe_unfrack_path is not expanding ~ to user home directory')
        sys.exit(1)
    if maybe_unfrack_path('~')('/tmp/test/unit') != '/tmp/test/unit':
        print('maybe_unfrack_path is modify paths that do not start with ~')
        sys.exit(1)

#
# Common OptionG

# Generated at 2022-06-22 18:42:34.229154
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)
    args = ['--force-handlers', '--flush-cache']
    opts, args = parser.parse_known_args(args)
    assert opts.force_handlers == True
    assert opts.flush_cache == True



# Generated at 2022-06-22 18:42:40.327138
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """
    Test unit for function add_tasknoplay_options
    """
    try:
        parser = create_base_parser("test_add_tasknoplay_options")
        add_tasknoplay_options(parser)
    except Exception as e:
        pytest.fail("got an error while runnung test_add_tasknoplay_options" + str(e))


# Generated at 2022-06-22 18:42:49.055993
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', '--env')
    parser.add_argument('-m', '--module')

    Base = argparse.HelpFormatter
    # Test _format_action_invocation of class SortingHelpFormatter
    class Test_SortingHelpFormatter_format_action_invocation(SortingHelpFormatter):
        def _format_action_invocation(self, action):
            if not action.option_strings:
                meta = self._metavar_formatter(action, action.dest)(1)
                return meta


# Generated at 2022-06-22 18:42:53.713003
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['--extra-vars', '@'+os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', 'unfrack_path', 'extravars.yml')])
    assert '@'+os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', 'unfrack_path', 'extravars.yml') == args.extra_vars[0]


# Generated at 2022-06-22 18:43:02.373322
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("foo/bar") == "foo/bar"
    assert unfrack_path()("/moo/boo") == "/moo/boo"
    assert unfrack_path()("~/moo/boo") == os.path.expanduser("~/moo/boo")
    assert unfrack_path()("/tmp/../moo/boo") == "/moo/boo"
    assert unfrack_path()("/tmp/../moo/./boo/../baz") == "/moo/baz"


#
# Options which can be overridden by config
#

# Generated at 2022-06-22 18:43:13.054415
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args([])
    assert not args.become_ask_pass
    assert not args.become_password_file
    assert args.become == C.DEFAULT_BECOME
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user is None

    args = parser.parse_args(['--become', '--become-user', 'dwalsh'])
    assert args.become
    assert args.become_user == 'dwalsh'

    args = parser.parse_args(['--become-ask-pass'])
    assert args.become_ask_pass


# Generated at 2022-06-22 18:43:17.727845
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    args = ['unrec', '-f', 'foo']
    parser = argparse.ArgumentParser()
    parser.add_argument('-f')
    parser.add_argument('--unrec', action=UnrecognizedArgument)
    parsed_args = parser.parse_args(args)
    assert parsed_args is not None


# Generated at 2022-06-22 18:43:19.223877
# Unit test for function version
def test_version():
    result = version()
    assert result is not None
    assert 'config file =' in result


# Generated at 2022-06-22 18:43:21.377239
# Unit test for function version
def test_version():
    called_prog = "test_version"
    assert version(called_prog) is not None

# Generated at 2022-06-22 18:43:25.941968
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    module_path = C.config.get_configuration_definition('DEFAULT_MODULE_PATH').get('default', '')
    add_module_options(parser)
    options = parser.parse_args(['--module-path', '/tmp/test'])
    assert options.module_path == ['/tmp/test']



# Generated at 2022-06-22 18:43:36.195776
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(['-u', 'user', '-T', '1', '--connection', 'local', '--ssh-common-args',
                                 'arg', '--sftp-extra-args', 'arg', '--scp-extra-args', 'arg', '--ssh-extra-args',
                                 'arg', '--private-key', 'key', '-c', 'conn_type', '--timeout', '5',
                                 '--connection-password-file', 'file.txt', '--verbose'])
    assert options.remote_user == 'user'
    assert options.connection == 'local'
    assert options.ssh_common_args == 'arg'
    assert options.sftp_extra_args

# Generated at 2022-06-22 18:43:42.692475
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = vars(parser.parse_args(["-b", "--become-method=su", "--become-user=root"]))
    assert args["become"]
    assert not args["become_ask_pass"]
    assert args["become_method"] == "su"
    assert args["become_user"] == "root"


# Generated at 2022-06-22 18:43:50.523841
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    # test add_verbosity_options()
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert '-v' in parser._option_string_actions
    assert '--verbose' in parser._option_string_actions
    # test nargs=0
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    option = parser._option_string_actions['-v'].dest
    assert parser.parse_args(['-v', '-v']).__dict__[option] == 2


# Generated at 2022-06-22 18:44:01.686350
# Unit test for function unfrack_path
def test_unfrack_path():
    """Return a list of path with relative path being make absolute.
    """
    def assert_unfrack_path(item):
        assert item == unfrack_path()(item)
        assert item == unfrack_path(pathsep=True)(item)

    old_cwd = os.getcwd()

# Generated at 2022-06-22 18:44:03.667294
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(["-t", "tagname"])
    assert vars(args) == {"tags": ["tagname"], "skip_tags": C.TAGS_SKIP}

#
# Functions to help validate CLI options
#


# Generated at 2022-06-22 18:44:08.431905
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """
    test if sort_keys is working
    """
    actions = [argparse.Action('-a', help='arg_a'), argparse.Action('-b', help='arg_b')]
    out = SortingHelpFormatter()
    out.add_arguments(actions)


# Generated at 2022-06-22 18:44:13.181584
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    normal_path = '/tmp/foo'
    unfrack_path = '=~/foo'
    assert maybe_unfrack_path('=~')(unfrack_path) == '=~' + os.path.expanduser('~/foo')
    assert maybe_unfrack_path('=~')(normal_path) is normal_path



# Generated at 2022-06-22 18:44:15.381905
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='connect_options', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    add_connect_options(parser)


# Generated at 2022-06-22 18:44:26.808090
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    def test_case(args, expected):
        with captured_output() as (out_stdout, out_stderr):
            parser = OptionParserWithTerminateOnNonDisplayOutput(description="description",
                                                                 version="version")
            add_tasknoplay_options(parser)
            options = parser.parse_args(args)
            assert options.task_timeout == expected
            assert out_stdout.getvalue() == ""
            assert out_stderr.getvalue() == ""

    # Test default value.
    test_case(args=[], expected=C.TASK_TIMEOUT)

    # Test with option.
    test_case(args=["--task-timeout", "10"], expected=10)

    # Test with option, trailing spaces.

# Generated at 2022-06-22 18:44:32.814544
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser=argparse.ArgumentParser()
    add_inventory_options(parser)
    assert str(parser.parse_args(['-i', 'a,b', '--list-hosts'])) == "Namespace(inventory=['a,b'], listhosts=True, subset=u'all')"


# Generated at 2022-06-22 18:44:38.427082
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser=parser)
    options = parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS
    options = parser.parse_args(['--forks', '42'])
    assert options.forks == 42


# Generated at 2022-06-22 18:44:50.921808
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = create_base_parser('ansible-doc')
    add_connect_options(parser)
    opts = vars(parser.parse_args([
        '--private-key', 'file.key',
        '-u', 'user',
        '-c', 'connection',
        '-T', '5',
        '--ssh-common-args', 'common',
        '--sftp-extra-args', 'extra',
        '--scp-extra-args', 'extra',
        '--ssh-extra-args', 'extra',
        '--ask-pass',
        '--connection-password-file', 'file'
    ]))
    assert opts['private_key_file'] == 'file.key'
    assert opts['remote_user'] == 'user'

# Generated at 2022-06-22 18:44:56.016271
# Unit test for function ensure_value
def test_ensure_value():
    class test_namespace:
        pass
    a = test_namespace()
    # Make sure new value is set
    ensure_value(a, 'b', 'c')
    assert a.b == 'c'
    # Make sure existing value is not overwritten
    a.b = 'd'
    ensure_value(a, 'b', 'c')
    assert a.b == 'd'



# Generated at 2022-06-22 18:45:00.092301
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test", "test")
    assert parser.parse_args(["--version"])


# Generated at 2022-06-22 18:45:06.868174
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    the_list = [3, 2, 1]
    result = ensure_value(namespace, 'the_list', the_list)
    assert result is namespace.the_list
    assert namespace.the_list is the_list
    namespace.the_list = [4, 5]
    result = ensure_value(namespace, 'the_list', the_list)
    assert result is not namespace.the_list
    assert result is the_list
    assert namespace.the_list == [4, 5]


#
# OptionParsers for the various subcommands
#

# Generated at 2022-06-22 18:45:18.803105
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    test_parser.add_argument('--D', action="store_false", default=argparse.SUPPRESS, help="test arg D")
    test_parser.add_argument('--C', action="store_false", default=argparse.SUPPRESS, help="test arg C")
    test_parser.add_argument('--B', action="store_false", default=argparse.SUPPRESS, help="test arg B")
    test_parser.add_argument('--A', action="store_false", default=argparse.SUPPRESS, help="test arg A")

    test_args = test_parser.parse_args([])

    # here's the key assertion
    # if this test is executed it will throw an exception if the args
    # are not

# Generated at 2022-06-22 18:45:22.660436
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    parser.parse_args('')
    parser.parse_args('-P 15')
    parser.parse_args('-B 20')
    parser.parse_args('-P 15 -B 20')



# Generated at 2022-06-22 18:45:29.532781
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # 1. Create a parser
    parser = argparse.ArgumentParser()
    # 2. Create an AnsibleVersion object
    action = AnsibleVersion(parser)
    # 3. Assign a mock method to the AnsibleVersion objects method version
    action.version = MagicMock()
    # 4. Call the AnsibleVersion objects method __call__
    action.__call__(parser, None, None, option_string=None)
    # 5. Check if __call__ called the version method with the expected arguments
    action.version.assert_called_once_with(parser.prog)



# Generated at 2022-06-22 18:45:32.037317
# Unit test for function add_async_options
def test_add_async_options():
    x = argparse.ArgumentParser()
    add_async_options(x)
    result = [(x.print_help())]

# Generated at 2022-06-22 18:45:38.504058
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    assert parser.format_help()
    p = parser.parse_args(['-e',"@test_data/test_vars1.yml"])
    assert p.extra_vars is not None
    assert p.extra_vars[0] == "@test_data/test_vars1.yml"



# Generated at 2022-06-22 18:45:39.670098
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass # TODO



# Generated at 2022-06-22 18:45:51.732988
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    import sys
    import unittest
    from unittest import mock

    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    argv = ['ansible', '-K']
    args = parser.parse_args(argv[1:])

    # Check that the parser correctly recognizes the -K argument
    assert args.become_ask_pass is True

    # Check that the code correctly handles the -K argument
    with mock.patch.object(sys, 'argv', argv):
        options = Options()
        options.connection = 'local'
        options.become = False
        options.become_ask_pass = True
        options = options.parse()
    assert options.become_ask_pass is True

    # Check that the parser correctly recognizes the --become-password

# Generated at 2022-06-22 18:45:58.634752
# Unit test for function add_vault_options
def test_add_vault_options():
    def options_to_env(options):
        env = dict(
            vault_ids=options.vault_ids,
            ask_vault_pass=options.ask_vault_pass,
            vault_password_files=options.vault_password_files
        )
        return env

    # default options
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args([])
    env = options_to_env(options)
    assert env == dict(
        vault_ids=[],
        ask_vault_pass=False,
        vault_password_files=[]
    )

    # vault_ids option
    parser = argparse.ArgumentParser()
    add_vault_options(parser)

# Generated at 2022-06-22 18:46:11.191355
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
    )

    add_runas_prompt_options(parser)

    # correct implementation
    arguments = ['-K']
    args = parser.parse_args(arguments)
    assert args.become_ask_pass == True and args.become_password_file is None

    arguments = ['--become-password-file']
    args = parser.parse_args(arguments)
    assert args.become_ask_pass == False and args.become_password_file is not None

    arguments = ['-K', '--become-password-file']
    with pytest.raises(SystemExit):
        args = parser.parse_args(arguments)


# Generated at 2022-06-22 18:46:22.666247
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # test for an exception
    class TestActions(object):
        pass
    t = TestActions()
    t.option_strings = None
    actions = [t]
    s = SortingHelpFormatter()
    try:
        s.add_arguments(actions)
        raise AssertionError()
    except Exception:
        pass
    # test for sort
    class TestActions(object):
        def __init__(self, n):
            self.n = n
            self.option_strings = chr(n+ord('a'))
    actions = [TestActions(i) for i in (1,0,2)]
    s = SortingHelpFormatter()
    s.add_arguments(actions)
    assert [a.n for a in actions] == [1,0,2]



# Generated at 2022-06-22 18:46:33.818598
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    result = vars(parser.parse_args(['-K']))
    assert result['become_ask_pass'] is True
    assert result['become_password_file'] is C.BECOME_PASSWORD_FILE
    assert result['become_password'] is None

    result = vars(parser.parse_args(['--become-password-file', 'test']))
    assert result['become_ask_pass'] is False
    assert result['become_password_file'] == 'test'
    assert result['become_password'] is None



# Generated at 2022-06-22 18:46:35.346634
# Unit test for function create_base_parser
def test_create_base_parser():
    assert create_base_parser('test-prog', usage='usage', desc='description', epilog='epilog')



# Generated at 2022-06-22 18:46:38.453809
# Unit test for function add_connect_options
def test_add_connect_options():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    add_connect_options(parser)
    return parser.parse_args(args=[])



# Generated at 2022-06-22 18:46:44.704939
# Unit test for function add_check_options
def test_add_check_options():
   parser = argparse.ArgumentParser()
   add_check_options(parser)
   (options, args)=parser.parse_known_args()
   assert not options.check, "The check option is not true"
   assert not options.syntax, "The syntax option is not true"
   assert not options.diff, "The diff option is not true"
   test_args=['-C','--syntax-check','-D']
   (options, args) = parser.parse_known_args(test_args)
   assert options.check, "The check option is true"
   assert options.syntax, "The syntax option is true"
   assert options.diff, "The diff option is true"



# Generated at 2022-06-22 18:46:50.876445
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    print("Execute Unit test for method __call__ of class UnrecognizedArgument")

    UnrecognizedArgument(option_strings=['-C'],dest='connection',nargs=0,help='DEPRECATED: use connection/ansible_connection')
    UnrecognizedArgument(option_strings=['-C', '--connection'], dest='connection', nargs=0, const=True,
                         help='DEPRECATED: use connection/ansible_connection')
    print("\n")
test_UnrecognizedArgument___call__()



# Generated at 2022-06-22 18:46:59.454859
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    # Test for the -o option
    try:
        # unit test for test_callback
        assert parser.parse_args(['-o'])
    except SystemExit:
        assert False
    # Test for the -t option
    # Test with valid input
    try:
        parser.parse_args(['-t', '/tmp'])
    except SystemExit:
        assert False
    # Test with invalid input
    try:
        parser.parse_args(['-t'])
        assert False
    except SystemExit:
        assert True



# Generated at 2022-06-22 18:47:11.753516
# Unit test for function version
def test_version():
    # set test values
    prog = 'ansible_test'
    __version__ = '4.4.4'
    C.DEFAULT_MODULE_PATH = '/test/test'
    ansible.__path__ = ['/test/test']
    sys.version = 'test_version'
    j2_version = 'test_version'
    C.COLLECTIONS_PATHS = ['test/test']

    # call function
    result = version(prog)

    # assert results

# Generated at 2022-06-22 18:47:21.101034
# Unit test for function ensure_value
def test_ensure_value():
    class namespace(object):
        pass
    ns = namespace()
    ns.foo = None

    assert ensure_value(ns, 'foo', [1,2,3]) == [1,2,3]
    assert ns.foo == [1,2,3]
    assert ensure_value(ns, 'bar', [1,2,3]) == [1,2,3]
    assert ns.bar == [1,2,3]
    test_iter = (x for x in [1, 2, 3])
    assert ensure_value(ns, 'baz', test_iter) == [1,2,3]
    assert ns.baz == [1,2,3]



# Generated at 2022-06-22 18:47:23.860254
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['-f', '100'])
    assert options.forks == 100



# Generated at 2022-06-22 18:47:28.910213
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", "--ansible-version", action=AnsibleVersion, help="Print ansible version")
    assert isinstance(parser.parse_args(["-a"]), argparse.Namespace)



# Generated at 2022-06-22 18:47:41.235058
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    optp = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    optp.add_argument('--foo')
    optp.add_argument('--bar')
    optp.add_argument('--baz')
    opt = optp.parse_args([])
    optp.print_help()
    assert opt == argparse.Namespace(bar=None, baz=None, foo=None)

# Generated at 2022-06-22 18:47:44.442808
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    parsed_args = vars(parser.parse_args([]))

    assert parsed_args["task_timeout"] == C.TASK_TIMEOUT


# Generated at 2022-06-22 18:47:50.450267
# Unit test for function add_vault_options
def test_add_vault_options():
    expected_help_arg = ("the vault identity to use", "vault password file")
    expected_help = ("ask for vault password", "ask for vault password")
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    for action in parser._actions:
        if action.option_strings[0] == '--vault-id':
            help_arg = action.help
        if action.option_strings[0] == '--ask-vault-pass':
            help = action.help
    assert expected_help_arg == help_arg
    assert expected_help == help


# Generated at 2022-06-22 18:47:55.259442
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = create_base_parser("ansible")
    add_basedir_options(parser)
    options, args  = parser.parse_known_args(['-h'])
    assert options.basedir is not None


# Generated at 2022-06-22 18:47:56.752315
# Unit test for function add_output_options
def test_add_output_options():
    parser = FakeOptParser()
    add_output_options(parser)



# Generated at 2022-06-22 18:48:05.836848
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    verbose_version = version(None)
    if len(verbose_version.splitlines()) > 2:
        sys.stderr.write('Error testing AnsibleVersion.\n')
        sys.stderr.write('Ansible version more than one line.\n')
        sys.stderr.write('This may cause exceptions in AnsibleVersion.\n')
        sys.stderr.write('Please contact the developers.\n')
        sys.exit(-1)
    ansible_version = to_native(version(os.path.basename(sys.argv[0])))
    sys.argv = [sys.argv[0], '--version']
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, help='display version information')
   

# Generated at 2022-06-22 18:48:09.557673
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options, args = parser.parse_known_args(['--playbook-dir', 'ansible-playbook-dir'])
    assert options.basedir == 'ansible-playbook-dir'



# Generated at 2022-06-22 18:48:13.600383
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(["--playbook-dir","/home/test"])
    assert args.basedir == "/home/test"


# Generated at 2022-06-22 18:48:19.587812
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog='TestProg',
    )
    add_async_options(parser)
    options, args = parser.parse_known_args(['-P', '10'])
    assert options.poll_interval == 10
    options, args = parser.parse_known_args(['-B', '20'])
    assert options.seconds == 20
    options, args = parser.parse_known_args(['--background', '30'])
    assert options.seconds == 30


# Generated at 2022-06-22 18:48:30.739230
# Unit test for function add_runas_options
def test_add_runas_options():
    '''
    Test module add_runas_options()
    '''
    # Create a temp directory to emulate --tree with
    tmpdir = tempfile.mkdtemp()

    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    add_connect_options(parser)
    add_output_options(parser)