

# Generated at 2022-06-22 18:38:32.775442
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    runas_options = parser.parse_args(['-b', '--become-method', 'su', '--become-user', 'root'])
    assert runas_options.become_method == 'su'
    assert runas_options.become_user == 'root'

    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    runas_options = parser.parse_args(['-K', '--ask-become-pass'])
    assert runas_options.become_ask_pass



# Generated at 2022-06-22 18:38:41.214485
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class F(argparse.ArgumentParser):
        def error(self, message):
            raise AssertionError(message)

    # FIXME: Figure out how to test the function above
    # p = F()
    # p.add_argument('-f', action=PrependListAction, nargs=1)
    # p.parse_args('-f foo'.split())
    # returns namespace(f=['foo'])
    # p.parse_args('-f foo -f bar'.split())
    # returns namespace(f=['bar', 'foo'])
    pass



# Generated at 2022-06-22 18:38:43.715218
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser) 
    args = parser.parse_args('-vvv'.split())
    assert args.verbosity == 3


# Generated at 2022-06-22 18:38:46.035204
# Unit test for function add_fork_options
def test_add_fork_options():
    argv = ['--forks', '10']
    parser = create_base_parser(prog='ansible-config', usage='', desc=version(), epilog='')
    add_fork_options(parser)
    args = parser.parse_args(argv)
    assert(args.forks == '10')


# Generated at 2022-06-22 18:38:49.243864
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    output = parser.parse_args(['-vvvvvvvvvvvvvvvvvvvv'])
    assert output.verbosity == 20



# Generated at 2022-06-22 18:38:52.662685
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    Test that add_runas_prompt_options() adds options correctly
    """
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['--ask-become-pass'])
    assert args.become_ask_pass
    args = parser.parse_args(['--become-password-file', '/path/to/file'])
    assert args.become_password_file == '/path/to/file'



# Generated at 2022-06-22 18:38:53.740831
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    # No options to test


# Generated at 2022-06-22 18:38:56.183439
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', "prependpath1:prependpath2", '-M', "/more:prepend1:prepend2"])
    assert options.module_path == ["/more", "prepend1", "prepend2", "prependpath1", "prependpath2"]


# Generated at 2022-06-22 18:39:06.734822
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    test_parser = argparse.ArgumentParser(
        prog = "ansible-for-devops",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_verbosity_options(test_parser)
    print (test_parser._option_string_actions)
    print (test_parser.parse_args())

# Generated at 2022-06-22 18:39:13.117927
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('test', 'test: ')
    add_runas_options(parser)
    options = parser.parse_args([])
    assert options
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user == C.DEFAULT_BECOME_USER
    assert options.become == C.DEFAULT_BECOME



# Generated at 2022-06-22 18:39:19.691692
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    from ansible.utils.display import Display
    test_parser = argparse.ArgumentParser()
    add_verbosity_options(test_parser)
    args = test_parser.parse_args(['-v'])
    assert args.verbosity == 1
    assert Display.verbosity == 1
    args = test_parser.parse_args(['-vvv'])
    assert args.verbosity == 3
    assert Display.verbosity == 3
    Display.verbosity = 0



# Generated at 2022-06-22 18:39:21.095118
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    assert False



# Generated at 2022-06-22 18:39:22.795740
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)


# Generated at 2022-06-22 18:39:28.608042
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        prog='Test',
        description='Parsing arguments',
        conflict_handler='resolve',
    )
    add_verbosity_options(parser)
    add_check_options(parser)
    cmdline = ['-v', '--check']
    options = parser.parse_args(cmdline)
    assert options.verbosity == 2
    assert options.check is True



# Generated at 2022-06-22 18:39:37.701275
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import datetime
    import collections
    import unittest

    try:
        import mock
    except ImportError:
        import unittest.mock as mock

    class OptionsList(list):

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super(OptionsList, self).__init__(*args, **kwargs)

        def __getattr__(self, name):
            return getattr(super(OptionsList, self), name)

    class DummyOption(mock.Mock):

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super(DummyOption, self).__init__(*args, **kwargs)


# Generated at 2022-06-22 18:39:47.452306
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.utils.display import Display
    from ansible.utils.path import module_loader
    from ansible.release import __version__ as ansible_version
    from ansible.release import __author__
    from ansible.release import __copyright__
    from ansible.release import __email__
    from ansible.release import __url__
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.yaml import HAS_LIBYAML, yaml_load
    from ansible.module_utils.common.argparse import ArgumentParser
    from ansible.module_utils.common.argparse import AnsibleVersion
    from ansible.module_utils.common.argparse import AnsibleModuleHelp
    from ansible.module_utils.common.argparse import make_option
   

# Generated at 2022-06-22 18:39:50.654863
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    with pytest.raises(SystemExit):
        parser.parse_args(['--task-timeout', '-1'])
    with pytest.raises(SystemExit):
        parser.parse_args(['--task-timeout', '0'])
    with pytest.raises(SystemExit):
        parser.parse_args(['--task-timeout', 'a'])
    with pytest.raises(SystemExit):
        parser.parse_args(['--task-timeout', 0])



# Generated at 2022-06-22 18:39:51.697811
# Unit test for function add_fork_options
def test_add_fork_options():
    result = add_fork_options(argparse.ArgumentParser())
    assert isinstance(result, argparse.ArgumentParser)



# Generated at 2022-06-22 18:39:53.485257
# Unit test for function add_output_options
def test_add_output_options():
    parser=argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', 'test','--one-line'])
    assert args.tree == 'test'
    assert args.one_line == True
    
    
    

# Generated at 2022-06-22 18:39:55.718570
# Unit test for function add_output_options
def test_add_output_options():
    class Args(object):
        def __init__(self):
            pass

    args = Args()

    test_parser = argparse.ArgumentParser()
    add_output_options(test_parser)
    test_parser.parse_args(namespace=args)

    assert not args.one_line
    assert not args.tree


# Generated at 2022-06-22 18:40:01.857410
# Unit test for function unfrack_path
def test_unfrack_path():
    yaml_loader = C.DEFAULT_YAML_LOADER
    yaml_loader.add_constructor(u'tag:yaml.org,2002:str', lambda loader, node: to_native(node.value, errors='surrogate_or_strict'))

    filename = os.path.join(os.path.dirname(__file__), 'test_unfrack_path.yaml')
    config = yaml_load(open(filename).read())
    for option in config['options']:
        assert option['result'] == unfrack_path(option.get('pathsep', False))(option['value'])



# Generated at 2022-06-22 18:40:07.685635
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    cmdline = '-i inventorypath'
    args = parser.parse_args(cmdline.split())
    assert args.inventory == ['inventorypath']
    cmdline = '-i inventorypath -i inventorypath2 -I'
    args = parser.parse_args(cmdline.split())
    assert args.inventory == ['inventorypath', 'inventorypath2']
    assert args.inventory_ignore_ext == ['.ignore']
    assert args.inventory_ignore_patterns == []



# Generated at 2022-06-22 18:40:16.584788
# Unit test for function add_check_options
def test_add_check_options():
    """
    Test whether options added with add_check_options are present in the parser.
    """
    parser = argparse.ArgumentParser()
    add_check_options(parser)

    options_added = [('-C', '--check'),
                     ('--syntax-check',),
                     ('-D', '--diff')]
    for option in options_added:
        assert parser._option_string_actions.get(option[0]) is not None or parser._option_string_actions.get(option[1]) is not None, \
            'Failed to add option {0}'.format(option)



# Generated at 2022-06-22 18:40:20.076597
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--unrecognized', action=UnrecognizedArgument, nargs=0)
    options = parser.parse_args(['-u'])



# Generated at 2022-06-22 18:40:25.203385
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', 'C:/Users/Ning/Desktop/ansible/modules'])
    assert options.module_path == [os.path.abspath('C:/Users/Ning/Desktop/ansible/modules')]



# Generated at 2022-06-22 18:40:32.058908
# Unit test for function unfrack_path
def test_unfrack_path():
    import tempfile
    from ansible.config import basedir
    from ansible.module_utils._text import to_native
    from tempfile import mkdtemp
    from os import path
    from shutil import rmtree
    my_basedir = mkdtemp(prefix='ansible-config-unfrack_path')
    my_ansible_basedir = path.join(my_basedir,'ansible')
    my_ansible_subdir = path.join(my_basedir,'my_subdir')
    my_file = path.join(my_basedir,'my_file')

# Generated at 2022-06-22 18:40:38.328378
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('-a', action=UnrecognizedArgument)
    try:
        test_parser.parse_args('-a'.split())
    except SystemExit as e:
        assert e.code == 2
# End unit test for method __call__ of class UnrecognizedArgument



# Generated at 2022-06-22 18:40:43.779958
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)

    options = parser.parse_args(['-f', '1'])
    assert options.forks == 1

    options = parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS

    options = parser.parse_args(['-f', 'foobar'])
    assert options.forks == C.DEFAULT_FORKS



# Generated at 2022-06-22 18:40:55.711193
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    p1 = "/home/user/dir/roles"
    q1 = maybe_unfrack_path("@")(p1)
    assert q1 == "@{home}/user/dir/roles"
    p2 = "/home/user/dir/roles"
    q2 = maybe_unfrack_path("@")(p2)
    assert q2 == "@{home}/user/dir/roles"
    p3 = "@{home}/user/dir/roles"
    q3 = maybe_unfrack_path("@")(p3)
    assert q3 == "@{home}/user/dir/roles"
    p4 = "~/dir/roles"
    q4 = maybe_unfrack_path("@")(p4)

# Generated at 2022-06-22 18:41:03.707599
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from units.compat.mock import patch, mock_open
    from ansible.cli.arguments import add_basedir_options
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    from ansible.release import __version__
    from ansible.utils.path import unfrackpath

    from io import StringIO

    mock_stdout = StringIO()
    mock_stderr = StringIO()

    with patch('ansible.cli.arguments.sys.stdout', mock_stdout):
        with patch('ansible.cli.arguments.sys.stderr', mock_stderr):
            parser = argparse.ArgumentParser(
                formatter_class=SortingHelpFormatter,
            )
            add_basedir_options(parser)
            args = parser.parse_

# Generated at 2022-06-22 18:41:14.007800
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    for want in [
            '-a, --full-argument',
            '-b, --a-bit-longer-argument',
            '-c, --full-argument-with-a-bit-more',
            '-d, --a-bit-longer-argument-with-a-bit-more',
            '-e, --full', 
            '-z, --a-bit-longer',
        ]:
        assert want == SortingHelpFormatter().add_arguments([
            argparse.ArgumentParser(
                formatter_class=SortingHelpFormatter
            ).add_argument(*want.split(), help='strange sorting')
        ]).splitlines()[-1]


#
# Options passed on command line
#

# Generated at 2022-06-22 18:41:19.474414
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_meta_options(parser)
    cmdline = ["--flush-cache"]
    args = parser.parse_args(cmdline)
    assert args.flush_cache == True


# Generated at 2022-06-22 18:41:21.582175
# Unit test for function add_subset_options
def test_add_subset_options():
     parser = argparse.ArgumentParser()
     add_subset_options(parser)
     options = parser.parse_args(['-t', 'tag1', '--tags', 'tag2', '--skip-tags', 'tag3'])
     assert options.tags == ['tag1', 'tag2']
     assert options.skip_tags == ['tag3']

# Generated at 2022-06-22 18:41:25.443124
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = Mock()
    runas_group = Mock()
    add_runas_prompt_options(parser, runas_group)
    assert parser.add_argument_group.called

# Generated at 2022-06-22 18:41:29.040906
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('--version', '-v', action=AnsibleVersion)
    test_parser.prog = 'Ansible'
    test_parser.parse_args(['--version'])



# Generated at 2022-06-22 18:41:40.205861
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    op = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    op.add_argument('-z')
    op.add_argument('-a')
    op.add_argument('-d')
    op.add_argument('-c')
    op.add_argument('--bar')
    op.add_argument('--foo')
    op.add_argument('-B')
    op.add_argument('-C')
    op.add_argument('-A')
    op.add_argument('-D')
    op.add_argument('-Y')
    op.add_argument('-X')
    op.add_argument('-W')
    op.add_argument('-V')
    op.add_argument('-U')
    op.add_argument('-T')
   

# Generated at 2022-06-22 18:41:51.249024
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    from unittest import TestCase
    from unittest.mock import MagicMock

    class MockParser(object):
        def __init__(self):
            self.values = None

        def error(self, arg):
            raise Exception(arg)

    def ensure_value_side_effect(namespace, dest, default=None):
        return namespace.values

    parser = MockParser()
    parser.values = ['c']

    dest = 'dummy_dest'
    const = ['a', 'b']
    nargs = 0

    prepend_list_action = PrependListAction(option_strings=[], dest=dest, nargs=nargs,
                                            const=const, default=None)


# Generated at 2022-06-22 18:41:56.364941
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='test_base_parser')
    options, args = parser.parse_known_args()
    #check for the new arguments appended
    assert options.verbosity == 0
    assert options.quiet is False
    assert options.verbosity is None

#def test_parse_version():
#    parser = create_base_parser(prog='test_version')
#    options, args = parser.parse_known_args(args=['--version'])
#    print(options.version)
#    assert version(prog='test_version')== options.version



# Generated at 2022-06-22 18:42:04.736505
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        def __init__(self):
            self.foo = None

    ns = Namespace()
    assert ns.foo is None
    assert ensure_value(ns, 'foo', 'bar') == 'bar'
    assert ns.foo == 'bar'

    assert ns.foo == 'bar'
    assert ensure_value(ns, 'foo', 'baz') == 'bar'
    assert ns.foo == 'bar'



# Generated at 2022-06-22 18:42:10.528064
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args('-i file1 -i file2 --list-hosts -l pattern'.split())
    assert args.inventory == ['file1', 'file2']
    assert args.listhosts is True
    assert args.subset == 'pattern'


# Generated at 2022-06-22 18:42:17.065924
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    arguments = parser.parse_args(args=['-e','b=2'])
    assert arguments.extra_vars == ['b=2']
    arguments = parser.parse_args(args=['-e','@test_file'])
    assert arguments.extra_vars == ['@test_file']

# Generated at 2022-06-22 18:42:20.676991
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(prog='test',
                                     formatter_class=SortingHelpFormatter)
    parser.add_argument('-z')
    parser.add_argument('--bar')
    parser.add_argument('-a')
    parser.add_argument('-1')
    parser.print_help()


# Generated at 2022-06-22 18:42:23.594712
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args([])
    assert args.become
    assert args.become_user == C.DEFAULT_BECOME_USER
    assert args.prompt_su
    assert args.prompt_sudo
    # because of the mutually exclusive group, only one of them
    # should be set
    assert args.prompt_su is not args.prompt_sudo



# Generated at 2022-06-22 18:42:29.725732
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='test')
    add_check_options(parser)
    args = parser.parse_args(['-C', '--check', '--syntax-check', '-D', '--diff', '--playbook-dir', 'playbook_dir'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True
    assert args.basedir == 'playbook_dir'



# Generated at 2022-06-22 18:42:39.233532
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    shf = SortingHelpFormatter()
    parser = argparse.ArgumentParser(formatter_class=shf)
    # pylint: disable=protected-access
    parser._actions = []
    parser._optionals._actions = []
    namespace = argparse.Namespace()
    args = ['ansible']
    parser.add_argument('--version', dest='version', action=AnsibleVersion, nargs=0,
                        help='Show Ansible version number and exit')
    with open(os.devnull, 'w') as tmp_stdout:
        parser.parse_args(args, namespace)
    assert namespace.version is None



# Generated at 2022-06-22 18:42:44.420435
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.parse_args(['--playbook-dir', 'test_playbook_dir'])
    assert parser.parse_args(['--playbook-dir', 'test_playbook_dir']).basedir == os.path.abspath('test_playbook_dir')



# Generated at 2022-06-22 18:42:47.242390
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='test_add_output_options')
    add_output_options(parser)
    options = parser.parse_args(['-o'])
    assert options.one_line

# Generated at 2022-06-22 18:42:52.479560
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='test', description='test parser')
    add_fork_options(parser)
    arg_str = 'foo --forks 23'
    args = parser.parse_args(arg_str.split())
    assert args.forks == 23

# Generated at 2022-06-22 18:42:58.054675
# Unit test for function add_subset_options
def test_add_subset_options():
    from collections import namedtuple
    from ansible.parsing.splitter import parse_kv
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display
    from ansible.__init__ import __version__
    from ansible.cli.arguments import OPTIONAL_PROVIDERS, REQUIRED_PROVIDERS

    display = Display()

    # mock parser class
    Parser = namedtuple('Parser', ['option_list', 'add_argument'])
    parser = Parser(option_list=[], add_argument=lambda x1, x2, **kwargs: parser.option_list.append(kwargs['dest']))
    # mock argument class

# Generated at 2022-06-22 18:43:09.286080
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ansible-cmdb')
    add_vault_options(parser)
    extra_vars = [
        '@./path/to/file.yml',
        '@./path/to/file.yaml',
        '@./path/to/file.json',
        'key=val',
        '@/path/to/vault.yml',
        '@/path/to/vault.yaml',
        '@/path/to/vault.json',
        '@/path/to/vault-id.yml',
        '@/path/to/vault-id.yaml',
        '@/path/to/vault-id.json',
    ]

# Generated at 2022-06-22 18:43:17.716573
# Unit test for function add_runas_options
def test_add_runas_options():
    # Test that --help shows the expected options
    # But first create and destroy a parser, so we know the option hasn't
    # been added in a previous test
    parser = argparse.ArgumentParser()
    parser = None
    # Now the test
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    (options, _) = parser.parse_known_args(['--help'])
    assert options.become
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    # The next line won't always hold true
    # assert options.become_user == C.DEFAULT_BECOME_USER


#
# Functions to add pre-canned options to an OptionParser
#


# Generated at 2022-06-22 18:43:24.289992
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from ansible.cli.arguments import base_parser, list_parser
    from ansible.utils import context_objects as co
    parser = SortingHelpFormatter(argparse.ArgumentParser())
    parser.add_arguments(base_parser._actions)
    parser.add_arguments(list_parser._actions)
#
# Special purpose OptionParsers
#



# Generated at 2022-06-22 18:43:33.460638
# Unit test for function unfrack_path
def test_unfrack_path():
    frack = ('/a/b/c:/d/e/f:/g/h/i', '/a/b/c', '/a/b/c:/d/e/f:/g/h/i:/usr/local/bin', '-')
    unfrack = ('/a/b/c', '/a/b/c', '/a/b/c:/d/e/f:/g/h/i:/usr/local/bin', '-')
    for test in range(len(frack)):
        assert unfrack_path(pathsep=True)(frack[test]) == unfrack[test]
        assert unfrack_path(pathsep=False)(frack[test]) == unfrack[test]



# Generated at 2022-06-22 18:43:41.473868
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test 1: no argument
    assert unfrack_path()("") == ""

    # Test 2: argument is '-'
    assert unfrack_path()("-") == "-"

    # Test 3: argument is empty string
    assert unfrack_path()("") == ""

    # Test 4: argument is a relative path
    assert unfrack_path()("/mydir/mydir2/mydir3") == "/mydir/mydir2/mydir3"

    # Test 5: argument is an absolute path
    assert unfrack_path()("/mydir/mydir2/mydir3") == "/mydir/mydir2/mydir3"

    # Test 6: argument is a boolean 'True'
    assert unfrack_path()(True) is True

    # Test 7: argument is a boolean 'False'
    assert unfrack

# Generated at 2022-06-22 18:43:46.564683
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('--banana')
    parser.add_argument('--apple')
    parser.add_argument('-a')
    parser.print_help()



# Generated at 2022-06-22 18:43:49.688890
# Unit test for function ensure_value
def test_ensure_value():
    x = argparse.Namespace()
    assert ensure_value(x, 'w', []) == []
    x.w = 1
    assert ensure_value(x, 'w', []) == 1
    assert ensure_value(x, 'y', []) == []
    assert x.y == []



# Generated at 2022-06-22 18:44:01.102316
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """
    This is a unit test for method test_AnsibleVersion___call__ in class AnsibleVersion
    """
    # Create an instance of class ArgumentParser
    from argparse import ArgumentParser
    parser = ArgumentParser()
    # Create an instance of class AnsibleVersion
    from ansible.module_utils.common._collections_compat import OrderedDict
    args = OrderedDict()
    args['version'] = AnsibleVersion(option_strings=[], dest='version')
    parser._actions = parser._actions + list(args.values())
    # Invoke method __call__ on class AnsibleVersion
    arg_values = None
    option_string = None
    args['version'].__call__(parser, namespace=None, values=arg_values, option_string=option_string)


# Generated at 2022-06-22 18:44:09.543512
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--foo', action=PrependListAction, nargs=1)
    args = parser.parse_args('--foo a --foo b --foo c'.split())
    args.foo == ['a', 'b', 'c']
    # The following test fails in Python 2.6.8
    # args = parser.parse_args('--foo a b c'.split())
    # args.foo == ['a', 'b', 'c']



# Generated at 2022-06-22 18:44:13.953178
# Unit test for function unfrack_path
def test_unfrack_path():
    opts = ["/foo", "-", "/bar/../roger"]
    assert unfrack_path()(opts[0]) == "/foo"
    assert unfrack_path()(opts[1]) == "-"
    assert unfrack_path()(opts[2]) == "/roger"


# Generated at 2022-06-22 18:44:18.700551
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_output_options(parser)
    options = parser.parse_args(['-o', '-t', 'test'])
    assert options.one_line, 'one line not set'
    assert options.tree == 'test', 'tree not set'


# Generated at 2022-06-22 18:44:31.231453
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['--limit', 'foo'])
    assert options.subset == 'foo'
    options = parser.parse_args(['-l', 'foo'])
    assert options.subset == 'foo'
    assert not options.listhosts
    options = parser.parse_args(['--list-hosts'])
    assert options.listhosts
    options = parser.parse_args(['-i', 'foo'])
    assert options.inventory == ['foo']
    options = parser.parse_args(['--inventory', 'foo,bar'])
    assert options.inventory == ['foo,bar']

# Generated at 2022-06-22 18:44:40.699003
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = create_base_parser("test")
    add_runtask_options(parser)
    args = parser.parse_args("-e key1=value1 -e @test.yml -e 'key2=value2'".split())
    assert args.extra_vars == [
        {'key1': 'value1'},
        '@test.yml',
        {'key2': 'value2'}
    ]
    args = parser.parse_args("-e key1=value1 -e key2=value2 -e key3=value3".split())
    assert args.extra_vars == [
        {'key1': 'value1'},
        {'key2': 'value2'},
        {'key3': 'value3'}
    ]

# Generated at 2022-06-22 18:44:52.094788
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert getattr(args, 'become_ask_pass') is True
    args = parser.parse_args(['--become-password-file', 'password_file'])
    assert getattr(args, 'become_password_file') == 'password_file'
    assert getattr(args, 'ask_become_pass') is False
    args = parser.parse_args(['--become-password-file', 'password_file', '-K'])
    assert getattr(args, 'become_password_file') == 'password_file'

# Generated at 2022-06-22 18:44:55.625924
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20


# Generated at 2022-06-22 18:45:02.104521
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Basic help message test
    ansible_parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class = SortingHelpFormatter,
        add_help = False
    )
    ansible_parser.add_argument('-h', '--help', action='help', help='show this help message and exit')
    # The help message should be printed in alphabetical order
    help_message = b'usage: ansible [-h] --help\n\noptional arguments:\n  -h, --help  show this help message and exit\n'
    assert ansible_parser.format_usage() == help_message



# Generated at 2022-06-22 18:45:10.137842
# Unit test for function ensure_value
def test_ensure_value():
    class Flags:
        def __init__(self, namespace=None):
            if isinstance(namespace, dict):
                self.__dict__.update(namespace)

        def __setattr__(self, key, value):
            self.__dict__[key] = value

        def __getattr__(self, item):
            return None

        def __getitem__(self, item):
            return self.__getattr__(item)

    flags = Flags()
    ensure_value(flags, 'a', 10)
    assert flags.a == 10

    flags = Flags()
    ensure_value(flags, 'a', [])
    assert isinstance(flags.a, list)

    flags = Flags(dict(a=10))
    ensure_value(flags, 'a', [])

# Generated at 2022-06-22 18:45:12.135609
# Unit test for function add_meta_options
def test_add_meta_options():
  parser = argparse.ArgumentParser()
  add_meta_options(parser)
  print(parser.format_help())
if __name__ == '__main__':
  test_add_meta_options()



# Generated at 2022-06-22 18:45:24.172206
# Unit test for function add_subset_options
def test_add_subset_options():
    '''
    Test add_subset_options()
    '''
    # Create a new parser
    parser = argparse.ArgumentParser()

    # add_subset_options()
    add_subset_options(parser)

    # Get the parser options as dict
    opts = vars(parser.parse_args())

    # No input passed, should match default values
    assert opts['tags'] == C.TAGS_RUN
    assert opts['skip_tags'] == C.TAGS_SKIP

    # Do not set any tags, should still match default values
    opts = vars(parser.parse_args(['--tags', '']))
    assert opts['tags'] == ['']
    opts = vars(parser.parse_args(['--skip-tags', '']))
    assert opts

# Generated at 2022-06-22 18:45:31.259446
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    test_args = ['--not-a-real-arg']
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument(*test_args, action=UnrecognizedArgument)
    try:
        test_parser.parse_args(test_args)
    except Exception:
        pass
    else:
        assert False, "Expected exception UnrecognizedArgument to be raised"


#
# Special purpose ArgumentParser classes
#

# Generated at 2022-06-22 18:45:42.832291
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

    options, args = parser.parse_known_args(['-u', 'ansible', '-c', 'ssh', '-T', '2', '--ssh-common-args', '-o stricthostkeychecking=no',
                                             '--sftp-extra-args', '-4', '--scp-extra-args', '-4', '--ssh-extra-args', '-4', '--private-key',
                                             '/home/johndoe/.ssh/private',
                                             '--ask-pass', '--connection-password-file', '/tmp/1234'])
    assert options.remote_user == 'ansible'
    assert options.connection == 'ssh'
    assert options.timeout == 2
   

# Generated at 2022-06-22 18:45:46.891827
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    add_tasknoplay_options(parser)
    parser.parse_args(['--task-timeout', '1'])



# Generated at 2022-06-22 18:45:54.568782
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser(prog='test_parser')
    add_check_options(parser)
    arguments = parser.parse_args(args=['--check'])
    assert arguments.check is True
    arguments = parser.parse_args(args=['--syntax-check'])
    assert arguments.syntax is True
    arguments = parser.parse_args(args=['--diff'])
    assert arguments.diff is True


# Generated at 2022-06-22 18:46:00.370469
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'C:\\Users\\vignesh\\Desktop\\t1'])
    assert args.basedir == 'C:\\Users\\vignesh\\Desktop\\t1'
    return True

# Generated at 2022-06-22 18:46:08.280244
# Unit test for function add_runtask_options
def test_add_runtask_options():
  parser = argparse.ArgumentParser(prog='ansible-playbook')
  add_runtask_options(parser)
  args = parser.parse_args(['-e', 'ANSIBLE_IGNORE_UNREACHABLE=1', '-e', 'ANSIBLE_HOSTS_UNREACHABLE=1', '-e', 'ANSIBLE_KEEP_REMOTE_FILES=1'])
  pprint.pprint(vars(args))
  pprint.pprint(vars(args)['extra_vars'])



# Generated at 2022-06-22 18:46:13.353513
# Unit test for function add_inventory_options
def test_add_inventory_options():
    fake_parser = argparse.ArgumentParser(prog='ansible')
    add_inventory_options(fake_parser)
    options = fake_parser.parse_args(['-i', 'hosts', '-l', 'foo'])
    assert options.inventory == ['hosts'], options.inventory
    assert options.subset == 'foo', options.subset



# Generated at 2022-06-22 18:46:20.207382
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = Mock()
    parser.add_mutually_exclusive_group = Mock()
    parser.add_argument = Mock()
    parser.add_argument_group = Mock()
    add_runas_prompt_options(parser)

    parser.add_mutually_exclusive_group.assert_called_once()
    parser.add_argument_group.assert_called_once()
    parser.add_argument.assert_called()



# Generated at 2022-06-22 18:46:23.577899
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, default=argparse.SUPPRESS)
    parser.parse_args(['--version'])
    assert True



# Generated at 2022-06-22 18:46:32.347969
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    try:
        PrependListAction('--foo', 'bar', nargs=0, const='spam')
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'
    try:
        PrependListAction('--foo', 'bar', nargs=2, const='spam')
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'
    try:
        PrependListAction('--foo', 'bar', nargs=argparse.OPTIONAL, const='spam')
    except ValueError:
        assert False, 'did not expect ValueError'

# Test for 'append' vs 'prepend'

# Generated at 2022-06-22 18:46:35.913862
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    cli_args = ['-i', 'test.ini']
    parser.parse_args(cli_args)



# Generated at 2022-06-22 18:46:46.111810
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class MockAction(argparse.Action):
        def __init__(self, option_strings, dest, nargs=None, const=None,
                     default=None, type=None, choices=None, required=False,
                     help=None, metavar=None):
            super(MockAction, self).__init__(option_strings, dest, nargs, const,
                                             default, type, choices, required,
                                             help, metavar)

    argparse_obj = argparse.ArgumentParser(description='description',
                                           formatter_class=SortingHelpFormatter)

    argparse_obj.add_argument(MockAction(['-z'], 'z'))
    argparse_obj.add_argument(MockAction(['-a', '--all'], 'all'))

    #

# Generated at 2022-06-22 18:46:50.605355
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', '/usr/share/mymodules'])
    assert options.module_path == ['/usr/share/mymodules']



# Generated at 2022-06-22 18:46:52.795496
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    parser.print_help()

# end of test



# Generated at 2022-06-22 18:46:54.991693
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = add_subset_options(parser)
    print(parser)


# Generated at 2022-06-22 18:46:56.846168
# Unit test for function ensure_value
def test_ensure_value():
    class ns(object):
        pass
    assert ensure_value(ns, 'foo', 'bar') is ensure_value(ns, 'foo', 'baz')



# Generated at 2022-06-22 18:46:59.665118
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('create_base_parser')
    assert isinstance(parser, argparse.ArgumentParser)

# Generated at 2022-06-22 18:47:01.862593
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(args=[])
    assert options.check == False
    assert options.diff == True
    assert options.syntax == False


# Generated at 2022-06-22 18:47:10.872715
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # TODO: Move this unit test to a pytest unit test
    from ansible.cli.help import AnsibleVersion
    args = []
    kwargs = {'option_string': '--version'}
    action = AnsibleVersion(**kwargs)
    assert isinstance(action, AnsibleVersion)
    parser = argparse.ArgumentParser()
    parser.VERSION_BANNER = ''
    parser.add_argument('--version', action=action, help='show program version')
    parser.parse_args(args)



# Generated at 2022-06-22 18:47:17.333452
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cli.arguments import UnrecognizedArgument
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    parser.print_help()
    with pytest.raises(SystemExit):
        parser.parse_args('--foo bar'.split())
    with pytest.raises(SystemExit):
        parser.parse_args('--foo'.split())



# Generated at 2022-06-22 18:47:26.618315
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import inspect
    import ansible.cli.playbook
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--inventory', action=PrependListAction, default=[])
    args = parser.parse_args([
            '-i', 'another_one.ini',
            '-i', 'hosts.ini',
            '--inventory', 'hosts.yml',
            '--inventory', 'local.yml',
        ])
    assert args.inventory == ['local.yml', 'hosts.yml', 'another_one.ini', 'hosts.ini'], args.inventory
#
# Common options for all Ansible tools
#

# Generated at 2022-06-22 18:47:29.582593
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    parser.parse_args("-f 3".split())
    assert parser.parse_args("-f 3".split()).forks == 3



# Generated at 2022-06-22 18:47:32.490177
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)



# Generated at 2022-06-22 18:47:36.605151
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    help_format = SortingHelpFormatter()
    sorted_help_format = [help_format.format_help()]
    assert sorted_help_format[0].split()[0] == '--ask-become-pass'


# Generated at 2022-06-22 18:47:40.909875
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(["-M", "/tmp", "-M", "/root"])
    assert args.module_path == ["/tmp", "/root"]


# Generated at 2022-06-22 18:47:47.315473
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('testprog', usage='usage', desc='description', epilog='epilog')
    assert parser is not None
    assert parser.prog == 'testprog'
    assert isinstance(parser.formatter_class, argparse.HelpFormatter)
    assert parser.epilog == 'epilog'
    assert parser.description == 'description'
    assert len(parser._actions) == 1
    assert parser._actions[0].dest == 'version'
    assert parser._actions[0].option_strings == ['--version']
    assert parser._actions[0].help == version.__doc__


# Generated at 2022-06-22 18:47:54.649466
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(prog='test_UnrecognizedArgument')
    parser.add_argument('--foo', action=UnrecognizedArgument)
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--foo'])
    assert False, 'unrecognized arguments: --foo'



# Generated at 2022-06-22 18:48:04.375062
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    p = argparse.ArgumentParser()
    p.add_argument('-b')
    p.add_argument('--foo')
    p.add_argument('--bar')
    p.add_argument('-a', '--bar')
    p.add_argument('--baz', '--qux')
    p.add_argument('-c')

    help_formatter = SortingHelpFormatter()
    help_formatter.add_arguments(p._actions)
    lines = help_formatter._root_section.split('\n')
    assert lines[1].startswith('  -a')
    assert lines[2].startswith('  --bar')
    assert lines[3].startswith('  -b')
    assert lines[4].startswith('  --baz')

# Generated at 2022-06-22 18:48:06.743075
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)


# Generated at 2022-06-22 18:48:13.322852
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(prog="TestBinary")
    add_runas_prompt_options(parser)
    options = parser.parse_args('-K --become-password-file=/path/to/a/file'.split())
    assert options.become_ask_pass == True
    assert options.become_password_file == '/path/to/a/file'



# Generated at 2022-06-22 18:48:22.143898
# Unit test for function ensure_value
def test_ensure_value():
    class MyNamespace:
        pass
    ns = MyNamespace()

    # ensure value None
    ensure_value(ns, 'test', None)
    assert(ns.test is None)
    ensure_value(ns, 'test', 'value')
    assert(ns.test == 'value')

    # ensure None value
    del ns.test
    ensure_value(ns, 'test', 'value')
    assert(ns.test == 'value')

    # ensure value list
    ensure_value(ns, 'test_list', [])
    assert(hasattr(ns, 'test_list'))
    ensure_value(ns, 'test_list', ['value'])
    assert(ns.test_list == ['value'])
    ensure_value(ns, 'test_list', 'value')