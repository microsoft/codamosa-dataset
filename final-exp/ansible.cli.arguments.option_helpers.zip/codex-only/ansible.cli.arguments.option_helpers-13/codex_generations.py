

# Generated at 2022-06-22 18:38:27.278224
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='?', const='hello')
    parser.add_argument('--bar', action=PrependListAction, nargs='?', const='world')
    args = parser.parse_args('--foo --bar'.split())
    assert args.foo == ['hello', None]
    assert args.bar == ['world', None]


#
# Signaling infrastructure
#

# Generated at 2022-06-22 18:38:36.362447
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description='Ansible %s Interpreter' % __version__,
                                     formatter_class=SortingHelpFormatter)
    parser.add_argument('-v', '--version', action='version', version='Ansible %s' % __version__)
    # Note: -vvvv -> -v -v -v -v
    parser.add_argument('-v', '--verbose', action='count', dest='verbosity', default=0,
                        help='verbose mode (-vvv for more, -vvvv to enable connection debugging)')
    parser.add_argument('-a', dest='host_list', metavar='host', action='append',
                        help='host to connect to')

# Generated at 2022-06-22 18:38:38.848277
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True



# Generated at 2022-06-22 18:38:46.987956
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('a', help='1')
    parser.add_argument('b', help='2')
    parser.add_argument('-c', help='3')
    parser.add_argument('-b', help='4')
    parser.add_argument('--z', help='5')
    parser.add_argument('--y', help='6')
    help_msg = parser.format_help()

# Generated at 2022-06-22 18:38:49.023870
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    assert parser.parse_args(['-K']).become_ask_pass is True
    assert parser.parse_args(['--become-password-file=/foo/bar']).become_password_file == '/foo/bar'


# Generated at 2022-06-22 18:38:52.347109
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    try:
        parser.parse_known_args(['--vault-password-file', 'UNIT_TEST_INVALID_PATH'])
    except AnsibleOptionsError:
        assert True
    else:
        assert False
    assert parser.parse_known_args(['--vault-password-file', 'UNIT_TEST_INVALID_PATH', '--vault-password-file', 'UNIT_TEST_INVALID_PATH'])



# Generated at 2022-06-22 18:38:54.447775
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # test for a good class
    sf = SortingHelpFormatter()
    assert sf.__class__.__name__ == "SortingHelpFormatter"


# Generated at 2022-06-22 18:39:04.785457
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Assuming /path/to/file exists on the test machine
    func = maybe_unfrack_path('@')
    assert func('@/path/to/file') == '@/path/to/file'
    # Assuming /path/to/file exists on the test machine
    assert func('@~/path/to/file') == '@/path/to/file'
    assert func('@/~/path/to/file') == '@/~/path/to/file'
    assert func('@path/to/file') == '@path/to/file'
    assert func('/path/to/file') == '/path/to/file'
    assert func('') == ''



# Generated at 2022-06-22 18:39:08.357741
# Unit test for function add_module_options
def test_add_module_options():
    # Test for the module_path option
    # Test for the superuser mode
    argv = ['-M', 'ansible', '-M', 'aws']
    args = AnsibleOptions(parser=add_module_options).parse(argv=argv)
    assert args.module_path == ['aws', 'ansible']
    # Test for standard user mode
    argv = ['-M', 'ansible', '-M', 'aws']
    args = AnsibleOptions(parser=add_module_options).parse(argv=argv)
    assert args.module_path == ['aws', 'ansible']



# Generated at 2022-06-22 18:39:12.053028
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])


# Generated at 2022-06-22 18:39:19.894058
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action=PrependListAction, dest='alist')
    args = parser.parse_args('--list 1 --list 2 --list 3'.split())
    args.alist = ['x', 'y', 'z']
    args1 = parser.parse_args('dummy --list 4 --list 5'.split())
    args.alist.extend(args1.alist)
    assert args.alist == ['1', '2', '3', '4', '5', 'x', 'y', 'z']


# Generated at 2022-06-22 18:39:25.906061
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir','/etc/ansible'])
    assert args.basedir == '/etc/ansible'


# Generated at 2022-06-22 18:39:32.118527
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='ansible', usage='usage: ansible <%s> [options] <inventory_spec>'
                                               ' [<pattern|file> ...] [<pattern> [<pattern>]]')
    # Version option should be added
    assert '--version' in [x.option_strings for x in parser._actions][0]
    # Formatter should be SortingHelpFormatter
    assert parser._actions[0].formatter_class == SortingHelpFormatter


# Generated at 2022-06-22 18:39:43.494293
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    s = '==> python -c "from ansible.cli import CLI; print(CLI().test_SortingHelpFormatter_add_arguments())" <=='
    h = argparse.HelpFormatter()
    h.add_argument("-b")
    h.add_argument("foo")
    h.add_argument("-a")
    h.add_argument("-c")
    h.add_argument("-A")
    h.add_argument("-B")
    h.add_argument("-C")
    h.add_argument("--foo")
    h.add_argument("--BAR")
    h.add_argument("--Baz")
    h.add_argument("--ZzZ")
    h.add_argument("--zzz")
    h.add_argument("--aaa")


# Generated at 2022-06-22 18:39:46.292756
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = version('ansible')
    app_name = ansible_version.split()[0]
    try:
        AnsibleVersion(app_name)
    except SystemExit:
        pass



# Generated at 2022-06-22 18:39:53.130430
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Create an instance of class SortingHelpFormatter
    formatter = SortingHelpFormatter()
    # Create an instance of argparse.Action
    test_action = argparse.Action(option_strings='--test-option-string', dest='test_dest')
    actions = [test_action]
    # Performs the actual formatting of the help message
    expected_text = '--test-option-string  \n'
    formatter_text = formatter.format_help(actions)[0]
    # Compare strings
    assert formatter_text == expected_text


# Generated at 2022-06-22 18:39:56.704882
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    try:
        parser.parse_args(['--foo'])
    except SystemExit:
        pass
    else:
        raise AssertionError('Failed to raise SystemExit.')



# Generated at 2022-06-22 18:40:03.295303
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='test_add_inventory_options',)
    add_inventory_options(parser)
    result = parser.parse_args(['-i', 'test/test_inven.yml', '--list-hosts', '-l', 'test'])
    assert (result == argparse.Namespace(inventory='test/test_inven.yml', listhosts=True, subset='test'))


# Generated at 2022-06-22 18:40:15.853420
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    # ensure no arguments are added by default
    assert len(parser._actions) == 0
    # ensure a vault-id adds a vault option
    parser.add_argument('--vault-id', default=[], dest='vault_ids', action='append', type=str,
                        help='the vault identity to use')
    assert len(parser._actions) == 1
    try:
        parser.parse_args(['--vault-id'])
    except SystemExit as e:
        assert e.code == 2
    parser.parse_args(['--vault-id', 'myid'])
    # ensure an actual vault file adds vault options

# Generated at 2022-06-22 18:40:18.672342
# Unit test for function add_fork_options
def test_add_fork_options():
    test_parser = argparse.ArgumentParser(prog="ansible-playbook",
                                        formatter_class=SortingHelpFormatter,
                                        conflict_handler='resolve')
    add_fork_options(test_parser)
    test_args = ['-f', '20', '--forks', '20']
    assert_args = {'forks': '20'}
    assert vars(test_parser.parse_args(test_args)) == assert_args



# Generated at 2022-06-22 18:40:19.375905
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
     pass

# Generated at 2022-06-22 18:40:25.456368
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    assert parser.format_help().strip(' \n').split('\n') == [
            'usage: ',
            '',
            'optional arguments:',
            '  --bar',
            '  --foo',
            '',
            ]


# Generated at 2022-06-22 18:40:28.574114
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(description='Test for function add_tasknoplay_options')
    add_tasknoplay_options(parser)
    parser.parse_args(['--task-timeout', '20'])


# Generated at 2022-06-22 18:40:36.398551
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    test1 = Namespace()
    ensure_value(test1, 'a', 1)
    assert test1.a == 1
    test2 = Namespace()
    test2.a = 2
    assert ensure_value(test2, 'a', 1) == 2
    assert test2.a == 2


#
# Main OptionParser configuration
#

# Generated at 2022-06-22 18:40:41.179196
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert parser.parse_args(["--task-timeout", "600"]).task_timeout == 600
    assert parser.parse_args([]).task_timeout == 600



# Generated at 2022-06-22 18:40:43.449623
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    opt = parser.parse_args(['-f', '5'])
    assert opt.forks == 5


# Generated at 2022-06-22 18:40:49.674768
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser("ansible-config")
    opts, args = parser.parse_known_args("-v".split())
    assert opts.verbosity == 1
    opts, args = parser.parse_known_args("-vvvv".split())
    assert opts.verbosity == 4



# Generated at 2022-06-22 18:40:54.605535
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args([])

    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP

    args = parser.parse_args(['--tags', 'tag1'])
    assert args.tags == ['tag1']
    assert args.skip_tags == C.TAGS_SKIP

    args = parser.parse_args(['--tags', 'tag1', '-t', 'tag2'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == C.TAGS_SKIP

    args = parser.parse_args(['--skip-tags', 'tag1'])
    assert args.tags == C.TAGS_

# Generated at 2022-06-22 18:40:57.765985
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(description='ansible')
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)

    results = parser.parse_args(['--version'])
    assert results.version == ''



# Generated at 2022-06-22 18:41:02.830921
# Unit test for function add_check_options
def test_add_check_options():
    from argparse import ArgumentParser
    org_parser = ArgumentParser()
    add_check_options(org_parser)
    (options, args) = org_parser.parse_known_args(['-C', '--syntax-check', '-D'])
    assert options.check is True
    assert options.syntax is True
    assert options.diff is True


# Generated at 2022-06-22 18:41:13.267601
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-c')
    parser.add_argument('--b')
    parser.add_argument('a')
    help = parser.format_help()
    positional = help.split('optional arguments:')[0].split('positional arguments:')[1].splitlines()
    optional = help.split('optional arguments:')[1].splitlines()
    assert positional == ['  a', '  --b', '  -c']
    assert optional == ['  -h, --help  show this help message and exit']
    #print(help)

#
# End of special purpose OptionParsers
#



# Generated at 2022-06-22 18:41:22.367146
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from unittest import mock
    from tempfile import NamedTemporaryFile
    from ansible.module_utils._text import to_bytes

    fakecommand = 'fakecommand'
    fakeversion = 'fakeversion'
    fakeversion = to_bytes(fakeversion)
    fakeout = NamedTemporaryFile()
    with mock.patch('sys.stdout.buffer.write') as mock_write:
        ansible_version = AnsibleVersion('store_true')
        ansible_version(None, None, None, fakecommand)
        mock_write.assert_called_with(fakeversion)



# Generated at 2022-06-22 18:41:30.671671
# Unit test for function add_check_options
def test_add_check_options():
    import tempfile
    import ansible.config.manager
    import pytest

    config_manager = ansible.config.manager.ConfigManager(
        os.path.join(tempfile.gettempdir(), 'ansible.cfg'))
    config_manager.set('defaults', 'stdout_callback', 'json')

    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, args = parser.parse_known_args(['-C'])
    assert options.check is True
    assert options.diff is False


# Generated at 2022-06-22 18:41:36.928604
# Unit test for function add_vault_options
def test_add_vault_options():
    # test if add-vault-option add ask-vault-password option
    module_parser = argparse.ArgumentParser()
    add_vault_options(module_parser)
    # test if add-vault-option add vault-password-file option
    module_parser = argparse.ArgumentParser()
    add_vault_options(module_parser)
    # test if add-vault-option add vault-id option
    module_parser = argparse.ArgumentParser()
    add_vault_options(module_parser)
    # test if add-vault-option add mutually exclusive option
    module_parser = argparse.ArgumentParser()
    add_vault_options(module_parser)


# Generated at 2022-06-22 18:41:43.744978
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(
        prog='mock',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_fork_options(parser)
    opts = parser.parse_args(['-f', '8'])
    assert opts.forks == 8


# Generated at 2022-06-22 18:41:44.577385
# Unit test for function version
def test_version():
    assert (__version__.startswith('2.9'))

# Generated at 2022-06-22 18:41:48.945026
# Unit test for function add_basedir_options
def test_add_basedir_options():
    print("Testing : test_add_basedir_options")
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', '/root/playbooks'])
    assert options.basedir == '/root/playbooks'


# Generated at 2022-06-22 18:41:50.767239
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='test')
    add_output_options(parser)
    opts = parser.parse_args(['-o', '-t', 'test'])
    assert opts.one_line is True
    assert opts.tree == 'test'



# Generated at 2022-06-22 18:41:54.699857
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.cli import CLI

    parser = CLI.base_parser()
    options = parser.parse_args(['-i', 'test_inventory'])

    assert options.inventory == ['test_inventory']

#
# Base Parser
#

# Generated at 2022-06-22 18:41:59.504387
# Unit test for function add_output_options
def test_add_output_options():
    parser = Mock()
    add_output_options(parser)
    # pylint: disable=line-too-long
    parser.add_argument.assert_any_call('-t', '--tree', dest='tree', default=None, help='log output to this directory')
    parser.add_argument.assert_any_call('-o', '--one-line', dest='one_line', action='store_true', help='condense output')



# Generated at 2022-06-22 18:42:03.441445
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path') == '@' + unfrackpath('/path')
    assert maybe_unfrack_path('@')('/path') == '/path'


# Generated at 2022-06-22 18:42:11.322657
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        prog="test_add_verbosity_options",
        formatter_class=SortingHelpFormatter,
        description="Testing add_verbosity_options",
        conflict_handler='resolve',
    )
    add_verbosity_options(parser)
    assert parser.parse_args(['-v']).verbosity == 1
    assert parser.parse_args(['-v', '-v']).verbosity == 2
    assert parser.parse_args(['-v', '-v', '-v']).verbosity == 3



# Generated at 2022-06-22 18:42:15.171102
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser=argparse.ArgumentParser(prog="test_add_basedir_options")
    add_basedir_options(parser)
    args=parser.parse_args(['-h'])


# Generated at 2022-06-22 18:42:17.836500
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args([])
    assert args.listhosts is False
    with pytest.raises(SystemExit):
        args = parser.parse_args([])


# Generated at 2022-06-22 18:42:23.986666
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    (options, args) = parser.parse_known_args(['-M', '/test'])
    assert options.module_path[0] == '/test'
    assert options.module_path[1] == ansible.__path__[0] + '/modules'



# Generated at 2022-06-22 18:42:26.229041
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    return parser.parse_args()


# Generated at 2022-06-22 18:42:35.316937
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='test_add_vault_options')
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test-id', '--ask-vault-password', '--vault-password-file', 'test.vault'])
    assert options.vault_ids == ['test-id']
    assert options.ask_vault_pass
    assert options.vault_password_files == ['test.vault']



# Generated at 2022-06-22 18:42:45.913561
# Unit test for function unfrack_path
def test_unfrack_path():
    # Call on scalar value
    assert unfrack_path()('foo') == 'foo'

    # Call on list of values
    # We should always use os.pathsep, but for compatibility with other code
    # we will accept other separators for now.
    assert unfrack_path(pathsep=True)('foo:bar') == ['foo', 'bar']
    assert unfrack_path(pathsep=True)('foo:bar:') == ['foo', 'bar']
    assert unfrack_path(pathsep=True)(':foo:bar:') == ['foo', 'bar']
    assert unfrack_path(pathsep=True)('foo,bar') == ['foo', 'bar']
    assert unfrack_path(pathsep=True)('foo,bar,') == ['foo', 'bar']
    assert unfrack

# Generated at 2022-06-22 18:42:57.106615
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import PluginLoader
    from ansible.cli import CLI
    Parser = argparse.ArgumentParser()
    Parser.add_argument('--version', nargs=0, action=AnsibleVersion, help='show ansible version')
    options = Parser.parse_args(['--version'])
    options.help = 'show ansible version'
    options.version = True
    options.verbosity = 0

# Generated at 2022-06-22 18:43:01.755934
# Unit test for function add_fork_options
def test_add_fork_options():
    """
    Checks that the correct number of parallel processes are specified
    """
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args('-f 20'.split())
    assert options.forks == 20


# Generated at 2022-06-22 18:43:12.628500
# Unit test for function add_check_options
def test_add_check_options():
    from collections import namedtuple
    Opts = namedtuple('Opts', ['check', 'syntax', 'diff'])
    arg_str = '--check --syntax-check --diff'
    ns = parse_options(arg_str)
    assert Opts(check=True, syntax=True, diff=True)== ns
    assert ns.verbosity == 0
 
    arg_str = '-vvvv'
    ns = parse_options(arg_str)
    assert ns.verbosity == 4
   
    arg_str = '--version'
    ns = parse_options(arg_str)
    assert ns
    arg_str = '-P 120 -B 30'
    ns = parse_options(arg_str)
    assert ns.seconds == 30
    assert ns.poll_interval == 120
    arg_

# Generated at 2022-06-22 18:43:13.501178
# Unit test for function add_runtask_options
def test_add_runtask_options():
    # TODO: implement this unit test
    raise AnsibleError("This unit test has not yet been implemented")


# Generated at 2022-06-22 18:43:17.118192
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action=UnrecognizedArgument, nargs='+', help='Test UnrecognizedArgument')
    parser.parse_args(['--test'])


# Generated at 2022-06-22 18:43:19.547255
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args(['-vvvv'])
    assert options.verbosity == 4


# Generated at 2022-06-22 18:43:27.717198
# Unit test for function add_runas_options
def test_add_runas_options():
    test_parser = argparse.ArgumentParser()
    add_runas_options(test_parser)

    # Test that required arguments were added
    assert "--become" in test_parser.format_help()
    assert "-b" in test_parser.format_help()
    assert "--become-method" in test_parser.format_help()
    assert "--become-user" in test_parser.format_help()

    # Test that help text is correct
    assert 'run operations with become' in test_parser.format_help()
    assert "'ansible-doc -t become -l' to list valid choices" in test_parser.format_help()
    assert 'run operations as this user' in test_parser.format_help()



# Generated at 2022-06-22 18:43:33.728820
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', '.'])
    assert options.basedir == unfrackpath('.')
    options = parser.parse_args(['--playbook-dir', '/foo/bar'])
    assert options.basedir == unfrackpath('/foo/bar')
    options = parser.parse_args([])
    assert options.basedir == None



# Generated at 2022-06-22 18:43:37.795300
# Unit test for function add_basedir_options
def test_add_basedir_options():
    
    parser = argparse.ArgumentParser(prog='ansible-vault')
    add_basedir_options(parser)
    args = parser.parse_args()
    assert args.basedir
    assert len(args.basedir) == len(C.DEFAULT_BECOME_METHODS)
    
    
    

# Generated at 2022-06-22 18:43:39.387291
# Unit test for function add_runas_options
def test_add_runas_options():
    parse = argparse.ArgumentParser()
    add_runas_options(parse)



# Generated at 2022-06-22 18:43:43.228291
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(description='Test for function add_runas_prompt_options')
    add_runas_prompt_options(parser)
    try:
        parser.parse_args(['--become-password-file', ''])
    except IOError:
        pass
    try:
        parser.parse_args(['--become-password-file', '/tmp/123'])
    except IOError:
        pass


# Generated at 2022-06-22 18:43:47.853366
# Unit test for function add_async_options
def test_add_async_options():
    p = argparse.ArgumentParser()
    add_async_options(p)
    options, args = p.parse_known_args(['-B', '1', '-P', '2'])
    assert options.seconds == 1
    assert options.poll_interval == 2


# Generated at 2022-06-22 18:43:59.462635
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    """
    The method add_arguments of class SortingHelpFormatter calls
    the parent class's add_arguments method after sorting
    the list of actions it is given.

    This test is not very comprehensive.  All it does is
    confirm that SortingHelpFormatter.add_arguments
    calls super with the same list if it is already sorted,
    and with a reversed list if it is sorted in reverse order.
    """
    class MockedSortingHelpFormatter(SortingHelpFormatter):
        def __init__(self):
            self.actions = []
        def add_arguments(self, actions):
            self.actions = actions
            return super(MockedSortingHelpFormatter, self).add_arguments(actions)

# Generated at 2022-06-22 18:44:07.980706
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    cmd = parser.add_parser("create")
    cmd.add_argument("--bucket", action=PrependListAction, nargs='+')

    args = parser.parse_args("create --bucket my-bucket".split())
    assert args.bucket == ["my-bucket"]
    args = parser.parse_args("create --bucket my-bucket --bucket my-bucket2".split())
    assert args.bucket == ["my-bucket2", "my-bucket"]


# Generated at 2022-06-22 18:44:09.647866
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    parser.parse_args(['-K'])
    parser.parse_args(['--become-password-file=/path/to/file'])



# Generated at 2022-06-22 18:44:10.296347
# Unit test for function add_connect_options
def test_add_connect_options():
    pass


# Generated at 2022-06-22 18:44:20.648669
# Unit test for function add_output_options
def test_add_output_options():
    
    args = None
    # Test with --tree
    args = shlex.split(' --tree')
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        assert False, "Test of add_output_options with --tree failed"
    assert parsed_args.tree == None, "Test of add_output_options with --tree failed for args.tree"
    assert parsed_args.one_line == False, "Test of add_output_options with --tree failed for args.one_line"
    # Test with -t
    args = shlex.split('-t')
    parser = argparse.ArgumentParser()
    add_output_options(parser)

# Generated at 2022-06-22 18:44:25.046153
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():

    class Options:
        """ Dummy class to collect args """
        def __init__(self):
            self.become_ask_pass = False
            self.become_password_file = None

    class Args:
        """ Dummy class for args """
        def __init__(self):
            self.become_ask_pass = False
            self.become_password_file = None

    opt = Options()
    args = Args()

    # Create an option parser
    parser = argparse.ArgumentParser()

    # Add options
    add_runas_prompt_options(parser, runas_group=None)

    # Run the args
    parser.parse_args(namespace=args)

    # Ensure the opt class has these attributes
    assert(hasattr(opt, "become_ask_pass"))


# Generated at 2022-06-22 18:44:28.586494
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--foo',
        action=PrependListAction,
        help='List of strings',
        type=str,
    )
    parser.add_argument(
        '--bar',
        default=[],
        help='List of strings',
        type=str,
    )
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--bar=3', '--bar=4'])
    assert args.foo == ['1', '2']
    assert args.bar == ['3', '4']
#
# Main Option Parser
#


# Generated at 2022-06-22 18:44:33.070798
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, help="unrecognized argument")
    options = parser.parse_args(['--foo'])
    assert options.foo is True
    assert options.help is None



# Generated at 2022-06-22 18:44:41.020558
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        epilog='epilog',
        description='desc',
        conflict_handler='resolve',
    )
    parser = add_verbosity_options(parser)
    assert '-v' in vars(parser.parse_args(['-v', '-vv', '-vvv', '-vvvv']))['verbosity']
    assert 'ansible version' in vars(parser.parse_args(['--version']))['version']
    assert '-vvvv' in vars(parser.parse_args(['-vvvv']))['verbosity']


# Generated at 2022-06-22 18:44:43.536275
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D', '--diff'])
    assert args.check is True
    assert args.syntax is True
    assert args.diff is True

# Generated at 2022-06-22 18:44:51.281774
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    option_strings = ['--_test']
    help_string = 'help_string'
    action = argparse.Action(option_strings=option_strings, help=help_string)
    test_SortingHelpFormatter = SortingHelpFormatter(prog='a_string')
    assert test_SortingHelpFormatter.add_arguments(actions=[action])



# Generated at 2022-06-22 18:44:55.973505
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)

    opts = parser.parse_args(['--playbook-dir', './test/test_basedir'])
    assert opts.basedir == os.path.join(os.path.dirname(__file__), '..', 'test/test_basedir')



# Generated at 2022-06-22 18:45:02.430048
# Unit test for function add_runtask_options
def test_add_runtask_options():
    import pdb

    parser = argparse.ArgumentParser()
    pdb.set_trace()
    add_runtask_options(parser)
    parser.parse_args(['-e', '@test.yaml', '-e', 'test2=@test2.yaml'])


# Generated at 2022-06-22 18:45:10.415951
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.config.manager import ConfigManager

    class fake_parser:
        def __init__(self):
            self.name = "test"
            self.args = ["-b", "-c", "-d", "--monkey"]
            self.config = ConfigManager()

        def error(self, msg):
            raise argparse.ArgumentError(None, msg)

    fp = fake_parser()
    with pytest.raises(argparse.ArgumentError) as exc:
        UnrecognizedArgument(option_strings=["-b", "-c", "-d", "--monkey"],
                             dest="--monkey", const=None, default=None,
                             required=False, help='', metavar=None)(fp, None, None, "--monkey")

# Generated at 2022-06-22 18:45:13.733124
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from ansible.cli.arguments import OptionsHelper
    helper = OptionsHelper(desc='', version='')
    parser = add_runas_prompt_options(helper.parser)
    args = ['--become-password-file', '-K']
    options = parser.parse_args(args)
    assert options.become_password_file == '-'
    assert options.become_ask_pass is True



# Generated at 2022-06-22 18:45:18.802143
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='remove-unused-molecule-yml')
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', '~/my/playbook', '/etc/ansible/roles/'])
    assert args.basedir == '~/my/playbook'

# Generated at 2022-06-22 18:45:22.660247
# Unit test for function ensure_value
def test_ensure_value():
    class MyNamespace():
        def __init__(self):
            self.empty_list = None

    my_namespace = MyNamespace()
    assert ensure_value(my_namespace, 'empty_list', []) == []
    assert my_namespace.empty_list == []



# Generated at 2022-06-22 18:45:33.307424
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    assert parser.parse_args('-i test'.split()).inventory == ['test']
    assert parser.parse_args('--inventory-file test'.split()).inventory == ['test']
    assert parser.parse_args('-i test --inventory ansible --inventory-file ansible/inventory'.split()).inventory == ['test', 'ansible', 'ansible/inventory']

    assert parser.parse_args('-l test'.split()).subset == 'test'
    assert parser.parse_args('--limit test'.split()).subset == 'test'
    # Test missing or unset value
    assert parser.parse_args('--limit'.split()).subset == C.DEFAULT_SUBSET



# Generated at 2022-06-22 18:45:40.196467
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        description="validate the add_fork_options function",
        conflict_handler='resolve',
    )
    add_fork_options(parser)
    output = parser.parse_args(['-f', '10'])
    assert output.forks == 10
# END


# Generated at 2022-06-22 18:45:41.499457
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    assert 'AnsibleVersion' in globals()
    assert AnsibleVersion

# Generated at 2022-06-22 18:45:50.901458
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', 'abc=def', '-e', 'ghi=jkl', '-e', 'key=multi line',
                              '-e', '@/path/to/json', '-e', '@/path/to/yaml'])
    assert 'abc' in args.extra_vars
    assert 'ghi' in args.extra_vars
    assert 'key' in args.extra_vars



# Generated at 2022-06-22 18:45:54.723731
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', 'test'])
    assert args.tree == 'test'



# Generated at 2022-06-22 18:46:01.719285
# Unit test for function add_async_options
def test_add_async_options():
    parser = create_base_parser('argparse_test', desc='example test')
    add_async_options(parser)
    option = parser.parse_args(['--poll', '50', '--background', '30'])
    assert option.poll_interval == 50
    assert option.seconds == 30

# Functions add_common_options & add_vault_options is tested in test_playbook.py



# Generated at 2022-06-22 18:46:10.557519
# Unit test for function add_inventory_options
def test_add_inventory_options():
    print("test_add_inventory_options")
    parser = create_base_parser('test')
    add_inventory_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.inventory is None
    assert options.listhosts is False
    assert options.subset is C.DEFAULT_SUBSET
    (options, args) = parser.parse_known_args(['--list-hosts'])
    assert options.inventory is None
    assert options.listhosts is True
    assert options.subset is C.DEFAULT_SUBSET
    (options, args) = parser.parse_known_args(['-i', '/path/to/file'])
    assert options.inventory == ['/path/to/file']
    assert options.listhosts is False

# Generated at 2022-06-22 18:46:22.205696
# Unit test for function create_base_parser
def test_create_base_parser():
    """
    Create an options parser for all ansible scripts
    """
    # base opts
    parser = create_base_parser("test_prog.py", usage="test", desc="test description", epilog="test epilog")

# Generated at 2022-06-22 18:46:29.953006
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
  mock_parser = MockParser()
  mock_namespace = MockNamespace()

  UnrecognizedArgument(option_strings=["--test", "-T"], dest="TESTING").__call__(mock_parser, mock_namespace, 1)
  assert mock_parser.error_called
  assert mock_parser.error_called_with == "unrecognized arguments: --test"

#
# Option Parser and subcommand creation
#

# Generated at 2022-06-22 18:46:31.721471
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    return parser

# Generated at 2022-06-22 18:46:43.151582
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.module_utils._text import to_bytes
    # This function tests some common use cases of PrependListAction
    # The basic idea is to pass a list of arguments to the parser.
    # Then the expected behavior is that a list of those arguments
    # should be prepended to the action's destination attribute.
    class TestParser(argparse.ArgumentParser):
        """A testing parser that allows accessing the parsed values through
        a dictionary."""
        def __init__(self):
            super(TestParser, self).__init__()
            self.clear()
            self.add_argument('--foo', action=PrependListAction, nargs=2)

        def parse_args(self, arg_list):
            self.clear()
            super(TestParser, self).parse_args(arg_list)


# Generated at 2022-06-22 18:46:50.805151
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser=argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert parser.parse_args([]).verbosity == 0
    assert parser.parse_args(['-v']).verbosity == 1
    assert parser.parse_args(['-vv']).verbosity == 2
    assert parser.parse_args(['-vvvvvv']).verbosity == 6



# Generated at 2022-06-22 18:46:59.210150
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()
    display.columns = 100

    action = PrependListAction(
        option_strings=["-h", "--help"],
        dest='list',
        default=[],
        help="Test plugin options"
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("-h", "--help", action=action, help="Test plugin options")
    parser.add_argument("-n", "--name", help="Test plugin options", dest='name', default=None)
    parser.add_argument("-p", "--path", help="Test plugin options", dest='path', default=None)

# Generated at 2022-06-22 18:47:05.704704
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    p = argparse.ArgumentParser()
    p.add_argument('--foo', action='store_true')
    p.add_argument('--bar', action=UnrecognizedArgument)
    # Unrecognized argument should raise an error
    try:
        p.parse_args('--foo --bar'.split())
        assert(False)
    except SystemExit as e:
        pass


# Generated at 2022-06-22 18:47:16.001082
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class FakeAction:
        def __init__(self, option_strings):
            self.option_strings = option_strings

    actions = [FakeAction(option_strings=['-b']),
               FakeAction(option_strings=['-d', '-f']),
               FakeAction(option_strings=['-a']),
               FakeAction(option_strings=['-c'])]
    fake_parser = FakeHelpParser()
    formatter = SortingHelpFormatter(fake_parser)
    formatter.add_arguments(actions)
    assert fake_parser.last_action_added == '-a'
    assert fake_parser.actions_called == ''.join(sorted(''.join(action.option_strings) for action in actions))



# Generated at 2022-06-22 18:47:22.236600
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog='test')
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '5'])
    assert args.task_timeout == 5
    parser = argparse.ArgumentParser(prog='test')
    add_tasknoplay_options(parser)
    with pytest.raises(SystemExit):
        parser.parse_args(['--task-timeout', '-4'])



# Generated at 2022-06-22 18:47:25.173366
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='test')
    add_basedir_options(parser)
    parser.parse_args()



# Generated at 2022-06-22 18:47:31.290234
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()
    prepend_list_action = PrependListAction(['-a'], 'action', ['a'], ['b'])
    prepend_list_action(None, namespace, [], option_string=None)
    assert namespace.action == ['a', 'b'], namespace.action


# Generated at 2022-06-22 18:47:42.692754
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace:
        """A fake namespace object for testing purposes"""
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    foo_ns = FakeNamespace()
    assert foo_ns.foo is None
    ensure_value(foo_ns, 'foo', [])
    assert foo_ns.foo == []
    ensure_value(foo_ns, 'foo', None)
    assert foo_ns.foo == []
    ensure_value(foo_ns, 'foo', [1, 2, 3])
    assert foo_ns.foo == [1]

    bar_ns = FakeNamespace(bar=None)
    assert bar_ns.bar is None
    ensure_value(bar_ns, 'bar', [])
    assert bar

# Generated at 2022-06-22 18:47:50.657149
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='test')
    add_connect_options(parser)
    opts = parser.parse_args(['--connection-password-file', '/tmp/passfile'])
    assert opts.ask_pass == False
    assert opts.connection_password_file == '/tmp/passfile'
    opts = parser.parse_args(['-k'])
    assert opts.ask_pass == True

# Generated at 2022-06-22 18:48:02.156093
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(["--private-key", ".ssh/host.pem","-u","root","-c","ssh","-T","3600"
                              ,"--ssh-common-args","gssapi-with-mic,tcp,none","--sftp-extra-args","-f","-l"
                              ,"--scp-extra-args","-l","--ssh-extra-args","-R","-k","--connection-password-file",
                              ".ssh"])
    assert args.private_key_file == '.ssh/host.pem'
    assert args.remote_user == "root"
    assert args.connection == "ssh"
    assert args.timeout == 3600

# Generated at 2022-06-22 18:48:06.846391
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    assert 'inventory' in parser._actions
    assert 'list-hosts' in parser._actions
    assert 'limit' in parser._actions
assert test_add_inventory_options()


# Generated at 2022-06-22 18:48:07.867250
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    parser.parse_args([])


# Generated at 2022-06-22 18:48:16.897176
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """
    Helper function to test the SortingHelpFormatter
    """
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--a')
    parser.add_argument('--c')
    parser.add_argument('--b')
    help = parser.format_help()
    assert help.split('\n')[4] == '  --a --b --c'
    assert help.split('\n')[-5] != '  --a --b --c'
    assert help.split('\n')[-5] == '  --c --b --a'



# Generated at 2022-06-22 18:48:18.868753
# Unit test for function add_meta_options
def test_add_meta_options():
    myParser = argparse.ArgumentParser()
    add_meta_options(myParser)
    assert len(myParser._actions) == 2
    assert myParser._actions[0].dest == 'force_handlers'
    assert myParser._actions[1].dest == 'flush_cache'

# Generated at 2022-06-22 18:48:23.463213
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
    )
    add_inventory_options(parser)
    result = parser.parse_args([])
    assert hasattr(result, 'inventory')
    assert hasattr(result, 'listhosts')
    assert result.listhosts == False
    assert result.inventory is None
    assert hasattr(result, 'subset')
    assert result.subset == C.DEFAULT_SUBSET
    result = parser.parse_args(['-i', 'inventory'])
    assert result.inventory == ['inventory']
    result = parser.parse_args(['-i', 'inventory', '--list-hosts'])
    assert result.inventory == ['inventory']
    assert result.listhosts == True