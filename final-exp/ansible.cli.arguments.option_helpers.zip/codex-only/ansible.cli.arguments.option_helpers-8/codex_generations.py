

# Generated at 2022-06-22 18:38:28.406281
# Unit test for function unfrack_path
def test_unfrack_path():
    # In windows, the base directory is '/'.
    # In other OS, the base directory is ''.
    assert unfrack_path(False)('fixtures/test.ini') == os.path.abspath(os.path.join(C.DEFAULT_LOCAL_TMP, 'fixtures/test.ini'))
    assert unfrack_path(False)('/fixtures/test.ini') == os.path.abspath('/fixtures/test.ini')
    assert unfrack_path(False)('fixtures/../test.ini') == os.path.abspath(os.path.join(C.DEFAULT_LOCAL_TMP, '../test.ini'))

# Generated at 2022-06-22 18:38:37.198341
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args()
    assert args.vault_ids == []
    assert not args.ask_vault_pass
    assert args.vault_password_files == []
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--ask-vault-password'])
    assert args.vault_ids == []
    assert args.ask_vault_pass
    assert args.vault_password_files == []
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-password-file', 'vault-pass-file'])

# Generated at 2022-06-22 18:38:40.125976
# Unit test for function add_async_options
def test_add_async_options():
    assert create_base_parser('test.py', 'usage').parse_args([]) == argparse.Namespace(seconds=0, poll_interval=10)



# Generated at 2022-06-22 18:38:46.059791
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    class MyParser(argparse.ArgumentParser):
        def exit(self, status=0, message=None):
            raise SystemExit(message)
    try:
        parser = MyParser()
        parser.add_argument('-x', '--x', nargs=1, action=UnrecognizedArgument)
        parser.parse_args(['-x', 'X'])
    except SystemExit as e:
        assert 'unrecognized arguments' in e.args[0]
    else:
        raise Exception("__call__ of UnrecognizedArgument didn't raise SystemExit")



# Generated at 2022-06-22 18:38:48.713433
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    option_string = "--one-line"
    value = parser.parse_args([option_string]).one_line
    assert True == value


# Generated at 2022-06-22 18:38:49.459701
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser=add_runas_prompt_options()

# Generated at 2022-06-22 18:38:55.239337
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '{ "@vars.yml": null }'])
    assert args.extra_vars == ["{ @vars.yml: null }"]
    args = parser.parse_args(['-e', '@vars.yml'])
    assert args.extra_vars == ["vars.yml"]
    args = parser.parse_args(['-e', '{"@vars.json": null}'])
    assert args.extra_vars == ["{ @vars.json: null }"]
    args = parser.parse_args(['-e', '@vars.json'])
    assert args.extra_vars == ["vars.json"]

# Generated at 2022-06-22 18:39:00.888539
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    opts = parser.parse_args(["-P", "1", "-B", "2"])
    assert opts.poll_interval == 1
    assert opts.seconds == 2



# Generated at 2022-06-22 18:39:04.354019
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    obj = UnrecognizedArgument(['--version'], None, nargs=1)
    obj.__call__(None, None, None, '--version')
# END of class UnrecognizedArgument


#
# Help/Documentation methods
#

# Generated at 2022-06-22 18:39:06.581232
# Unit test for function add_fork_options
def test_add_fork_options():
    import os.path
    OptionParser = argparse.ArgumentParser
    parser = OptionParser()
    add_fork_options(parser)
    args = parser.parse_args('-f 10'.split())
    assert args.forks == 10
    #
    args = parser.parse_args(''.split())
    assert args.forks == C.DEFAULT_FORKS


# Generated at 2022-06-22 18:39:11.028816
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ap = argparse.ArgumentParser(prog='ansible')
    version_action = AnsibleVersion(option_strings=('--version',))
    ap.add_argument('--version', action=version_action)
    ap.parse_args(args=['--version'])


# Generated at 2022-06-22 18:39:14.163742
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args()
    assert args.force_handlers, "force_handlers not set to true by default"
    assert not args.flush_cache, "flush_cache defaults to false"


# Generated at 2022-06-22 18:39:14.563721
# Unit test for function add_vault_options
def test_add_vault_options():
      assert 1 == 1

# Generated at 2022-06-22 18:39:16.423220
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='test')
    assert parser!=None


# Generated at 2022-06-22 18:39:17.934188
# Unit test for function version
def test_version():
    test_version = version('test')
    assert test_version.startswith('test')

# Generated at 2022-06-22 18:39:28.189680
# Unit test for function add_connect_options
def test_add_connect_options():
    # Confirm that the connect group exists and is an argument group
    parser = argparse.ArgumentParser()
    connect_group = parser.add_argument_group("Connection Options", "control as whom and how to connect to hosts")
    assert connect_group.title == "Connection Options"
    assert connect_group.description == "control as whom and how to connect to hosts"
    assert connect_group.parser is parser
    assert not connect_group._group_actions
    # add the connection options
    add_connect_options(parser)
    # confirm the data
    options = vars(parser.parse_args([]))
    assert options['remote_user'] == C.DEFAULT_REMOTE_USER
    assert options['connection'] == C.DEFAULT_TRANSPORT
    assert options['timeout'] == C.DEFAULT_TIMEOUT

# Generated at 2022-06-22 18:39:32.058465
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('*')('*foo/bar') == '*foo/bar'
    assert maybe_unfrack_path('*')('*../bar') == '*foo/bar'
    assert maybe_unfrack_path('*')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-22 18:39:39.641287
# Unit test for function version
def test_version():
    expected_output = [
        'ansible-cli-legacy [core 2.9.19]',
        '  config file = %s' % C.CONFIG_FILE,
        '  configured module search path = Default w/o overrides',
        '  ansible python module location = %s' % ':'.join(ansible.__path__),
        '  ansible collection location = %s' % ':'.join(C.COLLECTIONS_PATHS),
        '  executable location = %s' % sys.argv[0],
        '  python version = %s' % ''.join(sys.version.splitlines()),
        '  jinja version = %s' % j2_version,
        '  libyaml = %s' % HAS_LIBYAML
    ]

# Generated at 2022-06-22 18:39:41.232537
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = create_base_parser("test_options")
    add_tasknoplay_options(parser)
    parser.parse_args(['-i', 'local', '--', 'ping'])



# Generated at 2022-06-22 18:39:42.249896
# Unit test for function add_module_options
def test_add_module_options():
    import ansible.constants as C

# Generated at 2022-06-22 18:39:46.490231
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    u = UnrecognizedArgument(option_strings=['--help'], dest='unrecognized_argument', required=True, help='help text')
    assert u.option_strings == ['--help']
    assert u.dest == 'unrecognized_argument'
    assert u.required is True
    assert u.help == 'help text'



# Generated at 2022-06-22 18:39:56.236760
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='test')
    parser.formatter_class = SortingHelpFormatter
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == C.DEFAULT_REMOTE_USER
    assert args.connection == C.DEFAULT_TRANSPORT
    assert args.timeout == C.DEFAULT_TIMEOUT
    assert args.ssh_common_args is None
    assert args.sftp_extra_args is None
    assert args.scp_extra_args is None
    assert args.ssh_extra_args is None



# Generated at 2022-06-22 18:40:04.944604
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    group = parser.add_argument_group('group')
    group.add_argument('-f', '--foo', help='A foo', action='store_true')
    group.add_argument('-b', '--bar', help='A bar', action='store_true')
    group.add_argument('-z', '--baz', help='A baz', action='store_true')
    #
    # This is the text we are looking for
    #
    assert '-b BAR, --bar BAR' in parser.format_help()



# Generated at 2022-06-22 18:40:16.456050
# Unit test for function unfrack_path
def test_unfrack_path():
    curwd = os.getcwd().replace('\\', '/')

    # Test legacy handling of empty separated paths
    assert unfrack_path(pathsep=True)('') == []

    # Test simple path handling, with and without surrounding quotes
    assert unfrack_path(pathsep=False)('foo') == 'foo'
    assert unfrack_path(pathsep=False)('"foo"') == 'foo'

    # Test handling of special name '-', with and without surrounding quotes
    assert unfrack_path(pathsep=False)('-') == '-'
    assert unfrack_path(pathsep=False)('"-"') == '-'

    # Test handling of relative paths; current directory
    assert unfrack_path(pathsep=False)('./foo') == '%s/foo' % curwd
    assert unfrack

# Generated at 2022-06-22 18:40:19.951485
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog='foo')
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '5'])
    assert args.task_timeout == 5


# Generated at 2022-06-22 18:40:23.781386
# Unit test for function add_module_options
def test_add_module_options():
    myParser = argparse.ArgumentParser()
    add_module_options(myParser)
    assert myParser.get_default('module_path') == C.DEFAULT_MODULE_PATH
    assert myParser.get_default('module_path') == '~/.ansible/plugins/modules:/usr/share/ansible/plugins/modules'
    assert myParser.get_default('help') == 'prepend colon-separated path(s) to module library (default=~/.ansible/plugins/modules:/usr/share/ansible/plugins/modules)'
    #assert myParser.get_default('type') == unfrack_path(pathsep=True)
    assert myParser.get_default('action') == PrependListAction


# Generated at 2022-06-22 18:40:28.185407
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog="Test"
    )
    add_basedir_options(parser)
    args = parser.parse_args(["--playbook-dir=/ansible/playbook_dir"])
    assert 'basedir' in args
    assert args.basedir == to_native('/ansible/playbook_dir')


# Generated at 2022-06-22 18:40:33.009270
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = parser.parse_args(['-vvvv'])
    assert args.verbosity == 4

# Generated at 2022-06-22 18:40:43.726300
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='test_add_inventory_options',
                                     formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve')
    add_inventory_options(parser)

# Generated at 2022-06-22 18:40:46.946350
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser(prog='test')
    # Test add_fork_options with default value
    add_fork_options(parser)
    options = parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS
    # Test add_fork_options with new value
    options = parser.parse_args(['--forks', '10'])
    assert options.forks == 10



# Generated at 2022-06-22 18:40:49.423458
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    defaultVal = C.DEFAULT_FORKS
    add_fork_options(parser)
    try:
        opt, args = parser.parse_known_args(["-f", defaultVal])
        forksVal = opt.forks
        assert forksVal == defaultVal
    except:
        assert False


# Generated at 2022-06-22 18:40:55.019490
# Unit test for function add_output_options
def test_add_output_options():
    '''
     Unit test for function add_output_options
    '''
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 1
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_output_options(parser)
    arguments = parser.parse_args()
    print(arguments.tree)
    print(arguments.one_line)



# Generated at 2022-06-22 18:41:01.426272
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog="test_add_check_options")
    add_check_options(parser)
    assert sorted(['--check', '--syntax-check', '-D', '--diff']) == sorted(list(parser._option_string_actions.keys()))
    parsed = parser.parse_args(['--check'])
    assert parsed.check is True
    parsed = parser.parse_args(['--syntax-check'])
    assert parsed.syntax is True
    parsed = parser.parse_args(['-D'])
    assert parsed.diff is True


# Generated at 2022-06-22 18:41:09.509438
# Unit test for function add_vault_options
def test_add_vault_options():
    """
    Unit test for ansible.cli.arguments.add_vault_options
    """
    parser = MockArgumentParser()
    add_vault_options(add_help=False, parser=parser)
    parser.parse_args(shlex.split("--vault-id vault-infra-dev@prompt"))
    assert parser.vault_ids == ["vault-infra-dev@prompt"]



# Generated at 2022-06-22 18:41:11.367516
# Unit test for function add_runtask_options
def test_add_runtask_options():
    result = add_runtask_options([])
    print(result)
# Unit test ends


# Generated at 2022-06-22 18:41:20.370913
# Unit test for function add_vault_options
def test_add_vault_options():
    result = [
        {'ask_vault_pass': True},
        {'vault_ids': ['foo'], 'ask_vault_pass': True},
        {'vault_ids': ['foo'], 'vault_password_files': ['/path/to/vault_file']},
        {'vault_ids': ['foo', 'bar'], 'vault_password_files': ['/path/to/vault_file']},
        {'vault_ids': ['foo', 'bar'], 'vault_password_files': ['/path/to/vault_file', '/bar']},
    ]
    for i in result:
        parser = argparse.ArgumentParser()
        add_vault_options(parser)

# Generated at 2022-06-22 18:41:27.806434
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i',
                              './hosts',
                              '--list-hosts',
                              '-l',
                              'webservers:&foo'])

    assert args.inventory == ['./hosts']
    assert args.listhosts
    assert args.subset == 'webservers:&foo'



# Generated at 2022-06-22 18:41:39.228080
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Create a parser to test add_runas_prompt_options
    parser = argparse.ArgumentParser(
        prog='Unit test for add_runas_prompt_options'
    )
    # Create a group to test add_runas_prompt_options
    runas_group = parser.add_argument_group(
        title='Unit test for add_runas_prompt_options'
    )
    add_runas_prompt_options(parser, runas_group)
    # Test -K and --ask-become-pass
    # If the code is not correct, it will return an error that the Arguement of argument -K/--ask-become-pass is conflicted with argument -K/--ask-become-pass.
    args = parser.parse_args('-K'.split())
    # If the

# Generated at 2022-06-22 18:41:43.561232
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """ Test function add_tasknoplay_options """
    # Test function works as expected
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    # Test default value for --task-timeout option is set
    args = parser.parse_args(['--task-timeout'])
    assert args.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-22 18:41:48.243493
# Unit test for function add_async_options
def test_add_async_options():

    from units.mock.parser import MockOpts
    parser = MockOpts()
    add_async_options(parser)
    assert parser.has_option('-P')
    assert parser.has_option('--poll')
    assert parser.has_option('-B')
    assert parser.has_option('--background')

# Generated at 2022-06-22 18:41:51.473573
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='test_add_subset_options')
    add_subset_option(parser)

# Generated at 2022-06-22 18:41:58.330195
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    from ansible.cli.parser import AnsibleParser
    from ansible.release import __version__

    parser = AnsibleParser(usage='usage', formatter=SortingHelpFormatter())
    parser.add_argument('-v', '--version', dest='version', help='show program version', action=AnsibleVersion)
    test_args = ['-v']
    parsed_args = parser.parse_args(args=test_args)
    ansible_version = to_native(version(parser.prog))
    assert ansible_version == __version__


# Generated at 2022-06-22 18:42:00.463274
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_output_options(parser)
    args = parser.parse_args(['--one-line', '--tree', 'test/target/path'])
    assert args.one_line is True
    assert args.tree == 'test/target/path'



# Generated at 2022-06-22 18:42:04.245113
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    assert parser.parse_args(["-k"]).ask_pass



# Generated at 2022-06-22 18:42:13.690143
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path("@")("@/etc/ansible/ansible.cfg") == "@/etc/ansible/ansible.cfg")
    assert(maybe_unfrack_path("@")("/etc/ansible/ansible.cfg") == "/etc/ansible/ansible.cfg")
    assert(maybe_unfrack_path("@")("@/etc/ansible/hosts") == "@/etc/ansible/hosts")
    assert(maybe_unfrack_path("@")("@/etc/ansible/hosts") == "@/etc/ansible/hosts")
    assert(maybe_unfrack_path("@@")("@@/etc/ansible/hosts") == "/etc/ansible/hosts")



# Generated at 2022-06-22 18:42:16.497505
# Unit test for function ensure_value
def test_ensure_value():
    a = argparse.Namespace()
    ensure_value(a, 'b', {})
    assert a.b == {}


# common options for ansible tools

# Generated at 2022-06-22 18:42:19.943348
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog="test")
    add_async_options(parser)
    opts_values = parser.parse_args()
    assert opts_values.poll_interval == C.DEFAULT_POLL_INTERVAL
    assert opts_values.seconds == 0


# Generated at 2022-06-22 18:42:28.530314
# Unit test for function add_check_options
def test_add_check_options():
    args = argparse.Namespace(
        # check_options
        check=False,
        diff=False,
        syntax=False,
    )
    parser = argparse.ArgumentParser(prog='test')
    add_check_options(parser)
    return_value = parser.parse_args(args=['-C', '--syntax-check', '-D'], namespace=args)
    assert return_value.check == True
    assert return_value.diff == True
    assert return_value.syntax == True


# Generated at 2022-06-22 18:42:30.510863
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='ansible')
    assert parser is not None


# Generated at 2022-06-22 18:42:42.113599
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.cli.arguments import option_helpers as opt_help
    parser = opt_help.create_base_parser("ansible test")
    opt_help.add_connect_options(parser)
    options = parser.parse_args(['--private-key=abc','--ssh-common-args=abc','--sftp-extra-args=abc','--ssh-extra-args=abc','--connection-password-file=abc','--ssh-common-args=ProxyCommand'])
    assert options.private_key_file == 'abc'
    assert options.ssh_common_args == 'ProxyCommand'
    assert options.sftp_extra_args == 'abc'
    assert options.ssh_extra_args == 'abc'
    assert options.connection_password_file == 'abc'
    #print options.ssh_common

# Generated at 2022-06-22 18:42:48.447061
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    >>> parser = argparse.ArgumentParser()
    >>> parser.add_argument('--foo', nargs=2, action=PrependListAction)
    >>> parser.parse_args('--foo a b c d'.split())
    Namespace(foo=['c', 'd', 'a', 'b'])
    """

#
# Functions in the style of optparse
#

# Generated at 2022-06-22 18:42:49.542919
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # FIXME
    pass



# Generated at 2022-06-22 18:42:55.148582
# Unit test for function ensure_value
def test_ensure_value():
    class ns:
        pass
    a_ns = ns()
    a_ns.a = None
    ensure_value(a_ns, 'a', 1)
    assert a_ns.a == 1

    a_ns.a = 2
    ensure_value(a_ns, 'a', 1)
    assert a_ns.a == 2

#
# Standard parsers
#


# Generated at 2022-06-22 18:42:57.440053
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.parse_args(['-M', 'test'])



# Generated at 2022-06-22 18:43:08.023767
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # pylint: disable=protected-access

    options = ('-f', '--foo')
    dest = 'foo_list'
    args = ('arg1', 'arg2')

    # Test with nargs=2
    nargs = 2
    action = PrependListAction(options, dest, nargs=nargs)
    assert action.option_strings == options
    assert action.dest == dest
    assert action.nargs == nargs
    assert action.const is None
    assert action.default is None
    assert action.type is None
    assert action.choices is None
    assert not action.required
    assert action.help is None
    assert action.metavar == 'arg1 arg2'



# Generated at 2022-06-22 18:43:16.011955
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible', conflict_handler='resolve')
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    args = dict(vars(args))
    assert args['check'], '--check option error'
    assert args['syntax'], '--syntax-check option error'
    assert args['diff'], '--diff option error'
#

# Generated at 2022-06-22 18:43:23.226548
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import io
    import ansible.utils.display as display
    from ansible.cli.arguments import base_parser
    from ansible.cli.arguments import meta_parser

    output = io.StringIO()
    with display.redirect_stdout(output):
        base_parser.print_help()
    base_parser_output = output.getvalue().split('\n')
    # Because of the output is different among Python 2, Python 3 and Windows,
    # we only care some part of the output
    base_parser_output = base_parser_output[base_parser_output.index('optional arguments:'):]
    output = io.StringIO()
    with display.redirect_stdout(output):
        meta_parser.print_help()
    meta_parser_output = output.getvalue().split('\n')


# Generated at 2022-06-22 18:43:28.054101
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, nargs=2)
    try:
        parser.parse_args(['--foo', 'bar', 'baz'])
    except SystemExit:
        assert True
        return
    assert False  # Should never reach this point



# Generated at 2022-06-22 18:43:31.858265
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    import sys

    from ansible.module_utils.six import StringIO
    from ansible.cli import CLI

    test_args = ['./ansible', '--task-timeout', '50']
    test_stdout = StringIO()
    test_stderr = StringIO()
    cli = CLI(
        args=test_args,
        stdout=test_stdout,
        stderr=test_stderr
    )

    if sys.version_info >= (2, 7):
        cli._parse()

    #assert cli.parser.task_timeout == 50
    test_stdout.close()
    test_stderr.close()


# Generated at 2022-06-22 18:43:36.693167
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cli.default import CLI
    args = ['ansible', '--version']
    with pytest.raises(SystemExit):
        parser = CLI.base_parser(add_help=False)
        parser.add_argument('--version', action=AnsibleVersion)
        parser.add_argument('--help', action='help')
        parser.parse_args(args)


# Generated at 2022-06-22 18:43:40.657787
# Unit test for function ensure_value
def test_ensure_value():
    class Args:
        pass
    args = Args
    args.t = None
    ensure_value(args, 't', 'yay')
    assert args.t == 'yay'
    args.t = 'nay'
    ensure_value(args, 't', 'yay')
    assert args.t == 'nay'



# Generated at 2022-06-22 18:43:43.567459
# Unit test for function version
def test_version():
    # create a dummy module
    module = argparse.ArgumentParser()
    version(module)
    print(version())

# Generated at 2022-06-22 18:43:49.414999
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['--inventory-file', 'hosts', '--list-hosts', '--limit=192.168.0.1'])
    assert args.inventory == ['hosts']
    assert args.listhosts
    assert args.subset == '192.168.0.1'


# Generated at 2022-06-22 18:43:54.125926
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    class FakeOptParser():
        def __init__(self):
            self.opts = []

        def add_argument_group(self, name, description):
            return self

        def add_argument(self, *args, **kwargs):
            self.opts.append(args[0])

        def add_mutually_exclusive_group(self):
            return self

    assert len(FakeOptParser().opts) == 0
    test_parser = FakeOptParser()
    add_runas_prompt_options(test_parser)

    assert len(test_parser.opts) == 3
    assert '-K' in test_parser.opts
    assert '--ask-become-pass' in test_parser.opts
    assert '--become-password-file' in test_parser.opts

# Generated at 2022-06-22 18:43:55.798690
# Unit test for function create_base_parser
def test_create_base_parser():
    assert create_base_parser


# Generated at 2022-06-22 18:44:02.664775
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--foo', action=UnrecognizedArgument)
    # This line is a chance to see in debugger how arguments were parsed
    # parser.parse_args(['--foo', 'bar', 'baz'])
    # This line is a chance to see in debugger how arguments were parsed
    with pytest.raises(SystemExit) as err:
        parser.parse_args(['--foo', 'bar', 'baz'])
    assert 1 == err.value.code



# Generated at 2022-06-22 18:44:13.931931
# Unit test for function add_check_options
def test_add_check_options():
    import tempfile
    import shutil
    from ansible.playbook.play_context import PlayContext

    tmpdir = tempfile.mkdtemp()
    print("Using tempdir {0}".format(tmpdir))

    # Create dummy files in tmpdir to simulate ansible installation
    dummy_file = 'dummy_file.py'
    dummy_file_path = os.path.join(tmpdir, dummy_file)
    with open(dummy_file_path, "w") as f:
        f.write("#!/usr/bin/python")
    print("Created {0}".format(dummy_file_path))

    # Create dummy config file
    dummy_config = 'test_config.cfg'
    dummy_config_path = os.path.join(tmpdir, dummy_config)

# Generated at 2022-06-22 18:44:23.325903
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='test-playbook-dir')
    add_basedir_options(parser)
    parser.parse_args(['--playbook-dir', 'C:\\test'])
    parser.parse_args(['--playbook-dir', 'C:/test', '--playbook-dir', 'C:/test/test'])
    parser.parse_args(['--playbook-dir', 'C:\\test\\test'])
    parser.parse_args(['--playbook-dir', 'C:/'])
    try:
        parser.parse_args(['--playbook-dir', 'C:\\test\\test\\test'])
    except SystemExit:
        assert True



# Generated at 2022-06-22 18:44:29.014078
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parsed = parser.parse_args(['--playbook-dir', 'my-playbook-dir'])
    assert parsed.basedir == 'my-playbook-dir'


# Generated at 2022-06-22 18:44:29.920206
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog = "test")
    add_meta_options(parser)



# Generated at 2022-06-22 18:44:31.863836
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)

# Generated at 2022-06-22 18:44:36.202150
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    pargs = parser.parse_args(['--check', '--syntax-check', '-D'])
    assert pargs.check == True
    assert pargs.syntax == True
    assert pargs.diff == True



# Generated at 2022-06-22 18:44:45.429901
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    result = parser.parse_args(['-b', '--become-method=su', '--become-user=me', '-K'])
    assert result.become == True
    assert result.become_method == 'su'
    assert result.become_user == 'me'
    assert result.ask_pass == True
    assert result.ask_sudo_pass == True
    assert result.ask_su_pass == True


# Generated at 2022-06-22 18:44:49.297497
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', nargs=0, action=AnsibleVersion)
    parser.parse_args(['--version'])

# Generated at 2022-06-22 18:44:53.559333
# Unit test for function add_fork_options
def test_add_fork_options():
        test_defacking_path = "~/unfrackpath"
        parser = argparse.ArgumentParser()
        add_fork_options(parser)

        args = parser.parse_args(['--forks', '300'])
        assert args.forks == 300


# Generated at 2022-06-22 18:44:58.223184
# Unit test for function ensure_value
def test_ensure_value():
    import argparse
    class Namespace(object):
        pass

    assert [] == ensure_value(Namespace(), 'foo', [])
    assert 'bar' == ensure_value(Namespace(), 'foo', 'bar')
    assert 'baz' == ensure_value(Namespace(foo='baz'), 'foo', 'baz')


#
# The main parser used when running from the command line
#


# Generated at 2022-06-22 18:45:00.534567
# Unit test for function version
def test_version():
    assert ' [core 2.7.0]' in version("ansible-config")


# Generated at 2022-06-22 18:45:04.371925
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser=argparse.ArgumentParser()
    add_tasknoplay_options(parser)

    dest_value=parser.parse_args(['--task-timeout','10']).task_timeout
    assert dest_value==10


# Generated at 2022-06-22 18:45:08.365182
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    argv = ['ansible-doc']
    parser = argparse.ArgumentParser()
    parser.add_argument('-v' , '--version', dest='version', action=AnsibleVersion, default=argparse.SUPPRESS, help='Ansible version number')
    args = parser.parse_args(argv)
    assert vars(args) == {}



# Generated at 2022-06-22 18:45:13.772896
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    result = parser.parse_args('-t a -t b --skip-tags c --skip-tags d'.split())
    assert result.tags == ['a', 'b']
    assert result.skip_tags == ['c', 'd']

# Generated at 2022-06-22 18:45:15.250331
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    import tempfile
    parser=argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert parser._actions[-1].dest=='task_timeout'


# Generated at 2022-06-22 18:45:23.583398
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_str = maybe_unfrack_path("@")("@/tmp/test")
    assert test_str == "@" + unfrackpath("/tmp/test"), "Maybe_unfrack_path should be used for @/tmp/test"
    test_str = maybe_unfrack_path("@")("~/tmp/test")
    assert test_str == "~/tmp/test", "Maybe_unfrack_path should not be used for ~/tmp/test"

#
# Options for OptionParsers
#

# Generated at 2022-06-22 18:45:28.224964
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    res = parser.parse_args(["--force-handlers", "--flush-cache"])

    assert res.force_handlers == True
    assert res.flush_cache == True


# Generated at 2022-06-22 18:45:39.978255
# Unit test for function create_base_parser
def test_create_base_parser():
    """
    A function to create an option parser and check that it is identical
    to the standard base parser.
    """
    # base opts
    prog = 'ansible-runner'
    desc = 'desc'
    epilog = 'epilog'
    parser = create_base_parser(prog, desc, epilog)
    # parser.add_argument('--version', action=AnsibleVersion, nargs=0, help='show program\'s version number and exit')
    parser.add_argument('-v', '--verbose', dest='verbosity', action='count', default=0,
                        help='verbose mode (-vvv for more, -vvvv to enable connection debugging)')


# Generated at 2022-06-22 18:45:40.551700
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass

# Generated at 2022-06-22 18:45:45.944647
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    result = parser.parse_args(['-M/foo'])
    assert result.module_path == ['/foo']

    result = parser.parse_args(['-M/foo:/bar'])
    assert result.module_path == ['/foo', '/bar']

    result = parser.parse_args([])
    assert result.module_path == None



# Generated at 2022-06-22 18:45:49.383088
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.parse_args()

# Generated at 2022-06-22 18:45:52.465138
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    prepend = PrependListAction('-a', 'foo')
    ns = argparse.Namespace(foo=[1, 2, 3])
    prepend.__call__(ns, 'abc')
    assert ns.foo == ['abc', 1, 2, 3]

    prepend.__call__(ns, 'def')
    assert ns.foo == ['def', 'abc', 1, 2, 3]



# Generated at 2022-06-22 18:45:59.093636
# Unit test for function add_output_options
def test_add_output_options():
    test_parser = argparse.ArgumentParser(description="This is a test parser")
    add_output_options(test_parser)
    parsed_options = test_parser.parse_args(["-o", "-t", "/path/to/tree"])
    assert parsed_options.one_line
    assert parsed_options.tree == "/path/to/tree"


# Generated at 2022-06-22 18:46:09.595428
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    assert_equal(parser.parse_args('-t tag'.split()).tags, ['tag'])
    assert_equal(parser.parse_args('-t tag1 -t tag2'.split()).tags, ['tag1', 'tag2'])
    assert_equal(parser.parse_args('--skip-tags skip'.split()).skip_tags, ['skip'])
    assert_equal(parser.parse_args('--skip-tags skip1 --skip-tags skip2'.split()).skip_tags, ['skip1', 'skip2'])



# Generated at 2022-06-22 18:46:16.459968
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    # TODO: I am not sure what is being tested here but I am comfortable deleting
    # this unit test.
    test_args = parser.parse_args('--vault-id test_id --ask-vault-pass --vault-password-file /path/to/vaultfile.txt'.split())
    assert test_args.vault_ids == ['test_id']
    assert test_args.vault_password_files == ['/path/to/vaultfile.txt']
    assert test_args.ask_vault_pass is True



# Generated at 2022-06-22 18:46:26.285560
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    fake_path = '/some/fake/path'
    fake_beacon = '@fakedir:'
    def fake_unfrackpath(path):
        return fake_path
    orig_unfrack = ansible.utils.path.unfrackpath
    ansible.utils.path.unfrackpath = fake_unfrackpath
    assert maybe_unfrack_path(fake_beacon)(fake_path) == fake_beacon + fake_path
    assert maybe_unfrack_path(fake_beacon)(fake_beacon + fake_path) == fake_beacon + fake_path
    ansible.utils.path.unfrackpath = orig_unfrack



# Generated at 2022-06-22 18:46:36.784517
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(description='Test Add Check Options function')
    add_check_options(parser)
    try:
        # Normally, it's bad to explicitly catch an exception like this, but the argparse module
        # doesn't provide a way to check for it without throwing the exception
        # even if the action did what was expected.
        parser.parse_args(["--check"])
        assert "check" in parser.parse_args(["--check"])
        assert "diff" in parser.parse_args(["--diff"])
        assert "syntax" in parser.parse_args(["--syntax-check"])
    except SystemExit as e:
        assert "unrecognized arguments: --check" == str(e)


# Generated at 2022-06-22 18:46:38.525647
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)


# Generated at 2022-06-22 18:46:44.325457
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--append',
        action=PrependListAction,
        type=int,
        dest='append',
    )
    ns = parser.parse_args(['--append', '8', '--append', '9'])
    assert ns.append == [8, 9]


# Generated at 2022-06-22 18:46:55.852399
# Unit test for function version

# Generated at 2022-06-22 18:46:59.506684
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument("--create", action=UnrecognizedArgument)
    args = parser.parse_args("--create".split())
    parser.parse_known_args("--create".split())



# Generated at 2022-06-22 18:47:03.955983
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible', usage='%(prog)s ')
    add_check_options(parser)
    assert parser.format_help() == """usage: ansible [options]

optional arguments:
  -h, --help            show this help message and exit
  -C, --check           don't make any changes; instead, try to predict some of the changes that may occur
  --syntax-check        perform a syntax check on the playbook, but do not execute it
  -D, --diff            when changing (small) files and templates, show the differences in those files; works great with --check
"""



# Generated at 2022-06-22 18:47:06.619442
# Unit test for function add_async_options
def test_add_async_options():
    test_parser = argparse.ArgumentParser()
    add_async_options(test_parser)
    # test default values
    default_values = {
        'poll_interval': C.DEFAULT_POLL_INTERVAL,
        'seconds': 0
    }
    for k, v in default_values.items():
        assert v == test_parser.parse_args([]).__dict__[k]



# Generated at 2022-06-22 18:47:14.597681
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-d', action='store', dest='debug')
    parser.add_argument('-f', action='store', dest='force')
    parser.add_argument('-l', action='store', dest='listhosts')

    actions = parser._get_optional_actions()
    assert actions[0].dest == 'debug'
    assert actions[1].dest == 'force'
    assert actions[2].dest == 'listhosts'


# Generated at 2022-06-22 18:47:19.082284
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(['-M', 'tests/data/modules', '-M', '~/my_modules'])
    assert args.module_path == ['tests/data/modules', '~/my_modules']


# Generated at 2022-06-22 18:47:21.104404
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    assert '-C' in parser._option_string_actions



# Generated at 2022-06-22 18:47:29.491950
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = Mock()
    parser.add_argument = MagicMock(return_value=None)
    parser.add_mutually_exclusive_group = MagicMock(return_value=parser)
    parser.set_defaults = MagicMock(return_value=None)
    add_vault_options(parser)
    parser.add_argument.assert_called_with('--vault-id', default=[], dest='vault_ids', action='append', help='the vault identity to use', type=str)


# Generated at 2022-06-22 18:47:41.945547
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(description="test_add_connect_options")
    add_connect_options(parser)

    options = parser.parse_args(['-u', 'remote_user', '-k', '-T', 'timeout', '-c', 'connection', '--ssh-common-args',
                                 'ssh_common_args', '--ssh-extra-args', 'ssh_extra_args', '--sftp-extra-args',
                                 'sftp_extra_args', '--scp-extra-args', 'scp_extra_args', '--private-key', 'key-file',
                                 '--connection-password-file', 'conn_pass_file'])
    assert options.remote_user == 'remote_user' and \
           options.ask_pass and \
           options.timeout

# Generated at 2022-06-22 18:47:55.105275
# Unit test for function add_runtask_options
def test_add_runtask_options():

    with patch.object(ArgumentParser,'add_argument', return_value=None), \
         patch.object(ArgumentParser, 'add_mutually_exclusive_group', return_value=None):
        parser=ArgumentParser()

        add_runtask_options(parser)
        parser.add_argument.assert_any_call('-e', '--extra-vars', dest="extra_vars", action="append", type=maybe_unfrack_path('@'),
                        help="set additional variables as key=value or YAML/JSON, if filename prepend with @", default=[])
        parser.add_argument.assert_any_call('-t', '--tags', dest='tags', default='all',
                        help="only run plays and tasks tagged with these values")

# Generated at 2022-06-22 18:48:00.264118
# Unit test for function add_output_options
def test_add_output_options():
    """Unit test for function add_output_options"""
    parser = argparse.ArgumentParser()
    print ("Testing add_output_options")
    add_output_options(parser)
    args = parser.parse_args('-t /tmp/test1'.split())
    assert args.tree == '/tmp/test1'
    print ("Success")


# Generated at 2022-06-22 18:48:10.514398
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(prog='a', formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    try:
        parser.add_argument('--spam', action='store_true')
    except:
        pass
    output = parser.format_help()
    assert output.index('--bar') < output.index('--baz') < output.index('--foo')
    assert '--spam' not in output



# Generated at 2022-06-22 18:48:15.306743
# Unit test for function version
def test_version():
    import ansible.constants as C
    C.ANSIBLE_CACHE_PLUGIN = None
    C.ANSIBLE_CACHE_PLUGIN_CONNECTION = None
    assert version().startswith('ansible 2.1.1.')
    # Unit test for function version

# Generated at 2022-06-22 18:48:19.146555
# Unit test for function add_async_options
def test_add_async_options():
    """Tests for proper results from add_async_options"""
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P5', '-B10'])
    assert args.poll_interval == 5
    assert args.seconds == 10



# Generated at 2022-06-22 18:48:30.586277
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser(description='argparse prepend list action test')
    parser.add_argument('-a', '--append', action='append', default=['0'], help='append help')
    parser.add_argument('-p', '--prepend', action=PrependListAction, default=['0'], help='prepend help')
    parser.add_argument('-b', '--both', action=PrependListAction, nargs='+', default=['0'], help='both help')

    args = parser.parse_args(['-a', '1', '-a', '2', '-p', '3', '-p', '4', '-b', '5', '-b', '6', '7'])
    assert args.append == ['0', '1', '2']
    assert args