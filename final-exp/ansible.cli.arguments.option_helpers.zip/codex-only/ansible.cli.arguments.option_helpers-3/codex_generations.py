

# Generated at 2022-06-22 18:38:31.579085
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class TestOptionParser(argparse.ArgumentParser):
        def __init__(self):
            super(TestOptionParser, self).__init__(formatter_class=SortingHelpFormatter)
            self.add_argument('-a')
            self.add_argument('-b')
            self.add_argument('-c')
    #
    # run the test
    #
    # save stdout so we can re-assign it later
    oldout, olderr = sys.stdout, sys.stderr

# Generated at 2022-06-22 18:38:39.602756
# Unit test for function add_basedir_options
def test_add_basedir_options():
    # Create a parser to parse command line options
    args = '--playbook-dir /home/ansible/playbook-demo'
    parser = argparse.ArgumentParser()
    # Add the options to the parser
    add_basedir_options(parser)
    # Parse the command line arguments
    options = parser.parse_args(args.split())
    # This returns the value for 'basedir'
    basedir = getattr(options, 'basedir')
    assert basedir == '/home/ansible/playbook-demo'



# Generated at 2022-06-22 18:38:43.485480
# Unit test for function add_check_options
def test_add_check_options():
    conn = add_check_options(argparse.ArgumentParser())
    conn.add_argument('-t', '--tags', dest='tags', help="only run plays and tasks tagged with these values")
    memory_values = conn.parse_args(['-t', 'test'])
    assert memory_values.tags == 'test'



# Generated at 2022-06-22 18:38:46.354737
# Unit test for function add_connect_options
def test_add_connect_options():
    group = parser.add_argument_group("test group")
    group.add_argument('-k', '--ask-pass', default=C.DEFAULT_ASK_PASS, dest='ask_pass', action='store_true',
                                        help='ask for connection password')



# Generated at 2022-06-22 18:38:47.398115
# Unit test for function add_runas_options
def test_add_runas_options():
    '''
    TBD
    '''
    pass



# Generated at 2022-06-22 18:38:50.734670
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    assert parser.parse_args(['--poll', '-1']).poll_interval == -1
    assert parser.parse_args(['--background', '60']).seconds == 60



# Generated at 2022-06-22 18:38:57.133836
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """Unit test for function `add_runas_prompt_options`."""
    # test 1: test with `runas_group` is set
    runas_group = argparse.ArgumentGroup("Privilege Escalation Options", "control how and which user you become as on target hosts")
    arg_parser = argparse.ArgumentParser( prog = "ansible-playbook" )
    add_runas_prompt_options(arg_parser, runas_group)
    assert runas_group in arg_parser._action_groups
    # test 2: test without `runas_group`
    arg_parser = argparse.ArgumentParser( prog = "ansible-playbook" )
    add_runas_prompt_options(arg_parser)
    assert len(arg_parser._action_groups) == 1
    #

# Generated at 2022-06-22 18:39:03.358641
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    parser.add_argument('echo')
    print(parser.parse_args(['-h']))
    print(parser.parse_args(['--force-handlers']))
    print(parser.parse_args(['--flush-cache']))
    print(parser.parse_args(['echo']))
# End of unit test



# Generated at 2022-06-22 18:39:13.890324
# Unit test for function unfrack_path
def test_unfrack_path():
    """This is a unittest for the function unfrack_path"""
    print ('testing unfrack_path')
    abs_path = os.path.abspath(os.path.dirname(__file__))
    rel_path = './units'
    assert abs_path == unfrack_path()(rel_path)
    pathsep_abs_path = os.path.abspath(os.path.dirname(__file__)) + os.pathsep + os.path.abspath(os.path.dirname(__file__))
    pathsep_rel_path = './units' + os.pathsep + './units'
    assert pathsep_abs_path == os.pathsep.join(unfrack_path(pathsep=True)(pathsep_rel_path))
   

# Generated at 2022-06-22 18:39:23.500936
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # create parser
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    # add arguments
    # positional arguments
    parser.add_argument('foo')
    parser.add_argument('bar')
    # optional arguments
    parser.add_argument('-a', '--aaa', help='A')
    parser.add_argument('-b', '--bbb', help='B')
    # short optional arguments
    parser.add_argument('-c', help='C')
    parser.add_argument('-d', help='D')
    # positional arguments
    parser.add_argument('zoo')
    parser.add_argument('zab')
    # print help message
    parser.print_help()


# Generated at 2022-06-22 18:39:33.087663
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', action='store_true', help='aaaaaaaa')
    parser.add_argument('-c', action='store_true', help='cccccccc')
    parser.add_argument('-a', action='store_true', help='bbbbbbbb')
    parser.add_argument('-z', action='store_true', help='zzzzzzzz')
    parser.epilog = 'zoooom!'


# Generated at 2022-06-22 18:39:42.304937
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(["--vault-id", "default", "--ask-vault-pass", "--vault-password-file", "default"])
    assert args.vault_ids == ["default"]
    assert args.ask_vault_pass == True
    assert args.vault_password_files == ["default"]


#
# Functions to parse options
#


# Generated at 2022-06-22 18:39:45.129011
# Unit test for function add_vault_options
def test_add_vault_options():
    # test for add_vault_options()
    parser = argparse.ArgumentParser()

    # test for the method add_vault_options()
    add_vault_options(parser)
    assert parser.parse_args(['--vault-password-file', '~/.vault/password.txt']).vault_password_files == ['~/.vault/password.txt']



# Generated at 2022-06-22 18:39:49.933726
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '30', '-B', '20'])

    assert options.poll_interval == 30
    assert options.seconds == 20
#


# Generated at 2022-06-22 18:39:54.779852
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    res = parser.parse_args(['--task-timeout', '60'])
    assert res.task_timeout == 60



# Generated at 2022-06-22 18:39:58.845474
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    parser.parse_args('-i ./hosts'.split())



# Generated at 2022-06-22 18:40:07.756342
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--test',
        action=PrependListAction,
        metavar="TEST",
        help="test help"
    )
    options = parser.parse_args([])
    assert options.__dict__.get('test') == None
    options = parser.parse_args(['--test', 'test'])
    assert options.test == ['test']
    options = parser.parse_args(['--test', 'test1', 'test2'])
    assert options.test == ['test1', 'test2']
    options = parser.parse_args(['--test', 'test1', 'test2', 'test3', 'test4'])
    assert options.test == ['test1', 'test2', 'test3', 'test4']


# Generated at 2022-06-22 18:40:13.573736
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '60'])
    assert args.poll_interval == 60
    args = parser.parse_args(['-B', '60'])
    assert args.seconds == 60



# Generated at 2022-06-22 18:40:23.551765
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)

    args = parser.parse_args(['--check'])
    assert args.check == True
    assert args.syntax == False
    assert args.diff == C.DIFF_ALWAYS

    args = parser.parse_args(['--syntax-check'])
    assert args.check == False
    assert args.syntax == True
    assert args.diff == C.DIFF_ALWAYS

    args = parser.parse_args(['--diff'])
    assert args.check == False
    assert args.syntax == False
    assert args.diff == True

# Generated at 2022-06-22 18:40:31.595461
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # Create the test class
    class Test(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.formatter = SortingHelpFormatter()

    # Create a test class instance and use its method add_argument
    # to add unsorted arguments to the parser's attributes
    t = Test()
    t.add_argument('-z')
    t.add_argument('-a')
    t.add_argument('-b', action='store_true')
    t.add_argument('-c', action='append')
    t.add_argument('z')
    t.add_argument('a')
    t.add_argument('b', action='store_true')

# Generated at 2022-06-22 18:40:37.883820
# Unit test for function add_basedir_options
def test_add_basedir_options():
    """
    add_basedir_options: No value
    """
    option_value = None
    parser = argparse.ArgumentParser(prog="add_basedir_options")
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', option_value])
    assert args.basedir == option_value

# Generated at 2022-06-22 18:40:42.633511
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """Test add_tasknoplay"""
    # Testing add_tasknoplay_options function
    actual = argparse.Namespace(task_timeout=None)
    expected = argparse.Namespace(task_timeout=None)
    add_tasknoplay_options(actual)
    assert expected.task_timeout == actual.task_timeout



# Generated at 2022-06-22 18:40:55.128344
# Unit test for function version
def test_version():
    import jinja2
    assert version('foo') == 'foo [core 2.0.0] ({0}) last updated {1} (GMT {2:+04d})'.format(
        _gitinfo().split()[0], time.strftime("%Y/%m/%d %H:%M:%S", time.localtime(os.stat('.git').st_mtime)[1:]), time.timezone / -3600)
    assert 'ansible python module location = %s' % ':'.join(ansible.__path__) in version()
    assert 'ansible collection location = %s' % ':'.join(C.COLLECTIONS_PATHS) in version()
    assert '  config file = %s' % C.CONFIG_FILE in version()

# Generated at 2022-06-22 18:41:00.304915
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = create_base_parser(prog='')
    add_connect_options(parser)
    (options, args) = parser.parse_known_args(['-k','-c','myconnection', '-T','2','--ssh-extra-args','value'])
    assert options.ask_pass is True
    assert options.connection == 'myconnection'
    assert options.timeout == 2
    assert options.ssh_extra_args == 'value'



# Generated at 2022-06-22 18:41:04.267134
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()

    add_output_options(parser)

    opts = parser.parse_args()

    assert opts.one_line
    assert opts.tree
    assert opts.tree == 'log'



# Generated at 2022-06-22 18:41:07.765577
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args()
    print(args)



# Generated at 2022-06-22 18:41:11.334152
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    opts = parser.parse_args("--check".split())
    assert opts.check == True


# Generated at 2022-06-22 18:41:14.892866
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_meta_options(parser)
    args = parser.parse_args(['--flush-cache', '--force-handlers'])

# Generated at 2022-06-22 18:41:26.022355
# Unit test for method __call__ of class UnrecognizedArgument

# Generated at 2022-06-22 18:41:28.908660
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runtask_options(parser)
    exit_code, args = parser.parse_known_args()


# Generated at 2022-06-22 18:41:33.027887
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible/') == [unfrackpath('/etc/ansible/')]
    assert unfrack_path(True)('/etc/ansible:/etc/ansible2') == [unfrackpath('/etc/ansible'), unfrackpath('/etc/ansible2')]


# Generated at 2022-06-22 18:41:40.879941
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = "/Users/foo/.ansible/tmp/ansible-tmp-1518242660.32-87727037806811/roles/test123_ssh/library"
    test_path_expected = "/Users/foo/.ansible/tmp/ansible-tmp-1518242660.32-87727037806811/roles/test123_ssh/library"
    assert test_path_expected == maybe_unfrack_path('@')(test_path)



# Generated at 2022-06-22 18:41:43.532367
# Unit test for function add_module_options
def test_add_module_options():
    parser = create_base_parser("test")
    add_module_options(parser)
    parser.parse_args()
test_add_module_options.valid = True  # pylint: disable=invalid-name



# Generated at 2022-06-22 18:41:46.022064
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    # TODO: Add assertions



# Generated at 2022-06-22 18:41:55.042621
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    idx_arg = sys.argv.index('--version')
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, help='show Ansible version number and exit')
    parser.add_argument('--extra-vars', action=UnrecognizedArgument, nargs=1, help='set additional variables as key=value or YAML/JSON')
    sys.argv.pop(idx_arg)
    options = parser.parse_args()


# Generated at 2022-06-22 18:42:01.229111
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    options = parser.parse_args(['-K'])
    assert options.become_ask_pass is True
    options = parser.parse_args(['--become-password-file', 'test/file.txt', '--become-pass-file', 'test/file.pass', '-K'])
    assert options.become_ask_pass is True
    assert options.become_password_file == 'test/file.txt'
    assert options.become_password_file == options.become_pass_file



# Generated at 2022-06-22 18:42:06.372717
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert options.check is True
    assert options.syntax is True
    assert options.diff is True



# Generated at 2022-06-22 18:42:11.775766
# Unit test for function add_check_options
def test_add_check_options():
    p = argparse.ArgumentParser()
    add_check_options(p)
    opt = p.parse_args(['--check'])
    assert opt.check == True
    opt = p.parse_args(['--syntax-check'])
    assert opt.syntax == True
    opt = p.parse_args(['--diff'])
    assert opt.diff == True


# Generated at 2022-06-22 18:42:13.030437
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert '--task-timeout' in parser._actions[8].option_strings


# Generated at 2022-06-22 18:42:21.748532
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            raise Exception(message)

    args = ['foo', 'bar']

    options = {
        'option_strings': ['--foo'],
        'dest': 'foo',
        'nargs': 1,
        'const': None,
        'default': None,
        'type': None,
        'choices': None,
        'required': False,
        'help': None,
        'metavar': None
    }

    namespace = argparse.Namespace()

    # see https://docs.python.org/3/library/argparse.html#argparse.Namespace
    # All other attributes (including __weakref__) are initialized by argument parsing
    # and are only used in that context.

# Generated at 2022-06-22 18:42:30.195681
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'one', '--vault-id', 'two', '--ask-vault-password', '--vault-password-file', '/path/to/vault_password_file'])
    assert options.vault_ids == ['one', 'two']
    assert options.ask_vault_pass is True
    assert options.vault_password_files == ['/path/to/vault_password_file']


#
# Utilities
#


# Generated at 2022-06-22 18:42:36.066040
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    vault_opts = ['--vault-id', '--ask-vault-password', '--vault-password-file', '--ask-vault-pass', '--vault-pass-file']
    for vault_opt in vault_opts:
        assert any(vault_opt in str(x) for x in parser._actions), 'Error: %s is not found.' % vault_opt


#
# Options Parser
#


# Generated at 2022-06-22 18:42:46.280291
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.utils.args import parse_env
    from ansible.parsing.vault import VaultLib
    from ansible.cli.arguments import _safe_env_dict
    from ansible.parsing.vault import ParserError
    parser = argparse.ArgumentParser()

    add_runtask_options(parser)

    test_vars = {}
    test_vars['test1'] = 'value1'
    test_vars['test2'] = 'value2'
    test_vars['test3'] = 'value3'

    test_yaml_file_content = '''
test1: value1
test2: value2
test3: value3
    '''
    test_yaml_file = "test_add_runtask_options_yaml.yml"
   

# Generated at 2022-06-22 18:42:48.261357
# Unit test for function add_meta_options
def test_add_meta_options():
        parser = Mock()
        add_meta_options(parser)
        assert_equals(parser.add_argument.call_count, 2)
        
    


# Generated at 2022-06-22 18:42:58.084069
# Unit test for function version
def test_version():
    from ansible.utils.path import unfrackpath
    from mock import patch

    def do_test(config_file, module_path, config_def_path, results):
        config_path = [config_file, module_path, config_def_path]
        with patch('ansible.constants.CONFIG_FILE', config_file), \
                patch('ansible.constants.DEFAULT_MODULE_PATH', config_def_path):
            test_results = version('test').split('\n')
            for test_result, expected_result in zip(test_results, results):
                assert test_result == expected_result

    # When config_file is C.CONFIG_FILE and DEFAULT_MODULE_PATH is C.DEFAULT_MODULE_PATH, they are not included
    # in the output of version()
   

# Generated at 2022-06-22 18:43:05.184384
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.cli import CLI
    cli = CLI(['sdd', '--extra-vars', 'foo'])
    cli.parser = argparse.ArgumentParser(prog='sdd')
    add_async_options(cli.parser)
    cli.parse()
    assert cli.options.poll_interval == C.DEFAULT_POLL_INTERVAL
    assert cli.options.seconds == 0



# Generated at 2022-06-22 18:43:08.482141
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args('--playbook-dir /foo/bar'.split())
    assert args.basedir == '/foo/bar'



# Generated at 2022-06-22 18:43:17.109267
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', nargs='*',
                       action=UnrecognizedArgument, choices=['one', 'two', 'three'], dest='myfoo')
    args = parser.parse_args(['--foo one two three'])
    assert args.myfoo == ['one', 'two', 'three']


#
# The only purpose of this class is to allow the deprecation of shell options in favor
# of connection plugin options of the same name, which is a form of backwards compatibility
#

# Generated at 2022-06-22 18:43:27.303449
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = ['-h']
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 7:
        # Python 3.7 changes CLI output order.
        with open('tests/sanity/python37_help.txt') as f:
            output = f.read()
        expected = output
    else:
        expected = '''usage:  [-h] [--foo] [--bar]

optional arguments:
  -h, --help  show this help message and exit
  --foo
  --bar
'''
    # The following assertion fails because argparse sorts arguments

# Generated at 2022-06-22 18:43:38.129238
# Unit test for function add_vault_options
def test_add_vault_options():
    args = {}
    parser = Mock()
    MockAction = namedtuple('MockAction', ['append'])
    parser.add_argument = Mock(return_value=MockAction(append=args.setdefault))
    parser.add_mutually_exclusive_group = Mock(return_value=Mock())
    my_vault_id = 'new_vault_id'
    my_ask_vault_pass = 'new_ask_vault_pass'
    my_vault_password_file = 'new_vault_password_file'
    argv = ['-v',
            '--vault-id', my_vault_id,
            '--ask-vault-password', my_ask_vault_pass,
            '--vault-password-file', my_vault_password_file]


# Generated at 2022-06-22 18:43:40.512009
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = parser.parse_args(['-vvvv', '-v'])
    assert args.verbosity == 5


# Generated at 2022-06-22 18:43:52.422499
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='run.py')
    add_runtask_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.extra_vars == []
    (options, args) = parser.parse_known_args(['-e', 'a=b'])
    assert options.extra_vars == ['a=b']
    (options, args) = parser.parse_known_args(['-e', '@a'])
    assert options.extra_vars == ['@a']
    (options, args) = parser.parse_known_args(['-e', 'a=b', '-e', '@a'])
    assert options.extra_vars == ['a=b', '@a']



# Generated at 2022-06-22 18:44:03.047974
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(description='Argparse ArgumentParser')
    add_subset_options(parser)

    # --tags
    argv = ['-t','tag1','--tags','tag2','--tags','tag3']
    args = parser.parse_args(argv)
    assert hasattr(args, 'tags')
    assert args.tags == ['tag1', 'tag2', 'tag3']

    # --skip-tags
    argv = ['--skip-tags','stag1','--skip-tags','stag2','--skip-tags','stag3']
    args = parser.parse_args(argv)
    assert hasattr(args, 'skip_tags')
    assert args.skip_tags == ['stag1', 'stag2', 'stag3']


# Generated at 2022-06-22 18:44:05.313622
# Unit test for function version
def test_version():
    assert version('test_program').startswith('test_program [core')

# Generated at 2022-06-22 18:44:09.329577
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    try:
        AnsibleVersion(option_strings=['--version'], dest='version', nargs=0, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-22 18:44:10.969676
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    # Parser should not have a --ask-become-pass argument
    parser.parse_args(args=['--ask-become-pass'])



# Generated at 2022-06-22 18:44:16.963692
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog='test.py',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_async_options(parser)
    options = parser.parse_args(['-P', '22', '-B', '33'])
    assert options.poll_interval == 22
    assert options.seconds == 33



# Generated at 2022-06-22 18:44:20.688522
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    my_parser = argparse.ArgumentParser()

    add_runas_prompt_options(my_parser)

    args = my_parser.parse_args([])
    assert not args.become_ask_pass
    assert args.become_password_file is None

    args = my_parser.parse_args(["--ask-become-pass"])
    assert args.become_ask_pass is True
    assert args.become_password_file is None

    args = my_parser.parse_args(["--become-password-file", "/tmp/password"])
    assert not args.become_ask_pass
    assert args.become_password_file == "/tmp/password"




# Generated at 2022-06-22 18:44:23.378130
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(["-C"])
    assert args.check



# Generated at 2022-06-22 18:44:36.106368
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    '''
    >>> ap = argparse.ArgumentParser()
    >>> l = []
    >>> ap.add_argument('-a', action=PrependListAction, dest='l', nargs=2,
    ...                 help='an optional argument', default=l)
    >>> ns = ap.parse_args(args=['-a', '1', '2'])
    >>> print(ns.l)
    ['1', '2']
    >>> ns = ap.parse_args(args=['-a', '1', '2', '-a', '3', '4'])
    >>> print(ns.l)
    ['3', '4', '1', '2']
    >>> ns = ap.parse_args(args=[])
    >>> print(ns.l)
    []
    '''



# Generated at 2022-06-22 18:44:41.251904
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion(option_strings=['--version'], dest='version')
    parser = argparse.ArgumentParser(add_help=False)
    namespace = argparse.Namespace()
    action(parser, namespace, values=None, option_string=None)



# Generated at 2022-06-22 18:44:49.372148
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    fake_base = '/fake/base'
    fake_roles_path = '/fake/roles/path'
    path_finder_class = AnsibleOptions(base_path=fake_base, role_paths=[fake_roles_path])
    beacon = path_finder_class.get_option('beacon_path')
    assert maybe_unfrack_path(beacon)(beacon + '/fake/path') == beacon + fake_base + '/fake/path'


#
# Main class for organizing Option parsing
#

# Generated at 2022-06-22 18:44:55.642192
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    args = argparse.Namespace()
    # pylint: disable=unused-variable
    a1 = PrependListAction(option_strings=['-f'], dest='dest', nargs=1, const=1, default=None, type=None,
                              choices=None, required=False, help=None)
    # pylint: disable=unused-variable
    a2 = PrependListAction(option_strings=['-f'], dest='dest', nargs=1, const=None, default=None, type=None,
                              choices=None, required=False, help=None)
    a1(None, args, [0])
    assert args.dest == [0]
    a2(None, args, [1])
    assert args.dest == [1, 0]

# Generated at 2022-06-22 18:45:07.089304
# Unit test for function version

# Generated at 2022-06-22 18:45:14.064978
# Unit test for function add_output_options
def test_add_output_options():
    parser = Mock()
    add_output_options(parser)
    parser.add_argument.assert_has_calls([
        call('-o', '--one-line', dest='one_line', action='store_true',
             help='condense output'),
        call('-t', '--tree', dest='tree', default=None,
             help='log output to this directory'),
    ])



# Generated at 2022-06-22 18:45:16.983450
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test_prog")
    args = parser.parse_args("-v --version".split())
    assert args.verbosity == 1
    assert args.version is True


# Generated at 2022-06-22 18:45:26.573049
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    """
    Shows that exception is raised when an unexpected option argument
    is passed to the command line parser while the parser is in strict
    mode.
    """
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-U', action='store_const', const=True, dest='unrecognized', help='unrecognized argument')
    parser.add_argument('-s', action=UnrecognizedArgument, dest='spurious', help='spurious argument')
    with pytest.raises(SystemExit):
        parser.parse_args(['-U', '-s'])

#
# Core Options
#

# Generated at 2022-06-22 18:45:27.485280
# Unit test for function version
def test_version():
    assert isinstance(version(), basestring)

# Generated at 2022-06-22 18:45:29.945458
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='ansible-foo')
    assert parser.prog == 'ansible-foo'

#
# Functions to add pre-canned options to an OptionParser
#


# Generated at 2022-06-22 18:45:35.360756
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Verify that an exception is thrown if nargs is 0
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--foo', action=PrependListAction, nargs=0)
    except ValueError as e:
        assert "nargs for append actions must be > 0" == str(e)
    else:
        assert False



# Generated at 2022-06-22 18:45:43.934727
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args([])
    assert not args.become_ask_pass
    assert not args.become_password_file

    args = parser.parse_args(['-K'])
    assert args.become_ask_pass
    assert not args.become_password_file

    args = parser.parse_args(['--become-password-file', '/a/b/c'])
    assert not args.become_ask_pass
    assert args.become_password_file == '/a/b/c'



# Generated at 2022-06-22 18:45:49.052066
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    p.add_argument('--int', type=int, action=PrependListAction)
    p.add_argument('--list', type=int, action=PrependListAction, nargs=3)
    args = p.parse_args(['--int', '1', '--list', '1', '2', '3', '--int', '2'])
    assert args.int == [2, 1]
    assert args.list == [1, 2, 3]



# Generated at 2022-06-22 18:45:54.666303
# Unit test for function add_module_options
def test_add_module_options():
    """Test that -M and --module-path options are added correctly to the parser"""
    # Test setting module_path to the default value
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(args=[])
    assert options.module_path == C.DEFAULT_MODULE_PATH, \
        ("Default value for -M and --module-path is wrong: "
         "expected {}, got {}".format(C.DEFAULT_MODULE_PATH, options.module_path))
    # Test if module_path can be set from the command line
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    path = '/some/random/path'
    options = parser.parse_args(args=['-M', path])

# Generated at 2022-06-22 18:46:07.694084
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse


    class TestNamespace(object):
        pass


    testparser = argparse.ArgumentParser()


    testns = TestNamespace()
    testns.foo = ['bar']
    test_list = ['baz']
    testparser.add_argument('--foo', action='store')


    testparser.set_defaults(foo=['bar'])
    testaction = PrependListAction(option_strings=['--foo'],
                                   dest='foo',
                                   nargs=1,
                                   const='bar',
                                   default='bar',
                                   type=None,
                                   choices=None,
                                   help=None,
                                   metavar=None)
    testaction(testparser, testns, test_list, option_string='--foo')

# Generated at 2022-06-22 18:46:08.265860
# Unit test for function version
def test_version():
    assert not version() is None



# Generated at 2022-06-22 18:46:16.690933
# Unit test for function version
def test_version():
    assert version('ansible') == "ansible [core 2.9.3] (devel bf6b2d5813) last updated 2020/05/07 22:27:36 (GMT -0600)  config file = /etc/ansible/ansible.cfg  configured module search path = Default w/o overrides  ansible python module location = /usr/lib/python3.7/site-packages/ansible  ansible collection location = /usr/share/ansible/collections  executable location = /usr/bin/ansible  python version = 3.7.3 (default, Apr  3 2019, 05:39:12)  [GCC 8.3.0]  jinja version = 2.10.1  libyaml = True"

# Generated at 2022-06-22 18:46:23.048966
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    group = parser.add_argument_group('group')
    group.add_argument('-a', action='store_true')
    group.add_argument('-b', action='store_true')
    group.add_argument('-c', action='store_true')
    group.add_argument('-x', action='store_true')

    formatter = SortingHelpFormatter()
    help = parser.format_help()
    assert help == formatter.format_help()



# Generated at 2022-06-22 18:46:26.876620
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    print("Test for AnsibleVersion__call__")
    AnsibleVersion(option_strings='-T')


# Generated at 2022-06-22 18:46:38.444750
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog='asdf',
        formatter_class=SortingHelpFormatter,
        description="whatever",
        conflict_handler='resolve',
    )

    add_connect_options(parser)

    args = ['--user=root',
            '--connection=local',
            '--timeout=1',
            '--ssh-common-args=asdf',
            '--sftp-extra-args=asdf',
            '--scp-extra-args=asdf',
            '--ssh-extra-args=asdf',
            '-k',
            '--connection-password-file=asdf']

    parsed_args = parser.parse_args(args)
    assert parsed_args.remote_user == 'root'
    assert parsed_args.connection == 'local'


# Generated at 2022-06-22 18:46:45.363079
# Unit test for function add_subset_options
def test_add_subset_options():

    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    add_check_options(parser)
    add_module_options(parser)

    # test our defaults
    args = parser.parse_args([])
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP

    args = parser.parse_args([])
    assert args.check

    args = parser.parse_args([])
    assert args.module_path == ''

    args = parser.parse_args(['-M', './name'])
    assert args.module_path == './name'

    args = parser.parse_args(['-M', './name:./name2'])
    assert args.module_path == './name:./name2'



# Generated at 2022-06-22 18:46:50.024956
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='A test', conflict_handler="resolve")
    add_vault_options(parser)
    options = parser.parse_args(['--vault-password-file', 'unfrack'])
    assert options.vault_password_files == ['unfrack']

# Function to get the colored strings (if we are in a tty)

# Generated at 2022-06-22 18:46:52.742955
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.parse_args([])  # The parser should not throw an error



# Generated at 2022-06-22 18:47:04.442903
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    opt = add_inventory_options(parser)
    #parser.add_argument('-i', '--inventory', '--inventory-file', dest='inventory', action="append", help="specify inventory host path or comma separated host list. --inventory-file is deprecated")
    opt = add_inventory_options(parser)
    parser.parse_args(['--inventory', 'foo'])
    assert parser.parse_args(['--inventory', 'foo']).inventory == 'foo'
    parser.parse_args(['--inventory', 'bar'])
    assert parser.parse_args(['--inventory', 'bar']).inventory == 'bar'
    parser.parse_args(['-i', 'bar'])
    assert parser.parse_args(['-i', 'bar']).inventory == 'bar'


# Generated at 2022-06-22 18:47:06.592592
# Unit test for function create_base_parser
def test_create_base_parser():
    assert create_base_parser('ansible-config', 'Ansible Configuration tool')



# Generated at 2022-06-22 18:47:13.942714
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.cli.arguments import SortingHelpFormatter
    import os
    import sys
    import argparse
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runtask_options(parser)
    args = parser.parse_args(['-e','{"my_var": "my value"}'])
    assert (args.extra_vars[0].get('my_var') == "my value")



# Generated at 2022-06-22 18:47:23.656387
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():

    class arg(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super(arg, self).__init__(*args, **kwargs)
            self.epilog = "epilog"
            self.prog = "prog"

    # Create an instance of arg
    obj_arg = arg()

    # Create an instance of SortingHelpFormatter
    obj_SortingHelpFormatter = SortingHelpFormatter()

    # Create an instance of argparse.Namespace
    class argparse_Namespace(object):
        def __init__(self, **kwargs):
            super(argparse_Namespace, self).__init__()
            self.__dict__.update(kwargs)

    # Create an instance of argparse Action

# Generated at 2022-06-22 18:47:27.073304
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)


#
# Functions to parse arguments
#


# Generated at 2022-06-22 18:47:33.602758
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(["--private-key=/etc/foo/bar", "-u", "jenn", "-c", "smart", "-T", "300",
                                 "--ssh-common-args=foo", "--sftp-extra-args=bar", "--scp-extra-args=baz", "--ssh-extra-args=foobar",
                                 "-k", "--conn-pass-file=/etc/ansible/foo.txt"])
    assert options.private_key_file == "/etc/foo/bar"
    assert options.remote_user == "jenn"
    assert options.connection == "smart"
    assert options.timeout == 300
    assert options.ssh_common_args == "foo"

# Generated at 2022-06-22 18:47:34.632810
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='test')
    add_inventory_options(parser)
    # parser.parse_args()

# Generated at 2022-06-22 18:47:39.275804
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    add_fork_options(parser)
    options = parser.parse_args(['--forks', '-1'])
    assert options.forks == 0



# Generated at 2022-06-22 18:47:46.664693
# Unit test for function add_module_options
def test_add_module_options():
    module_path = C.config.get_configuration_definition('DEFAULT_MODULE_PATH').get('default', '')
    parser = Mock()
    add_module_options(parser)
    assert parser.add_argument.call_args_list[1][0][0] == '-M'
    assert parser.add_argument.call_args_list[1][1]['nargs'] == '?'
    assert parser.add_argument.call_args_list[1][1]['default'] == None
    assert parser.add_argument.call_args_list[1][1]['help'] == "prepend colon-separated path(s) to module library (default=%s)" % module_path


# Generated at 2022-06-22 18:47:48.929316
# Unit test for function add_subset_options
def test_add_subset_options():
    assert add_subset_options('') == ''



# Generated at 2022-06-22 18:47:54.410891
# Unit test for function add_output_options
def test_add_output_options():
    ansible_output_options = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        prog='test_prog',
    )
    add_output_options(ansible_output_options)
# Test case for function add_output_options

# Generated at 2022-06-22 18:47:56.308206
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    c = AnsibleVersion()
    c.__call__('', '', '', '')
    assert True



# Generated at 2022-06-22 18:48:01.870918
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog="test_add_tasknoplay_options")
    add_tasknoplay_options(parser)
    options = parser.parse_args(["--task-timeout=42"])
    assert options.task_timeout == "42"
    options = parser.parse_args([])
    assert options.task_timeout == "60"



# Generated at 2022-06-22 18:48:14.256200
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='test',
                                usage="testing",
                                desc="this is only a test",
                                epilog="testing is complete")
    assert isinstance(parser, argparse.ArgumentParser)
    assert parser._actions[0].default == version
    assert parser._actions[0].help == "show program's version number, config file location, configured module search path," \
                                      " module location, executable location and exit"
    assert parser._actions[1].default == False
    assert parser._actions[1].dest == 'v'
    assert parser._actions[1].help == "verbose mode (-v, -vv, -vvv, etc)"
    assert parser._actions[1].const == 1
    assert parser._actions[1].nargs == '?'
    assert parser._actions[2].default

# Generated at 2022-06-22 18:48:17.836035
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    UnrecognizedArgument(option_strings='-s, --string', dest='string', const=True, default=None, required=False, help='help', metavar='var')(None, None, None, option_string='-s')

#
# Options Parser factories
#

# Generated at 2022-06-22 18:48:22.487474
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from unittest.mock import Mock, patch, call
    parser = Mock()
    runas_group = Mock()
    parser.add_argument_group.return_value = runas_group
    add_runas_prompt_options(parser, runas_group)
    parser.add_argument_group.assert_called_with(runas_group)
    parser.add_mutually_exclusive_group.assert_called_once_with()

# Generated at 2022-06-22 18:48:26.975097
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_verbosity_options(parser)
    options = parser.parse_args(['-vv'])
    assert options.verbosity == 2

