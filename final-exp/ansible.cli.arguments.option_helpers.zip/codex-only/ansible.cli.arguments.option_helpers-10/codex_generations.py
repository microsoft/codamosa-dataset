

# Generated at 2022-06-22 18:38:28.329253
# Unit test for function create_base_parser
def test_create_base_parser():
    assert create_base_parser('', epilog='', desc='')


# Generated at 2022-06-22 18:38:39.514836
# Unit test for constructor of class PrependListAction

# Generated at 2022-06-22 18:38:40.087350
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-22 18:38:48.132802
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(description="Add options for commands which need to connection to other hosts")
    add_connect_options(parser)

# Generated at 2022-06-22 18:38:51.072967
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    # Set arguments
    args = parser.parse_args(['-e', 'key1=value1'])
    assert args.extra_vars == ['key1=value1']
    args = parser.parse_args(['-e', '@/tmp/foo.yaml'])
    assert args.extra_vars == ['/tmp/foo.yaml']


# Generated at 2022-06-22 18:38:55.600809
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print(AnsibleVersion().__call__(None, None, None, None))


# Generated at 2022-06-22 18:39:00.600941
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()
    add_inventory_options(parser)
    assert parser.add_argument.call_count == 3
    parser = Mock()
    add_inventory_options(parser)
    assert parser.add_argument.call_count == 3


# Generated at 2022-06-22 18:39:09.479467
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from unittest import mock
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext

    cli = CLI()
    pc = PlayContext()
    cli._play_context = pc

    # Test case 1:
    # Test when self.nargs is arg_parse.OPTIONAL, self.const is not None,
    # self.default is None
    action = PrependListAction(
        ['--tags'],
        'tags',
        nargs=argparse.OPTIONAL,
        const=['all'],
        default=None,
    )
    parser = mock.MagicMock()
    namespace = mock.MagicMock()
    values = ['jenkins']
    option_string = '--tags'
    action(parser, namespace, values, option_string)
   

# Generated at 2022-06-22 18:39:17.362593
# Unit test for function unfrack_path
def test_unfrack_path():
    # if we don't use share/ansible with all the other paths, the tests
    # in lib/ansible/module_utils cause "cannot import module" errors.
    allpaths = C.DEFAULT_ROLES_PATH + os.path.pathsep + C.DEFAULT_MODULE_PATH + os.path.pathsep + C.DEFAULT_MODULE_UTILS_PATH
    testpaths = [
        ('/etc/ansible', '/etc/ansible'),
        ('/etc/ansible:' + allpaths, ['/etc/ansible'] + allpaths.split(os.pathsep)),
        ('/etc/ansible:~/myansible', ['/etc/ansible', os.path.expanduser('~/myansible')]),
    ]


# Generated at 2022-06-22 18:39:19.174920
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = vars(parser.parse_args(["-M", "/tmp/1:/tmp/2"]))
    assert args['module_path'] == ['/tmp/1', '/tmp/2']



# Generated at 2022-06-22 18:39:23.578378
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace():
        def __init__(self):
            pass
    x = Namespace()
    y = ensure_value(x, 'foo', [])
    assert y is not None
    assert x.foo is not None
    assert y == x.foo


#
# Common base parser for all cli tools
#

# Generated at 2022-06-22 18:39:31.471422
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)('$HOME') == [os.path.expanduser('~')]
    assert unfrack_path(True)('/media/sdlkfj/WeirdlyFormattedPath') == ['/media/sdlkfj/WeirdlyFormattedPath']
    assert unfrack_path(False)('$HOME/foo/../bar') == os.path.expanduser('~/bar')
    assert unfrack_path(False)('/media/sdlkfj/WeirdlyFormattedPath') == '/media/sdlkfj/WeirdlyFormattedPath'
test_unfrack_path()



# Generated at 2022-06-22 18:39:35.689646
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser('test')
    parser.add_argument('--prepend', action=PrependListAction, default=[])
    args = parser.parse_args(['--prepend', '1', '--prepend', '2'])
    assert args.prepend == ['2', '1']


# Generated at 2022-06-22 18:39:43.546584
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser('ansible')
    options = parser.parse_args()
    assert options.verbosity == C.DEFAULT_VERBOSITY
    # simple verbosity
    args = ['-v']
    options = parser.parse_args(args)
    assert options.verbosity == 1
    # multiple verbosity
    args = ['-vvvv']
    options = parser.parse_args(args)
    assert options.verbosity == 4


# Generated at 2022-06-22 18:39:48.263557
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ''' test the constructor of the class AnsibleVersion '''
    ansible_version = AnsibleVersion(option_strings='--version', dest='count')



# Generated at 2022-06-22 18:39:58.449767
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    # I'm not sure if this is a bug in the argparse module, but I don't think the
    # mutually exclusive groups can has --help as a parameter.
    for action in parser._actions:
        if type(action) == argparse._MutuallyExclusiveGroup:
            for child_action in action._group_actions:
                if child_action.dest == 'help' and type(child_action) == argparse._HelpAction:
                    action._group_actions.remove(child_action)
                    break

    # Here we go!

# Generated at 2022-06-22 18:40:04.611970
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'test_name', 'test_value')
    assert getattr(namespace, 'test_name') == 'test_value'
    ensure_value(namespace, 'test_none', None)
    assert getattr(namespace, 'test_none') is None
    ensure_value(namespace, 'test_empty', [])
    assert getattr(namespace, 'test_empty') == []



# Generated at 2022-06-22 18:40:07.969070
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    parser.parse_args(args=['--version'])


# Generated at 2022-06-22 18:40:11.185035
# Unit test for function add_subset_options
def test_add_subset_options():
    options_parser = argparse.ArgumentParser(
        prog='ansible-runner',
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_subset_options(options_parser)
    args = options_parser.parse_args()
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP
    assert args.tags_file == C.TAGS_FILE
    assert args.skip_tags_file == C.SKIP_TAGS_FILE



# Generated at 2022-06-22 18:40:14.450977
# Unit test for function add_runtask_options
def test_add_runtask_options():
    # Create a parser to check that args are added correctly.
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)

    # Try adding args to the parser.
    options = parser.parse_args(['-e', '@abc.yml', '-e', 'abc.json'])
    # Make sure that paths with extension .yml or .json are unfracked.
    assert options.extra_vars == [maybe_unfrack_path('@')('@abc.yml'), maybe_unfrack_path('@')('abc.json')]



# Generated at 2022-06-22 18:40:19.611091
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = Mock()
    add_tasknoplay_options(parser)
    assert (
        parser.add_argument.call_args_list ==
        [call('--task-timeout', type=int, dest='task_timeout', action='store', default=C.TASK_TIMEOUT, help='set task timeout limit in seconds, must be positive integer.')]
    )



# Generated at 2022-06-22 18:40:25.368707
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    assert parser._option_string_actions.get('--inventory') is not None
    assert parser._option_string_actions.get('--inventory-file') is not None
    assert parser._option_string_actions.get('--list-hosts') is not None
    assert parser._option_string_actions.get('-l') is not None


# Generated at 2022-06-22 18:40:29.917192
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(prog='test_UnrecognizedArgument')
    parser.add_argument('--test', action=UnrecognizedArgument)
    parsed, extra = parser.parse_known_args(['--test', 'arg1', 'arg2'])
    assert len(extra) == 2
    assert extra[0] == 'arg1'
    assert extra[1] == 'arg2'



# Generated at 2022-06-22 18:40:37.929465
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    p.add_argument('--foo', action=PrependListAction)
    p.add_argument('--bar', action=PrependListAction)
    arg_pattern = ['--foo', 'foo', '--bar', 'bar']
    options = p.parse_args(arg_pattern)

    assert options.foo == ['foo']
    assert options.bar == ['bar']


#
# parser helper functions
#

# Generated at 2022-06-22 18:40:39.217918
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    assert parser.get_default('extra_vars') == []


# Generated at 2022-06-22 18:40:45.706407
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter, conflict_handler='resolve',)
    add_output_options(parser)
    (options, args) = parser.parse_known_args(['-o', '-t', 'test'])
    assert options.one_line == True
    assert options.tree == 'test'



# Generated at 2022-06-22 18:40:49.610539
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'first', '-t', 'second', '--skip-tags', 'third', '--skip-tags', 'fourth'])
    assert options.tags == ['first', 'second']
    assert options.skip_tags == ['third', 'fourth']


#
# DEPRECATED:  use sanitize_jinja_template_string directly
#

# Generated at 2022-06-22 18:40:51.539569
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
  import argparse
  parser=argparse.ArgumentParser()
  add_tasknoplay_options(parser)
  options_dict=vars(parser.parse_args(['--task-timeout','10']))
  assert options_dict['task_timeout']==10


# Generated at 2022-06-22 18:41:01.913106
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--append', nargs='+', action=PrependListAction)
    parser.add_argument('-b', '--append-const', action=PrependListAction, const='foo', nargs='?')
    parser.add_argument('-c', '--append-const-single', action=PrependListAction, const='foo')

    with pytest.raises(ValueError):
        parser.parse_args('-a 1 2 3 -b'.split())
    with pytest.raises(ValueError):
        parser.parse_args('-a 1 2 3 -b 1'.split())
    with pytest.raises(ValueError):
        parser.parse_args('-c 1 2'.split())

# Generated at 2022-06-22 18:41:10.037131
# Unit test for function ensure_value
def test_ensure_value():
    import unittest.mock
    c = unittest.mock.MagicMock()
    ensure_value(c, 'x', 42)
    c.x = 10
    ensure_value(c, 'x', 42)
    c.y = None
    ensure_value(c, 'y', 42)
    c.assert_has_calls([unittest.mock.call.x, unittest.mock.call.y], any_order=True)



# Generated at 2022-06-22 18:41:11.387221
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(args=[])
    assert args.forks == C.DEFAULT_FORKS



# Generated at 2022-06-22 18:41:12.882020
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = vars(parser.parse_args([]))
    assert args['task_timeout'] == C.TASK_TIMEOUT



# Generated at 2022-06-22 18:41:25.075030
# Unit test for function add_vault_options
def test_add_vault_options():
    from ansible_test.unit.test_loader import TestLoader
    from ansible_test.unit.test_utils import TestUtils

    from ansible.cli.arguments import add_vault_options

    parser = argparse.ArgumentParser()
    vault_group = parser.add_mutually_exclusive_group()
    add_vault_options(parser)
    TestUtils.assert_equals(True, '--vault-id' in parser.format_help())
    TestUtils.assert_equals(True, '--ask-vault-password' in parser.format_help())
    TestUtils.assert_equals(True, '--vault-password-file' in parser.format_help())

# Generated at 2022-06-22 18:41:31.549898
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # initialize a parser
    parser = argparse.ArgumentParser()
    # add argument "--version"
    parser.add_argument('--version', action=AnsibleVersion)
    # simulate that program was called with "--version" from command line
    command_line = ['--version']
    names = parser.parse_args(command_line)
    # check that Ansible version is printed
    assert ansible.__version__ == ansible.__version__
    # check that parser exits
    assert sys.exit() == None

# Generated at 2022-06-22 18:41:32.098720
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass


# Generated at 2022-06-22 18:41:35.576156
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '-D'])
    assert args.check
    assert args.diff


# Generated at 2022-06-22 18:41:39.900650
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['-C', '-D'])
    assert options.check
    assert options.diff
    assert not options.syntax


# Generated at 2022-06-22 18:41:46.126354
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers()
    play_parser = subparsers.add_parser('ansible-playbook')
    play_parser.prog = 'ansible-playbook'
    AnsibleVersion(option_strings=('--version', '-v'))(parser, None, None)



# Generated at 2022-06-22 18:41:49.187896
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='test')
    add_fork_options(parser)
    options = parser.parse_args(['-f', 4])
    assert options.forks == 4


# Generated at 2022-06-22 18:41:56.589830
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()

    # Test the runas_group
    runas_group = parser.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")
    # consolidated privilege escalation (become)
    runas_group.add_argument("-b", "--become", default=C.DEFAULT_BECOME, action="store_true", dest='become',
                             help="run operations with become (does not imply password prompting)")

# Generated at 2022-06-22 18:42:08.425655
# Unit test for function add_runtask_options
def test_add_runtask_options():
    """Validate if the extra-vars has filename prepend with @ and the test if the file exists"""

    test_filename = 'test.yaml'
    test_parser = argparse.ArgumentParser(
        epilog=None,
        description="",
        usage='%(prog)s [options]',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
        add_help=False
    )
    add_runtask_options(test_parser)
    args, _ = test_parser.parse_known_args(['--extra-vars', '@'+test_filename])

    # Assert the path is prepended with @.
    assert args.extra_vars, '@'+test_filename
    # Assert the file is exist.
    assert os.path

# Generated at 2022-06-22 18:42:12.255665
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', '~/directory1:~/directory2'])
    assert options.module_path == ['/home/vagrant/directory1', '/home/vagrant/directory2']



# Generated at 2022-06-22 18:42:17.853746
# Unit test for function version
def test_version():
    # Load a version string from the version file
    version_file = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'VERSION'))
    version_string = open(version_file).read()

    assert __version__ == version_string.strip()
    assert version() == version('')



# Generated at 2022-06-22 18:42:21.471104
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    args = '--list-option a --list-option b c'.split()

    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('--list-option', action=PrependListAction)

    options = test_parser.parse_args(args)
    assert options.list_option == ['c', 'b', 'a']



# Generated at 2022-06-22 18:42:27.952101
# Unit test for function add_fork_options
def test_add_fork_options(): 
    parser = argparse.ArgumentParser(prog="test_add_fork_options", description="Testing description")
    add_fork_options(parser)
    args = parser.parse_args(args=["-f", "10"])
    assert args.forks == 10
    args = parser.parse_args(args=["--forks", "10"])
    assert args.forks == 10


# Generated at 2022-06-22 18:42:31.556210
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    add_verbosity_options(parser)
    args = parser.parse_args(['-f', '2', '-vvv'])
    assert args.verbosity == 3
    assert args.forks == 2


# Generated at 2022-06-22 18:42:40.090237
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args([])
    assert options.verbosity == 0
    options = parser.parse_args(['--verbose'])
    assert options.verbosity == 1
    options = parser.parse_args(['-v'])
    assert options.verbosity == 1
    options = parser.parse_args(['-vv'])
    assert options.verbosity == 2
    options = parser.parse_args(['-vvv'])
    assert options.verbosity == 3



# Generated at 2022-06-22 18:42:48.934210
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    epilog = 'example epilog'

    sut = SortingHelpFormatter()
    parser = argparse.ArgumentParser(formatter_class=sut, epilog=epilog)
    parser.add_argument('-x')
    parser.add_argument('-z')
    parser.add_argument('-y')

    help_output = parser.format_help()
    assert help_output.endswith(epilog)
    # the various argparse help_outputs vary slightly across python versions,
    # so just the general order of -x, -y and -z lines is being checked
    # rather than trying to ensure the exact ordering of each line
    assert help_output.find('-x') < help_output.find('-y')
    assert help_output.find('-y') < help_output

# Generated at 2022-06-22 18:42:50.340138
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert parser.format_help() is not None



# Generated at 2022-06-22 18:42:53.283229
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser('test')
    add_meta_options(parser)
    options = parser.parse_args(['--flush-cache'])
    assert options.flush_cache == True


# Generated at 2022-06-22 18:42:55.884463
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options, args = parser.parse_known_args()
    assert options.one_line is None
    assert options.tree is None

    options, args = parser.parse_known_args(['-o', '-t', 'log'])
    assert options.one_line == True
    assert options.tree == os.path.realpath('log')



# Generated at 2022-06-22 18:43:07.507812
# Unit test for function create_base_parser
def test_create_base_parser():
    # Use the module to ensure coverage
    from ansible.cli import CLI

    p = create_base_parser(prog='test')
    assert p is not None

    options = p.parse_args(['--version'])
    assert options is not None

    p = create_base_parser(prog='test')
    options = p.parse_args(['-v'])
    assert options.verbosity == 1

    p = create_base_parser(prog='test')
    options = p.parse_args(['-vv'])
    assert options.verbosity == 2

    p = create_base_parser(prog='test')
    options = p.parse_args(['-vvvvvvvvvvvvvvvvvvvvvv'])
    assert options.verbosity == 20

    # p = create_base_parser(

# Generated at 2022-06-22 18:43:19.145908
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # example:
    # python3.6 test-module.py -m ./library/my_module -a "url='https://localhost/' username=myuser password='mypassword'" -i 127.0.0.1,192.168.0.3
    # python3.6 test-module.py -m ./library/my_module -a "url='https://localhost/' username=myuser password='mypassword'" -i 127.0.0.1,192.168.0.3
    parser = create_base_parser('test-module.py')
    add_inventory_options(parser)

# Generated at 2022-06-22 18:43:28.014939
# Unit test for function add_subset_options
def test_add_subset_options():
    """Unit test for function add_subset_options"""
    opts = MockOpts()
    parser = MockParser()

    add_subset_options(parser)

    opts.tags = ['test_tag']
    opts.skip_tags = ['test_skip_tag']

    args = ['--tags', 'test_tag', '--skip-tags', 'test_skip_tag']
    _ = parser.parse_args(args, opts)

    assert opts.tags == ['test_tag']
    assert opts.skip_tags == ['test_skip_tag']

    opts2 = MockOpts()
    parser2 = MockParser()
    add_subset_options(parser2)

    opts2.tags = ['test_tag', 'test_tag']


# Generated at 2022-06-22 18:43:32.815778
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(description='sample program')
    add_fork_options(parser)
    args = parser.parse_args(['-f', '5'])
    assert args.forks == 5



# Generated at 2022-06-22 18:43:41.051107
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.constants import DEFAULT_LOCAL_TMP, DEFAULT_REMOTE_TMP
    # Test for unfrack_path when pathsep=False
    assert unfrack_path(pathsep=False)("") == ""
    assert unfrack_path(pathsep=False)("." + os.pathsep) == "."
    assert unfrack_path(pathsep=False)("~/foo") == os.path.expanduser("~/foo")
    assert unfrack_path(pathsep=False)("/var/tmp/bar") == "/var/tmp/bar"
    assert unfrack_path(pathsep=False)("$HOME") == os.getenv("HOME")

# Generated at 2022-06-22 18:43:49.919962
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    class MyParser(argparse.ArgumentParser):
        def error(self, message):
            self.error_called = True
            self.message = message

    p = MyParser(add_help=False)
    p.add_argument('--foo', action=UnrecognizedArgument)
    try:
        p.parse_args(['--foo', 'bar'])
    except SystemExit:
        pass
    assert p.error_called
    assert p.message == 'unrecognized arguments: --foo'


#
# Options that correspond to the command line options in ansible-playbook
#

# Generated at 2022-06-22 18:43:57.790440
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # Just make sure the constructor doesn't throw an exception
    UnrecognizedArgument(option_strings='--test-argument', dest='test_argument')

#
# BasicOptionParser is a simple extension of the Python OptionParser class
# which adds a few Ansible-specific features:
#
# 1.  It lets plugins register their own command line options.
# 2.  It ensures that plugin options are always properly namespaced.
# 3.  It automatically generates --version and --help options.
#

# Generated at 2022-06-22 18:44:01.850213
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    options = argparse.Namespace()
    os.environ['ANSIBLE_VERSION_CHECK'] = 'True'
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', action=AnsibleVersion, default=options)
    options, remaining_args = parser.parse_known_args()


# Generated at 2022-06-22 18:44:13.443932
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Create an action with a non-optional positional argument
    assert sys.exc_info()[1] == None
    try:
        PrependListAction('--foo', 'action', nargs=0)
    except ValueError as e:
        assert str(e) == 'nargs for append actions must be > 0; if arg strings are not supplying the value to append, the append const action may be more appropriate'
    # Create an action with a required positional argument, but with an 'optional' const
    assert sys.exc_info()[1] == None

# Generated at 2022-06-22 18:44:18.412849
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    p = argparse.ArgumentParser(description="test_argparse")
    p.add_argument("foo", action=AnsibleVersion, help="A test case", nargs=0)

    # Unit test: check the integrity of class AnsibleVersion
    # AssertionError: usage: test_argparse [-h] foo
    # test_argparse: error: argument foo: no such option: --foo
    p.parse_args()

    # Unit test: check if the print output is expected.
    # AssertionError: AssertionError not raised
    try:
        p.parse_args("--version".split())
    except AssertionError:
        pass
    else:
        raise AssertionError("AssertionError not raised")



# Generated at 2022-06-22 18:44:22.499762
# Unit test for function add_inventory_options
def test_add_inventory_options():
    """
    Unit test for function add_inventory_options
    """
    parser=argparse.ArgumentParser()
    add_inventory_options(parser)
    args=parser.parse_args(["--inventory=HELLO"])
    assert args.inventory==["HELLO"]



# Generated at 2022-06-22 18:44:35.421858
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Parser for testing
    parser = argparse.ArgumentParser()
    # Check that version string is in the format:
    # ansible 2.2.0.0
    #  config file = /etc/ansible/ansible.cfg
    #  configured module search path = [u'/usr/share/ansible']
    #  ansible python module location = /usr/lib/python2.7/site-packages/ansible
    #  executable location = /usr/bin/ansible
    #  python version = 2.7.5 (default, Aug  4 2017, 00:39:18) [GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]
    #
    #  Current version of Ansible: 2.2.0.0
    #  Latest version of Ansible available: 2.2

# Generated at 2022-06-22 18:44:37.932897
# Unit test for function add_meta_options
def test_add_meta_options():
    add_meta_options(argparse.ArgumentParser())



# Generated at 2022-06-22 18:44:42.847861
# Unit test for function add_basedir_options
def test_add_basedir_options():
    basedir_options_dict = {}
    for key in add_basedir_options.__code__.co_varnames:
        basedir_options_dict[key] = None
    return basedir_options_dict


# Generated at 2022-06-22 18:44:47.007508
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    class Args:
        task_timeout = None
    args = Args()
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args([], args)
    assert args.task_timeout == C.TASK_TIMEOUT


# Generated at 2022-06-22 18:44:48.933987
# Unit test for function version
def test_version():
    assert version('foo').startswith('foo')

# Generated at 2022-06-22 18:44:53.195089
# Unit test for function add_check_options
def test_add_check_options():
    parser=argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args('-C --check -D --diff'.split())
    assert args.check == True
    assert args.syntax == False
    assert args.diff == True

# Generated at 2022-06-22 18:44:58.220330
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path('/usr/share/ansible:/etc/ansible') == '/usr/share/ansible:/etc/ansible'
    assert unfrack_path(True)('/usr/share/ansible') == ['/usr/share/ansible']
    assert unfrack_path(True)('/usr/share/ansible:/etc/ansible') == ['/usr/share/ansible', '/etc/ansible']


# Generated at 2022-06-22 18:45:03.820844
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfrack_path_test = maybe_unfrack_path("@")
    assert unfrack_path_test("@/foo/bar") == "/foo/bar"
    assert unfrack_path_test("@foo/bar") == "@foo/bar"


#
# Base Options Parsers
#

# Generated at 2022-06-22 18:45:09.891902
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfrack_beacon = '@'
    assert maybe_unfrack_path(unfrack_beacon)(unfrack_beacon + 'foo' + os.path.sep + 'bar') == unfrack_beacon + os.path.join('foo', 'bar')
    assert maybe_unfrack_path(unfrack_beacon)(unfrack_beacon + 'foo') == unfrack_beacon + 'foo'
    assert maybe_unfrack_path(unfrack_beacon)('baz') == 'baz'


#
# Global Options parsers
#

# Generated at 2022-06-22 18:45:12.823349
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog="ansible", formatter_class=SortingHelpFormatter)
    test_command = '/usr/local/bin/ansible '
    add_module_options(parser)
    args = parser.parse_args(test_command.split())
    assert args.module_path == ''



# Generated at 2022-06-22 18:45:23.033971
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    actions = [
        argparse.Action(option_strings=['--f'], dest='foo'),
        argparse.Action(option_strings=['--a'], dest='bar'),
        argparse.Action(option_strings=['--c'], dest='baz'),
    ]
    formatter = SortingHelpFormatter(prog='program')
    expected_help = '  --a BAR                                                                                                                                                                 \n  --c BAZ                                                                                                                                                                 \n  --f FOO                                                                                                                                                                 '
    assert expected_help == formatter.format_help(actions)


#
# Subcommand parsers and shared option parser
#

# Generated at 2022-06-22 18:45:31.607247
# Unit test for function version
def test_version():
    def _test_version(prog, exp_0, exp_1):
        ver = version(prog)
        assert ver[0].startswith(exp_0)
        assert ver[1].startswith('  config file')
        assert ver[2].startswith('  configured module search path')
        assert ver[3].startswith('  ansible python module location')
        assert ver[4].startswith('  ansible collection location')
        assert ver[5].startswith('  executable location')
        if exp_1:
            assert ver.splitlines()[0].endswith(exp_1)
        else:
            assert ver.splitlines()[0].endswith(exp_0)

    _test_version('prog', 'prog [core X.Y.Z]', '')
   

# Generated at 2022-06-22 18:45:35.152512
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    test = UnrecognizedArgument(['--foo', '-f'], dest='boo')
    assert isinstance(test, UnrecognizedArgument)



# Generated at 2022-06-22 18:45:46.357975
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parsed, _ = parser.parse_known_args(['--vault-password-file', 'test', '--ask-vault-password'])
    assert 'test' in parsed.vault_password_files
    assert parsed.ask_vault_pass
    parsed, _ = parser.parse_known_args(['--vault-password-file', 'test', '--vault-password-file', 'test2'])
    assert 'test2' in parsed.vault_password_files
    assert parsed.vault_password_files[0] == 'test'
    parsed, _ = parser.parse_known_args(['--ask-vault-password', '--vault-password-file', 'test'])
    assert 'test'

# Generated at 2022-06-22 18:45:56.847095
# Unit test for function unfrack_path
def test_unfrack_path():
    # pylint: disable=too-many-locals
    # Create original path
    origpath = '/home/jdoe/ansible/roles/test/'
    # Create test paths that are added to ANSIBLE_ROLES_PATH
    testpath1 = './'
    testpath2 = '/home/jdoe/ansible/roles/'
    testpath3 = '/home/jdoe/ansible/roles/other/'
    testpath4 = '../'
    testpath5 = '/home/jdoe/ansible/roles/other/../test/'
    testpath6 = '/home/jdoe/ansible/roles/other/../../../test/'
    # Prepend original path to front of list
    testpath = [origpath]
    # Add test paths to

# Generated at 2022-06-22 18:46:00.954840
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    arg_line = parser.format_help()
    assert '-vvvv' in arg_line
    assert '--verbose' in arg_line



# Generated at 2022-06-22 18:46:10.557713
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from argparse import ArgumentParser
    # Test that command line option are added
    parser = ArgumentParser()
    add_runas_prompt_options(parser)
    parser.parse_args(["-K"])
    parser.parse_args(["--ask-become-pass"])
    parser.parse_args(["--become-password-file", "file"])
    parser.parse_args(["--become-pass-file", "file"])
    # Test that already defined options are not added
    exception_string = "argument -K: conflicting option string(s): --ask-become-pass"

# Generated at 2022-06-22 18:46:21.217579
# Unit test for function add_runas_options
def test_add_runas_options():
    import argparse
    parser = argparse.ArgumentParser(description="become unit tests")
    add_runas_options(parser)
    # Just checking for no exceptions here.  None of the options take a value, so checking
    # that the parser correctly parses them is not really feasible.
    testargs = ['-b', '--become-user', 'test', '--become-method', 'test', '--ask-become-pass']
    args = parser.parse_args(testargs)
    assert args.become
    assert args.become_user == 'test'
    assert args.become_method == 'test'
    assert args.ask_become_pass



# Generated at 2022-06-22 18:46:32.110480
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_subset_options(parser)
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_subset_options(parser)
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_subset_options(parser)
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_subset_options(parser)



# Generated at 2022-06-22 18:46:41.704478
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-x', action=UnrecognizedArgument, help='some help')
    parser.parse_args(['-x'])
# Not sure how to unit test this...
#def test_UnrecognizedArgument___call___with_error():
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-x', action=UnrecognizedArgument, help='some help')
#    parser.parse_args(['-y'])


#
# Globals
#

# constants for extra verbosity levels
VERBOSITY_0 = 0
VERBOSITY_1 = 1
VERBOSITY_2 = 2
VERBOSITY_3 = 3

# common command line argument configurations
version_base_parser = argparse.Argument

# Generated at 2022-06-22 18:46:44.703036
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', '@prompt'])
    assert options.vault_ids == ['@prompt']
    # options = parser.parse_args(['--vault-password-file', '/path/.vault_pass.txt'])
    # assert options.vault_password_files == '/path/.vault_pass.txt'



# Generated at 2022-06-22 18:46:53.056188
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(["--playbook-dir", "foo"])
    assert args.basedir == "foo"
    assert args.playbook_dir == "foo"
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args([])
    assert hasattr(args, "basedir")
    assert args.basedir is None
    assert args.playbook_dir is None



# Generated at 2022-06-22 18:47:00.446545
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-z')
    parser.add_argument('-a')
    parser.add_argument('--ccc')
    parser.add_argument('--bbb')
    parser.add_argument('--aaa')
    parser.print_help()
    assert parser.format_help() == """usage: prog [-h] [-a] [-z] [--aaa AAA] [--bbb BBB] [--ccc CCC]

optional arguments:
  -h, --help   show this help message and exit
  -a
  -z
  --aaa AAA
  --bbb BBB
  --ccc CCC
""".strip()
#

# Generated at 2022-06-22 18:47:04.329407
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    argparse.UnrecognizedArgument('unknown', 'dest', const=True, default=None, required=False, help='test', metavar=None, nargs=0)


# Generated at 2022-06-22 18:47:09.626971
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert args.one_line

    args = parser.parse_args(['-t', '/tmp'])
    assert args.tree == '/tmp'


# Generated at 2022-06-22 18:47:10.367204
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    pass

# Generated at 2022-06-22 18:47:13.744275
# Unit test for function add_connect_options
def test_add_connect_options():
    fake_parser = argparse.ArgumentParser()
    add_connect_options(fake_parser)

# Generated at 2022-06-22 18:47:23.503263
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('foo')
    assert parser is not None
    assert parser.usage == ''
    assert parser.description is None
    assert parser.epilog is None
    assert parser.prog == 'foo'
    assert parser.formatter_class == SortingHelpFormatter
    assert parser._conflict_handler == 'resolve'
    assert parser._actions[0].dest == 'version'
    assert parser._actions[0].option_strings == ['--version']
    assert parser._actions[0].const is None
    assert parser._actions[0].default is None
    assert parser._actions[0].required is False
    assert parser._actions[0].nargs == 0
    assert parser._actions[0].help == "show program's version number, config file location, configured module search path, module location, executable location and exit"

# Generated at 2022-06-22 18:47:30.057032
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(add_help=False)

    values = ['-a', 'foo', '-b', 'bar']
    parser.add_argument('-a', action=UnrecognizedArgument)
    parser.add_argument('-b')
    opts = parser.parse_args(values)

    assert opts.b == 'bar'
    # TODO: this is only caught in UnrecognizedArgument and not by ArgumentParser as it should be
    # assert opts.a == 'foo'

#
# Main entry points
#

# Generated at 2022-06-22 18:47:41.434798
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'foo_bar', [])
    assert(namespace.foo_bar == [])
    ensure_value(namespace, 'foo_bar', [1])
    assert(namespace.foo_bar == [])
    ensure_value(namespace, 'foo_bar2', [2])
    assert(namespace.foo_bar2 == [2])
    ensure_value(namespace, 'foo_bar2', [3])
    assert(namespace.foo_bar2 == [2])
    # cleanup
    delattr(namespace, 'foo_bar')
    delattr(namespace, 'foo_bar2')

#
# Parser and options
#

# Generated at 2022-06-22 18:47:47.140348
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    """
    Unit test for constructor of class UnrecognizedArgument
    """
    from ansible.cli import CLI
    my_cli = CLI()
    my_parser = my_cli.get_base_parser()
    # Option string can be only -y or --yes
    my_parser.add_argument('--yes', action=UnrecognizedArgument, help='Be yes!', default=True)
    # Option string can be only -n or --no
    my_parser.add_argument('--no', action=UnrecognizedArgument, help='Be no!', default=False)



# Generated at 2022-06-22 18:47:48.823413
# Unit test for function version
def test_version():
    assert version('ansible') is not None



# Generated at 2022-06-22 18:47:54.060799
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument = mock.MagicMock()
    action = AnsibleVersion(option_strings="--version")
    action(parser, None, None, "--version")
    assert parser.add_argument.call_count == 1



# Generated at 2022-06-22 18:47:57.754224
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test1', action=UnrecognizedArgument, help='my help')
    try:
        options = parser.parse_args(['--test1'])
    except SystemExit as e:
        return
    assert False, 'SystemExit not raised'


#
# Utilities
#

# Generated at 2022-06-22 18:48:06.262077
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', 'test=test'])
    assert options.extra_vars == ['test=test']
    # In parsing json/yaml, quotes are not expect for single valued integer types, but some shells (like bash) may
    # add quotes to the argument passed to ansible-playbook (like ansible-playbook '-e {"test": 10}').
    options = parser.parse_args(['-e', '{"test": 10}'])
    assert options.extra_vars == [{'test': 10}]
    options = parser.parse_args(['-e', '["test"]'])
    assert options.extra_vars == [['test']]
    # Invalid json should be passed

# Generated at 2022-06-22 18:48:11.170554
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path('b')('b/foo') == 'b/foo')
    assert(maybe_unfrack_path('b')('b/bar/') == 'b/bar')
    assert(maybe_unfrack_path('b')('c/foo') == 'c/foo')



# Generated at 2022-06-22 18:48:15.637718
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    parsed = parser.parse_args(['--force-handlers','--flush-cache'])
    assert parsed.force_handlers == True
    assert parsed.flush_cache == True



# Generated at 2022-06-22 18:48:22.242498
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args([])
    assert args.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert args.flush_cache == False
    args = parser.parse_args(["--force-handlers"])
    assert args.force_handlers == True
    assert args.flush_cache == False
    args = parser.parse_args(["--flush-cache"])
    assert args.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert args.flush_cache == True


# Generated at 2022-06-22 18:48:29.485917
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    parser.add_argument('-K', '--ask-become-pass', dest='become_ask_pass', action='store_true',
                                  default=C.DEFAULT_BECOME_ASK_PASS,
                                  help='ask for privilege escalation password')
    parser.add_argument('--become-password-file', '--become-pass-file', default=C.BECOME_PASSWORD_FILE, dest='become_password_file',
                                  help="Become password file", type=unfrack_path(), action='store')
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass == True
    args = parser.parse_args(['--become-password-file', 'test'])