

# Generated at 2022-06-22 18:38:30.411508
# Unit test for function version
def test_version():
    assert 'ansible-console' in version('ansible-console')
    assert 'core' in version()
    assert 'config file' in version()
    assert 'configured module search path' in version()
    assert 'ansible python module location' in version()
    assert 'executable location' in version()
    assert 'python version' in version()
    assert 'jinja version' in version()

# Generated at 2022-06-22 18:38:41.131200
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')

# Generated at 2022-06-22 18:38:46.371562
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    p = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    p.add_argument("--foo")
    p.add_argument("--bar")
    text = p.format_help()
    assert text.find("--bar") < text.find("--foo")


# Generated at 2022-06-22 18:38:50.216895
# Unit test for function unfrack_path
def test_unfrack_path():
    """Unit test for function unfrack_path .
    :return: None
    """
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path(pathsep=True)('/foo/bar:/bar/foo') == ['/foo/bar', '/bar/foo']


# Generated at 2022-06-22 18:38:55.185090
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--unknown-argument', action='store_true', default=False, help='Unknown argument')
    parser.add_argument('positional-argument', action=UnrecognizedArgument)
    options, args = parser.parse_known_args()
    assert options.unknown_argument is True
    assert args == ['--unknown-argument']

#
# Parsers
#


# Generated at 2022-06-22 18:39:01.164329
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    p.add_argument('--list', action=PrependListAction)
    args = p.parse_args('--list 1 --list 2'.split())
    assert args.list == ['2', '1']


#
# Command Line Parsers
#

# Generated at 2022-06-22 18:39:03.352367
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    options = parser.parse_args()
    assert "task-timeout" in options


# Generated at 2022-06-22 18:39:04.507049
# Unit test for function version
def test_version():
    assert version()


#
# Option Parsing
#

# Generated at 2022-06-22 18:39:05.427698
# Unit test for function version
def test_version():
    assert version()



# Generated at 2022-06-22 18:39:16.067571
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-f')
    parser.add_argument('--foo')
    parser.add_argument('-b', '--baz')
    parser.add_argument('bar')
    help = parser.format_help()
    assert help == "usage: <unknown> [-h] [-f F] [--foo FOO] [-b BAR] [--baz BAR] bar\n\npositional arguments:\n  bar\n\noptional arguments:\n  -h, --help  show this help message and exit\n  -f F\n  --foo FOO\n  -b BAR, --baz BAR\n", 'argparse format help not as expected'


# Generated at 2022-06-22 18:39:26.306891
# Unit test for function add_subset_options
def test_add_subset_options():
    """Unit test for function add_subset_options"""
    from ansible.utils.display import Display
    from ansible.parsing.splitter import parse_kv
    display = Display()
    display.verbosity = 4
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options, args = parser.parse_known_args(['-t', 'tag1', '-t', 'tag2', '--tags', 'tag3', '--skip-tags', 'tag1,tag2'])
    assert isinstance(options, argparse.Namespace)
    assert isinstance(args, list)
    assert options.tags == ['tag1', 'tag2', 'tag3']
    assert options.skip_tags == ['tag1', 'tag2']
    options, args = parser.parse_

# Generated at 2022-06-22 18:39:32.515417
# Unit test for function ensure_value
def test_ensure_value():
    test_ns = argparse.Namespace()
    assert ensure_value(test_ns, 'foo', True) == True
    assert ensure_value(test_ns, 'foo', False) == True
    assert ensure_value(test_ns, 'bar', True) == True
    test_ns = argparse.Namespace(foo=False)
    assert ensure_value(test_ns, 'foo', True) == False
    assert ensure_value(test_ns, 'bar', True) == True



# Generated at 2022-06-22 18:39:34.341950
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('')
    if parser != None:
        assert True
    else:
        assert False


# Generated at 2022-06-22 18:39:36.156704
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    assert parser.parse_args()



# Generated at 2022-06-22 18:39:38.562315
# Unit test for function add_runtask_options
def test_add_runtask_options():
    import argparse
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    cmd = "-e key=value -e key2=value2 -e @myjson.json"
    args = parser.parse_args(shlex.split(cmd))
    assert args.extra_vars == ['key=value', 'key2=value2', '@myjson.json']

# Generated at 2022-06-22 18:39:40.431849
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options = parser.parse_args(['--one-line'])
    assert options.one_line == True



# Generated at 2022-06-22 18:39:43.503124
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Arrange
    parser = argparse.ArgumentParser()
    # Act
    add_runas_prompt_options(parser)
    # Assert
    assert parser.parse_args(["-K"])
    assert parser.parse_args(["--ask-become-pass"])
    assert parser.parse_args(["--become-password-file", "file1"])
    assert parser.parse_args(["--become-pass-file", "file1"])



# Generated at 2022-06-22 18:39:53.401987
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    ns = Namespace()
    assert ensure_value(ns, 'foo', [1,2,3]) == [1,2,3]
    assert getattr(ns, 'foo', None) == [1,2,3]

    ns = Namespace(foo=[7,8,9])
    assert ensure_value(ns, 'foo', [1,2,3]) == [7,8,9]
    assert getattr(ns, 'foo', None) == [7,8,9]

#
# Functions for parsing ANSIBLE_CONFIG AND *.cfg files
#



# Generated at 2022-06-22 18:39:55.295980
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_output_options(parser)
    args = parser.parse_args(['-t','/tmp/log'])
    assert args.tree == '/tmp/log'


# Generated at 2022-06-22 18:39:58.611348
# Unit test for function version
def test_version():
    assert version() == version("test")

#
# Methods not dependent on other type of option parse helpers should come first
#

# Generated at 2022-06-22 18:40:00.689997
# Unit test for function version
def test_version():
    assert version() == "2.0.0.2-0.1 ({0})".format(_gitinfo())


# Generated at 2022-06-22 18:40:03.374632
# Unit test for function add_runas_options
def test_add_runas_options():
    test_parser = argparse.ArgumentParser()
    add_runas_options(test_parser)
    options = test_parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'bob'])
    assert options.become_method == 'sudo'
    assert options.become_user == 'bob'



# Generated at 2022-06-22 18:40:15.853503
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test (os.pathsep) path separation functionality of unfrack_path()
    # On Windows os.pathsep is ; and on unix it is :
    path_env_var_sep = os.pathsep

    # Test defaults
    assert unfrack_path()("fake_path") == unfrackpath("fake_path")
    assert unfrack_path(pathsep=False)("fake_path") == unfrackpath("fake_path")

    # Test -
    assert unfrack_path()("-") == "-", "unfrack_path function failed for '-'"

    # Test pathsep=True with a single location
    assert unfrack_path(pathsep=True)("fake_path") == [unfrackpath("fake_path")]

# Generated at 2022-06-22 18:40:21.506302
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action="store", help='foo')
    parser.add_argument('--bar', action="store", help='bar')
    args = parser.parse_args([])
    assert(args.foo is None)
    assert(args.bar is None)



# Generated at 2022-06-22 18:40:24.957935
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    module = UnrecognizedArgument(['--some_option'], dest='some_option')
    assert module.option_strings == ['--some_option'] and module.dest == 'some_option'

#
# Parser and helpers for the `ansible` CLI tool
#

# Generated at 2022-06-22 18:40:29.462946
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
 
    class Namespace(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    ns = Namespace(foo=[1, 2])

    action = PrependListAction(('-p', '--prepend'), 'foo')
    action(None, ns, (3, 4))

    assert [3, 4, 1, 2] == ns.foo



# Generated at 2022-06-22 18:40:36.092862
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    sys.argv = ['ansible']
    parser = argparse.ArgumentParser(description='Ansible Version')
    parser.add_argument('--version', action=AnsibleVersion)
    parser.print_help()
    sys.argv = ['ansible', '--version']
    parser.parse_args()



# Generated at 2022-06-22 18:40:39.939672
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', dest='foo', action=PrependListAction, metavar='N',
                        type=int, default=[])
    parser.parse_args()
    assert True



# Generated at 2022-06-22 18:40:46.323168
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    test_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    test_parser.add_argument("-B", action="store",
                             help="bar help")
    test_parser.add_argument("-a", action="store",
                             help="foo help")
    test_help_output = 'usage: usage\n' \
                       '\n' \
                       'optional arguments:\n' \
                       '  -a, --arga  foo help\n' \
                       '  -B, --argB  bar help\n'
    assert test_parser.format_help() == test_help_output


# Generated at 2022-06-22 18:40:53.195478
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    (options, args) = parser.parse_known_args(['-u', 'dummy', '--ssh-common-args', '-o StrictHostKeyChecking=no'])
    assert options.remote_user == 'dummy'
    assert options.ssh_common_args == '-o StrictHostKeyChecking=no'



# Generated at 2022-06-22 18:40:56.923867
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'dir1'])
    assert args.basedir == 'dir1'



# Generated at 2022-06-22 18:41:02.657559
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test_action = AnsibleVersion(option_strings=['-v'])
    test_parser = argparse.ArgumentParser(prog='ansible-playbook')

    # test_action.__call__(parser=test_parser, namespace=None, values=None, option_string=None)

    assert test_action.__call__(parser=test_parser, namespace=None, values=None, option_string=None) == None



# Generated at 2022-06-22 18:41:10.593818
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('foo', help='foo help')
    parser.add_argument('bar', help='bar help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-b', action='store_true', help='b help')
    parser.parse_args(['--help'])


# Generated at 2022-06-22 18:41:18.550641
# Unit test for function create_base_parser
def test_create_base_parser():
    os.environ['ANSIBLE_CONFIG'] = ''

    from ansible.config.manager import ConfigManager

    config = ConfigManager('')
    config.update_config_obj()

    # Clear all config environment variables
    # so that they do not interfere with the test
    to_delete = []
    for key in os.environ.keys():
        if key.startswith('ANSIBLE_'):
            to_delete.append(key)
    for key in to_delete:
        os.environ.pop(key)

    parser = create_base_parser('ansible-inventory')

    assert 'ANSIBLE_LOG_PATH' not in parser._option_string_actions.keys()

    # does not have the --config option
    # (the inventory cli does not support it)
    assert '--config' not in parser

# Generated at 2022-06-22 18:41:21.966246
# Unit test for function add_subset_options
def test_add_subset_options():
    class MyArgs():
        C = C
        subset = ''
        extra_vars = ''
        tags = ''
        skip_tags = ''
        task_timeout = ''
    args = MyArgs()
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args(namespace=args)
    assert args.subset == C.DEFAULT_SUBSET
    assert args.extra_vars == ''
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP
    assert args.task_timeout == C.TASK_TIMEOUT

# Generated at 2022-06-22 18:41:27.832348
# Unit test for function add_subset_options
def test_add_subset_options():
    """Test add_subset_options"""
    print("Testing add_subset_options")
    description = "A description text"
    parser = argparse.ArgumentParser(
        prog="prog_name",
        description=description,
    )
    add_subset_options(parser)
    args_list = ["--tags", "tag_value", "--skip-tags", "skip_tag_value"]
    args = parser.parse_args(args_list)
    assert args.tags == ['tag_value']
    assert args.skip_tags == ['skip_tag_value']


# Generated at 2022-06-22 18:41:30.773995
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    av = AnsibleVersion("version", help="display version", nargs=0)
    for i in range(10):
        av("parser", "namespace", "values", "option_string")


# Generated at 2022-06-22 18:41:38.000557
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    import unittest
    import difflib
    from ansible.cli import CLI

    class TestAddOptions(unittest.TestCase):
        def setUp(self):
            self.parser = None

        def test_add_runas_prompt_options_returns_parser_with_group_but_no_arguments(self):
            parser = CLI.base_parser()
            parser = add_runas_prompt_options(parser)

            self.assertEqual(parser.format_help(),
                             '')

        def test_add_runas_prompt_options_returns_parser_with_no_group_but_with_arguments(self):
            parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
            parser = add_runas_prompt_options

# Generated at 2022-06-22 18:41:49.663817
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    parser.add_argument(
        '--version', action=UnrecognizedArgument, nargs=0,
        help='output version information and exit')
    # Execute method __call__ of class UnrecognizedArgument
    # with an argument string
    try:
        parser.parse_args(['--version'])
    except SystemExit:
        assert True
    # Execute method __call__ of class UnrecognizedArgument
    # with a help option
    try:
        parser.parse_args(['--help', '--version'])
    except SystemExit:
        assert True
    # Execute method __call__ of class UnrecognizedArgument
    # with a help option

# Generated at 2022-06-22 18:41:56.906907
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # pylint: disable=unused-argument
    def test(option_strings, dest, nargs, const, default, type, choices, required, help, metavar):
        parser = argparse.ArgumentParser()
        parser.add_argument(
            *option_strings,
            dest=dest,
            nargs=nargs,
            const=const,
            default=default,
            type=type,
            choices=choices,
            required=required,
            help=help,
            metavar=metavar,
            action=PrependListAction,
        )
        return parser

    # No nargs given
    exception_caught = False

# Generated at 2022-06-22 18:42:02.038082
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    version_output = version("ansible inventory")
    assert version_output == "%s %s" % (ansible.__title__, ansible.__version__)


#
# Shared option parsers
#

# Generated at 2022-06-22 18:42:03.911319
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(["-C", "--syntax-check", "-D"])
    assert args.check is True
    assert args.syntax is True
    assert args.diff is True


# Generated at 2022-06-22 18:42:07.193139
# Unit test for function version
def test_version():
    '''
    Test the above version function.
    '''
    # TODO: allow setting a CONFIG_FILE environment variable
    # to have the function return something we can test
    # against.
    version()

# Generated at 2022-06-22 18:42:16.054543
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test with pathsep
    assert ['test'] == unfrack_path(pathsep=True)('test')
    # Test with no pathsep
    assert 'test' == unfrack_path(pathsep=False)('test')
    # Test with pathsep and pathsep in input value
    assert ['test1', 'test2'] == unfrack_path(pathsep=True)('test1:test2')
    # Test with pathsep, pathsep in input value and empty values
    assert ['test1', 'test2'] == unfrack_path(pathsep=True)('test1::test2')



# Generated at 2022-06-22 18:42:18.402508
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    assert parser._actions[3].nargs is '*'


# Generated at 2022-06-22 18:42:28.243335
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(add_help=False, prog='test')
    add_module_options(parser)
    args = parser.parse_args(["-M","testdir1:testdir2"])
    assert args.module_path == ['testdir1', 'testdir2'], 'test add module option failed'
    args = parser.parse_args(["-M","testdir1:testdir2","-M","testdir3:testdir4"])
    assert args.module_path == ['testdir1', 'testdir2', 'testdir3', 'testdir4'], 'test add module option failed'



# Generated at 2022-06-22 18:42:31.121292
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    PrependListAction(option_strings=['--append'], dest='mylist', help='mylist help', default=[])



# Generated at 2022-06-22 18:42:36.290948
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(description='test parser')
    add_output_options(parser)
    options = parser.parse_args(['-o', '-t', '/tmp/test'])
    assert options.one_line is True
    assert options.tree == '/tmp/test'



# Generated at 2022-06-22 18:42:42.943800
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    from ansible.cli.arguments import Options
    options = Options()
    parser = options.parser
    add_tasknoplay_options(parser)
    parser.parse_args(['--task-timeout', '600'])
    assert options.task_timeout == 600
    parser.parse_args(['--task-timeout', '-1'])
    assert options.task_timeout == 0
    # Default value should be greater than 0
    assert options.task_timeout > 0


# Generated at 2022-06-22 18:42:48.388464
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    try:
        parser.parse_args(['--foo', 'bar'])
    except SystemExit as e:
        if e.code == 2:
            return True
    return False



# Generated at 2022-06-22 18:42:54.224881
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    opts = parser.parse_args(['--check'])
    assert opts.check

    opts = parser.parse_args(['--diff'])
    assert opts.diff

    opts = parser.parse_args(['--syntax-check'])
    assert opts.syntax



# Generated at 2022-06-22 18:42:56.277981
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    action = PrependListAction(['--foo'], 'foo')
    parser.add_argument('--foo', action=action)



# Generated at 2022-06-22 18:43:00.464609
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(os.path.basename(sys.argv[0])))
    assert sys.argv[0] == 'test/ansible-version'
    assert ansible_version == 'test version'


# Generated at 2022-06-22 18:43:07.465126
# Unit test for function create_base_parser
def test_create_base_parser():
    result = create_base_parser(prog='foo')
    assert result.prog == 'foo'
    assert isinstance(result, argparse.ArgumentParser)
    assert isinstance(result.formatter_class, SortingHelpFormatter)
    assert isinstance(result._actions[1], AnsibleVersion)
    assert result._actions[1].help == 'show program\'s version number, config file location, configured module search path, module location, executable location and exit'



# Generated at 2022-06-22 18:43:18.144097
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = Mock()
    add_vault_options(parser)
    assert parser.add_argument.call_count == 3
    args = parser.add_argument.call_args_list
    assert args[0][0][0] == '--vault-id'
    assert args[0][0][1] == '--vault-id'
    assert args[1][0][0] == '--ask-vault-password'
    assert args[1][0][1] == '--ask-vault-pass'
    assert args[2][0][0] == '--vault-password-file'
    assert args[2][0][1] == '--vault-pass-file'


# Generated at 2022-06-22 18:43:22.106845
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser('test')
    parser.add_argument('-f', '--foo', action=UnrecognizedArgument)
    parser.parse_args(['-f', 'bar'])



# Generated at 2022-06-22 18:43:27.059225
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    a_options = ['--a']
    b_options = ['--b']
    parser = argparse.ArgumentParser()
    parser.add_argument(a_options[0], action=UnrecognizedArgument, help='a help')
    parser.add_argument(b_options[0], action=UnrecognizedArgument, help='b help')
    with parser.suppress_warnings():
        args = parser.parse_args(a_options + b_options)



# Generated at 2022-06-22 18:43:34.059751
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='Ansible', formatter_class=SortingHelpFormatter)
    add_vault_options(parser)
    args = parser.parse_args()
    assert args.vault_ids == None
    assert args.ask_vault_pass == None
    assert args.vault_password_files == None

# Normalize arguments to dict, where string keys are converted to unicode

# Generated at 2022-06-22 18:43:39.372274
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    assert getattr(parser.parse_args([]), 'one_line') is False
    assert getattr(parser.parse_args([]), 'tree') is None
    assert getattr(parser.parse_args(['--one-line']), 'one_line') is True
    assert getattr(parser.parse_args(['-t', 'SubDir']), 'tree') == 'SubDir'
    assert getattr(parser.parse_args(['--tree', 'SubDir']), 'tree') == 'SubDir'



# Generated at 2022-06-22 18:43:45.472261
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    test_action = PrependListAction(
        option_strings=('foo','bar','buzz'),
        dest='test_dest',
        const=None,
        default=None,
        type=None,
        choices=None,
        required=False,
        help='test help',
        metavar='test metavar',
    )

    sample_namespace = argparse.Namespace()

    # test now with nargs=None
    test_action.nargs=None
    sample_values = [1,2,3]
    test_action.__call__(argparse.ArgumentParser(), sample_namespace, sample_values)
    assert(sample_namespace.test_dest == [1,2,3])

    # test now with nargs=2
    test_action.nargs=2
    sample_

# Generated at 2022-06-22 18:43:51.970227
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """
    Unit testing for method __call__ of class AnsibleVersion
    """

    def get_parser(prog):
        parser = argparse.ArgumentParser()
        parser.add_argument("--version", action=AnsibleVersion, help='show program version and exit')
        parser.prog = prog

        return parser

    if j2_version != '2.10':
        ansible_version = to_native(version('/usr/bin/ansible'))
        assert ansibleVersion(['--version'], get_parser('/usr/bin/ansible')) == ansible_version
    else:

        my_parser = get_parser('/usr/bin/ansible')
        my_parser.exit = lambda status=0, message=None: (status, message)

# Generated at 2022-06-22 18:44:02.731494
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # 1. test with appending values
    action = PrependListAction(option_strings=['--option'], dest='foo', const=1, default=[1])
    assert action.default == [1, 1]
    assert action.nargs == argparse.OPTIONAL
    assert action.const == 1
    assert action.type == None

    action = PrependListAction(option_strings=['--option'], dest='foo', const=1, default=[1], nargs='+')
    assert str(action) == '--option [VALUES]...'
    assert action.default == [1, 1]
    assert action.nargs == argparse.ONE_OR_MORE
    assert action.const == 1
    assert action.type == None


# Generated at 2022-06-22 18:44:12.727236
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(description='test')
    add_runtask_options(parser)

    result = parser.parse_args(['-e', "@/data/vars.yml"])
    assert result.extra_vars == ['/data/vars.yml']

    result = parser.parse_args(['-e', "name1=value1", "-e", "@/data/vars.yml"])
    assert result.extra_vars == ["name1=value1", '/data/vars.yml']

    result = parser.parse_args(['-e', "name2=value2"])
    assert result.extra_vars == ["name2=value2"]



# Generated at 2022-06-22 18:44:22.813968
# Unit test for function version
def test_version():

    exe_list = ['/usr/bin/ansible', '/usr/bin/ansible-playbook',
                '/usr/bin/ansible-vault', '/usr/bin/ansible-console',
                '/usr/bin/ansible-doc', '/usr/bin/ansible-inventory']
    ansible_module_path_prefix = '/home/username/.local/lib/python2.7/site-packages/ansible'
    ansible_module_path_lists = ['/usr/share/ansible', '/etc/ansible']
    ansible_module_paths = ['/usr/share/ansible', '/etc/ansible', '/home/username/.local/lib/python2.7/site-packages/ansible']
    ansible_module_paths = ':'.join(ansible_module_paths)


# Generated at 2022-06-22 18:44:25.897886
# Unit test for function create_base_parser
def test_create_base_parser():
    p = create_base_parser('test')
    return p.parse_args(['-v'])


# Generated at 2022-06-22 18:44:28.153948
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

# Generated at 2022-06-22 18:44:29.450070
# Unit test for function add_check_options
def test_add_check_options():
    assert True, "test passed"



# Generated at 2022-06-22 18:44:36.953647
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
  class MockNamespace(object):
    pass

  class MockOptionString(object):
    pass

  class MockParser(object):
    def __init__(self):
      self.prog = 'ansible'
      self.exit = lambda: None

  namespace = MockNamespace()
  option_string = MockOptionString()
  parser = MockParser()

  action = AnsibleVersion(option_string)
  action(parser, namespace, None, option_string)


#
# Main class for all common CLI options
#

# Generated at 2022-06-22 18:44:39.801499
# Unit test for function add_vault_options
def test_add_vault_options():
    from ansible.cli.arguments import option_helpers as coh
    add_vault_options(coh.base_parser)

# Generated at 2022-06-22 18:44:49.585617
# Unit test for function add_module_options
def test_add_module_options():
    testmodule_opt = argparse.ArgumentParser(description="test add_module_options")
    add_module_options(testmodule_opt)
    module_path = C.config.get_configuration_definition('DEFAULT_MODULE_PATH').get('default', '')
    assert module_path == testmodule_opt.get_default('module_path')
    testpass = ['-M', '~/test']
    testfail = ['-M', '~/test']
    try:
        testmodule_opt.parse_args(testfail)
    except SystemExit:
        pass
    except Exception as e:
        raise e
    else:
        raise RuntimeError('fail')
    testmodule_opt.parse_args(testpass)



# Generated at 2022-06-22 18:44:57.648967
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible import constants as C
    test_variables = {'default_forks': 1}
    with patch.object(C, 'DEFAULT_FORKS', test_variables['default_forks']):
        test_args = Mock()
        test_args.forks = C.DEFAULT_FORKS
        parser = Mock()
        add_fork_options(parser)
        parser.add_argument.assert_any_call('-f', '--forks', dest='forks', default=C.DEFAULT_FORKS, type=int,
                        help="specify number of parallel processes to use (default=1)")



# Generated at 2022-06-22 18:44:59.772960
# Unit test for function add_vault_options
def test_add_vault_options():
    """
    add_vault_options test
    """

    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(args=[])
    assert args.vault_ids is not None
    assert args.ask_vault_pass is not None
    assert args.vault_password_files is not None



# Generated at 2022-06-22 18:45:03.053920
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog="Test", description='Unit test for function')
    add_tasknoplay_options(parser)

# Generated at 2022-06-22 18:45:10.887197
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Code under test
    formatter = SortingHelpFormatter()

    # Create a parser to parse test data
    parser = argparse.ArgumentParser(formatter_class=formatter)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-f', '--foo', action='store_true', default=False)
    group.add_argument('-b', '--bar', action='store_true', default=False)

    # Mock group.group_actions
    group.group_actions = [
        argparse._StoreTrueAction(
            option_strings=('-f', '--foo'), dest='foo', default=False, required=False, help=None
        )
    ]

    # Mock formatter.indent_increment
    formatter.indent_increment = ' ' * 4

# Generated at 2022-06-22 18:45:16.636531
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='*', help="Test help text")
    args = vars(parser.parse_args(['--foo', 'bar', 'baz', 'bat', '--foo', 'foo']))
    assert args['foo'] == ['foo', 'bar', 'baz', 'bat']
    args = vars(parser.parse_args(['--foo', 'bar', 'baz', 'bat']))
    assert args['foo'] == ['bar', 'baz', 'bat']



# Generated at 2022-06-22 18:45:23.528337
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    # Test the defaults
    options = parser.parse_args(args='')
    assert int(options.forks) == C.DEFAULT_FORKS
    # Test changing the default
    options = parser.parse_args(args='-f 10')
    assert options.forks == 10


# Generated at 2022-06-22 18:45:30.845770
# Unit test for function add_vault_options
def test_add_vault_options():
    class FakeOptionParser:
        add_argument = None

    parser = FakeOptionParser()
    parser.add_argument = Mock()
    add_vault_options(parser)
    calls = [
        call('--vault-id', default=[], action='append', dest='vault_ids', type=str, help='the vault identity to use'),
    ]
    parser.add_argument.assert_has_calls(calls)


# Generated at 2022-06-22 18:45:39.320884
# Unit test for function add_basedir_options
def test_add_basedir_options():
    """Unittest function for add_basedir_options"""
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', '.'])
    assert options.basedir == ['.']
    options = parser.parse_args(['--playbook-dir', '~/test'] )
    assert options.basedir == [os.path.expanduser('~/test')]
    options = parser.parse_args([])
    assert options.basedir == None



# Generated at 2022-06-22 18:45:48.406531
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('+')('+/home/dave/ansible') == '+/home/dave/ansible'
    assert maybe_unfrack_path('/')('+/home/dave/ansible') == '+/home/dave/ansible'
    assert maybe_unfrack_path('/')('/home/dave/ansible') == '/home/dave/ansible'
    assert maybe_unfrack_path('/')('+/home/dave/ansible/') == '+/home/dave/ansible'
    assert maybe_unfrack_path('/')('/home/dave/ansible/') == '/home/dave/ansible'

# Generated at 2022-06-22 18:45:56.057459
# Unit test for function add_output_options
def test_add_output_options():
    '''
    Test add_output_options function
    '''
    # Create a parser
    parser = argparse.ArgumentParser()
    # Add options
    add_output_options(parser)
    # Parse the arguments
    args = parser.parse_args()
    # Check if the value of variable is correct or not
    assert args.one_line == None
    assert args.tree == None



# Generated at 2022-06-22 18:46:06.056260
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_runas_options(parser)
    runas_group = parser._action_groups[2]
    assert(runas_group.title == 'Privilege Escalation Options')
    assert(runas_group.description == 'control how and which user you become as on target hosts')
    assert(runas_group._group_actions[0].dest == 'become')
    assert(runas_group._group_actions[1].dest == 'become_method')
    assert(runas_group._group_actions[2].dest == 'become_user')



# Generated at 2022-06-22 18:46:11.565326
# Unit test for function ensure_value
def test_ensure_value():
    from ansible.utils.display import Display

    class Namespace(object):
        pass

    n = Namespace()
    ensure_value(n, '_display', Display())
    ensure_value(n, '_display', Display())
    assert n._display is not None


#
# Parser for Ansible Core
#

# Generated at 2022-06-22 18:46:20.151636
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    # Check default value
    options = parser.parse_args([])
    assert options.check == False
    assert options.syntax == False
    assert options.diff == C.DIFF_ALWAYS
    # Check enabled options
    options = parser.parse_args(["-C", "--syntax-check", "-D"])
    assert options.check == True
    assert options.syntax == True
    assert options.diff == True



# Generated at 2022-06-22 18:46:26.996758
# Unit test for function unfrack_path
def test_unfrack_path():
    def test_unfrack_path_inner(value, expected_value):
        ansible_path = unfrack_path()
        result_value = ansible_path(value)
        assert result_value == expected_value, "Expected %s, but got %s" % (expected_value, result_value)
    # Testing argument None
    test_unfrack_path_inner(None, '')
    # Testing argument '-'
    test_unfrack_path_inner('-', '-')
    # Testing argument '.'
    test_unfrack_path_inner('.', '.')
    # Testing argument './'
    test_unfrack_path_inner('./', '.')
    # Testing argument '/'
    test_unfrack_path_inner('/', '/')
    # Testing argument

# Generated at 2022-06-22 18:46:33.498551
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        epilog='',
        description='',
        conflict_handler='resolve',
    )
    add_meta_options(parser)
    result = parser.parse_known_args(['--force-handlers', '--flush-cache'])
    assert result[0].force_handlers == True
    assert result[0].flush_cache == True



# Generated at 2022-06-22 18:46:38.359616
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    result = maybe_unfrack_path("@")("@ansible/foo")
    assert result == "@@ansible/foo"
    result = maybe_unfrack_path("@")("~/foo")
    assert result == "~/foo"
    assert maybe_unfrack_path("@")("@ansible/foo")



# Generated at 2022-06-22 18:46:39.990756
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)



# Generated at 2022-06-22 18:46:44.427199
# Unit test for function add_check_options
def test_add_check_options():
    for opt in ('-C', '--check', '--syntax-check', '-D', '--diff'):
        assert opt in [x.option_strings[0] for x in add_check_options.__code__.co_consts]



# Generated at 2022-06-22 18:46:49.552956
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    argparse.ArgumentParser.add_argument = lambda self, *args, **kwargs: None
    parser.add_argument('--version', dest='version', action=AnsibleVersion)

#
# Common Utilities
#


# Generated at 2022-06-22 18:46:58.638702
# Unit test for function add_connect_options
def test_add_connect_options():
    parser=argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--ask-pass', '--connection-password-file',"/home/tester/test",'--ssh-common-args',"-vvv",'--sftp-extra-args',"-l",'--scp-extra-args',"-l",'--ssh-extra-args',"-R"])
    assert (args.ask_pass==True)
    assert (args.connection_password_file=="/home/tester/test")
    assert (args.ssh_common_args=="-vvv")
    assert (args.sftp_extra_args=="-l")
    assert (args.scp_extra_args=="-l")
    assert (args.ssh_extra_args=="-R")

# Generated at 2022-06-22 18:47:02.674652
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-playbook'
    ns = argparse.Namespace()
    option_string = '--version'
    values = None
    AnsibleVersion()(parser, ns, values, option_string)



# Generated at 2022-06-22 18:47:11.697452
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(
        prog='test',
        description='test add_meta_options',
        conflict_handler='resolve',
    )
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers is True
    assert args.flush_cache is True
    args = parser.parse_args([])
    assert args.force_handlers is False
    assert args.flush_cache is False



# Generated at 2022-06-22 18:47:17.731108
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(description='description')
    add_runtask_options(parser)
    for arg in ('-e', '--extra-vars', '-e', '--extra-vars'):
        args = parser.parse_args([arg, 'val'])
        assert getattr(args, 'extra_vars') == ['val', 'val']



# Generated at 2022-06-22 18:47:25.069328
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', '/tmp/foo', '-M', '/tmp/bar'])
    assert options.module_path == ['/tmp/bar', '/tmp/foo']
    options = parser.parse_args(['-M', '/tmp/bar'])
    assert options.module_path == ['/tmp/bar']
    options = parser.parse_args(['-M', '/tmp/bar:baz'])
    assert options.module_path == ['/tmp/bar', 'baz']



# Generated at 2022-06-22 18:47:34.627030
# Unit test for function add_inventory_options
def test_add_inventory_options():
    testArgs = ['--list-hosts', '--inventory', 'hosts', '-l', 'limit', '--limit', 'otherlimit']
    parser = argparse.ArgumentParser(description='add_inventory_options test')
    add_inventory_options(parser)
    ret = parser.parse_args(testArgs)
    expectedRet = argparse.Namespace(inventory=['hosts'], listhosts=True, subset=['limit', 'otherlimit'])
    assert vars(ret) == vars(expectedRet)



# Generated at 2022-06-22 18:47:35.843354
# Unit test for function add_basedir_options
def test_add_basedir_options():
    assert add_basedir_options



# Generated at 2022-06-22 18:47:42.283593
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    opts = parser.parse_args()
    assert opts.connection == C.DEFAULT_TRANSPORT
    assert opts.timeout == C.DEFAULT_TIMEOUT
    assert opts.ask_pass == C.DEFAULT_ASK_PASS
    assert opts.connection_password_file == C.CONNECTION_PASSWORD_FILE



# Generated at 2022-06-22 18:47:43.983517
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog='test_add_module_options')
    add_module_options(parser)



# Generated at 2022-06-22 18:47:46.729523
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    parser.parse_args(args=['-o', '-t', '/path/to/log'])
# End of unit test for function add_output_options



# Generated at 2022-06-22 18:47:50.348064
# Unit test for function ensure_value
def test_ensure_value():
    assert [42] == ensure_value(argparse.Namespace(), 'foo', [42])
    args = argparse.Namespace()
    ensure_value(args, 'foo', [42])
    assert [42] == ensure_value(args, 'foo', [43])
    assert [42] == args.foo


#
# Utilities
#

# Generated at 2022-06-22 18:47:56.358722
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    argparse.ArgumentParser()
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    #assert args.version == 'ansible-base'  # NOTE: this takes some time to finish


# Generated at 2022-06-22 18:48:02.428108
# Unit test for function add_inventory_options
def test_add_inventory_options():
    args = ['--inventory-file', 'hosts', '--list-hosts', '-l', 'foo']
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(args)
    assert options.inventory == ['hosts']
    assert options.listhosts == True
    assert options.subset == 'foo'


# Generated at 2022-06-22 18:48:06.014654
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'localhost'])
    assert options.inventory == ['localhost']



# Generated at 2022-06-22 18:48:08.596476
# Unit test for function add_basedir_options
def test_add_basedir_options():
    assert(add_basedir_options)
add_basedir_options(add_basedir_options)



# Generated at 2022-06-22 18:48:09.230294
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    pass



# Generated at 2022-06-22 18:48:19.617645
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.utils import version

    if sys.version_info >= (2, 7):
        import io
        sys.stdout = io.StringIO()
        prog = 'ansible-doc'
        parser = argparse.ArgumentParser(prog=prog)
        namespace = argparse.Namespace()
        values = None
        option_string = None
        AnsibleVersion.__call__(AnsibleVersion(), parser, namespace, values, option_string)
        ansible_version = sys.stdout.getvalue()
        print(ansible_version)
        print(version('ansible-doc'))
        assert ansible_version == version(prog)
    else:
        print("Skip to test method __call__ of class AnsibleVersion because of the lower version of python")

# Generated at 2022-06-22 18:48:29.611109
# Unit test for function add_subset_options
def test_add_subset_options():
    class FakeClass(object):
        def __init__(self, argv):
            self.args = argv
    #Unit test for argument -t --tags
    obj = FakeClass([])
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args(["-t", "tag1"], namespace=obj)
    assert getattr(obj, 'tags') == ["tag1"]
    obj = FakeClass([])
    parser.parse_args(["--tags", "tag2"], namespace=obj)
    assert getattr(obj, 'tags') == ["tag2"]