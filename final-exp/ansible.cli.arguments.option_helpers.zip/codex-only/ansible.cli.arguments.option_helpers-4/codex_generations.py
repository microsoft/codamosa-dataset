

# Generated at 2022-06-22 18:38:36.660229
# Unit test for function add_runas_options
def test_add_runas_options():
    """Add options for commands which can run tasks as another user"""
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runas_options(parser)
    # verify that become-user when no -become-user is passed is equal to root
    args = parser.parse_args(['-b'])
    assert not args.become_user, 'error: default become_user should be None'
    # verify that become-user when -become-user is passed is equal to the passed user
    args = parser.parse_args(['-b', '--become-user', 'ansible'])
    assert args.become_user == 'ansible', 'error: become_user should be ansible'
# EOC Unit test for function add_runas_options



# Generated at 2022-06-22 18:38:40.719915
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = vars(parser.parse_args([]))
    assert args['task_timeout'] == C.TASK_TIMEOUT

# Generated at 2022-06-22 18:38:48.678548
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='test')
    add_connect_options(parser)
    args= vars(parser.parse_args(['--private-key', '~/.ssh/mykey.pem', '-u', 'myuser']))
    assert args['private_key_file'] == os.path.expanduser('~/.ssh/mykey.pem')
    assert args['remote_user'] == 'myuser'
    assert args['connection'] == 'smart'
    assert args['timeout'] == 10
    assert args['ssh_common_args'] is None
    assert args['sftp_extra_args'] is None
    assert args['scp_extra_args'] is None
    assert args['ssh_extra_args'] is None
    assert args['ask_pass'] is False

# Generated at 2022-06-22 18:38:54.775002
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    myplay = play()
    myplay.args = {}
    myplay.options = parser()
    myplay.options = add_tasknoplay_options(myplay.options)
    myplay.options.parse_args(['--task-timeout', '100'])
    myplay.args['task_timeout'] = 100

# Generated at 2022-06-22 18:39:02.994591
# Unit test for function add_subset_options
def test_add_subset_options():
    args = []
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS)
    add_subset_options(parser)
    add_check_options(parser)
    add_inventory_options(parser)
    add_fork_options(parser)
    args = parser.parse_args(args)
    assert isinstance(args.tags, list)
    assert isinstance(args.skip_tags, list)
    assert not args.syntax
    assert not args.listhosts



# Generated at 2022-06-22 18:39:06.293727
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    results = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert results.force_handlers
    assert results.flush_cache



# Generated at 2022-06-22 18:39:10.722294
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True)('relative/path:/absolute/path') == ['relative/path', '/absolute/path']
    assert unfrack_path()('relative/path') == 'relative/path'
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-22 18:39:21.548729
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_parser = argparse.ArgumentParser()
    sub_parsers = test_parser.add_subparsers()
    test_subparser1 = sub_parsers.add_parser(
        "test_subparser1", help="test_subparser1 help",
        formatter_class=SortingHelpFormatter)
    test_subparser2 = sub_parsers.add_parser(
        "test_subparser2", help="test_subparser1 help",
        formatter_class=SortingHelpFormatter)
    test_subparser3 = sub_parsers.add_parser(
        "test_subparser3", help="test_subparser1 help",
        formatter_class=SortingHelpFormatter)

# Generated at 2022-06-22 18:39:27.721326
# Unit test for function add_connect_options
def test_add_connect_options():
    import argparse
    parser = argparse.ArgumentParser(description="Ansible hello")
    add_connect_options(parser)
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, help="Show the current version")
    parser.add_argument('--list-hosts', action='store_true', dest="listhosts", default=False, help="input file name")
    cli = parser.parse_args()


# Generated at 2022-06-22 18:39:36.426112
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.cli import CLI, AnsibleCLI
    import sys
    class TestAnsibleVersion(AnsibleVersion):
        def __init__(self, option_strings, dest, **kwargs):
            super(TestAnsibleVersion, self).__init__(option_strings, dest, **kwargs)

    tav = TestAnsibleVersion('-T', 'testversion', nargs=0, help='test AnsibleVersion class')
    parser = argparse.ArgumentParser(description='Test AnsibleVersion class')
    parser.add_argument('-T', '--testversion', action=TestAnsibleVersion,
                        help='test AnsibleVersion class')
    parser.prog = 'testversion'
    argv = ['--testversion']
    sys.argv = argv

    # Assert: no exception is

# Generated at 2022-06-22 18:39:41.141298
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    # case 1: task timeout of integer value
    test_args = ['--task-timeout', '60']
    args_ns = parser.parse_args(test_args)
    assert (args_ns.task_timeout == 60)
    # case 2: task timeout of output of None
    test_args = ['--task-timeout']
    args_ns = parser.parse_args(test_args)
    assert (args_ns.task_timeout is None)
    # case 3: task timeout of non-positive value
    test_args = ['--task-timeout', '-1']
    args_ns = parser.parse_args(test_args)
    assert (args_ns.task_timeout == -1)
    # case 4:

# Generated at 2022-06-22 18:39:49.842028
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # os.path.join is needed because the path separator is different between *nix and Windows
    paths = [
        os.path.join(os.path.sep, 'home', 'user', 'hello'),
        os.path.join(os.path.sep, 'home', 'user', 'hello', 'world'),
        os.path.join(os.path.sep, 'home', 'user', 'hello', 'world', 'file.txt'),
    ]
    for path in paths:
        unfrack_path = maybe_unfrack_path(beacon='@')(path)

# Generated at 2022-06-22 18:39:59.819790
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-22 18:40:01.612814
# Unit test for function add_check_options
def test_add_check_options():
    n = create_base_parser("test")
    print (n)
    add_check_options(n)
    print (n)


# Generated at 2022-06-22 18:40:08.426348
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from ansible.config.manager import ConfigManager
    C.config = ConfigManager()
    parser = argparse.ArgumentParser(
        prog="test",
        formatter_class=SortingHelpFormatter,
        description="test"
    )
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'some/path'])
    assert args.basedir == 'some/path'



# Generated at 2022-06-22 18:40:15.165317
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from ansible.module_utils.ansible_release import ANSIBLE_VERSION
    # Base parser
    parser = create_base_parser("ansible-playbook")
    add_basedir_options(parser)
    # Create parser for ansible-playbook
    args = parser.parse_args("-vvvv --playbook-dir <path>")
    assert args.verbosity == 4
    assert args.playbook_dir == "<path>"

# Generated at 2022-06-22 18:40:21.756144
# Unit test for function add_async_options
def test_add_async_options():
    options = {
        'poll': 20,
        'seconds': 20
    }
    parser = create_base_parser('unit_test')
    add_async_options(parser)
    parser = parser.parse_args(['-P', '20', '-B', '20'])
    assert parser.poll_interval == options['poll']
    assert parser.seconds == options['seconds']



# Generated at 2022-06-22 18:40:30.620889
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible import context
    from ansible.cli.arguments import option_helpers as opt_help
    parser = opt_help.get_base_parser(constants=context.CLI_ARGS)
    parser.add_argument('--tag', action=PrependListAction, default=[], help='only run plays and tasks tagged with these values')
    options = parser.parse_args(['--tag', 'tag-1', '--tag', 'tag-2'])
    assert options.tag == ['tag-1', 'tag-2']
    options = parser.parse_args(['--tag', 'tag-1', '--tag', 'tag-2', '--tag', 'tag-3'])
    assert options.tag == ['tag-1', 'tag-2', 'tag-3']
# END test for method __call__ of

# Generated at 2022-06-22 18:40:31.100881
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    assert True



# Generated at 2022-06-22 18:40:36.397223
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog='ansible-test-script',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_connect_options(parser)
    return parser



# Generated at 2022-06-22 18:40:40.636752
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_basedir_options(parser)
    opts = parser.parse_args(['--playbook-dir','/home'])
    assert opts.basedir == '/home'


# Generated at 2022-06-22 18:40:44.546043
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args("-b -K -k --become-method=sudo --become-user=root".split())
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-22 18:40:50.473961
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
  import argparse
  parser = argparse.ArgumentParser()
  add_runas_prompt_options(parser)
  parser.parse_args(['-K'])
  parser.parse_args(['--become-password-file', 'foo'])



# Generated at 2022-06-22 18:40:58.439660
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    import argparse
    from ansible.utils.path import unfrackpath
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    p = CLI([unfrackpath(__file__)])
    parser = p.parser

    # Add --version / -V to test AnsibleVersion()
    parser._add_version_option = True
    opt_help.add_version_option_to_parser(parser)

    # test ansible version
    options = parser.parse_args(['--version'])
    assert options.version is True


# Generated at 2022-06-22 18:41:02.654119
# Unit test for function add_vault_options
def test_add_vault_options():
    from ansible.cli import CLI
    cli = CLI()
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(args=[])
    cli.options = options
    assert options.ask_vault_pass == False
    assert options.vault_ids == []
    assert options.vault_password_files == []
    # NOTE: --ask-vault-pass not working correctly.
    # test with --ask-vault-pass
    options = parser.parse_args(args=['--ask-vault-pass'])
    cli.options = options
    assert options.ask_vault_pass == True
    assert options.vault_ids == []
    assert options.vault_password_files == []
    # test with --vault-

# Generated at 2022-06-22 18:41:09.775340
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog='ansible-test')
    add_module_options(parser)
    args = parser.parse_args(['-M', '/tmp'])
    assert args.module_path == ['/tmp']
    args = parser.parse_args(['-M', '/tmp:/tmp2'])
    assert args.module_path == ['/tmp', '/tmp2']



# Generated at 2022-06-22 18:41:10.875297
# Unit test for function add_meta_options
def test_add_meta_options():
  #pass
  assert add_meta_options


# Generated at 2022-06-22 18:41:11.791031
# Unit test for function add_output_options
def test_add_output_options():
    pass


# Generated at 2022-06-22 18:41:15.537344
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    assert parser.has_action('--vault-id')
    assert getattr(parser.has_action('--ask-vault-password'), 'dest') == 'ask_vault_pass'


#
# Functions to handle some common CLI layouts
#


# Generated at 2022-06-22 18:41:21.206865
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    result = add_connect_options(parser)
    assert result == 'connection,connection_password_file,private_key_file,scp_extra_args,sftp_extra_args,ssh_common_args,ssh_extra_args,ask_pass,user,connection,timeout,timeout'



# Generated at 2022-06-22 18:41:23.671415
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['-f', '9'])
    assert options.forks == 9



# Generated at 2022-06-22 18:41:28.801278
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert '-v' in parser._option_string_actions.keys()
    assert '--verbose' in parser._option_string_actions.keys()


# Generated at 2022-06-22 18:41:36.051349
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(prog='ansible-version', add_help=False)
    parser.add_argument('-v', '--version', action='version', version=__version__,
                        help='show program version')

    parser.add_argument('--version', action=UnrecognizedArgument)
    options = parser.parse_args(['-v'])
    assert options.version == __version__

    options = parser.parse_args(['--version'])

#
# Customization of argparse for Ansible
#


# Generated at 2022-06-22 18:41:43.218073
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = Parser()
    parser.add_argument("--test", action=UnrecognizedArgument, nargs=2)
    with pytest.raises(SystemExit) as cm:
        parser.parse_args("--test foo bar".split(" "))
        assert cm.exconly().startswith("Exception SystemExit")
    parser = Parser()
    parser.add_argument("--test", nargs=2)
    parser.parse_args("--test foo bar".split(" "))
    assert parser.test == ("foo", "bar")



# Generated at 2022-06-22 18:41:51.918892
# Unit test for function add_basedir_options
def test_add_basedir_options():

    parser = argparse.ArgumentParser(prog='ansible')
    add_basedir_options(parser)
    arguments = [
        ['--playbook-dir', '$HOME/playbooks'],
        ['--playbook-dir', 'foo/bar'],
    ]
    for args in arguments:
        opt = parser.parse_args(args)
        assert isinstance(opt.basedir, str)
        assert opt.basedir.endswith('/')
        assert not opt.basedir.startswith('$')
        assert args[1] in opt.basedir
    
    # More comprehensive testing of the underlying function can be found in the test suite for DEFAULT_MODULE_PATH


# Generated at 2022-06-22 18:41:58.055774
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        epilog='test epilog',
        description='test desc',
        conflict_handler='resolve'
    )
    add_verbosity_options(parser)
    options = parser.parse_args(['-vvv'])
    assert options.verbosity == 3
    options = parser.parse_args([])
    assert options.verbosity == 0


# Generated at 2022-06-22 18:42:01.144602
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('foo')('foo/bar') == 'foo{0}bar'.format(os.sep)



# Generated at 2022-06-22 18:42:09.835843
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # pylint: disable=protected-access
    parser = argparse.ArgumentParser()

    subparsers = parser.add_subparsers()
    my_parser = subparsers.add_parser('foo')

    # This is the method we want to test
    formatter = SortingHelpFormatter()

    # Test the case where we want to format the whole help, including the
    # description of the program
    action = parser._get_positional_actions()[0]
    formatter.add_arguments(action._get_subactions())

# Generated at 2022-06-22 18:42:10.400040
# Unit test for function add_subset_options

# Generated at 2022-06-22 18:42:14.811777
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ap = argparse.ArgumentParser()
    av = AnsibleVersion(option_strings=['-v', '--version'])
    av(ap, None, None, '--version')



# Generated at 2022-06-22 18:42:17.518941
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args('-i inventory -l host'.split())
    assert options.inventory == ['inventory']
    assert options.subset == 'host'


# Generated at 2022-06-22 18:42:28.328244
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-z', action="store")
    parser.add_argument('-a', action="store")
    parser.add_argument('-b', action="store")
    parser.add_argument('-c', action="store")
    assert parser.format_help().splitlines()[-4] == '-a'
    assert parser.format_help().splitlines()[-3] == '-b'
    assert parser.format_help().splitlines()[-2] == '-c'
    assert parser.format_help().splitlines()[-1] == '-z'


# Note: This option parser has been deprecated in favor of CLI.

# Generated at 2022-06-22 18:42:32.029691
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog='test_add_async_options',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_async_options(parser)
    assert parser._actions[1].option_strings == ('-B', '--background')



# Generated at 2022-06-22 18:42:38.193095
# Unit test for function add_connect_options
def test_add_connect_options():
    print("Testing function ansible.cli.CLI.test_add_connect_options")
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    argv = ['--connection-password-file', 'D:/test/pass.txt']
    ns = parser.parse_args(argv)
    print(ns.connection_password_file)


# Generated at 2022-06-22 18:42:45.194296
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # Valid call AnsibleVersion
    ansible_version = to_native(version('ansible'))
    assert ansible_version == "ansible 2.8.0"
    # Invalid call AnsibleVersion
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--version', action='AnsibleVersion', nargs=0)
        args = parser.parse_args('--version'.split())
        assert(args)
    except SystemExit as e:
        assert(e.code == os.EX_OK)



# Generated at 2022-06-22 18:42:49.141812
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.cli.argparse.default import AnsibleOptions

    opt_parse = AnsibleOptions(['-t', 'tag1', '--tags', 'tag2', '--skip-tags', 'skip1,,skip2'])
    assert opt_parse.options.tags == ['tag1', 'tag2']
    assert opt_parse.options.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-22 18:42:58.598656
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_vars = [('@extravar', '@extravar'),
                 ('@/tmp/testfile', '@' + os.path.normpath('/tmp/testfile')),
                 ('@@/tmp/testfile', '@@/tmp/testfile'),
                 ('@@extravar', '@@extravar'),
                 ('@~/tmp/testfile', '@' + os.path.normpath('~/tmp/testfile')),
                 ('@~/tmp/tes|tfile', '@~/tmp/tes|tfile')]
    for var in test_vars:
        assert maybe_unfrack_path('@')(var[0]) == var[1]

# Generated at 2022-06-22 18:43:06.821704
# Unit test for function unfrack_path
def test_unfrack_path():
    assert '.' == unfrack_path()('.')
    assert C.DEFAULT_ROLES_PATH == unfrack_path()(C.DEFAULT_ROLES_PATH)
    assert unfrackpath(os.getcwd()) == unfrack_path()(os.getcwd())
    assert C.DEFAULT_ROLES_PATH == unfrack_path()(C.DEFAULT_ROLES_PATH + os.pathsep + os.getcwd())
    assert '- == stdin' == unfrack_path()('-')



# Generated at 2022-06-22 18:43:18.552681
# Unit test for function add_connect_options
def test_add_connect_options():
    option_groups = {}
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    pargs = parser.parse_args()
    pargs.syntax=False
    pargs.host_pattern = 'localhost'
    pargs.connection = 'local'
    pargs.user = 'ansible'
    pargs.verbosity = 1
    pargs.inventory = None
    pargs.subset = None
    pargs.module_paths = None
    pargs.forks = None
    pargs.check = False
    pargs.listhosts = None
    pargs.listtasks = None
    pargs.listtags = None
    pargs.step = None
    pargs.start_at_task = None
    pargs.sudo = False
    pargs.sudo_user

# Generated at 2022-06-22 18:43:29.901545
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    class AnsibleOptions(object):
        pass

    class AnsibleParser(argparse.ArgumentParser):
        def __init__(self):
            self.return_value = None
            self.error_message = None
        def error(self, message):
            self.error_message = message
        def exit(self, return_value=0):
            self.return_value = return_value
        def get_default(self, dest):
            return 'default'

    parser = AnsibleParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.add_argument('--not-defined', action=UnrecognizedArgument)
    options = AnsibleOptions()

    options_str = '--version'
    parser.parse_args(options_str.split(), namespace=options)

# Generated at 2022-06-22 18:43:33.633171
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    arg_string = '-K'
    args = parser.parse_args(arg_string.split())
    assert args.become_ask_pass



# Generated at 2022-06-22 18:43:38.047103
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # test the simple case.
    assert maybe_unfrack_path('#')('#/foo/bar') == '#' + unfrackpath('/foo/bar')

    # test that case where a leading '#' is extended
    assert maybe_unfrack_path('#')('##/foo/bar') == '##/foo/bar'



# Generated at 2022-06-22 18:43:49.787399
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    option_vault_id = "option_vault_id"
    option_ask_vault_pass = "option_ask_vault_pass"
    option_vault_password_files = "option_vault_password_files"

    # Test option vault_id
    option_value = "foo"
    args = parser.parse_args(["--vault-id", option_value])
    assert args.vault_ids[0] == option_value

    # Test option vault_id
    option_value = "bar"
    args = parser.parse_args(["--vault-id", option_value])
    assert args.vault_ids == [option_vault_id, option_value]

    # Test option

# Generated at 2022-06-22 18:43:56.731405
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'myinventoryfile', '-l', 'mylimit'])
    assert options.inventory == ['myinventoryfile'], options.inventory
    assert options.listhosts is False, options.listhosts
    assert options.subset == 'mylimit', options.subset



# Generated at 2022-06-22 18:44:00.028190
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = parser.parse_args(['-vvvv', '--verbose'])
    assert args.verbosity == 5, "unexpected verbosity"



# Generated at 2022-06-22 18:44:02.547011
# Unit test for function version
def test_version():
    from ansible import constants as C
    from ansible.module_utils.common.yaml import HAS_LIBYAML, yaml_load
    from ansible.utils.path import unfrackpath



# Generated at 2022-06-22 18:44:13.894964
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import nose
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    display.verbosity = 3
    loader = DataLoader()

    # Initialize parser
    parser = argparse.ArgumentParser(description='ansible', usage='%(prog)s [options]', formatter_class=ArgparseRawDescriptionHelpFormatter, add_help=False)
    parser.add_argument('--version', action=AnsibleVersion, version=__version__,
                        help='show program\'s version number and exit')
    parser.add_argument('-v', '--verbose', action='count', dest='verbosity', default=0,
                        help='verbose mode (-vvv for more, -vvvv to enable connection debugging)')
    parser.add_

# Generated at 2022-06-22 18:44:18.258235
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz']

# Generated at 2022-06-22 18:44:20.339779
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    result = _get_result()
    assert result.args.module_path[0] == './lib/ansible/modules/system'



# Generated at 2022-06-22 18:44:25.789731
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.parse_args([])
    assert parser.parse_args(['--playbook-dir', 'mypath'])
    assert parser.parse_args(['--playbook-dir', 'mypath'])



# Generated at 2022-06-22 18:44:32.082875
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    options = parser.parse_args(['-b', '--become-user', 'foo'])

    assert(options.become == True)
    assert(options.become_method == 'sudo')
    assert(options.become_user == 'foo')



# Generated at 2022-06-22 18:44:41.291158
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Test with option_strings
    option_strings = ['-o', '--option']
    dest = 'option'
    nargs = None
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = None
    metavar = None
    act = PrependListAction(option_strings, dest, nargs=nargs, const=const, default=default,
                            type=type, choices=choices, required=required, help=help, metavar=metavar)
    assert act.option_strings == option_strings
    assert act.dest == dest
    assert act.nargs == nargs
    assert act.const == const
    assert act.default == default
    assert act.type == type
    assert act.choices == choices
    assert act.required == required

# Generated at 2022-06-22 18:44:46.480119
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

    opts = parser.parse_args(['--private-key', 'id_rsa', '-c', 'ssh'])

    assert opts.private_key_file == 'id_rsa'
    assert opts.connection == 'ssh'



# Generated at 2022-06-22 18:44:51.334762
# Unit test for function add_fork_options
def test_add_fork_options():
    parser=argparse.ArgumentParser()
    add_fork_options(parser)
    try:
        parser.parse_args(['-f', '10'])
    except SystemExit as e:
        assert e.code==0
    except:
        assert False


# Generated at 2022-06-22 18:44:53.402877
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(["--task-timeout", "600"])
    assert args.task_timeout == 600



# Generated at 2022-06-22 18:45:00.534173
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    from ansible.cli import CLI
    my_parser = CLI.base_parser(constants.MODULE_PATH, None)
    add_tasknoplay_options(my_parser)
    my_args = my_parser.parse_args(['ansible', 'debug', '--task-timeout', '300'])
    assert my_args.task_timeout == 300



# Generated at 2022-06-22 18:45:09.027734
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    # create_base_parser() function can add --version and -v options
    parser=create_base_parser('test')
    add_connect_options(parser)
    options = parser.parse_args(['--key-file','/root/.ssh/id_rsa', '--user', 'root', '--connection', 'ssh', '--timeout', '30',
                                '--ssh-common-args', '-o ForwardAgent=yes', '--sftp-extra-args', '-f', '-l',
                                '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '--ask-pass', '--connection-password-file',
                                '/etc/passwd'])

# Generated at 2022-06-22 18:45:14.539555
# Unit test for function add_inventory_options
def test_add_inventory_options():
    """Test add_inventory_options function.
    The first test will add inventory option,
    the second test will add inventory option and -l option.
    """
    my_parser = argparse.ArgumentParser()
    add_inventory_options(my_parser)
    result1 = my_parser.parse_args(['-i', '/inventory_file'])
    assert result1.inventory == ['/inventory_file']

    my_parser = argparse.ArgumentParser()
    add_inventory_options(my_parser)
    result2 = my_parser.parse_args(['-i', '/inventory_file', '-l', 'all'])
    assert result2.inventory == ['/inventory_file']
    assert result2.subset == 'all'



# Generated at 2022-06-22 18:45:17.549803
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='')
    add_inventory_options(parser)
    assert parser._actions[2].metavar == "COMMA_SEP_HOSTLIST"


# Generated at 2022-06-22 18:45:22.690390
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--dest', action=PrependListAction, nargs='*')
    results = parser.parse_args(['--dest', 'a', '--dest', 'b', '--dest', 'c'])
    assert results.dest == ['c', 'b', 'a']



# Generated at 2022-06-22 18:45:24.062881
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog="test")
    add_module_options(parser)
    options = parser.parse_args([])
    assert 'module_path' in options
    
    

# Generated at 2022-06-22 18:45:29.154033
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-password-file', 'foo'])
    assert options.vault_password_files == ['foo']
    # TODO
    # FIXME


#
# Functions to process options
#


# Generated at 2022-06-22 18:45:41.032140
# Unit test for function add_runas_options
def test_add_runas_options():
    # Test normal flow
    parser_1 = argparse.ArgumentParser()
    add_runas_options(parser_1)
    args_1 = parser_1.parse_args(['-b', '--become', '--become-method', 'sudo'])
    assert args_1.become
    assert not args_1.runas_prompt
    assert args_1.become_method == 'sudo'

    # Test combine with add_runas_prompt_options()
    parser_2 = argparse.ArgumentParser()
    add_runas_options(parser_2)
    add_runas_prompt_options(parser_2)

# Generated at 2022-06-22 18:45:43.974494
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='PROGBAR')
    ns = argparse.Namespace()
    v = AnsibleVersion()
    v(parser, ns, [], None)



# Generated at 2022-06-22 18:45:55.991114
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import io

    class MockAction(argparse.Action):
        def __init__(self, option_strings, dest, nargs=None, const=None, default=None, type=None, choices=None,
                     required=False, help=None, metavar=None):
            self.option_strings = ['--' + x for x in option_strings]
        def __call__(self, parser, namespace, values, option_string=None):
            pass
    method = SortingHelpFormatter().add_arguments
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--alpha', action=MockAction)
    parser.add_argument('--zebra', action=MockAction)
    stream = io.StringIO()

# Generated at 2022-06-22 18:46:02.524425
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    data = parser.parse_args(['--ask-vault-password', '--vault-id', 'test'])
    assert data.vault_ids == ['test']
    assert data.ask_vault_pass
    assert getattr(data, 'vault_password_files', None) is None


# Generated at 2022-06-22 18:46:10.556695
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    try:
        import __main__
        __main__.__file__
    except AttributeError:
        print('Can not run unit test for class UnrecognizedArgument because class argparse.ArgumentParser will not'
              ' recognize __main__.__file__')
        sys.exit(0)

    # Test case 1: call constructor of class UnrecognizedArgument with valid positional argument option_strings
    UnrecognizedArgument(option_strings=['-v'], dest='verbosity', const=True, default=None, required=False,
                         help=None, metavar=None, nargs=0)

    # The following test case will cause the program to raise an exception.
    # if an exception is raised, the unit test will pass.

    # Test case 2: call constructor of class UnrecognizedArgument with invalid positional argument option_

# Generated at 2022-06-22 18:46:17.483134
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version == None
    assert parser._exit_code == 0
    assert parser._exit_message == to_native(version(parser.prog))


# Generated at 2022-06-22 18:46:22.560420
# Unit test for function add_runtask_options
def test_add_runtask_options():
    '''Unit test for function ansible.cli.helpers.add_runtask_options()'''
    parser = create_base_parser('ansible')
    add_runtask_options(parser)
    args = parser.parse_args([])
    assert args.extra_vars == []



# Generated at 2022-06-22 18:46:27.483571
# Unit test for function ensure_value
def test_ensure_value():
    import sys
    args = argparse.Namespace()
    ensure_value(args, 'foo', 'bar')
    if args.foo != 'bar':
        sys.exit(1)
    sys.exit(0)



# Generated at 2022-06-22 18:46:29.705118
# Unit test for function version
def test_version():
    ansible_version = version()
    assert type(ansible_version) == str


# Generated at 2022-06-22 18:46:39.789824
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    epilog = "example usage: ansible-doc -l"

# Generated at 2022-06-22 18:46:42.000417
# Unit test for function version
def test_version():
    assert version() != ''



# Generated at 2022-06-22 18:46:46.995165
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class Parser(object):
        def __init__(self):
            self.error = lambda *args, **kwargs: "{}".format(args)
    parser = Parser()
    namespace = argparse.Namespace()
    action = PrependListAction(parser, ["1", "2"], "dest", default=["3", "4"])
    action(namespace, [])
    assert getattr(namespace, "dest") == ["3", "4"]



# Generated at 2022-06-22 18:46:57.254107
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    with pytest.raises(SystemExit):
        parser = argparse.ArgumentParser()
        parser.add_argument('--foo', help='This is foo', action='store_true')
        parser.add_argument('-v', '--version', help="Show program's version number and exit", action='version', version=__version__)
        parser.add_argument('--version', help='Ansible Version', action='version', version=__version__)
        parser.add_argument('--version', help='Ansible Version', action='version', version=__version__)
        parser.add_argument('--version', help='Ansible Version', action='version', version=__version__)
        parser.add_argument('-v', '--version', action='version', version=__version__)

# Generated at 2022-06-22 18:47:01.295040
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    setattr(namespace, self.dest, items)
    setattr(namespace, self.dest, items)
    setattr(namespace, self.dest, items)
    setattr(namespace, self.dest, items)

# Generated at 2022-06-22 18:47:06.193479
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    
    class FakeArgs(object):
        def __init__(self, prog):
            self.prog = prog
    args = FakeArgs('ansible')
    av = AnsibleVersion('store')
    av.__call__(args, None, None, None)


# Generated at 2022-06-22 18:47:17.027760
# Unit test for function unfrack_path
def test_unfrack_path():
    with open(__file__, 'r') as f:
        fake_file = f.read()

    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    # fake opts

    options_file = None
    options_vars = []
    options_private_key_file = None
    options_playbook = None
    options_verbosity = 2
    options_listtags = False
    options_listtasks = False
    options_check = False
    options_syntax = None #check_syntax
    options_tags = []
    options_skip_tags = []
    options_start_at_task = None
    options_become = False
   

# Generated at 2022-06-22 18:47:28.342146
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from tests.lib.options.fixture_help_options import HelpOptions

    option_instance = HelpOptions()
    help_output = []
    f = SortingHelpFormatter(option_instance.parser)
    for option in option_instance.parser._actions:
        if option.help:
            help_output.append('\n'.join(f.expand_help(option)))
    # Help from options with no short option are on top
    assert help_output[0].startswith('-h') is False
    assert help_output[1].startswith('-h') is True
    # Check if options are sorted based on long option
    assert help_output[1].startswith('--version') is True
    assert help_output[2].startswith('--verbose') is True


# Generated at 2022-06-22 18:47:39.195023
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    def ns(argv):
        parser = argparse.ArgumentParser()
        add_runas_prompt_options(parser)
        return parser.parse_args(argv)
    assert ns(['-K']) == ns(['--ask-become-pass'])
    assert ns(['--become-password-file', '/etc/ansible/passwords/become']) == \
           ns(['--become-pass-file', '/etc/ansible/passwords/become'])
    assert ns(['--become-password-file', '-']) == ns(['--become-pass-file', '-'])



# Generated at 2022-06-22 18:47:45.151118
# Unit test for function add_basedir_options
def test_add_basedir_options():
    """
    test for function add_basedir_options
    """
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(["--playbook-dir", "/dev/null"])
    assert options.basedir == "/dev/null"
    assert C.config._Config__ctx.searchpath[0] == "/dev/null"



# Generated at 2022-06-22 18:47:58.416846
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import argparse
    # include the module-specific argument, so that the help can be
    # properly found in the testing environment
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-t', action=PrependListAction, nargs=1, metavar='T', dest='targets')
    parser.add_argument('-foo', nargs=1, action='append', metavar='a', dest='foos')
    parser.add_argument('-foo', nargs=1, action='append', metavar='b', dest='foos')
    parser.add_argument('-foo', nargs=1, action='append', metavar='c', dest='foos')

# Generated at 2022-06-22 18:48:02.319883
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    parser.parse_args(['--foo'])



# Generated at 2022-06-22 18:48:11.295794
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    opts = parser.parse_args('')
    # Check for defaults
    assert opts.become is False
    assert opts.become_method == C.DEFAULT_BECOME_METHOD
    # Check for new arguments
    assert hasattr(opts, 'become')
    assert hasattr(opts, 'become_method')
    assert hasattr(opts, 'become_user')
    # Check for boolean values
    assert opts.become == False



# Generated at 2022-06-22 18:48:17.540239
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """Test add_tasknoplay_options with parser"""

    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['-e', 'var=val'])
    assert args.extra_vars == ['var=val'], "Extra vars"
    assert not hasattr(args, 'roles_path')
    assert hasattr(args, 'task_timeout')

# Generated at 2022-06-22 18:48:19.754978
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser=argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args=parser.parse_known_args()
    assert all((args.become_ask_pass,args.become_password_file)==C.DEFAULT_BECOME_ASK_PASS)
    return True


# Generated at 2022-06-22 18:48:26.549405
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '1', '-B', '2'])
    assert options.poll_interval == 1 and options.seconds == 2

