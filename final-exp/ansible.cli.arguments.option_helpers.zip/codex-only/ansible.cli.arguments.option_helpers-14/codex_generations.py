

# Generated at 2022-06-22 18:38:32.149856
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_connect_options(parser)
    argv = ['-u', 'root', '-k', '--private-key=/path/to/key', '--ssh-common-args=1', '--sftp-extra-args=2',
            '--scp-extra-args=3', '--ssh-extra-args=4', '-T', '32', '--connection=ssh',
            '--connection-password-file=/path/to/password_file']
    parser.parse_args(argv)
    
    
    

# Generated at 2022-06-22 18:38:34.813201
# Unit test for function add_module_options
def test_add_module_options():
    arg_parser = argparse.ArgumentParser()
    add_module_options(arg_parser)
    arg_parser.parse_args(["--module-path", "path1:path2"])



# Generated at 2022-06-22 18:38:38.912726
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir',__file__])
    assert options.basedir == os.path.dirname(__file__)

# Generated at 2022-06-22 18:38:43.563134
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
    )
    add_runas_options(parser)
    options = parser.parse_args([])
    assert options.become is False
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user is None



# Generated at 2022-06-22 18:38:48.819870
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description='A test parser',
                                     formatter_class=SortingHelpFormatter)
    parser.add_argument('input_file', action='store', help='The input file')
    parser.add_argument('--output_file', action='store', help='The output file')
    parser.add_argument('-p', '--parameter', action='store', help='A pararmeter')

    (options, args) = parser.parse_known_args(args=['-h'])


# Generated at 2022-06-22 18:39:00.051190
# Unit test for function add_runas_options
def test_add_runas_options():
    # Note: These tests are incomplete!
    parser = argparse.ArgumentParser(description=" Test Parser ")
    add_runas_options(parser)
    add_runas_prompt_options(parser)
    # Test if options have been added
    assert('-b' in parser.format_help())
    assert('--become' in parser.format_help())
    assert('--become-method' in parser.format_help())
    assert('--become-user' in parser.format_help())
    assert('--become-ask-pass' in parser.format_help())
    assert('--ask-become-pass' in parser.format_help())
    # Test if the options have the correct type and default value
    assert(False == parser.parse_args([]).become)

# Generated at 2022-06-22 18:39:04.827167
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_meta_options(parser)
    output = parser.parse_known_args(['--flush-cache'])
    assert output[0].flush_cache
    output = parser.parse_known_args(['--force-handlers'])
    assert output[0].force_handlers



# Generated at 2022-06-22 18:39:05.903468
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
  parser = argparse.ArgumentParser()
  add_runas_prompt_options(parser)
  return parser.parse_args([])



# Generated at 2022-06-22 18:39:10.352507
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '1', '-B', '2'])
    assert args.poll_interval == 1
    assert args.seconds == 2


# Generated at 2022-06-22 18:39:13.611225
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', 'foo=bar', '-e', '@/path/to/file'])
    assert args.extra_vars == [{'foo': 'bar'}, '/path/to/file']
    args = parser.parse_args(['-e', '@/path/to/file', '-e', 'foo=bar'])
    assert args.extra_vars == ['/path/to/file', {'foo': 'bar'}]



# Generated at 2022-06-22 18:39:17.548945
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    a = UnrecognizedArgument(option_strings=['--ab'], dest='UAR_ab', help='unite test')
    assert len(a.option_strings) == 1
    assert a.option_strings[0] == '--ab'



# Generated at 2022-06-22 18:39:22.709177
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(description='test add_subset_options')
    add_subset_options(parser)

    result = parser.parse_args(['--tags', 'cron,apache', '--skip-tags', 'php'])
    assert result.tags == ['cron', 'apache']
    assert result.skip_tags == ['php']



# Generated at 2022-06-22 18:39:32.427562
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # GIVEN: An ansible option parser
    class MockAnsibleOptionParser(argparse.OptionParser):
        def error(self, errmsg):
            raise Exception(errmsg)

        def exit(self):
            pass
    # WHEN: I invoke method __call__ of UnrecognizedArgument class with an option string
    mock_parser = MockAnsibleOptionParser()
    try:
        bad_action = UnrecognizedArgument(option_strings=['-b', '--bad'], dest='bad', const=True, default=None, required=False, help=None, metavar=None, nargs=0)
        bad_action(mock_parser, None, None, option_string='-b')
    except Exception as err:
        # THEN: The exception is what I expect
        assert err.args[0]

# Generated at 2022-06-22 18:39:36.207079
# Unit test for function add_output_options
def test_add_output_options():
    """Unit test for function add_output_options"""
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', '/tmp/log'])
    assert args.tree == '/tmp/log'
# End of unit test for function add_output_options



# Generated at 2022-06-22 18:39:47.273448
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import ansible.cli.base_parser.base_parser  # noqa

# Generated at 2022-06-22 18:39:50.182705
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=argparse.ArgumentParser()
    add_meta_options(parser)
    options = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert options.force_handlers == True
    assert options.flush_cache == True



# Generated at 2022-06-22 18:39:59.976479
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs, collection_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collections_loader import AnsibleCollectionsLoader
    from ansible.utils.path import unfrackpath
    import sys


    loader = DataLoader()
    display = Display()
    add_all_plugin_dirs()


# Generated at 2022-06-22 18:40:11.420398
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    cmd = os.path.basename(sys.argv[0])
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)

    # Bad option
    (args, extra) = parser.parse_known_args(["-p", "10"])
    if getattr(args, "task_timeout", "not set") != "not set":
        raise Exception("")

    # Valid option
    (args, extra) = parser.parse_known_args(["-t", "10"])
    if getattr(args, "task_timeout", "not set") == "not set":
        raise Exception("")

    # Validate negative value will raise an error

# Generated at 2022-06-22 18:40:22.507766
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    import os
    import tempfile
    from ansible.cli.arguments import OptionParser
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-22 18:40:31.189923
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from argparse import Namespace
    from ansible.module_utils.common.args import PrependListAction
    #
    # Constructor
    #
    action = PrependListAction(option_strings=['-a', '--append'], dest='name')
    #
    # Testing method __call__
    #
    namespace = Namespace(name=[])
    action(None, namespace, ['value1', 'value2'], '--append')
    msg = "namespace.name is not as expected: ['value1', 'value2'] != {0}".format(namespace.name)
    assert namespace.name == ['value1', 'value2'], msg
    namespace = Namespace(name=['value3'])

# Generated at 2022-06-22 18:40:34.597343
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = create_base_parser('ansible', '', '', '')
    add_tasknoplay_options(parser)
    options = parser.parse_args(['--task-timeout', '10'])
    assert options.task_timeout == 10



# Generated at 2022-06-22 18:40:40.185790
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansibleVersion = AnsibleVersion('store', 'version', 'help')
    # Using __call__() to test the constructor
    parser = argparse.ArgumentParser()
    parser.prog = 'prog'
    ansibleVersion(parser, None, None)


#
# utility functions for optparse
#

#
# Option callback functions
#

# Generated at 2022-06-22 18:40:44.955326
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace(object):
        pass
    test_namespace = FakeNamespace()
    test_namespace.test_attribute = []
    ensure_value(test_namespace, 'test_attribute', []).append('a')
    assert test_namespace.test_attribute == ['a']
    ensure_value(test_namespace, 'test_attribute', []).append('b')
    assert test_namespace.test_attribute == ['a', 'b']



# Generated at 2022-06-22 18:40:47.870553
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = MockCLI()
    add_vault_options(parser)
    assert parser.option_list.get('--vault-id')
    assert parser.option_list.get('--ask-vault-password')
    assert parser.option_list.get('--vault-password-file')



# Generated at 2022-06-22 18:40:55.432088
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    opts = parser.parse_args(['-e', '@/file.yml', '-e', '@/file.json', '-e', '@/file.txt', '-e', 'key1=val1', '-e', 'key2=val2'])
    assert opts.extra_vars == ['/file.yml', '/file.json', '/file.txt', 'key1=val1', 'key2=val2']



# Generated at 2022-06-22 18:40:59.288359
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser('ansible-program', desc='a program')
    add_verbosity_options(parser)
    assert '-v' in [x.option_strings for x in parser._actions][0]
    assert '--verbose' in [x.option_strings for x in parser._actions][0]



# Generated at 2022-06-22 18:41:07.117209
# Unit test for function unfrack_path
def test_unfrack_path():
    def check(value, result):
        assert unfrack_path(pathsep=False)(value) == result

    # Ensure appropriate prefixes work
    for prefix in ('~', '~/', '/', 'file:', 'file:'):
        check(prefix + '/foo', '/foo')

    # Ensure $HOME/.ansible prefix works
    check('foo', os.path.join(os.path.expanduser('~'), '.ansible', 'foo'))
    check('/foo', '/foo')



# Generated at 2022-06-22 18:41:16.244892
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runas_prompt_options(parser)
    yaml_output = parser.parse_args(['-K'])
    assert yaml_output.become_ask_pass == True
    yaml_output = parser.parse_args(['--become-password-file'])
    assert yaml_output.become_password_file == C.BECOME_PASSWORD_FILE
    yaml_output = parser.parse_args(['-k', '--become-password-file', 'filename'])
    assert yaml_output.become_ask_pass == False
    assert yaml_output.become_password_file == 'filename'


# Generated at 2022-06-22 18:41:20.365458
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = to_native(version(""))
    if __version__ in ansible_version and j2_version in ansible_version and \
            ansible.__copyright__ in ansible_version:
        return True
    else:
        return False



# Generated at 2022-06-22 18:41:24.602473
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-playbook'
    AnsibleVersion('-V')(parser, None, None, '-V')
    return True


# Generated at 2022-06-22 18:41:29.384528
# Unit test for function add_subset_options
def test_add_subset_options():
    """Unit test for function add_subset_options"""
    parser = argparse.ArgumentParser(description="test for add_subset_options")
    add_subset_options(parser)
    args = vars(parser.parse_args(['-t', 'abc', '--tags', 'def', '--skip-tags', 'ghi', '--skip-tags', 'jkl']))
    assert args['skip_tags'] == ['ghi', 'jkl']
    assert args['tags'] == ['abc', 'def']


# Generated at 2022-06-22 18:41:36.900222
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # import argparse
    # from argparse import Action
    # from argparse import ArgumentParser
    # from ansible.cli.argparse import UnrecognizedArgument
    p = argparse.ArgumentParser()
    p.add_argument('foo', action=UnrecognizedArgument)
    with p.parse_args(''):
        pass  # it will raise SystemExit with error when error occurs
    with p.parse_args('foo=bar'.split()):
        pass  # it will raise SystemExit with error when error occurs



# Generated at 2022-06-22 18:41:40.327797
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.cli.arguments import OptionParser
    parser = OptionParser(add_async_options)
    options = parser.parse_args(['-B'])
    assert options.seconds == 0



# Generated at 2022-06-22 18:41:49.369025
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options, args = parser.parse_known_args(["-i", "host1", "-i", "host2", "--inventory", "host3,host4"])
    assert options.inventory == ['host1', 'host2', 'host3,host4']

    options, args = parser.parse_known_args(["--list-hosts"])
    assert options.listhosts is True

    options, args = parser.parse_known_args(["-l", "subset"])
    assert options.subset == "subset"



# Generated at 2022-06-22 18:41:55.216917
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(
        ['-b', '--become-method', 'sudo', '--become-user', 'espuser'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'espuser'



# Generated at 2022-06-22 18:41:57.988869
# Unit test for function add_basedir_options
def test_add_basedir_options():

    args = ['testfile.yml', '-i', 'localhost,']
    parser = argparse.ArgumentParser(
        prog = 'test',
        formatter_class = SortingHelpFormatter,
        conflict_handler = 'resolve',
    )
    add_basedir_options(parser)
    args = parser.parse_args(args)

# Generated at 2022-06-22 18:41:59.569367
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """ Test AnsibleModule.add_runas_prompt_options """
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    return parser

# Generated at 2022-06-22 18:42:00.525970
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    _ = add_verbosity_options(None)



# Generated at 2022-06-22 18:42:12.140983
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.utils.display import Display
    from ansible.parsing import vault

    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
    )

    add_async_options(parser)

    args = parser.parse_args(['--poll', '0'])
    assert args.poll_interval == 0

    # set password to ensure that it is not logged
    vault_pass = 'a vault pass'
    display = Display()
    vault_id = 'test_ovault'
    vault.VaultLib(vault_pass).write_file(vault_id, 'test')

    args = parser.parse_args(['--vault-id', '{0}'.format(vault_id), '--background', '120'])


# Generated at 2022-06-22 18:42:19.654151
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=SortingHelpFormatter,
                                     add_help=False)
    group = parser.add_argument_group()
    group.add_argument('-c', '--color', action='store_true', help='color')
    group.add_argument('-b', '--debug', action='store_true', help='debug')
    parser.parse_args([])
    assert '-b' < '-c'
    assert '--debug' < '--color'
    parser.parse_args(['-h'])



# Generated at 2022-06-22 18:42:27.739813
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    def argparse_error_handler(e):
        print('Argument not parsed error is handled')
        print(e)
    # Initialize parser
    parser = create_base_parser(prog='ansible-runner', usage="usage: %(prog)s [options]")
    # Get the option values
    try:
        args = parser.parse_args(
            ['--version'], error_handler=argparse_error_handler)
    except SystemExit:
        pass



# Generated at 2022-06-22 18:42:31.547006
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    l = []
    ensure_value(ns, 'l', l)
    assert ns.l is l
    assert ns.l is not l



# Generated at 2022-06-22 18:42:43.136245
# Unit test for function ensure_value
def test_ensure_value():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--something', type=int, action=PrependListAction)
    args = parser.parse_args([])
    # E1  - return empty list if not set
    value = ensure_value(args, 'something', [])
    assert not value
    # E2  - return the list if set
    value = ensure_value(args, 'something', [])
    assert value == args.something
    # E3  - set the list if not set
    value = ensure_value(args, 'something', [42])
    assert value == args.something
    # E4  - do not change the list if set
    value = ensure_value(args, 'something', [43])
    assert value == args.something



# Generated at 2022-06-22 18:42:46.038099
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('ansible-test')
    args = parser.parse_args(['--version'])
    assert args.version == True


# Generated at 2022-06-22 18:42:49.685127
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog=__name__, conflict_handler='resolve')
    add_connect_options(parser)
    parser.parse_args()



# Generated at 2022-06-22 18:42:53.851717
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(args=['-i', 'hosts', '--list-hosts', '-l', 'pattern'])
    assert options.inventory == ['hosts'], "could not process -i option"
    assert options.listhosts is True, "could not process --list-hosts option"
    assert options.subset == 'pattern', "could not process -l option"

# end of unit test for function add_inventory_options



# Generated at 2022-06-22 18:42:56.821759
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible',
                                     formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve')
    add_check_options(parser)
    args = parser.parse_args(['-C', '-D'])
    assert args.check == True
    assert args.diff == True
    assert args.syntax == False
# end unit test



# Generated at 2022-06-22 18:42:59.417941
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    Unit test for function add_runas_prompt_options
    """
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_prompt_options(parser)
    args = parser.parse_args([])
    assert args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS
    assert args.become_password_file == C.BECOME_PASSWORD_FILE



# Generated at 2022-06-22 18:43:04.937424
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='unit-test', formatter_class=SortingHelpFormatter,)
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', './test'])
    assert args.basedir == os.path.join(os.getcwd(), 'test')

# Generated at 2022-06-22 18:43:11.187983
# Unit test for function add_connect_options
def test_add_connect_options():
    """ this function tests the add_connect_options function on parser """
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    parser.parse_args(['--private-key', 'file.pem', '--user', 'user', '--connection', 'ssh', '--timeout', '10', '--ssh-common-args', 'common', '--sftp-extra-args', 'extra', '--scp-extra-args', 'extra', '--ssh-extra-args', 'extra', '-k'])



# Generated at 2022-06-22 18:43:19.188875
# Unit test for function add_connect_options
def test_add_connect_options():
    """Unit test for function add_connect_options"""

    parser = argparse.ArgumentParser(prog='ansible-inventory')
    add_connect_options(parser)
    parser.add_argument('--list', action='store_true', help='List active servers')
    parser.add_argument('--host', help='Get all information about specified host', type=str)
    inventory_args = parser.parse_args('--list'.split())
    assert inventory_args.list is True
    assert inventory_args.host is None
    assert inventory_args.private_key_file == '~/.ssh/id_rsa'
    assert inventory_args.remote_user == 'root'
    assert inventory_args.connection == 'smart'
    assert inventory_args.timeout == 10
    assert inventory_args.ssh_common_args is None


# Generated at 2022-06-22 18:43:30.052231
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    args = []
    parser = argparse.ArgumentParser()
    parser.add_argument(dest='item', action=PrependListAction)
    parser.add_argument('item2', action='store')
    parser.add_argument('-f', '--flag', action='append', default=[])
    parser.add_argument('-s', '--sum')
    results = parser.parse_args(args, namespace=SimpleNamespace())
    assert results.item == []
    assert results.item2 == None
    assert results.flag == []
    assert results.sum == None
    args = ['first', 'second', '--flag', 'a1', '-s', '-1', '--flag', 'a2']
    results = parser.parse_args(args, namespace=SimpleNamespace())

# Generated at 2022-06-22 18:43:35.566412
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-c", "--command")
    parser.add_argument("--colour")
    parser.add_argument("--ansible")
    help_output = parser.format_help()
    assert help_output.index("-c, --command") < help_output.index("--ansible") < help_output.index("--colour")



# Generated at 2022-06-22 18:43:40.293388
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible.cli import CLI

    base_parser = create_base_parser('any module')
    add_fork_options(base_parser)
    cli = CLI(base_parser)

    assert cli.parser.get_default('forks') == C.DEFAULT_FORKS, 'Forks default should be 5'
    assert cli.options.forks == C.DEFAULT_FORKS, 'Forks default should be 5'



# Generated at 2022-06-22 18:43:43.232197
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.cli.arguments import PrependListAction
    a = PrependListAction

# Generated at 2022-06-22 18:43:45.902919
# Unit test for function add_meta_options
def test_add_meta_options():
   parser = argparse.ArgumentParser()
   add_meta_options(parser)
   args = parser.parse_args('--flush-cache'.split())
   assert args.flush_cache == True
   args = parser.parse_args('--force-handlers'.split())
   assert args.force_handlers == True
   args = parser.parse_args('-k'.split())
   assert args.ask_pass == True



# Generated at 2022-06-22 18:43:57.604340
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    from ansible.utils.collection_loader import AnsibleCollectionLoader


# Generated at 2022-06-22 18:44:04.774459
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from argparse import ArgumentParser
    from datetime import datetime
    parser = ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(["-e", "var1=var1", "-e", "@var.json", "-e", "var2=var2"])
    assert isinstance(args.extra_vars, list)
    assert args.extra_vars[0] == "var1=var1"
    assert args.extra_vars[1] == '@var.json'
    assert args.extra_vars[2] == 'var2=var2'



# Generated at 2022-06-22 18:44:14.669274
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-f")
    parser.add_argument("-a", action="store_true")
    parser.add_argument("-d", action="store_false")
    parser.add_argument("-v")
    parser.add_argument("-t")
    parser.add_argument("-b", action="store_true")
    parser.add_argument("-c", action="store_false")
    parser.add_argument("-e")
    parser.add_argument("-g")
    parser.add_argument("-w")
    parser.add_argument("-x")
    parser.add_argument("-y")
    parser.add_argument("-z")
    parser.add_argument("-q")

# Generated at 2022-06-22 18:44:16.002405
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    return parser

# Generated at 2022-06-22 18:44:18.409879
# Unit test for function unfrack_path
def test_unfrack_path():
    current_dir = os.path.dirname(__file__)
    assert unfrack_path()('.') == unfrackpath('.')
    assert unfrack_path()(current_dir) == unfrackpath(current_dir)



# Generated at 2022-06-22 18:44:20.840771
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    program = 'ansible-lint'
    ap = argparse.ArgumentParser(prog=program)
    AnsibleVersion(prog=program)



# Generated at 2022-06-22 18:44:28.425521
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser('test')
    add_inventory_options(parser)
    options, args = parser.parse_known_args(['-i', 'test/test/test,test', '--list-hosts', '-l', 'test'])
    assert options.inventory == ['test/test/test,test']
    assert options.listhosts is True
    assert options.subset == 'test'



# Generated at 2022-06-22 18:44:29.298069
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__(): pass



# Generated at 2022-06-22 18:44:33.552775
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(
        prog="add_fork_options",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )

    add_fork_options(parser)
    args = parser.parse_args(['--forks', '5'])
    assert args.forks == 5


# Generated at 2022-06-22 18:44:35.421113
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    version_ansible = AnsibleVersion(['--version'], {'dest': 'version'})



# Generated at 2022-06-22 18:44:41.863934
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', dest='version', action=AnsibleVersion)
    options = parser.parse_args(['--version'])
    assert options.version
# End of unit test for method __call__ of class AnsibleVersion



# Generated at 2022-06-22 18:44:52.461673
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import tempfile
    from io import StringIO
    from ansible.utils import context_objects as co
    from ansible.config.manager import ConfigManager
    from ansible.cli import CLI

    # Initialize test context
    # FIXME: this needs to be simplified by exposing relevant objects to test_utils.get_cli_runner()
    co.GlobalCLIArgs = CLI.base_parser('').parse_args([])
    co.GlobalCLIArgs.explicit_subcommand = True
    co.GlobalCLIArgs.subcommand = 'version'
    config_manager = ConfigManager(cli_args=co.GlobalCLIArgs)
    co.GlobalCLIConfig = config_manager.get_config()

# Generated at 2022-06-22 18:44:55.585108
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = parser.parse_args(['--verbose', '--verbose', '--verbose'])
    assert args.verbosity == 3

# Generated at 2022-06-22 18:45:01.657636
# Unit test for function create_base_parser
def test_create_base_parser():
    from ansible.cli.arguments import Options

    argv = ("--version","--v","-vvvv")
    prog = "ansible"
    desc = "this is a test"
    epilog = "this is an epilog"

    opts = Options()
    parser = create_base_parser(prog, desc=desc, epilog=epilog)

    cmd_opts = vars(parser.parse_args(argv))
    options = vars(opts)
    options['stdout_callback'] = None
    assert cmd_opts == options

# Generated at 2022-06-22 18:45:05.077736
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()

    ensure_value(namespace, 'foo', 1)
    ensure_value(namespace, 'bar', 2)

    assert namespace.foo == 1
    assert namespace.bar == 2


# common code between ansible and ansible-playbook

# Generated at 2022-06-22 18:45:12.279154
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)
    assert parser.add_argument.call_count == 2
    args, kwargs = parser.add_argument.call_args_list[0]
    assert args[0] == '--force-handlers'
    assert kwargs['default'] == C.DEFAULT_FORCE_HANDLERS
    assert kwargs['dest'] == 'force_handlers'
    assert kwargs['action'] == 'store_true'
    assert kwargs['help'] == "run handlers even if a task fails"
    args, kwargs = parser.add_argument.call_args_list[1]
    assert args[0] == '--flush-cache'
    assert kwargs['dest'] == 'flush_cache'

# Generated at 2022-06-22 18:45:20.847896
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    with open("test_add_vault_options.json") as f:
        data = json.load(f)
    args = parser.parse_args(data['add_vault_options']['args'])
    assert args.vault_ids == data['add_vault_options']['vault_ids']
    assert args.ask_vault_pass == data['add_vault_options']['ask_vault_pass']
    assert args.vault_password_files == data['add_vault_options']['vault_password_files']

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-22 18:45:25.389532
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    from ansible.cli.arguments import options
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableMapping
    import json

    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(["--task-timeout", "1"])
    assert isinstance(args.extra_vars, list)
    assert args.task_timeout == 1

# Generated at 2022-06-22 18:45:29.949848
# Unit test for function add_inventory_options
def test_add_inventory_options():
    test_cli = "/usr/bin/ansible-playbook --list-hosts"
    parser = create_base_parser()
    add_inventory_options(parser)
    options = parser.parse_args(shlex.split(test_cli))
    assert options.listhosts ==True



# Generated at 2022-06-22 18:45:36.178508
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('-l', action=PrependListAction)
    args = arg_parser.parse_args(['-l', '1', '-l', '2', '-l', '3'])
    assert args.l[0] == '1'
    assert args.l[1] == '2'
    assert args.l[2] == '3'



# Generated at 2022-06-22 18:45:41.749449
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test = maybe_unfrack_path(beacon='@')

    assert test('@/test') == '@' + unfrackpath('./test')
    assert test('test') == 'test'
    assert test('@@/test') == '@@/test'
    assert test('@@@/test') == '@@@/test'



# Generated at 2022-06-22 18:45:49.996490
# Unit test for function unfrack_path
def test_unfrack_path():
    # expects to get unified path from input path
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo//bar///baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/../bar/../../baz') == '/baz'
    assert unfrack_path()('/tmp/foo/../bar/../../baz/') == '/baz'
    # expects to get raw input path
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('a') == 'a'

# Generated at 2022-06-22 18:46:00.427250
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    class TestArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            return True

    parser = TestArgumentParser()
    # The '*' requires a non-empty value for nargs. It is necessary for testing
    parser.add_argument(
        '--unrecognized',
        action=UnrecognizedArgument,
        help='unrecognized options',
        nargs='*'
    )

    (options, args) = parser.parse_known_args(['--unrecognized', '-t', '-u'])
    print(options.unrecognized)
    # The options.unrecognized is ['-t', '-u']

# Generated at 2022-06-22 18:46:06.763546
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.cli.arguments import add_async_options
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    assert len(parser._actions) == 2
    args = parser.parse_args(['-P', '3', '-B', '25'])
    assert args.poll_interval == 3
    assert args.seconds == 25



# Generated at 2022-06-22 18:46:16.495502
# Unit test for function add_runtask_options
def test_add_runtask_options():
    test_parser = argparse.ArgumentParser(description='Test parser')
    add_runtask_options(test_parser)
    # setup test vars
    test_extra_vars = [
        "thisvar=thatvar",
        "@thisvar_file.yml",
        "@thisvar_file.json"
    ]
    expected_extra_vars = [
        "thisvar=thatvar",
        "@/unfracked/path/to/thisvar_file.yml",
        "@/unfracked/path/to/thisvar_file.json"
    ]
    # run test
    for ev in test_extra_vars:
        test_args = ['--extra-vars', ev]
        result = test_parser.parse_args(test_args)
        assert 'extra_vars'

# Generated at 2022-06-22 18:46:26.815753
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser(prog='test')
    add_verbosity_options(parser)
    args = parser.parse_args(args=['--verbose'])
    assert args.verbosity == 1
    assert getattr(args, 'verbose', None) is None
    args = parser.parse_args(args=['-v'])
    assert args.verbosity == 1
    assert getattr(args, 'verbose', None) is None
    args = parser.parse_args(args=['-vvv'])
    assert args.verbosity == 3
    args = parser.parse_args(args=['-vvvv'])
    assert args.verbosity == 4
    assert getattr(args, 'verbose', None) is None



# Generated at 2022-06-22 18:46:27.797833
# Unit test for function create_base_parser
def test_create_base_parser():
    create_base_parser('ansible-program')



# Generated at 2022-06-22 18:46:38.918436
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    test_AnsibleVersion = AnsibleVersion(option_strings=['-v', '--version'])
    # Constructor test
    assert test_AnsibleVersion
    assert test_AnsibleVersion.const == 0
    assert test_AnsibleVersion.nargs == 0
    assert test_AnsibleVersion.default == argparse.SUPPRESS
    assert test_AnsibleVersion.type == None
    assert test_AnsibleVersion.choices == None
    assert test_AnsibleVersion.required == False
    assert test_AnsibleVersion.help == None
    assert test_AnsibleVersion.metavar == None
    assert test_AnsibleVersion.dest == None
    assert test_AnsibleVersion.option_strings == ['-v', '--version']
    assert test_AnsibleVersion.__call

# Generated at 2022-06-22 18:46:44.619767
# Unit test for function add_inventory_options
def test_add_inventory_options():
    """
    Test that add_inventory_options() works
    """
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i','my_inventory','--list-hosts','-l','localhost'])
    if args.inventory != ['my_inventory']:
        raise AssertionError('The inventory option was not parsed correctly')
    if args.listhosts != True:
        raise AssertionError('The listhosts option was not parsed correctly')
    if args.subset != 'localhost':
        raise AssertionError('The subset option was not parsed correctly')



# Generated at 2022-06-22 18:46:56.097924
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)

    args = parser.parse_args(['-P5', '-B100'])
    assert args.poll_interval == 5
    assert args.seconds == 100

    args = parser.parse_args(['-P-1'])
    assert args.poll_interval == -1

    # Invalid poll interval, i.e. non-integer
    try:
        args = parser.parse_args(['-P foo'])
    except SystemExit:
        pass
    else:
        assert 'poll_interval is not an integer'

    # Invalid background execution time, i.e. non-integer
    try:
        args = parser.parse_args(['-B bar'])
    except SystemExit:
        pass

# Generated at 2022-06-22 18:46:57.308505
# Unit test for function add_output_options
def test_add_output_options():
    add_output_options(ArgumentParser())
# Test ends


# Generated at 2022-06-22 18:46:59.664666
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    main(['-V'])
    sys.modules.pop("ansible.cli.action")


# Generated at 2022-06-22 18:47:03.743695
# Unit test for function ensure_value
def test_ensure_value():
    class namespace:
        pass

    test_list = []
    ensure_value(namespace, 'test_list', test_list)
    assert id(getattr(namespace, 'test_list')) == id(test_list)

    getattr(namespace, 'test_list').append(1)
    ensure_value(namespace, 'test_list', test_list)
    assert id(getattr(namespace, 'test_list')) == id(test_list)

    assert getattr(namespace, 'test_list') == [1]



# Generated at 2022-06-22 18:47:07.121249
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class Namespace(object):
        pass
    namespace = Namespace()
    namespace.foo = ['old_value_1', 'old_value_2']
    new_value = ['new_value']
    prependlistaction = PrependListAction(option_strings = ['-f', '--foo'], dest = 'foo', nargs=1)
    prependlistaction.__call__(parser = None, namespace = namespace, values = new_value, option_string = None)
    assert namespace.foo == ['new_value', 'old_value_1', 'old_value_2']


# Generated at 2022-06-22 18:47:12.068112
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--foo', action=UnrecognizedArgument)
    try:
        parser.parse_args('-f'.split())
    except SystemExit as e:
        assert e.code == 2
    else:
        assert False



# Generated at 2022-06-22 18:47:17.068624
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from ansible.utils.path import is_path_safe
    parser = argparse.ArgumentParser(prog='ansible')
    add_basedir_options(parser)
    args = parser.parse_args(["--playbook-dir", "/tmp/foo/bar"])
    assert args.basedir == "/tmp/foo/bar"
    assert is_path_safe("/tmp/foo/bar")



# Generated at 2022-06-22 18:47:22.725653
# Unit test for function add_meta_options
def test_add_meta_options():
    """Test function.add_meta_options"""
    parser = argparse.ArgumentParser(
        prog='test_add_meta_options',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_meta_options(parser)
    assert parser._actions[-1].dest == 'flush_cache'
    assert parser._actions[-2].dest == 'force_handlers'



# Generated at 2022-06-22 18:47:27.664304
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    test_parser = argparse.ArgumentParser()
    add_verbosity_options(test_parser)
    known_args, extra_args = test_parser.parse_known_args(['-vvvv'])

    assert known_args.verbosity == 4



# Generated at 2022-06-22 18:47:33.217819
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser(description='test program')
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    argv = ['--version']
    args = parser.parse_args(argv)
    assert args.version is None



# Generated at 2022-06-22 18:47:43.716468
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Make a derived class to expose protected __init__ and _get_value methods
    class TestPrependListAction(PrependListAction):
        def __init__(self, option_strings, dest, **kwargs):
            super(TestPrependListAction, self).__init__(option_strings, dest, **kwargs)

        def _get_value(self, namespace):
            return super(TestPrependListAction, self)._get_value(namespace)

    # Check for required nargs > 0, if const is provided
    try:
        action = TestPrependListAction(['-t'], 'test', const=0, nargs=0)
        assert False, "Should have raised an exception"
    except ValueError:
        pass

    # Check for required nargs=OPTIONAL if const is provided,
    # but n

# Generated at 2022-06-22 18:47:45.967323
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser("test")
    add_verbosity_options(parser)
    args = parser.parse_args([])
    assert args.verbosity == C.DEFAULT_VERBOSITY



# Generated at 2022-06-22 18:47:59.110048
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(description="add_runtask_options")
    add_runtask_options(parser)

# Generated at 2022-06-22 18:48:03.083232
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    results = parser.parse_args(['--check', '--syntax-check', "--diff"])
    assert results.check is True
    assert results.syntax is True
    assert results.diff is True


# Generated at 2022-06-22 18:48:15.263773
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter,
            description="Test SortingHelpFormatter")

    parser.add_argument('-c', nargs='?', type=str,
                        help='set an alternate config file')
    parser.add_argument('-D', '--directory', nargs='?', type=str,
                        help='change lib/ansible/modules/ directory')
    parser.add_argument('--list-deps', nargs='?', type=str,
                        help='list dependencies for module')
    parser.add_argument('-i', '--inventory-file', nargs='?', type=str,
                        help='specify inventory host file (default=/etc/ansible/hosts)')

# Generated at 2022-06-22 18:48:19.381725
# Unit test for function add_check_options
def test_add_check_options():

    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '--diff'])
    assert args.check and args.syntax and args.diff

#
# Functions to add pre-canned parser options to an existing OptionParser
#



# Generated at 2022-06-22 18:48:28.215058
# Unit test for function add_runas_options
def test_add_runas_options():
    """
    Make sure that the expected defaults are present in the command
    line arguments when add_runas_options is called.
    """
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    args = parser.parse_args('')

    assert args.become == C.DEFAULT_BECOME
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user == None

