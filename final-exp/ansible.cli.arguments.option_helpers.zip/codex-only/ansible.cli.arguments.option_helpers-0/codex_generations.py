

# Generated at 2022-06-22 18:38:36.798942
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = Mock()

    add_runas_prompt_options(parser)


# Generated at 2022-06-22 18:38:41.379881
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():

    # Create class with variable bind to its constructor
    ansibleVersion = AnsibleVersion('--version')

    # Create a mock parser with a string as its version
    mock_parser_version = argparse.ArgumentParser('0.0.1')

    # Create a mock function with a return value as None
    mock_parser_exit = lambda: None

    # Add above mock function to a dummy class
    class mock_parser():
        def exit():
            return mock_parser_exit

    # Assign mock class to a variable
    mock_parser_variable = mock_parser

    # Assign 'version' and 'exit' to mock parser
    mock_parser_variable.version = mock_parser_version
    mock_parser_variable.exit = mock_parser_exit

    # Call action function in class ansibleVersion

# Generated at 2022-06-22 18:38:46.716816
# Unit test for function add_module_options
def test_add_module_options():
    def foo(m):
        return "foo"
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options, args = parser.parse_known_args(["-M", "bar"])
    assert options.module_path == 'bar'
    options, args = parser.parse_known_args(["-M", "foo%sbar" % os.pathsep])
    assert options.module_path == 'bar' + os.pathsep + 'foo'
    options, args = parser.parse_known_args(["-M", "%sfoo%sbar" % (os.pathsep, os.pathsep)])
    assert options.module_path == 'bar' + os.pathsep + 'foo'

# Generated at 2022-06-22 18:38:54.231743
# Unit test for function add_check_options
def test_add_check_options():
    class Options(object):
        def __init__(self):
            self.check = False
            self.syntax = False
            self.diff = False
    options = Options()
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        description='Ansible Runner',
        usage='%(prog)s [options]',
        conflict_handler='resolve'
    )
    add_check_options(parser)
    parser.parse_args(['--check', '--syntax-check', '--diff'], options)
    assert options.check == True
    assert options.syntax == True
    assert options.diff == True



# Generated at 2022-06-22 18:38:58.360826
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['--become', '--become-user', 'root', '--become-method', 'su'])
    assert not args.prompt_su_pass
    assert args.become
    assert args.become_user == 'root'
    assert args.become_method == 'su'


# Generated at 2022-06-22 18:39:06.252522
# Unit test for function add_basedir_options
def test_add_basedir_options():
    p = create_base_parser('/bin/ansible')
    add_basedir_options(p)
    #to_native cast turns byte strings into Unicode strings
    x = to_native(p.parse_args(['--playbook-dir', C.config.get_config_value('PLAYBOOK_DIR') ]))
    assert x.basedir == unfrackpath(C.config.get_config_value('PLAYBOOK_DIR'))
    y = to_native(p.parse_args(['--playbook-dir', '/dev/null' ]))
    assert y.basedir  == unfrackpath('/dev/null')


# Generated at 2022-06-22 18:39:07.734924
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '5'])
    assert args.forks == 5


# Generated at 2022-06-22 18:39:16.805456
# Unit test for function add_runas_options
def test_add_runas_options():
    module = AnsibleModule(
        argument_spec = dict()
    )
    parser = module.parser

    # Run with no arguments.
    add_runas_options(parser)
    parsed_args = parser.parse_args([])
    # Note that this is the value we set in v2_runner.
    assert parsed_args.become_user == 'root'

    # Run again with a different user.
    add_runas_options(parser)
    parsed_args = parser.parse_args(['--become-user', 'test'])
    assert parsed_args.become_user == 'test'


# Generated at 2022-06-22 18:39:21.636617
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    parser.add_argument('--foo', action=UnrecognizedArgument, nargs=0)
    try:
        parser.parse_args(['--foo'])
    except SystemExit:
        return
    assert False, 'should have failed'



# Generated at 2022-06-22 18:39:26.562582
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    result = str(parser.parse_args(['--force-handlers', '--flush-cache']))
    assert '--force-handlers' in result
    assert '--flush-cache' in result
# Unit test ends


# Generated at 2022-06-22 18:39:28.219457
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_module_options(parser)
    (options, args) = parser.parse_known_args(['-M', ''])
    assert options.module_path is None



# Generated at 2022-06-22 18:39:31.216954
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    p = argparse.ArgumentParser()
    p.add_argument('--test', action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        p.parse_args(['--test'])
#
# Special purpose OptionParsers
#


# Generated at 2022-06-22 18:39:33.028357
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    (options, args) = parser.parse_known_args(['-M', '/foo/bar', '-M', '/baz'])
    assert options.module_path == ['/baz', '/foo/bar']


# Generated at 2022-06-22 18:39:34.749469
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(
        prog='test_add_runtask_options',
        description='test add_runtask_options function'
    )
    add_runtask_options(parser)
    parser.parse_args(args=[__file__])



# Generated at 2022-06-22 18:39:41.602021
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # create the formatter object
    formatter = SortingHelpFormatter()
    # create an argument parser
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    # add arguments to the parser
    parser.add_argument('-b', '--bar')
    parser.add_argument('-c', '--baz')
    parser.add_argument('-a', '--foo')
    # formatter stores a parser object in self._parser
    # we can infer the output of add_arguments of formatter
    # from the structure of that parser object
    # so we make sure the output of formatter.add_argument
    # has the expected structure
    add_arguments_output = parser.format_help()

# Generated at 2022-06-22 18:39:46.394793
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.errors import AnsibleOptionsError
    from ansible.utils.display import Display
    display = Display()
    if not os.path.exists('/tmp/ansible_test_unfrack_path.log'):
        open('/tmp/ansible_test_unfrack_path.log', 'w').close()
        assert os.path.exists('/tmp/ansible_test_unfrack_path.log')

# Generated at 2022-06-22 18:39:51.594924
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    argp = argparse.ArgumentParser(add_help=False)
    argp.add_argument('--foo', action=UnrecognizedArgument)
    foo_args = ['--foo', 'bar', 'zzz']
    with pytest.raises(SystemExit) as exc:
        argp.parse_args(foo_args)
    assert exc.value.code == 2


# Generated at 2022-06-22 18:39:58.068830
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--version', action=AnsibleVersion)
    parser.add_argument('-m', '--module-path', action=UnrecognizedArgument, help='unrecognized arguments')
    args = parser.parse_args()
    assert args.module_path


#
# Used by ansibullbot/runner.py
#

# Generated at 2022-06-22 18:40:03.306816
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args("")
    assert args.force_handlers == False, 'test_add_meta_options assert#1 has failed.'
    assert args.flush_cache == False, 'test_add_meta_options assert#2 has failed.'
    args = parser.parse_args("--force-handlers --flush-cache")
    assert args.force_handlers == True, 'test_add_meta_options assert#3 has failed.'
    assert args.flush_cache == True, 'test_add_meta_options assert#4 has failed.'


# Generated at 2022-06-22 18:40:11.698078
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    ua = UnrecognizedArgument(['-u'], 'unrecognized_arg', nargs=0)
    assert ua.nargs == 0
    assert ua.const is True
    assert ua.default is None
    assert ua.required is False
    assert ua.help is None
    assert ua.metavar is None
    assert ua.dest == 'unrecognized_arg'
    assert ua.option_strings == ['-u']



# Generated at 2022-06-22 18:40:15.978272
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve', prog='test_prog')
    add_verbosity_options(parser)
    # Parser is created and options added.
    # Just testing if options added successfully.
    assert parser.get_default('verbosity') == 0


# Generated at 2022-06-22 18:40:21.932894
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('a') == unfrack_path()('b') == os.path.realpath('a')
    assert unfrack_path(True)('a' + os.path.pathsep + 'b') == [os.path.realpath('a'), os.path.realpath('b')]
    assert unfrack_path()('-') == '-'

#
# OptionGroups
#

# Generated at 2022-06-22 18:40:26.450462
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    assert 'unrecognized arguments: -X' == \
           UnrecognizedArgument('-X', 'dest_X')\
           .__call__(argparse.ArgumentParser(description='description'),
                     argparse.Namespace(), values='-X', option_string='-X')\
           .args[0]



# Generated at 2022-06-22 18:40:30.940354
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='append')
    parser.add_argument('-b', action=PrependListAction)
    namespace = parser.parse_args('-a 1 -a 2 -b 1 -b 2'.split())
    assert namespace.a == ['1', '2']
    assert namespace.b == ['1', '2']

# Generated at 2022-06-22 18:40:41.635826
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = ['--private-key', 'test_path', '-u', 'test_user', '-c', 'test_connection', '-T', 'test_timeout',
            '--ssh-common-args', 'test_ssh_common_args', '--sftp-extra-args', 'test_sftp_extra_args',
            '--scp-extra-args', 'test_scp_extra_args', '--ssh-extra-args', 'test_ssh_extra_args',
            '-k', '--connection-password-file', 'test_connection_password_file']
    parsed = parser.parse_args(args)
    assert parsed.private_key_file == 'test_path'
    assert parsed.remote_user

# Generated at 2022-06-22 18:40:53.321905
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('#')('#/usr/local') == '#/usr/local'
    # Trailing slashes should be preserved
    assert maybe_unfrack_path('#')('#/usr/local/') == '#/usr/local/'
    assert maybe_unfrack_path('#')('/usr/local') == '/usr/local'
    assert maybe_unfrack_path('#')('/usr/local/') == '/usr/local/'
    assert maybe_unfrack_path('#')('#relative') == '#' + unfrackpath('relative')



# Generated at 2022-06-22 18:41:02.060716
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args([])
    assert options.connection == C.DEFAULT_TRANSPORT
    assert options.remote_user == C.DEFAULT_REMOTE_USER
    assert options.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert options.timeout == C.DEFAULT_TIMEOUT

    # ssh only
    assert options.scp_extra_args is None
    assert options.sftp_extra_args is None
    assert options.ssh_common_args is None
    assert options.ssh_extra_args is None

    # password
    assert options.ask_pass == C.DEFAULT_ASK_PASS
    assert options.connection_password_file == C.CONNECTION_PASSW

# Generated at 2022-06-22 18:41:04.311632
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)


# Generated at 2022-06-22 18:41:07.765964
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = to_native(version(__file__))
    assert 'ansible' in ansible_version
    assert __version__ in ansible_version



# Generated at 2022-06-22 18:41:14.361149
# Unit test for function version
def test_version():
    os.chdir(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..'))
    assert version().splitlines()[0] == "%s [core %s]" % (os.path.basename(sys.argv[0]), __version__)
    assert version().splitlines()[-1] == "  libyaml = %s" % HAS_LIBYAML

# vim: set expandtab:ts=4:sw=4:

# Generated at 2022-06-22 18:41:15.697493
# Unit test for function create_base_parser
def test_create_base_parser():
    our_parser = create_base_parser("test","","test")
    our_parser.print_help()



# Generated at 2022-06-22 18:41:20.276456
# Unit test for function add_inventory_options
def test_add_inventory_options():
    #
    # Test add_inventory_options() by running it against a mock OptionParser
    # object.
    #
    # We don't actually care about the resulting object, just that the
    # function calls don't crash.
    #
    parser = Mock()
    add_inventory_options(parser)



# Generated at 2022-06-22 18:41:26.194467
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@") == "@"
    assert maybe_unfrack_path("@")("@@") == "@@"
    assert maybe_unfrack_path("@")("@foo") == "@" + unfrackpath("foo")
    assert maybe_unfrack_path("@")("@@foo") == "@@foo"
    assert maybe_unfrack_path("@")("foo") == "foo"



# Generated at 2022-06-22 18:41:31.202972
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert (maybe_unfrack_path('@')('@/tmp')) == '@/tmp'
    if os.path.sep != '/':
        assert (maybe_unfrack_path('@')('@\\tmp')) == '@/tmp'
    assert (maybe_unfrack_path('@')('~/tmp')) == '~/tmp'



# Generated at 2022-06-22 18:41:41.540172
# Unit test for function version

# Generated at 2022-06-22 18:41:46.887838
# Unit test for function add_runas_options
def test_add_runas_options():
    """
    Unit test for function add_runas_options
    """
    parser = argparse.ArgumentParser(description='Ansible')
    add_runas_options(parser)
    args_true = parser.parse_args('--become -K'.split())
    assert args_true.become



# Generated at 2022-06-22 18:41:55.172780
# Unit test for function ensure_value
def test_ensure_value():
    class n:
        pass

    setattr(n, 'foo', None)
    ensure_value(n, 'foo', 'bar')
    assert n.foo == 'bar'
    assert ensure_value(n, 'foo', 'baz') == 'bar'

    del n.foo
    ensure_value(n, 'foo', 'quux')
    assert n.foo == 'quux'
    assert ensure_value(n, 'foo', 'thud') == 'quux'


#
# Module Parsers
#

# Generated at 2022-06-22 18:42:00.396888
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='Sample for add_runas_options')
    add_runas_options(parser)
    result = parser.parse_known_args(['--help'])[0]
    expected = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, description='Sample for add_runas_options')
    expected_group = expected.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")
    expected_group.add_argument("-b", "--become", default=C.DEFAULT_BECOME, action="store_true", dest='become',
                             help="run operations with become (does not imply password prompting)")

# Generated at 2022-06-22 18:42:07.236585
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_fork_options(parser)
    try:
        parser.parse_args(['-f','t','--forks','1','--','1','2','3','4','5','6','7','8'])
    except SystemExit:
        assert True
    else:
        assert False
test_add_fork_options()


# Generated at 2022-06-22 18:42:17.853783
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import StringIO
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-a", action='store_true', help="Option_A")
    parser.add_argument("-b", action='store_true', help="Option_B")
    parser.add_argument("-c", action='store_true', help="Option_C")
    parser.add_argument("-d", action='store_true', help="Option_D")
    parser.add_argument("-e", action='store_true', help="Option_E")
    parser.add_argument("-f", action='store_true', help="Option_F")
    parser.add_argument("-g", action='store_true', help="Option_G")

# Generated at 2022-06-22 18:42:23.515500
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass

    namespace = Namespace()

    ensure_value(namespace, 'foo', False)
    assert namespace.foo is False

    ensure_value(namespace, 'bar', True)
    assert namespace.bar is True

    ensure_value(namespace, 'foo', True)
    assert namespace.foo is False



# Generated at 2022-06-22 18:42:32.607026
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """Class 'PrependListAction' unit test"""
    def _test_input(test_input):
        """Test the test_input"""
        parser = argparse.ArgumentParser()
        parser.add_argument('-a', action=PrependListAction)
        args = parser.parse_args(test_input)
        return getattr(args, 'a')


# Generated at 2022-06-22 18:42:39.405805
# Unit test for function add_check_options
def test_add_check_options():
    parser1 = argparse.ArgumentParser()
    parser2 = argparse.ArgumentParser()
    add_check_options(parser1)
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser1.parse_args(["-C"])
    check = pytest_wrapped_e.value.code
    assert check == 0

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser1.parse_args(["--check"])
    check = pytest_wrapped_e.value.code
    assert check == 0

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser1.parse_args(["--syntax-check"])
    check = pytest_wrapped_e.value.code

# Generated at 2022-06-22 18:42:46.891084
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = SortingHelpFormatter()
    try:
        parser.add_arguments(argparse.HelpFormatter().add_argument('foo'))
    except TypeError:
        # We have python 2.6
        pass
    else:
        cmds = ['-b', '-a', '-c']
        try:
            parser.add_arguments(argparse.HelpFormatter(cmds).add_argument('foo'))
        except TypeError:
            # We have python 2.6
            pass
        else:
            assert cmds == ['-a', '-b', '-c']



# Generated at 2022-06-22 18:42:53.555210
# Unit test for function ensure_value
def test_ensure_value():
    assert ensure_value(None, 'foo', []) == []
    assert ensure_value(None, 'foo', '') == ''
    assert ensure_value(argparse.Namespace(), 'foo', []) == []
    assert ensure_value(argparse.Namespace(foo=None), 'foo', []) == []
    assert ensure_value(argparse.Namespace(foo=[]), 'foo', []) == []



# Generated at 2022-06-22 18:42:57.441631
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version",
                        action=AnsibleVersion,
                        nargs=0)
    opts = parser.parse_args(['-v'])
    assert opts.version == to_native(__version__)


# Generated at 2022-06-22 18:42:59.878761
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    base_args = ["-t", "test"]
    (args, _) = parser.parse_known_args(args=base_args)
    assert args.tree == "test"
    base_args = ["-o"]
    (args, _) = parser.parse_known_args(args=base_args)
    assert args.one_line



# Generated at 2022-06-22 18:43:06.158139
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class FakeActions:
        def __init__(self, option_strings):
            self.option_strings = option_strings
    formatter = SortingHelpFormatter()
    actions = [FakeActions(("-x",)), FakeActions(("-b",)), FakeActions(("-a",))]
    formatter.add_arguments(actions)

#
# Options
#

# Generated at 2022-06-22 18:43:13.818060
# Unit test for function add_module_options

# Generated at 2022-06-22 18:43:16.309958
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    action = PrependListAction(['-b'], 'bar', nargs=1, metavar='metavar')
    assert action.nargs == argparse.OPTIONAL



# Generated at 2022-06-22 18:43:21.841020
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    parser.add_argument('-D', '--diff', dest='diff', action='store_true',
                        help="when changing (small) files and templates, show the differences in those"
                             " files; works great with --check")
    opts = parser.parse_args(['-f', '-ff', '--forks', '5', '-D'])

    assert opts.forks == 5
    assert opts.diff



# Generated at 2022-06-22 18:43:28.131636
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_argparser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    test_argparser.add_argument("-b", action="store_true", help="Test -b opition")
    test_argparser.add_argument("-d", action="store_true", help="Test -d opition")
    test_argparser.add_argument("-a", action="store_true", help="Test -a opition")
    test_argparser.add_argument("-c", action="store_true", help="Test -c opition")
    test_args = test_argparser.parse_args(['-h'])


# Generated at 2022-06-22 18:43:33.507868
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser('test')
    add_meta_options(parser)
    opts, args = parser.parse_known_args(['--flush-cache', '--force-handlers'])

    assert opts.flush_cache is True and opts.force_handlers is True



# Generated at 2022-06-22 18:43:35.219180
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)


# Generated at 2022-06-22 18:43:40.014889
# Unit test for function ensure_value
def test_ensure_value():
    class A(object):
        pass
    a = A()
    assert ensure_value(a, 'b', 0) == 0
    a.b = 1
    assert ensure_value(a, 'b', 0) == 1
    ensure_value(a, 'c', [])
    assert a.c == []
    ensure_value(a, 'c', [1])
    assert a.c == [1]



# Generated at 2022-06-22 18:43:51.951135
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    parser = add_vault_options(parser)
    parser.print_help()
    print("")
    subparsers = parser.add_subparsers()
    parser_create = subparsers.add_parser('create')
    parser_create = add_vault_options(parser_create)
    parser_create.print_help()
    print("")
    parser_decrypt = subparsers.add_parser('decrypt')
    parser_decrypt = add_vault_options(parser_decrypt)
    parser_decrypt.print_help()
    print("")
    parser_edit = subparsers.add_parser('edit')
    parser_edit = add_vault_options(parser_edit)
    parser_edit.print_help()

# Generated at 2022-06-22 18:44:01.144535
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action=PrependListAction)
    options = parser.parse_args(['--list', 'last'])
    assert options.list == ['last']

    options = parser.parse_args(['--list', 'last', '--list=first'])
    assert options.list == ['first', 'last']

    options = parser.parse_args(['--list', 'one', 'two', '--list=first', 'second', 'third'])
    assert options.list == ['first', 'second', 'third', 'one', 'two']



# Generated at 2022-06-22 18:44:10.523093
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = Mock()

    add_runas_options(parser)

    parser.add_argument_group.assert_called_with("Privilege Escalation Options", "control how and which user you become as on target hosts")
    parser.add_argument_group.return_value.add_argument.assert_any_call("-b", "--become", default=C.DEFAULT_BECOME, action="store_true", dest='become',
                             help="run operations with become (does not imply password prompting)")

# Generated at 2022-06-22 18:44:16.508972
# Unit test for function ensure_value
def test_ensure_value():
    without = argparse.Namespace()
    ensure_value(without, 'hello', 'world')
    assert without.hello == 'world'

    with_other_value = argparse.Namespace()
    setattr(with_other_value, 'hello', 'goodbye')
    ensure_value(with_other_value, 'hello', 'world')
    assert with_other_value.hello == 'goodbye'


# Generated at 2022-06-22 18:44:27.994909
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()

    parser.add_argument('--version', action=AnsibleVersion, default=argparse.SUPPRESS)

    parser.add_argument('--foo', action=UnrecognizedArgument, help='This does nothing.')

    parser.add_argument('--bar', action=UnrecognizedArgument, help='This does nothing too.')

    parser.add_argument('--legit', action='store_true', default=False)

    args = parser.parse_args(['--foo'])
    if args.legit != False:
        raise Exception('legit is not false')

    args = parser.parse_args(['--bar'])
    if args.legit != False:
        raise Exception('legit is not false')

    args = parser.parse_args(['--legit'])

# Generated at 2022-06-22 18:44:38.878715
# Unit test for function version
def test_version():
    ''' test version output '''
    import os
    import sys
    import unittest
    import tempfile
    from ansible.module_utils.common.version import version

    # Can't import ansible.constants without this
    os.environ['ANSIBLE_CONFIG'] = 'bogus'

    class TestModule(unittest.TestCase):
        def test_version(self):
            test_args = []
            test_args.append('')
            file_name = tempfile.NamedTemporaryFile().name
            with open(file_name, "w+") as config_file:
                config_file.write(version())
            results = open(file_name).read()
            self.assertIn('config file = ', results)
            self.assertIn('configured module search path = ', results)


# Generated at 2022-06-22 18:44:45.155451
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    options = parser.parse_args(['-K', '--become-password-file=/tmp/blah'])

    assert options.become_ask_pass
    assert options.become_password_file == '/tmp/blah'



# Generated at 2022-06-22 18:44:46.254898
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__(): pass



# Generated at 2022-06-22 18:44:51.125044
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog="myprog", usage="my usage", desc="my desc", epilog="my epilog")
    assert parser.epilog == "my epilog\n"
    assert parser.description == "my desc\n"


#

# Generated at 2022-06-22 18:44:56.198421
# Unit test for function add_module_options
def test_add_module_options():
    options = {}
    parser = argparse.ArgumentParser(description='Test')
    add_module_options(parser)
    argv = ['-M', 'path/to/my/modules']
    args = parser.parse_args(argv)
    assert isinstance(args, argparse.Namespace)
    assert args.module_path == ['path/to/my/modules', module_path]



# Generated at 2022-06-22 18:44:57.540740
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    pass



# Generated at 2022-06-22 18:45:07.795352
# Unit test for function add_runas_options
def test_add_runas_options():
    # add_runas_options() is actually a function within a function, so the unit
    # test has to call the outer one.
    for fcn in [add_runas_options]:
        parser = argparse.ArgumentParser()
        fcn(parser)
        opts = parser.parse_args([])
        assert opts.become is False
        assert opts.become_method == C.DEFAULT_BECOME_METHOD
        assert opts.become_user == C.DEFAULT_BECOME_USER
        assert opts.ask_become_pass is False
        assert opts.ask_su_pass is False
        assert opts.ask_sudo_pass is False
        assert opts.ask_vault_pass is False
        assert opts.become_ask_pass is False
        opts

# Generated at 2022-06-22 18:45:14.365032
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'ID1', '--vault-id', 'ID2', '--ask-vault-pass', '--vault-pass-file', 'FILE1', '--vault-password-file', 'FILE2'])
    assert args.vault_ids == ['ID1', 'ID2'], "'vault_ids' is not set to ['ID1', 'ID2']"
    assert args.ask_vault_pass is True, "'ask_vault_pass' is not set to True"
    assert args.vault_password_files == ['FILE1', 'FILE2'], "'vault_password_files' is not set to ['FILE1', 'FILE2']"




# Generated at 2022-06-22 18:45:23.530238
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = MyParser([])
    namespace = argparse.Namespace()
    values = "values"
    option_string = "option_string"
    parser.exit = MagicMock()
    ansible_version = to_native(version(getattr(parser, 'prog')))
    with patch('ansible.cli.argparse.parser.version', new=ansible_version) as mock_version:
        ansible_version = to_native(version(getattr(parser, 'prog')))
        assert ansible_version == mock_version(getattr(parser, 'prog'))
        mock_version.assert_called_once_with('test')
        mock_print.assert_called_once_with(ansible_version)
        parser.exit.assert_called_once()


#
# Main funcs
#

# Generated at 2022-06-22 18:45:29.458323
# Unit test for function version
def test_version():
    assert "2.1.1" in version()
    assert " [core 2.1.1]" in version("A")
    assert "A [core 2.1.1]" in version("A")
    assert "A [core 1.2.3]" in version("A", "1.2.3")
    assert "A [core 1.2.3]" in version("A")
    assert "1.2.3" in version(prog="")
    assert "1.2.3" in version(prog=None)

# Generated at 2022-06-22 18:45:35.218666
# Unit test for function add_connect_options
def test_add_connect_options():
    # tests:
    #   ansible-console -h
    #   ansible-doc -h
    #   ansible-galaxy -h
    #   ansible-inventory -h
    #   ansible-vault -h
    main_prog = ['ansible-console', 'ansible-doc', 'ansible-galaxy', 'ansible-inventory', 'ansible-vault']
    for prog in main_prog:
        parser = create_base_parser(prog)
        add_connect_options(parser)
        # option that should be defined

# Generated at 2022-06-22 18:45:38.904071
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from ansible.cli import CLI
    cli = CLI(args=[])
    cli.parse()
    assert cli.options.basedir == C.config.get_config_value('PLAYBOOK_DIR')
    


# Generated at 2022-06-22 18:45:42.449035
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args()
    assert not args.tags
    assert not args.skip_tags
    assert args.tags == []
    assert args.skip_tags == []



# Generated at 2022-06-22 18:45:47.040571
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible_test._internal.compat import exit_json
    test_args = ['ansible-test']
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', dest='foo', action='store_true')
    args = parser.parse_args(test_args)
    print("args = %s" % args)

# Generated at 2022-06-22 18:45:49.426018
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version('zang.py'))


#
# Main Parser
#

# Generated at 2022-06-22 18:45:57.277487
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # constructor of class UnrecognizedArgument can accept empty positional and option arguments.
    UnrecognizedArgument([], '')
    # constructor of class UnrecognizedArgument can not accept positional argument which is not empty.
    try:
        UnrecognizedArgument(['positional_arg'], '')
    except:
        pass
    else:
        raise Exception()
    # constructor of class UnrecognizedArgument can accept option argument which is not empty.
    UnrecognizedArgument(['--option_arg'], '')

#
# Utility functions
#

# We have to use the builtin function here, because the AnsibleModule class
# uses this to determine if we are running as a script.

# Generated at 2022-06-22 18:46:10.169977
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    #set logging to warning
    logger.setLevel(logging.WARNING)
    add_runtask_options(parser)

    with pytest.raises(SystemExit) as cm:
        parser.parse_args(['-e', '@'])
    assert cm.value.code == 1

    with pytest.raises(SystemExit) as cm:
        parser.parse_args(['-e', '@file'])
    assert cm.value.code == 1

    with pytest.raises(SystemExit) as cm:
        parser.parse_args(['-e', '@file'])
    assert cm.value.code == 1


# Generated at 2022-06-22 18:46:15.084712
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(description='Process some integers.')
    add_runtask_options(parser)
    args = parser.parse_args(["-e", "@/etc/ansible/hosts", "-e", "@test_file.yml", "-e", "item1=val1"])
    assert args.extra_vars == ["/etc/ansible/hosts", "@test_file.yml", "item1=val1"]



# Generated at 2022-06-22 18:46:19.146954
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    example = UnrecognizedArgument(['--example'])
    with pytest.raises(SystemExit):
        example(parser, None, None, '--example')

# Generated at 2022-06-22 18:46:22.205226
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser_object = argparse.ArgumentParser(prog="test")
    add_verbosity_options(parser_object)
    options = parser_object.parse_args(['-vvvv'])
    assert 4 == options.verbosity



# Generated at 2022-06-22 18:46:26.820537
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args()
    assert not args.become_ask_pass



# Generated at 2022-06-22 18:46:30.671449
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class FakeNamespace:
        pass
    action = PrependListAction(dest='foo', metavar='bar')
    namespace = FakeNamespace()
    action(namespace, ['baz'])
    return namespace.foo == ['baz']



# Generated at 2022-06-22 18:46:34.984757
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f')
    parser.add_argument('-x', action=UnrecognizedArgument)
    parser.parse_args(['-f', 'foo', '-x'])  # Raises exception as expected



# Generated at 2022-06-22 18:46:38.908386
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)

    fake_args = ['-C', '--syntax-check', '-D']
    args = parser.parse_args(fake_args)

    assert args.check is True
    assert args.syntax is True
    assert args.diff is True


# Generated at 2022-06-22 18:46:40.799791
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    myargs=parser.parse_args()



# Generated at 2022-06-22 18:46:46.820148
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args([])
    assert not args.vault_ids
    assert not args.ask_vault_pass
    assert not args.vault_password_files
    # vault-id
    args = parser.parse_args(['--vault-id', 'vault1'])
    assert args.vault_ids == ['vault1']
    assert not args.ask_vault_pass
    assert not args.vault_password_files
    args = parser.parse_args(['--vault-id', 'vault1', '--vault-id', 'vault2'])
    assert args.vault_ids == ['vault1', 'vault2']
    assert not args.ask_vault

# Generated at 2022-06-22 18:46:47.412078
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass


# Generated at 2022-06-22 18:46:51.945963
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert options.check
    assert options.syntax
    assert options.diff


# Generated at 2022-06-22 18:46:54.234284
# Unit test for function add_async_options
def test_add_async_options():
    o = argparse.ArgumentParser()
    a = add_async_options(o)
    assert a is None



# Generated at 2022-06-22 18:47:01.166362
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import argparse
    pa = PrependListAction(option_strings=[], dest='dest', nargs=None, const=None, default=[], type=None, choices=None, required=False, help=None, metavar=None)
    parser = argparse.ArgumentParser()
    namespace = parser.parse_args([])
    namespace.dest = None
    pa(parser=parser, namespace=namespace, values=['a'])
    assert namespace.dest == ['a']
    pa(parser=parser, namespace=namespace, values=['b'])
    assert namespace.dest == ['b', 'a']
    pa(parser=parser, namespace=namespace, values=['c', 'd'])
    assert namespace.dest == ['c', 'd', 'b', 'a']



# Generated at 2022-06-22 18:47:13.511445
# Unit test for function add_vault_options
def test_add_vault_options():
    # Create new parser object
    parser = argparse.ArgumentParser()
    # Test add_vault_options function
    add_vault_options(parser)

    # Add arguments to parser object
    args = parser.parse_args(['--vault-id', 'A', '--vault-password-file', 'B'])

    # Test the type of created args object
    test_type = type(args)
    assert test_type is argparse._ActionsContainer, "Incorrect type of created object"

    # Test the values
    assert args.vault_ids[0] is 'A', "Incorrect value of vault_id"
    assert args.vault_password_files[0] is 'B', "Incorrect value of vault_password_file"



# Generated at 2022-06-22 18:47:19.074468
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible-inventory')
    add_inventory_options(parser)
    myargs = parser.parse_args()
    assert myargs.inventory is None
    assert myargs.listhosts is False
    assert myargs.subset is None

    myargs = parser.parse_args(['-i hosts'])
    assert myargs.inventory == ['hosts']
    assert myargs.listhosts is False
    assert myargs.subset is None

    myargs = parser.parse_args(['-i hosts', '-i another/hosts', '-i foo.cfg'])
    assert myargs.inventory == ['hosts', 'another/hosts', 'foo.cfg']
    assert myargs.listhosts is False
    assert myargs.subset is None

    myargs

# Generated at 2022-06-22 18:47:22.143231
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args('-P 85 -B 100'.split())
    assert args.seconds == 100
    assert args.poll_interval == 85


# Generated at 2022-06-22 18:47:29.175423
# Unit test for function add_output_options
def test_add_output_options():
    collection = 'ansible.builtin'
    name = 'setup'
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    parser._ansible_module_collections.append(collection)
    parser._ansible_module_name.append(name)
    opts, args = parser.parse_known_args()
    assert opts.tree is None



# Generated at 2022-06-22 18:47:36.022943
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    p.add_argument('--foo', action=PrependListAction)
    assert p.parse_args(['--foo', 'a', '--foo', 'b']).foo == ['b', 'a']


#
# get_bin_path() - Find the first occurrence of a specific binary in the
# provided path list
#

# Generated at 2022-06-22 18:47:42.515603
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='foo')
    a = add_meta_options(parser)
    assert a.__name__ == "store_true" # check that the argparse has the right type
    args = parser.parse_args("-f".split())
    assert args.force_handlers is True # check that the argparse is setting the right value
    assert vars(args).get("flush_cache") is None # check that the argparse isn't setting this value


# Generated at 2022-06-22 18:47:55.773572
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from collections import namedtuple
    #
    def test_it(caption, actions, result):
        class FakeAction:
            def __init__(self, option_strings):
                self.option_strings = option_strings
            def __repr__(self):
                return "{0}({1!r})".format(self.__class__.__name__, self.option_strings)
        #
        actions = [FakeAction(a) for a in actions]
        formatter = SortingHelpFormatter()
        result = [FakeAction(a) for a in result]
        formatter.add_arguments(actions)
        assert actions == result
    #
    test_it('basic, no args',
            ['a', 'b'],
            ['a', 'b'])

# Generated at 2022-06-22 18:48:00.189191
# Unit test for function add_async_options
def test_add_async_options():
    testargs = ['--poll', '30' , '--background', '30']
    parser = create_base_parser('test', 'test')
    add_async_options(parser)
    args, unknown = parser.parse_known_args(testargs)
    assert args.poll_interval == 30
    assert args.seconds == 30



# Generated at 2022-06-22 18:48:05.454242
# Unit test for function add_fork_options
def test_add_fork_options():
    # create an option parser object
    parser = create_base_parser('test_add_fork_options')    
    # add options
    add_fork_options(parser)
    # parse args
    args = vars(parser.parse_args())
    assert args['forks'] == C.DEFAULT_FORKS



# Generated at 2022-06-22 18:48:09.700849
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'test'])
    assert options.basedir == "test"



# Generated at 2022-06-22 18:48:17.211920
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(add_help=False)

    try:
        p = UnrecognizedArgument()
    except SystemError:
        pass

    try:
        p = UnrecognizedArgument(u'unrecognized')
    except SystemError:
        pass

    try:
        p = UnrecognizedArgument(u'unrecognized', u'dest')
    except SystemError:
        pass

    p = UnrecognizedArgument(u'unrecognized', u'dest', required=True)
    p = UnrecognizedArgument(u'unrecognized', u'dest', help=u'required help')



# Generated at 2022-06-22 18:48:24.276390
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # All defined
    PrependListAction(['-f', '--file'], 'file', nargs=None, const='default_value', default=None,
                      type=None, choices=None, required=False, help=None, metavar=None)

    # Required arguments
    PrependListAction(['-f', '--file'], 'file')

    # Default values
    PrependListAction(['-f', '--file'], 'file', nargs=None, const=None, default=None,
                      type=None, choices=None, required=False, help=None, metavar=None)

    # Optional arguments, nargs == argparse.OPTIONAL

# Generated at 2022-06-22 18:48:31.518617
# Unit test for method __call__ of class AnsibleVersion