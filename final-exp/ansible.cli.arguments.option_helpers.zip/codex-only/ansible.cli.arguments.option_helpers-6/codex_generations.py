

# Generated at 2022-06-22 18:38:30.629723
# Unit test for function add_runtask_options
def test_add_runtask_options():
    """Test function add_runtask_options."""
    parser = create_base_parser("ansible")
    add_runtask_options(parser)
    return parser.parse_args([""])



# Generated at 2022-06-22 18:38:34.020115
# Unit test for function add_check_options
def test_add_check_options():
    p = argparse.ArgumentParser()
    add_check_options(p)
    argv = shlex.split('--check')
    options = p.parse_args(argv)
    assert options.check



# Generated at 2022-06-22 18:38:40.913604
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['--tags', 'foo', '--tags', 'bar', '--skip-tags', 'baz'])
    assert args.tags == ['foo', 'bar']
    assert args.skip_tags == ['baz']



# Generated at 2022-06-22 18:38:43.067592
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    result = parser.parse_args(["--version"])
    parser.exit()


# Generated at 2022-06-22 18:38:53.216802
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    p = argparse.ArgumentParser()
    p.formatter_class = SortingHelpFormatter

    p.add_argument('-z', action='store')
    p.add_argument('-x', action='store')
    p.add_argument('-a', action='store')
    p.add_argument('-c', action='store')

    p.add_argument('--zz', action='store')
    p.add_argument('--aa', action='store')
    p.add_argument('--xx', action='store')
    p.add_argument('--cc', action='store')

    output = p.format_help()
    assert output.find('-a') < output.find('-c')
    assert output.find('-x') < output.find('-z')

# Generated at 2022-06-22 18:38:57.195451
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog="test")
    add_async_options(parser)
    options = parser.parse_args(["-B", "60"])
    assert options.seconds == 60



# Generated at 2022-06-22 18:39:02.434066
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    assert parser.parse_args([]).become_ask_pass == C.DEFAULT_BECOME_ASK_PASS
    assert parser.parse_args(['-K']).become_ask_pass == True
    assert parser.parse_args(['--ask-become-pass']).become_ask_pass == True
    assert parser.parse_args(['--become-password-file=/path/to/file', '-K']).become_password_file == '/path/to/file'
    assert parser.parse_args(['-K', '--become-password-file=/path/to/file']).become_password_file == '/path/to/file'



# Generated at 2022-06-22 18:39:09.868013
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(prog='ansible-config')
    parser.add_argument("-f", "--file", action=UnrecognizedArgument)
    parser.add_argument("-c", "--config", action=UnrecognizedArgument)
    parser.add_argument("-k", action=UnrecognizedArgument)
    parser.add_argument("-k", action=UnrecognizedArgument)
    parser.add_argument("-u", "--user", action=UnrecognizedArgument)
    parser.add_argument("-K", "--ask-become-pass", action=UnrecognizedArgument)
    parser.add_argument("-T", "--timeout", action=UnrecognizedArgument)
    parser.add_argument("--private-key", action=UnrecognizedArgument)




# Generated at 2022-06-22 18:39:20.761324
# Unit test for function version
def test_version():
    assert version('ansible') == 'ansible [core 2.9.8] (d0bff6c36f610049aa81c70d9bb208f6c3441bc0) last updated 2019/11/22 14:01:05 (GMT -0500)  config file = /root/.ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3.6/site-packages/ansible\n  ansible collection location = /root/ansible/ansible_collections\n  executable location = /root/ansible/ansible/bin/ansible\n  python version = 3.6.8 (default, Oct  7 2019, 12:59:55)\n  jinja version = 2.10.1\n  libyaml = False'

# Generated at 2022-06-22 18:39:29.853468
# Unit test for function ensure_value
def test_ensure_value():
    class Args(object):
        def __init__(self):
            self.xyzzy = None
    args = Args()
    assert args.xyzzy == None
    ensure_value(args, 'xyzzy', 42)
    assert args.xyzzy == 42
    ensure_value(args, 'xyzzy', 0)
    assert args.xyzzy == 42


#
# Base options
#
standard_parser = argparse.ArgumentParser(add_help=False)
standard_parser.add_argument('-v', '--version', '--vers', action='version', version=version('__ansible_basename__'))



# Generated at 2022-06-22 18:39:34.153978
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """Test to generate a help string"""
    usage = "usage: prog [-h] [--private-key PRIVATE_KEY_FILE]" \
            " [--ssh-common-args SSH_COMMON_ARGS] [--sftp-extra-args SFTP_EXTRA_ARGS]" \
            " [--scp-extra-args SCP_EXTRA_ARGS] [--ssh-extra-args SSH_EXTRA_ARGS]" \
            " [--connection-password-file CONNECTION_PASSWORD_FILE]" \
            " [--timeout TIMEOUT] [--become] [--become-method BECOME_METHOD]" \
            " [--become-user BECOME_USER] [-K] [--become-password-file BECOME_PASSWORD_FILE]"
    parser = argparse.Argument

# Generated at 2022-06-22 18:39:42.532253
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(description='add_inventory_options')
    add_inventory_options(parser)
    opts = parser.parse_args(["-i", "inventory_file"])
    assert opts.inventory == ["inventory_file"]
    opts = parser.parse_args(["--list-hosts"])
    assert opts.listhosts == True
    opts = parser.parse_args(["-l", "subset"])
    assert opts.subset == "subset"



# Generated at 2022-06-22 18:39:43.799341
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    assert PrependListAction('test_PrependListAction', 'test_PrependListAction')


#
# OptionParser hooks
#

# Generated at 2022-06-22 18:39:46.141389
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    assert UnrecognizedArgument



# Generated at 2022-06-22 18:39:49.970496
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, help='Print version of Ansible to stdout')
    args = parser.parse_args(['--version'])
    assert True


# Generated at 2022-06-22 18:39:55.742394
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(description="Test program")
    add_async_options(parser)

    parser.parse_args(args=["-P", "10", "-B", "100"])
    assert parser.parse_args().poll_interval == 10
    assert parser.parse_args().seconds == 100


# Generated at 2022-06-22 18:40:06.045988
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class MockAction(argparse.Action):
        def __init__(self, option_strings, dest=argparse.SUPPRESS, default=argparse.SUPPRESS, help=None):
            super(MockAction, self).__init__(option_strings=option_strings, dest=dest, default=default, nargs=0, help=help)

    class MockParser(argparse.ArgumentParser):
        def __init__(self, **kwargs):
            super(MockParser, self).__init__(**kwargs)
            self.actions = []

        def add_argument(self, *args, **kwargs):
            action = MockAction(args, **kwargs)
            self.actions.append(action)


# Generated at 2022-06-22 18:40:06.787396
# Unit test for function add_output_options
def test_add_output_options():
    pass



# Generated at 2022-06-22 18:40:11.372889
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-H', '--host', action=UnrecognizedArgument)
    args = parser.parse_args(args=['-D', 'THIS IS A TEST'])

# Generated at 2022-06-22 18:40:15.425024
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser = argparse.ArgumentParser()
        parser.add_argument('1', action=UnrecognizedArgument)
        parser.parse_args(['1'])


# Generated at 2022-06-22 18:40:26.496710
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        prog='test_SortingHelpFormatter_add_arguments'
    )
    # add arguments in a random order
    parser.add_argument('--second', '-s')
    parser.add_argument('--third', '-t')
    parser.add_argument('--first', '-f')
    # test the result
    lines = parser.format_help().split('\n')
    # check that the short options appear in alphabetical order
    assert lines[2].index('-f') < lines[2].index('-s') < lines[2].index('-t')
    # check that the long options appear in alphabetical order

# Generated at 2022-06-22 18:40:28.772268
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_verbosity_options(parser)
    assert parser.get_default('verbosity') == 0



# Generated at 2022-06-22 18:40:30.106938
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    parser.parse_args(["--force-handlers"])
    parser.parse_args(["--flush-cache"])



# Generated at 2022-06-22 18:40:36.797444
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/a/file') == '/path/to/a/file'
    assert unfrack_path()('/path/{{ to }}/a/file') == '/path/to/a/file'
    assert unfrack_path(True)('/path:{{ to }}:a/file') == ['/path', 'to', 'a/file']



# Generated at 2022-06-22 18:40:41.552444
# Unit test for function add_output_options
def test_add_output_options():
    parser = OptionParser()
    add_output_options(parser)
    opts, args = parser.parse_args(["-o", "-t", "test-tree"])
    assert opts.one_line is True
    assert opts.tree == "test-tree"
# End of unit test



# Generated at 2022-06-22 18:40:45.857973
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('-b', action='store_true', dest='bar')
    parser.add_argument('-c')
    parser.add_argument('baz')

    # test that this doesn't crash
    SortingHelpFormatter().add_argument(parser)

#
# AnsibleOptionParser base class
#

# Generated at 2022-06-22 18:40:50.366266
# Unit test for function ensure_value
def test_ensure_value():
    args = argparse.Namespace()
    ensure_value(args, 'foo', 'bar')
    assert args.foo == 'bar'
    ensure_value(args, 'foo', 'pants')
    assert args.foo == 'bar'



# Generated at 2022-06-22 18:40:55.202886
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI

    choices = ['all', 'never', 'changed', 'yaml', 'json']
    loader = DataLoader()
    cli = CLI(None, None)

    parser = cli.base_parser(basic.ANSIBLE_MODULE_ARGS, 'test_add_subset_options')

    parser.add_argument('--forks', dest='forks', default=10, type=int)
    parser.add_argument('--list-hosts', dest='listhosts', action='store_true')
    parser.add_argument('--list-tasks', dest='listtasks', action='store_true')

# Generated at 2022-06-22 18:40:59.346645
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    result = parser.parse_args(args=['-P', '5', '-B', '8'])
    assert result.poll_interval == 5
    assert result.seconds == 8



# Generated at 2022-06-22 18:41:00.642055
# Unit test for function add_fork_options
def test_add_fork_options():
    m = argparse.ArgumentParser()
    add_fork_options(m)
    args = m.parse_args(args=['-f','10'])
    assert args.forks == 10


# Generated at 2022-06-22 18:41:05.846725
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('test', '')
    add_runas_options(parser)
    args = parser.parse_args(["--become", "--become-user=newuser"])
    assert args.become
    assert args.become_user == "newuser"



# Generated at 2022-06-22 18:41:11.455442
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)

    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == C.DIFF_ALWAYS


# Generated at 2022-06-22 18:41:19.277664
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', '--aaa', help='AAA')
    parser.add_argument('-b', '--bbb', help='BBB')
    parser.add_argument('-c', '--ccc', help='CCC')

    # Need to call parse_args() so that all the help will be generated
    parser.parse_args(['--help'])

    expected_help = """
usage: [-h] [-a AAA] [-b BBB] [-c CCC]

optional arguments:
  -h, --help  show this help message and exit
  -a AAA      AAA
  -b BBB      BBB
  -c CCC      CCC
"""
    assert parser.format_help() == expected_help


# Generated at 2022-06-22 18:41:22.328802
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog="azure_rm_storageaccount" ,desc="Get information about a storage account")
    # check parser is successfully created
    assert parser is not None
    assert parser._actions[0] == '--help'


# Generated at 2022-06-22 18:41:24.512189
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert parser



# Generated at 2022-06-22 18:41:30.945520
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/')('/etc/hosts') == '/etc/hosts'
    assert maybe_unfrack_path('/')('@/etc/hosts') == '@/etc/hosts'
    assert maybe_unfrack_path('@')('@/etc/hosts') == '@/etc/hosts'
    assert maybe_unfrack_path('@')('@@/etc/hosts') == '@@/etc/hosts'



# Generated at 2022-06-22 18:41:34.484617
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser('test')
    add_check_options(parser)
    options = parser.parse_args(['--check'])
    assert options.check == True
    assert options.syntax == False


# Generated at 2022-06-22 18:41:35.614568
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)


# Generated at 2022-06-22 18:41:37.884922
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()

    add_runas_options(parser)

    parsed = parser.parse_args()

    assert parsed.become is False
    assert parsed.become_method == 'sudo'
    assert parsed.become_user == 'root'
    assert parsed.ask_become_pass is False



# Generated at 2022-06-22 18:41:44.398183
# Unit test for function create_base_parser
def test_create_base_parser():
    p = create_base_parser('test')
    assert p._actions[0].option_strings == ('-v', '--verbose')
    assert p._actions[1].option_strings == ('--version',)
    assert p.prog == 'test'
    assert p.description is None
    assert p.epilog is None
    assert p.conflict_handler == 'resolve'
    assert p.formatter_class.__name__ == 'SortingHelpFormatter'
    assert p._actions[1].help == "show program's version number, config file location, configured module search path," \
                   " module location, executable location and exit"



# Generated at 2022-06-22 18:41:47.564748
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args()
    assert options.forks == C.DEFAULT_FORKS


# Generated at 2022-06-22 18:41:54.213691
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    a = AnsibleVersion(option_strings='--version', help=None)
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, help='Print version and exit')
    parser.parse_args(['--version'])
    parser.prog = 'ansible-playbook'
    parser.parse_args(['--version'])



# Generated at 2022-06-22 18:41:56.514450
# Unit test for function add_output_options
def test_add_output_options():
    def helper(args, result):
        parser = argparse.ArgumentParser()
        add_output_options(parser)
        return vars(parser.parse_args(args)) == result

    assert helper(["-o"], {"one_line": True})
    assert helper(["-t", "/tmp/logs"], {"tree": "/tmp/logs"})
    assert helper(["--help"], False)



# Generated at 2022-06-22 18:42:05.644959
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    action = PrependListAction(["-a","--aaa"], "a")
    p = argparse.ArgumentParser()
    p.add_argument("-a","--aaa", action=action)
    ns = p.parse_args()
    assert ns.a == []
    ns = p.parse_args("-a foo".split())
    assert ns.a == ["foo"]
    ns = p.parse_args("-a foo -a bar".split())
    assert ns.a == ["bar", "foo"]

#
# Utility functions
#

# Generated at 2022-06-22 18:42:16.361728
# Unit test for function add_basedir_options
def test_add_basedir_options():

    # Create test parser
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_basedir_options(parser)

    # Test normal file path
    input_args = parser.parse_args(['--playbook-dir', 'a/b/c'])
    assert input_args.basedir == 'a/b/c'

    # Test '-' for stdin
    input_args = parser.parse_args(['--playbook-dir', '-'])
    assert input_args.basedir == '-'

    # Test error when option is not provided
    input_args = parser.parse_args(['--playbook-dir'])

# Generated at 2022-06-22 18:42:21.106859
# Unit test for function add_async_options
def test_add_async_options():
    test_prog = 'ansible-pull'
    parser = create_base_parser(test_prog)
    add_async_options(parser)
    test_args = ['-B', '5', '-P', '30']

    opts = parser.parse_args(test_args)
    assert opts.seconds == 5
    assert opts.poll_interval == 30


# Generated at 2022-06-22 18:42:31.587598
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    ''' Return value if it not start with beacon '''
    assert maybe_unfrack_path('@')('/etc/ansible/hosts') == '/etc/ansible/hosts'
    ''' Return value if it starts with beacon '''
    assert maybe_unfrack_path('@')('@/etc/ansible/hosts') == '@' + unfrackpath('/etc/ansible/hosts')

#
# Common Options
#
common = argparse.ArgumentParser(add_help=False)
common.add_argument('--version', action=AnsibleVersion, version=version, nargs=0,
                    help='show program\'s version number and exit')

# Connection Options
connection = argparse.ArgumentParser(add_help=False)

# Generated at 2022-06-22 18:42:38.948674
# Unit test for function add_module_options
def test_add_module_options():
    test_parser = argparse.ArgumentParser()
    add_module_options(test_parser)
    test_args = ["-M", "/etc/ansible/modules"]
    out_args = copy.deepcopy(test_args)
    test_args.insert(0, "dummy_program_name")
    args = test_parser.parse_args(test_args)
    assert args.module_path == out_args[1]
    return



# Generated at 2022-06-22 18:42:45.535409
# Unit test for function add_async_options
def test_add_async_options():
    parser = create_base_parser('/some/bin/some')
    # test add_async_options()
    add_async_options(parser)
    parsed = parser.parse_args(['--poll=60'])
    assert getattr(parsed, 'poll_interval') == 60, 'should equal 60'
    parsed = parser.parse_args(['--background=120'])
    assert getattr(parsed, 'seconds') == 120, 'should equal 120'



# Generated at 2022-06-22 18:42:57.030630
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    assert '-i' in parser._option_string_actions
    assert '--inventory' in parser._option_string_actions
    assert '--inventory-file' in parser._option_string_actions
    assert '--list-hosts' in parser._option_string_actions
    assert '-l' in parser._option_string_actions
    assert '--limit' in parser._option_string_actions
#
# These tests have to be added to the 'TestCLI' class in
# test/units/test_ansible_cli in the local ansible repository.
#
# class TestCLI(unittest.TestCase):
#    def setUp(self):
#        pass
#
#    def tearDown(self):
#        pass
#

# Generated at 2022-06-22 18:43:04.759271
# Unit test for function add_module_options
def test_add_module_options():
    c = copy.deepcopy(C.config._config)
    C.initialize()
    C.config.initialize_options()
    parser = add_module_options(create_base_parser())
    args = parser.parse_args(['-M', '~/foo/bar:~/bar/baz'])
    assert args.module_path == ['~/bar/baz', '~/foo/bar']
    C.config._config = c

# Generated at 2022-06-22 18:43:06.400765
# Unit test for function add_module_options
def test_add_module_options():
    assert add_module_options('') == None


# Generated at 2022-06-22 18:43:11.217131
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(["-f1"])
    assert args.forks == 1

# Generated at 2022-06-22 18:43:17.744386
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = __version__
    arg_parser = argparse.ArgumentParser(description='Test')
    arg_parser.add_argument('-v', '--version', dest='version', action=AnsibleVersion, default=argparse.SUPPRESS, help='Show program\'s Ansible version number and exit.')
    arg_parser.prog = '__main__'
    args = arg_parser.parse_args(['--version'])
    assert ansible_version == args.version, "Ansible version number in test is not equal to version in args.version"


# Generated at 2022-06-22 18:43:25.126837
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    action = UnrecognizedArgument(option_strings=['--option', '-o'], dest='unrecognized_arguments')
    parser = argparse.ArgumentParser()
    parser.add_argument('--option', action=UnrecognizedArgument)
    parser.add_argument('positional_argument')
    args = parser.parse_args('--option -o POSITIONAL'.split())
    #TODO: How to validate parser.error?



# Generated at 2022-06-22 18:43:31.071575
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    test_args = ['-vv']
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_verbosity_options(parser)
    options = parser.parse_args(test_args)
    assert options.verbosity == 2



# Generated at 2022-06-22 18:43:37.544248
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # GIVEN
    parser = AnsibleArgumentParser()
    parser.prog = 'ansible'
    # WHEN
    argument = UnrecognizedArgument(['--something'])
    # EXPECT
    assert not argument.nargs
    assert not argument.required
    assert not argument.default
    assert argument.help is None
    assert argument.metavar is None
    assert argument.const
    assert argument.dest is None
    assert not argument.option_strings
    assert argument.__call__(parser, None, None) is None



# Generated at 2022-06-22 18:43:44.373901
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument(dest='nargs1', action='store_true')
    p.add_argument('-a', dest='nargs2', action='store_true')
    p.add_argument('-b', nargs='?', dest='nargs3')
    p.add_argument('-c', nargs='*', dest='nargs4')
    p.add_argument('-d', nargs='+', dest='nargs5')
    p.add_argument('-e', nargs=1, dest='nargs6')
    f = SortingHelpFormatter()
    s = f.format_help(p)
    assert s.index(' -a') < s.index(' -b'), "SortingHelpFormatter"
    assert s.index

# Generated at 2022-06-22 18:43:50.364591
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_value = maybe_unfrack_path("@")("@/tmp/ansible/localhost")
    assert test_value == "@/tmp/ansible/localhost"
    test_value = maybe_unfrack_path("@")("/tmp/ansible/localhost")
    assert test_value == "/tmp/ansible/localhost"
    test_value = maybe_unfrack_path("@")("abc")
    assert test_value == "abc"


# Generated at 2022-06-22 18:43:56.885628
# Unit test for function add_output_options
def test_add_output_options():
    parser=argparse.ArgumentParser()
    add_output_options(parser)
    try:
        args=parser.parse_args('-o --tree /var/log/ansible'.split())
    except SystemExit:
        assert False
    assert args.one_line==True
    assert args.tree=='/var/log/ansible'

# Generated at 2022-06-22 18:43:57.650745
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass

# Generated at 2022-06-22 18:44:09.328568
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    arg1 = argparse.ArgumentParser(description='arg1', prog='prog')
    arg2 = argparse.ArgumentParser(description='arg2', prog='prog')
    arg1.add_argument('-a')
    arg2.add_argument('-b')
    arg1.print_help()
    arg2.print_help()

    parser = argparse.ArgumentParser(prog='parser', add_help=False)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.print_help()

    formatter = SortingHelpFormatter()

    parser.formatter = formatter
    parser.print_help()

    parser = argparse.ArgumentParser(description='description',
                                     prog='prog',
                                     add_help=False)
   

# Generated at 2022-06-22 18:44:13.521539
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    result = UnrecognizedArgument
    assert isinstance(result, argparse.Action)
    assert isinstance(result, object)
    assert result.__name__ == 'UnrecognizedArgument'
    assert isinstance(result.__doc__, str)

#
# Generic OptionParser
#

# Generated at 2022-06-22 18:44:20.225750
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():

    def sorted_actions():
        return [
                ['-h', '--help'],
                ['-c', '--config'],
                ['-i', '--inventory'],
                ['-e', '--extra-vars'],
                ['-t', '--tags'],
                ['-v', '--verbose'],
                ['-D', '--debug']
                ]

    class Actions(object):
        attr_list = []

        def __init__(self, name, **kwargs):
            self.name = name
            for k, v in kwargs.items():
                setattr(self, k, v)
                self.attr_list.append(k)

        def __repr__(self):
            return '%s' % self.name

    class Parser(object):
        attr

# Generated at 2022-06-22 18:44:25.145782
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='exe')
    add_runas_options(parser)
    args = parser.parse_args(['-b'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user is None
    parser = argparse.ArgumentParser(prog='exe')
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method=su', '--become-user=test'])
    assert args.become is True
    assert args.become_method == 'su'
    assert args.become_user == 'test'



# Generated at 2022-06-22 18:44:27.675260
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=argparse.ArgumentParser()
    add_meta_options(parser)
    group = parser._action_groups[2]
    assert group.title == 'meta options'
    assert group._group_actions[0].dest == 'force_handlers'
    assert group._group_actions[1].dest == 'flush_cache'
# End unit test for function add_meta_options



# Generated at 2022-06-22 18:44:38.650442
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='ansible-test')
    add_subset_options(parser)

    # Ensure that adding the arguments to the parser didn't break anything
    parser.add_argument('-e', '--extra-vars', dest="extra_vars", action="append", type=maybe_unfrack_path('@'),
                        help="set additional variables as key=value or YAML/JSON, if filename prepend with @", default=[])

    args = parser.parse_args(['-t', 'foo'])
    assert args.tags == ['foo']

    args = parser.parse_args(['-t', 'foo', '-t', 'bar'])
    assert args.tags == ['foo', 'bar']

    args = parser.parse_args(['--tags', 'foo'])
   

# Generated at 2022-06-22 18:44:43.794753
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test/path'])
    assert args.basedir == 'test/path'



# Generated at 2022-06-22 18:44:48.471911
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    return parser.parse_args("--playbook-dir foo/bar".split())



# Generated at 2022-06-22 18:44:52.772534
# Unit test for function add_inventory_options
def test_add_inventory_options():
    print("Testing function add_inventory_options")
    parser = create_base_parser('ansible-inventory')
    add_inventory_options(parser)
    new_parser = parser.parse_args('--list-hosts'.split())
    print(new_parser)



# Generated at 2022-06-22 18:44:56.006979
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args('')
    assert options.vault_ids is None
    assert options.vault_password_files is None


# Generated at 2022-06-22 18:45:04.163093
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = ['--private-key', '/path/to/key', '-u', 'user', '-c', 'ssh', '-T', '100', '--ssh-common-args', 'common',
            '--sftp-extra-args', 'sftp', '--scp-extra-args', 'scp', '--ssh-extra-args', 'ssh']
    args = parser.parse_args(args)
    assert args.private_key_file == '/path/to/key'
    assert args.remote_user == 'user'
    assert args.connection == 'ssh'
    assert args.timeout == 100
    assert args.ssh_common_args == 'common'

# Generated at 2022-06-22 18:45:07.643954
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(description="", add_help=False)
    parser.add_argument('--dest', action=UnrecognizedArgument, dest="dest")
    options = parser.parse_args(["--dest", "value"])
    assert options.dest == True



# Generated at 2022-06-22 18:45:11.915745
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('blah', 'foo bar', 'desc', epilog='epilog')
    opts = parser.parse_args(['--version'])
    assert opts.verbosity is None


# Generated at 2022-06-22 18:45:15.258689
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_async_options(parser)
    parser.parse_args(args=['-B', '10', '-P', '10'])

# Generated at 2022-06-22 18:45:22.563100
# Unit test for function add_runas_options
def test_add_runas_options():
    # Arrange
    parser = argparse.ArgumentParser(prog='test_add_runas_options', conflict_handler='resolve')

    # Act
    add_runas_options(parser)

    # Assert
    expected = set(['--become', '--become-method', '--become-user', '--ask-become-pass'])
    actual = set(parser._actions[-4:])  # pylint: disable=protected-access
    difference = expected.difference(actual)
    assert(len(difference) == 0)



# Generated at 2022-06-22 18:45:26.059050
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(["-o", "-t", "test_dir"])
    assert args.one_line
    assert args.tree


# Generated at 2022-06-22 18:45:33.335421
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    def mock_unfrack_path(value):
        return "unfracked_" + value

    old_unfrack = unfrackpath
    unfrackpath = mock_unfrack_path

    path = 'A/B/C'

    beacon = '@'
    assert maybe_unfrack_path(beacon)(beacon + path) == '@unfracked_A/B/C'
    assert maybe_unfrack_path(beacon)('/not/beacon' + path) == '/not/beacon' + path

    beacon = '/not/beacon'
    assert maybe_unfrack_path(beacon)('/not/beacon' + path) == 'unfracked_' + '/not/beacon' + path

# Generated at 2022-06-22 18:45:39.724195
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args=parser.parse_args(["-M", "/home/ansible/library", "-M", "/home/ansible/module"])
    assert args.module_path == ["/home/ansible/module", "/home/ansible/library"]



# Generated at 2022-06-22 18:45:42.513761
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args('-vvvv'.split())
    assert options.verbosity == 4



# Generated at 2022-06-22 18:45:50.514140
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-22 18:46:01.719331
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()

    add_meta_options(parser)

    # We are a bit fuzzy on the output that is generated.
    #
    # For example, if a new option was added we don't want to break the unit test.
    #
    options = parser.parse_args(args=[])
    assert options.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert options.flush_cache is False

    options = parser.parse_args(args=['--force-handlers', '--flush-cache'])
    assert options.force_handlers is True
    assert options.flush_cache is True

test_add_meta_options()



# Generated at 2022-06-22 18:46:09.700895
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    # assert that function add_module_options has been added correctly
    assert '-M' in parser._option_string_actions
    assert '--module-path' in parser._option_string_actions
    assert parser._option_string_actions['-M'].dest == 'module_path'
    assert parser._option_string_actions['--module-path'].dest == 'module_path'




# Generated at 2022-06-22 18:46:13.951142
# Unit test for function add_basedir_options
def test_add_basedir_options():
    from ansible.cli.arguments import add_basedir_options
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_basedir_options(parser)
    options = parser.parse_args(["--playbook-dir","some_dir"])
    assert options.basedir == unfrack_path()("some_dir")


# Generated at 2022-06-22 18:46:20.462037
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('test_prog', 'test_usage', 'test_desc', 'test_epilog')
    assert parser.prog == 'test_prog'
    assert parser.formatter_class.__name__ == 'SortingHelpFormatter'
    assert parser.description == 'test_desc'
    assert parser.epilog == 'test_epilog'
    parser.parse_args(['--version'])


# Generated at 2022-06-22 18:46:23.492788
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=create_base_parser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.flush_cache == True
    assert args.force_handlers == True


# Generated at 2022-06-22 18:46:35.407367
# Unit test for function add_vault_options
def test_add_vault_options():
    from ansible.cli.arguments import OptionParser, AnsibleCli
    parser = OptionParser(AnsibleCli, usage="ansible-config %s", runas_opts=True,
                          vault_opts=True, connect_opts=True, dir_opts=True, subset_opts=True,
                          output_opts=True, check_opts=True, runtask_opts=True, async_opts=True, metadata_opts=True)
    parser.add_vault_options()


# Generated at 2022-06-22 18:46:39.278844
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    opts = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert opts.check
    assert opts.syntax
    assert opts.diff

# Generated at 2022-06-22 18:46:45.931605
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.utils.collection_loader.loader import AnsibleCollectionLoader
    myCL = AnsibleCollectionLoader()
    myCL.load_collections(C.COLLECTIONS_PATHS)
    myCL.resolve_collections(['mynamespace.mycollection'])
    print(myCL.get_collection_paths('mynamespace.mycollection'))
    print(C.COLLECTIONS_PATHS)


# Generated at 2022-06-22 18:46:48.888894
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # Constructor
    ansible_version = AnsibleVersion("store")
    # Calling the constructor.
    ansible_version(None, None, None, None)



# Generated at 2022-06-22 18:46:58.231487
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # create a temp file for testing
    (fd, unused) = tempfile.mkstemp()
    os.close(fd)

    # create a dummy option string to test with
    option_string = "--test-option"

    # create a temp parser to test with
    parsing_mock = mock.Mock()
    # set up the side effect of the parser to exit with an error
    parsing_mock.error.side_effect = SystemExit

    # create a new optoion action to test with
    test_action = UnrecognizedArgument(option_strings='--unknown-option', dest="unknown-option", const=True, default=None,
                                       required=False, help=None, nargs=0)
    # call the action with the temp parser and mock option string

# Generated at 2022-06-22 18:47:04.881524
# Unit test for function add_check_options
def test_add_check_options():
    args = ['-C', '--syntax-check', '-D']
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    result = parser.parse_args(args)
    assert result.check == True, 'check is not True'
    assert result.syntax == True, 'syntax is not True'
    assert result.diff == True, 'diff is not True'


# Generated at 2022-06-22 18:47:13.361471
# Unit test for function ensure_value
def test_ensure_value():
    class FakeArgs():
        param1 = None
        param2 = 'present'

    # existing argument value should not be overridden
    result = ensure_value(FakeArgs(), 'param2', 'value')
    assert FakeArgs().param2 == 'present'
    assert result == 'present'

    # new argument should be added with specified value
    result = ensure_value(FakeArgs(), 'param1', 'value')
    assert FakeArgs().param1 == 'value'
    assert result == 'value'


#
# Parser itself
#

# Generated at 2022-06-22 18:47:16.987113
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args(['--tags', 'foo', '--tags', 'bar'])
    parser.parse_args(['--skip-tags', 'foo', '--skip-tags', 'bar'])



# Generated at 2022-06-22 18:47:23.088639
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-t', action='store_true')
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', '-c', action='store_true')
    parser.add_argument('--bar', action='store_true')
    assert parser.format_help(parser)


#
# Options base class
#

# Generated at 2022-06-22 18:47:29.596463
# Unit test for function add_vault_options
def test_add_vault_options():
  parser = argparse.ArgumentParser()
  add_vault_options(parser)
  expected_help = """
  the vault identity to use --ask-vault-password, --ask-vault-pass  ask for vault
  password --vault-password-file, --vault-pass-file  vault password file
  """

test_add_vault_options()

# Generated at 2022-06-22 18:47:34.999191
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True)('.') == [unfrackpath('.')]
    assert unfrack_path()(os.path.sep) == unfrackpath(os.path.sep)
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-22 18:47:37.654229
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_connect_options(parser)



# Generated at 2022-06-22 18:47:46.341655
# Unit test for function ensure_value
def test_ensure_value():
    class MyNamespace:
        def __init__(self):
            self.attr1 = None
            self.attr2 = None
        def __str__(self):
            return "MyNamespace(attr1=%s, attr2=%s)" % (repr(self.attr1), repr(self.attr2))

    ns = MyNamespace()
    ensure_value(ns, 'attr1', 'hello')
    assert ns.attr1 == 'hello'
    ensure_value(ns, 'attr1', 'goodbye')
    assert ns.attr1 == 'hello'
    ensure_value(ns, 'attr2', 'hello')
    assert ns.attr2 == 'hello'
    ensure_value(ns, 'attr2', 'goodbye')
    assert ns.attr2 == 'hello'


#
# Option Pars

# Generated at 2022-06-22 18:47:53.456965
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    # Check the default setting
    tparser = argparse.ArgumentParser()
    add_tasknoplay_options(tparser)
    opts = tparser.parse_args([])
    assert opts.task_timeout == C.TASK_TIMEOUT
    # Check a valid integer option
    value = 123
    opts = tparser.parse_args(["--task-timeout", str(value)])
    assert opts.task_timeout == value
    # Check a negative integer option
    value = -1
    opts = tparser.parse_args(["--task-timeout", str(value)])
    assert opts.task_timeout == C.TASK_TIMEOUT
    # Check a non-integer option
    value = "abc"

# Generated at 2022-06-22 18:47:58.234381
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("~/my_playbook.yml") == "~/my_playbook.yml"
    assert unfrack_path()("~/my_playbook.yml") != "~/my_playbook.ym"


# Generated at 2022-06-22 18:48:04.276665
# Unit test for function add_vault_options
def test_add_vault_options():
    optp = optparse.OptionParser()
    add_vault_options(optp)
    opts, args = optp.parse_args(['--vault-id', '1', '2'])
    print(opts, args)
    assert opts.vault_ids == ['1', '2']


# Generated at 2022-06-22 18:48:14.111718
# Unit test for function add_connect_options
def test_add_connect_options():
    module = sys.modules[__name__]
    is_option = lambda option_name: hasattr(module, option_name)
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    namespace = parser.parse_args([])
    for option in ['private_key_file', 'remote_user', 'connection', 'timeout', 'ssh_common_args',
                   'sftp_extra_args', 'scp_extra_args', 'ssh_extra_args', 'ask_pass', 'connection_password_file']:
        assert is_option(option) is True
#

# Generated at 2022-06-22 18:48:23.180205
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """Make sure that the SortingHelpFormatter is sorting actions."""

    class TempOptionParser(argparse.ArgumentParser):
        """Use a temporary argparse.ArgumentParser to test SortingHelpFormatter."""

        def __init__(self):
            super(TempOptionParser, self).__init__()
            self.formatter_class = SortingHelpFormatter
            self.prog = 'test_SortingHelpFormatter'

    parser = TempOptionParser()
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-c')

    plain_action = parser._get_action_from_name('-a')
    dest_action = parser._get_action_from_name('-c')
    parser._actions[0] = dest_action
    parser._

# Generated at 2022-06-22 18:48:30.001735
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = create_base_parser('test')
    add_subset_options(parser)
    # pass in test args; only -v is supported by create_base_parser,
    # and -t/-v is caught by add_subset_options
    args = parser.parse_args(['-t', 'my_only_tag', '-vvv'])
    # assert the expected result
    assert args.verbosity == 3
    assert args.tags == ['my_only_tag']
    assert args.skip_tags == C.TAGS_SKIP

