

# Generated at 2022-06-22 18:38:36.721876
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from io import StringIO
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.utils.path import unfrackpath
    cli = CLI(args=None)
    cli.parser = cli.base_parser(constants=CLI.constants, usage='%(prog)s')
    cli.parser.add_argument = lambda *args, **kwargs: None
    cli.parser.exit = lambda x: None
    cli.parser.parse_args = lambda *args, **kwargs: None
    cli.parser.prog = 'ansible-playbook'
    cli.parser.print_version = lambda *args, **kwargs: None
    cli.parser.print_help = lambda *args, **kwargs: None


# Generated at 2022-06-22 18:38:40.719927
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    opts = parser.parse_args('-C -D'.split())
    assert opts.check
    assert opts.diff

# Generated at 2022-06-22 18:38:51.266107
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.utils.boolean import boolean
    from ansible.utils.vars import merge_hash
    test_truthy = [True, 'True', 'true', '1', 1, 'on', 'yes', 'Y', 'TRUE']
    # test default options
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args([])
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP
    # test custom options
    for truthy in test_truthy:
        # test tags
        merge_hash(C, {'TAGS_RUN': [], 'TAGS_SKIP': []})
        parser = argparse.ArgumentParser()
        add_subset_options(parser)

# Generated at 2022-06-22 18:39:00.052773
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='test_argparse', add_help=False)
    parser.add_argument('-v', '--verbose', dest='verbosity', default=C.DEFAULT_VERBOSITY, action="count",
                        help="verbose mode (-vvv for more, -vvvv to enable connection debugging)")
    add_subset_options(parser)
    args = parser.parse_args()
    assert args.tags is not None
    assert args.skip_tags is not None


# Generated at 2022-06-22 18:39:02.848152
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    # Default value is not correct
    assert parser.get_default('ask_vault_pass') == True
    assert parser.get_default('vault_ids') == []
    assert parser.get_default('vault_password_files') == []
# Test add_vault_options
test_add_vault_options()



# Generated at 2022-06-22 18:39:04.458001
# Unit test for function add_module_options
def test_add_module_options():
    from unittest import mock

    parser = argparse.ArgumentParser(prog='test')
    with mock.patch('ansible.cli.config.CLIConfig.get_configuration_definition'):
        add_module_options(parser)



# Generated at 2022-06-22 18:39:11.161006
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    help_args = [
        '-h', '--help',       # short and long help options
        '-V', '--version',    # short and long version options
    ]

    class _FakeParser(object):
        def __init__(self):
            self.prog = self._prog
            self.exit_called = False
            self.parse_args_results = None

        @staticmethod
        def parse_args(args):
            parser = _FakeParser()
            parser.parse_args_results = parser.parse_known_args(args)[0]
            return parser.parse_args_results

        @staticmethod
        def parse_known_args(args):
            parser = _FakeParser()
            parser.parse_args_results = parser.parse_known_args(args)[0]
            return parser.parse_

# Generated at 2022-06-22 18:39:17.851891
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(
        prog='',
        formatter_class=SortingHelpFormatter,
        epilog='',
        description='',
        conflict_handler='resolve',
    )
    add_subset_options(parser)
    tt = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip1', '--skip-tags', 'skip2'])
    assert tt.tags == ['tag1', 'tag2']
    assert tt.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-22 18:39:21.459568
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', action=UnrecognizedArgument, nargs=1)
    parser.parse_args(['--input', '/tmp/pass'])



# Generated at 2022-06-22 18:39:24.238195
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'foo'])
    assert args.basedir == 'foo'

# Generated at 2022-06-22 18:39:26.875622
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog="argparse_test.py")
    add_fork_options(parser)
    args = parser.parse_args([])
    assert args.forks == C.DEFAULT_FORKS, "Default value of forks should be C.DEFAULT_FORKS"
    args = parser.parse_args(["-f", "10"])
    assert args.forks == 10, "default value of forks should be 10"


# Generated at 2022-06-22 18:39:32.718258
# Unit test for function add_subset_options
def test_add_subset_options():
    parser= argparse.ArgumentParser(
            prog = 'unittest_ansible_parser',
            formatter_class = SortingHelpFormatter,
            )
    add_subset_options(parser)
    try:
        parser.parse_args(['-t', 'VALID'])
    except SystemExit:
        assert False
    try:
        parser.parse_args(['-t', ])
        assert False
    except SystemExit:
        pass



# Generated at 2022-06-22 18:39:39.391676
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--version',
        dest='version',
        action=AnsibleVersion,
        nargs=0,
        help='show program\'s version number and exit'
    )
    result = parser.parse_args(['--version'])
    assert result.version is True


# Generated at 2022-06-22 18:39:41.206031
# Unit test for function add_fork_options
def test_add_fork_options():
    test_parser = argparse.ArgumentParser()
    add_fork_options(test_parser)
    test_args = ['--forks', '-1']
    parsed_args = test_parser.parse_args(test_args)
    assert parsed_args.forks == -1


# Generated at 2022-06-22 18:39:49.879200
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class Action(argparse.Action):
        def __init__(self, **kwargs):
            super(Action, self).__init__(**kwargs)
    def get_args(fmt):
        parser = argparse.ArgumentParser()
        parser.add_argument('--ccc', action=Action)
        parser.add_argument('-b', action=Action)
        parser.add_argument('-a', action=Action)
        parser.add_argument('--aaa', action=Action)

        arg_strings = []

        class PseudoFile(object):
            def write(self, s):
                arg_strings.append(s)

        fmt.add_arguments(parser._get_action_from_name('version').option_strings)
        parser.print_help(file=PseudoFile())
        return arg

# Generated at 2022-06-22 18:39:59.851949
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c')
    parser.add_argument('-b')
    parser.add_argument('aa')
    parser.add_argument('-a')
    parser._actions.append(argparse.Action('-Z', help='Z'))
    parser._actions.append(argparse.Action('-Y', help='Y'))
    parser._actions.append(argparse.Action('bb', help='b'))
    parser._actions.append(argparse.Action('-X', help='X'))
    parser._actions.append(argparse.Action('-d', help='d'))
    parser._actions.append(argparse.Action('-e', help='e'))
    parser._actions.append(argparse.Action('-f', help='f'))

# Generated at 2022-06-22 18:40:01.843352
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """ unit test for add_runas_prompt_options """
    parser = Mock()
    result = add_runas_prompt_options(parser)
    assert result is not None
    assert result == parser.add_argument_group.return_value.__enter__.return_value


#
# Option Parser Helpers
#


# Generated at 2022-06-22 18:40:08.723875
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()
    add_inventory_options(parser)
    parser.add_argument.assert_any_call('-list-hosts', dest='listhosts', action='store_true', help='outputs a list of matching hosts; does not execute anything else')
    parser.add_argument.assert_any_call('-i', '--inventory', '--inventory-file', dest='inventory', action="append", help="specify inventory host path or comma separated host list. --inventory-file is deprecated")
    parser.add_argument.assert_any_call('-l', '--limit', default=C.DEFAULT_SUBSET, dest='subset', help='further limit selected hosts to an additional pattern')



# Generated at 2022-06-22 18:40:11.710987
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """Verify function add_runas_prompt_options with an example"""
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True
    args = parser.parse_args([])
    assert args.become_ask_pass is False
    assert args.become_password_file == C.BECOME_PASSWORD_FILE



# Generated at 2022-06-22 18:40:22.014763
# Unit test for function add_inventory_options
def test_add_inventory_options():
    optparser = argparse.ArgumentParser()
    add_inventory_options(optparser)

    # parse arguments
    optparser.parse_args(args=['-i', 'my.inventory'])
    optparser.parse_args(args=['--inventory', 'my.inventory'])
    optparser.parse_args(args=['--inventory-file', 'my.inventory'])
    optparser.parse_args(args=['--list-hosts'])
    optparser.parse_args(args=['-l', 'my.subset'])
    optparser.parse_args(args=['--limit', 'my.subset'])


# Generated at 2022-06-22 18:40:25.146168
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    p = argparse.ArgumentParser()
    p.add_argument('--version', nargs=0, action=AnsibleVersion)
    p.parse_args(['--version'])



# Generated at 2022-06-22 18:40:27.101946
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    assert_options(parser)



# Generated at 2022-06-22 18:40:30.117639
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        conflict_handler='resolve',
    )
    add_async_options(parser)
    options = parser.parse_args(["-P", "5", "-B", "30"])
    assert options.poll_interval == 5
    assert options.seconds == 30


# Generated at 2022-06-22 18:40:32.973033
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args("-C --diff".split())
    assert args.check is True
    assert args.diff is True
    assert args.check_mode is True
    assert args.syntax is False
test_add_check_options.unittest = ['.options']



# Generated at 2022-06-22 18:40:36.797607
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='ansible-playbook')
    assert parser.parse_args(['--version'])
    assert parser.parse_args(['-vvvvvvv'])



# Generated at 2022-06-22 18:40:45.210187
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction, const=[1, 2],
                        nargs=argparse.OPTIONAL)
    parser.add_argument('bar', action=PrependListAction)

    # Test without --bar option
    # -f 1 -f 2 bar 1 bar 2 bar 3
    ns = parser.parse_args('-f 1 -f 2 bar 1 bar 2 bar 3'.split())
    assert ns.foo == ['1', '2']
    assert ns.bar == ['3', '2', '1']

    # Test with --bar option
    # -f 1 -f 2 --bar -f 3 -f 4 bar 1 bar 2 bar 3

# Generated at 2022-06-22 18:40:50.960999
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )

    add_connect_options(parser)
    cmdline = '--private-key test -u testuser -c ssh --ssh-common-args test --sftp-extra-args test --scp-extra-args test --ssh-extra-args test --timeout 100 --connection-password-file test -k'.split()
    parsed = parser.parse_args(cmdline)
    assert parsed.private_key_file == 'test'
    assert parsed.remote_user == 'testuser'
    assert parsed.connection == 'ssh'
    assert parsed.ssh_common_args == 'test'
    assert parsed.sftp_extra_args == 'test'
    assert parsed.scp_extra_

# Generated at 2022-06-22 18:40:51.935026
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)



# Generated at 2022-06-22 18:40:56.396814
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser('tests')
    add_verbosity_options(parser)
    args = ['--version', '-v']
    parsed = parser.parse_args(args)
    assert parsed.verbosity == 1



# Generated at 2022-06-22 18:41:01.506406
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', nargs=1, default=True, action=UnrecognizedArgument)
    args = parser.parse_args(['--test', 'my_test'])
    assert args.test is True
    try:
        args = parser.parse_args(['--test-bad', 'my_test'])
    except SystemExit:
        pass
    else:
        assert False


# Generated at 2022-06-22 18:41:06.394218
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args("--playbook-dir playbook-dir".split())
    assert options.basedir == "playbook-dir"



# Generated at 2022-06-22 18:41:16.073631
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = create_base_parser(prog="ansiballz", usage="ansiballz [-e EXTRA_VARS] [-vvv] [-t TREE] [-l SUBSET]",
                                desc="assemble a base ansible command line call")
    add_runtask_options(parser)
    args = parser.parse_args(args=['-e', 'var1=val1', '-e', '@varfile', '-e', 'var2: val2', '-vvv', '-t', 'mytree', '-l', 'subset'])
    assert args.extra_vars[0] == 'var1=val1'
    assert args.extra_vars[1] == '@varfile'
    assert args.extra_vars[2] == 'var2: val2'
   

# Generated at 2022-06-22 18:41:24.229188
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    parser.parse_args(["--task-timeout", "30"])
    parser.parse_args(["--task-timeout", "0"])
    with pytest.raises(SystemExit):
        parser.parse_args(["--task-timeout", "-1"])
    with pytest.raises(SystemExit):
        parser.parse_args(["--task-timeout", "1.5"])



# Generated at 2022-06-22 18:41:30.687807
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('~/test/') == unfrack_path(pathsep=False)('~/test') == unfrackpath('~/test')
    assert unfrack_path(pathsep=True)('~/test/:/tmp') == ['~/test', '/tmp']
    assert unfrack_path(pathsep=False)('-') == '-'
    assert unfrack_path(pathsep=False)('.') == os.getcwd()


# Generated at 2022-06-22 18:41:38.978122
# Unit test for function add_check_options
def test_add_check_options():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    parser = create_base_parser(
        usage='usage: test_add_check_options [options]',
        desc='Ansible check options'
    )
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert args.check is True
    assert args.syntax is True
    assert args.diff is True


# Generated at 2022-06-22 18:41:41.910872
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion([], argparse.SUPPRESS, {})
    parser = argparse.ArgumentParser()
    namespace = argparse.Namespace()
    action(parser, namespace, [], option_string=None)



# Generated at 2022-06-22 18:41:52.231052
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='ansible-console', usage="%(prog)s [options]", description="The ansible console tool provides an ansible REPL.")
    add_runtask_options(parser)
    #args = parser.parse_args(['--extra-vars', "user={{lookup('env', 'USER')}}", '--extra-vars', "@passwords.yml", '--extra-vars', "mykey=myvalue"])
    args = parser.parse_args(['--extra-vars', "user={{lookup('env', 'USER')}}", '--extra-vars', "@passwords.yml"])
    print("args.extra_vars: %s" % args.extra_vars)

# Generated at 2022-06-22 18:41:59.239245
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from six import StringIO
    sys.stdout = buffer = StringIO()
    tmp_parser = argparse.ArgumentParser(prog='test')
    tmp_namespace = argparse.Namespace()
    tmp_values = argparse.Namespace()
    tmp_AnsibleVersion = AnsibleVersion('store', {})
    tmp_AnsibleVersion.__call__(tmp_parser, tmp_namespace, tmp_values)
    tmp_parser.exit()
    result = buffer.getvalue()
    sys.stdout = sys.__stdout__
    assert result == __version__ + '\n'



# Generated at 2022-06-22 18:42:01.685084
# Unit test for function add_meta_options
def test_add_meta_options():
    import pytest
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options = parser.parse_args([])
    assert options.force_handlers == C.DEFAULT_FORCE_HANDLERS

    options = parser.parse_args(['--force-handlers'])
    assert options.force_handlers == True


# Generated at 2022-06-22 18:42:04.373213
# Unit test for function add_basedir_options
def test_add_basedir_options():
  parser = create_base_parser(prog='ansible-config')
  add_basedir_options(parser)
  parser.print_help()



# Generated at 2022-06-22 18:42:09.413340
# Unit test for function create_base_parser
def test_create_base_parser():
    for args in [ (), ("prog"), ("prog", "usage", "desc", "epilog")]:
        parser = create_base_parser(*args)
        assert parser.prog is not None
        options = parser.parse_args(['--version'])
        assert options.verbosity is None


# Generated at 2022-06-22 18:42:12.266493
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    assert parser._action_groups[2]._group_actions[0].dest == 'tags'
    assert parser._action_groups[2]._group_actions[0].default == C.TAGS_RUN
    assert parser._action_groups[2]._group_actions[1].dest == 'skip_tags'
    assert parser._action_groups[2]._group_actions[1].default == C.TAGS_SKIP



# Generated at 2022-06-22 18:42:14.354968
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    version = AnsibleVersion('--version','version','version','version')
    print(version)



# Generated at 2022-06-22 18:42:17.865156
# Unit test for function ensure_value
def test_ensure_value():
    test = argparse.Namespace()
    assert ensure_value(test, 'attr', []) == []
    assert ensure_value(test, 'attr', {}) == []
    test.attr = 'test'
    assert ensure_value(test, 'attr', []) == 'test'
    assert ensure_value(test, 'attr', {}) == 'test'



# Generated at 2022-06-22 18:42:18.317905
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    pass



# Generated at 2022-06-22 18:42:19.802529
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t'])
    assert args.one_line is True
    assert args.tree is not None


# Generated at 2022-06-22 18:42:31.167441
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path1 = '/home/user/foo'
    path2 = './home/user/foo'
    path3 = '@/home/user/foo'
    path4 = '@./home/user/foo'
    path5 = '/home/user/foo/@'
    path6 = './home/user/foo/@'

    assert maybe_unfrack_path('@/')(path1) == path1
    assert maybe_unfrack_path('@/')(path2) == path2
    assert maybe_unfrack_path('@/')(path3) == ('@/' + unfrackpath(path3[1:]))
    assert maybe_unfrack_path('@/')(path4) == ('@/' + unfrackpath(path4[1:]))
    assert maybe_unfrack

# Generated at 2022-06-22 18:42:42.750893
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-c", action="store")
    parser.add_argument("-b", action="store")
    parser.add_argument("-a", action="store")
    help_text = parser.format_help()
    options = parser._option_string_actions
    assert '-b' == list(options.keys())[0]

#
# Global options
#

# Generated at 2022-06-22 18:42:46.161335
# Unit test for function add_basedir_options
def test_add_basedir_options():
    # No exception is raised when execute below functions
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    assert parser.get_default('basedir') == C.config.get_config_value('PLAYBOOK_DIR')



# Generated at 2022-06-22 18:42:56.207679
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--f')
    parser.add_argument('--g')
    parser.add_argument('--h')
    parser.add_argument('--i', '-i', required=True)
    parser.add_argument('--j', action=UnrecognizedArgument)

    try:
        parser.parse_args('--j -i'.split())
        assert False
    except SystemExit:
        pass
    try:
        parser.parse_args('--invalid'.split())
        assert False
    except SystemExit:
        pass
    parsed = parser.parse_args('-i'.split())
    assert parsed.i == '-i'



# Generated at 2022-06-22 18:43:02.417865
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    _ = parser.add_argument('-V', '--version', action=AnsibleVersion, help='Show program\'s version number and exit')
    args = parser.parse_args(['-V'])
    assert args.version is None, 'Parsed value %s != expected None' % args.version


#
# The public API
#


# Generated at 2022-06-22 18:43:08.026786
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args([])
    assert options.basedir == C.config.get_config_value('PLAYBOOK_DIR')
    options = parser.parse_args(['--playbook-dir', 'some_path'])
    assert options.basedir == 'some_path'



# Generated at 2022-06-22 18:43:12.166603
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', dest='version', action=AnsibleVersion)
    args = parser.parse_args()



# Generated at 2022-06-22 18:43:21.187890
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible.utils.display import Display
    display = Display()
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(["-f", "25"])
    display.verbosity = options.verbosity
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(["-v"])
    display.verbosity = options.verbosity
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(["-vvv"])
    display.verbosity = options.verbosity
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(["-vvvv"])


# Generated at 2022-06-22 18:43:27.338400
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("") == ""
    assert unfrack_path()("-") == "-"
    assert unfrack_path()("my_playbook") == "my_playbook"
    assert unfrack_path()("/my_playbook") == "/my_playbook"
    assert unfrack_path()("~/my_playbook") == os.path.expanduser("~/my_playbook")



# Generated at 2022-06-22 18:43:34.371528
# Unit test for function add_meta_options
def test_add_meta_options():
    from collections import namedtuple
    mock_parser = namedtuple("mock_parser", ["add_argument"])
    test_parser = mock_parser(add_argument=lambda args, **kwargs: True)
    add_meta_options(test_parser)
    assert test_parser.add_argument("--force-handlers") == True
    assert test_parser.add_argument("--flush-cache") == True



# Generated at 2022-06-22 18:43:37.032493
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('ansible-myprog', usage="", desc="description", epilog="epilogstring")
    assert parsers_equal(parser, 'ansible-myprog')


# Generated at 2022-06-22 18:43:42.391191
# Unit test for function add_fork_options
def test_add_fork_options():
    result = b"""
usage: add_fork_options [-h] [-f FORKS]

optional arguments:
  -h, --help  show this help message and exit
  -f FORKS    specify number of parallel processes to use (default=5)
"""
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        prog="add_fork_options"
    )
    add_fork_options(parser)
    try:
        parser.parse_args([])
    except SystemExit:
        pass
    result = parser.format_help()
    assert result == result



# Generated at 2022-06-22 18:43:52.055709
# Unit test for function ensure_value
def test_ensure_value():
    class DummyNamespace(object):
        def __init__(self):
            self.namespace = 0
        def __setattr__(self, key, value):
            self.__dict__[key] = value
            if key == 'namespace':
                self.namespace += 1
    ns = DummyNamespace()
    assert ns.namespace == 0
    assert ensure_value(ns, 'test_string', 'test_value') == 'test_value'
    assert ensure_value(ns, 'test_list', []) == []
    assert ensure_value(ns, 'test_list', []) is not []
    assert ns.namespace == 2


#
# Misc
#

# Generated at 2022-06-22 18:44:02.762837
# Unit test for function create_base_parser
def test_create_base_parser():
    # test version action
    version_help = "show program's version number, config file location, configured module search path," \
                   " module location, executable location and exit"
    parser = create_base_parser('test', '<<usage>>', '<<desc>>', '<<epilog>>')
    assert isinstance(parser, argparse.ArgumentParser)
    assert hasattr(parser.parse_args(['--version']), 'version')
    assert hasattr(parser.parse_args(['--verbose']), 'verbosity')
    assert hasattr(parser.parse_args(['-v']), 'verbosity')
    assert len(parser.parse_known_args(['--verbose'])[1]) == 0
    assert len(parser.parse_known_args(['-v'])[1]) == 0
    assert parser.description

# Generated at 2022-06-22 18:44:12.857724
# Unit test for function add_vault_options
def test_add_vault_options():
    from ..bin import ansible
    from ..utils import context_objects as co

    optparser = ansible.cli.CLI.base_parser(constants.DEFAULT_MODULE_NAME, '/some/random/path/ansible-playbook')
    result = add_vault_options(optparser)

    # Test that the returned value is the parser
    assert result is optparser

    # Test the vault-password-file and vault-id options can be added to the parser
    assert '--vault-password-file' in result._option_string_actions.keys()
    assert '--vault-pass-file' in result._option_string_actions.keys()
    assert '--vault-id' in result._option_string_actions.keys()


# Generated at 2022-06-22 18:44:16.646080
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'aaa'])
    assert options.basedir == 'aaa'



# Generated at 2022-06-22 18:44:20.539155
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = OptionParser()
    parser.add_option('-f', '--forks', dest='forks', default=C.DEFAULT_FORKS, type=int,
                        help="specify number of parallel processes to use (default=%s)" % C.DEFAULT_FORKS)
    options, _ = parser.parse_args(['-f', '1'])
    assert options.forks == 1



# Generated at 2022-06-22 18:44:21.642859
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog='ansible-doc')
    add_tasknoplay_options(parser)



# Generated at 2022-06-22 18:44:29.912717
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(epilog='version=%s, ansible=%s' % (__version__, __version__))
    add_inventory_options(parser)
    options = parser.parse_args(['--inventory-file', '1.inventory', '-l', 'nodes'])
    assert options.inventory == ['1.inventory']
    assert options.listhosts == False
    assert options.subset == 'nodes'



# Generated at 2022-06-22 18:44:35.580038
# Unit test for function add_async_options
def test_add_async_options():
    """Unit test for function add_async_options"""
    parser = argparse.ArgumentParser(prog="test_add_async_options")
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20


# Generated at 2022-06-22 18:44:41.420685
# Unit test for function add_runtask_options
def test_add_runtask_options():
    p = argparse.ArgumentParser()
    add_runtask_options(p)
    argv = " -e @/path/to/file -e k1=v1 -e k2=v2 -e k3=v3 -e k4=v4".split()
    args = p.parse_args(argv)
    assert args.extra_vars == ['/path/to/file', 'k1=v1', 'k2=v2', 'k3=v3', 'k4=v4']


# Generated at 2022-06-22 18:44:43.836121
# Unit test for function add_runas_options
def test_add_runas_options():
    cmdline = ['-bU', 'testbecomeuser']
    args = parse_extra_args(cmdline)
    assert args.become
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user == 'testbecomeuser'



# Generated at 2022-06-22 18:44:48.059614
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    args1 = [version()]
    opt_string = ['AnsibleVersion', args1]
    assert opt_string is not None

# Generated at 2022-06-22 18:44:56.327859
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """Unit test for constructor of class SortingHelpFormatter"""
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action='store_true', help='foo help')
    parser.add_argument('--bar', action='store_true', help='bar help')
    assert parser.format_help() == 'usage: test_SortingHelpFormatter [-h] [--bar] [--foo]\n\noptional arguments:\n  -h, --help  show this help message and exit\n  --bar       bar help\n  --foo       foo help\n'


# Generated at 2022-06-22 18:45:07.365591
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # First part of the test is to ensure that 'SortingHelpFormatter' class is not being subclassed
    assert 'returntocommand' not in SortingHelpFormatter.__dict__ and 'add_arguments' in SortingHelpFormatter.__dict__

    # Second part of the test is to ensure that 'add_arguments' method of 'SortingHelpFormatter' class is not being
    # overridden by any subclass.
    assert 'add_arguments' not in SortingHelpFormatter.__bases__

    # Third part of the test is to ensure that 'add_arguments' method of 'SortingHelpFormatter' class is not being
    # overridden by any class.
    assert 'add_arguments' in SortingHelpFormatter.__dict__


# Generated at 2022-06-22 18:45:12.235137
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(description='test parser')
    add_output_options(parser)
    assert set(['-o', '--one-line', '-t', '--tree']) == set(parser._actions[-2:])




# Generated at 2022-06-22 18:45:14.279067
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(["-M", "/path/to/modules"])
    assert args.module_path == ["/path/to/modules"]



# Generated at 2022-06-22 18:45:17.584674
# Unit test for function add_output_options
def test_add_output_options():
    opt = ['-t', 'abc']
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(opt)
    assert args.tree == 'abc'


# Generated at 2022-06-22 18:45:24.616086
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(description="Dummy Description")
    add_async_options(parser)
    args = parser.parse_args(["--poll", "10", "-B", "20"])
    assert args.poll_interval == 10
    assert args.seconds == 20
    args = parser.parse_args()
    assert args.poll_interval == 10
    assert args.seconds == 0

# Generated at 2022-06-22 18:45:31.727151
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = parser.parse_args([])
    assert args.verbosity == 0

    args = parser.parse_args(['-v'])
    assert args.verbosity == 1

    args = parser.parse_args(['-vv'])
    assert args.verbosity == 2

    args = parser.parse_args(['-vvv'])
    assert args.verbosity == 3

    args = parser.parse_args(['-vvvv'])
    assert args.verbosity == 4

    args = parser.parse_args(['-vvvvv'])
    assert args.verbosity == 5


# Generated at 2022-06-22 18:45:42.610801
# Unit test for function add_vault_options
def test_add_vault_options():
    parse = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    add_vault_options(parse)
    res = parse.parse_args()
    assert res.vault_ids == []
    assert res.ask_vault_pass == C.DEFAULT_ASK_VAULT_PASS
    assert res.vault_password_files == []
    parse = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    add_vault_options(parse)
    res = parse.parse_args('--vault-id ENV'.split())
    assert res.vault_ids == ['ENV']
    assert res.ask_vault_pass == C.DEFAULT_ASK_VAULT_PASS
    assert res.vault_

# Generated at 2022-06-22 18:45:44.151940
# Unit test for function version
def test_version():
    '''Just define the function, it should be covered by the integration tests
    '''

# Generated at 2022-06-22 18:45:51.696302
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='Ansible parser test')
    add_runas_options(parser)
    options = parser.parse_args()
    assert not options.become_user
    assert not options.ask_become_pass
    assert options.become
    assert options.become_method == 'sudo'



# Generated at 2022-06-22 18:45:58.634832
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(description='Argparse Python module')
    add_connect_options(parser)
    #print(parser.format_help())
    #print(parser.parse_args(['-c', 'ssh', '-u', 'test_user', '--private-key', 'test_key.pem', '--connection-password-file', 'test_password_file']))
    #print(parser.parse_args(['-T','222', '-c', 'local', '-u', 'test_user']))
    #print(parser.parse_args(['--connection-password-file', 'test_password_file']))
    #print(parser.parse_args(['--ssh-common-args', 'ProxyCommand=test_command', '--sftp-extra-args', '-f', '-

# Generated at 2022-06-22 18:46:01.858854
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args([])



# Generated at 2022-06-22 18:46:07.693520
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options,args = parser.parse_known_args(['--force-handlers', '--flush-cache'])
    assert (options.force_handlers == True)
    assert (options.flush_cache == True)



# Generated at 2022-06-22 18:46:09.701406
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    assert  SortingHelpFormatter().add_arguments([]) == None



# Generated at 2022-06-22 18:46:13.008328
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-22 18:46:22.810398
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args, _ = parser.parse_known_args()
    assert args.verbosity == C.DEFAULT_VERBOSITY
    args, _ = parser.parse_known_args(['-v'])
    assert args.verbosity == 1
    args, _ = parser.parse_known_args(['-vv'])
    assert args.verbosity == 2
    args, _ = parser.parse_known_args(['-vvv'])
    assert args.verbosity == 3
    args, _ = parser.parse_known_args(['-vvvv'])
    assert args.verbosity == 4



# Generated at 2022-06-22 18:46:34.233173
# Unit test for function add_module_options
def test_add_module_options():
    """ add module options Unit test """
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    add_module_options(parser)
    args = parser.parse_args([])
    assert DEFAULT_MODULE_PATH == args.module_path
    args = parser.parse_args(['-M', 'test'])
    assert args.module_path == ['test', os.getcwd() + '/library']
    args = parser.parse_args(['-M', 'test:test2:test3'])
    assert args.module_path == ['test', 'test2', 'test3', os.getcwd() + '/library']



# Generated at 2022-06-22 18:46:39.017688
# Unit test for function ensure_value
def test_ensure_value():
    class MyNamespace:
        def __init__(self):
            self.my_value = None

    my_namespace = MyNamespace()
    assert my_namespace.my_value is None
    ensure_value(my_namespace, 'my_value', 'hello')
    assert my_namespace.my_value == 'hello'



# Generated at 2022-06-22 18:46:42.978679
# Unit test for function version
def test_version():
    assert isinstance(version("test.py"), str)
    assert isinstance(version("test.py"), str)
    assert isinstance(version("test.py"), str)



# Generated at 2022-06-22 18:46:48.692933
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    assert_raises(SystemExit, parser.parse_args, ['--foo'])


#
# OptionParser overloads
#

# Generated at 2022-06-22 18:46:57.624936
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    opts = parser.parse_args(args=[])
    assert opts.verbosity == C.DEFAULT_VERBOSITY
    opts = parser.parse_args(args=['-v'])
    assert opts.verbosity == C.DEFAULT_VERBOSITY + 1
    opts = parser.parse_args(args=['-vvvvvvv'])
    assert opts.verbosity == C.DEFAULT_VERBOSITY + 3
    opts = parser.parse_args(args=['-vvvvvvvvvvvvvvvvvvv'])
    assert opts.verbosity == C.DEFAULT_VERBOSITY + 3



# Generated at 2022-06-22 18:47:10.461939
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    parsed_args = parser.parse_args(['--extra-vars', '@/etc/ansible/host.yml'])
    assert parsed_args.extra_vars == ['/etc/ansible/host.yml']
    parsed_args = parser.parse_args(['--extra-vars', '@/etc/ansible/host.yml', '--extra-vars', '@/etc/ansible/host.json'])
    assert parsed_args.extra_vars == ['/etc/ansible/host.yml', '/etc/ansible/host.json']

# Generated at 2022-06-22 18:47:16.460785
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(
        prog="Test",
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description="tests",
        conflict_handler='resolve',
    )
    add_tasknoplay_options(parser)
    options, args = parser.parse_known_args(args=[])
    assert options.task_timeout == C.TASK_TIMEOUT, "Invalid default value for --task-timeout"



# Generated at 2022-06-22 18:47:22.008418
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser(prog='PROG')
    parser.add_argument('-a', action=PrependListAction)
    parser.add_argument('-b', action=PrependListAction)
    args = parser.parse_args(['-a=foo', '-a=bar', '-b=baz'])
    assert args.a == ['bar', 'foo']
    assert args.b == ['baz']

# Generated at 2022-06-22 18:47:27.554947
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_tasknoplay_options(parser)
    v = vars(parser.parse_args(['--task-timeout', '10']))
    assert v['task_timeout'] == 10



# Generated at 2022-06-22 18:47:36.571631
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # test if constructor creates help correctly
    class MockParser(object):

        def error(self, txt):
            raise argparse.ArgumentError('MockParser', txt)

        def add_argument(self, *args, **kwargs):
            assert kwargs['help'] == 'Will never be called'

    p = MockParser()
    u = UnrecognizedArgument('-s', '--s', help="Will never be called")
    u(p, 'test', 'add_argument', '')

#
# Common options
#

# Generated at 2022-06-22 18:47:40.019685
# Unit test for function version
def test_version():
    import doctest
    test_results = doctest.testmod(version=version)
    if test_results.failed == 0:
        print("Success: %d test passed." % test_results.attempted)

# Generated at 2022-06-22 18:47:43.197000
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(["--force-handlers", "--flush-cache"])
    assert args.force_handlers
    assert args.flush_cache


# Generated at 2022-06-22 18:47:56.465499
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, type=int, help='append an int to list')
    parser.add_argument('--bar', action=PrependListAction, type=int, help='append an int to list')
    # not specifying any options to foo or bar will make them both default to []
    assert parser.parse_args([]).foo == parser.parse_args([]).bar == []
    # bar gets the value 1, prepended to list specified in --foo option
    ns = parser.parse_args(['--foo', '1', '--foo', '3', '--bar', '5'])
    assert ns.foo == [1, 3]
    assert ns.bar == [5]
    # options for foo & bar can appear in any order
   

# Generated at 2022-06-22 18:48:01.357760
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    action = PrependListAction(dest='foo', nargs='+')
    parser.add_argument('--foo', default=[], action=action)
    args = parser.parse_args(['--foo=bar', '--foo=baz'])
    assert args.foo == ['baz', 'bar']



# Generated at 2022-06-22 18:48:06.223269
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_verbosity_options(parser)
    args = parser.parse_args(['-vvvv'])
    assert args.verbosity == 4



# Generated at 2022-06-22 18:48:15.586378
# Unit test for function add_check_options
def test_add_check_options():
    parser = add_check_options(create_base_parser('test'))
    options = parser.parse_args(['--syntax-check'])
    assert options.syntax == True
    assert options.check == False
    assert options.diff == False
    options = parser.parse_args(['--check'])
    assert options.syntax == False
    assert options.check == True
    assert options.diff == C.DIFF_ALWAYS
    options = parser.parse_args(['-D'])
    assert options.syntax == False
    assert options.check == False
    assert options.diff == True

# Generated at 2022-06-22 18:48:23.396613
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    C.DEFAULT_LOCAL_TMP = '/'
    assert maybe_unfrack_path('@')('@/tmp/ansible') == '@/tmp/ansible'
    assert maybe_unfrack_path('@')('@/home/ansible') == '@/home/ansible'
    assert maybe_unfrack_path('@')('@./test') == '@./test'
    assert maybe_unfrack_path('@')('@../test') == '@../test'
    assert maybe_unfrack_path('@')('@/tmp/ansible/') == '@/tmp/ansible/'
    assert maybe_unfrack_path('@')('@/home/ansible/') == '@/home/ansible/'
    assert maybe_unfr

# Generated at 2022-06-22 18:48:24.469179
# Unit test for function add_output_options
def test_add_output_options():
    parser=argparse.ArgumentParser()
    add_output_options(parser)


# Generated at 2022-06-22 18:48:29.363921
# Unit test for function add_vault_options
def test_add_vault_options():
    """Test for function add_vault_options"""
    parser = create_base_parser('test')
    add_vault_options(parser)
    options = parser.parse_args(['test', '--vault-password-file', '~/ansible/vault_passwords'])
    assert 'ansible/vault_passwords' in options.vault_password_files

