

# Generated at 2022-06-22 18:38:36.193817
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', nargs=2, action=PrependListAction, required=True)
    parser.add_argument('-q', nargs='*', action=PrependListAction)
    try:
        parser.add_argument('-r', action=PrependListAction)
        assert False, "Expecting ValueError"
    except ValueError:
        pass
    args = parser.parse_args('-p a b -p c d -q x y z'.split())
    assert args.p == ['a', 'b', 'c', 'd']
    assert args.q == ['x', 'y', 'z']


#
# Finite state machine transition helpers
#

# Generated at 2022-06-22 18:38:41.582458
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.cli.arguments import options as opts

    parser = opts.create_base_parser('test')
    opts.add_connect_options(parser)
    opts.add_async_options(parser)

    opts.add_output_options(parser, default_output_file=None)

    parsed_args = parser.parse_args([])



# Generated at 2022-06-22 18:38:46.916058
# Unit test for function add_fork_options
def test_add_fork_options():
    parser=argparse.ArgumentParser()
    add_fork_options(parser)
    
    # Case1: Valid fork number
    result=parser.parse_args(["-f","4"])
    assert result.forks==4

    # Case2: Default fork number
    result=parser.parse_args([])
    assert result.forks==5

    # Case3: Invalid fork number
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser.parse_args(["-f","2.5"])

    # Case4: Invalid argument
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser.parse_args(["-f", "hello"])
    
    # Case5: Argument should be Integer

# Generated at 2022-06-22 18:38:48.378434
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_fork_options(parser)
    options = parser.parse_args(['-f', '4'])
    assert options.forks == 4


# Generated at 2022-06-22 18:38:55.056876
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = '@'
    test_value = '@/my/test/path'
    assert maybe_unfrack_path(beacon)(test_value) == test_value
    test_value = '@~/my/test/path'
    assert maybe_unfrack_path(beacon)(test_value) == '@' + os.path.expanduser('~/my/test/path')
    test_value = '/my/test/path'
    assert maybe_unfrack_path(beacon)(test_value) == test_value
# end unit test for function maybe_unfrack_path



# Generated at 2022-06-22 18:38:59.778482
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers'])
    assert args.force_handlers is True


# Generated at 2022-06-22 18:39:08.118989
# Unit test for function unfrack_path
def test_unfrack_path():

    # unfrack_path() with a path separator
    optionval = "/path/to/ansible/roles;/path/to/roles/2"
    expected = [
        os.path.join(C.DEFAULT_ROLES_PATH, 'path', 'to', 'ansible', 'roles'),
        os.path.join(C.DEFAULT_ROLES_PATH, 'path', 'to', 'roles', '2')
    ]
    result = unfrack_path(True)(optionval)
    assert result == expected

    # unfrack_path() without a path separator
    optionval = "/path/to/ansible/roles"
    expected = os.path.join(C.DEFAULT_ROLES_PATH, 'path', 'to', 'ansible', 'roles')

# Generated at 2022-06-22 18:39:12.655007
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    arg1 = '-v'
    parser = argparse.ArgumentParser()
    parser.add_argument(arg1, action=AnsibleVersion, nargs=0)
    prog_name = parser.prog
    namespace = parser.parse_args([arg1])



# Generated at 2022-06-22 18:39:19.997969
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class SubParser(argparse.ArgumentParser):
        def __init__(self):
            super(SubParser, self).__init__(description='subparser description')
            self.add_argument('--foo', action=PrependListAction)

    parser = SubParser()
    name = './config'
    old_cwd = os.getcwd()
    os.chdir(os.path.expanduser(name))
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar'], args.foo
    os.chdir(old_cwd)

#
# General purpose OptionParser
#

# Generated at 2022-06-22 18:39:26.955564
# Unit test for function add_vault_options
def test_add_vault_options():
        parser = argparse.ArgumentParser(prog='Test program')
        add_vault_options(parser)
        options = parser.parse_args('--vault-id test --ask-vault-pass'.split())
        assert options.vault_ids == ['test']
        assert options.ask_vault_pass == True
        assert options.vault_password_files == []


# Generated at 2022-06-22 18:39:31.251510
# Unit test for function add_connect_options
def test_add_connect_options():
    class TestOptionParser(object):
        def add_argument_group(self, *args, **kwargs):
            return None

        def add_argument(self, *args, **kwargs):
            return None

    test_option_parser = TestOptionParser()
    add_connect_options(test_option_parser)
    assert test_option_parser



# Generated at 2022-06-22 18:39:39.071228
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store', dest='foo', default=['default'])
    parser.add_argument('bar', nargs='*', default=[])

    assert parser.parse_args(['--foo', 'one', 'two']).foo == ['one', 'two']
    assert parser.parse_args(['--foo', 'one', 'two']).bar == []

    assert parser.parse_args(['one', 'two']).foo == ['default']
    assert parser.parse_args(['one', 'two']).bar == ['one', 'two']

    parser.add_argument('--bar', action=PrependListAction, default=[])
    assert parser.parse_args(['--bar', 'one', 'two']).bar == ['one', 'two']


# Generated at 2022-06-22 18:39:41.878132
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():

    test_parser1 = argparse.ArgumentParser()
    add_tasknoplay_options(test_parser1)

    test_parser2 = argparse.ArgumentParser()
    add_tasknoplay_options(test_parser2)

    assert test_parser1.format_help() == test_parser2.format_help()



# Generated at 2022-06-22 18:39:44.603427
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cli.arguments import OptionParser, UnrecognizedArgument
    u = UnrecognizedArgument(['-f'], 'f')
    parser = OptionParser(prog='ansible-playbook', usage='%prog [options] playbook.yml')
    try:
        u(parser, None, None)
    except SystemExit:
        pass
    assert parser.exit_code != 0



# Generated at 2022-06-22 18:39:47.180099
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    options = add_runas_prompt_options(parser)
    options = vars(parser.parse_args(['-K', '--ask-become-pass']))
    assert options['become_ask_pass'] is True
    options = vars(parser.parse_args(['--become-password-file', 'password.txt']))
    assert options['become_password_file'] == 'password.txt'



# Generated at 2022-06-22 18:39:57.315584
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class TestModule(object):
        # check that add_argument() appends to positional_arguments instead of overriding
        def __init__(self):
            self.foo = None
            self.bar = None
            self.baz = None

        def add_argument(self, *args, **kwargs):
            self.positional_arguments = args
            self.keyword_arguments = kwargs

    base_parser = TestModule()
    class_under_test = SortingHelpFormatter(base_parser)
    class_under_test.add_argument("foo")
    class_under_test.add_argument("bar")
    class_under_test.add_argument("baz")

    assert base_parser.positional_arguments == ("foo", "bar", "baz")



# Generated at 2022-06-22 18:40:03.396052
# Unit test for function add_runas_options
def test_add_runas_options():
    connect_password_group = argparse.ArgumentParser(conflict_handler='resolve')

    connect_password_group.add_argument('-k', '--ask-pass', default=C.DEFAULT_ASK_PASS, dest='ask_pass', action='store_true',
                                        help='ask for connection password')
    connect_password_group.add_argument('--connection-password-file', '--conn-pass-file', default=C.CONNECTION_PASSWORD_FILE, dest='connection_password_file',
                                        help="Connection password file", type=unfrack_path(), action='store')

    assert connect_password_group.parse_args(['-k', '--connection-password-file'])



# Generated at 2022-06-22 18:40:07.659216
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    # The task-timeout option should be present
    assert '--task-timeout' in parser._option_string_actions



# Generated at 2022-06-22 18:40:11.426191
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = Mock()
    runas_group = parser.add_argument_group(Mock())
    runas_pass_group = parser.add_mutually_exclusive_group()
    add_runas_prompt_options(parser, runas_group)
    runas_pass_group.add_argument.assert_called_once_with('-K', '--ask-become-pass', dest='become_ask_pass', action='store_true',
                                  default=C.DEFAULT_BECOME_ASK_PASS,
                                  help='ask for privilege escalation password')

#
# Functions to add multiple options to an OptionParser
#



# Generated at 2022-06-22 18:40:13.820339
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser("argparse test")
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']

# Generated at 2022-06-22 18:40:25.454697
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    nameless_parser = argparse.ArgumentParser()
    nameless_parser.add_argument('--x', nargs='*', action=UnrecognizedArgument)
    assert nameless_parser.parse_args(['--x', 'one', 'two', 'three']).x is False, 'Namespace does not have the expected value'


# These are the commands that do not take --args
# This is kind of a hack until we figure out a better way
NO_ARGS_COMMANDS = [
    'list-hosts',
    'list-tags',
    'list-tasks',
    'syntax-check',
    'config',
    'completion',
]
# This is kind of a hack until we figure out a better way
NO_COMP_COMMANDS = [
    'completion',
]



# Generated at 2022-06-22 18:40:29.519708
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    from ansible.cli.arguments import UnrecognizedArgument
    parser.add_argument('--unrecognized_argument_argument', action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args(['--unrecognized_argument_argument'])


# Generated at 2022-06-22 18:40:34.320923
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    test_parser.add_argument('-e')
    test_parser.add_argument('-b')
    test_parser.add_argument('-a')
    test_parser.add_argument('-c')
    test_parser.add_argument('-d')
    # test that -e and -b are before -a and -c
    assert '-e' in test_parser.format_help().splitlines()[2]
    assert '-b' in test_parser.format_help().splitlines()[3]
    assert '-a' in test_parser.format_help().splitlines()[4]
    assert '-c' in test_parser.format_help().splitlines()[5]

# Generated at 2022-06-22 18:40:36.697934
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    parser.parse_args(['-P', '-B'])

# Generated at 2022-06-22 18:40:45.165394
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class MockParser():
        def __init__(self, values):
            self.values = values

        def error(self, error_message):
            raise ValueError(error_message)

    # Test case 1: nargs == 0
    test_opt_string = '-a'
    namespace = argparse.Namespace(opt_a=[])
    test_const = "test_const"
    test_args = [test_const]
    test_nargs = 0
    test_action = PrependListAction(option_strings=test_opt_string, dest='opt_a', nargs=test_nargs, const=test_const)

    parser = MockParser("")

# Generated at 2022-06-22 18:40:57.549751
# Unit test for function add_basedir_options
def test_add_basedir_options():
    file1_path = '/home/user/playbook/file1'
    file2_path = '/home/user/playbook/file2'
    dir1_path = '/home/user/playbook/dir1'
    dir2_path = '/home/user/playbook/dir2'
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir=%s' % dir1_path])
    assert args.basedir == unfrackpath(dir1_path)
    args = parser.parse_args(['--playbook-dir=%s:%s' % (dir1_path, dir2_path)])

# Generated at 2022-06-22 18:40:58.980868
# Unit test for function add_async_options
def test_add_async_options():
    parser = create_base_parser('test')
    add_async_options(parser)


# Generated at 2022-06-22 18:41:07.117181
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    '''
    Constructor of class SortingHelpFormatter requires following arguments:
    prog:
    indent_increment:
    max_help_position:
    width:
    '''
    parser = SortingHelpFormatter(prog='foo', indent_increment=2,
                                  max_help_position=8, width=20)
    assert parser.prog == 'foo'
    assert parser.indent_increment == 2
    assert parser.max_help_position == 8
    assert parser.width == 20


# Generated at 2022-06-22 18:41:11.959619
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    arg_with_no_dashes = parser.add_argument(dest='subcommand')
    arg_with_dash = parser.add_argument('-x')
    parsed_args = parser.parse_args()
    assert parsed_args.subcommand == 'test'



# Generated at 2022-06-22 18:41:16.625667
# Unit test for function add_module_options
def test_add_module_options():   
    # 1. Run function
    parser = argparse.ArgumentParser(
        prog='ansible-test',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_module_options(parser)
    ns = parser.parse_args(['-M', 'test1', '-M', '/test2'])
    # 2. Verify the result
    assert ns.module_path == ['test1', '/test2']


# Generated at 2022-06-22 18:41:19.250490
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='Test add_runas_options')
    add_runas_options(parser)
    return parser



# Generated at 2022-06-22 18:41:23.485410
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = maybe_unfrack_path('@DEFAULT')
    # Test case: value.startswith('@DEFAULT')
    assert path('@DEFAULT/path/to') == '@DEFAULT/path/to'
    # Test case: not value.startswith('@DEFAULT')
    assert path('not default path') == 'not default path'


# Generated at 2022-06-22 18:41:28.693493
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert parser.parse_args(["-v"]).verbosity == 1  # 1 should be default value
    assert parser.parse_args(["-vvvvvvvvvvvvvvvvvvvvvvvvvvvvv"]).verbosity == 30  # 30 should be maximum limit


# Generated at 2022-06-22 18:41:33.581050
# Unit test for function add_module_options
def test_add_module_options():
    usage = 'usage: unit test'
    desc = 'unit test'
    epilog = 'unit test'
    parser = create_base_parser(os.path.basename('ansible-console'), usage, desc, epilog)
    add_module_options(parser)
    options = parser.parse_args([])
    assert options.module_path == module_path



# Generated at 2022-06-22 18:41:43.711936
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = ['--dest']
    dest = 'dest'
    nargs = None
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = None
    metavar = None
    action = PrependListAction(option_strings=option_strings,
                               dest=dest,
                               nargs=nargs,
                               const=const,
                               default=default,
                               type=type,
                               choices=choices,
                               required=required,
                               help=help,
                               metavar=metavar)
    parser = argparse.ArgumentParser()
    namespace = argparse.Namespace
    values = ['test_value']
    option_string = '--dest'

# Generated at 2022-06-22 18:41:49.940978
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = type('', (), dict(__name__='test_add_runtask_options'))()
    parser.add_argument = Mock()

    add_runtask_options(parser)

    parser.add_argument.assert_any_call('-e', '--extra-vars', dest='extra_vars', action='append', type=maybe_unfrack_path('@'),
                        help='set additional variables as key=value or YAML/JSON, if filename prepend with @', default=[])



# Generated at 2022-06-22 18:41:54.232580
# Unit test for function add_module_options
def test_add_module_options():
    """Unit test for function test_add_module_options"""
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.parse_args(['-M', '~/ansible/modules'])

# Generated at 2022-06-22 18:42:00.935327
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test",
           desc="""Ansible {0} unit test""".format(__version__),
           epilog="This is a test")

    parser.add_argument("--foo", action="store_true", dest="foobar", help="An example of foo argument")
    parser.add_argument("-b", action="store", dest="baz", help="An example of b argument")

    args = parser.parse_args(["-b", "this is b", "--version", "--foo"])
    assert(args.foobar is True)
    assert(args.v == 0)
    assert(args.baz == "this is b")

# Generated at 2022-06-22 18:42:02.064528
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    return parser


# Generated at 2022-06-22 18:42:03.723836
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    assert not hasattr(UnrecognizedArgument, '__call__')



# Generated at 2022-06-22 18:42:13.500989
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class DummyOption(object):
        def __init__(self, option_string, help_msg):
            self.option_strings = [option_string]
            self.help = help_msg
        def __getattr__(self, name):
            return None
    opt1 = DummyOption('-c', 'copy source file to remote file')
    opt2 = DummyOption('-d', 'remote directory')
    opt3 = DummyOption('-r', 'remote file')
    dummy_action_list = [opt1, opt2, opt3]
    parser = argparse.ArgumentParser(prog='fixture', description='testing sort')
    SortingHelpFormatter(parser)
    parser.add_argument('-c', '--copy', action='store_true', help='copy source file to remote file')

# Generated at 2022-06-22 18:42:15.313694
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # FIXME: how do we actually test this?
    assert True



# Generated at 2022-06-22 18:42:18.067351
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value = '/tmp/ansible/roles/my_role'
    result = maybe_unfrack_path('@')(value)
    assert result == '@' + unfrackpath(value[1:])



# Generated at 2022-06-22 18:42:24.357255
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    try:
        parser = argparse.ArgumentParser(prog="test-ansible-version")
        parser.add_argument('--version', action=AnsibleVersion)
        args = parser.parse_args([])
        args = parser.parse_args(['--version'])
    except SystemExit:
        pass
    except Exception:
        assert(1 == 0)



# Generated at 2022-06-22 18:42:28.285186
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    my_parser = argparse.ArgumentParser()
    my_parser.add_argument('--foo', action=UnrecognizedArgument)
    try:
        my_parser.parse_args(['--foo'])
    except SystemExit:
        pass



# Generated at 2022-06-22 18:42:39.855597
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from ansible.cli.playbook import PluginLoader
    class MyOptParser(argparse.ArgumentParser):
        def __init__(self, prog="args_test", usage="", description='', epilog='', version=None,
                     parents=[]):
            super(MyOptParser, self).__init__(prog=prog, usage=usage, description=description, epilog=epilog,
                                              version=version, parents=parents)
            self.cli = PluginLoader(parser=self, inventory=None)
    options = MyOptParser()
    add_runas_prompt_options(options)
    assert options.cli.parser._actions[7].nargs != '?'
    assert options.cli.parser._actions[7].dest == 'become'

# Generated at 2022-06-22 18:42:44.246334
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = Mock()
    add_vault_options(parser)
    assert parser.add_argument.call_count == 3, 'Expected 3 calls to add_argument()'
    assert parser.add_argument_group.call_count == 1, 'Expected 1 call to add_argument_group()'

# Generated at 2022-06-22 18:42:53.072667
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class action_list(list):
        def append(self, value):
            self.append(value)

    pa = PrependListAction(['s', ], 's', nargs=1, type=str, help='blah')
    pa.__call__(None, action_list(), ['b', ])
    pa2 = PrependListAction(['s', ], 's', nargs=1, type=str, help='blah')
    pa2.__call__(None, action_list(), ['a', ])



# Generated at 2022-06-22 18:42:55.198553
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    # create a parser
    parser = create_base_parser('test')
    # call the function
    add_tasknoplay_options(parser)
    # use the parser
    opts = parser.parse_args(['--task-timeout', '5'])
    # check the parser results
    assert opts.task_timeout == 5



# Generated at 2022-06-22 18:43:00.368975
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='executable', formatter_class=SortingHelpFormatter, conflict_handler='resolve', )
    add_fork_options(parser)
    assert parser.format_help().find("specify number of parallel processes to use (default={})".format(C.DEFAULT_FORKS)) > 0


# Generated at 2022-06-22 18:43:02.147392
# Unit test for function add_subset_options
def test_add_subset_options():
    # create fake parser to test function, then delete it
    fake_parser = argparse.ArgumentParser()
    add_subset_options(fake_parser)
    del(fake_parser)
if __name__ == '__main__':
    test_add_subset_options()


# Generated at 2022-06-22 18:43:05.497068
# Unit test for function add_subset_options
def test_add_subset_options():
    test_parser = argparse.ArgumentParser(prog='TEST')
    add_subset_options(test_parser)
    test_cmd_argv = ['-t', 'test_tag1', '-t', 'test_tag2', '--skip-tags', 'test_tag3', '--skip-tags', 'test_tag4']
    test_options = test_parser.parse_args(test_cmd_argv)
    assert test_options.tags == ['test_tag1', 'test_tag2']
    assert test_options.skip_tags == ['test_tag3', 'test_tag4']


# Generated at 2022-06-22 18:43:06.949745
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    _, args = parser.parse_known_args(['--tree', '/tmp'])
    assert args.tree == '/tmp'



# Generated at 2022-06-22 18:43:16.217541
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', '/opt/ansible_modules'])
    assert options.module_path == ['/opt/ansible_modules']
    options = parser.parse_args(['-M', '/opt/ansible_modules:/opt/ansible_modules1'])
    assert options.module_path == ['/opt/ansible_modules', '/opt/ansible_modules1']
    options = parser.parse_args([])
    assert options.module_path is None



# Generated at 2022-06-22 18:43:24.818773
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    def _test_with_runas_group():
        runas_group = parser.add_argument_group('foo', 'bar')
        add_runas_prompt_options(parser, runas_group)

        args = parser.parse_args(['-K'])
        assert args.become_ask_pass is True
        assert args.become_password_file is None
    parser = argparse.ArgumentParser()
    _test_with_runas_group()



# Generated at 2022-06-22 18:43:35.118781
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = Mock()
    runas_group = Mock()
    add_runas_prompt_options(parser, runas_group=runas_group)
    parser.add_argument_group.assert_called_with(runas_group)
    runas_pass_group = parser.add_mutually_exclusive_group.return_value

# Generated at 2022-06-22 18:43:40.197190
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    assert issubclass(UnrecognizedArgument, argparse.Action)
    def _test(option_strings, dest, const=True, default=None, required=False, help=None, metavar=None, nargs=0):
        return UnrecognizedArgument(option_strings, dest, const, default, required, help, metavar, nargs)
    assert isinstance(_test(['-m'], 'module_name'), UnrecognizedArgument)


# Generated at 2022-06-22 18:43:48.709915
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    ue = UnrecognizedArgument(['--example'], 'noop', help='A noop argument')
    assert ue.__dict__ == {'help': 'A noop argument',
                           'metavar': None,
                           'dest': 'noop',
                           'required': False,
                           'choices': None,
                           'option_strings': ['--example'],
                           'nargs': 0,
                           'const': True,
                           'default': None}

#
# CLI errors
#

# Generated at 2022-06-22 18:43:56.884754
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)

    assert parser._option_string_actions['-i'].help == 'specify inventory host path or comma separated host list. --inventory-file is deprecated'
    assert parser._option_string_actions['--list-hosts'].help == 'outputs a list of matching hosts; does not execute anything else'
    assert parser._option_string_actions['-l'].help == 'further limit selected hosts to an additional pattern'



# Generated at 2022-06-22 18:44:02.251769
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = '/test/test'
    assert maybe_unfrack_path('=-')('=-%s' % path) == '=-%s' % unfrackpath(path)
    assert maybe_unfrack_path('=-')('=-/t') == '=-/t'
    assert maybe_unfrack_path('=-')('=/t') == '=/t'



# Generated at 2022-06-22 18:44:08.709947
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', 'foo=value', '-e', '@file', '-e', '{"foo": "value"}'])
    assert options.extra_vars == ['foo=value', '@file', '{"foo": "value"}']



# Generated at 2022-06-22 18:44:13.358087
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    _v = 42

    n = Namespace()
    assert ensure_value(n, 'foo', _v) is _v
    assert n.foo is _v

    _v = 'testing'
    assert ensure_value(n, 'bar', _v) is _v
    assert n.bar is _v



# Generated at 2022-06-22 18:44:17.820090
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    av = AnsibleVersion(
        option_strings=['--version', '-V'],
        dest='version',
        nargs=0,
        const=None,
        default='==SUPPRESS==',
        type=None,
        choices=None,
        help='Show program\'s version number and exit.',
        metavar=None
    )
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = vars(parser.parse_args(['--version']))

    assert args['version'] == 0



# Generated at 2022-06-22 18:44:23.456374
# Unit test for function ensure_value
def test_ensure_value():
    class Parser(object):
        pass

    p = Parser()
    p.foo = 'bar'
    assert ensure_value(p, 'foo', 'baz') == 'bar'
    assert p.foo == 'bar'

    assert ensure_value(p, 'marco', 'polo') == 'polo'
    assert p.marco == 'polo'
# END unit test for function ensure_value



# Generated at 2022-06-22 18:44:36.106153
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    my_action = PrependListAction('-s', 'my_list')
    my_namespace = argparse.Namespace(my_list=['a','b','c','d'])
    my_action(None, my_namespace, ['e','f'], None)
    assert getattr(my_namespace, 'my_list') == ['e','f','a','b','c','d']

    my_action = PrependListAction('-s', 'my_list')
    my_namespace = argparse.Namespace()
    my_action(None, my_namespace, ['e','f'], None)
    assert getattr(my_namespace, 'my_list') == ['e','f']


#
# Supporting code for ansible-playbook cli options
#

# Generated at 2022-06-22 18:44:45.688540
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--blah')
    parser.add_argument('--foo')
    parser.add_argument('--xyz')
    parser.add_argument('--bar')
    actions = parser._optionals._actions
    assert actions[0].option_strings == ['--bar']
    assert actions[1].option_strings == ['--blah']
    assert actions[2].option_strings == ['--foo']
    assert actions[3].option_strings == ['--xyz']


# Generated at 2022-06-22 18:44:52.627677
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = Mock()
    add_runas_options(parser)

    parser.add_argument_group.assert_any_call(
        "Privilege Escalation Options",
        "control how and which user you become as on target hosts"
    )
    parser.add_argument_group.assert_any_call(
        "Privilege Escalation Prompting",
        "control how and when become passwords are prompted for"
    )



# Generated at 2022-06-22 18:44:55.052854
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args(['-v'])
    assert options.verbosity == 1

# Generated at 2022-06-22 18:44:58.296178
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    # Uncomment below line to run test on module level
    # add_fork_options(parser)
    options, remaining_args = parser.parse_known_args(["-f", "10"])
    assert options.forks == 10



# Generated at 2022-06-22 18:45:05.510170
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class = SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--bar1')
    help_output = parser.format_help()
    assert help_output.index("--bar") < help_output.index("--bar1")
    assert help_output.index("--bar1") < help_output.index("--foo")


# Generated at 2022-06-22 18:45:15.771554
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import unittest
    import argparse
    class TestPrependListAction(unittest.TestCase):
        def test_default_case(self):
            action = PrependListAction(
                option_strings=['--with-brackets'],
                dest='dest',
                nargs='+',
                default=['default argument']
            )
            namespace = argparse.Namespace(dest=[])
            action(None, namespace, ['one', 'two'], '--with-brackets')
            self.assertEqual(namespace.dest, ['one', 'two'])
    unittest.main()

#
# Helpers for OptionParser
#


# Generated at 2022-06-22 18:45:17.123887
# Unit test for function version
def test_version():
    assert _gitinfo()
    assert version('test')
    assert version()

# Generated at 2022-06-22 18:45:22.226735
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(beacon='~')('~/ansible/test') == '~/ansible/test'
    assert maybe_unfrack_path(beacon='/')('/ansible/test') == '/ansible/test'



# Generated at 2022-06-22 18:45:27.615186
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = None
    options, args = add_subset_options(parser)
    assert options == '-t, --tags TAGS[,TAGS]..., --skip-tags TAGS[,TAGS]...'
    assert args == 'only run plays and tasks tagged with these values'
    assert options, args == 'only run plays and tasks whose tags do not match these values'
# Test for function version

# Generated at 2022-06-22 18:45:30.754355
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    arguments = parser.parse_args(["-vv"])
    assert arguments.verbosity == 2

# Generated at 2022-06-22 18:45:41.888067
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    try:
        PrependListAction('-o', '--option', nargs=1, const=[1,2,3], default=[4,5,6])
    except Exception as e:
        assert 'nargs must be' in str(e)
    try:
        PrependListAction('-o', '--option', nargs=0, const=None)
    except Exception as e:
        assert 'nargs for append actions must be' in str(e)
    try:
        PrependListAction('-o', '--option', nargs=argparse.OPTIONAL, const=None)
    except Exception as e:
        assert 'must supply const' in str(e)
    p = PrependListAction('-o', '--option', nargs=argparse.OPTIONAL, const=[1,2,3])

# Generated at 2022-06-22 18:45:50.092860
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
  from mock import Mock
  from ansible.parsing.dataloader import DataLoader
  from ansible.plugins.loader import PluginLoader
  from ansible.parsing.vault import VaultLib
  from ansible.errors import AnsibleError
  from ansible.cli.parser import Parser
  from ansible.utils.context_objects import Context
  from ansible.utils.path import unfrackpath
  from ansible.utils.display import Display

  # Mock the context object on which the parser would depend for information
  context = Context()
  context._init_global_context(cli_args={})
  context.vault = VaultLib(password_files=context.cli_args.vault_password_files)

# Generated at 2022-06-22 18:46:02.524425
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    opts = parser.parse_args(['-u', 'test','-c', 'ssh', '-T', '50', '--ssh-common-args', 'test-common-args', '--sftp-extra-args', 'test-sftp-extra-args',
                              '--scp-extra-args', 'test-scp-extra-args', '--ssh-extra-args', 'test-ssh-extra-args',
                              '-k', '--connection-password-file', 'test-conn-pass-file'])
    assert opts.remote_user == 'test'
    assert opts.connection == 'ssh'
    assert opts.timeout == 50

# Generated at 2022-06-22 18:46:07.674559
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ap = argparse.ArgumentParser()
    ap.add_argument('-v', '--version', help='ansible version', action=AnsibleVersion)
    av = AnsibleVersion(option_strings=['-v', '--version'])
    av(ap, '', '', '-v')



# Generated at 2022-06-22 18:46:12.942188
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_check_options(parser)
    for opt in ['-C','--syntax-check', '-D', '--diff']:
        assert opt in [x.option_strings[0] for x in parser._actions], "{0} not in parser._actions".format(opt)



# Generated at 2022-06-22 18:46:17.836834
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    add_runas_prompt_options(parser)
    add_runas_prompt_options(parser)



# Generated at 2022-06-22 18:46:20.330662
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    t = PrependListAction(
        option_strings=['--test'],
        dest='test'
    )
    assert t.dest == 'test'



# Generated at 2022-06-22 18:46:24.343129
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class Parser(object):
        def exit(self):
            sys.exit(0)

    #print(sys.argv[0])
    namespace = argparse.Namespace()
    namespace.prog = ''
    _action = AnsibleVersion(option_strings=[])
    _action(Parser(), namespace, None)

    _action(Parser(), namespace, None, option_string='--version')


# Generated at 2022-06-22 18:46:28.836179
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '1', '-B', '2'])
    assert args.poll_interval == 1
    assert args.seconds == 2



# Generated at 2022-06-22 18:46:33.140540
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.parse_args(['--foo', 'this', '--foo=is', '--foo=sparta'])



# Generated at 2022-06-22 18:46:35.965288
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    assert parser
    parser.parse_args('--playbook-dir foo'.split())


# Generated at 2022-06-22 18:46:41.740713
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument = UnrecognizedArgument(['--foo'], dest='test', help=None, required=False, const=True)
    try:
        parser.parse_args(['--foo', 'bar'])
    except SystemExit:
        pass
    else:
        assert False, "Expected SystemExit"



# Generated at 2022-06-22 18:46:44.580453
# Unit test for function add_runas_options
def test_add_runas_options():
    test_parser = argparse.ArgumentParser()
    add_runas_options(test_parser)
    test_args = "ansible-playbook --list-tasks --extra-vars env=qa -b".split(" ")
    parsed_args = test_parser.parse_args(test_args)
    assert parsed_args.listtasks
    assert parsed_args.extra_vars == {'env': 'qa'}
    assert parsed_args.become



# Generated at 2022-06-22 18:46:50.709953
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('test-add_runas_options', usage='')
    add_runas_options(parser)
    options, _ = parser.parse_known_args()
    assert options.become_method == 'sudo'
    assert options.become == C.DEFAULT_BECOME



# Generated at 2022-06-22 18:46:57.424777
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action='store_true', help='foo help')
    parser.add_argument('--bar', action='store_true', help='bar help')
    parser.add_argument('--baz', action='store_true', help='baz help')
    parser.add_argument('--qux', action='store_true', help='qux help')
    parser.print_help()

#
# Command Line Parser
#


# Generated at 2022-06-22 18:47:07.142754
# Unit test for function add_runtask_options
def test_add_runtask_options():
    # test case for extra_vars
    # 1. add extra-vars with value
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', 'key=value'])
    assert args.extra_vars == ['key=value']
    # 2. add extra-vars without value
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', 'key'])
    assert args.extra_vars == ['key']


# Generated at 2022-06-22 18:47:07.801537
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass

# Generated at 2022-06-22 18:47:09.445164
# Unit test for function unfrack_path
def test_unfrack_path():
    oldpwd = os.getcwd()
    os.chdir('/tmp')
    assert unfrackpath('/my/dir') == '/my/dir'
    assert unfrackpath('my/dir') == '/tmp/my/dir'
    os.chdir(oldpwd)
#
# Options Classes
#


# Generated at 2022-06-22 18:47:17.068634
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # ansible_version = AnsibleVersion()
    ansible_version = AnsibleVersion(
        ['--version'],
        dest="version",
        nargs=0,
        const=None,
        default=None,
        type=None,
        choices=None,
        required=False,
        help="version",
        metavar=None)
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    assert 'Ansible Core' in ansible_version.__call__(parser, None, None)



# Generated at 2022-06-22 18:47:21.881500
# Unit test for function add_fork_options
def test_add_fork_options():
    argv = ["prog_name", "-f", "1", "host1"]
    parser = argparse.ArgumentParser(prog="prog_name", conflict_handler='resolve')
    add_fork_options(parser)
    args = parser.parse_args(argv)
    assert(args.forks == 1)


# Generated at 2022-06-22 18:47:30.993924
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    # Check definition of privilege escalation options with default values
    opts = parser.parse_args(args=[])
    assert not hasattr(opts, 'ask_pass')
    assert not hasattr(opts, 'become_ask_pass')
    assert not hasattr(opts, 'become_user')

    # Check consolidated privilege escalation
    opts = parser.parse_args(args=['--become'])
    assert opts.become

    # Check consolidated privilege escalation and ask password
    opts = parser.parse_args(args=['--become', '--ask-become-pass'])
    assert opts.become
    assert opts.become_ask_pass

    # Check consolidated privilege escalation and ask become user

# Generated at 2022-06-22 18:47:34.569257
# Unit test for function unfrack_path
def test_unfrack_path():
  path = unfrack_path(pathsep=False)("/usr/share/ansible")
  assert path == "/usr/share/ansible"


# Generated at 2022-06-22 18:47:44.552523
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@/home/user') == '@' + unfrackpath('/home/user')
    assert maybe_unfrack_path('@')('@/home/user/') == '@' + unfrackpath('/home/user/')
    assert maybe_unfrack_path('@')('@/home/user//') == '@' + unfrackpath('/home/user/')
    assert maybe_unfrack_path('@')('@/home/user//') == '@' + unfrackpath('/home/user/')
    assert maybe_unfrack_path('@')('/home/user') == '/home/user'
    assert maybe_unfrack

# Generated at 2022-06-22 18:47:54.649356
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog='test_cmd',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', '/test/test_cmd'])
    assert args.basedir == '/test/test_cmd'
    args = parser.parse_args(['--playbook-dir', '~/test/test_cmd'])
    assert args.basedir == '~/test/test_cmd'



# Generated at 2022-06-22 18:47:58.896866
# Unit test for function add_fork_options
def test_add_fork_options():
    #mock cmdline
    sys.argv = ['/bin/cmd', '-f', '10']

    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args()

    assert options.forks == 10



# Generated at 2022-06-22 18:48:04.811067
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert parser.parse_args(['--force-handlers', '--flush-cache']).force_handlers == True
    assert parser.parse_args(['--force-handlers', '--flush-cache']).flush_cache == True


# Generated at 2022-06-22 18:48:13.323266
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/usr/local/ansible') == '/usr/local/ansible'
    assert unfrack_path()('/usr/local/ansible:~') == '/usr/local/ansible:/etc/ansible'
    assert unfrack_path(pathsep=True)('/usr/local/ansible:~') == ['/usr/local/ansible', '/etc/ansible']
    assert unfrack_path()('~') == '/etc/ansible'
test_unfrack_path()



# Generated at 2022-06-22 18:48:20.931381
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test maybe_unfrack_path with an ~ in a path
    expected_result = '/path/to/home/file.yml'
    input_value = '@/path/to/home/file.yml'
    result = maybe_unfrack_path('@')(input_value)
    assert result == expected_result, "maybe_unfrack_path failed, got: %s, expected: %s" % (result, expected_result)

    # Test maybe_unfrack_path with an ~ in a path
    expected_result = '/path/to/home/file.yml'
    input_value = '@@/path/to/home/file.yml'
    result = maybe_unfrack_path('@@')(input_value)

# Generated at 2022-06-22 18:48:27.139596
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    (options, args) = parser.parse_known_args(['-M', '/tmp', '-M', '~/ansible'])
    assert options.module_path == ['/tmp', '/home/ansible']

