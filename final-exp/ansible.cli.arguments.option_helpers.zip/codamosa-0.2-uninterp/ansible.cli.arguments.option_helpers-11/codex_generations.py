

# Generated at 2022-06-16 19:41:14.309803
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'inventory', '--list-hosts', '-l', 'subset'])
    assert args.inventory == ['inventory']
    assert args.listhosts is True
    assert args.subset == 'subset'



# Generated at 2022-06-16 19:41:20.255922
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'vault_id', '--ask-vault-password', '--vault-password-file', 'vault_password_file'])
    assert options.vault_ids == ['vault_id']
    assert options.ask_vault_pass == True
    assert options.vault_password_files == ['vault_password_file']



# Generated at 2022-06-16 19:41:24.182122
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'inventory', '--list-hosts', '-l', 'limit'])
    assert options.inventory == ['inventory']
    assert options.listhosts is True
    assert options.subset == 'limit'



# Generated at 2022-06-16 19:41:29.811590
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'test', '--vault-password-file', 'test'])
    assert args.vault_ids == ['test']
    assert args.vault_password_files == ['test']
    assert args.ask_vault_pass is False



# Generated at 2022-06-16 19:41:41.924298
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'test', '--vault-password-file', 'test.txt'])
    assert args.vault_ids == ['test']
    assert args.vault_password_files == ['test.txt']
    assert args.ask_vault_pass == False
    args = parser.parse_args(['--vault-id', 'test', '--ask-vault-password'])
    assert args.vault_ids == ['test']
    assert args.vault_password_files == []
    assert args.ask_vault_pass == True

# Generated at 2022-06-16 19:41:44.143447
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])


# Generated at 2022-06-16 19:41:50.200705
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:41:52.586077
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '10'])
    assert args.forks == 10


# Generated at 2022-06-16 19:41:57.352234
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo/'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar/'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../')

# Generated at 2022-06-16 19:42:08.438208
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:42:22.212217
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']


# Generated at 2022-06-16 19:42:34.283079
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10',
                              '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p -q bastion',
                              '--sftp-extra-args', '-f', '-l',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '-k',
                              '--connection-password-file', '~/.ssh/password'])
    assert args.private_key_file == '~/.ssh/id_rsa'

# Generated at 2022-06-16 19:42:38.103901
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check is True
    assert args.syntax is True
    assert args.diff is True


# Generated at 2022-06-16 19:42:45.482496
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '--tags', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:48.802278
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:42:51.645227
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers is True
    assert args.flush_cache is True



# Generated at 2022-06-16 19:42:55.730162
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', '/tmp/test'])
    assert options.basedir == '/tmp/test'


# Generated at 2022-06-16 19:43:02.610950
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:43:07.183524
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'tree'])
    assert args.one_line == True
    assert args.tree == 'tree'


# Generated at 2022-06-16 19:43:18.830323
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:43:35.206109
# Unit test for function version
def test_version():
    assert version('ansible-test') == 'ansible-test [core 2.0.0.0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible-test\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18)\n[GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]\n  jinja version = 2.9.6\n  libyaml = True'

# Generated at 2022-06-16 19:43:46.320103
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == unfrackpath('/path/to/file')
    assert unfrack_path()('/path/to/file') == unfrackpath('/path/to/file')
    assert unfrack_path(pathsep=True)('/path/to/file:/path/to/file2') == [unfrackpath('/path/to/file'), unfrackpath('/path/to/file2')]
    assert unfrack_path(pathsep=True)('/path/to/file:/path/to/file2') == [unfrackpath('/path/to/file'), unfrackpath('/path/to/file2')]
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-16 19:43:51.645281
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:44:03.709740
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'

# Generated at 2022-06-16 19:44:15.096287
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '10'])
    assert args.task_timeout == 10
    args = parser.parse_args([])
    assert args.task_timeout == C.TASK_TIMEOUT
    args = parser.parse_args(['--task-timeout', '-10'])
    assert args.task_timeout == C.TASK_TIMEOUT
    args = parser.parse_args(['--task-timeout', '0'])
    assert args.task_timeout == C.TASK_TIMEOUT
    args = parser.parse_args(['--task-timeout', '10.0'])
    assert args.task_timeout == C.TASK_TIMEOUT

# Generated at 2022-06-16 19:44:28.312231
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('/foo') == '/foo'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('/foo/bar/') == '/foo/bar/'
    assert maybe_unfrack_path('@')('@/foo/bar/baz')

# Generated at 2022-06-16 19:44:29.256237
# Unit test for function version
def test_version():
    assert version()
    assert version('foo')

# Generated at 2022-06-16 19:44:40.509023
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:42.025621
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '10'])
    assert args.task_timeout == 10


# Generated at 2022-06-16 19:44:47.780499
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'
    ns.foo = None
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'baz'



# Generated at 2022-06-16 19:45:02.623147
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--eggs')


# Generated at 2022-06-16 19:45:10.575024
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz/../../') == '/foo'
    assert unfrack_path()('/foo/bar/baz/../../../') == '/'
    assert unfrack_

# Generated at 2022-06-16 19:45:19.752496
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:22.269532
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible')

#
# Option Parsers
#

# Generated at 2022-06-16 19:45:32.465262
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:43.750541
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:45.166570
# Unit test for function version
def test_version():
    assert version() is not None
    assert version('test') is not None

# Generated at 2022-06-16 19:45:46.390789
# Unit test for function version
def test_version():
    assert version() is not None
    assert version('test') is not None

# Generated at 2022-06-16 19:45:55.867984
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')
    assert version(prog='ansible-playbook') == version(prog='ansible-playbook')
    assert version(prog='ansible-config') == version(prog='ansible-config')
    assert version(prog='ansible-doc') == version(prog='ansible-doc')
    assert version(prog='ansible-galaxy') == version(prog='ansible-galaxy')
    assert version(prog='ansible-inventory') == version(prog='ansible-inventory')
    assert version(prog='ansible-pull') == version(prog='ansible-pull')
    assert version(prog='ansible-vault') == version(prog='ansible-vault')

# Generated at 2022-06-16 19:46:07.149725
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action="store_true", help="a")
    parser.add_argument('-b', action="store_true", help="b")
    parser.add_argument('-c', action="store_true", help="c")
    parser.add_argument('-d', action="store_true", help="d")
    parser.add_argument('-e', action="store_true", help="e")
    parser.add_argument('-f', action="store_true", help="f")
    parser.add_argument('-g', action="store_true", help="g")
    parser.add_argument('-h', action="store_true", help="h")

# Generated at 2022-06-16 19:46:33.954618
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/qux') == '/tmp/foo/bar/baz/qux'

# Generated at 2022-06-16 19:46:45.810935
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:46:54.089847
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert unfrack_path()('/etc/ansible/hosts:/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert unfrack_path(pathsep=True)('/etc/ansible/hosts:/etc/ansible/hosts') == ['/etc/ansible/hosts', '/etc/ansible/hosts']
    assert unfrack_path()('/etc/ansible/hosts:/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert unfrack_path()('/etc/ansible/hosts:/etc/ansible/hosts') == '/etc/ansible/hosts'

# Generated at 2022-06-16 19:46:56.518997
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'



# Generated at 2022-06-16 19:47:08.500610
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:47:17.996771
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:47:29.681037
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:40.637042
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:47.594240
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('/foo') == '/foo'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-16 19:47:58.741664
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file:') == '/path/to/file'
    assert unfrack_path()('/path/to/file:/path/to/another/file') == '/path/to/file:/path/to/another/file'
    assert unfrack_path()('/path/to/file:/path/to/another/file:') == '/path/to/file:/path/to/another/file'
    assert unfrack_path()('/path/to/file:/path/to/another/file:/path/to/yet/another/file') == '/path/to/file:/path/to/another/file:/path/to/yet/another/file'

# Generated at 2022-06-16 19:48:48.518075
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

# Generated at 2022-06-16 19:48:53.404954
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@@')('@@/foo/bar') == '@@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@@')('@/foo/bar') == '@/foo/bar'



# Generated at 2022-06-16 19:48:59.293412
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'



# Generated at 2022-06-16 19:49:08.677181
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')

# Generated at 2022-06-16 19:49:18.040321
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:49:29.027254
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:49:39.265939
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@tmp/foo') == '@tmp/foo'
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@@tmp/foo') == '@@tmp/foo'
    assert maybe_unfrack_path('@')('@@@/tmp/foo') == '@@@/tmp/foo'
    assert maybe_unfrack_path('@')('@@@tmp/foo') == '@@@tmp/foo'
    assert maybe_unfrack_path('@')('@@@/tmp/foo')

# Generated at 2022-06-16 19:49:50.668127
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:49:59.579205
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:50:10.266125
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz/../../') == '/foo'
    assert unfrack_path()('/foo/bar/baz/../../../') == '/'