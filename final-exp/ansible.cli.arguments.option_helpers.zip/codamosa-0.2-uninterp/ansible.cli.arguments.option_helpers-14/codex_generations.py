

# Generated at 2022-06-16 19:41:39.713814
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/../baz') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/bar/../../../baz') == '/baz'

# Generated at 2022-06-16 19:41:51.104722
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10', '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p -q bastionhost', '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.ssh/password'])
    assert options.private_key_file == '~/.ssh/id_rsa'
    assert options.remote_user == 'root'
    assert options.connection == 'ssh'
   

# Generated at 2022-06-16 19:41:54.561578
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:41:59.796037
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    assert parser.parse_args(['-K']).become_ask_pass
    assert parser.parse_args(['--become-password-file', 'foo']).become_password_file == 'foo'
    assert parser.parse_args(['-K', '--become-password-file', 'foo']).become_password_file == 'foo'



# Generated at 2022-06-16 19:42:09.848027
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10',
                              '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p bastion',
                              '--sftp-extra-args', '-f', '-l',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '-k',
                              '--connection-password-file', '~/.ssh/id_rsa'])
    assert args.private_key_file == '~/.ssh/id_rsa'
   

# Generated at 2022-06-16 19:42:15.074969
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'testuser'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'testuser'



# Generated at 2022-06-16 19:42:19.626733
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check == True
    args = parser.parse_args(['--syntax-check'])
    assert args.syntax == True
    args = parser.parse_args(['--diff'])
    assert args.diff == True


# Generated at 2022-06-16 19:42:32.564952
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:/tmp/bar') == '/tmp/foo:/tmp/bar'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')

# Generated at 2022-06-16 19:42:41.294272
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '10'])
    assert args.task_timeout == 10
    args = parser.parse_args([])
    assert args.task_timeout == C.TASK_TIMEOUT
    args = parser.parse_args(['--task-timeout', '-10'])
    assert args.task_timeout == -10
    args = parser.parse_args(['--task-timeout', '0'])
    assert args.task_timeout == 0
    args = parser.parse_args(['--task-timeout', '10.5'])
    assert args.task_timeout == 10.5
    args = parser.parse_args(['--task-timeout', 'abc'])
   

# Generated at 2022-06-16 19:42:47.771772
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert options.become is True
    assert options.become_method == 'sudo'
    assert options.become_user == 'root'



# Generated at 2022-06-16 19:43:12.273684
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', '@test.yml'])
    assert options.extra_vars == ['@test.yml']
    options = parser.parse_args(['-e', '@test.yml', '-e', '@test2.yml'])
    assert options.extra_vars == ['@test.yml', '@test2.yml']
    options = parser.parse_args(['-e', '@test.yml', '-e', '@test2.yml', '-e', 'key=value'])
    assert options.extra_vars == ['@test.yml', '@test2.yml', 'key=value']



# Generated at 2022-06-16 19:43:23.495737
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:43:28.207308
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test_dir'])
    assert args.basedir == 'test_dir'


# Generated at 2022-06-16 19:43:31.831049
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers is True
    assert args.flush_cache is True



# Generated at 2022-06-16 19:43:39.194842
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'

# Generated at 2022-06-16 19:43:44.877563
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '@/tmp/test.yml', '-e', '@/tmp/test.json', '-e', '@/tmp/test.txt'])
    assert args.extra_vars == ['/tmp/test.yml', '/tmp/test.json', '@/tmp/test.txt']



# Generated at 2022-06-16 19:43:47.731530
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version == None



# Generated at 2022-06-16 19:43:49.866516
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:44:02.497006
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:05.464801
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test_playbook_dir'])
    assert args.basedir == 'test_playbook_dir'

# Generated at 2022-06-16 19:44:23.286234
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:44:32.762881
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:44:43.874411
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:44:49.780249
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass

    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'

    ns = Namespace()
    ns.foo = 'baz'
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'baz'

#
# Option Parsers
#


# Generated at 2022-06-16 19:44:54.572607
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Test with a valid program name
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None
    # Test with an invalid program name
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:45:01.622484
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e'])
    assert args.foo == ['d', 'e', 'a', 'b', 'c']

#
# Option Parsers
#

# Generated at 2022-06-16 19:45:11.994290
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:20.561492
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:31.097569
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test PrependListAction')
    parser.add_argument('--foo', action=PrependListAction, nargs='+', default=[])
    parser.add_argument('--bar', action=PrependListAction, nargs='+', default=[])
    args = parser.parse_args(['--foo', 'a', 'b', '--bar', 'c', 'd'])
    assert args.foo == ['a', 'b']
    assert args.bar == ['c', 'd']
    args = parser.parse_args(['--bar', 'c', 'd', '--foo', 'a', 'b'])
    assert args.foo == ['a', 'b']

# Generated at 2022-06-16 19:45:33.060477
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

#
# Option Parsers
#

# Generated at 2022-06-16 19:45:46.390258
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible')

#
# Options
#

# Generated at 2022-06-16 19:45:55.867680
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:46:07.148078
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == unfrack_path()('/tmp/foo')
    assert unfrack_path()('/tmp/foo') != unfrack_path()('/tmp/bar')
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar')
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') != unfrack_path(pathsep=True)('/tmp/foo:/tmp/baz')
    assert unf

# Generated at 2022-06-16 19:46:18.341535
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', None)
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', [])
    assert ns.foo == []
    ensure_value(ns, 'foo', [1])
    assert ns.foo == [1]
    ensure_value(ns, 'foo', None)
    assert ns.foo == [1]
    ensure_value(ns, 'foo', [2])
    assert ns.foo == [2]


#
# Main OptionParser
#

# Generated at 2022-06-16 19:46:29.494700
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class TestParser(argparse.ArgumentParser):
        def error(self, message):
            raise RuntimeError(message)

    parser = TestParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs=1)
    parser.add_argument('--baz', action=PrependListAction, nargs=0)
    parser.add_argument('--qux', action=PrependListAction, nargs=argparse.OPTIONAL)
    parser.add_argument('--quux', action=PrependListAction, nargs=argparse.OPTIONAL, const='const')

    # Test that nargs must be > 0

# Generated at 2022-06-16 19:46:39.945661
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/b/c') == '/a/b/c'
    assert unfrack_path()('/a/b/c/') == '/a/b/c'
    assert unfrack_path()('/a/b/c/.') == '/a/b/c'
    assert unfrack_path()('/a/b/c/..') == '/a/b'
    assert unfrack_path()('/a/b/c/../..') == '/a'
    assert unfrack_path()('/a/b/c/../../..') == '/'
    assert unfrack_path()('/a/b/c/../../../') == '/'
    assert unfrack_path()('/a/b/c/../../../..') == '/'
    assert unfrack_path()

# Generated at 2022-06-16 19:46:43.370922
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:46:46.290360
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:46:48.336637
# Unit test for function version
def test_version():
    assert version() == '2.9.0 (detached HEAD bf9d9d9) last updated 2019/11/26 17:00:00 (GMT -0500)'


# Generated at 2022-06-16 19:46:55.938514
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:47:13.318198
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:47:21.072733
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.add_argument('-d', action='store_true', help='d help')
    parser.add_argument('-e', action='store_true', help='e help')
    parser.add_argument('-f', action='store_true', help='f help')
    parser.add_argument('-g', action='store_true', help='g help')
    parser.add_argument('-h', action='store_true', help='h help')
   

# Generated at 2022-06-16 19:47:24.482616
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:47:34.595695
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(prog='ansible-config')
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux'])
    assert args.foo == ['qux', 'bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux', '--foo', 'quux'])

# Generated at 2022-06-16 19:47:46.465569
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path()('${HOME}/foo') == os.path.expandvars('${HOME}/foo')



# Generated at 2022-06-16 19:47:52.375934
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    options = dict()
    options['module_path'] = None
    options['module_path'] = '/home/centos/ansible/lib/ansible/modules/cloud/amazon'
    options['module_path'] = '/home/centos/ansible/lib/ansible/modules/cloud/amazon'
    options['module_path'] = '/home/centos/ansible/lib/ansible/modules/cloud/amazon'
    options['module_path'] = '/home/centos/ansible/lib/ansible/modules/cloud/amazon'
    options['module_path'] = '/home/centos/ansible/lib/ansible/modules/cloud/amazon'

# Generated at 2022-06-16 19:48:03.958196
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'

# Generated at 2022-06-16 19:48:08.750694
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction)
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--bar', '3', '--bar', '4'])
    assert args.foo == ['1', '2']
    assert args.bar == ['3', '4']



# Generated at 2022-06-16 19:48:14.058048
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:48:25.819725
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:48:41.040884
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:48:48.958250
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux'])
    assert args.foo == ['qux', 'bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux', 'quux'])
    assert args.foo == ['qux', 'quux', 'bar', 'baz']



# Generated at 2022-06-16 19:48:55.416618
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:49:06.232719
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:49:11.246547
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:49:19.413424
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'

# Generated at 2022-06-16 19:49:27.516423
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:49:33.473094
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args('--foo a b c'.split())
    assert args.foo == ['a', 'b', 'c']



# Generated at 2022-06-16 19:49:41.049221
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../../') == '/'

# Generated at 2022-06-16 19:49:51.521165
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:50:12.291901
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-d')
    parser.add_argument('-c')
    parser.add_argument('-f')
    parser.add_argument('-e')
    parser.print_help()


# Generated at 2022-06-16 19:50:13.394607
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:50:20.921609
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file:') == '/path/to/file'
    assert unfrack_path()('/path/to/file:/path/to/file2') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:') == '/path/to/file:/path/to/file2'
    assert unfrack_path(pathsep=True)('/path/to/file:/path/to/file2') == ['/path/to/file', '/path/to/file2']
    assert unfrack_path(pathsep=True)('/path/to/file:/path/to/file2:')

# Generated at 2022-06-16 19:50:27.285855
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:50:29.117803
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])


# Generated at 2022-06-16 19:50:35.517907
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz/../../') == '/foo'
    assert unfrack_path()('/foo/bar/baz/../../../') == '/'
    assert unfrack_path()('/foo/bar/baz/../../../../') == '/'
    assert unfrack_path()

# Generated at 2022-06-16 19:50:38.146343
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:50:48.691222
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:50:52.950112
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'a', '--foo', 'b', '--foo', 'c'])
    assert args.foo == ['c', 'b', 'a']
