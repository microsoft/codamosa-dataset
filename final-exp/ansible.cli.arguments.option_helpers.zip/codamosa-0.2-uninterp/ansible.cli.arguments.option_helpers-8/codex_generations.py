

# Generated at 2022-06-16 19:41:52.295759
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20



# Generated at 2022-06-16 19:41:55.433291
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '5', '-B', '10'])
    assert options.poll_interval == 5
    assert options.seconds == 10



# Generated at 2022-06-16 19:41:57.557755
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:42:01.647186
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:42:05.673643
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='test')
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20


# Generated at 2022-06-16 19:42:11.298621
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:15.346123
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check is True
    assert args.syntax is True
    assert args.diff is True


# Generated at 2022-06-16 19:42:27.603284
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux'

# Generated at 2022-06-16 19:42:37.844688
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:42:42.089493
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20



# Generated at 2022-06-16 19:43:35.838297
# Unit test for function version
def test_version():
    assert version() is not None

# Generated at 2022-06-16 19:43:39.853962
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '1'])
    assert args.task_timeout == 1


# Generated at 2022-06-16 19:43:48.792894
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')
    assert maybe_

# Generated at 2022-06-16 19:44:01.778827
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10',
                              '--ssh-common-args', '-o ProxyCommand="ssh -W %h:%p -q bastion"',
                              '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R',
                              '-k', '--connection-password-file', '~/.ssh/pass'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'

# Generated at 2022-06-16 19:44:08.441546
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')

# Generated at 2022-06-16 19:44:16.956716
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:18.091478
# Unit test for function version
def test_version():
    assert version()
    assert version("test")

# Generated at 2022-06-16 19:44:30.333758
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['-u', 'test_user', '-c', 'test_connection', '-T', '10', '--ssh-common-args', 'test_ssh_common_args',
                              '--sftp-extra-args', 'test_sftp_extra_args', '--scp-extra-args', 'test_scp_extra_args',
                              '--ssh-extra-args', 'test_ssh_extra_args', '-k', '--connection-password-file', 'test_connection_password_file'])
    assert args.remote_user == 'test_user'
    assert args.connection == 'test_connection'
    assert args.timeout == 10
    assert args.ssh_common

# Generated at 2022-06-16 19:44:33.584485
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'su', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'su'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:44:38.467344
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:44:51.431544
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') != '@/foo/bar'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-16 19:44:58.303425
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') != '@/path/to/file'
    assert maybe_unfrack_path('@')('/path/to/file') == '/path/to/file'


# Generated at 2022-06-16 19:45:08.171822
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/.') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar/../baz') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/.') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/..') == '/tmp/foo'

# Generated at 2022-06-16 19:45:17.863326
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:45:29.896827
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/quux') == '/foo/bar/baz/qux/quux'

# Generated at 2022-06-16 19:45:41.816672
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:45:52.731229
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:45:58.177194
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:46:08.322254
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file/') == '/path/to/file'
    assert unfrack_path()('/path/to/file/.') == '/path/to/file'
    assert unfrack_path()('/path/to/file/..') == '/path/to'
    assert unfrack_path()('/path/to/file/../..') == '/path'
    assert unfrack_path()('/path/to/file/../../..') == '/'
    assert unfrack_path()('/path/to/file/../../../..') == '/'
    assert unfrack_path()('/path/to/file/../../../../..') == '/'
    assert unfrack_

# Generated at 2022-06-16 19:46:10.584933
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-16 19:46:29.372327
# Unit test for function version
def test_version():
    assert version()



# Generated at 2022-06-16 19:46:35.623421
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/../baz') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../../baz') == '/tmp/baz'

# Generated at 2022-06-16 19:46:47.115975
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') != '@/path/to/file'
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + os.path.abspath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') != '@' + os.path.abspath('/path/to/file')

# Generated at 2022-06-16 19:46:55.319875
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:47:06.999381
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')

# Generated at 2022-06-16 19:47:11.777933
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']



# Generated at 2022-06-16 19:47:20.069231
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('~/foo/bar') == '~/foo/bar'
    assert maybe_unfrack_path('@')('@./foo/bar') == '@' + unfrackpath('./foo/bar')
    assert maybe_unfrack_path('@')('./foo/bar') == './foo/bar'

# Generated at 2022-06-16 19:47:31.504261
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:42.276650
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:47:47.448499
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'



# Generated at 2022-06-16 19:48:35.045739
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_

# Generated at 2022-06-16 19:48:45.117807
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:48:52.946405
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs='+')
    parser.add_argument('--baz', action=PrependListAction, nargs='+')
    parser.add_argument('--bam', action=PrependListAction, nargs='+')
    parser.add_argument('--bap', action=PrependListAction, nargs='+')
    parser.add_argument('--bak', action=PrependListAction, nargs='+')
    parser.add_argument('--bau', action=PrependListAction, nargs='+')

# Generated at 2022-06-16 19:49:04.648100
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unf

# Generated at 2022-06-16 19:49:11.001826
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo/'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar/'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../')

# Generated at 2022-06-16 19:49:17.298893
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') != '@/foo/bar'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') != '@' + unfrackpath('/foo/bar')



# Generated at 2022-06-16 19:49:28.688798
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/ ') == '/foo/bar'
    assert unfrack_path()('/foo/bar/ /foo/baz') == '/foo/bar/ /foo/baz'
    assert unfrack_path(pathsep=True)('/foo/bar/:/foo/baz') == ['/foo/bar', '/foo/baz']
    assert unfrack_path(pathsep=True)('/foo/bar/:/foo/baz/') == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-16 19:49:39.139893
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/etc/ansible/hosts') == '@' + unfrackpath('/etc/ansible/hosts')
    assert maybe_unfrack_path('@')('@/etc/ansible/hosts') == '@' + unfrackpath('/etc/ansible/hosts')
    assert maybe_unfrack_path('@')('@/etc/ansible/hosts') == '@' + unfrackpath('/etc/ansible/hosts')
    assert maybe_unfrack_path('@')('@/etc/ansible/hosts') == '@' + unfrackpath('/etc/ansible/hosts')

# Generated at 2022-06-16 19:49:45.591907
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('-') == '-'
    assert unfrack_path(pathsep=True)('-') == ['-']



# Generated at 2022-06-16 19:49:51.448515
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') != '@/tmp/foo'

