

# Generated at 2022-06-16 19:41:51.023579
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:41:56.948467
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:42:04.260499
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:07.185816
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:42:13.001379
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:17.449488
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'hosts', '--list-hosts', '-l', 'subset'])
    assert args.inventory == ['hosts']
    assert args.listhosts
    assert args.subset == 'subset'


# Generated at 2022-06-16 19:42:29.677139
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'ansible', '-c', 'ssh', '-T', '10', '--ssh-common-args', '-o ProxyCommand="ssh -W %h:%p gateway"', '--sftp-extra-args', '-f', '-l', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.ansible/conn_pass'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'ansible'
    assert args.connection

# Generated at 2022-06-16 19:42:34.194107
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers is True
    assert args.flush_cache is True



# Generated at 2022-06-16 19:42:37.127083
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test_dir'])
    assert args.basedir == 'test_dir'



# Generated at 2022-06-16 19:42:43.239433
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'test.txt'])
    assert args.become_password_file == 'test.txt'
    args = parser.parse_args(['-K', '--become-password-file', 'test.txt'])
    assert args.become_ask_pass is True
    assert args.become_password_file == 'test.txt'
    args = parser.parse_args(['--become-password-file', 'test.txt', '-K'])
    assert args.become_ask_pass is True
    assert args

# Generated at 2022-06-16 19:42:55.150248
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '/tmp/test/path'
    assert maybe_unfrack_path('@')('@' + test_path) == '@' + test_path
    assert maybe_unfrack_path('@')(test_path) == test_path


# Generated at 2022-06-16 19:43:02.243624
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:43:04.973297
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_async_options(parser)
    options = parser.parse_args(['-B', '10'])
    assert options.seconds == 10
    options = parser.parse_args(['-P', '10'])
    assert options.poll_interval == 10
    options = parser.parse_args(['-B', '10', '-P', '10'])
    assert options.seconds == 10
    assert options.poll_interval == 10



# Generated at 2022-06-16 19:43:07.980077
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:43:12.981570
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../../bar') == '/bar'

# Generated at 2022-06-16 19:43:23.697576
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:43:29.961984
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:43:37.471555
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    assert ensure_value(ns, 'foo', 'bar') == 'bar'
    assert ns.foo == 'bar'
    assert ensure_value(ns, 'foo', 'baz') == 'bar'
    assert ns.foo == 'bar'
    ns.foo = 'baz'
    assert ensure_value(ns, 'foo', 'bar') == 'baz'
    assert ns.foo == 'baz'



# Generated at 2022-06-16 19:43:41.059301
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20



# Generated at 2022-06-16 19:43:49.433370
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='test')
    parser.add_argument('-a', action=PrependListAction, nargs='+')
    parser.add_argument('-b', action=PrependListAction, nargs='+')
    parser.add_argument('-c', action=PrependListAction, nargs='+')
    parser.add_argument('-d', action=PrependListAction, nargs='+')
    parser.add_argument('-e', action=PrependListAction, nargs='+')
    parser.add_argument('-f', action=PrependListAction, nargs='+')

# Generated at 2022-06-16 19:44:06.682987
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']

# Generated at 2022-06-16 19:44:09.512651
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--ask-vault-password', '--vault-password-file', 'baz'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.ask_vault_pass is True
    assert args.vault_password_files == ['baz']


# Generated at 2022-06-16 19:44:13.320351
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--ask-vault-password', '--vault-password-file', 'foo', '--vault-password-file', 'bar'])
    assert options.vault_ids == ['foo', 'bar']
    assert options.ask_vault_pass
    assert options.vault_password_files == ['foo', 'bar']



# Generated at 2022-06-16 19:44:20.484282
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', '@prompt', '--vault-password-file', 'foo.txt'])
    assert options.vault_ids == ['@prompt']
    assert options.vault_password_files == ['foo.txt']


# Generated at 2022-06-16 19:44:27.358434
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test', '--vault-password-file', 'test'])
    assert options.vault_ids == ['test']
    assert options.vault_password_files == ['test']
    assert options.ask_vault_pass == False



# Generated at 2022-06-16 19:44:34.526936
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz/../../') == '/foo'
    assert unfrack_path()('/foo/bar/baz/../../../') == '/'
    assert unfrack_path()('/foo/bar/baz/../../../../') == '/'
    assert unfrack_path()

# Generated at 2022-06-16 19:44:45.037122
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:44:54.332541
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:04.016930
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz//') == '@' + unfrackpath('/foo/bar/baz//')


# Generated at 2022-06-16 19:45:11.570240
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert unfrack_path()('~/foo/bar:/baz/qux') == os.path.expanduser('~/foo/bar') + ':/baz/qux'

# Generated at 2022-06-16 19:45:30.925075
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('@~/foo/bar/') == '@' + unfrackpath('~/foo/bar/')
    assert maybe_unfrack_path('@')('@./foo/bar') == '@./foo/bar'

# Generated at 2022-06-16 19:45:38.686302
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help

    parser = CLI.base_parser(constants=C, usage='%(prog)s [options]',
                             desc="Ansible command line tool")
    opt_help.add_version_option(parser)
    args = parser.parse_args(['--version'])
    assert args.version is True
    assert args.version_info is False
    assert args.verbosity == 0



# Generated at 2022-06-16 19:45:41.950136
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:45:52.824868
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo=d', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args

# Generated at 2022-06-16 19:46:04.892833
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:11.098193
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')


# Generated at 2022-06-16 19:46:20.707976
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:46:21.485906
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:46:32.123295
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')
   

# Generated at 2022-06-16 19:46:43.526327
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:47:09.286157
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:18.423686
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@@@/foo/bar') == '@@@/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@@') == '@@'
    assert maybe_unfrack_path('@')('@@@') == '@@@'
    assert maybe_unfrack_path('@')('@@@foo') == '@@@foo'

# Generated at 2022-06-16 19:47:29.847045
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:47:40.766242
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == '~/foo'
    assert unfrack_path()('~/foo/bar') == '~/foo/bar'
    assert unfrack_path()('~/foo/bar:/baz/qux') == '~/foo/bar:/baz/qux'

# Generated at 2022-06-16 19:47:50.125950
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path()('${HOME}/foo') == os.path.expandvars('${HOME}/foo')

# Generated at 2022-06-16 19:48:02.245502
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:04.361984
# Unit test for function version
def test_version():
    assert version() == version(prog=None)
    assert version(prog='ansible') == version(prog='ansible')

#
# Option Parsers
#

# Generated at 2022-06-16 19:48:08.860679
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test PrependListAction')
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']

# Generated at 2022-06-16 19:48:11.414144
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']



# Generated at 2022-06-16 19:48:22.765913
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@/') == '@'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:49:03.910330
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'



# Generated at 2022-06-16 19:49:10.605782
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:19.192732
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:49:20.156725
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass



# Generated at 2022-06-16 19:49:23.112506
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:49:26.852891
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None



# Generated at 2022-06-16 19:49:27.575542
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

# Generated at 2022-06-16 19:49:39.010363
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:50.668153
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:49:54.985980
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Create a mock parser
    class MockParser(object):
        def __init__(self):
            self.prog = 'mock_parser'
        def exit(self):
            pass
    # Create an instance of AnsibleVersion
    ansible_version = AnsibleVersion(option_strings=['--version'])
    # Call method __call__ of class AnsibleVersion
    ansible_version(MockParser(), None, None)


# Generated at 2022-06-16 19:50:44.504373
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    options = dict()
    options['module_path'] = None
    options['module_path'] = ['/home/centos/my_modules']
    options['module_path'] = ['/home/centos/my_modules']
    options['module_path'] = ['/home/centos/my_modules']
    options['module_path'] = ['/home/centos/my_modules']
    options['module_path'] = ['/home/centos/my_modules']
    options['module_path'] = ['/home/centos/my_modules']
    options['module_path'] = ['/home/centos/my_modules']

# Generated at 2022-06-16 19:50:54.201226
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file:') == '/path/to/file'
    assert unfrack_path()('/path/to/file:/path/to/file2') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:/path/to/file3') == '/path/to/file:/path/to/file2:/path/to/file3'