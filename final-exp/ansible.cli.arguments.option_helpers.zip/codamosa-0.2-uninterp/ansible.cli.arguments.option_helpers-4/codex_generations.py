

# Generated at 2022-06-16 19:41:40.839379
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible-playbook')

#
# Option Parsers
#

# Generated at 2022-06-16 19:41:52.092774
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:42:01.447744
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@@@/foo/bar') == '@@@/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@@') == '@@'
    assert maybe_unfrack_path('@')('@@@') == '@@@'
    assert maybe_unfrack_

# Generated at 2022-06-16 19:42:11.343186
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '30', '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p bastion', '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.vault_pass.txt'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'
    assert args.connection == 'ssh'
   

# Generated at 2022-06-16 19:42:19.939818
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('foo') == unfrackpath('foo')
    assert unfrack_path(pathsep=True)('foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('foo:bar:') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('foo::bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('foo:bar:baz') == [unfrackpath('foo'), unfrackpath('bar'), unfrackpath('baz')]

# Generated at 2022-06-16 19:42:33.117352
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path()('${HOME}/foo') == os.path.expandvars('${HOME}/foo')

# Generated at 2022-06-16 19:42:35.150938
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    return parser



# Generated at 2022-06-16 19:42:38.287264
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:42:41.092715
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test_vault_id', '--vault-password-file', 'test_vault_password_file'])
    assert options.vault_ids == ['test_vault_id']
    assert options.vault_password_files == ['test_vault_password_file']


# Generated at 2022-06-16 19:42:47.036100
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-B', '10'])
    assert args.seconds == 10
    args = parser.parse_args(['-P', '10'])
    assert args.poll_interval == 10


# Generated at 2022-06-16 19:43:03.327159
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:43:07.074934
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:43:18.731457
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-d')
    parser.add_argument('-c')
    parser.add_argument('-f')
    parser.add_argument('-e')
    parser.add_argument('-h')
    parser.add_argument('-g')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:43:23.576961
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:43:27.655775
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:43:30.608456
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:43:37.984320
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')

# Generated at 2022-06-16 19:43:47.632791
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:43:53.841506
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:44:04.818140
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:44:13.709721
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass



# Generated at 2022-06-16 19:44:17.615004
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:44:24.112895
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', 'foo=bar', '-e', '@/tmp/foo.yml'])
    assert options.extra_vars == ['foo=bar', '/tmp/foo.yml']



# Generated at 2022-06-16 19:44:33.099712
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:44.031163
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:44:47.779983
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:44:55.341673
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/tmp/foo') == '/tmp/foo'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar:/tmp/baz') == ['/tmp/foo', '/tmp/bar', '/tmp/baz']
    assert unfrack_path(pathsep=True)('/tmp/foo::/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo::/tmp/bar:/tmp/baz') == ['/tmp/foo', '/tmp/bar', '/tmp/baz']

# Generated at 2022-06-16 19:44:57.480759
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'hosts', '--list-hosts', '-l', 'subset'])
    assert args.inventory == ['hosts']
    assert args.listhosts == True
    assert args.subset == 'subset'



# Generated at 2022-06-16 19:45:00.135998
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:45:04.614460
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', '@/tmp/foo.yml', '-e', '@/tmp/bar.yml'])
    assert options.extra_vars == ['/tmp/foo.yml', '/tmp/bar.yml']



# Generated at 2022-06-16 19:45:33.138481
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp/') == '/tmp'

# Generated at 2022-06-16 19:45:38.336900
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'


#
# Option Parser
#

# Generated at 2022-06-16 19:45:48.519837
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:45:56.819454
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unf

# Generated at 2022-06-16 19:46:07.487435
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unf

# Generated at 2022-06-16 19:46:12.805016
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'



# Generated at 2022-06-16 19:46:20.366935
# Unit test for function version
def test_version():
    assert version() == '2.9.1 (ansible-base 2.9.1)\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3/dist-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.7.3 (default, Apr  3 2019, 05:39:12) \n[GCC 8.3.0]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:46:31.402799
# Unit test for function version
def test_version():
    assert version() == '2.9.6 (devel bd2e6f7a6) last updated 2020/02/04 18:12:13 (GMT -0500)\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3.6/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.6.8 (default, Apr 25 2019, 21:02:35) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:46:34.777294
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-16 19:46:46.672598
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:05.354641
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/.') == '/foo/bar'
    assert unfrack_path()('/foo/bar/..') == '/foo'
    assert unfrack_path()('/foo/bar/../baz') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../../baz') == '/baz'
    assert unfrack_path()('/foo/bar/../../../baz') == '/baz'
    assert unfrack_path()('/foo/bar/../../../../baz') == '/baz'

# Generated at 2022-06-16 19:47:15.752612
# Unit test for function version
def test_version():
    assert version('ansible-playbook') == 'ansible-playbook [core 2.0.0.0-1.el7.centos]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible-playbook\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]\n  jinja version = 2.9.6\n  libyaml = True'

# Generated at 2022-06-16 19:47:22.236831
# Unit test for function version
def test_version():
    assert version() == version(prog=None)
    assert version(prog='ansible') == version(prog='ansible')
    assert version(prog='ansible') != version(prog='ansible-playbook')
    assert version(prog='ansible') != version(prog=None)
    assert version(prog='ansible') != version(prog='ansible-config')
    assert version(prog='ansible') != version(prog='ansible-connection')
    assert version(prog='ansible') != version(prog='ansible-console')
    assert version(prog='ansible') != version(prog='ansible-doc')
    assert version(prog='ansible') != version(prog='ansible-galaxy')

# Generated at 2022-06-16 19:47:27.549034
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b'])
    assert args.foo == ['a', 'b']
    args = parser.parse_args(['--foo', 'a', 'b', '--foo', 'c', 'd'])
    assert args.foo == ['c', 'd', 'a', 'b']
    args = parser.parse_args(['--foo', 'a', 'b', '--foo', 'c', 'd', '--foo', 'e', 'f'])
    assert args.foo == ['e', 'f', 'c', 'd', 'a', 'b']



# Generated at 2022-06-16 19:47:39.100732
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file:') == '/path/to/file'
    assert unfrack_path()('/path/to/file:/path/to/file2') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:/path/to/file3') == '/path/to/file:/path/to/file2:/path/to/file3'

# Generated at 2022-06-16 19:47:49.024822
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:48:00.530269
# Unit test for function version
def test_version():
    assert version('ansible-playbook') == 'ansible-playbook [core 2.9.0.dev0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3/dist-packages/ansible\n  ansible collection location = /usr/share/ansible/collections:/usr/share/ansible/collections\n  executable location = /usr/bin/ansible-playbook\n  python version = 3.7.3 (default, Apr  3 2019, 05:39:12) \n[GCC 8.3.0]\n  jinja version = 2.10\n  libyaml = True'


# Generated at 2022-06-16 19:48:09.116964
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo//bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo//bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar//') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar//') == '/tmp/foo/bar'

# Generated at 2022-06-16 19:48:19.384241
# Unit test for function version
def test_version():
    assert version() == """2.9.0
  config file = /etc/ansible/ansible.cfg
  configured module search path = Default w/o overrides
  ansible python module location = /usr/lib/python3.6/site-packages/ansible
  ansible collection location = /usr/share/ansible/collections:/usr/share/ansible/collections
  executable location = /usr/bin/ansible
  python version = 3.6.8 (default, Apr 25 2019, 21:02:35)
[GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]
  jinja version = 2.10
  libyaml = True"""


# Generated at 2022-06-16 19:48:24.989728
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction)
    args = parser.parse_args('--foo 1 --bar 2 --foo 3'.split())
    assert args.foo == ['3', '1']
    assert args.bar == ['2']



# Generated at 2022-06-16 19:48:48.232471
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']

# Generated at 2022-06-16 19:48:54.993211
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.add_argument('--foo', action='store_true', help='foo help')
    parser.add_argument('--bar', action='store_true', help='bar help')
    parser.add_argument('--baz', action='store_true', help='baz help')
    parser.add_argument('--long', action='store_true', help='long help')

# Generated at 2022-06-16 19:49:06.198772
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:49:17.793329
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux'])
    assert args.foo == ['qux', 'bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux', 'quux'])
    assert args.foo == ['qux', 'quux', 'bar', 'baz']


# Generated at 2022-06-16 19:49:29.027346
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:39.265645
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../../bar') == '/bar'

# Generated at 2022-06-16 19:49:50.668708
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:49:59.665620
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']

# Generated at 2022-06-16 19:50:10.306447
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:50:14.685917
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']
