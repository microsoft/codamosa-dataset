

# Generated at 2022-06-16 19:41:26.300646
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert args.check is True
    assert args.syntax is True
    assert args.diff is True


# Generated at 2022-06-16 19:41:33.491018
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'localhost'])
    assert args.inventory == ['localhost']
    args = parser.parse_args(['-i', 'localhost', '-i', '127.0.0.1'])
    assert args.inventory == ['localhost', '127.0.0.1']
    args = parser.parse_args(['--inventory-file', 'localhost'])
    assert args.inventory == ['localhost']
    args = parser.parse_args(['--inventory-file', 'localhost', '--inventory-file', '127.0.0.1'])
    assert args.inventory == ['localhost', '127.0.0.1']

# Generated at 2022-06-16 19:41:38.700351
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'inventory', '--list-hosts', '-l', 'subset'])
    assert options.inventory == ['inventory']
    assert options.listhosts is True
    assert options.subset == 'subset'



# Generated at 2022-06-16 19:41:47.187006
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']


# Generated at 2022-06-16 19:41:52.295342
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', '~/ansible/playbooks'])
    assert args.basedir == '~/ansible/playbooks'



# Generated at 2022-06-16 19:41:55.862511
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test_vault_id', '--ask-vault-password', '--vault-password-file', 'test_vault_password_file'])
    assert options.vault_ids == ['test_vault_id']
    assert options.ask_vault_pass == True
    assert options.vault_password_files == ['test_vault_password_file']



# Generated at 2022-06-16 19:41:58.693627
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None



# Generated at 2022-06-16 19:42:02.880305
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', '@/path/to/file.yml'])
    assert options.extra_vars == ['/path/to/file.yml']
    options = parser.parse_args(['-e', '@/path/to/file.json'])
    assert options.extra_vars == ['/path/to/file.json']
    options = parser.parse_args(['-e', '@/path/to/file.yaml'])
    assert options.extra_vars == ['/path/to/file.yaml']
    options = parser.parse_args(['-e', '@/path/to/file.txt'])
    assert options.extra_vars

# Generated at 2022-06-16 19:42:07.609997
# Unit test for function version
def test_version():
    assert version('ansible-playbook') == 'ansible-playbook [core 2.10.0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3/dist-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible-playbook\n  python version = 3.8.2 (default, Apr 27 2020, 15:53:34)\n[GCC 9.3.0]\n  jinja version = 2.11.2\n  libyaml = True'

# Generated at 2022-06-16 19:42:11.769014
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:42:32.024477
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:42:34.328278
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:42:45.384541
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:42:49.873801
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20


# Generated at 2022-06-16 19:42:54.856644
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20


# Generated at 2022-06-16 19:42:58.424095
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:43:03.579963
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-B', '10', '-P', '5'])
    assert args.poll_interval == 5
    assert args.seconds == 10


# Generated at 2022-06-16 19:43:15.736022
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10', '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p gateway', '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.ssh/pass'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'
    assert args.connection == 'ssh'
    assert args.timeout

# Generated at 2022-06-16 19:43:25.300768
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/usr/local/bin') == '/usr/local/bin'
    assert unfrack_path()('/usr/local/bin:/usr/bin') == '/usr/local/bin:/usr/bin'
    assert unfrack_path(pathsep=True)('/usr/local/bin:/usr/bin') == ['/usr/local/bin', '/usr/bin']
    assert unfrack_path(pathsep=True)('/usr/local/bin:/usr/bin:/usr/local/sbin') == ['/usr/local/bin', '/usr/bin', '/usr/local/sbin']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/ansible') == os.path.expanduser('~/ansible')

# Generated at 2022-06-16 19:43:35.973064
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:43:49.028747
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.add_argument('-d', action='store_true', help='d help')
    parser.add_argument('-e', action='store_true', help='e help')
    parser.add_argument('-f', action='store_true', help='f help')
    parser.add_argument('-g', action='store_true', help='g help')
    parser.add_argument('-h', action='store_true', help='h help')
   

# Generated at 2022-06-16 19:44:01.908768
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:13.160753
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:17.566168
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers
    assert args.flush_cache


# Generated at 2022-06-16 19:44:30.016993
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b'])
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'
    assert args.become_ask_pass == False
    assert args.ask_sudo_pass == False
    assert args.ask_su_pass == False
    assert args.ask_pass == False
    assert args.become_ask_pass == False
    assert args.become_ask_sudo_pass == False
    assert args.become_ask_su_pass == False
    assert args.become_ask_pass == False

# Generated at 2022-06-16 19:44:37.387265
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == unfrackpath('/path/to/file')
    assert unfrack_path(pathsep=True)('/path/to/file:/path/to/file2') == [unfrackpath('/path/to/file'), unfrackpath('/path/to/file2')]
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-16 19:44:42.062594
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'


# Generated at 2022-06-16 19:44:45.664813
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:44:54.660834
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/a/b/c') == '/a/b/c'
    assert unfrack_path(pathsep=False)('~/a/b/c') == os.path.expanduser('~/a/b/c')
    assert unfrack_path(pathsep=False)('~/a/b/c/') == os.path.expanduser('~/a/b/c/')
    assert unfrack_path(pathsep=False)('~/a/b/c/') == os.path.expanduser('~/a/b/c/')
    assert unfrack_path(pathsep=False)('~/a/b/c/') == os.path.expanduser('~/a/b/c/')
    assert unfrack

# Generated at 2022-06-16 19:44:59.922406
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.print_help()


# Generated at 2022-06-16 19:45:13.124615
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.prog = 'ansible'
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:45:21.332739
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/.') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar/../baz') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/.') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../baz/..') == '/tmp/foo'

# Generated at 2022-06-16 19:45:31.708158
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/usr/share/ansible/') == '/usr/share/ansible'
    assert unfrack_path()('/usr/share/ansible') == '/usr/share/ansible'
    assert unfrack_path()('/usr/share/ansible/') == '/usr/share/ansible'
    assert unfrack_path()('/usr/share/ansible') == '/usr/share/ansible'
    assert unfrack_path()('/usr/share/ansible/') == '/usr/share/ansible'
    assert unfrack_path()('/usr/share/ansible') == '/usr/share/ansible'
    assert unfrack_path()('/usr/share/ansible/') == '/usr/share/ansible'

# Generated at 2022-06-16 19:45:43.170568
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')
   

# Generated at 2022-06-16 19:45:51.411099
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:45:53.895681
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:46:05.966899
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:46:11.403160
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:46:13.904819
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['--tags', 'tag1', '--tags', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:46:17.928426
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    ns = Namespace()
    assert ensure_value(ns, 'foo', 'bar') == 'bar'
    assert ns.foo == 'bar'
    assert ensure_value(ns, 'foo', 'baz') == 'bar'
    assert ns.foo == 'bar'


#
# Main OptionParser
#

# Generated at 2022-06-16 19:46:35.013327
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:46:46.839850
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/../baz') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/../qux') == '/foo/qux'
    assert unfrack_path()('/foo/bar/../baz/../qux/') == '/foo/qux'
    assert unfrack_path()('/foo/bar/../baz/../qux/../') == '/foo'

# Generated at 2022-06-16 19:46:55.106377
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:46:58.049565
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])


# Generated at 2022-06-16 19:47:02.440930
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.prog = 'ansible-playbook'
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:47:05.633900
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:47:12.575176
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:/tmp/bar') == '/tmp/foo:/tmp/bar'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-16 19:47:16.121621
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:47:22.405608
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-16 19:47:32.588968
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:47:52.186114
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:47:52.932647
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:47:53.571886
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:48:03.455436
# Unit test for function version
def test_version():
    assert version() == '2.9.0\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 2.7.5 (default, Aug  7 2019, 00:51:29)\n[GCC 4.8.5 20150623 (Red Hat 4.8.5-39)]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:48:12.399118
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert unfrack_path()('~/foo/bar:/baz/qux') == os.path.expanduser('~/foo/bar:/baz/qux')

# Generated at 2022-06-16 19:48:21.191941
# Unit test for function version
def test_version():
    assert version() == '2.8.0\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18)\n[GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:48:30.439703
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:33.492752
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None
    assert args.__dict__ == {}


# Generated at 2022-06-16 19:48:36.026789
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:48:39.671239
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:49:09.888429
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo/:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo/../bar:/tmp/foo/../baz') == ['/tmp/bar', '/tmp/baz']

# Generated at 2022-06-16 19:49:18.766004
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:49:29.271001
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser

# Generated at 2022-06-16 19:49:39.349690
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert unfrack_path()('/etc/ansible/hosts:/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert unfrack_path(pathsep=True)('/etc/ansible/hosts:/etc/ansible/hosts') == ['/etc/ansible/hosts', '/etc/ansible/hosts']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert unfrack_path()('/etc/ansible/hosts') == '/etc/ansible/hosts'

# Generated at 2022-06-16 19:49:44.079948
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/.') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar/../baz') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/bar/../../../baz') == '/baz'
    assert unfrack_path()('/tmp/foo/bar/../../../../baz') == '/baz'

# Generated at 2022-06-16 19:49:53.295258
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:49:57.164905
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/bar/foo') == '/foo/bar:/bar/foo'
    assert unfrack_path(pathsep=True)('/foo/bar:/bar/foo') == ['/foo/bar', '/bar/foo']
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-16 19:50:01.384499
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:50:11.670878
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.add_argument('-d', action='store_true', help='d help')
    parser.add_argument('-e', action='store_true', help='e help')
    parser.add_argument('-f', action='store_true', help='f help')
    parser.add_argument('-g', action='store_true', help='g help')
    parser.add_argument('-h', action='store_true', help='h help')
   

# Generated at 2022-06-16 19:50:20.286159
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--quuz')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
