

# Generated at 2022-06-16 19:41:41.921088
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar') == ['/foo/bar']
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux:/') == ['/foo/bar', '/baz/qux', '/']
    assert unfrack_path(pathsep=True)('/foo/bar::/baz/qux') == ['/foo/bar', '/baz/qux']


# Generated at 2022-06-16 19:41:47.076297
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '5'])
    assert args.forks == 5


# Generated at 2022-06-16 19:41:56.908654
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:42:08.304166
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:/tmp/bar') == '/tmp/foo:/tmp/bar'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar:') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('/tmp/foo::/tmp/bar') == ['/tmp/foo', '/tmp/bar']

# Generated at 2022-06-16 19:42:13.319763
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:42:22.087282
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    options = parser.parse_args(['-K'])
    assert options.become_ask_pass is True
    options = parser.parse_args(['--become-password-file', 'test'])
    assert options.become_password_file == 'test'
    options = parser.parse_args(['-K', '--become-password-file', 'test'])
    assert options.become_ask_pass is True
    assert options.become_password_file == 'test'



# Generated at 2022-06-16 19:42:24.007372
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:42:35.643354
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp') == '@' + unfrackpath('/tmp')
    assert maybe_unfrack_path('@')('@/tmp/') == '@' + unfrackpath('/tmp/')
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('/tmp') == '/tmp'
    assert maybe_unfrack_path('@')('/tmp/') == '/tmp/'

# Generated at 2022-06-16 19:42:42.344680
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:42:52.880704
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass == True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'
    args = parser.parse_args(['-K', '--become-password-file', 'test'])
    assert args.become_ask_pass == True
    assert args.become_password_file == 'test'



# Generated at 2022-06-16 19:43:02.666394
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:43:09.412063
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:43:13.008253
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:43:23.698801
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:43:29.985576
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10', '--ssh-common-args', '-o', 'ProxyCommand=ssh -W %h:%p gateway', '--sftp-extra-args', '-f', '-l', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.ssh/pass'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'
    assert args.connection == 'ssh'

# Generated at 2022-06-16 19:43:40.930555
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10',
                              '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p -q bastion',
                              '--sftp-extra-args', '-f -l', '--scp-extra-args', '-l', '--ssh-extra-args', '-R',
                              '-k', '--connection-password-file', '~/.ssh/password'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'
   

# Generated at 2022-06-16 19:43:47.999269
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['-u', 'test_user', '-c', 'test_connection', '-T', '10', '--ssh-common-args', 'test_ssh_common_args', '--sftp-extra-args', 'test_sftp_extra_args', '--scp-extra-args', 'test_scp_extra_args', '--ssh-extra-args', 'test_ssh_extra_args', '-k', '--connection-password-file', 'test_connection_password_file'])
    assert args.remote_user == 'test_user'
    assert args.connection == 'test_connection'
    assert args.timeout == 10

# Generated at 2022-06-16 19:43:55.810477
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check is True
    args = parser.parse_args(['--syntax-check'])
    assert args.syntax is True
    args = parser.parse_args(['--diff'])
    assert args.diff is True



# Generated at 2022-06-16 19:44:02.289250
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip1', '--skip-tags', 'skip2'])
    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-16 19:44:05.335377
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers
    assert args.flush_cache


# Generated at 2022-06-16 19:44:29.895103
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux'

# Generated at 2022-06-16 19:44:34.135859
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test', '--ask-vault-password', '--vault-password-file', 'test'])
    assert options.vault_ids == ['test']
    assert options.ask_vault_pass == True
    assert options.vault_password_files == ['test']


#
# Functions to add pre-canned options to an OptionParser
#


# Generated at 2022-06-16 19:44:43.140951
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--vault-password-file', 'foo', '--vault-password-file', 'bar'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.vault_password_files == ['foo', 'bar']
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--ask-vault-password'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.ask_vault_pass is True



# Generated at 2022-06-16 19:44:49.788832
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '@/tmp/vars.yml'])
    assert args.extra_vars == ['/tmp/vars.yml']
    args = parser.parse_args(['-e', '@/tmp/vars.yml', '-e', '@/tmp/vars2.yml'])
    assert args.extra_vars == ['/tmp/vars.yml', '/tmp/vars2.yml']
    args = parser.parse_args(['-e', '@/tmp/vars.yml', '-e', '@/tmp/vars2.yml', '-e', 'key=value'])
    assert args.extra_v

# Generated at 2022-06-16 19:45:00.786242
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-z')
    parser.add_argument('-a')
    parser.add_argument('-10')
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')

# Generated at 2022-06-16 19:45:10.945898
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '@test.yaml'])
    assert args.extra_vars == ['@test.yaml']
    args = parser.parse_args(['-e', '@test.yaml', '-e', '@test2.yaml'])
    assert args.extra_vars == ['@test.yaml', '@test2.yaml']
    args = parser.parse_args(['-e', '@test.yaml', '-e', '@test2.yaml', '-e', 'key=value'])
    assert args.extra_vars == ['@test.yaml', '@test2.yaml', 'key=value']

# Generated at 2022-06-16 19:45:14.027176
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:45:21.668675
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@@/foo/bar/') == '@@/foo/bar/'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('/foo/bar/') == '/foo/bar/'



# Generated at 2022-06-16 19:45:24.098256
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])

# Generated at 2022-06-16 19:45:33.683916
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/@') == '@' + unfrackpath('/foo/bar/@')
    assert maybe_unfrack_path('@')('@/foo/bar/@/') == '@' + unfrackpath('/foo/bar/@/')
   

# Generated at 2022-06-16 19:45:55.679916
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:07.070989
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/qux') == '/tmp/foo/bar/baz/qux'

# Generated at 2022-06-16 19:46:11.202384
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:15.325480
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:20.263383
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/..') == '/tmp'


# Generated at 2022-06-16 19:46:23.807865
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:33.202295
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz/../../') == '/foo'
    assert unfrack_path()('/foo/bar/baz/../../../') == '/'
    assert unfrack_path()('/foo/bar/baz/../../../../') == '/'
    assert unfrack_path()

# Generated at 2022-06-16 19:46:36.387154
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:39.934557
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:46:49.304169
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'

# Generated at 2022-06-16 19:47:14.674683
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible-test')

#
# Option Parsers
#

# Generated at 2022-06-16 19:47:21.673259
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:32.421990
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/path/to/file') == '/path/to/file'
    assert unfrack_path(pathsep=False)('~/path/to/file') == os.path.expanduser('~/path/to/file')
    assert unfrack_path(pathsep=False)('~/path/to/file') == os.path.expanduser('~/path/to/file')
    assert unfrack_path(pathsep=False)('~/path/to/file') == os.path.expanduser('~/path/to/file')
    assert unfrack_path(pathsep=False)('~/path/to/file') == os.path.expanduser('~/path/to/file')

# Generated at 2022-06-16 19:47:43.087392
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:47:51.057572
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/b/c') == '/a/b/c'
    assert unfrack_path()('/a/b/c/') == '/a/b/c'
    assert unfrack_path()('/a/b/c/../d') == '/a/b/d'
    assert unfrack_path()('/a/b/c/../../d') == '/a/d'
    assert unfrack_path()('/a/b/c/../../../d') == '/d'
    assert unfrack_path()('/a/b/c/../../../../d') == '/d'
    assert unfrack_path()('/a/b/c/../../../../../d') == '/d'

# Generated at 2022-06-16 19:48:02.791086
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:03.657654
# Unit test for function version
def test_version():
    assert version() is not None


# Generated at 2022-06-16 19:48:04.354662
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

# Generated at 2022-06-16 19:48:11.440363
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../qux') == '/foo/bar/qux'
    assert unfrack_path()('/foo/bar/baz/../../qux') == '/foo/qux'

# Generated at 2022-06-16 19:48:22.811808
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/../baz') == '/tmp/foo/baz'
    assert unfrack_path()('/tmp/foo/bar/../../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/bar/../../../baz') == '/baz'

# Generated at 2022-06-16 19:49:09.701304
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:18.653465
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:29.169417
# Unit test for function version
def test_version():
    assert version() == version(prog=None)
    assert version(prog='ansible') == version(prog='ansible')
    assert version(prog='ansible') != version(prog='ansible-playbook')
    assert version(prog='ansible') != version(prog=None)
    assert version(prog='ansible') != version(prog='ansible-config')
    assert version(prog='ansible') != version(prog='ansible-console')
    assert version(prog='ansible') != version(prog='ansible-doc')
    assert version(prog='ansible') != version(prog='ansible-galaxy')
    assert version(prog='ansible') != version(prog='ansible-inventory')

# Generated at 2022-06-16 19:49:39.321441
# Unit test for function version
def test_version():
    assert version() == version(prog='')
    assert version(prog='ansible-playbook') == version(prog='ansible-playbook')
    assert version(prog='ansible-playbook').startswith('ansible-playbook')
    assert version(prog='ansible-playbook').endswith('last updated')
    assert version(prog='ansible-playbook').count('\n') == 7
    assert version(prog='ansible-playbook').count('  ') == 8
    assert version(prog='ansible-playbook').count('=') == 8
    assert version(prog='ansible-playbook').count(')') == 2
    assert version(prog='ansible-playbook').count('(') == 2

# Generated at 2022-06-16 19:49:44.060269
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo/'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar/'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../')

# Generated at 2022-06-16 19:49:45.948769
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible-playbook')

#
# Options
#

# Generated at 2022-06-16 19:49:54.661360
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action="store", dest="b")
    parser.add_argument('-a', action="store", dest="a")
    parser.add_argument('-c', action="store", dest="c")
    parser.add_argument('-d', action="store", dest="d")
    parser.add_argument('-e', action="store", dest="e")
    parser.add_argument('-f', action="store", dest="f")
    parser.add_argument('-g', action="store", dest="g")
    parser.add_argument('-h', action="store", dest="h")
    parser.add_argument('-i', action="store", dest="i")
    parser.add_argument

# Generated at 2022-06-16 19:50:00.588696
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:50:11.073933
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:50:13.460847
# Unit test for function version
def test_version():
    assert version()
    assert version('test')

#
# Option Parser
#