

# Generated at 2022-06-16 19:41:42.490246
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'test'])
    assert options.basedir == 'test'


# Generated at 2022-06-16 19:41:46.009115
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='test')
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check
    assert args.syntax
    assert args.diff


# Generated at 2022-06-16 19:41:52.946400
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(['-M', 'test'])
    assert args.module_path == ['test']
    args = parser.parse_args(['-M', 'test:test2'])
    assert args.module_path == ['test', 'test2']



# Generated at 2022-06-16 19:41:56.060807
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert options.force_handlers
    assert options.flush_cache



# Generated at 2022-06-16 19:42:00.911495
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:06.455276
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    options = parser.parse_args(['--check'])
    assert options.check is True
    options = parser.parse_args(['--syntax-check'])
    assert options.syntax is True
    options = parser.parse_args(['--diff'])
    assert options.diff is True



# Generated at 2022-06-16 19:42:09.360519
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'test_vault_id', '--vault-password-file', 'test_vault_password_file'])
    assert args.vault_ids == ['test_vault_id']
    assert args.vault_password_files == ['test_vault_password_file']
    assert args.ask_vault_pass == False


#
# Functions to parse options
#


# Generated at 2022-06-16 19:42:13.229797
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:42:17.008898
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:42:21.415797
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'test'])
    assert options.basedir == 'test'


# Generated at 2022-06-16 19:42:38.032567
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass == True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'
    args = parser.parse_args(['-K', '--become-password-file', 'test'])
    assert args.become_ask_pass == True
    assert args.become_password_file == 'test'


# Generated at 2022-06-16 19:42:50.673182
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10',
                              '--ssh-common-args', '-o ProxyCommand="ssh -W %h:%p -q bastion"',
                              '--sftp-extra-args', '-f', '-l',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '-k',
                              '--connection-password-file', '~/.ssh/password'])

# Generated at 2022-06-16 19:43:02.821039
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('/foo/bar/') == '/foo/bar/'
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('/foo/bar/baz') == '/foo/bar/baz'
    assert maybe

# Generated at 2022-06-16 19:43:08.834785
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'su', '--become-user', 'root'])
    assert args.become == True
    assert args.become_method == 'su'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:43:17.101008
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'
    args = parser.parse_args([])
    assert args.become_ask_pass is False
    assert args.become_password_file is None



# Generated at 2022-06-16 19:43:17.748717
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:43:22.738634
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:43:26.602282
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'


# Generated at 2022-06-16 19:43:31.657219
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass == True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'



# Generated at 2022-06-16 19:43:42.422901
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'
    assert maybe_unfrack_path('@')('@foo/bar/') == '@foo/bar'
    assert maybe_unfrack_path('@')('@foo/bar/') == '@foo/bar'
    assert maybe_unfrack_path('@')('@foo/bar/')

# Generated at 2022-06-16 19:43:55.265165
# Unit test for function version
def test_version():
    assert version() == version(prog="ansible")

#
# Option Parsers
#

# Generated at 2022-06-16 19:43:59.802166
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20


# Generated at 2022-06-16 19:44:03.043734
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '10'])
    assert args.task_timeout == 10



# Generated at 2022-06-16 19:44:08.235744
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-B', '10'])
    assert args.seconds == 10
    assert args.poll_interval == C.DEFAULT_POLL_INTERVAL
    args = parser.parse_args(['-P', '10'])
    assert args.poll_interval == 10
    assert args.seconds == 0
    args = parser.parse_args(['-B', '10', '-P', '20'])
    assert args.seconds == 10
    assert args.poll_interval == 20



# Generated at 2022-06-16 19:44:16.002491
# Unit test for function version
def test_version():
    assert version() == """2.9.6 (devel) last updated 2020/06/03 19:00:00 (GMT +0000)
  config file = /etc/ansible/ansible.cfg
  configured module search path = Default w/o overrides
  ansible python module location = /usr/lib/python3/dist-packages/ansible
  ansible collection location = /usr/share/ansible/collections
  executable location = /usr/bin/ansible
  python version = 3.8.2 (default, Apr 27 2020, 15:53:34) 
[GCC 9.3.0]
  jinja version = 2.11.2
  libyaml = True"""

# Generated at 2022-06-16 19:44:28.956221
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--eggs')


# Generated at 2022-06-16 19:44:33.810379
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20


# Generated at 2022-06-16 19:44:44.509074
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:44:53.971766
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:44:58.303486
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20


# Generated at 2022-06-16 19:45:05.931131
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None
    assert args.version is None



# Generated at 2022-06-16 19:45:08.939141
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:45:18.605898
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:45:30.924678
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:45:34.026102
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:45:45.444959
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')

# Generated at 2022-06-16 19:45:55.267330
# Unit test for function version
def test_version():
    assert version() == version(prog='')
    assert version('ansible') == version(prog='ansible')
    assert version('ansible-playbook') == version(prog='ansible-playbook')
    assert version('ansible-vault') == version(prog='ansible-vault')
    assert version('ansible-console') == version(prog='ansible-console')
    assert version('ansible-doc') == version(prog='ansible-doc')
    assert version('ansible-galaxy') == version(prog='ansible-galaxy')
    assert version('ansible-pull') == version(prog='ansible-pull')
    assert version('ansible-config') == version(prog='ansible-config')

# Generated at 2022-06-16 19:45:59.001775
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:46:02.937872
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])
    parser.exit()



# Generated at 2022-06-16 19:46:10.793587
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'
    assert maybe_unfrack_path('@')('@foo/bar/') == '@foo/bar/'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:46:30.102994
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('~/foo/bar') == '~/foo/bar'



# Generated at 2022-06-16 19:46:32.180937
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:46:43.568333
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:52.416548
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:46:58.633610
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp') == '@' + unfrackpath('/tmp')
    assert maybe_unfrack_path('@')('@tmp') == '@tmp'
    assert maybe_unfrack_path('@')('@/tmp/') == '@' + unfrackpath('/tmp/')
    assert maybe_unfrack_path('@')('@tmp/') == '@tmp/'
    assert maybe_unfrack_path('@')('@/tmp/file') == '@' + unfrackpath('/tmp/file')
    assert maybe_unfrack_path('@')('@tmp/file') == '@tmp/file'

# Generated at 2022-06-16 19:47:06.049830
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'



# Generated at 2022-06-16 19:47:16.082556
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:47:18.744193
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'



# Generated at 2022-06-16 19:47:30.162199
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:47:33.531272
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    parser.parse_args(['--version'])



# Generated at 2022-06-16 19:48:07.217620
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:48:12.234286
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'



# Generated at 2022-06-16 19:48:23.375278
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:48:31.114935
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:48:33.677105
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:48:36.186244
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:48:46.305382
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:48:53.628711
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'

# Generated at 2022-06-16 19:49:05.514556
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('~/foo/bar') == '~/foo/bar'
    assert maybe_unfrack_path('@')('@./foo/bar') == '@' + unfrackpath('./foo/bar')
    assert maybe_unfrack_path('@')('./foo/bar') == './foo/bar'

# Generated at 2022-06-16 19:49:11.438267
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')