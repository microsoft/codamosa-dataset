

# Generated at 2022-06-16 19:41:39.403432
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'su', '--become-user', 'test'])
    assert args.become is True
    assert args.become_method == 'su'
    assert args.become_user == 'test'



# Generated at 2022-06-16 19:41:50.699459
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'local', '-T', '10', '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p -q bastionhost', '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.vault_pass.txt'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'

# Generated at 2022-06-16 19:41:58.729418
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_subset_options(parser)
    args = parser.parse_args(['--tags', 'tag1', '--tags', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']


# Generated at 2022-06-16 19:42:09.183049
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '10'])
    assert args.task_timeout == 10
    args = parser.parse_args(['--task-timeout', '-10'])
    assert args.task_timeout == -10
    args = parser.parse_args(['--task-timeout', '0'])
    assert args.task_timeout == 0
    args = parser.parse_args(['--task-timeout', '1.0'])
    assert args.task_timeout == 1.0
    args = parser.parse_args(['--task-timeout', 'a'])
    assert args.task_timeout == 'a'



# Generated at 2022-06-16 19:42:18.517087
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz//') == '/tmp/foo/bar/baz'

# Generated at 2022-06-16 19:42:20.488769
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '5'])
    assert args.forks == 5


# Generated at 2022-06-16 19:42:33.466098
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test PrependListAction')
    parser.add_argument('-a', action=PrependListAction, nargs='+', dest='args')
    parser.add_argument('-b', action=PrependListAction, nargs='+', dest='args')
    parser.add_argument('-c', action=PrependListAction, nargs='+', dest='args')
    parser.add_argument('-d', action=PrependListAction, nargs='+', dest='args')
    parser.add_argument('-e', action=PrependListAction, nargs='+', dest='args')

# Generated at 2022-06-16 19:42:41.003770
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:42:42.408321
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible')

#
# Options
#

# Generated at 2022-06-16 19:42:47.628081
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', '/tmp'])
    assert args.one_line is True
    assert args.tree == '/tmp'


# Generated at 2022-06-16 19:43:22.868176
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@~/tmp/foo') == '@' + unfrackpath('~/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo//') == '@' + unfrackpath('/tmp/foo//')

# Generated at 2022-06-16 19:43:33.872134
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unf

# Generated at 2022-06-16 19:43:38.086374
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:43:47.701195
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:43:50.802195
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:44:03.356136
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:44:11.988659
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', None)
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', [])
    assert ns.foo == []
    ensure_value(ns, 'foo', None)
    assert ns.foo == []



# Generated at 2022-06-16 19:44:15.472222
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:44:25.494569
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--ask-vault-password', '--vault-password-file', 'foo', '--vault-password-file', 'bar'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.ask_vault_pass is True
    assert args.vault_password_files == ['foo', 'bar']



# Generated at 2022-06-16 19:44:30.056080
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='test_add_async_options')
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '20'])
    assert args.poll_interval == 10
    assert args.seconds == 20


# Generated at 2022-06-16 19:44:46.811205
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../../bar') == '/bar'

# Generated at 2022-06-16 19:44:54.829420
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:57.949283
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:45:07.793807
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../../baz') == '/baz'
    assert unfrack_path()('/tmp/foo/../../baz/') == '/baz'
    assert unfrack_

# Generated at 2022-06-16 19:45:17.484577
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:23.078581
# Unit test for function version
def test_version():
    assert version('ansible-test') == 'ansible-test [core 2.9.0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible-test\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18)\n  jinja version = 2.9.6\n  libyaml = True'


# Generated at 2022-06-16 19:45:33.046752
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@@/tmp/foo/') == '@@/tmp/foo/'
    assert maybe_unfrack_path('@')('@@/tmp/foo/bar') == '@@/tmp/foo/bar'

# Generated at 2022-06-16 19:45:36.451051
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:45:40.441218
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:45:51.411638
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('@./foo/bar') == '@' + unfrackpath('./foo/bar')
    assert maybe_unfrack_path('@')('@../foo/bar') == '@' + unfrackpath('../foo/bar')
    assert maybe_unfrack_path('@')('@../foo/bar') == '@' + unfrackpath('../foo/bar')

# Generated at 2022-06-16 19:46:11.229528
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/../') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz/../../') == '/foo'
    assert unfrack_path()('/foo/bar/baz/../../../') == '/'
    assert unfrack_

# Generated at 2022-06-16 19:46:21.158768
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')

# Generated at 2022-06-16 19:46:31.848797
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:34.291622
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:37.810097
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:48.510173
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', '1', '2', '--bar', '3', '4'])
    assert args.foo == ['1', '2']
    assert args.bar == ['3', '4']
    args = parser.parse_args(['--bar', '3', '4', '--foo', '1', '2'])
    assert args.foo == ['1', '2']
    assert args.bar == ['3', '4']

# Generated at 2022-06-16 19:46:56.322756
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo//') == '@' + unfrackpath('/tmp/foo//')
    assert maybe_unfrack_path('@')('@/tmp/foo///') == '@' + unfrackpath('/tmp/foo///')

# Generated at 2022-06-16 19:47:08.300520
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:47:16.598634
# Unit test for function version
def test_version():
    assert version() == '2.9.0\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3.6/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.6.8 (default, Apr 25 2019, 21:02:35) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:47:23.239817
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') != '@/foo/bar'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-16 19:48:02.206438
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:48:08.588927
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='*')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']

#
# OptionParser for ansible-playbook
#

# Generated at 2022-06-16 19:48:13.966951
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:25.701457
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/') == '/tmp'
    assert unfrack_path()('/tmp/../tmp/../tmp/../tmp/../tmp') == '/tmp'
    assert unf

# Generated at 2022-06-16 19:48:26.628192
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

# Generated at 2022-06-16 19:48:34.704053
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/../baz') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/../qux') == '/foo/qux'
    assert unfrack_path()('/foo/bar/../baz/../qux/') == '/foo/qux'
    assert unfrack_path()('/foo/bar/../baz/../qux/../../quux') == '/quux'

# Generated at 2022-06-16 19:48:37.759675
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:48:41.217841
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:48:47.558623
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') != '@/path/to/file'
    assert maybe_unfrack_path('@')('/path/to/file') == '/path/to/file'
    assert maybe_unfrack_path('@')('@/path/to/file') != '@' + '/path/to/file'


# Generated at 2022-06-16 19:48:54.582259
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo//') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar//') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'

# Generated at 2022-06-16 19:50:27.111558
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']


# Generated at 2022-06-16 19:50:33.473119
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@@') == '@@'
    assert maybe_unfrack_path('@')('@foo') == '@foo'
    assert maybe_unfrack_path('@')('@@foo') == '@@foo'
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'

# Generated at 2022-06-16 19:50:42.658983
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:50:47.507312
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', '--foo', 'b', '--foo', 'c'])
    assert args.foo == ['c', 'b', 'a']


# Generated at 2022-06-16 19:50:57.487319
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    options = dict()