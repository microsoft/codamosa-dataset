

# Generated at 2022-06-16 19:41:36.785912
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'test'])
    assert options.basedir == 'test'


# Generated at 2022-06-16 19:41:47.234835
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args('--foo 1 --foo 2 --foo 3'.split())
    assert args.foo == [1, 2, 3]
    args = parser.parse_args('--foo 1 --foo 2 --foo 3 --foo 4 --foo 5'.split())
    assert args.foo == [1, 2, 3, 4, 5]
    args = parser.parse_args('--foo 1 --foo 2 --foo 3 --foo 4 --foo 5 --foo 6'.split())
    assert args.foo == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-16 19:41:51.544525
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:42:01.391194
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['--ask-become-pass'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'
    args = parser.parse_args(['--ask-become-pass', '--become-password-file', 'test'])
    assert args.become_ask_pass is True
    assert args.become_password_file == 'test'
    args = parser.parse_args(['--become-password-file', 'test', '--ask-become-pass'])

# Generated at 2022-06-16 19:42:05.172374
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:42:11.334125
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '@/tmp/test.yaml'])
    assert args.extra_vars == ['/tmp/test.yaml']
    args = parser.parse_args(['-e', '@/tmp/test.yaml', '-e', '@/tmp/test2.yaml'])
    assert args.extra_vars == ['/tmp/test.yaml', '/tmp/test2.yaml']
    args = parser.parse_args(['-e', '@/tmp/test.yaml', '-e', '@/tmp/test2.yaml', '-e', 'key=value'])

# Generated at 2022-06-16 19:42:19.943250
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10', '--ssh-common-args', '-o ProxyCommand=ssh -W %h:%p', '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '-k', '--connection-password-file', '~/.ssh/passwd'])
    assert args.private_key_file == '~/.ssh/id_rsa'
    assert args.remote_user == 'root'
    assert args.connection == 'ssh'
    assert args.timeout

# Generated at 2022-06-16 19:42:24.244929
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:42:29.422354
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:42:31.807461
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:42:45.209095
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'inventory_file', '--list-hosts', '-l', 'subset'])
    assert options.inventory == ['inventory_file']
    assert options.listhosts == True
    assert options.subset == 'subset'


# Generated at 2022-06-16 19:42:52.746327
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:57.792903
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'hosts', '--list-hosts', '-l', 'subset'])
    assert options.inventory == ['hosts']
    assert options.listhosts == True
    assert options.subset == 'subset'


# Generated at 2022-06-16 19:43:03.759513
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'test', '--list-hosts', '-l', 'test'])
    assert args.inventory == ['test']
    assert args.listhosts == True
    assert args.subset == 'test'



# Generated at 2022-06-16 19:43:15.894531
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:43:22.565896
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path(pathsep=True)('~/foo:/tmp/bar') == [os.path.expanduser('~/foo'), '/tmp/bar']


# Generated at 2022-06-16 19:43:25.093895
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test', '--ask-vault-password', '--vault-password-file', 'test'])
    assert options.vault_ids == ['test']
    assert options.ask_vault_pass is True
    assert options.vault_password_files == ['test']



# Generated at 2022-06-16 19:43:28.725386
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:43:39.537629
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/..') == '/tmp'


# Generated at 2022-06-16 19:43:48.615299
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/a/b/c') == '/a/b/c'
    assert unfrack_path(pathsep=False)('a/b/c') == 'a/b/c'
    assert unfrack_path(pathsep=False)('~/a/b/c') == os.path.expanduser('~/a/b/c')
    assert unfrack_path(pathsep=False)('~/a/b/c/') == os.path.expanduser('~/a/b/c')
    assert unfrack_path(pathsep=False)('~/a/b/c/../d') == os.path.expanduser('~/a/b/d')

# Generated at 2022-06-16 19:43:59.397267
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers
    assert args.flush_cache


# Generated at 2022-06-16 19:44:10.783110
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    parser = argparse.ArgumentParser(description='test', formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', '--append', action=PrependListAction, default=[], help='append help')
    args = parser.parse_args(['-a', '1', '-a', '2', '-a', '3'])
    assert args.append == ['1', '2', '3']
    args = parser.parse_args(['-a', '1', '-a', '2', '-a', '3', '-a', '4', '-a', '5'])
    assert args.append == ['1', '2', '3', '4', '5']

# Generated at 2022-06-16 19:44:17.307809
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class Namespace(object):
        pass
    namespace = Namespace()
    namespace.dest = []
    action = PrependListAction(option_strings=[], dest='dest', nargs=None, const=None, default=None, type=None,
                               choices=None, required=False, help=None, metavar=None)
    action(parser=None, namespace=namespace, values=['a', 'b'], option_string=None)
    assert namespace.dest == ['a', 'b']
    action(parser=None, namespace=namespace, values=['c', 'd'], option_string=None)
    assert namespace.dest == ['c', 'd', 'a', 'b']



# Generated at 2022-06-16 19:44:29.766472
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:44:41.745286
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test with a list of values
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz']

    # Test with a single value
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']

    # Test with a single value and a default value
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=['baz'])
    args = parser.parse_args

# Generated at 2022-06-16 19:44:51.818916
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:44:58.962484
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='*')
    parser.add_argument('--bar', action=PrependListAction, nargs='*')
    args = parser.parse_args(['--foo', 'a', 'b', '--bar', 'c', 'd'])
    assert args.foo == ['a', 'b']
    assert args.bar == ['c', 'd']



# Generated at 2022-06-16 19:45:08.851671
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test PrependListAction')
    parser.add_argument('-a', action=PrependListAction, nargs='+', dest='mylist')
    args = parser.parse_args(['-a', '1', '2', '3'])
    assert args.mylist == ['1', '2', '3']
    args = parser.parse_args(['-a', '1', '2', '3', '-a', '4', '5', '6'])
    assert args.mylist == ['4', '5', '6', '1', '2', '3']

# Generated at 2022-06-16 19:45:12.859821
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:45:16.655576
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    n = Namespace()
    ensure_value(n, 'foo', 'bar')
    assert n.foo == 'bar'
    ensure_value(n, 'foo', 'baz')
    assert n.foo == 'bar'


#
# Main parser
#

# Generated at 2022-06-16 19:45:31.944174
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test PrependListAction')
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz', '--foo', 'qux'])
    assert args.foo == ['qux', 'baz', 'bar']
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz', '--foo', 'qux', '--foo', 'quux'])


# Generated at 2022-06-16 19:45:43.211222
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/..') == '/tmp'


# Generated at 2022-06-16 19:45:53.719877
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction, nargs='+')
    parser.add_argument('--baz', action=PrependListAction, nargs='*')
    parser.add_argument('--qux', action=PrependListAction, nargs=2)
    parser.add_argument('--quux', action=PrependListAction, nargs=argparse.OPTIONAL)
    parser.add_argument('--corge', action=PrependListAction, nargs=argparse.OPTIONAL, const='grault')

# Generated at 2022-06-16 19:46:04.005230
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='test')
    parser.add_argument('--foo', action=PrependListAction, nargs='+', default=[])
    args = parser.parse_args(['--foo', '1', '--foo', '2'])
    assert args.foo == ['2', '1']
    args = parser.parse_args(['--foo', '1'])
    assert args.foo == ['1']
    args = parser.parse_args([])
    assert args.foo == []



# Generated at 2022-06-16 19:46:10.733916
# Unit test for function version
def test_version():
    assert version() == '2.8.0.dev0\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18)\n[GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]\n  jinja version = 2.9.6\n  libyaml = True'

# Generated at 2022-06-16 19:46:20.475849
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:31.501493
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../../bar/../baz/') == '/baz'
    assert unfrack_path()('/tmp/foo/../../bar/../baz') == '/baz'

# Generated at 2022-06-16 19:46:42.746538
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:46:52.769595
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:58.860570
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert unfrack_path()('$HOME/foo/bar') == os.path.expandvars('$HOME/foo/bar')

# Generated at 2022-06-16 19:47:12.615886
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']


# Generated at 2022-06-16 19:47:19.881167
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:47:31.454992
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:47:36.249568
# Unit test for function version
def test_version():
    assert version() == '2.9.6 (devel b6c9a6d4d6)  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3/dist-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.7.3 (default, Apr  3 2019, 05:39:12)\n[GCC 8.3.0]\n  jinja version = 2.10\n  libyaml = True'

#
# Option Parsers
#

# Generated at 2022-06-16 19:47:47.631859
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/.') == '/foo/bar'
    assert unfrack_path()('/foo/bar/..') == '/foo'
    assert unfrack_path()('/foo/bar/../') == '/foo'
    assert unfrack_path()('/foo/bar/../../') == '/'
    assert unfrack_path()('/foo/bar/../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../../') == '/'

# Generated at 2022-06-16 19:47:58.867190
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')

# Generated at 2022-06-16 19:48:08.001795
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:48:19.114243
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:48:24.667503
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs='+')
    parser.parse_args(['--foo', '1', '2', '--bar', '3', '4'])



# Generated at 2022-06-16 19:48:31.728573
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs='+', const=['a', 'b'])
    parser.add_argument('--baz', action=PrependListAction, nargs='*', const=['a', 'b'])
    parser.add_argument('--qux', action=PrependListAction, nargs='?', const=['a', 'b'])
    parser.add_argument('--quux', action=PrependListAction, nargs=2, const=['a', 'b'])

# Generated at 2022-06-16 19:49:06.270861
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:49:17.823766
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/roles') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/') == '/etc/ansible/roles'
    assert unfrack_path()('roles') == 'roles'
    assert unfrack_path()('roles/') == 'roles'
    assert unfrack_path()('~/roles') == os.path.expanduser('~/roles')
    assert unfrack_path()('~/roles/') == os.path.expanduser('~/roles')
    assert unfrack_

# Generated at 2022-06-16 19:49:29.027435
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test unfrack_path with pathsep=False
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'

# Generated at 2022-06-16 19:49:39.294052
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.add_argument('-d', action='store_true', help='d help')
    parser.add_argument('-e', action='store_true', help='e help')
    parser.add_argument('-f', action='store_true', help='f help')
    parser.add_argument('-g', action='store_true', help='g help')
    parser.add_argument('-h', action='store_true', help='h help')
   

# Generated at 2022-06-16 19:49:40.407371
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible')

#
# Options for all commands
#

# Generated at 2022-06-16 19:49:41.969654
# Unit test for function version
def test_version():
    assert version() is not None

#
# Option Parsers
#

# Generated at 2022-06-16 19:49:52.203738
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:49:59.028159
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    options = dict()
    options['module_path'] = None
    options['forks'] = 5
    options['become'] = None
    options['become_method'] = None
    options['become_user'] = None
    options['check'] = False
    options['listhosts'] = None
    options['listtasks'] = None
    options['listtags'] = None
    options['syntax'] = None
    options['connection'] = 'smart'
    options['module_path'] = None
    options['remote_user'] = None
    options['private_key_file'] = None
    options['ssh_common_args'] = None
    options['ssh_extra_args'] = None

# Generated at 2022-06-16 19:50:05.681154
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args('--foo a b c'.split())
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args('--foo a --foo b c'.split())
    assert args.foo == ['b', 'c', 'a']



# Generated at 2022-06-16 19:50:15.346997
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../../bar') == '/bar'

# Generated at 2022-06-16 19:50:49.581523
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']



# Generated at 2022-06-16 19:50:58.954186
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs='+')
    parser.add_argument('--baz', action=PrependListAction, nargs='+')
    parser.add_argument('--qux', action=PrependListAction, nargs='+')
    parser.add_argument('--quux', action=PrependListAction, nargs='+')
    parser.add_argument('--corge', action=PrependListAction, nargs='+')
    parser.add_argument('--grault', action=PrependListAction, nargs='+')