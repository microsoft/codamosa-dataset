

# Generated at 2022-06-16 19:41:26.972971
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:41:30.702356
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'test_inventory', '--list-hosts', '-l', 'test_subset'])
    assert args.inventory == ['test_inventory']
    assert args.listhosts == True
    assert args.subset == 'test_subset'


# Generated at 2022-06-16 19:41:42.445665
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:41:53.165350
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    assert unfrack_path()('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert unfrack_path()('${HOME}/foo') == os.path.expandvars('${HOME}/foo')

# Generated at 2022-06-16 19:41:58.728424
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:04.680292
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:42:07.091255
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])


# Generated at 2022-06-16 19:42:11.994689
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    assert ensure_value(ns, 'foo', 'bar') == 'bar'
    assert ns.foo == 'bar'
    ns.foo = 'baz'
    assert ensure_value(ns, 'foo', 'bar') == 'baz'
    assert ns.foo == 'baz'



# Generated at 2022-06-16 19:42:16.073457
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['--ask-become-pass'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'test.txt'])
    assert args.become_password_file == 'test.txt'



# Generated at 2022-06-16 19:42:19.717296
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', '@/tmp/test.yml'])
    assert options.extra_vars == ['/tmp/test.yml']


# Generated at 2022-06-16 19:42:44.336522
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--ask-vault-password', '--vault-password-file', 'foo', '--vault-password-file', 'bar'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.ask_vault_pass == True
    assert args.vault_password_files == ['foo', 'bar']


# Generated at 2022-06-16 19:42:48.186758
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test'])
    assert args.basedir == 'test'


# Generated at 2022-06-16 19:42:55.335792
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-16 19:42:58.788911
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:43:04.210362
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:43:09.098667
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert options.check == True
    assert options.syntax == True
    assert options.diff == True


# Generated at 2022-06-16 19:43:10.399605
# Unit test for function version
def test_version():
    assert version()

#
# Option Parser
#

# Generated at 2022-06-16 19:43:14.512158
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:43:15.595626
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:43:19.500944
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert options.check
    assert options.syntax
    assert options.diff


# Generated at 2022-06-16 19:43:37.096892
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    options = dict()
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None
    options['module_path'] = None

# Generated at 2022-06-16 19:43:47.018095
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:43:59.752246
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:44:10.783783
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:44:13.451124
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:44:15.757275
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:44:17.409310
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:44:18.693856
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', 'test'])
    assert args.tree == 'test'


# Generated at 2022-06-16 19:44:30.729564
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-f', '--foo')
    parser.add_argument('-b', '--bar')
    parser.add_argument('-c', '--baz')
    parser.add_argument('-d', '--qux')
    parser.add_argument('-e', '--quux')
    parser.add_argument('-a', '--quuz')
    parser.add_argument('-g', '--corge')
    parser.add_argument('-z', '--grault')
    parser.add_argument('-y', '--garply')
    parser.add_argument('-x', '--waldo')
    parser.add_argument('-w', '--fred')
    parser.add

# Generated at 2022-06-16 19:44:36.353164
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:44:51.932562
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/roles') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/foo') == '/etc/ansible/roles/foo'
    assert unfrack_path()('/etc/ansible/roles/foo/') == '/etc/ansible/roles/foo'

# Generated at 2022-06-16 19:44:58.258668
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == unfrackpath('/path/to/file')
    assert unfrack_path(pathsep=True)('/path/to/file:/path/to/file2') == [unfrackpath('/path/to/file'), unfrackpath('/path/to/file2')]
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-16 19:45:08.127528
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:45:17.820083
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--quux')
    parser.add_argument('--xyzzy')
    parser.add_argument('--plugh')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--eggs')
    parser.add_argument('--ham')
    parser.add_argument('--foo-bar')
    parser.add_argument('--foo-baz')
    parser.add_argument('--foo-quux')
    parser.add_argument('--foo-xyzzy')
    parser.add_

# Generated at 2022-06-16 19:45:29.854363
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:36.396979
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:40.392624
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:45:43.850986
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, type=int)
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--foo', '3'])
    assert args.foo == [1, 2, 3]


# Generated at 2022-06-16 19:45:45.698500
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])


# Generated at 2022-06-16 19:45:46.227771
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass



# Generated at 2022-06-16 19:46:07.149990
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:18.341953
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction, nargs=2)
    parser.add_argument('--baz', action=PrependListAction, nargs='*')
    parser.add_argument('--qux', action=PrependListAction, nargs='+')
    parser.add_argument('--quux', action=PrependListAction, nargs=argparse.OPTIONAL)
    parser.add_argument('--corge', action=PrependListAction, nargs=argparse.OPTIONAL, const='const')
    parser.add_argument('--grault', action=PrependListAction, nargs=argparse.OPTIONAL, const='const', default='default')


# Generated at 2022-06-16 19:46:29.494915
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:46:39.883172
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f', '--foo', 'g', 'h', 'i'])

# Generated at 2022-06-16 19:46:40.634966
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:46:47.575479
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@@/foo/bar/') == '@@/foo/bar/'



# Generated at 2022-06-16 19:46:55.464330
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/b/c') == '/a/b/c'
    assert unfrack_path()('/a/b/c/') == '/a/b/c'
    assert unfrack_path()('/a/b/c/../d') == '/a/b/d'
    assert unfrack_path()('/a/b/c/../../d') == '/a/d'
    assert unfrack_path()('/a/b/c/../../../d') == '/d'
    assert unfrack_path()('/a/b/c/../../../../d') == '/d'
    assert unfrack_path()('/a/b/c/../../../../../d') == '/d'

# Generated at 2022-06-16 19:47:01.120006
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--foo', '3'])
    assert args.foo == ['3', '2', '1']



# Generated at 2022-06-16 19:47:11.909037
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo/bar') == '/tmp/foo/bar'

# Generated at 2022-06-16 19:47:18.917841
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store', help='b')
    parser.add_argument('-a', action='store', help='a')
    parser.add_argument('-c', action='store', help='c')
    assert parser.format_help() == '''usage: [-h] [-b B] [-a A] [-c C]

optional arguments:
  -h, --help  show this help message and exit
  -b B        b
  -a A        a
  -c C        c
'''


# Generated at 2022-06-16 19:47:40.979143
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz', '--foo', 'qux'])
    assert args.foo == ['qux', 'baz', 'bar']
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    args = parser.parse_args([])
    assert args.foo == []


# Generated at 2022-06-16 19:47:46.140300
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', '1', '--foo', '2'])
    assert args.foo == ['2', '1']

# Generated at 2022-06-16 19:47:52.208987
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.add_argument('--bar', action=PrependListAction, nargs='+')
    parser.add_argument('--baz', action=PrependListAction, nargs='+')
    parser.add_argument('--qux', action=PrependListAction, nargs='+')
    parser.add_argument('--quux', action=PrependListAction, nargs='+')
    parser.add_argument('--corge', action=PrependListAction, nargs='+')
    parser.add_argument('--grault', action=PrependListAction, nargs='+')

# Generated at 2022-06-16 19:48:03.808406
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path(pathsep=True)('-') == ['-']
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert unfrack_path()('~/foo/bar:/baz/qux') == os.path.expanduser('~/foo/bar:/baz/qux')

# Generated at 2022-06-16 19:48:11.056382
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo/'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar/'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp/'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../')

# Generated at 2022-06-16 19:48:21.619444
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:48:30.584622
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:48:39.953148
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:48.726876
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('foo') == unfrackpath('foo')
    assert unfrack_path(pathsep=True)('foo') == [unfrackpath('foo')]
    assert unfrack_path(pathsep=True)('foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('foo:bar:') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)(':foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)(':foo:bar:') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path

# Generated at 2022-06-16 19:48:58.962117
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', '1', '2', '3'])
    assert args.foo == ['1', '2', '3']
    args = parser.parse_args(['--foo', '1', '2', '3', '--foo', '4', '5', '6'])
    assert args.foo == ['4', '5', '6', '1', '2', '3']
    args = parser.parse_args(['--foo', '1', '2', '3', '--foo', '4', '5', '6', '--foo', '7', '8', '9'])

# Generated at 2022-06-16 19:49:39.487352
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='test')
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    args = parser.parse_args([])
    assert args.foo == []



# Generated at 2022-06-16 19:49:48.819731
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()
    action = PrependListAction(option_strings=[], dest='foo', nargs=1, const=None, default=None, type=None,
                 choices=None, required=False, help=None, metavar=None)
    action(parser=None, namespace=namespace, values=['bar'], option_string=None)
    assert namespace.foo == ['bar']
    action(parser=None, namespace=namespace, values=['baz'], option_string=None)
    assert namespace.foo == ['baz', 'bar']

#
# Utility functions
#

# Generated at 2022-06-16 19:49:56.470636
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/b/c') == '/a/b/c'
    assert unfrack_path()('/a/b/c/') == '/a/b/c'
    assert unfrack_path()('/a/b/c/.') == '/a/b/c'
    assert unfrack_path()('/a/b/c/..') == '/a/b'
    assert unfrack_path()('/a/b/c/../..') == '/a'
    assert unfrack_path()('/a/b/c/../../..') == '/'
    assert unfrack_path()('/a/b/c/../../../..') == '/'
    assert unfrack_path()('/a/b/c/../../../../..') == '/'
    assert unfrack_

# Generated at 2022-06-16 19:50:08.599618
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:50:17.680285
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')
   

# Generated at 2022-06-16 19:50:24.073024
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:50:29.201496
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='*')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:50:31.805190
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']



# Generated at 2022-06-16 19:50:39.318036
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../../../../../bar') == '/bar'

# Generated at 2022-06-16 19:50:47.546093
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux', 'quux'])
    assert args.foo == ['qux', 'quux', 'bar', 'baz']

#
# Option Parsers
#