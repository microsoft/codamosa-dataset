

# Generated at 2022-06-16 19:41:35.550521
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-16 19:41:46.676804
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '30',
                              '--ssh-common-args', '-o ProxyCommand="ssh -W %h:%p -q bastion"',
                              '--sftp-extra-args', '-f', '-l',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '-k',
                              '--connection-password-file', '~/.ssh/pass'])
    assert args.private_key_file == '~/.ssh/id_rsa'
   

# Generated at 2022-06-16 19:41:56.881621
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'ssh', '-T', '10',
                              '--ssh-common-args', '-o ProxyCommand="ssh -W %h:%p -q bastion"',
                              '--sftp-extra-args', '-f', '-l',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '-k',
                              '--connection-password-file', '~/.ssh/pass'])
    assert args.private_key_file == '~/.ssh/id_rsa'
   

# Generated at 2022-06-16 19:42:03.353017
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'test.ini', '--list-hosts', '-l', 'test'])
    assert args.inventory == ['test.ini']
    assert args.listhosts == True
    assert args.subset == 'test'


# Generated at 2022-06-16 19:42:05.928095
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'



# Generated at 2022-06-16 19:42:09.994156
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'
    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'


#
# Option Parser
#

# Generated at 2022-06-16 19:42:13.143801
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['--ask-become-pass'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'myfile'])
    assert args.become_password_file == 'myfile'



# Generated at 2022-06-16 19:42:15.953898
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar', '--ask-vault-password', '--vault-password-file', 'baz'])
    assert args.vault_ids == ['foo', 'bar']
    assert args.ask_vault_pass
    assert args.vault_password_files == ['baz']


# Generated at 2022-06-16 19:42:28.117703
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert unfrack_path()('~/foo/bar:/baz/qux') == os.path.expanduser('~/foo/bar:/baz/qux')

# Generated at 2022-06-16 19:42:30.573542
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'test_inventory', '--list-hosts', '-l', 'test_subset'])
    assert options.inventory == ['test_inventory']
    assert options.listhosts is True
    assert options.subset == 'test_subset'



# Generated at 2022-06-16 19:42:47.391913
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None
    assert args.version == None


# Generated at 2022-06-16 19:42:54.745961
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(["-t", "tag1", "--tags", "tag2", "--skip-tags", "tag3", "--skip-tags", "tag4"])
    assert args.tags == ["tag1", "tag2"]
    assert args.skip_tags == ["tag3", "tag4"]



# Generated at 2022-06-16 19:43:00.758513
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'foo', '-t', 'bar', '--skip-tags', 'baz', '--skip-tags', 'qux'])
    assert args.tags == ['foo', 'bar']
    assert args.skip_tags == ['baz', 'qux']



# Generated at 2022-06-16 19:43:05.987353
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    opts = parser.parse_args(['-P', '10', '-B', '20'])
    assert opts.poll_interval == 10
    assert opts.seconds == 20



# Generated at 2022-06-16 19:43:08.130233
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers
    assert args.flush_cache



# Generated at 2022-06-16 19:43:14.460181
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:43:19.966452
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:43:22.829824
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '10'])
    assert args.forks == 10


# Generated at 2022-06-16 19:43:27.159628
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    opts = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert opts.tags == ['tag1', 'tag2']
    assert opts.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:43:30.865518
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20


# Generated at 2022-06-16 19:43:48.085074
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/..') == '/tmp'


# Generated at 2022-06-16 19:44:01.048743
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:44:03.749664
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:44:15.096516
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@' + unfrackpath('/tmp/foo') + '/'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo') + '/'

# Generated at 2022-06-16 19:44:20.895552
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']


# Generated at 2022-06-16 19:44:31.580119
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class TestParser(argparse.ArgumentParser):
        def error(self, message):
            raise Exception(message)
    parser = TestParser()
    parser.add_argument('--foo', action=PrependListAction)
    try:
        parser.parse_args(['--foo', 'bar'])
    except Exception as e:
        assert e.args[0] == 'unrecognized arguments: --foo'
    else:
        assert False, 'Expected Exception'
    try:
        parser.parse_args(['--foo', 'bar', 'baz'])
    except Exception as e:
        assert e.args[0] == 'unrecognized arguments: --foo'
    else:
        assert False, 'Expected Exception'

# Generated at 2022-06-16 19:44:36.603570
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', './'])
    assert args.basedir == './'


# Generated at 2022-06-16 19:44:44.164412
# Unit test for function version
def test_version():
    assert version() == """2.9.0
  config file = /etc/ansible/ansible.cfg
  configured module search path = Default w/o overrides
  ansible python module location = /usr/lib/python3/dist-packages/ansible
  ansible collection location = /usr/share/ansible/collections
  executable location = /usr/bin/ansible
  python version = 3.7.3 (default, Apr  3 2019, 05:39:12)
[GCC 8.3.0]
  jinja version = 2.10.1
  libyaml = True"""

# Generated at 2022-06-16 19:44:48.268171
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:44:51.588900
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-c')
    parser.print_help()


# Generated at 2022-06-16 19:45:03.975703
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args('--foo 1 --foo 2'.split())
    assert args.foo == ['1', '2']
    args = parser.parse_args('--foo 1 2'.split())
    assert args.foo == ['1', '2']
    args = parser.parse_args('--foo 1 --foo 2 3'.split())
    assert args.foo == ['1', '2', '3']



# Generated at 2022-06-16 19:45:13.716263
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux'])
    assert args.foo == ['qux', 'bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', 'baz', '--foo', 'qux', '--foo', 'quux'])
    assert args.foo == ['quux', 'qux', 'bar', 'baz']



# Generated at 2022-06-16 19:45:21.697396
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'

# Generated at 2022-06-16 19:45:31.980985
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')
    parser.add_argument('--eggs')


# Generated at 2022-06-16 19:45:40.110831
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar') == ['/foo/bar']
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-16 19:45:47.043065
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:45:56.210756
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true', help='a')
    parser.add_argument('-b', action='store_true', help='b')
    parser.add_argument('-c', action='store_true', help='c')
    parser.add_argument('-d', action='store_true', help='d')
    parser.add_argument('-e', action='store_true', help='e')
    parser.add_argument('-f', action='store_true', help='f')
    parser.add_argument('-g', action='store_true', help='g')
    parser.add_argument('-h', action='store_true', help='h')

# Generated at 2022-06-16 19:46:07.146785
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar:@/foo/baz') == '@' + unfrackpath('/foo/bar:@/foo/baz')
    assert maybe_unfrack_path('@')('@/foo/bar:@@/foo/baz') == '@' + unfrackpath('/foo/bar:@@/foo/baz')


# Generated at 2022-06-16 19:46:08.251514
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')



# Generated at 2022-06-16 19:46:11.730204
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:24.132114
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:46:33.407252
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:46:42.339090
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:46:47.685832
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') != '@' + '/path/to/file'
    assert maybe_unfrack_path('@')('/path/to/file') == '/path/to/file'


# Generated at 2022-06-16 19:46:55.549257
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/qux') == '/tmp/foo/bar/baz/qux'

# Generated at 2022-06-16 19:47:07.230162
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/../baz') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/../qux') == '/foo/qux'
    assert unfrack_path()('/foo/bar/../baz/../qux/') == '/foo/qux'

# Generated at 2022-06-16 19:47:17.007077
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test with default value
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    # Test with no default value
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    # Test with multiple values
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])

# Generated at 2022-06-16 19:47:20.011001
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'a', '--foo', 'b'])
    assert args.foo == ['b', 'a']



# Generated at 2022-06-16 19:47:31.457119
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')

# Generated at 2022-06-16 19:47:42.233777
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo//') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar//') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/') == '/tmp/foo/bar/baz'

# Generated at 2022-06-16 19:48:04.513824
# Unit test for function version
def test_version():
    assert version() == '2.9.0\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]\n  jinja version = 2.9.6\n  libyaml = True'

#
# Option Parsers
#

# Generated at 2022-06-16 19:48:05.355734
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

# Generated at 2022-06-16 19:48:09.113274
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'
    assert maybe_unfrack_path('@')('foo/bar') == 'foo/bar'



# Generated at 2022-06-16 19:48:14.253283
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file:') == '/path/to/file'
    assert unfrack_path()('/path/to/file:/path/to/file2') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:/path/to/file3') == '/path/to/file:/path/to/file2:/path/to/file3'

# Generated at 2022-06-16 19:48:26.015922
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('/tmp/foo/') == '/tmp/foo/'
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('/tmp/foo/bar') == '/tmp/foo/bar'



# Generated at 2022-06-16 19:48:32.277096
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:34.841826
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:48:44.886918
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test PrependListAction')
    parser.add_argument('--foo', action=PrependListAction, nargs='+', default=[])
    parser.add_argument('--bar', action=PrependListAction, nargs='+', default=[])
    parser.add_argument('--baz', action=PrependListAction, nargs='+', default=[])
    parser.add_argument('--qux', action=PrependListAction, nargs='+', default=[])
    parser.add_argument('--quux', action=PrependListAction, nargs='+', default=[])

# Generated at 2022-06-16 19:48:52.740545
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../qux') == '/qux'

# Generated at 2022-06-16 19:49:04.398550
# Unit test for function version
def test_version():
    assert version('ansible-playbook') == 'ansible-playbook [core 2.9.0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible-playbook\n  python version = 2.7.5 (default, Aug  4 2017, 00:39:18) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-16)]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:49:39.294294
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:49:44.041191
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:49:44.615895
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass



# Generated at 2022-06-16 19:49:51.081485
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    parser.add_argument('--bar', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', '1', '--bar', '2', '--foo', '3', '--bar', '4'])
    assert args.foo == ['1', '3']
    assert args.bar == ['2', '4']



# Generated at 2022-06-16 19:49:58.240975
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-c')
    parser.add_argument('-b')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:50:07.016938
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'
    assert maybe_unfrack_path('@')('@./foo/bar') == '@./foo/bar'
    assert maybe_unfrack_path('@')('@../foo/bar') == '@../foo/bar'
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@~/foo/bar'



# Generated at 2022-06-16 19:50:12.291320
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction)
    args = parser.parse_args(['--foo', '1', '2', '--bar', '3', '4'])
    assert args.foo == ['1', '2']
    assert args.bar == ['3', '4']



# Generated at 2022-06-16 19:50:13.716339
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:50:14.969184
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:50:22.235153
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@@/tmp/foo/') == '@@/tmp/foo/'
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')