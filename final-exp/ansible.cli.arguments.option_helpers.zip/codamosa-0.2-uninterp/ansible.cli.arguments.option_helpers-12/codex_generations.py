

# Generated at 2022-06-16 19:41:45.727929
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:41:55.311109
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'
    args = parser.parse_args(['-K', '--become-password-file', 'test'])
    assert args.become_ask_pass is True
    assert args.become_password_file == 'test'



# Generated at 2022-06-16 19:42:03.439178
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:42:05.136944
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None


# Generated at 2022-06-16 19:42:09.992783
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'test_inventory', '--list-hosts', '-l', 'test_limit'])
    assert args.inventory == ['test_inventory']
    assert args.listhosts == True
    assert args.subset == 'test_limit'


# Generated at 2022-06-16 19:42:14.216206
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar'])
    assert args.vault_ids == ['foo', 'bar']
    args = parser.parse_args(['--vault-password-file', 'foo', '--vault-password-file', 'bar'])
    assert args.vault_password_files == ['foo', 'bar']
    args = parser.parse_args(['--ask-vault-password'])
    assert args.ask_vault_pass is True
    args = parser.parse_args([])
    assert args.ask_vault_pass is False

#
# Functions to add pre-canned options to an OptionParser
#



# Generated at 2022-06-16 19:42:18.812483
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'test_inventory', '--list-hosts', '-l', 'test_subset'])
    assert options.inventory == ['test_inventory']
    assert options.listhosts is True
    assert options.subset == 'test_subset'



# Generated at 2022-06-16 19:42:21.131929
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line == True
    assert args.tree == 'test'



# Generated at 2022-06-16 19:42:23.638998
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-16 19:42:26.142870
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:42:49.941120
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@@/tmp/foo/bar') == '@@/tmp/foo/bar'

# Generated at 2022-06-16 19:43:01.959940
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    add_connect_options(parser)
    args = parser.parse_args(['-k', '-u', 'root', '-c', 'ssh', '-T', '10', '--ssh-common-args', '-o', 'ProxyCommand=ssh -W %h:%p', '--sftp-extra-args', '-f', '-l', '--scp-extra-args', '-l', '--ssh-extra-args', '-R', '--private-key', '~/.ssh/id_rsa', '--connection-password-file', '~/.ssh/passwd'])
    assert args.ask_pass == True
    assert args.remote_user == 'root'
    assert args

# Generated at 2022-06-16 19:43:04.285872
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:43:16.318368
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('/tmp/foo/') == '/tmp/foo/'
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('/tmp/foo/bar') == '/tmp/foo/bar'
    assert maybe_unfrack

# Generated at 2022-06-16 19:43:25.734704
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/test.pem', '-u', 'testuser', '-c', 'testconnection', '-T', '10',
                              '--ssh-common-args', 'testsshcommonargs', '--sftp-extra-args', 'testsftpextraargs',
                              '--scp-extra-args', 'testscpextraargs', '--ssh-extra-args', 'testsshextraargs',
                              '-k', '--connection-password-file', '~/test.pem'])
    assert args.private_key_file == '~/test.pem'
    assert args.remote_user == 'testuser'

# Generated at 2022-06-16 19:43:29.927057
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True


# Generated at 2022-06-16 19:43:31.293599
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '10'])
    assert args.forks == 10


# Generated at 2022-06-16 19:43:34.482084
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', '10', '-B', '20'])
    assert options.poll_interval == 10
    assert options.seconds == 20


# Generated at 2022-06-16 19:43:45.658707
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:43:47.725309
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['-f', '10'])
    assert options.forks == 10


# Generated at 2022-06-16 19:43:54.168052
# Unit test for function version
def test_version():
    assert version() is not None

# Generated at 2022-06-16 19:44:04.999155
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:44:06.830882
# Unit test for function version
def test_version():
    assert version() == version(prog='ansible')

# Generated at 2022-06-16 19:44:07.466975
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:44:16.454476
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:44:29.213361
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')

# Generated at 2022-06-16 19:44:40.509107
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@/foo/bar'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@/') == '@' + unfrackpath('/')
    assert maybe_unfrack_path('@')('@/') == '@/'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@/foo/bar'
    assert maybe_unfrack_

# Generated at 2022-06-16 19:44:48.082694
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file:') == '/path/to/file'
    assert unfrack_path()('/path/to/file:/path/to/file2') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:') == '/path/to/file:/path/to/file2'
    assert unfrack_path()('/path/to/file:/path/to/file2:/path/to/file3') == '/path/to/file:/path/to/file2:/path/to/file3'

# Generated at 2022-06-16 19:44:55.509312
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/roles') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/') == '/etc/ansible/roles'
    assert unfrack_path()('roles') == 'roles'
    assert unfrack_path()('roles/') == 'roles'
    assert unfrack_path()('~/roles') == '~/roles'
    assert unfrack_path()('~/roles/') == '~/roles'

# Generated at 2022-06-16 19:44:57.231974
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible')


# Generated at 2022-06-16 19:45:12.633960
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/') == '/etc/ansible/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack_path()('/etc/ansible/ansible.cfg/ansible.cfg/') == '/etc/ansible/ansible.cfg/ansible.cfg'
    assert unfrack

# Generated at 2022-06-16 19:45:21.004914
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:45:31.344887
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')

# Generated at 2022-06-16 19:45:39.687688
# Unit test for function version
def test_version():
    assert version('test') == 'test [core 2.9.0] (test-branch test-commit) last updated test-date (GMT test-offset)\n  config file = test-config\n  configured module search path = test-module-path\n  ansible python module location = test-ansible-path\n  ansible collection location = test-collection-path\n  executable location = test-executable\n  python version = test-python-version\n  jinja version = test-jinja-version\n  libyaml = test-libyaml'

# Generated at 2022-06-16 19:45:43.086244
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-16 19:45:48.570270
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@@') == '@@'



# Generated at 2022-06-16 19:45:54.234572
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.print_help()


# Generated at 2022-06-16 19:46:06.379288
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:46:12.149287
# Unit test for function version
def test_version():
    assert version('ansible') == 'ansible [core 2.9.0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3.6/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.6.8 (default, Apr 25 2019, 21:02:35) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]\n  jinja version = 2.10\n  libyaml = True'

# Generated at 2022-06-16 19:46:21.807096
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrack

# Generated at 2022-06-16 19:46:43.527050
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@@')('@@/tmp/foo') == '@@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@@')('@@@/tmp/foo') == '@@@/tmp/foo'
    assert maybe_unfrack_path('@@')('@@@/tmp/foo') == '@@@/tmp/foo'
    assert maybe_unfrack_path('@@')('@@@/tmp/foo') == '@@@/tmp/foo'
    assert maybe_unfrack

# Generated at 2022-06-16 19:46:52.379631
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/baz') == '@' + unfrackpath('/tmp/foo/bar/baz')

# Generated at 2022-06-16 19:46:52.893982
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-16 19:46:58.919984
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'

# Generated at 2022-06-16 19:47:02.769745
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'



# Generated at 2022-06-16 19:47:13.447109
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/.') == '/foo/bar'
    assert unfrack_path()('/foo/bar/..') == '/foo'
    assert unfrack_path()('/foo/bar/../') == '/foo'
    assert unfrack_path()('/foo/bar/../../') == '/'
    assert unfrack_path()('/foo/bar/../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../../') == '/'

# Generated at 2022-06-16 19:47:21.155345
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/bar') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/') == '/tmp/foo/bar'
    assert unfrack_path()('/tmp/foo/bar/baz') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/') == '/tmp/foo/bar/baz'
    assert unfrack_path()('/tmp/foo/bar/baz/qux') == '/tmp/foo/bar/baz/qux'

# Generated at 2022-06-16 19:47:32.171605
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:47:42.929793
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:47:51.008977
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/qux') == '@' + unfrackpath('/foo/bar/baz/qux')

# Generated at 2022-06-16 19:48:10.686438
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-16 19:48:21.484967
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:30.560805
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:37.262787
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert parser.parse_args(['--foo', 'a', 'b', 'c']).foo == ['a', 'b', 'c']
    assert parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f']).foo == ['d', 'e', 'f', 'a', 'b', 'c']

#
# Option Parser
#

# Generated at 2022-06-16 19:48:47.144299
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:48:54.291147
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('@./foo/bar') == '@' + unfrackpath('./foo/bar')
    assert maybe_unfrack_path('@')('@../foo/bar') == '@' + unfrackpath('../foo/bar')
    assert maybe_unfrack_path('@')('@../../foo/bar') == '@' + unfrackpath('../../foo/bar')

# Generated at 2022-06-16 19:49:06.121610
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/../baz') == '/foo/baz'
    assert unfrack_path()('/foo/bar/../baz/') == '/foo/baz/'
    assert unfrack_path()('/foo/bar/../../baz') == '/baz'
    assert unfrack_path()('/foo/bar/../../baz/') == '/baz/'
    assert unfrack_path()('/foo/bar/../../../baz') == '/baz'
    assert unfrack_path()('/foo/bar/../../../baz/') == '/baz/'
    assert unf

# Generated at 2022-06-16 19:49:17.696879
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:49:28.994444
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:39.267017
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar:/baz/qux') == '/foo/bar:/baz/qux'
    assert unfrack_path(pathsep=True)('/foo/bar:/baz/qux') == ['/foo/bar', '/baz/qux']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert unfrack_path()('~/foo/bar:/baz/qux') == os.path.expanduser('~/foo/bar') + ':/baz/qux'

# Generated at 2022-06-16 19:50:10.226722
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')
   

# Generated at 2022-06-16 19:50:19.030674
# Unit test for function version
def test_version():
    assert version() == version(prog=None)
    assert version(prog='ansible') == version(prog='ansible')
    assert version(prog='ansible-playbook') == version(prog='ansible-playbook')
    assert version(prog='ansible-config') == version(prog='ansible-config')
    assert version(prog='ansible-doc') == version(prog='ansible-doc')
    assert version(prog='ansible-galaxy') == version(prog='ansible-galaxy')
    assert version(prog='ansible-inventory') == version(prog='ansible-inventory')
    assert version(prog='ansible-pull') == version(prog='ansible-pull')

# Generated at 2022-06-16 19:50:25.031268
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:50:31.715598
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser.add_argument('-e')
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.add_argument('-h')
    parser.add_argument('-i')
    parser.add_argument('-j')
    parser.add_argument('-k')
    parser.add_argument('-l')
    parser.add_argument('-m')
    parser.add_argument('-n')
    parser.add_argument('-o')
    parser.add_argument('-p')
   

# Generated at 2022-06-16 19:50:39.205753
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')

# Generated at 2022-06-16 19:50:46.797411
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('/foo/bar/') == '/foo/bar/'



# Generated at 2022-06-16 19:50:56.724792
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/etc/ansible/ansible.cfg') == '@' + unfrackpath('/etc/ansible/ansible.cfg')
    assert maybe_unfrack_path('@')('@/etc/ansible/ansible.cfg') != '@/etc/ansible/ansible.cfg'
    assert maybe_unfrack_path('@')('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    assert maybe_unfrack_path('@')('@/etc/ansible/ansible.cfg') != '@' + '/etc/ansible/ansible.cfg'