

# Generated at 2022-06-16 19:41:35.914548
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Create a parser
    parser = argparse.ArgumentParser()
    # Create an AnsibleVersion object
    ansible_version = AnsibleVersion(option_strings=['--version'])
    # Call the method __call__ of class AnsibleVersion
    ansible_version.__call__(parser, None, None, '--version')



# Generated at 2022-06-16 19:41:43.630819
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    ns = Namespace()
    assert ensure_value(ns, 'foo', []) == []
    assert ns.foo == []
    assert ensure_value(ns, 'foo', []) is ns.foo
    assert ensure_value(ns, 'foo', [1]) == []
    assert ns.foo == []
    assert ensure_value(ns, 'bar', [1]) == [1]
    assert ns.bar == [1]
    assert ensure_value(ns, 'bar', []) is ns.bar



# Generated at 2022-06-16 19:41:48.892476
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    n = Namespace()
    ensure_value(n, 'foo', 'bar')
    assert n.foo == 'bar'
    ensure_value(n, 'foo', 'baz')
    assert n.foo == 'bar'


#
# Common code for all parsers
#

# Generated at 2022-06-16 19:41:57.358367
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'test'])
    assert args.become_password_file == 'test'



# Generated at 2022-06-16 19:42:02.414060
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '5', '-B', '10'])
    assert args.poll_interval == 5
    assert args.seconds == 10



# Generated at 2022-06-16 19:42:05.306963
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:42:15.121116
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args([])
    assert options.become == C.DEFAULT_BECOME
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user == C.DEFAULT_BECOME_USER
    assert options.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS
    assert options.become_ask_sudo_pass == C.DEFAULT_BECOME_ASK_SUDO_PASS
    assert options.become_ask_su_pass == C.DEFAULT_BECOME_ASK_SU_PASS
    assert options.become_password_file == C.BECOME_PASSWORD_FILE

# Generated at 2022-06-16 19:42:27.603225
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '--user', 'root', '--connection', 'ssh', '--timeout', '10',
                              '--ssh-common-args', '-o ProxyCommand="ssh -W %h:%p -q bastion"',
                              '--sftp-extra-args', '-f', '-l',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '--ask-pass',
                              '--connection-password-file', '~/.ssh/id_rsa'])

# Generated at 2022-06-16 19:42:29.282000
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'tree'])
    assert args.one_line is True
    assert args.tree == 'tree'


# Generated at 2022-06-16 19:42:33.071616
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None



# Generated at 2022-06-16 19:42:55.555353
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4']).tags == ['tag1', 'tag2']
    assert parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4']).skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:43:02.730634
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', 'tag1', '--tags', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['tag3', 'tag4']



# Generated at 2022-06-16 19:43:14.835905
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar/'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz/'
    assert unfrack_path()('/foo/bar/baz/qux') == '/foo/bar/baz/qux'
    assert unfrack_path()('/foo/bar/baz/qux/') == '/foo/bar/baz/qux/'

# Generated at 2022-06-16 19:43:19.928448
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path()('/etc/ansible/roles') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/foo') == '/etc/ansible/roles/foo'
    assert unfrack_path()('/etc/ansible/roles/foo/') == '/etc/ansible/roles/foo'
    assert unfrack_path()('roles/foo') == 'roles/foo'

# Generated at 2022-06-16 19:43:25.004056
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip1', '--skip-tags', 'skip2'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-16 19:43:35.839049
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('@/path/to/file') != '@/path/to/file'
    assert maybe_unfrack_path('@')('/path/to/file') == '/path/to/file'
    assert maybe_unfrack_path('@')('@/path/to/file') != '/path/to/file'
    assert maybe_unfrack_path('@')('@/path/to/file') != '@path/to/file'
    assert maybe_unfrack_path('@')('@path/to/file') == '@path/to/file'
    assert maybe_

# Generated at 2022-06-16 19:43:46.532560
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../../bar') == '/bar'
    assert unfrack_path()('/tmp/foo/../../bar/') == '/bar'

# Generated at 2022-06-16 19:43:53.555009
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip1', '--skip-tags', 'skip2'])
    assert args.tags == ['tag1', 'tag2']
    assert args.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-16 19:44:01.820861
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-c')
    assert parser.format_help() == 'usage: [-h] [-a] [-b] [-c]\n\noptional arguments:\n  -h, --help  show this help message and exit\n  -a\n  -b\n  -c\n'


# Generated at 2022-06-16 19:44:10.605465
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:44:22.538526
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'hosts', '--list-hosts', '-l', 'subset'])
    assert args.inventory == ['hosts']
    assert args.listhosts == True
    assert args.subset == 'subset'


# Generated at 2022-06-16 19:44:32.282673
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@' + unfrackpath('/foo/bar/')
    assert maybe_unfrack_path('@')('@/foo/bar/baz') == '@' + unfrackpath('/foo/bar/baz')
    assert maybe_unfrack_path('@')('@/foo/bar/baz/') == '@' + unfrackpath('/foo/bar/baz/')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'

# Generated at 2022-06-16 19:44:34.601808
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:44:45.039475
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@~/foo') == '@' + unfrackpath('~/foo')
    assert maybe_unfrack_path('@')('@~/foo/bar') == '@' + unfrackpath('~/foo/bar')
    assert maybe_unfrack_path('@')('@~/foo/bar/') == '@' + unfrackpath('~/foo/bar/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')

# Generated at 2022-06-16 19:44:52.517722
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@@') == '@@'



# Generated at 2022-06-16 19:45:02.827107
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')

# Generated at 2022-06-16 19:45:04.486594
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-16 19:45:11.395805
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'
    assert maybe_unfrack_path('@@')('@@/foo/bar') == '@@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@@')('@@@/foo/bar') == '@@@/foo/bar'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@@')('@@') == '@@'



# Generated at 2022-06-16 19:45:19.820971
# Unit test for function version
def test_version():
    assert version() == '2.9.6 (devel fb7d8c5e5)  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python3.6/site-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.6.8 (default, Apr 25 2019, 21:02:35) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]\n  jinja version = 2.10\n  libyaml = True'


# Generated at 2022-06-16 19:45:23.418986
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-16 19:45:35.976188
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:45:46.679314
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    assert unfrack_path()('/path/to/file/') == '/path/to/file'
    assert unfrack_path()('/path/to/file/../file') == '/path/to/file'
    assert unfrack_path()('/path/to/file/../../file') == '/path/to/file'
    assert unfrack_path()('/path/to/file/../../../file') == '/path/to/file'
    assert unfrack_path()('/path/to/file/../../../../file') == '/path/to/file'
    assert unfrack_path()('/path/to/file/../../../../../file') == '/path/to/file'
    assert unfrack_

# Generated at 2022-06-16 19:45:48.018115
# Unit test for function version
def test_version():
    assert version()
    assert version('test')

#
# Options
#

# Generated at 2022-06-16 19:45:55.263878
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']



# Generated at 2022-06-16 19:45:59.330519
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:09.138753
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')
    assert maybe_unfrack_path('@')('@/tmp/foo/bar/') == '@' + unfrackpath('/tmp/foo/bar/')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'

# Generated at 2022-06-16 19:46:18.957679
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test with default values
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz']
    # Test with nargs
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs=2, default=[])
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']

# Generated at 2022-06-16 19:46:30.023989
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@@/tmp/foo/') == '@@/tmp/foo/'
    assert maybe_unfrack_path('@')('@/tmp/foo/bar') == '@' + unfrackpath('/tmp/foo/bar')

# Generated at 2022-06-16 19:46:35.983161
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action="store_true", help="b help")
    parser.add_argument('-a', action="store_true", help="a help")
    parser.add_argument('-c', action="store_true", help="c help")
    parser.add_argument('-d', action="store_true", help="d help")
    parser.add_argument('-e', action="store_true", help="e help")
    parser.add_argument('-f', action="store_true", help="f help")
    parser.add_argument('-g', action="store_true", help="g help")
    parser.add_argument('-h', action="store_true", help="h help")
   

# Generated at 2022-06-16 19:46:40.028357
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:46:55.979448
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo:/tmp/bar') == '/tmp/foo:/tmp/bar'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-16 19:47:01.383833
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args('--foo 1 --foo 2'.split())
    assert args.foo == ['2', '1']

# Generated at 2022-06-16 19:47:11.468929
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test with no default value
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz']

    # Test with default value
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=['a', 'b'])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz', 'a', 'b']

#
# Option Parser
#

# Generated at 2022-06-16 19:47:19.862251
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--quuz')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')


# Generated at 2022-06-16 19:47:31.454645
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/.') == '/foo/bar'
    assert unfrack_path()('/foo/bar/..') == '/foo'
    assert unfrack_path()('/foo/bar/../') == '/foo'
    assert unfrack_path()('/foo/bar/../../') == '/'
    assert unfrack_path()('/foo/bar/../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../../') == '/'

# Generated at 2022-06-16 19:47:35.810164
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='test')
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    args = parser.parse_args([])
    assert args.foo == []



# Generated at 2022-06-16 19:47:47.521010
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'

# Generated at 2022-06-16 19:47:50.177276
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'a', '--foo', 'b'])
    assert args.foo == ['b', 'a']



# Generated at 2022-06-16 19:47:56.831578
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo') != '@/tmp/foo'



# Generated at 2022-06-16 19:48:02.791176
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('/path/to/file') == '/path/to/file'
    assert maybe_unfrack_path('@')('@/path/to/file') != '@/path/to/file'



# Generated at 2022-06-16 19:48:35.215899
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction)
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--bar', '3', '--bar', '4'])
    assert args.foo == ['1', '2']
    assert args.bar == ['3', '4']



# Generated at 2022-06-16 19:48:45.307115
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:48:50.365311
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction)
    args = parser.parse_args(['--foo', 'a', '--bar', 'b', '--foo', 'c', '--bar', 'd'])
    assert args.foo == ['c', 'a']
    assert args.bar == ['d', 'b']


# Generated at 2022-06-16 19:48:56.306401
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/.') == '/foo/bar'
    assert unfrack_path()('/foo/bar/..') == '/foo'
    assert unfrack_path()('/foo/bar/../') == '/foo'
    assert unfrack_path()('/foo/bar/../../') == '/'
    assert unfrack_path()('/foo/bar/../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../') == '/'
    assert unfrack_path()('/foo/bar/../../../../../') == '/'

# Generated at 2022-06-16 19:48:59.381855
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-16 19:49:08.733912
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/') == '/tmp/foo'
    assert unfrack_path()('/tmp/foo/../bar') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/') == '/tmp/bar'
    assert unfrack_path()('/tmp/foo/../bar/../baz') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/') == '/tmp/baz'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../') == '/tmp'
    assert unfrack_path()('/tmp/foo/../bar/../baz/../../') == '/'


# Generated at 2022-06-16 19:49:16.112434
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = parser.parse_args(['--foo', 'a', 'b', 'c', '--foo', 'd', 'e', 'f'])
    assert args.foo == ['d', 'e', 'f', 'a', 'b', 'c']


# Generated at 2022-06-16 19:49:26.086191
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz']
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz', '--foo', 'qux'])
    assert args.foo == ['bar', 'baz', 'qux']



# Generated at 2022-06-16 19:49:37.634703
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar/') == '/foo/bar'
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'
    assert unfrack_path()('/foo/bar/baz/') == '/foo/bar/baz'

# Generated at 2022-06-16 19:49:45.901844
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', '1', '--foo', '2'])
    assert args.foo == ['1', '2']
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--foo', '3'])
    assert args.foo == ['1', '2', '3']

