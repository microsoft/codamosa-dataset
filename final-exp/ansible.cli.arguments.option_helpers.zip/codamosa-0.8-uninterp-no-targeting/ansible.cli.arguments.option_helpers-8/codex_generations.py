

# Generated at 2022-06-20 12:52:29.918008
# Unit test for function add_output_options
def test_add_output_options():
    from ansible.utils.sentinel import Sentinel
    parser = argparse.ArgumentParser()
    add_output_options(parser)

    # test defaults
    parsed = parser.parse_args([])
    assert parsed.one_line is None
    assert parsed.tree is None

    # test values
    parsed = parser.parse_args(['-o', '-t', 'foo'])
    assert parsed.one_line is True
    assert parsed.tree == 'foo'


# Generated at 2022-06-20 12:52:41.572879
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test that paths are converted to absolute native paths
    # https://docs.python.org/3/library/os.path.html#os.path.abspath
    test_paths = [
        ('/dev', '/dev'),
        ('/dev/null', '/dev/null'),
        ('~/ansible', os.path.abspath('~/ansible')),
    ]

    # Test that relative paths are converted to absolute paths relative to the
    # current working directory.
    # https://docs.python.org/3/library/os.path.html#os.path.abspath
    current_dir = os.path.abspath(os.curdir)

# Generated at 2022-06-20 12:52:53.341338
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.py3kcompat import PY3

    # test a simple Python list using nargs=1
    a = PrependListAction(option_strings=['-a','--append'], dest='append', nargs=1, required=False, help=None, metavar=None)
    namespace = argparse.Namespace()
    values = ['foo']
    a(None, namespace, values)
    assert getattr(namespace, 'append') == values

    # test a Python list with a variable number of args,
    # including the special case where the variable number of
    # args is 0 (using nargs=argparse.ONE_OR_MORE)

# Generated at 2022-06-20 12:52:54.054990
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    pass



# Generated at 2022-06-20 12:52:59.939701
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = ['--ask-become-pass']
    args = parser.parse_args(args)
    assert args.become_ask_pass is True
    args = ['--become-password-file=/tmp/become.txt']
    args = parser.parse_args(args)
    assert args.become_password_file == '/tmp/become.txt'
    args = ['--ask-become-pass', '--become-password-file=/tmp/become.txt']
    args = parser.parse_args(args)
    assert args.become_ask_pass is True
    assert args.become_password_file == '/tmp/become.txt'



# Generated at 2022-06-20 12:53:05.440487
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=argparse.ArgumentParser()
    add_meta_options(parser)
    args_list=parser.parse_args(['--force-handlers'])
    assert args_list.force_handlers == True
    args_list=parser.parse_args(['--flush-cache'])
    assert args_list.flush_cache == True


# Generated at 2022-06-20 12:53:11.976256
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog="test_program")
    add_tasknoplay_options(parser)
    options = parser.parse_args(args=[])
    assert options.task_timeout == C.TASK_TIMEOUT
    options = parser.parse_args(args=["--task-timeout", "666"])
    assert options.task_timeout == 666



# Generated at 2022-06-20 12:53:12.988251
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    assert parser is not None



# Generated at 2022-06-20 12:53:16.183678
# Unit test for function add_vault_options
def test_add_vault_options():
    
    parser = argparse.ArgumentParser(prog='ansible',
                                     usagge='''ansible <host-pattern> [options]''',
                                     description='Runs Ansible modules on a target host')
    
    add_vault_options(parser)
    params = parser.parse_args('--ask-vault-pass --vault-password-file /home/user/vault_pass'.split())

    assert params.ask_vault_pass == True
    assert params.vault_password_files == ['/home/user/vault_pass']

# Generated at 2022-06-20 12:53:18.750816
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(description='This is a testing')
    add_tasknoplay_options(parser)
    args = parser.parse_args(args=['--task-timeout', '-1'])
    assert args.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-20 12:53:43.361107
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.add_argument('--playbook-dir', default=C.config.get_config_value('PLAYBOOK_DIR'), dest='basedir', action='store',
                        help="Since this tool does not use playbooks, use this as a substitute playbook directory."
                             "This sets the relative path for many features including roles/ group_vars/ etc.",
                        type=unfrack_path())



# Generated at 2022-06-20 12:53:56.158797
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args([])
    assert args.become is False
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user is None
    assert args.become_ask_pass is False
    assert args.ask_pass is False

    args = parser.parse_args(['-b'])
    assert args.become is True
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user is None
    assert args.become_ask_pass is False
    assert args.ask_pass is False


# Generated at 2022-06-20 12:53:57.037254
# Unit test for function add_runtask_options
def test_add_runtask_options():
    # TODO: Create unit test for add_runtask_options
    pass


# Generated at 2022-06-20 12:54:02.404994
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert(parser.print_help(), '''usage: test_add_meta_options.py [-h] [--force-handlers] [--flush-cache]

optional arguments:
  -h, --help            show this help message and exit
  --force-handlers      run handlers even if a task fails
  --flush-cache         clear the fact cache for every host in inventory
''')

# Generated at 2022-06-20 12:54:07.687932
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    class args(object):
        task_timeout = 0
        extra_vars = []
    parser = argparse.ArgumentParser(description='test_add_tasknoplay_options')
    add_tasknoplay_options(parser)
    args = parser.parse_args(args=[])
    assert args.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-20 12:54:18.214400
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class Argument:
        def __init__(self, option_strings, *args, **kwargs):
            self.option_strings = option_strings

    parser = SortingHelpFormatter(argparse.ArgumentParser())
    input_obj = [
        Argument(["-c"]),
        Argument(["-b"]),
        Argument(["-a"]),
        Argument(["-e"]),
        Argument(["-d"])
    ]
    #test with a list of Actions
    ref_obj = [
        Argument(["-a"]),
        Argument(["-b"]),
        Argument(["-c"]),
        Argument(["-d"]),
        Argument(["-e"])
    ]

    parser.add_arguments(input_obj)
    assert ref_obj == input_obj


# Generated at 2022-06-20 12:54:21.809319
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test_playbook_dir'])
    assert args.basedir == 'test_playbook_dir'



# Generated at 2022-06-20 12:54:32.689225
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # test case: no unrecognized arguments
    parser = argparse.ArgumentParser(description='Test', add_help=False)
    parser.add_argument('-c', action=UnrecognizedArgument)
    parser.parse_args(['playbook.yml'])

    # test case: no unrecgonized arguments - ack
    parser = argparse.ArgumentParser(description='Test', add_help=False)
    parser.add_argument('-c', action=UnrecognizedArgument)
    parser.parse_args(['--ack-pass', 'playbook.yml'])

    # test case: unrecognized arguments
    parser = argparse.ArgumentParser(description='Test', add_help=False)
    parser.add_argument('-c', action=UnrecognizedArgument)

# Generated at 2022-06-20 12:54:36.154202
# Unit test for function add_check_options
def test_add_check_options():
    res = SortingHelpFormatter()
    assert isinstance(res, SortingHelpFormatter)


# Generated at 2022-06-20 12:54:38.693934
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    data = parser.parse_args("-o -t ~/tmp".split())
    # Check if one_line is set to True
    assert data.one_line
    # Check for tree directory
    assert data.tree == "~/tmp"



# Generated at 2022-06-20 12:55:08.748415
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='test')
    add_async_options(parser)
    option, args = parser.parse_known_args([])
    assert option.seconds == 0
    assert option.poll_interval == C.DEFAULT_POLL_INTERVAL
    option, args = parser.parse_known_args(['-B', '10', '-P', '20'])
    assert option.seconds == 10
    assert option.poll_interval == 20


# Generated at 2022-06-20 12:55:10.106080
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='script')
    add_runtask_options(parser)


# Generated at 2022-06-20 12:55:12.123625
# Unit test for function add_basedir_options
def test_add_basedir_options():
    b = argparse.ArgumentParser()
    add_basedir_options(b)
    assert b.dest=='basedir'


# Generated at 2022-06-20 12:55:21.411513
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('') == ''
    assert unfrack_path()('/etc') == '/etc'
    assert unfrack_path()('/etc:.') == '/etc:.'
    assert unfrack_path(pathsep=True)('') == []
    assert unfrack_path(pathsep=True)('/etc') == ['/etc']
    assert unfrack_path(pathsep=True)('/etc:.') == ['/etc', '.']
    assert unfrack_path(pathsep=True)('~/:/usr:/etc/') == ['~', '/usr', '/etc']
    return True



# Generated at 2022-06-20 12:55:28.150619
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    print("Testding class PrependListAction ")
    parser = argparse.ArgumentParser(prog='ansible-inventory')
    parser.add_argument('-p', '--prepend', metavar="groupname", action=PrependListAction, dest="prepend", help="prepend groupname to the path")
    print(dir(parser))
    print("parser.parse_args = ", parser.parse_args(['--prepend=aaa', '--prepend=bbb']))



# Generated at 2022-06-20 12:55:30.819046
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert parser.add_argument_group.call_count == 2


# Generated at 2022-06-20 12:55:33.936180
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    parser.parse_args(['--check'])



# Generated at 2022-06-20 12:55:41.475283
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible', conflict_handler='resolve',description="description")
    add_inventory_options(parser)
    (args, _) = parser.parse_known_args(['-i', '/path/to/hosts', '--list-hosts', '-l', 'subset'])
    assert args.inventory == ['/path/to/hosts']
    assert args.subset == 'subset'
    assert args.listhosts == True


# Generated at 2022-06-20 12:55:47.213232
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    class FakeParser(object):
        pass

    class FakeNamespace(object):
        pass

    parser = FakeParser()
    parser.prog = 'foo'
    namespace = FakeNamespace()
    option_string = None
    values = None
    # assert nothing raised
    AnsibleVersion(self=None)(parser, namespace, values, option_string=None)
    #assert(namespace is None)



# Generated at 2022-06-20 12:55:52.210834
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import ansible.cli
    setattr(ansible.cli.CLI, 'ansible_version', 'ansible_version')
    setattr(ansible.cli.CLI, 'exit', 'exit')
    ansible.cli.AnsibleVersion.__call__(self, parser='parser', namespace='namespace', values='values', option_string='option_string')



# Generated at 2022-06-20 12:56:01.207491
# Unit test for function add_module_options
def test_add_module_options():
    module_path = C.config.get_configuration_definition('DEFAULT_MODULE_PATH')
    assert module_path.get('default', '').startswith('/usr/share/ansible')



# Generated at 2022-06-20 12:56:04.085190
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    with pytest.raises(SystemExit):
        p = AnsibleOptionParser()
        p.parse_args('--foo'.split())


#
# AnsibleOptionParser
#

# Generated at 2022-06-20 12:56:12.651688
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    opt = argparse.Namespace()
    opt.a = []
    opt.b = []

    # test that `a` is appended normally
    action = PrependListAction(option_strings=['-a'], dest='a')
    action(None, opt, [1, 2], '-a')
    assert opt.a == [1, 2]

    # test that `b` is prepended with two arguments
    action = PrependListAction(option_strings=['-b'], dest='b')
    action(None, opt, [3, 4], '-b')
    assert opt.b == [3, 4]

# Generated at 2022-06-20 12:56:17.510324
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C', '--syntax-check', '-D'])
    assert args.check
    assert args.syntax
    assert args.diff



# Generated at 2022-06-20 12:56:24.681564
# Unit test for function add_meta_options
def test_add_meta_options():
    class Options:
        pass
    opt = Options()
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(args=[])
    args_dict = vars(args)
    for key, val in args_dict.items():
        setattr(opt, key, val)
    assert opt.force_handlers == True
    assert opt.flush_cache == False
    assert repr(opt) == 'Options(flush_cache=False, force_handlers=True)'



# Generated at 2022-06-20 12:56:36.725279
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace():
        pass
    fake_namespace = FakeNamespace()
    ensure_value(fake_namespace, 'a', 'b')
    assert fake_namespace.a == 'b'
    ensure_value(fake_namespace, 'a', [])
    assert fake_namespace.a == 'b'
    fake_namespace.a = None
    ensure_value(fake_namespace, 'a', [])
    assert fake_namespace.a == []
    ensure_value(fake_namespace, 'a', 'b')
    assert fake_namespace.a == []


#
# Other misc/convenient globals
#

# Python 2/3 unicode workaround
if sys.version_info[0] >= 3:
    unicode = str

#
# --help/-h/h/

# Generated at 2022-06-20 12:56:42.887473
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.errors import AnsibleModuleError
    from . import display
    with pytest.raises(AnsibleModuleError) as excinfo:
        # pylint: disable=protected-access
        UnrecognizedArgument(option_strings='-i',dest='become_method',nargs=0).__call__(display.Display(),None,None)
    assert 'unrecognized arguments: -i' in str(excinfo.value)



# Generated at 2022-06-20 12:56:49.831554
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    for become_ask_pass in [True, False]:
        for become_password_file in [True, False]:
            for argument_group in [True, False]:
                parser = argparse.ArgumentParser()
                if argument_group:
                    runas_group = parser.add_argument_group()
                else:
                    runas_group = None
                add_runas_prompt_options(parser, runas_group)
                args = parser.parse_args([])
                assert args.become_ask_pass == become_ask_pass
                assert args.become_password_file == become_password_file



# Generated at 2022-06-20 12:56:56.529120
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '@/tmp/test.yml'])
    assert args.extra_vars == ['/tmp/test.yml']

    args = parser.parse_args(['-e', 'test1', '-e', 'test2'])
    assert args.extra_vars == ['test1', 'test2']



# Generated at 2022-06-20 12:57:00.259510
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    help = parser.format_help()
    assert "-i, --inventory, --inventory-file" in help
    assert "specify inventory host path or comma separated host list. --inventory-file is deprecated" in help
    assert "--list-hosts" in help
    assert "outputs a list of matching hosts; does not execute anything else" in help
    assert "-l, --limit" in help
    assert "further limit selected hosts to an additional pattern" in help


# Generated at 2022-06-20 12:57:10.879797
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    options = parser.parse_args(['-K'])
    assert options.become_ask_pass is True
    options = parser.parse_args(['--become-password-file=/path/to/file'])
    assert options.become_password_file == '/path/to/file'



# Generated at 2022-06-20 12:57:17.471840
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action=PrependListAction, nargs='*', const='const')
    parser.add_argument('-b', action=PrependListAction, nargs='*')
    parser.add_argument('-c', action=PrependListAction, nargs=2)
    opts = parser.parse_args('-a 1 -a 2 -b a b -c 1 2'.split())
    assert opts.a == ['1', '2', 'const']
    assert opts.b == ['a', 'b']
    assert opts.c == ['1', '2']

# Generated at 2022-06-20 12:57:22.877473
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_tasknoplay_options(parser)
    opt = parser.parse_args(['--task-timeout', '10'])
    assert opt.task_timeout == 10



# Generated at 2022-06-20 12:57:27.806426
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    # We assume a separator is single line, which doesn't require extra effort.
    str(parser.parse_args(callback=lambda *args: parser.exit(0, '\n')))



# Generated at 2022-06-20 12:57:33.719056
# Unit test for function add_output_options
def test_add_output_options():
    parser = Mock(argparse.ArgumentParser)
    module = sys.modules[__name__]
    module._mk_method = Mock()
    module._mk_method.return_value = None

    module.add_output_options(parser)
    module._mk_method.assert_any_call('-o', '--one-line')
    module._mk_method.assert_any_call('-t', '--tree')

# Generated at 2022-06-20 12:57:38.604032
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert len(vars(parser.parse_args()).items()) == 0 # No arguments
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert vars(parser.parse_args('--task-timeout 100'.split())) == {'task_timeout': 100}


# Generated at 2022-06-20 12:57:40.174265
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['--forks', '100'])
    assert args.forks==100


# Generated at 2022-06-20 12:57:51.895461
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    a = argparse.Action(option_strings=['-a'], dest='a', help='a')
    b = argparse.Action(option_strings=['-b'], dest='b', help='b')
    c = argparse.Action(option_strings=['-c'], dest='c', help='c')

    p = argparse.ArgumentParser()
    p.add_argument('-a', action=a)
    p.add_argument('-b', action=b)
    p.add_argument('-c', action=c)

    # unittest, verify sort order of option_strings
    s = SortingHelpFormatter()
    stream = s.format_help()
    assert stream.find('-a') < stream.find('-b') < stream.find('-c')


# Generated at 2022-06-20 12:57:54.490331
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Initialize an argument parser
    parser = argparse.ArgumentParser(description='Process some integers.')
    # Add options to the parser
    add_runas_prompt_options(parser)
    # Parse the options
    args = parser.parse_args()
    # Run tests
    assert args.become_password_file == "~/.ansible/ansible.cfg"



# Generated at 2022-06-20 12:57:59.711197
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(description='Merge runas options')
    add_runas_prompt_options(parser)
    args = parser.parse_args('-K --ask-become-pass --become-password-file /tmp/my_pass --become-pass-file /tmp/my_pass'.split(' '))
    assert args.become_ask_pass and args.become_password_file == "/tmp/my_pass"
    args = parser.parse_args('-K --ask-become-pass --become-password-file /tmp/my_pass'.split(' '))
    assert args.become_ask_pass and args.become_password_file == "/tmp/my_pass"

# Generated at 2022-06-20 12:58:12.381571
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, nargs=0)
    options = parser.parse_args(['--foo'])
    assert options.foo is True
    try:
        parser.parse_args(['--bar'])
        assert False
    except SystemExit:
        assert True


#
# The main parser
#

# Generated at 2022-06-20 12:58:22.841365
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # beacon plus a leading path separator and a relative path,
    # should return the relative path but prefixed with the beacon
    assert (maybe_unfrack_path('@')('@./test')) == '@test'
    # should return a path with a leading path separator but prefixed with the beacon
    assert (maybe_unfrack_path('@')('@/test')) == '@/test'
    # should return the original input data
    assert (maybe_unfrack_path('@')('/test')) == '/test'
    assert (maybe_unfrack_path('@')('test')) == 'test'
    assert (maybe_unfrack_path('@')('@test')) == '@test'


#
# CLI Option Parsers
#

# Generated at 2022-06-20 12:58:24.056711
# Unit test for function add_runtask_options
def test_add_runtask_options():
    assert add_runtask_options([]) == 'add_runtask_options'

# Generated at 2022-06-20 12:58:31.527930
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='test_add_fork_options')
    add_fork_options(parser)
    # parse_args defaults to [1:] for args, but you need to
    # specify the args you are going to use, or it will
    # parse sys.argv.[1:]
    args = parser.parse_args([])
    assert args.forks == C.DEFAULT_FORKS


# Generated at 2022-06-20 12:58:41.633743
# Unit test for function add_inventory_options
def test_add_inventory_options():
  parser = argparse.ArgumentParser()
  add_inventory_options(parser)
  parser.parse_args(['-i','/tmp/invent_path'])
  parser.parse_args(['--inventory','/tmp/invent_path'])
  parser.parse_args(['--inventory-file','/tmp/invent_path'])
  parser.parse_args(['--list-hosts'])
  parser.parse_args(['-l','my_limit'])
  parser.parse_args(['--limit','my_limit'])

# Generated at 2022-06-20 12:58:45.056195
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    parsed, args = parser.parse_known_args()
    assert all([parsed.check is False, parsed.syntax is False, parsed.diff is True])

# Generated at 2022-06-20 12:58:52.892309
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='test_add_check_options')
    add_check_options(parser)
    args = parser.parse_args(['-C'])
    assert args.check is True
    args = parser.parse_args(['--syntax-check'])
    assert args.syntax is True
    args = parser.parse_args(['-D'])
    assert args.diff is True



# Generated at 2022-06-20 12:58:54.453878
# Unit test for function version
def test_version():
    assert version()

#
# Option parsing
#

# Generated at 2022-06-20 12:58:56.875715
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog="test",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_connect_options(parser)
    parser.parse_args()



# Generated at 2022-06-20 12:59:06.498932
# Unit test for function add_check_options
def test_add_check_options():
    DATA = "syntax-check playbook"
    DATA1 = "-check playbook"
    DATA2 = "diff playbook"
    DATA3 = "check playbook"
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(args=DATA.split())
    assert args.syntax == True
    args = parser.parse_args(args=DATA1.split())
    assert args.check == True
    args = parser.parse_args(args=DATA2.split())
    assert args.diff == True
    args = parser.parse_args(args=DATA3.split())
    assert args.check == True
    return True


# Generated at 2022-06-20 12:59:24.807497
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cli.arguments import UnrecognizedArgument
    parser = argparse.ArgumentParser()
    ua = UnrecognizedArgument('-u', 'unrecognized')
    parser.add_argument('-u', action=ua)
    try:
        parser.parse_args(['-b', 'bar'])
    except SystemExit as e:
        assert e.code == 2

# Generated at 2022-06-20 12:59:31.004333
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(prog='test_UnrecognizedArgument___call__')
    parser.add_argument('--foo', action=UnrecognizedArgument, dest='bar')
    try:
        args = parser.parse_args(['--foo', 'baz'])
    except SystemExit:
        args = 'SystemExit'
    assert args == 'SystemExit'



# Generated at 2022-06-20 12:59:31.824410
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass



# Generated at 2022-06-20 12:59:40.128113
# Unit test for function add_subset_options
def test_add_subset_options():

    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args(["-v","--tags=ansible","-t=ansible-test","--skip-tags=ansible-skip","--skip-tags=ansible-skip2"])
    assert parser.parse_args(["-v","-t=smoke","--skip-tags=smoke"]).verbosity == 1
    assert parser.parse_args(["-v","-t=smoke","--skip-tags=smoke"]).tags == ['smoke']
    assert parser.parse_args(["-v","-t=smoke","--skip-tags=smoke"]).skip_tags == ['smoke']

# Generated at 2022-06-20 12:59:49.992679
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog='test_ansible_connection',
        formatter_class=SortingHelpFormatter,
        description='test module')
    add_connect_options(parser)

# Generated at 2022-06-20 12:59:53.491914
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['-f', '10'])
    print(options.forks)


# Generated at 2022-06-20 13:00:03.146353
# Unit test for function unfrack_path
def test_unfrack_path():
    assert(unfrack_path('/tmp/foo') == '/tmp/foo')
    assert(unfrack_path('/tmp/../tmp/foo') == '/tmp/foo')
    assert(unfrack_path('/tmp/foo') == os.path.realpath('/tmp/foo'))
    assert(unfrack_path('/tmp/foo') == os.path.normpath('/tmp/foo'))
    assert(unfrack_path('/tmp/foo/../bar') == os.path.normpath('/tmp/foo/../bar'))
    assert(unfrack_path('/tmp/foo/../bar') == os.path.realpath('/tmp/foo/../bar'))

# Generated at 2022-06-20 13:00:13.206487
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser('testing', formatter_class=SortingHelpFormatter)
    parser.add_argument('foo', choices=['bar', 'baz'])
    parser.add_argument('sli', choices=['mor', 'gni'])
    parser.add_argument('--one')
    parser.add_argument('--two')
    parser.add_argument('-a', '--alpha')
    parser.add_argument('-b', '--bravo')
    for line in parser.format_help().split("\n"):
        if not line.strip():
            continue
        assert line.startswith("  -"), line



# Generated at 2022-06-20 13:00:20.053344
# Unit test for function add_fork_options
def test_add_fork_options():
    prog = 'ansible-playbook'
    desc = 'Executes a playbook.'
    epilog = 'Does not actually do anything'
    parser = create_base_parser(prog, desc, epilog)
    add_fork_options(parser)
    # test successful case
    args = ['-f', '5']
    results = parser.parse_args(args)
    assert results.forks == 5, 'should have 5'
    args = ['--forks', '10']
    results = parser.parse_args(args)
    assert results.forks == 10, 'should have 10'
    # test default
    args = []
    results = parser.parse_args(args)
    assert results.forks == C.DEFAULT_FORKS, 'should have %s' %C.DEFAULT_FORKS
   

# Generated at 2022-06-20 13:00:22.604193
# Unit test for function add_inventory_options
def test_add_inventory_options():
    a = ['1','2']
    b = ['-i','1','-i','2']
    assert add_inventory_options(a) == b


# Generated at 2022-06-20 13:00:38.624538
# Unit test for function add_check_options
def test_add_check_options():
    # Given
    parser = argparse.ArgumentParser()
    # When
    add_check_options(parser)
    # Then
    assert parser is not None



# Generated at 2022-06-20 13:00:44.902866
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(description='description')
    add_verbosity_options(parser)
    arg_list = ['--verbose', '-vvvv']
    adjusted_args = []
    for arg in arg_list:
        if arg == '-vvvv':
            adjusted_arg = "--verbose=4"
        else:
            adjusted_arg = arg
        adjusted_args.append(adjusted_arg)
    parsed_args = parser.parse_args(adjusted_args)
    assert parsed_args.verbosity == 4



# Generated at 2022-06-20 13:00:47.385343
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    p = '~/foo'
    assert p == maybe_unfrack_path('~')(p)
    assert p == maybe_unfrack_path('/')(p)


# Generated at 2022-06-20 13:00:50.428734
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('test', usage="test usage", desc="test desc", epilog="test epi")
    opts, args = parser.parse_known_args()
    assert opts.verbose == 0
    assert opts.version == False 



# Generated at 2022-06-20 13:00:52.737764
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    assert '-f' in parser._actions[0].option_strings



# Generated at 2022-06-20 13:01:01.889238
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from six.moves import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping
    class FakeParser(object):
        def __init__(self):
            self.error = lambda s: None
            self.prog = 'test_prog'
        # Unit test for method __init__ of class FakeParser
        def test___init__():
            assert FakeParser.__init__.__doc__

    # Unit test for method __call__ of class UnrecognizedArgument

# Generated at 2022-06-20 13:01:05.789645
# Unit test for function add_runtask_options
def test_add_runtask_options():
    import argparse

    parser = argparse.ArgumentParser()
    add_runtask_options(parser)

    args = parser.parse_args()

    assert args.extra_vars == []

    args = parser.parse_args([])

    assert args.extra_vars == []



# Generated at 2022-06-20 13:01:16.464680
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.utils.color import stringc
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.pb_runner import PlaybookRunner
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.plugins.callback import CallbackBase
    from ansible.executor import playbook_executor

    class ResultCallback(CallbackBase):
        def __init__(self, *args):
            super(ResultCallback, self).__init__(*args)
            self.status_no_hosts = False
            self.status_no_active_hosts = False


# Generated at 2022-06-20 13:01:18.755752
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args('--foo a --foo b'.split())
    assert args.foo == ['b', 'a']

# end of class AppendListAction



# Generated at 2022-06-20 13:01:21.992289
# Unit test for function add_module_options
def test_add_module_options():
    argv = shlex.split(' -M /path/to/modules')
    parser = argparse.ArgumentParser(prog='ansible-test')
    add_module_options(parser)
    (options, args) = parser.parse_known_args(args=argv)
    assert hasattr(options, 'module_path')
    assert options.module_path == ['/path/to/modules']
