

# Generated at 2022-06-20 12:52:21.545504
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    import argparse
    from collections import namedtuple

    class Parser(object):
        def error(self, obj):
            self.obj = obj

    FakeNamespace = namedtuple('FakeNamespace', 'obj')

    option_strings = '-a --and'
    dest = 'test'

    ua = UnrecognizedArgument(option_strings, dest)

    parser = Parser()
    namespace = FakeNamespace(None)
    values = 0
    option_string = None

    ua(parser, namespace, values, option_string)
    assert parser.obj == 'unrecognized arguments: %s' % option_string


#
# Command Line Argument Processing
#

# Generated at 2022-06-20 12:52:24.197508
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(["--task-timeout", "20"])
    assert args.task_timeout == 20


# Generated at 2022-06-20 12:52:29.060961
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog="test_add_runtask_options")
    add_runtask_options(parser)
    args = parser.parse_args(["-e", "username=abc"])
    assert args.extra_vars == ['username=abc']


# Generated at 2022-06-20 12:52:29.686471
# Unit test for function version
def test_version():
    assert version(__file__) is not None


# Generated at 2022-06-20 12:52:40.950610
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    expected1 = '@/abs/path'
    input1 = '@/abs/path'
    result1 = maybe_unfrack_path('@')(input1)
    assert expected1 == result1

    expected_relative = '@./rel/path'
    input_relative = '@./rel/path'
    result_relative = maybe_unfrack_path('@')(input_relative)
    assert expected_relative == result_relative

    expected_with_beacon = '@/abs/path'
    input_with_beacon = '@@/abs/path'
    result_with_beacon = maybe_unfrack_path('@@')(input_with_beacon)
    assert expected_with_beacon == result_with_beacon


# Generated at 2022-06-20 12:52:45.413599
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    assert parser.get_default('connection') == C.DEFAULT_TRANSPORT



# Generated at 2022-06-20 12:52:49.390509
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(description='Test add_connect_options')
    add_connect_options(parser)
    # test if the function add_connect_options is working
    assert parser.parse_args(['--private-key'])


# Unit tests for function add_check_options

# Generated at 2022-06-20 12:52:56.678052
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    def TestPrependListActionWrapper():
        try:
            PrependListAction(['--foo'], 'bar', None, 'baz')
        except Exception as e:
            raise Exception('PrependListAction init failed with %s' % e)

    # Test calling bad nargs
    try:
        PrependListAction(['--foo'], 'bar', 0)
        raise Exception('PrependListAction nargs must be greater than 0')
    except argparse.ArgumentError:
        pass
    # Test optional nargs with const
    try:
        TestPrependListActionWrapper()
    except Exception as e:
        raise Exception('PrependListAction optional nargs with const failed with %s' % e)



# Generated at 2022-06-20 12:53:07.765075
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    a = argparse.ArgumentParser()
    a.add_argument('-b')
    a.add_argument('-a')
    b = argparse.ArgumentParser()
    b.add_argument('-d')
    b.add_argument('-c')
    c = argparse.ArgumentParser()
    c.add_argument('-f')
    c.add_argument('-e')

    p = SortingHelpFormatter()
    # p._add_action(a)
    # p._add_action(b)
    # p._add_action(c)
    p.add_arguments([a, b, c])
    assert p._action_max_length == 2
    assert p._action_max_length == 2
    assert p._action_max_length == 2



# Generated at 2022-06-20 12:53:12.673573
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = create_base_parser('test_add_basedir_options')
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'test_playbook_dir'])
    assert options.basedir == os.path.abspath('test_playbook_dir')


# Generated at 2022-06-20 12:53:26.617302
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    result = vars(parser.parse_args(['-B 20']))
    assert result['seconds'] == 20
    assert result['poll_interval'] == C.DEFAULT_POLL_INTERVAL



# Generated at 2022-06-20 12:53:33.048584
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    def test_options(option_list, expect_ask_pass=False, expect_become_password_file=None):
        parser = argparse.ArgumentParser()
        add_runas_prompt_options(parser)
        results = parser.parse_args(option_list)
        assert results.become_ask_pass == expect_ask_pass
        assert expect_become_password_file == None or results.become_password_file == expect_become_password_file

    # Test default options
    test_options([])

    # Test --ask-become-pass
    test_options([], expect_ask_pass=True)

    # Test --become-password-file
    test_options([], expect_become_password_file=C.BECOME_PASSWORD_FILE)

    # Test mutually

# Generated at 2022-06-20 12:53:35.902389
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    opts = parser.parse_args(['-t','/tmp'])
    assert vars(opts)['tree'] == '/tmp'


# Generated at 2022-06-20 12:53:40.783979
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.utils.path import get_bin_path
    import subprocess
    value = "{{ test_var }}"
    assert get_bin_path('sh') == unfrack_path()(value)
    assert get_bin_path('sh') == unfrack_path(pathsep=True)(os.pathsep.join([value]))
    assert '-' == unfrack_path()('-')


# Generated at 2022-06-20 12:53:44.623493
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from units.mock.parser_mock import MockParser
    parser = MockParser()
    add_inventory_options(parser)
    assert parser.has_option('-i')
    assert parser.has_option('--inventory')



# Generated at 2022-06-20 12:53:49.116842
# Unit test for function add_vault_options
def test_add_vault_options():
    """Unit test for function add_vault_options"""
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        prog="ansible-doc",
        conflict_handler='resolve',
    )
    add_vault_options(parser)
    args = parser.parse_args(["--vault-password-file", "@prompt:"], namespace=argparse.Namespace())
    print(args)
    assert args.vault_password_files == ['@prompt:']
# test_add_vault_options()

# Generated at 2022-06-20 12:53:59.812602
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    testargs = ["-v", "-v", "-v", "test1", "test2", "test3", "test4", "test5"]
    rv = PrependListAction(option_strings=["-v"],
                           dest="verbose",
                           nargs="*",
                           const=None,
                           default=None,
                           type=None,
                           choices=None,
                           required=False,
                           help=None,
                           metavar=None)(
        parser = argparse.ArgumentParser(),
        namespace = argparse.Namespace(),
        values = testargs[1:],
        option_string = "-v")
    assert isinstance(rv, PrependListAction)


#
# Functions used by parsers
#


# Generated at 2022-06-20 12:54:04.145224
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args("-b --become-user testuser".split())

    assert options.become == True
    assert options.become_user == 'testuser'



# Generated at 2022-06-20 12:54:07.859122
# Unit test for function add_fork_options
def test_add_fork_options():
    # Verify that the default value for 'forks' is used if not passed in to the parser
    options = argparse.Namespace()
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    parser.parse_args(args=[], namespace=options)
    assert options.forks == C.DEFAULT_FORKS
    # Verify that the default value for 'forks' can be overridden via the parser
    options = argparse.Namespace()
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    parser.parse_args(args=['--forks=1'], namespace=options)
    assert options.forks == 1



# Generated at 2022-06-20 12:54:09.195570
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    opts = parser.parse_args()
    assert opts.forks == C.DEFAULT_FORKS



# Generated at 2022-06-20 12:54:39.410443
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert "--task-timeout" in parser.format_help()
# enable unit test for function add_tasknoplay_options
test_add_tasknoplay_options()


# Generated at 2022-06-20 12:54:45.215686
# Unit test for function ensure_value
def test_ensure_value():
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('--test', action='store_true')
    test_ns = test_parser.parse_args([])
    # Test default
    assert ensure_value(test_ns, 'test', False) == False
    # Test existing
    test_ns = test_parser.parse_args(['--test'])
    assert ensure_value(test_ns, 'test', False) == True


# Generated at 2022-06-20 12:54:51.139593
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.cli import CLI
    parser=CLI.base_parser(constants=C)
    parser.add_argument('--version', '-v', action=AnsibleVersion, version=__version__)
    pargs = parser.parse_known_args(['--version'])


#
# Function to create a base parser for ansible cli tools
#

# Generated at 2022-06-20 12:54:54.828758
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    av = AnsibleVersion(option_strings=[], dest=None, nargs=0, const=None, default=None, type=None, choices=None, help=None, metavar=None)
    assert isinstance(av, AnsibleVersion)



# Generated at 2022-06-20 12:54:59.781046
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = Mock()
    add_tasknoplay_options(parser)
    parser.add_argument.assert_called_once_with('--task-timeout', type=int, dest='task_timeout', action='store', default=C.TASK_TIMEOUT,
                        help='set task timeout limit in seconds, must be positive integer.')


# Generated at 2022-06-20 12:55:09.361086
# Unit test for function add_module_options
def test_add_module_options():
    parser=argparse.ArgumentParser()
    add_module_options(parser)
    option_list=[
            ['-M', '--module-path',
                'prepend colon-separated path(s) to module library (default=%s)' % C.DEFAULT_MODULE_PATH,
                'type=unfrack_path(pathsep=True), action=PrependListAction'
            ]
            ]
    #Check if the options add in function add_module_options are correct

# Generated at 2022-06-20 12:55:16.521237
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(description='A test parser', formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', '--beta', help='Beta argument')
    parser.add_argument('-a', '--alpha', help='Alpha argument')
    # Test output of the sorted help message
    example = '[-a|--alpha ALPHA] [-b|--beta BETA]\n'
    assert parser.format_help() == example



# Generated at 2022-06-20 12:55:23.757720
# Unit test for function add_inventory_options
def test_add_inventory_options():
    """
    Adds options for commands that utilize inventory
    """
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    group = parser._action_groups[-1]
    test_inv_option = group._group_actions[0]
    test_list_option = group._group_actions[1]
    test_limit_option = group._group_actions[2]
    assert test_inv_option.dest == 'inventory'
    assert test_list_option.dest == 'listhosts'
    assert test_limit_option.dest == 'subset'


# Generated at 2022-06-20 12:55:30.071364
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    class FakeParser(object):
        def __init__(self):
            self.options = []

        def add_argument(self, *args, **kwargs):
            self.options.append((args, kwargs))

    parser = FakeParser()
    add_verbosity_options(parser)
    assert(len(parser.options) == 1)
    args, kwargs = parser.options[0]
    assert(args == ('-v', '--verbose'))
    assert(kwargs == {'action': 'count', 'default': 0, 'dest': 'verbosity',
                      'help': 'verbose mode (-vvv for more, -vvvv to enable connection debugging)'})
# Unit test ends


# Generated at 2022-06-20 12:55:39.833895
# Unit test for function add_basedir_options
def test_add_basedir_options():
    # create parser
    parser = create_base_parser('test', usage='test')
    add_basedir_options(parser)
    opts = parser.parse_args([])
    assert opts.basedir == C.DEFAULT_PLAYBOOK_DIR
    assert unfrackpath(opts.basedir) == C.DEFAULT_PLAYBOOK_DIR
    opts = parser.parse_args(['--playbook-dir', '/not/a/default'])
    assert opts.basedir == '/not/a/default', opts.basedir
    assert unfrackpath(opts.basedir) == '/not/a/default'


# Generated at 2022-06-20 12:55:53.552812
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    with patch.object(parser, 'add_argument', new=my_add_argument):
        add_meta_options(parser)
        assert my_add_argument.call_args_list[0][0] == ('--force-handlers',)
        assert my_add_argument.call_args_list[1][0] == ('--flush-cache',)

# Generated at 2022-06-20 12:55:56.206687
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, nargs=1)


# Generated at 2022-06-20 12:55:59.753624
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()
    add_inventory_options(parser)
    args = []
    for call in parser.method_calls:
        if call[0] == 'add_argument':
            args.append(call[1][0])
    assert args == ['-i',
                    '--inventory',
                    '--inventory-file',
                    '--list-hosts',
                    '-l',
                    '--limit']



# Generated at 2022-06-20 12:56:02.314945
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    opt = add_runas_prompt_options(parser)
    assert_equal(opt, parser)



# Generated at 2022-06-20 12:56:08.477334
# Unit test for function create_base_parser
def test_create_base_parser():
    option = create_base_parser('argparse', usage='usage', desc='desc', epilog='epilog')
    assert option.prog == 'argparse'
    assert option.usage == 'usage'
    assert option.description == 'desc'
    assert option.epilog == 'epilog'
    assert option.formatter_class == SortingHelpFormatter
    assert option.conflict_handler == 'resolve'



# Generated at 2022-06-20 12:56:19.366345
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    parser = create_base_parser('test', 'test desc')
    add_connect_options(parser)

# Generated at 2022-06-20 12:56:23.127620
# Unit test for function add_basedir_options
def test_add_basedir_options():
    import tempfile
    parser = create_base_parser()
    add_basedir_options(parser)
    basedir = tempfile.mkdtemp()
    args = parser.parse_args(['--playbook-dir', basedir])
    assert args.basedir == basedir
    os.rmdir(basedir)



# Generated at 2022-06-20 12:56:28.768237
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    sys.argv.append("-v")
    parser = create_base_parser("test")
    assert(parser.parse_args().verbosity == 1)
    sys.argv.append("-vvvv")
    parser = create_base_parser("test")
    assert(parser.parse_args().verbosity == 4)
test_add_verbosity_options()



# Generated at 2022-06-20 12:56:34.972101
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog='ansible-doc',
        formatter_class=SortingHelpFormatter,
        description="Show ansible docs",
        conflict_handler='resolve',
    )
    add_verbosity_options(parser)
    add_basedir_options(parser)
    args = parser.parse_args(args=['--playbook-dir', 'k'])
    print(args.basedir)



# Generated at 2022-06-20 12:56:41.720856
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test1', '--vault-id', 'test2'])
    assert options.vault_ids == ['test1', 'test2']


#
# Functions to extract options from an OptionParser into a Settings instance
#


# Generated at 2022-06-20 12:56:54.267013
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert parser._actions[0].dest == 'verbosity'
    assert parser._actions[0].default == C.DEFAULT_VERBOSITY


# Generated at 2022-06-20 12:57:05.073989
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    test_case = [
        {
            "message": "SortingHelpFormatter.add_arguments failed",
            "argv": "--type test --action install --extra-vars environment=test",
            "expected": "--action install --extra-vars environment=test --type test"
        },
        {
            "message": "SortingHelpFormatter.add_arguments failed",
            "argv": "--extra-vars environment=test --type test --action install",
            "expected": "--action install --extra-vars environment=test --type test"
        },
    ]
    action = argparse.Action(option_strings=['--type'], dest='type')
    argument_parser = SortingHelpFormatter()
    exit_code = []

# Generated at 2022-06-20 12:57:06.968211
# Unit test for function add_subset_options
def test_add_subset_options():
    myparser = argparse.ArgumentParser()
    add_subset_options(myparser)
    myresult = myparser.parse_args(["--tags", "test1", "--skip-tags", "test2"])
    print(myresult)

# Generated at 2022-06-20 12:57:09.468350
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    argument_parser = argparse.ArgumentParser(
        description='test',
        formatter_class=SortingHelpFormatter
    )
    argument_parser.add_argument('--apple')
    argument_parser.add_argument('-b', '--banana')
    argument_parser.add_argument('-bacon')

    argument_parser.print_help()


# Generated at 2022-06-20 12:57:13.332929
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(["-t", "hi", "--tags=mom", "--skip-tags=bad", "--skip-tags=ugly"])
    assert options.tags == ['hi', 'mom']
    assert options.skip_tags == ['bad', 'ugly']

# Generated at 2022-06-20 12:57:14.909523
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.parse_args(args=[])
    assert parser.exit()



# Generated at 2022-06-20 12:57:16.726494
# Unit test for function add_runtask_options
def test_add_runtask_options():
    import argparse
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    return parser


# Generated at 2022-06-20 12:57:23.139827
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = add_runas_options(argparse.ArgumentParser(formatter_class=SortingHelpFormatter))
    arguments = ['-b', '--become-method', 'su', '--become-user', 'alice']
    args = parser.parse_args(arguments)
    assert(args.become is True)
    assert(args.become_method == 'su')
    assert(args.become_user == 'alice')


# Generated at 2022-06-20 12:57:28.500184
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(['-t', "test1", '-t', "test2", '--skip-tags', "test3", '--skip-tags', "test4"])
    assert options.tags == ["test1", "test2"]
    assert options.skip_tags == ["test3", "test4"]

# Generated at 2022-06-20 12:57:32.650580
# Unit test for function add_runtask_options
def test_add_runtask_options():

    class MockOptionParser(object):
        pass

    option_parser = MockOptionParser()
    option_parser.add_argument = Mock()
    add_runtask_options(option_parser)
    assert option_parser.add_argument.call_count == 2



# Generated at 2022-06-20 12:57:51.050313
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)

    # Check default
    args = parser.parse_args([])
    assert args.task_timeout == C.TASK_TIMEOUT

    # Check for value
    args = parser.parse_args(['--task-timeout', '3'])
    assert args.task_timeout == 3



# Generated at 2022-06-20 12:57:51.644875
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-20 12:57:53.463330
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    parser_args = parser.parse_args()
    assert parser_args.verbosity == 0
    assert parser_args.verbosity == C.DEFAULT_VERBOSITY


# Generated at 2022-06-20 12:57:56.997589
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()

    try:
        add_tasknoplay_options(parser)
    except SystemExit:
        pytest.fail("add_tasknoplay_options() called argparse.exit()")


# Generated at 2022-06-20 12:58:00.010312
# Unit test for function ensure_value
def test_ensure_value():
    class namespace(object):
        pass
    n = namespace
    ensure_value(n, 'foo', 'bar')
    assert n.foo == 'bar'
    ensure_value(n, 'foo', 'not bar')
    assert n.foo == 'bar'



# Generated at 2022-06-20 12:58:10.596269
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class Mock(object):
        pass

    args = Mock()
    args.foo = None

    opt = argparse.Namespace()
    opt.foo = [1, 2, 3]
    opt.bar = None
    opt.baz = None

    pa = PrependListAction(['-f', '--foo'], 'foo')
    pa(None, opt, [4, 5], None)
    assert opt.foo == [4, 5, 1, 2, 3]

    pa = PrependListAction(['-b', '--bar'], 'bar')
    pa(None, opt, [4, 5], None)
    assert opt.foo == [4, 5, 1, 2, 3]
    assert opt.bar == [4, 5]


# Generated at 2022-06-20 12:58:17.460643
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('ansible-doc')
    add_runas_options(parser)
    # FIXME: This test is still a bit lame.  It just checks that we don't crash.
    args = parser.parse_args('--private-key=host_key --become-method=sudo'.split())
    assert args.private_key_file == 'host_key'
    assert args.become_method == 'sudo'


# Generated at 2022-06-20 12:58:21.770367
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible',
                                     formatter_class=SortingHelpFormatter)
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir','test_dir'])
    assert args.basedir == 'test_dir'


# Generated at 2022-06-20 12:58:32.092648
# Unit test for function create_base_parser
def test_create_base_parser():
    prog = 'ansible'
    usage = 'usage: ansible <host-pattern> [options]'
    desc = 'Ansible is a radically simple IT automation platform that makes your applications and systems easier to deploy.'
    epilog = 'By default, Ansible processes playbooks and modules synchronously. This can be changed by using the serial inventory keyword.'
    base_parser = create_base_parser(prog, usage, desc, epilog)
    assert base_parser is not None
    assert base_parser.prog == prog
    assert base_parser.epilog == epilog
    assert base_parser.description == desc


# Generated at 2022-06-20 12:58:36.770964
# Unit test for function add_basedir_options
def test_add_basedir_options():
    p = argparse.ArgumentParser(epilog='some-epilog',
                                prog='some-prog',
                                usage='some-usage')
    add_basedir_options(p)
    opts = p.parse_args(['--playbook-dir', 'some-basedir'])
    assert opts.basedir == unfrackpath('some-basedir')



# Generated at 2022-06-20 12:59:06.222932
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')

    help_text = parser.format_help()
    assert help_text.index('--bar') < help_text.index('--baz')
    assert help_text.index('--baz') < help_text.index('--foo')



# Generated at 2022-06-20 12:59:12.223120
# Unit test for function add_fork_options
def test_add_fork_options():
    """
    Test function add_fork_options, this will only check if default value is the same with the configuration file
    """
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS



# Generated at 2022-06-20 12:59:15.408519
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', action=UnrecognizedArgument)
    assert parser.parse_args(['-s', 'a value']) is None



# Generated at 2022-06-20 12:59:16.424149
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    return parser


# Generated at 2022-06-20 12:59:17.118048
# Unit test for function add_inventory_options
def test_add_inventory_options():
    pass

# Generated at 2022-06-20 12:59:22.991277
# Unit test for function add_runtask_options
def test_add_runtask_options():

    parser = argparse.ArgumentParser(
        prog='ansible-cmdb',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description='Test',
        conflict_handler='resolve',
    )
    add_runtask_options(parser)
    try:
        parser.parse_args('-e "key=value" -e "@/data.yml"'.split())
    except SystemExit:
        assert False

    return True

if __name__ == '__main__':
    test_add_runtask_options()



# Generated at 2022-06-20 12:59:27.062570
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['--module-path=test:test2'])
    assert options.module_path == ['test', 'test2']
    options = parser.parse_args([])
    assert options.module_path == None



# Generated at 2022-06-20 12:59:34.099497
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args("-i inventory -i inventory2 --list-hosts -l localhost".split())
    assert args.inventory[0] == 'inventory'
    assert args.inventory[1] == 'inventory2'
    assert args.listhosts is True
    assert args.subset == 'localhost'
# END Unit test for function add_inventory_options


# Generated at 2022-06-20 12:59:45.689530
# Unit test for method __call__ of class UnrecognizedArgument

# Generated at 2022-06-20 12:59:50.025833
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_output_options(parser)
    options = parser.parse_args(['--one-line', '--tree', '~/random'])
    assert options.one_line is True
    assert options.tree == '~/random'


# Generated at 2022-06-20 13:00:09.989359
# Unit test for function add_runas_options
def test_add_runas_options():
    # creating a parser
    parser = argparse.ArgumentParser()
    parser.add_argument = MagicMock()
    args = ["-b", "--become", "--become-method", "--become-user"]
    kwargs = [{'dest': 'become', "default": C.DEFAULT_BECOME, "action": "store_true"}] * 2 + [{"dest": "become_method", "default": C.DEFAULT_BECOME_METHOD},
                                                                                              {"dest": "become_user", "default": C.DEFAULT_BECOME_USER}]
    # calling add_runas_options
    add_runas_options(parser)
    # checking number of calls and the arguments passed

# Generated at 2022-06-20 13:00:11.962890
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('foo')
    check_version_option(parser)



# Generated at 2022-06-20 13:00:14.586015
# Unit test for function add_output_options
def test_add_output_options():
    parser = Parser()
    add_output_options(parser)
    (options, args) = parser.parse_args(['-t','tmp'])
    assert options.tree == 'tmp'


# Generated at 2022-06-20 13:00:26.087956
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(['-c', 'gce', '-u', 'root', '--private-key', '~/.ssh/id_rsa'])
    assert options.remote_user == 'root'
    assert options.private_key_file == '~/.ssh/id_rsa'
    assert options.connection == 'gce'
    # Validate default values
    assert options.timeout == C.DEFAULT_TIMEOUT
    assert options.ssh_common_args == None
    assert options.sftp_extra_args == None
    assert options.scp_extra_args == None
    assert options.ssh_extra_args == None
    assert not options.ask_pass
    assert options.connection_password_file == C

# Generated at 2022-06-20 13:00:30.188285
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    action = AnsibleVersion(option_strings='--version')
    with open('testdata/module_utils/common/argparse/__call__.txt', 'r') as ifile:
        expected_result = ifile.read()
    result = action(parser, None, None)
    assert expected_result == result



# Generated at 2022-06-20 13:00:34.796505
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(["-P 5", "-B 3"])
    assert args.poll_interval == 5
    assert args.seconds == 3



# Generated at 2022-06-20 13:00:39.919525
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    test_pass = True
    try:
        options, args = parser.parse_known_args(['-e', '@file'])
        test_pass = options.extra_vars[0] == '@file' 
    except:
        test_pass = False 
    finally:
        return test_pass


# Generated at 2022-06-20 13:00:47.386000
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store', help='1')
    parser.add_argument('-c', action='store', help='2')
    parser.add_argument('-a', action='store', help='3')
    parser.add_argument('-d', action='store', help='4')
    help = parser.format_help()
    assert help.index('-a') < help.index('-b')
    assert help.index('-b') < help.index('-c')
    assert help.index('-c') < help.index('-d')



# Generated at 2022-06-20 13:00:53.893943
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    opts = parser.parse_args([])
    for option in ["tags", "skip_tags"]:
        assert getattr(opts, option) == C.TAGS_RUN, \
            "add_subset_options fails to set default value for option %s" % option
    text = "only run plays and tasks tagged with these values"
    assert text in parser._option_string_actions['-t'].help, \
        "add_subset_options fails to set help message for option -t"
    assert text in parser._option_string_actions['--tags'].help, \
        "add_subset_options fails to set help message for option --tags"

# Generated at 2022-06-20 13:00:56.151556
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser("test")
    add_verbosity_options(parser)
    assert 'verbosity' in parser._defaults



# Generated at 2022-06-20 13:01:12.167479
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
# End unit test for function add_check_options



# Generated at 2022-06-20 13:01:13.903237
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options, args = parser.parse_known_args()
    assert options.forks == C.DEFAULT_FORKS
    assert args == []



# Generated at 2022-06-20 13:01:18.839507
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args('')
    assert args.foo is None
    ensure_value(args, 'foo', 1)
    assert args.foo == 1
    args = parser.parse_args('--foo 2'.split())
    assert args.foo == [2]
    ensure_value(args, 'foo', 1)
    assert args.foo == [1]



# Generated at 2022-06-20 13:01:22.241764
# Unit test for function create_base_parser
def test_create_base_parser():
    # Just test that none of the options raise exceptions
    parser = create_base_parser('ansible-console', usage="usage")
    parser.parse_args(['-v', '-v', '-v'])
    parser.parse_args(['-v', '-v'])
    parser.parse_args(['-v'])
    parser.parse_args([])
    parser.parse_args(['--version'])


# Generated at 2022-06-20 13:01:30.384521
# Unit test for function ensure_value
def test_ensure_value():
    import unittest
    import argparse

    class TestEnsureValue(unittest.TestCase):
        def setUp(self):
            self.parser = argparse.ArgumentParser()

        def test_ensure_value(self):
            self.parser.add_argument('--foo')
            self.parser.parse_args(args=[], namespace=argparse.Namespace())
            self.assertEqual(None, self.parser.parse_args().foo)
            ensure_value(self.parser.parse_args(), 'foo', [])
            self.assertEqual([], self.parser.parse_args().foo)
            self.parser.parse_args(args=['--foo', 'bar'], namespace=argparse.Namespace())
            ensure_value(self.parser.parse_args(), 'foo', [])
           

# Generated at 2022-06-20 13:01:34.503008
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('/tmp/foo') == '/tmp/foo'


# Generated at 2022-06-20 13:01:42.273690
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, default=[])

    parser.parse_args(['--foo', 'bar'])
    assert parser.parse_args(['--foo', 'bar']).foo == ['bar']

    parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert parser.parse_args(['--foo', 'bar', '--foo', 'baz']).foo == ['bar', 'baz']

    parser.parse_args(['--foo', 'bar'])
    assert parser.parse_args(['--foo', 'bar']).foo == ['bar']

    parser.parse_args([])
    assert parser.parse_args([]).foo == []

