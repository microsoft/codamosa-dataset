

# Generated at 2022-06-20 12:52:06.919280
# Unit test for function add_meta_options
def test_add_meta_options():
    module = mock.MagicMock()
    add_meta_options(module)

    module.add_argument.assert_any_call(
        '--force-handlers',
        action='store_true',
        dest='force_handlers',
        default=C.DEFAULT_FORCE_HANDLERS,
        help='run handlers even if a task fails'
    )

    module.add_argument.assert_any_call(
        '--flush-cache',
        action='store_true',
        dest='flush_cache',
        help='clear the fact cache for every host in inventory'
    )



# Generated at 2022-06-20 12:52:09.388285
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    argv = ['--connection-password-file', './test/unit/utils/test_connection_password_file']
    args = parser.parse_args(argv)
    assert args.connection_password_file == './test/unit/utils/test_connection_password_file'



# Generated at 2022-06-20 12:52:14.940691
# Unit test for function add_runas_options
def test_add_runas_options():
    test_parser = argparse.ArgumentParser()
    add_runas_options(test_parser)
    # test defaults
    assert test_parser.parse_args([]).become == C.DEFAULT_BECOME
    assert test_parser.parse_args([]).become_method == C.DEFAULT_BECOME_METHOD
    assert test_parser.parse_args([]).become_user == C.DEFAULT_BECOME_USER
    # test short option
    assert test_parser.parse_args(['-b']).become == True
    # test long option
    assert test_parser.parse_args(['--become']).become == True
    assert test_parser.parse_args(['--become-user=meng.zhou']).become_user == 'meng.zhou'


# Generated at 2022-06-20 12:52:18.788372
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ''' Unit test for constructor of class AnsibleVersion '''

    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)



# Generated at 2022-06-20 12:52:28.288972
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b', '-u', 'testuser', '--ask-become-pass', '-K','-k', '-B'])
    assert args.become
    assert args.become_user == 'testuser'
    assert args.ask_become_pass
    assert args.ask_pass
    assert args.become_ask_pass_msg



# Generated at 2022-06-20 12:52:32.901485
# Unit test for function add_subset_options
def test_add_subset_options():
    # Create parser with add_subset_options
    parser = create_base_parser('test_add_subset_options')
    add_subset_options(parser)
    # Test parser function
    result = parser.parse_args(['-t', 'tag1', '--tags', 'tag2', '--skip-tags', 'tag3', '--skip-tags', 'tag4'])
    assert result.tags == ['tag1', 'tag2']
    assert result.skip_tags == ['tag3', 'tag4']
    # Test parser help message
    result = parser.parse_args(['--help'])


# Generated at 2022-06-20 12:52:34.943254
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args()
    assert args.vault_ids == []
    assert args.ask_vault_pass == C.DEFAULT_ASK_VAULT_PASS
    assert args.vault_password_files is None



# Generated at 2022-06-20 12:52:46.202590
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    '''
    Test a simple constructor for the class SortingHelpFormatter
    '''
    parser = SortingHelpFormatter()
    # There are some errors if we have no actions
    parser.add_argument('-f', '--foo', default=None, action='store_true', help='foo help')
    parser.add_argument('-b', '--bar', default=None, action='store_true', help='bar help')
    parser.add_argument('-z', '--baz', default=None, action='store_true', help='baz help')
    parser.parse_args(['-f', '-b', '-z'])


# Generated at 2022-06-20 12:52:53.076967
# Unit test for function add_inventory_options
def test_add_inventory_options():
    import ansible.cli.argparse as argparse
    parser = argparse.base_parser('')
    argparse.add_inventory_options(parser)
    options = parser.parse_args(['-i', 'test.ini', '--list-hosts', '-l', 'all'])
    assert options.inventory[0] == 'test.ini'
    assert options.listhosts is True
    assert options.subset == 'all'
# done function add_inventory_options unit test



# Generated at 2022-06-20 12:53:05.060572
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # By default, inventory is None
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_inventory_options(parser)
    options = parser.parse_args([])
    assert not options.inventory

    # Single inventory item, should be a list
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'foo'])
    assert options.inventory == ['foo']

    # Multiple inventory items, should be a list
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'foo', '--inventory', 'bar'])
   

# Generated at 2022-06-20 12:53:22.400984
# Unit test for function add_async_options
def test_add_async_options():
    parser = create_base_parser('test', 'Testing argument check')
    add_async_options(parser)
    args = parser.parse_args(['-P', '500', '-B', '600'])
    assert args.poll_interval == '500'
    assert args.seconds == '600'



# Generated at 2022-06-20 12:53:25.198280
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['--forks', '5'])
    assert args.forks == 5



# Generated at 2022-06-20 12:53:28.821067
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    assert len(parser._actions) == 0
    add_runas_options(parser)
    assert len(parser._actions) == 4
    # add_runas_options includes add_runas_prompt_options
    assert len([action for action in parser._actions if action.dest == 'ask_become_pass']) == 1
    assert len([action for action in parser._actions if action.dest == 'ask_pass']) == 1



# Generated at 2022-06-20 12:53:36.834346
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from ansible.cli.arguments import base_parser
    parser = argparse.ArgumentParser(description='description', formatter_class=SortingHelpFormatter)
    parser.add_argument('--version', action='version', version=__version__)
    base_parser(parser)
    output = parser.format_help()
    # Make sure --version is the first option
    assert output.startswith('usage: ')
    assert '--version' in output.split('\n', 1)[1]



# Generated at 2022-06-20 12:53:42.483396
# Unit test for function add_inventory_options
def test_add_inventory_options():

    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args([])
    assert options.inventory is None
    assert not options.listhosts
    assert options.subset == C.DEFAULT_SUBSET

    # This is just a smoke test, their are better unit tests for the OptionParser
    options = parser.parse_args(['-i', 'foo', '-l', 'bar'])
    assert options.inventory == ['foo']
    assert not options.listhosts
    assert options.subset == 'bar'

    options = parser.parse_args(['--inventory', 'foo', '--limit', 'bar'])
    assert options.inventory == ['foo']
    assert not options.listhosts
    assert options.subset == 'bar'


# Generated at 2022-06-20 12:53:47.106542
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)

# Unit test to check that option -P with invalid value throws an error

# Generated at 2022-06-20 12:53:49.703053
# Unit test for function add_module_options
def test_add_module_options():
   parser = argparse.ArgumentParser()
   add_module_options(parser)
   
   data = """
-M /usr/share/ansible/modules -M /usr/share/ansible/plugins/modules

   """
   sys.argv = data.split()
   args = parser.parse_args()
   assert args.module_path == ["/usr/share/ansible/plugins/modules", "/usr/share/ansible/modules"]



# Generated at 2022-06-20 12:53:55.466747
# Unit test for function add_basedir_options
def test_add_basedir_options():
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    test_parser = argparse.ArgumentParser()
    add_basedir_options(test_parser)
    args = test_parser.parse_args(['--playbook-dir', basedir])
    assert args.basedir == basedir



# Generated at 2022-06-20 12:54:03.980654
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description='description',
        epilog='epilog', formatter_class=SortingHelpFormatter)
    parser.add_argument('--x', help='x')
    parser.add_argument('--y', help='y')
    parser.add_argument('--abcd', help='abcd')
    expected_lines = [
        'usage: [-h] [--abcd ABCD] [--x X] [--y Y]',
        '',
        'description',
        '',
        'optional arguments:',
        '  -h, --help  show this help message and exit',
        '  --abcd ABCD',
        '  --x X',
        '  --y Y',
        '',
        'epilog',
    ]
    output = parser.format

# Generated at 2022-06-20 12:54:09.056670
# Unit test for function add_vault_options
def test_add_vault_options():
    options1, _ = create_parser().parse_known_args(['--vault-password-file=/foo/bar'])
    assert options1.vault_password_files == ['/foo/bar']
    options2, _ = create_parser().parse_known_args(['--vault-password-file=/foo/bar', '--vault-password-file=/foo/bar2'])
    assert options2.vault_password_files == ['/foo/bar', '/foo/bar2']
    options3, _ = create_parser().parse_known_args(['--vault-password-file=/tmp/does_not_exist'])
    assert options3.vault_password_files == ['/tmp/does_not_exist']

# Generated at 2022-06-20 12:54:28.718690
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    results = parser.parse_args([])
    assert results.extra_vars == []
    results = parser.parse_args(['-e', '@/tmp/data.yml'])
    assert results.extra_vars == ['/tmp/data.yml']
    results = parser.parse_args(['-e', '@/tmp/data.yml', '-e', '@/tmp/data.json'])
    assert results.extra_vars == ['/tmp/data.yml', '/tmp/data.json']



# Generated at 2022-06-20 12:54:33.235220
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog='ansible')
    assert parser.prog == 'ansible'
    add_verbosity_options(parser)
    parser.parse_args(['--verbose'])
    with pytest.raises(SystemExit):
        parser.parse_args(['--version'])
    assert parser.prog == 'ansible'

# Generated at 2022-06-20 12:54:40.421751
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser("test_add_runas_prompt_options")
    add_runas_prompt_options(parser)

    args = parser.parse_args("--become-password-file=become_password_file")
    assert args.become_password_file == "become_password_file"

    args = parser.parse_args("-K")
    assert args.become_ask_pass



# Generated at 2022-06-20 12:54:43.051133
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', action=UnrecognizedArgument)
    try:
        parser.parse_args('-b'.split())
    except SystemExit as e:
        assert e.code == 2


#
# Options parsers for commands that must implement 'version' and 'help'
#

# Generated at 2022-06-20 12:54:48.593802
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    usage_msg = """\
usage: prog [-h] [--foo FOO] [--bar BAR]

optional arguments:
  -h, --help     show this help message and exit
  --foo FOO
  --bar BAR\
"""
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='foo')
    parser.add_argument('--bar', default='bar')
    parser.formatter_class = SortingHelpFormatter

    output = parser.format_help()
    assert output == usage_msg


# Generated at 2022-06-20 12:55:00.702557
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    assert parser.get_default('private_key_file') == C.DEFAULT_PRIVATE_KEY_FILE
    assert parser.get_default('remote_user') == C.DEFAULT_REMOTE_USER
    assert parser.get_default('connection') == C.DEFAULT_TRANSPORT
    assert parser.get_default('timeout') == C.DEFAULT_TIMEOUT
    assert parser.get_default("ssh_common_args") is None
    assert parser.get_default("sftp_extra_args") is None
    assert parser.get_default("scp_extra_args") is None
    assert parser.get_default("ssh_extra_args") is None
    assert parser.get_default('ask_pass') == C.DE

# Generated at 2022-06-20 12:55:04.978970
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    n = Namespace()
    testval = 'testval'
    ensure_value(n, 'test', testval)
    assert(n.test == testval)
    assert(ensure_value(n, 'test', testval) is n.test)



# Generated at 2022-06-20 12:55:09.605907
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check
    args = parser.parse_args(['--syntax-check'])
    assert args.syntax
    args = parser.parse_args(['--diff'])
    assert args.diff



# Generated at 2022-06-20 12:55:16.831227
# Unit test for function ensure_value
def test_ensure_value():
    class namespace:
        pass
    namespace.test = None
    assert ensure_value(namespace, 'test', 3) == 3
    assert namespace.test == 3
    namespace.test = None
    assert ensure_value(namespace, 'test', None) is None
    assert namespace.test is None
    namespace.test = None
    assert ensure_value(namespace, 'test', []) == []
    assert namespace.test == []

# Unit tests for class PrependListAction

# Generated at 2022-06-20 12:55:19.734874
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    utp = add_tasknoplay_options("some_task_object")
    assert utp == "some_task_object"
#/Unit test for function add_tasknoplay_options


# Generated at 2022-06-20 12:55:25.437930
# Unit test for function add_inventory_options
def test_add_inventory_options():
    pass



# Generated at 2022-06-20 12:55:33.242581
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        prog="none"
    )
    verbosity_options = {
        dest:'verbosity',
        default:C.DEFAULT_VERBOSITY,
        action:'count',
        help:'verbose mode (-vvv for more, -vvvv to enable connection debugging)'
    }
    add_verbosity_options(parser)
    if isinstance(parser.action,object):
        assert True
    else:
        assert False


# Generated at 2022-06-20 12:55:38.119879
# Unit test for function add_basedir_options
def test_add_basedir_options():
    # Testing the not default value
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options, args = parser.parse_known_args(['--playbook-dir', 'my_new_directory'])
    assert options.basedir == 'my_new_directory'



# Generated at 2022-06-20 12:55:49.338928
# Unit test for function add_output_options
def test_add_output_options():
    # create a parser
    parser = create_base_parser('test', 'test desc', 'test epilog')

    # add options to it
    add_output_options(parser)

    # create expected help output
    base_help = 'usage: test [-h] [-v] [--version] [-o] [-t TREE]\n\n'
    version_help = 'show program\'s version number, config file location, configured module search path,' \
                   ' module location, executable location and exit'
    version_epilog = '  home = %s\n' % ':'.join(C.COLLECTIONS_PATHS)
    base_epilog = 'test epilog\n\n'
    base_desc = 'test desc\n\n'

    # test help output
    expected_help = base_help

# Generated at 2022-06-20 12:55:53.515403
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    results = parser.parse_args(['--task-timeout', '5'])
    assert results.task_timeout == 5
    results = parser.parse_args([])
    assert results.task_timeout == C.TASK_TIMEOUT


# Generated at 2022-06-20 12:55:59.672250
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    '''
    Unit test for function add_tasknoplay_options
    :return:
    '''
    parser = argparse.ArgumentParser(prog='test_ansible_module')
    add_tasknoplay_options(parser)
    opts = parser.parse_args(['--task-timeout', '10'])
    assert opts.task_timeout == 10



# Generated at 2022-06-20 12:56:01.467529
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)


# Generated at 2022-06-20 12:56:06.331783
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ap = argparse.ArgumentParser(description='Test')
    ap.add_argument('--version', type=None, help='Show version information and exit', action=AnsibleVersion)
    # AnsibleVersion requires no parameters in constructor
    args = ap.parse_args(args=['--version'])
    assert args



# Generated at 2022-06-20 12:56:10.419679
# Unit test for function add_basedir_options
def test_add_basedir_options():

    """ Unit test for function add_basedir_options """

    parser = argparse.ArgumentParser(prog='ansible')
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', 'test'])
    assert options.basedir == 'test'



# Generated at 2022-06-20 12:56:16.431000
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args=parser.parse_args([])
    assert args.module_path == None
    args=parser.parse_args(['-M','path1','path2','path3'])
    assert args.module_path == ['path1', 'path2', 'path3']


# Generated at 2022-06-20 12:56:25.887082
# Unit test for function add_check_options
def test_add_check_options():
    test_parser = argparse.ArgumentParser()
    add_check_options(test_parser)
    args = test_parser.parse_args('-C -D --syntax-check'.split())

    assert args.check
    assert args.diff
    assert args.syntax


# Generated at 2022-06-20 12:56:29.470635
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    try:
        a = AnsibleVersion(None, '-v')
        assert a is not None
        assert isinstance(a, AnsibleVersion)
    except Exception:
        print("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-20 12:56:41.357320
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from unittest.mock import patch
    import io
    import sys

    arge = argparse.ArgumentError('', '')
    argp = argparse.ArgumentParser()
    argp._actions.append(AnsibleVersion('--version'))
    argp_exit = argp.exit
    args = []

    with patch.object(io, 'StringIO', io.StringIO) as mock_stringio:
        with patch.object(argp, 'exit') as mock_exit:
            with patch.object(sys, 'stdout', mock_stringio()) as mock_stdout:
                try:
                    argp.print_help()
                except argparse.ArgumentError:
                    assert True


# Generated at 2022-06-20 12:56:47.475239
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser(prog='')
    parser.add_argument('--help', action='help', help='show this help message and exit')
    args = parser.parse_args(['-v'])
    assert args.verbosity == 1
    args = parser.parse_args(['-vv'])
    assert args.verbosity == 2
    args = parser.parse_args(['-vvv'])
    assert args.verbosity == 3
    args = parser.parse_args(['-vvvv'])
    assert args.verbosity == 4
    args = parser.parse_args('-vvv --help'.split())
    assert args.verbosity == 3



# Generated at 2022-06-20 12:56:53.380896
# Unit test for function add_connect_options
def test_add_connect_options():
    """Function test_add_connect_options()"""
    parser = argparse.ArgumentParser(usage='%(prog)s [options]', formatter_class=SortingHelpFormatter)
    add_connect_options(parser)
    parser.print_help()
    assert parser.parse_args(['-u', 'root', '-c', 'local', '--private-key', '/tmp/id_rsa'])



# Generated at 2022-06-20 12:56:55.574335
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('ansible', 'testing', 'description', 'epilog')
    print(parser)



# Generated at 2022-06-20 12:57:06.890000
# Unit test for function version
def test_version():
    program_name = "test-program"
    test_version = "test-version"
    test_gitinfo = "test-info"
    __version__ = test_version

    _orig_gitinfo = __main__._gitinfo
    __main__._gitinfo = lambda: test_gitinfo
    try:
        testcase = version(program_name)
    finally:
        __main__._gitinfo = _orig_gitinfo

# Generated at 2022-06-20 12:57:10.587261
# Unit test for function add_fork_options
def test_add_fork_options():
    import ansible.module_utils.basic
    parser = ansible.module_utils.basic.AnsibleOptions(add_fork_options)
    args = ['-f', '23']
    (options, args) = parser.parse_args(args)
    assert options.forks == 23


# Generated at 2022-06-20 12:57:15.305733
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = SortingHelpFormatter()
    actions = [
        argparse.Action([], option_strings=['-a', '--abc'], dest="abc", default=False),
        argparse.Action([], option_strings=['-b', '--bac'], dest="bac", default=False),
        argparse.Action([], option_strings=['-c', '--cab'], dest="cab", default=False),
    ]
    parser.add_arguments(actions)

# Generated at 2022-06-20 12:57:18.542473
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert options.check
    assert options.syntax
    assert options.diff


# Generated at 2022-06-20 12:57:28.269527
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    assert AnsibleVersion()



# Generated at 2022-06-20 12:57:29.667808
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args('-f 100'.split())
    assert args.forks == 100


# Generated at 2022-06-20 12:57:39.137814
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class DummyAction(argparse.Action):
        def __init__(self, option_strings, dest, nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None):
            super(DummyAction, self).__init__(option_strings=option_strings, dest=dest, nargs=nargs, const=const, default=default, type=type, choices=choices, required=required, help=help, metavar=metavar)
            self.count = 0
        def __call__(self, parser, namespace, values, option_string=None):
            setattr(namespace, self.dest, self.count)
            self.count += 1
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)

# Generated at 2022-06-20 12:57:44.987956
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options = parser.parse_args(["-o", "-t", "/etc"])
    assert options.one_line == True
    assert options.tree == "/etc"
# Function add_output_options ends



# Generated at 2022-06-20 12:57:46.710878
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='argparse_test')
    add_meta_options(parser)
    parser.parse_args(['--force-handlers'])
    parser.parse_args(['--flush-cache'])



# Generated at 2022-06-20 12:57:56.959308
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import argparse
    class FakeAction:
        def __init__(self, option_string):
            self.option_strings = option_string
    # Initial call
    parser = argparse.ArgumentParser(prog='test_add_arguments',
                                     formatter_class=SortingHelpFormatter)
    parser.add_argument('--opt1', action=FakeAction,
                        option_string=['--opt1'])
    parser.add_argument('--opt2', action=FakeAction,
                        option_string=['--opt2'])
    parser.add_argument('--opt10', action=FakeAction,
                        option_string=['--opt10'])
    parser.add_argument('--opt3', action=FakeAction,
                        option_string=['--opt3'])

# Generated at 2022-06-20 12:58:03.792022
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(prog='foo', add_help=False)
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--unrecognized-argument', action=UnrecognizedArgument, const=True, option_strings='--baz')
    args = parser.parse_args('--baz'.split())
    assert args.unrecognized_argument is True
#
# Special purpose OptionParsers
#

#
# Option Parsers
#
# These are used when a specific option parser is required, such as in the
# command line.  By default they will use the normal optparse defaults, but
# can be configured to define specific options.
#



# Generated at 2022-06-20 12:58:07.489438
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['-b'])
    assert args.become is True


# Generated at 2022-06-20 12:58:11.320260
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog="test_prog")
    args = ['-v','-vv']
    parser.parse_args(args[0:])
    assert True



# Generated at 2022-06-20 12:58:18.084385
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('test', desc='test parser')
    add_runas_options(parser)
    options = parser.parse_args(['-b', '-K', '--become-user=someone'])
    assert options.become
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user == 'someone'
    assert options.become_ask_pass

# Generated at 2022-06-20 12:58:45.613792
# Unit test for function unfrack_path
def test_unfrack_path():
    test_data = [
        # Normalize a valid path
        ('/path/to/file', '/path/to/file'),
        # Paths ending with a separator are not normalized
        ('/path/to/file/', '/path/to/file/'),
        # List of paths
        ('/path/to/file:/path/to/file2', ['/path/to/file', '/path/to/file2']),
        # Allow empty list of paths
        ('', []),
        # Allow '-' as path
        ('-', '-'),
        # No-op for paths that are already normalized
        ('~/path/to/file', '~/path/to/file'),
    ]


# Generated at 2022-06-20 12:58:53.930742
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-id', 'default', '--vault-password-file', '@vault/vault_pass.txt'])
    assert args.vault_ids == ['default']
    assert args.vault_password_files == ['@vault/vault_pass.txt']
    try:
        args = parser.parse_args(['--vault-id', 'default', '--ask-vault-pass'])
        assert False
    except SystemExit:
        assert True

# Generated at 2022-06-20 12:58:55.733913
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser('foo', 'bar', 'baz')
    add_fork_options(parser)
    return parser



# Generated at 2022-06-20 12:58:57.186207
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    parser.parse_args(args=[])

# Generated at 2022-06-20 12:59:00.326656
# Unit test for function add_output_options
def test_add_output_options():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    parser = argparse.ArgumentParser()
    add_output_options(parser)
    (options, args) = parser.parse_known_args(['-o'])
    assert options.one_line
    (options, args) = parser.parse_known_args(['--tree', '/tmp/'])
    assert options.tree == '/tmp/'
# End of unit test for function add_output_options



# Generated at 2022-06-20 12:59:08.519663
# Unit test for function add_async_options
def test_add_async_options():
    """ test add_async_options() """
    parser = argparse.ArgumentParser()
    parser.add_argument('-P', '--poll', default=C.DEFAULT_POLL_INTERVAL, type=int, dest='poll_interval',
                        help="set the poll interval if using -B (default=%s)" % C.DEFAULT_POLL_INTERVAL)
    parser.add_argument('-B', '--background', dest='seconds', type=int, default=0,
                        help='run asynchronously, failing after X seconds (default=N/A)')
    args = parser.parse_args()
    assert args.poll == 10
    assert args.poll_interval == 10
    assert args.seconds == 0



# Generated at 2022-06-20 12:59:13.493446
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='test_add_fork_options')
    add_fork_options(parser)
    myargs = ['-f', '3']
    args = parser.parse_args(myargs)
    print(args)
    assert args.forks == 3


# Generated at 2022-06-20 12:59:18.957709
# Unit test for function add_vault_options
def test_add_vault_options():
    """Test function add_vault_options for ansible-test"""
    parser = argparse.ArgumentParser()
    add_vault_options(parser)

    options = parser.parse_args(['--vault-id', 'id1'])
    assert options.vault_ids == ['id1']

    options = parser.parse_args(['--ask-vault-pass'])
    assert options.ask_vault_pass is True

    options = parser.parse_args(['--vault-password-file', 'file1'])
    assert options.vault_password_files == ['file1']


#
# Functions to implement option groups
#


# Generated at 2022-06-20 12:59:23.406716
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(description="Testing for function add_fork_options")
    add_fork_options(parser)
    opts, args = parser.parse_known_args()
    assert opts.forks == 50



# Generated at 2022-06-20 12:59:26.684367
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = version('')
    o = AnsibleVersion('')
    o(None, None, None, None)
    with pytest.raises(SystemExit) as excinfo:
        o(None, None, None, None)
    assert '0' in str(excinfo.value)


# Generated at 2022-06-20 13:01:14.731803
# Unit test for function add_vault_options
def test_add_vault_options():
        parser = argparse.ArgumentParser(description="This is a argparse object")
        add_vault_options(parser)
        args = parser.parse_args()
        assert not args.vault_ids
        assert args.vault_password_files == []
        assert args.ask_vault_pass is False

# Generated at 2022-06-20 13:01:21.175569
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-config-utils')
    parser.add_argument('--playbook-dir', default=C.config.get_config_value('PLAYBOOK_DIR'), dest='basedir', action='store',
                        help="Since this tool does not use playbooks, use this as a substitute playbook directory."
                             "This sets the relative path for many features including roles/ group_vars/ etc.",
                        type=unfrack_path())
    cmd_args = ['--playbook-dir', '~/roles']
    namespace, unknown_args = parser.parse_known_args(cmd_args)
    assert namespace.basedir == '~/roles'
    assert unknown_args == []



# Generated at 2022-06-20 13:01:25.461850
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from six import StringIO
    args = ['-v']
    _stdout = sys.stdout
    output = StringIO()
    sys.stdout = output
    target = AnsibleVersion(option_strings=args)
    target(None, None, None, option_string=None)
    answer = to_native(output.getvalue().strip())
    sys.stdout = _stdout
    assert answer == __version__



# Generated at 2022-06-20 13:01:26.342266
# Unit test for function version
def test_version():
    assert isinstance(version(), str)

# Generated at 2022-06-20 13:01:30.901439
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.cli.arguments import options as options
    import sys


    output = sys.stdout
    class TestOptParse(object):
        def __init__(self):
            self.uses_idiot = True
            self.class_idiot = True
            self.instance_idiot = True
            self.no_idiot = True
            self.no_class_idiot = True
            self.no_instance_idiot = True

            self.uses_optimistic = True
            self.class_optimistic = True
            self.instance_optimistic = True
            self.no_optimistic = True
            self.no_class_optimistic = True
            self.no_instance_optimistic = True

    # key: The idiot options
    # value: The optimistic options