

# Generated at 2022-06-20 12:52:04.053813
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    '''
    Test function add_tasknoplay_options
    '''
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    # Just test that we can supply --task-timeout
    args = parser.parse_args(['--task-timeout', 1234])
    assert args.task_timeout == 1234



# Generated at 2022-06-20 12:52:09.681188
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser('test')
    add_fork_options(parser)
    args = parser.parse_args(['-f'])
    assert args.forks == C.DEFAULT_FORKS



# Generated at 2022-06-20 12:52:16.347203
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    maybe_unfrack_path('@')('@./xxxxxx').startswith('@')
    maybe_unfrack_path('@')('@./xxxxxx').endswith('library/xxxxxx')
    maybe_unfrack_path('@')('@./xxxxxx') == '@library/xxxxxx'
    maybe_unfrack_path('@')('./xxxxxx') == './xxxxxx'



# Generated at 2022-06-20 12:52:26.070960
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', '1', '--foo', '2', '--foo', '3'])
    assert args.foo == [1, 2, 3]

    args = parser.parse_args(['--foo', '1', '--foo=2', '--foo', '3', '--foo=4'])
    assert args.foo == [1, 3, 2, 4]

    args = parser.parse_args(['--foo', '1', '--foo', '2', '--foo', '3', '4'])
    assert args.foo == [1, 2, 3, 4]


# Generated at 2022-06-20 12:52:34.757592
# Unit test for function add_runas_options
def test_add_runas_options():
    with pytest.raises(AttributeError):
        parser = argparse.ArgumentParser(description="Test getattr")
        add_runas_options(parser)
        parser.parse_args(''.split())

    parser = argparse.ArgumentParser(description="Test getattr")
    add_runas_options(parser)
    options = parser.parse_args('-b --become-user=test_become_user'.split())
    assert options.become is True
    assert options.become_user == 'test_become_user'
    assert options.become_pass is None



# Generated at 2022-06-20 12:52:39.542360
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    sys.argv = ['test_AnsibleVersion___call__', '--version']
    parser = init_parser(usage="%prog some_script [options]")
    args = parser.parse_args()
    assert args.version is None
    assert args.verbosity is 0



# Generated at 2022-06-20 12:52:48.793858
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    args = ['-x']
    test_schema = {
        'description': 'test unrecognized arguments',
        'arguments': [
            {'args': ['-x', '--test-xyz'], 'action': 'store'}
        ]
    }

    parser = argparse.ArgumentParser()
    for arg in argparse.ArgumentParser(description=test_schema['description']):
        add_parser_argument(parser, arg)

    try:
        args = parser.parse_args(args)
    except SystemExit:
        pass



# Generated at 2022-06-20 12:52:59.183200
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # add_inventory_options with valid '-i'.
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    inv = "valid_inventory.py"
    args = parser.parse_args(['-i', inv])
    assert args.inventory == [inv]

    # add_inventory_options with invalid '-i'.
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    inv = "invalid_inventory.ini"
    with pytest.raises(SystemExit):
        parser.parse_args(['-i', inv, '-l', 'all'])

    # add_inventory_options with multiple '-i'.
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    inv1 = "inventory_1.py"

# Generated at 2022-06-20 12:53:07.910359
# Unit test for function add_async_options
def test_add_async_options():

    def result(args):
        return args.poll_interval, args.seconds

    args = ['--poll', '30', '-B', '600']
    p = argparse.ArgumentParser()
    a = add_async_options(p)
    result(p.parse_args(args=args))
    args = ['-B', '600', '--poll', '30']
    p = argparse.ArgumentParser()
    a = add_async_options(p)
    result(p.parse_args(args=args))
    args = []
    p = argparse.ArgumentParser()
    a = add_async_options(p)
    result(p.parse_args(args=args))



# Generated at 2022-06-20 12:53:18.347291
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # https://docs.python.org/3.6/library/argparse.html#nargs
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    parser.add_argument('--bar', action=UnrecognizedArgument, nargs=1)
    parser.add_argument('--baz', action=UnrecognizedArgument, nargs='*')
    parser.add_argument('--qux', action=UnrecognizedArgument, nargs='?')
    parser.add_argument('--quux', action=UnrecognizedArgument, nargs='+')
    try:
        parser.parse_args(['--foo'])
    except SystemExit:
        pass
    else:
        assert False

# Generated at 2022-06-20 12:53:48.844876
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser('test', usage="", desc="", epilog='')
    add_inventory_options(parser)
    parser.add_argument('-M', '--module-path', default=C.DEFAULT_MODULE_PATH, dest='module_path',
                        help="ansible module path value")
    options, args = parser.parse_known_args(['-i','hosts', '-l', 'host1', '--list-hosts', '-M', '/tmp'])
    assert options.inventory == ['hosts']
    assert options.subset == 'host1'
    assert options.listhosts == True
    assert options.module_path == '/tmp'


# Generated at 2022-06-20 12:53:51.051784
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = " -f 2 "
    opt = parser.parse_args(args.split())
    assert opt.forks == 2



# Generated at 2022-06-20 12:53:54.050125
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("ansible", desc="My program does things.")
    args = parser.parse_args([])
    assert args.version is False
    assert args.verbosity == 0



# Generated at 2022-06-20 12:54:03.315441
# Unit test for function add_async_options
def test_add_async_options():
    from ansible import context
    from ansible.cli.arguments import options as cli_options
    from ansible.errors import AnsibleParserError

    parser = cli_options.create_base_parser("/test")
    cli_options.add_async_options(parser)
    init_args = parser.parse_args([])
    assert not context.CLIARGS.seconds
    assert not context.CLIARGS.poll_interval
    init_args = parser.parse_args(["-P", "10"])
    assert context.CLIARGS.poll_interval == 10
    # This is the default so it should not have changed
    assert not context.CLIARGS.seconds
    init_args = parser.parse_args(["-B", "10"])
    assert context.CLIARGS

# Generated at 2022-06-20 12:54:05.295546
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert parser is not None



# Generated at 2022-06-20 12:54:15.980785
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.vault import VaultLib
    from ansible.utils.display import Display
    from ansible.utils.debug import enable_debugger
    from ansible import context
    from ansible.errors import AnsibleOptionsError
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    import tempfile
    import os
   

# Generated at 2022-06-20 12:54:22.533145
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    parsed, _ = parser.parse_known_args(['--become', '--become-user', 'test_user',
                                         '--become-method', 'sudo', '--extra-vars', 'a=b'])
    assert parsed.become
    assert parsed.become_user == 'test_user'
    assert parsed.become_method == 'sudo'



# Generated at 2022-06-20 12:54:31.828231
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # test for unfracking
    assert maybe_unfrack_path('@')('@/test/value') == '@' + unfrackpath('/test/value')
    assert maybe_unfrack_path('@')('@test/value') == '@' + unfrackpath('test/value')
    assert maybe_unfrack_path('@')('@@/test/value') == '@@/test/value'
    assert maybe_unfrack_path('@')('@@test/value') == '@@test/value'
    assert maybe_unfrack_path('@')('/test/value') == '/test/value'



# Generated at 2022-06-20 12:54:36.469849
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser('test')
    add_fork_options(parser)
    assert '-f' in [o.option_strings for o in parser._actions]


# Generated at 2022-06-20 12:54:43.672811
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(description='description', usage='usage', add_help=False)
    parser.add_argument('--test', action=UnrecognizedArgument, required=True)

    results = parser.parse_args(args=['--test', 'value'])
    assert results.test == 'value'
    try:
        results = parser.parse_args(args=['--test', '--test2', 'value'])
        assert False, 'Expected parser.error'
    except SystemExit:
        pass
    except:
        raise



# Generated at 2022-06-20 12:54:55.693760
# Unit test for function unfrack_path
def test_unfrack_path():
    assert None is unfrack_path()(None)
    # Test when pathsep is False
    assert 'bar' == unfrack_path()('bar')
    assert 'bar' == unfrack_path()('/bar')
    assert 'bar' == unfrack_path()('foo/bar')
    assert 'bar' == unfrack_path()('/foo/bar')
    assert 'foo/bar' == unfrack_path()('foo/bar')
    # Test when pathsep is True
    assert unfrack_path(pathsep=True)(None) == [None]
    assert unfrack_path(pathsep=True)('') == []
    assert unfrack_path(pathsep=True)(':') == [None, None]
    assert unfrack_path(pathsep=True)('bar') == ['bar']


# Generated at 2022-06-20 12:54:57.659392
# Unit test for function add_vault_options
def test_add_vault_options():
    expected = ['vault_id', 'vault_password_file', 'ask_vault_pass',]
    parser = create_base_parser()
    add_vault_options(parser)
    options = vars(parser.parse_args(''))
    assert options.keys() == expected


# Generated at 2022-06-20 12:55:00.087107
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('test') == to_native(os.path.realpath('test'), errors='surrogate_or_strict')


# Generated at 2022-06-20 12:55:09.583637
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class TestParser(argparse.ArgumentParser):
        def error(self, message):
            raise RuntimeError(message)

    sys.argv = []

    parser = TestParser()
    parser.add_argument('--foo', action='append')
    parser.add_argument('--foo2', action=PrependListAction)
    parser.parse_args(['--foo', 'a', '--foo', 'b', '--foo2', 'c', '--foo', 'd', '--foo2', 'e'])
    assert parser.parse_args(['--foo', 'a', '--foo', 'b', '--foo2', 'c', '--foo', 'd', '--foo2', 'e']).foo == ['a', 'b', 'd']

# Generated at 2022-06-20 12:55:11.917406
# Unit test for function create_base_parser
def test_create_base_parser():
    """
    Ensure create_base_parser creates a parser without error
    """
    parser = create_base_parser('test_prog', 'Test usage text')
    assert parser



# Generated at 2022-06-20 12:55:19.990131
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    class TestArgs():
        def __init__(self):
            self.prog = 'test_prog'
    args = TestArgs()
    try:
        UnrecognizedArgument(option_strings='--foo', dest='foo')(parser=args, namespace='test', value='test', option_string='--foo')
    except SystemExit as e:
        assert e.code != 0
    else:
        assert False, 'UnrecognizedArgument method __call__ failed to raise SystemExit.'


#
# Parser-related functions
#

# Generated at 2022-06-20 12:55:22.797017
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser=argparse.ArgumentParser(prog='test')
    add_basedir_options(parser)
    parser.parse_args(['--playbook-dir=/etc'])


# Generated at 2022-06-20 12:55:28.495959
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='unit_test_ansible', usage='', desc='', epilog='')
    parser.parse_args(['--help'])
    version_help = "show program's version number, config file location, configured module search path," \
                   " module location, executable location and exit"
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, help=version_help)
    add_verbosity_options(parser)
    _junk = parser.parse_args(['--version'])



# Generated at 2022-06-20 12:55:31.387736
# Unit test for function add_async_options
def test_add_async_options():

    parser = argparse.ArgumentParser()
    add_async_options(parser)
    parser.parse_args(['-P', '1', '-B', '10'])



# Generated at 2022-06-20 12:55:41.849509
# Unit test for function ensure_value
def test_ensure_value():
    class DummyNamespace(object):
        def __init__(self):
            self.value = None
            self.foo = None

    namespace = DummyNamespace()

    # return set value
    ensure_value(namespace, 'foo', 'bar')
    assert namespace.foo == 'bar'
    # return default value
    assert ensure_value(namespace, 'value', 'bar') == 'bar'
    # return existing value
    assert ensure_value(namespace, 'foo', 'baz') == 'bar'


#
# Option Parser base object.  Handles some default parsing options and acts as a base
# for the subcommand parsers
#

# Generated at 2022-06-20 12:55:59.309958
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("--bar")
    parser.add_argument("--foo")
    parser.add_argument("arg1")

    parsed = parser.parse_args(["arg1", "--foo=foo"])
    assert parsed.bar is None
    assert parsed.foo == "foo"
    assert parsed.arg1 == "arg1"


# Generated at 2022-06-20 12:56:09.281526
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert '@/var/lib/awx' == maybe_unfrack_path('@')('@var/lib/awx')
    assert '@var/lib/awx' == maybe_unfrack_path('@')('@var/lib/awx/')
    assert '@/var/lib/awx/' == maybe_unfrack_path('@')('@/var/lib/awx')
    assert '@/var/lib/awx/' == maybe_unfrack_path('@')('@/var/lib/awx/')
    assert '@@/var/lib/awx/' == maybe_unfrack_path('@')('@@/var/lib/awx/')


# Generated at 2022-06-20 12:56:16.003470
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """
    Test for function add_tasknoplay_options
    """
    parser = argparse.ArgumentParser(prog='myprogram')
    add_tasknoplay_options(parser)
    args = parser.parse_args([])
    assert type(args.task_timeout) is int
    assert args.task_timeout == C.TASK_TIMEOUT
    assert C.TASK_TIMEOUT == 30



# Generated at 2022-06-20 12:56:22.316512
# Unit test for function add_fork_options
def test_add_fork_options():
    opt = {}
    parser = Mock()
    parser.add_argument = lambda *a, **kw: opt.update({'pos': a, 'kw': kw})
    add_fork_options(parser)
    assert opt == {'pos': ('-f', '--forks'), 'kw': {'dest': 'forks', 'default': C.DEFAULT_FORKS, 'type': int,
                   'help': "specify number of parallel processes to use (default=%s)" % C.DEFAULT_FORKS}}


# Generated at 2022-06-20 12:56:33.771913
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(description='argparse description', formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument_group('group1')
    parser.add_argument_group('group2')
    parser.add_argument_group('group3')
    parser.add_argument_group('group4')
    parser.add_argument('-c')
    parser.add_argument('-d')
    parser_args = parser.parse_args([])  # parser.parse_args(sys.argv[1:])
    #  getattr(parser_args, 'argparse_description') is None, because the argparse_description is not the defined
    #  argument in the class ArgumentParser.

# Generated at 2022-06-20 12:56:35.998479
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == unfrackpath('/etc/ansible')


# Generated at 2022-06-20 12:56:46.505046
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from copy import copy
    from argparse import ArgumentParser
    global_parser = ArgumentParser(add_help=False)
    global_parser.add_argument('global_arg',action=UnrecognizedArgument)
    parser = ArgumentParser()
    subparsers = parser.add_subparsers(dest='command')
    other_parser = subparsers.add_parser('other',parents=[global_parser])
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        other_parser.parse_args(['other','--global-arg'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-20 12:56:48.993140
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--syntax-check'])
    assert args.syntax == True



# Generated at 2022-06-20 12:56:54.038165
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar/vars') == '@/foo/bar/vars'
    assert maybe_unfrack_path('@')('@@/foo/bar/vars') == '@@/foo/bar/vars'



# Generated at 2022-06-20 12:57:04.612304
# Unit test for function add_module_options
def test_add_module_options():
    # check for prepend list action
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(['-M', '/foo'])
    assert(args.module_path == ['/foo', '/usr/share/ansible/plugins/modules'])
    args = parser.parse_args(['-M', '/foo', '-M', '/bar'])
    assert(args.module_path == ['/bar', '/foo', '/usr/share/ansible/plugins/modules'])
    args = parser.parse_args(['-M', '/foo:/bar'])
    assert(args.module_path == ['/bar', '/foo', '/usr/share/ansible/plugins/modules'])
    # check for normal action
    parser = argparse.ArgumentParser()
   

# Generated at 2022-06-20 12:57:23.051668
# Unit test for function create_base_parser

# Generated at 2022-06-20 12:57:32.651432
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    frag='/path/to/beacon'
    rfrag=maybe_unfrack_path(frag)(frag)
    assert rfrag == frag, "maybe_unfrack_path failed, got %s instead of %s." % (rfrag, frag)
    test_frag='~/path/to/beacon'
    test_rfrag='%s/path/to/beacon' % os.path.expanduser('~')
    assert maybe_unfrack_path(frag)(test_frag) == test_rfrag, "maybe_unfrack_path failed, got %s instead of %s." % (maybe_unfrack_path(frag)(test_frag), test_rfrag)



# Generated at 2022-06-20 12:57:38.136610
# Unit test for function add_check_options
def test_add_check_options():
    import ansible.utils.args
    parser = argparse.ArgumentParser()
    ansible.utils.args.add_check_options(parser)
    option = parser.parse_args(['--check'])
    assert option.check == True
    option = parser.parse_args(['--syntax-check'])
    assert option.syntax == True
    option = parser.parse_args(['--diff'])
    assert option.diff == True


# Generated at 2022-06-20 12:57:45.147345
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check == True
    args = parser.parse_args(['--syntax-check'])
    assert args.syntax == True
    args = parser.parse_args(['--diff'])
    assert args.diff == True

# Generated at 2022-06-20 12:57:46.709687
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    parser.parse_args(['-M', 'foo', '-K', 'bar'])

# Generated at 2022-06-20 12:57:53.706848
# Unit test for function add_runas_options
def test_add_runas_options():
    """
    Test if add_runas_options() contains all the required options
    """
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(argv[1:])
    expected_one = '-b --become -K --ask-become-pass --ask-become-priv --ask-become-user -U --become-user -R --become-method'
    result_one = args.become
    assert result_one in expected_one



# Generated at 2022-06-20 12:57:54.292480
# Unit test for function add_meta_options
def test_add_meta_options():
    assert True


# Generated at 2022-06-20 12:58:02.641913
# Unit test for function add_vault_options
def test_add_vault_options():
    """
    Unit test for function add_vault_options
    """
    parser_1 = argparse.ArgumentParser()
    add_vault_options(parser_1)
    # --vault-id
    parser_2 = argparse.ArgumentParser()
    add_vault_options(parser_2)
    options, _ = parser_2.parse_known_args(['--vault-id', 'MyVaultId'])
    assert options.vault_ids == ['MyVaultId']
    # --vault-password-file
    parser_3 = argparse.ArgumentParser()
    add_vault_options(parser_3)
    options, _ = parser_3.parse_known_args(['--vault-password-file', 'MyVaultPasswordFile'])
    assert options.vault

# Generated at 2022-06-20 12:58:14.642380
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class DummyParser:
        def __init__(self):
            self.dummy_namespace = Namespace()
            self.dummy_namespace.dummy_list = [0]

        def error(self, message):
            raise AssertionError(message)

        def exit(self):
            raise SystemExit()

    dummy_parser = DummyParser()
    prepend_list_action = PrependListAction(["--dummy-option"], "dummy_list")

    # Case 1:
    # Check that given action prepends list.
    prepend_list_action(dummy_parser, dummy_parser.dummy_namespace, [1, 2], "--dummy-option")

# Generated at 2022-06-20 12:58:19.780854
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = ["-C","-D","--syntax-check","--check","--diff"]
    # args = parser.parse_args(sys.argv[1:])
    args = parser.parse_args(args)
    print(args)



# Generated at 2022-06-20 12:58:30.229671
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('ansible')
    opts, args = parser.parse_known_args()
    assert opts.verbosity == 0
    assert opts.quiet == 0



# Generated at 2022-06-20 12:58:34.143800
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    cli_args = ['-o', 'True', '-t', '/tmp/dir', ]
    namespace = parser.parse_args(cli_args)
    assert namespace.one_line == True
    assert namespace.tree == '/tmp/dir'


# Generated at 2022-06-20 12:58:37.189066
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    # my main concern is that the object does not throw an exception here
    assert parser is not None


# Generated at 2022-06-20 12:58:42.772727
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    args = ["--version"]
    parser = argparse.ArgumentParser()
    parser.add_argument('-V', '--version',
                        action=AnsibleVersion,
                        nargs=0,
                        dest='version',
                        help='Show version number and exit')
    args = vars(parser.parse_args(args))
    assert args['version'] == version()



# Generated at 2022-06-20 12:58:45.713173
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(prog = 'test')
    parser.add_argument('-f', '--foo', action=UnrecognizedArgument, help='help')    
    parser.parse_args(['-f'])

# Generated at 2022-06-20 12:58:50.466766
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path') == '@' + unfrackpath('/path')
    assert maybe_unfrack_path('@')('/path') == '/path'
    assert maybe_unfrack_path('@')('@path') == '@path'



# Generated at 2022-06-20 12:58:54.779955
# Unit test for function create_base_parser
def test_create_base_parser():
    # Check for base options
    # Version opt should be present
    # Verbosity opts should be present
    p = create_base_parser("ansible")
    opts, args = p.parse_known_args(['-v', '--version'])
    assert opts.verbosity
    assert opts.version


# Generated at 2022-06-20 12:58:59.192054
# Unit test for function version
def test_version():
    argv = sys.argv
    sys.argv = ['ansible']
    try:
        # Check for specific errors
        assert version()
        assert version(prog='test')
    finally:
        # Restore sys.argv
        sys.argv = argv
test_version()

# Generated at 2022-06-20 12:59:02.899935
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    assert '-t --tree' in str(parser.format_help())


# Generated at 2022-06-20 12:59:10.229230
# Unit test for function unfrack_path
def test_unfrack_path():
    """Unit test for function unfrack_path"""
    assert unfrack_path()('/') == '/'
    assert unfrack_path()('//') == '//'
    assert unfrack_path()('/') == '/'
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path()('./foo') == './foo'
    assert unfrack_path()('./foo') == './foo'
    assert unfrack_path()('../foo') == '../foo'
    assert unfrack_path()('~/foo') == '~/foo'
    assert unfrack_path()('$ANSIBLE_CONFIG') == '$ANSIBLE_CONFIG'
    assert unfrack_path()('${ANSIBLE_CONFIG}') == '${ANSIBLE_CONFIG}'
    assert unfrack

# Generated at 2022-06-20 12:59:21.485051
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    res = add_connect_options(parser)
    assert res is not None



# Generated at 2022-06-20 12:59:31.092206
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # test with only one option
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--a')
    assert parser.format_help() == """usage: [-h] [--a A]

optional arguments:
  -h, --help  show this help message and exit
  --a A"""

    # test with two options
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--a')
    parser.add_argument('-b')
    assert parser.format_help() == """usage: [-h] [-b B] [--a A]

optional arguments:
  -h, --help  show this help message and exit
  -b B
  --a A"""

    # test with three options

# Generated at 2022-06-20 12:59:39.005124
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('bar')
    parser.add_argument('foo')
    parser.add_argument('-f')
    parser.add_argument('--foo')
    parser.add_argument('boo')
    parser.add_argument('--bar')
    parser.add_argument('-b')
    out = parser.format_help()
    assert out.find('-b') < out.find('--bar'), '-b and --bar ordered incorrectly'
    assert out.find('foo') < out.find('bar'), 'foo and bar ordered incorrectly'



# Generated at 2022-06-20 12:59:43.648177
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == 'foo'
    assert unfrack_path()('./foo') == './foo'
    assert unfrack_path()('~/foo') == os.path.join(os.path.expanduser('~'), 'foo')



# Generated at 2022-06-20 12:59:51.697603
# Unit test for function create_base_parser
def test_create_base_parser():
    p = create_base_parser("ansible-test", usage="test usage", desc="test desc", epilog="test epilog")
    p.add_argument('-t', '--test', dest='test', action='store_true', default=False, help="test option")
    opts, _args = p.parse_known_args([])
    assert opts.test == False
    opts, _args = p.parse_known_args(['-v'])
    assert opts.test == False
    opts, _args = p.parse_known_args(['-t', '-vvvv'])
    assert opts.test == True
    opts, _args = p.parse_known_args(['--version'])

# Generated at 2022-06-20 12:59:53.690706
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)


# Generated at 2022-06-20 13:00:03.036527
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, help='Show version number and exit')
    parser.add_argument('--unrecognized-arguments', action=UnrecognizedArgument, help='Display an error message about unrecognized arguments and exit', nargs=argparse.REMAINDER)
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--unrecognized-arguments', '--version'])
    assert args.unrecognized_arguments == ['--version']
    args = parser.parse_args(['--version', '--unrecognized-arguments', '--version'])
    assert args.version



# Generated at 2022-06-20 13:00:07.284145
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """Test function add_tasknoplay_options"""
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    parser.parse_known_args()



# Generated at 2022-06-20 13:00:16.722768
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():

    import argparse
    from ansible.utils.display import SortingHelpFormatter

    output = """
  -a, --a-b A B C
  -d, --a-d A D E
  -f, --a-f A F G
  -c, --c-d C D E
  -e, --c-e C E G
  -g, --c-g C G H
"""

    class DummyOptParser(object):

        def __init__(self):
            self.usage = 'usage'
            self.prog = 'prog'
            self.indent_increment = 0
            self.max_help_position = 0
            self.current_indent = 0

    class DummyAction(object):

        def __init__(self, *opt_strings):
            self.option_strings

# Generated at 2022-06-20 13:00:26.298804
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.cli.arguments import add_runtask_options
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    vars_loader = DataLoader()
    inventory_manager = InventoryManager(loader=vars_loader)
    display = Display()
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)

# Generated at 2022-06-20 13:00:44.714382
# Unit test for function ensure_value
def test_ensure_value():
    class Args(object):
        def __init__(self):
            self.list_arg = []
    args = Args()
    # Test return value
    assert ensure_value(args, 'list_arg', [1]) == [1]
    # List has been added to namespace
    assert args.list_arg == [1]
    # Try appending to list
    assert ensure_value(args, 'list_arg', [2, 3]) == [1, 2, 3]
    # List has been appended to
    assert args.list_arg == [1, 2, 3]
    # Try again and ensure it doesn't grow further
    assert ensure_value(args, 'list_arg', [4]) == [1, 2, 3]
    assert args.list_arg == [1, 2, 3]
    # Create a scal

# Generated at 2022-06-20 13:00:51.451033
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options, args = parser.parse_known_args([])
    assert options.tags == C.TAGS_RUN
    assert options.skip_tags == C.TAGS_SKIP
    options, args = parser.parse_known_args(["-t","abc","--skip-tags","def"])
    assert options.tags == ["abc"]
    assert options.skip_tags == ["def"]
    options, args = parser.parse_known_args(["-t","abc","-t","def","--skip-tags","ghi","--skip-tags","jkl"])
    assert sorted(options.tags) == ["abc","def"]
    assert sorted(options.skip_tags) == ["ghi","jkl"]

add_connect_options

# Generated at 2022-06-20 13:00:56.592332
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    arg_list, arg_dict = parse_args_to_dict(parser, ['-t', 't1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9',
                                                     '--skip-tags', 'st1', 'st2', 'st3', 'st4', 'st5'])
    assert arg_dict['tags'] == ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9']
    assert arg_dict['skip_tags'] == ['st1', 'st2', 'st3', 'st4', 'st5']



# Generated at 2022-06-20 13:01:03.948347
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runtask_options(parser)
    options = parser.parse_args([])
    assert options.extra_vars == []

    options = parser.parse_args(['-e', 'a=b'])
    assert options.extra_vars == ['a=b']

    options = parser.parse_args(['-e', 'a=b', '-e', 'a=b'])
    assert options.extra_vars == ['a=b', 'a=b']

    options = parser.parse_args(['-e', '@/tmp/a.yml', '-e', 'a=b'])
    assert options.extra_vars == ['/tmp/a.yml', 'a=b']



# Generated at 2022-06-20 13:01:12.402713
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    prog = './test_version.py'
    usage = ''
    desc = 'Test version'
    epilog=''
    parser1 = create_base_parser(prog, usage, desc, epilog)
    assert parser1.prog == prog
    assert parser1.usage == usage
    assert parser1.description == desc
    assert parser1.epilog == epilog
    args = parser1.parse_args()
    assert args.verbosity == C.DEFAULT_VERBOSITY
    # Test for help option
    main(args)

# Generated at 2022-06-20 13:01:16.167108
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'foo', [])
    assert namespace.foo == []

    namespace = argparse.Namespace()
    ensure_value(namespace, 'foo', {})
    assert namespace.foo == {}
# End unit test code



# Generated at 2022-06-20 13:01:18.943390
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    # Verify that the default base dir is the same as the value in constants.py
    args = parser.parse_args(['--playbook-dir', 'path/to/playbook'])
    assert 'path/to/playbook' == args.basedir

#
# Functions to add common options to OptionParser
#


# Generated at 2022-06-20 13:01:21.704827
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    from ansible.cli.arguments import base_parser
    s = SortingHelpFormatter()
    s.add_arguments(base_parser.__dict__['_actions'])

#
# Options parsers (for parsing args in main and subcommands)
#


# Generated at 2022-06-20 13:01:25.452950
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = 'asdasd'
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', nargs=0, action=AnsibleVersion, help='Show Ansible version number and exit')
    if ansible_version != to_native(version(parser.prog)):
        sys.exit(1)


# Generated at 2022-06-20 13:01:28.772350
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(description="""ansible-galaxy""")
    add_basedir_options(parser)
    data = parser.parse_args(['--playbook-dir', 'test_playbook_dir'])
    assert data.basedir == 'test_playbook_dir'
