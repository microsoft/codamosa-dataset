

# Generated at 2022-06-20 12:52:53.423030
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(
        prog='test_add_inventory_options',
        description='description',
        conflict_handler='resolve',
    )
    add_inventory_options(parser)
    add_list_options(parser)
    add_sheet_options(parser)

    args = parser.parse_args(['--host', 'host1', '-i', 'host2,host3', '--limit', 'host4', '--list-hosts'])
    assert args.inventory[0] == 'host2,host3'
    assert args.limit == 'host4'
    assert args.subset == 'host4'
    assert args.hosts == ['host1', 'host2', 'host3']
    assert args.listhosts


# Generated at 2022-06-20 12:52:55.977705
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    parser.parse_args(['--task-timeout', '20'])



# Generated at 2022-06-20 12:53:05.921538
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog="ansible-playbook")
    add_check_options(parser)
    playbooks = [
        '-c local -i inventory playbook.yml',
        'ansible-playbook -i inventory playbook.yml',
        'ansible-playbook -i inventory --syntax playbook.yml'
    ]
    for test_playbook in playbooks:
        args = parser.parse_args(test_playbook.split())
        assert args.check is False
        assert args.syntax is False
    # assert Exception("--syntax-check option is not work")



# Generated at 2022-06-20 12:53:08.253501
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == version(parser.prog)



# Generated at 2022-06-20 12:53:18.555747
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_check_options(parser)
    # no args
    args = parser.parse_args([])
    assert args.check is False
    assert args.syntax is False
    assert args.diff is False
    # -C, short form
    args = parser.parse_args(['-C'])
    assert args.check is True
    assert args.syntax is False
    assert args.diff is False
    # -C, long form
    args = parser.parse_args(['--check'])
    assert args.check is True
    assert args.syntax is False
    assert args.diff is False
    # --diff, short form
    args = parser.parse_args(['-D'])
    assert args.check is False
   

# Generated at 2022-06-20 12:53:26.589838
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    namespace = argparse.Namespace()

    # Create an action that appends a string to a list
    p = PrependListAction(['-a', '--append'], dest='action',
                          nargs=1, const=1, type=str,
                          choices=None, required=False, metavar=None)

    # Append a string to a list attribute of namespace
    p(parser=None, namespace=namespace, values=['a'], option_string='-a')
    # Assert that the list is correct
    assert namespace.action == ['a']

    # Append another string to the list attribute of namespace
    p(parser=None, namespace=namespace, values=['b'], option_string='-a')
    # Assert that the list is correct
    assert namespace.action == ['a', 'b']

# Generated at 2022-06-20 12:53:38.509647
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class MockAction:
        def __init__(self, option_strings):
            self.option_strings = option_strings

    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('--c')
    parser.add_argument('--d')
    help = parser.format_help()
    if help[:10] != 'usage: test':
        print("Test case for SortingHelpFormatter.add_arguments failed")
        print("Expected output: usage: test.py [-h] [-a] [-b] [--c] [--d]")
        raise Exception("Test case for SortingHelpFormatter.add_arguments failed")



# Generated at 2022-06-20 12:53:50.216937
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = [
        '-k',
        '--private-key', 'some_path',
        '-u', 'connection_user',
        '-c', 'connection_type',
        '--ssh-common-args', 'some_ssh_args',
        '--sftp-extra-args', 'some_sftp_args',
        '--scp-extra-args', 'some_scp_args',
        '--ssh-extra-args', 'some_ssh_args',
        '--connection-password-file', 'some_path',
    ]
    arg_dict = vars(parser.parse_args(args))
    assert arg_dict['ask_pass'] is True

# Generated at 2022-06-20 12:53:52.286963
# Unit test for function add_subset_options
def test_add_subset_options():
    assert isinstance(add_subset_options, type(argparse.ArgumentParser))


# Generated at 2022-06-20 12:53:54.376289
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='smoketest')
    add_meta_options(parser)

    base_opts = parser.parse_args([])
    opts = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert opts.force_handlers == True
    assert opts.flush_cache == True



# Generated at 2022-06-20 12:54:14.624895
# Unit test for function unfrack_path
def test_unfrack_path():
    """
    >>> unfrack_path()('test')
    'test'
    >>> unfrack_path()('/test1:test2')
    '/test1:test2'
    >>> unfrack_path(pathsep=True)('/test1:test2')
    ['/test1', 'test2']
    >>> unfrack_path()('-')
    '-'
    """



# Generated at 2022-06-20 12:54:25.046028
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cmdline import SORTED_VERSION_KEYS, ExitWithError

# Generated at 2022-06-20 12:54:34.011829
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.module_utils.common.argparse import PrependListAction
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS)
    add_async_options(parser)
    options = parser.parse_args(['--poll', '10', '--background', '20'])
    assert options.poll_interval == 10, "Failed to parse --poll argument"
    assert options.seconds == 20, "Failed to parse --background argument"
    options = parser.parse_args(['-P', '11', '-B', '21'])
    assert options.poll_interval == 11, "Failed to parse -P argument"
    assert options.seconds == 21, "Failed to parse -B argument"


# Generated at 2022-06-20 12:54:42.111289
# Unit test for function add_check_options
def test_add_check_options():
    from ansible.utils.common.collections import is_sequence
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.plugin_docs import get_docstring

    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, args = parser.parse_known_args(
        ['--syntax-check', '--diff']
    )
    assert options.check
    assert options.syntax
    assert options.diff == C.DIFF_ALWAYS



# Generated at 2022-06-20 12:54:44.674200
# Unit test for function add_runas_options
def test_add_runas_options():
    import argparse
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    p = parser.parse_args()
    assert p.become == False
    assert p.become_method == 'sudo'
    assert p.become_user == None



# Generated at 2022-06-20 12:54:46.048535
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser(
        'unit-test'
    )
    assert len(parser._actions) == 2



# Generated at 2022-06-20 12:54:52.083221
# Unit test for function version
def test_version():
    import sys
    import os
    import tempfile
    sys.modules.pop('ansible', None)
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.cli import CLI
    from ansible import constants as C
    import ansible.constants as global_constants

    def _write_config(config):
        with tempfile.NamedTemporaryFile(prefix='ansible_config') as config_file:
            config_file.write(config.encode())
            config_file.flush()
            os.environ['ANSIBLE_CONFIG'] = config_file.name


# Generated at 2022-06-20 12:55:02.558835
# Unit test for function version
def test_version():
    # set some env/args to trigger some messages
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    import sys
    sys.argv = ['ansible-playbook']
    result = version('ansible-playbook').split('\n')
    if os.path.isfile('/etc/ansible/ansible.cfg'):
        assert len(result) == 11
    else:
        assert len(result) == 10
    assert result[0].startswith('ansible-playbook')
    assert result[1].startswith('  config file')
    assert result[2].startswith('  configured module search path')
    assert result[3].startswith('  ansible python module location')
    assert result[4].startswith('  ansible collection location')

# Generated at 2022-06-20 12:55:04.397839
# Unit test for function add_output_options
def test_add_output_options():
    test_parser = argparse.ArgumentParser(prog='test')
    add_output_options(test_parser)
    args = test_parser.parse_args(['-t', 'ansible'])
    assert args.tree == 'ansible'


# Generated at 2022-06-20 12:55:07.937418
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_async_options(parser)
    options = parser.parse_args()
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL


# Generated at 2022-06-20 12:55:17.889855
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = add_subset_options(sys.argv[0])
    return parser

# Generated at 2022-06-20 12:55:22.838037
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--aa')
    parser.add_argument('--bb')
    parser.add_argument('--cc')
    parser.add_argument('--dd')
    parser.print_help()

#
# Options that improve compatibility when running under Windows
#

# Generated at 2022-06-20 12:55:31.868747
# Unit test for function add_subset_options
def test_add_subset_options():
    ansible_options = ["-t", "--tags", "-t", "--tags", "--skip-tags", "--skip-tags"]
    result_list = []
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(ansible_options)
    result_list.append(args.tags)
    result_list.append(args.skip_tags)
    assert result_list == [['TAGS_RUN', 'TAGS_RUN'], ['TAGS_SKIP', 'TAGS_SKIP']]



# Generated at 2022-06-20 12:55:43.819214
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible-console')
    add_inventory_options(parser)
    (args, remainder) = parser.parse_known_args(['--list-hosts'])
    assert args.listhosts
    (args, remainder) = parser.parse_known_args(['-i', 'host[0-3]', '-l', 'host1'])
    assert args.subset == 'host1'
    assert args.inventory == ['host[0-3]']
    (args, remainder) = parser.parse_known_args(['-i', 'host[0-3]', '--inventory', 'host[4-6]'])
    assert args.subset == C.DEFAULT_SUBSET

# Generated at 2022-06-20 12:55:46.084409
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    test_parser = argparse.ArgumentParser()
    test_parser.prog = "ansible-test"
    assert test_parser.prog == "ansible-test"
    test_version = AnsibleVersion(test_parser)
    test_version(test_parser, test_parser.parse_args(), test_parser.prog)
    assert test_version is not None


# Generated at 2022-06-20 12:55:55.129086
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import io
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, _):
        sys.argv = ['ansible-config', '-v']
        from ansible.config.arguments import AnsibleParser

# Generated at 2022-06-20 12:56:06.377407
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    help_formatter = SortingHelpFormatter(sort_keys=True, width=10)
    # multiple options with different number of arguments
    parser = argparse.ArgumentParser(description="Empty", formatter_class=help_formatter)
    parser.add_argument('--host', action='store', nargs=1)
    parser.add_argument('--user', action='store_true')
    parser.add_argument('-k', action='store', type=int, help='int')
    parser.add_argument('-p', action='store', help='pass')
    parser.add_argument('-k2', action='store', nargs=2, help='int')
    parser.add_argument('--option', action='store', nargs=2, help='option')

# Generated at 2022-06-20 12:56:17.511140
# Unit test for function version
def test_version():
    """ version should return the version of Ansible """

# Generated at 2022-06-20 12:56:21.433273
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['--become-method', 'su', '--become-user', 'root'])
    assert args.become_method == 'su'
    assert args.become_user == 'root'



# Generated at 2022-06-20 12:56:27.746143
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(args=['-e', '@pytest.yml', '-e', '@pytest.yml'])
    assert args.extra_vars == ['@pytest.yml', '@pytest.yml']


# Generated at 2022-06-20 12:56:46.842817
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('ansible', usage='usage sample', desc='description sample', epilog='epilog sample')
    options = parser.parse_args([])
    assert options.verbosity == 0

# Generated at 2022-06-20 12:56:49.799110
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    p = argparse.ArgumentParser()
    p.add_argument('--foo', action=UnrecognizedArgument, default='test')
    args = p.parse_args('--foo abc'.split())
    assert args.unrecognized_arguments == 'test'



# Generated at 2022-06-20 12:56:53.463677
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = ['-f']
    options = parser.parse_args(args)
    assert options.force_handlers


# Generated at 2022-06-20 12:56:58.491514
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # fails when run as ansible-script, but passes when installed - unsure why
    test_path = '/foo/bar'
    test_path_expected = '@@/foo/bar'
    assert maybe_unfrack_path('@@')(test_path) == test_path_expected

#
# Parsing and objectification of ANSIBLE_CONFIG
#

# Generated at 2022-06-20 12:57:02.934625
# Unit test for function add_runas_options
def test_add_runas_options():
    from ansible.cli.arguments import AnsibleOptions, options_definition
    import unittest

    parser = AnsibleOptions(usage="%prog", options_list=options_definition)
    add_runas_options(parser)
    opts = parser.parse_args(["-b","--become-user","testuser"])
    #Test whether options are set correctly
    assert opts.become == True
    assert opts.become_method == "sudo"
    assert opts.become_user == "testuser"
    assert opts.ask_become_pass == True



# Generated at 2022-06-20 12:57:08.225098
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """Unit test for function add_tasknoplay_options."""
    parser = argparse.ArgumentParser(prog='ansible')
    add_tasknoplay_options(parser)
    b_args = parser.parse_args(['--task-timeout', '1'])
    assert b_args.task_timeout == 1



# Generated at 2022-06-20 12:57:15.756256
# Unit test for function add_vault_options
def test_add_vault_options():
    # default paths
    parser = create_base_parser('ansible-cmdb')
    add_vault_options(parser)
    options = parser.parse_args(['-i', ':memory:', '-o', 'html_fancy', '.'])
    assert options.vault_password_files == []
    assert options.ask_vault_pass == False
    options = parser.parse_args(['-i', ':memory:', '-o', 'html_fancy', '--vault-password-file=passfile', '.'])
    assert options.vault_password_files == ['passfile']
    assert options.ask_vault_pass == False

# Generated at 2022-06-20 12:57:22.789184
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    actual_help = parser.format_help()
    expected_help = 'usage: PROG [-h] [--task-timeout TASK_TIMEOUT]\n\noptional arguments:\n  -h, --help            show this help message and exit\n  --task-timeout TASK_TIMEOUT\n                        set task timeout limit in seconds, must be positive\n                        integer.\n'
    assert actual_help == expected_help



# Generated at 2022-06-20 12:57:33.114048
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_connect_options(parser)
    options = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'root', '-c', 'local', '-T', '10', '--ssh-common-args', 'ProxyCommand', '--ssh-extra-args', '-R'])
    assert options.private_key_file == os.path.expanduser('~/.ssh/id_rsa')
    assert options.remote_user == 'root'
    assert options.connection == 'local'
    assert options.timeout == 10
    assert options.ssh_common_args == 'ProxyCommand'
    assert options.ssh_extra_args == '-R'



# Generated at 2022-06-20 12:57:43.483980
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
  parser = MockParser()
  parser.add_argument('--foo', action=PrependListAction)
  # Test with a list
  values = ['bar']
  parser.parse_args(['--foo', 'bar'])
  expect_run_kwargs = {'foo': ['bar']}
  assert expect_run_kwargs == run_kwargs
  # Test with multiple values
  values = ['bar', 'baz']
  parser.parse_args(['--foo', 'bar', 'baz'])
  expect_run_kwargs = {'foo': ['baz', 'bar']}
  assert expect_run_kwargs == run_kwargs
  # Test with nested values
  parser.parse_args(['--foo', 'bar', 'baz', '--foo', '--foo', 'spam'])
 

# Generated at 2022-06-20 12:57:53.180304
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    import argparse

    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.print_help()



# Generated at 2022-06-20 12:58:01.884417
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path_test = unfrack_path()
    assert unfrack_path_test('/tmp/foo') == '/tmp/foo'
    assert unfrack_path_test('/tmp/foo-') == '/tmp/foo-'
    assert unfrack_path_test('/tmp/foo-/tmp/foo') == '/tmp/foo/tmp/foo'
    unfrack_path_test_sep = unfrack_path(True)
    assert unfrack_path_test_sep('/tmp/foo:/tmp/foo1') == ['/tmp/foo', '/tmp/foo1']
    assert unfrack_path_test_sep('/tmp/foo-:/tmp/foo1') == ['/tmp/foo-', '/tmp/foo1']

# Generated at 2022-06-20 12:58:13.901752
# Unit test for constructor of class UnrecognizedArgument

# Generated at 2022-06-20 12:58:23.767281
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    """Test method __call__ of class PrependListAction.
    """
    # Test with simple string.
    parser = argparse.ArgumentParser(
        prog='parser',
        usage='Usage of %(prog)s'
    )
    parser.add_argument(
        '--name',
        # Prepend given value to the choices list, passing empty string will
        # insert it to the front.
        action=PrependListAction,
        choices=['Alice', 'Bob']
    )

    def assert_name(args, expected):
        args = parser.parse_args(args.split())
        assert args.name == expected

    assert_name('--name', [])
    assert_name('--name John', ['John'])

# Generated at 2022-06-20 12:58:25.833431
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    assert parser



# Generated at 2022-06-20 12:58:30.565579
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    opts = parser.parse_args(['-e', 'key=value'])
    assert opts.extra_vars == ['key=value']
    opts = parser.parse_args(['-e', '{ "key": "value" }'])
    assert opts.extra_vars == ['{ "key": "value" }']
    opts = parser.parse_args(['-e', '@tmp.json'])
    assert opts.extra_vars == ['@tmp.json']
    assert opts.extra_vars != ['tmp.json']



# Generated at 2022-06-20 12:58:34.777283
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    # Test default
    args = parser.parse_args([])
    assert args.forks == C.DEFAULT_FORKS
    # Test forks
    args = parser.parse_args(['-f', '3'])
    assert args.forks == 3
    assert '-f' in args
    assert '3' in args
    # Test forks again
    args = parser.parse_args(['--forks', '5'])
    assert args.forks == 5
    assert '--forks' in args
    assert '5' in args
    # Test forks as a string
    args = parser.parse_args(['--forks', 'foo'])
    assert args.forks == 'foo'
    assert '--forks'

# Generated at 2022-06-20 12:58:42.729954
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """
    SortingHelpFormatter() constructs a sorted help formatter
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.epilog = 'example epilog'
    parser.formatter_class = SortingHelpFormatter
    # parser.parse_args()
    usage = parser.format_usage()
    assert usage == "usage: [-h] [-a] [-b]\n"

# Show configuration untis

# Generated at 2022-06-20 12:58:45.395017
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    class DummyParser:
        def exit(self):
            pass

    action = AnsibleVersion(None, None, None, None)
    action(DummyParser(), None, None)



# Generated at 2022-06-20 12:58:55.698574
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """test the add_runas_prompt_options function"""

    test_parser = argparse.ArgumentParser()
    add_runas_prompt_options(test_parser)
    test_args = test_parser.parse_args([])
    assert test_args.become_ask_pass is False
    assert test_args.become_password_file is None

    test_args = test_parser.parse_args(['--ask-become-pass'])
    assert test_args.become_ask_pass is True
    assert test_args.become_password_file is None

    test_args = test_parser.parse_args(['--become-password-file', 'some_mysterious_filename'])
    assert test_args.become_ask_pass is False
    assert test_args.bec

# Generated at 2022-06-20 12:59:10.183526
# Unit test for function create_base_parser
def test_create_base_parser():
    prog = "ansible --version"
    version_help = "show program's version number, config file location, configured module search path," \
                   " module location, executable location and exit"
    parser = create_base_parser(prog)

    def test_version():

        result = parser.parse_args(['--version'])
        assert result.version == 1
        assert result.verbosity == 0
        assert result.version_check == True
        assert result.inventory == None
        assert result.syntax == None
        assert result.listhosts == None
        assert result.subset == None
        assert result.module_path == None
        assert result.extra_vars == None
        assert result.tree == None
        assert result.ask_vault_pass == None
        assert result.output_file == None
        assert result.check

# Generated at 2022-06-20 12:59:13.858681
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = ['--forks', '200']
    opt_args = parser.parse_args(args)
    assert opt_args.forks == 200


# Generated at 2022-06-20 12:59:16.201841
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '~/somepath'
    beacon = "~/"
    assert maybe_unfrack_path(beacon)(test_path) == '~/somepath'


# Generated at 2022-06-20 12:59:20.846348
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_runtask_options(parser)
    assert parser.add_argument('-e', '--extra-vars', dest="extra_vars", action="append", type=maybe_unfrack_path('@'),
                        help="set additional variables as key=value or YAML/JSON, if filename prepend with @", default=[])
test_add_runtask_options()



# Generated at 2022-06-20 12:59:27.522345
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    def check_verbose(args, verbose):
        parser = argparse.ArgumentParser()
        add_verbosity_options(parser)

        try:
            options = parser.parse_args(args=args)
        except SystemExit:
            options = None

        assert options.verbosity == verbose

    check_verbose(['-v'], 1)
    check_verbose(['-vv'], 2)
    check_verbose(['-vvv'], 3)
    # -vvvv is connection debugging
    check_verbose(['-vvvv'], 3)



# Generated at 2022-06-20 12:59:38.183822
# Unit test for function add_runas_options
def test_add_runas_options():
    class Options(object):
        def __init__(self):
            self.inventory = None
            self.listhosts = None
            self.subset = None
            self.module_name = None
            self.module_path = None
            self.forks = None
            self.one_line = None
            self.tree = None
            self.ask_vault_pass = None
            self.vault_password_files = None
            self.new_vault_password_file = None
            self.output_file = None
            self.tags = None
            self.skip_tags = None
            self.ask_sudo_pass = None
            self.ask_su_pass = None
            self.sudo = None
            self.sudo_user = None
            self.su = None
            self.su_user = None


# Generated at 2022-06-20 12:59:43.215907
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', dest='version', action=AnsibleVersion)
    parser.prog = "ansible_version"
    args = parser.parse_args(['--version'])
    assert args.version is True



# Generated at 2022-06-20 12:59:50.674763
# Unit test for function version
def test_version():
    assert isinstance(version('test'), basestring)


#
# Default Options for certain OptionParsers
#

defaults = {
    'connection': 'smart',
    'module_path': '/path/to/mymodules',
    'forks': 5,
    'become': False,
    'become_method': 'sudo',
    'become_user': 'root',
    'check': False,
    'diff': False,
    'listhosts': None,
    'listtasks': None,
    'listtags': None,
    'syntax': None,
    'verbosity': 3,
    'inventory': '',
}

# Generated at 2022-06-20 13:00:00.334061
# Unit test for function add_meta_options
def test_add_meta_options():
    from units.compat.mock import patch
    from ansible.cli.arguments import OptionParser, add_meta_options
    optparser = OptionParser(None, usage="")
    add_meta_options(optparser)

    with patch('ansible.config.settings.DEFAULT_FORCE_HANDLERS', True):
        args = optparser.parse_args(['--force-handlers'])
        assert args.force_handlers is True

    with patch('ansible.config.settings.DEFAULT_FORCE_HANDLERS', False):
        args = optparser.parse_args(['--force-handlers'])
        assert args.force_handlers is True



# Generated at 2022-06-20 13:00:06.947557
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='test_add_check_options',
                                     formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve')
    add_check_options(parser)
    options, args = parser.parse_known_args(['-C', '-D'])
    assert options.check == True
    assert options.diff == True
    options, args = parser.parse_known_args(['--check', '--diff'])
    assert options.check == True
    assert options.diff == True
    options, args = parser.parse_known_args(['--syntax-check'])
    assert options.syntax == True


# Generated at 2022-06-20 13:00:26.990093
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args([])
    assert args.module_path is None


# Generated at 2022-06-20 13:00:28.714379
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    print(parser.print_help())


# Generated at 2022-06-20 13:00:30.656678
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', 'tmp'])
    assert args.tree == 'tmp'



# Generated at 2022-06-20 13:00:35.516512
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog="testprog")
    add_output_options(parser)
    assert parser.parse_args([]).tree == None
    assert parser.parse_args(['-t', 'cool']).tree == 'cool'



# Generated at 2022-06-20 13:00:44.743180
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, add_help=False)
    parser.add_argument("-b", action="store_true", default=False, help="-b option")
    parser.add_argument("--bar", action="store_true", default=False, help="--bar option")
    parser.add_argument("-a", action="store_true", default=False, help="-a option")
    parser.add_argument("--foo", action="store_true", default=False, help="--foo option")

# Generated at 2022-06-20 13:00:48.807748
# Unit test for function add_vault_options
def test_add_vault_options():
    # check that the parser has a group named 'vault'
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    group = parser.add_mutually_exclusive_group()
    assert group.name == "vault"
    assert group.title == "Vault Options"
    assert group.conflict_handler == "error"



# Generated at 2022-06-20 13:00:54.766394
# Unit test for function add_subset_options
def test_add_subset_options():
    """Unit test for function add_subset_options
    """
    parser = argparse.ArgumentParser(
        prog='unittest',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_subset_options(parser)
    # test if --tags and --skip-tags options is added
    parser_args = parser.parse_args(['-t', '--tags'])
    assert parser_args.tags == '--tags'
    parser_args = parser.parse_args(['--skip-tags'])
    assert parser_args.skip_tags == '--skip-tags'
    parser_args = parser.parse_args(['--skip-tags', '--tags'])
    assert parser_args.skip_tags == '--skip-tags'
    assert parser

# Generated at 2022-06-20 13:00:59.547981
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = vars(parser.parse_args(''))
    assert args['become'] == C.DEFAULT_BECOME, args['become']
    assert args['become_method'] == C.DEFAULT_BECOME_METHOD, args['become_method']
    assert args['become_user'] is None, args['become_user']
    assert args['become_ask_pass'] == C.DEFAULT_BECOME_ASK_PASS, args['become_ask_pass']
    assert args['become_ask_sudo_pass'] == C.DEFAULT_BECOME_ASK_SUDO_PASS, args['become_ask_sudo_pass']

# Generated at 2022-06-20 13:01:10.154393
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    original_actions = [ '-b', '--bb', '-aa', '--a']

    for a in original_actions:
        parser.add_argument(a)

    from ansible.cli.argparser.playbook import _add_playbook_common_options
    _add_playbook_common_options(parser)

    parser.add_argument('-c', '--check', action='store_true', help='Dummy')

    args = ['-h']
    parsed = parser.parse_args(args)

    help = parser.format_help()

# Generated at 2022-06-20 13:01:18.840416
# Unit test for function create_base_parser
def test_create_base_parser():
    from ansible.utils.parse_kv import parse_kv

    parser = create_base_parser("foo")
    try:
        parser.parse_args()
    except SystemExit:
        pass

    parser = create_base_parser("foo")
    try:
        parser.parse_args(["foo"])
    except SystemExit:
        pass

    parser = create_base_parser("foo")
    try:
        parser.parse_args(["--version"])
    except SystemExit:
        pass

    parser = create_base_parser("foo")
    try:
        parser.parse_args(["-v"])
    except SystemExit:
        pass

    parser = create_base_parser("foo")