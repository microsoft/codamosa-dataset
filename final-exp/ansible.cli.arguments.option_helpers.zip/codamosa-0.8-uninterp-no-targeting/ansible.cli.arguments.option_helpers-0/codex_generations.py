

# Generated at 2022-06-20 12:52:06.921099
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    parser.parse_args(['--private-key', 'key-file', '-u', 'user', '-c', 'connection', \
        '-T', 'timeout', '--ssh-common-args', 'ssh-common-args','--sftp-extra-args', \
        'sftp-extra-args','--scp-extra-args', 'scp-extra-args','--ssh-extra-args', \
        'ssh-extra-args','-k', 'ask-pass','--connection-password-file', \
        'connection-password-file'])


# Generated at 2022-06-20 12:52:20.195897
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.parse_args(['--vault-id', 'value', '-k', '--vault-password-file', 'value', '--ask-vault-password'])
    parser.parse_args(['--vault-id', 'value', '--vault-password-file', 'value'])
    parser.parse_args(['--vault-id', 'value'])
    parser.parse_args('--vault-id value --vault-password-file value'.split())
    parser.parse_args('--ask-vault-password --vault-id value'.split())

    # Test proper error message on missing vault-id

# Generated at 2022-06-20 12:52:25.315570
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, default=argparse.SUPPRESS)
    args = parser.parse_args(['--version'])
    assert args.version is None



# Generated at 2022-06-20 12:52:32.268399
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(['--private-key', '/tmp/id_rsa', '-u', 'ansible', '-c', 'local',
                                 '-T', '12', '-k', '--ssh-common-args', 'test', '--sftp-extra-args', 'test',
                                 '--scp-extra-args', 'test', '--ssh-extra-args', 'test'])
    assert options.private_key_file == "/tmp/id_rsa"
    assert options.remote_user == 'ansible'
    assert options.connection == 'local'
    assert options.timeout == 12
    assert options.ask_pass
    assert options.ssh_common_args == 'test'

# Generated at 2022-06-20 12:52:37.619036
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='ansible-version')
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, dest='version_test')
    args = parser.parse_args(['--version'])
    # no exception
    #print(args)
    #assert args.version_test is True
# END of unit test


# Generated at 2022-06-20 12:52:39.194080
# Unit test for function add_module_options
def test_add_module_options():
    '''
    Test case for function add_module_options.
    '''
    argument_parser = argparse.ArgumentParser()
    add_module_options(argument_parser)
    argument_parser.parse_args()



# Generated at 2022-06-20 12:52:47.741049
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    action = AnsibleVersion(
        option_strings=['--version'],
        dest='version',
        nargs=0,
        const=None,
        default=None,
        required=False,
        help="show program's version number and exit"
    )
    assert str(action) == "AnsibleVersion(option_strings=['--version'], dest='version', nargs=0, const=None, default=None, required=False, help='show program\'s version number and exit')"



# Generated at 2022-06-20 12:52:52.824788
# Unit test for function add_runtask_options
def test_add_runtask_options():
    '''Test the options for run task option'''
    import argparse
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""Performs operations on remote hosts""",
    )
    add_runtask_options(parser)
# Unit test ends


# Generated at 2022-06-20 12:53:04.741323
# Unit test for function add_connect_options
def test_add_connect_options():

    test_parser = argparse.ArgumentParser(add_help=False)
    add_connect_options(test_parser)

    # Test defaults for arguments
    options = test_parser.parse_args([])
    assert options.remote_user == C.DEFAULT_REMOTE_USER
    assert options.connection == C.DEFAULT_TRANSPORT
    assert options.timeout == C.DEFAULT_TIMEOUT
    assert options.ssh_common_args is None
    assert options.sftp_extra_args is None
    assert options.scp_extra_args is None
    assert options.ssh_extra_args is None
    assert options.connection_password_file == C.CONNECTION_PASSWORD_FILE
    assert options.ask_pass == C.DEFAULT_ASK_PASS
    assert options.private_key_file

# Generated at 2022-06-20 12:53:09.374969
# Unit test for function add_runtask_options
def test_add_runtask_options():
    import argparse
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    parser.parse_args(["-e", "opt1=val1", "-e", "@/tmp/info_file"])


# Generated at 2022-06-20 12:53:36.481665
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    assert parser.parse_args('-M /a:b:c/d/e'.split()).module_path == ['/a', '/b', '/c/d/e']
    assert parser.parse_args(''.split()).module_path is None

# Generated at 2022-06-20 12:53:38.245039
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog='test_add_module_options')
    add_module_options(parser)
    args = parser.parse_args()



# Generated at 2022-06-20 12:53:40.661485
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

#
# Functions to enable options for specific commands (and all sub commands)
#


# Generated at 2022-06-20 12:53:42.813613
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-20 12:53:48.318149
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'data/playbook'])
    assert args.basedir == 'data/playbook'



# Generated at 2022-06-20 12:53:59.480794
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    """Unit tests for method `__call__` of class `PrependListAction`.
    """
    import argparse, unittest
    class StubParser(object):
        def __init__(self, values):
            self._values = values
        def error(self, message):
            raise Exception(message)
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.parser = StubParser(values = {
                'key1': [1, 2, 3],
                'key2': [4, 5, 6],
            })
            self.action = PrependListAction(
                option_strings = [],
                dest = '',
            )
            self.values = None
            self.option_string = ''

# Generated at 2022-06-20 12:54:01.686453
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    parser.parse_args()



# Generated at 2022-06-20 12:54:10.917923
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--foo', action=UnrecognizedArgument, default='bar')
    options = parser.parse_args([])
    assert options.foo == 'bar'
    assert parser.parse_args(['--foo']).foo == 'bar'
    try:
        parser.parse_args(['--foo', 'bar'])
        assert False, "unexpected success"
    except SystemExit:
        pass
    try:
        parser.parse_args(['--unrecognized', 'bar'])
        assert False, "unexpected success"
    except SystemExit:
        pass

#
# Common OptParsers
#

# Generated at 2022-06-20 12:54:14.967145
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible_test._internal.utils.module_runner import sanitize_module_args, ModuleRunner
    mr = ModuleRunner(None, None)
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f1'])
    mr._parse_cli_args(args)
    assert mr.module_args['forks'] == '1'

    mr = ModuleRunner(None, None)
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f10'])
    mr._parse_cli_args(args)
    assert mr.module_args['forks'] == '10'

# Generated at 2022-06-20 12:54:19.932745
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser=argparse.ArgumentParser(
        prog='test_add_tasknoplay_options',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_tasknoplay_options(parser)
    parser.print_help()


# Generated at 2022-06-20 12:54:31.267183
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print("")
    parser = argparse.ArgumentParser()
    namespace = argparse.Namespace()
    values = argparse.Namespace()
    option_string = "--version"
    AnsibleVersion.__call__(__call__, parser, namespace, values, option_string)



# Generated at 2022-06-20 12:54:39.516108
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    #1. Create a standalone ArgumentParser with call to function add_tasknoplay_options
    parser = ArgumentParser()
    add_tasknoplay_options(parser)
    #2. Verify help message for --task-timeout option
    assert parser.format_help().find('task timeout limit') != -1, "did not find the expected help message for the --task-timeout option"


#
# Utilities for common options handling
#


# Generated at 2022-06-20 12:54:41.545563
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(shlex.split("-t /tmp/tree"))
    assert args.tree == "/tmp/tree"



# Generated at 2022-06-20 12:54:43.285933
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(description='add module options test')
    add_module_options(parser)



# Generated at 2022-06-20 12:54:45.469212
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    (options,args) = parser.parse_known_args()
    assert options.force_handlers is True
    assert options.flush_cache is None



# Generated at 2022-06-20 12:54:47.471314
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    a = AnsibleVersion(option_strings=['--version'])
    results = a.__call__(None, None, None)
    assert results is None



# Generated at 2022-06-20 12:54:51.093049
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    assert parser is not None



# Generated at 2022-06-20 12:55:01.823472
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    if not os.path.isabs('/'):
        # we are probably on a windows system where current directory
        # could be named `c:frobnicate`
        return
    assert maybe_unfrack_path('@')('@/some/path') == '@' + os.path.abspath('/some/path')
    assert maybe_unfrack_path('@')('@./some/path') == '@' + os.path.abspath('./some/path')
    assert maybe_unfrack_path('@')('@@/some/path') == '@@' + os.path.abspath('/some/path')

# Generated at 2022-06-20 12:55:07.559054
# Unit test for function add_connect_options
def test_add_connect_options():
    # TODO: use mock to test the argument of parse_args
    from ansible.cli import CLI
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(
        args=[],
        display=display,
    )
    cli._add_options(cli.parser)
    cli.options, cli.args = cli.parser.parse_args()


#   end add_conect_options


# Generated at 2022-06-20 12:55:18.555499
# Unit test for function add_inventory_options
def test_add_inventory_options():
    import unittest
    import tempfile
    import os
    class TestAddInventoryOptions(unittest.TestCase):
        def setUp(self):
            self.td = tempfile.mkdtemp()
            self.inventory_path = os.path.join(self.td, "inventory")
            os.close(os.open(self.inventory_path, os.O_CREAT))

            self.parser = argparse.ArgumentParser()
            add_inventory_options(self.parser)
            self.args = [ '-i', self.inventory_path]

        def tearDown(self):
            shutil.rmtree(self.td)

        def test_add_inventory_options_inventory_path_exist(self):
            args = self.parser.parse_args(self.args)
            self.assertTrue

# Generated at 2022-06-20 12:55:30.540090
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser()
    for option in [('-v','--verbose'),('-vv','--verbose'),('-v','--verbose'),('-vvvv','--verbose'),('-vvvvvvvvvv','--verbose'),('-q','--quiet'),('-C','--check')]:
        assert option in [tuple(action.option_strings) for action in parser._actions]
    assert version_help in [action.help for action in parser._actions]


# Generated at 2022-06-20 12:55:42.539966
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from os.path import basename
    from ansible.utils.path import unfrackpath
    # The number of arguments is wrong
    try:
        AnsibleVersion(1)
    except TypeError as e:
        pass
    # Without jinja2
    try:
        AnsibleVersion(0)(argparse.ArgumentParser(), [], None)
    except:
        pass
    # With jinja2 but no value
    try:
        AnsibleVersion(0)(argparse.ArgumentParser(), None, None)
    except:
        pass
    # With jinja2 and value
    try:
        os.system("unset PYTHONPATH")
        AnsibleVersion(1)(argparse.ArgumentParser(), [unfrackpath("/usr/bin/ansible")], None)
    except:
        pass

# Generated at 2022-06-20 12:55:47.394459
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'foobar'])
    assert hasattr(options, 'vault_ids')
    assert options.vault_ids == ['foobar']
    options = parser.parse_args(['--vault-id', 'baz', '--vault-id', 'quux'])
    assert hasattr(options, 'vault_ids')
    assert options.vault_ids == ['baz', 'quux']
    options = parser.parse_args(['--ask-vault-password'])
    assert hasattr(options, 'ask_vault_pass')

# Generated at 2022-06-20 12:55:49.777573
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version('ansible'))
    print(ansible_version)
    exit()



# Generated at 2022-06-20 12:55:54.598758
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    sys.argv[0] = './ansible'
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == None
    message = "./ansible " + __version__ + "\n"
    assert sys.stdout.getvalue() == message


#
# Common CLI options
#

# Generated at 2022-06-20 12:55:58.345771
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['-f', '22'])
    assert options.forks == 22



# Generated at 2022-06-20 12:56:05.076633
# Unit test for function ensure_value
def test_ensure_value():

    class Foo:
        pass
    foo = Foo()
    ensure_value(foo, 'bar', 'baz')
    assert(foo.bar == 'baz')

    foo.bar = []
    ensure_value(foo, 'bar', 'baz')
    assert(foo.bar == ['baz'])

    foo.bar = ['foo']
    ensure_value(foo, 'bar', 'baz')
    assert(foo.bar == ['foo'])


#
# Options parsers
#

# Generated at 2022-06-20 12:56:11.738215
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    test_action = UnrecognizedArgument(option_strings=['--test-option'], dest='test', const=True,
                                       default=None, required=False, help='unrecognized arguments: %s')
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--test-option', action=test_action)
    args = parser.parse_args(['--test-option'])
    assert args.test is True


#
# Private functions
#


# Generated at 2022-06-20 12:56:21.198175
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import io
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        version(prog='ansible-config')
    assert out.getvalue().strip() == __version__



# Generated at 2022-06-20 12:56:24.908407
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-config verify --list-options')
    parser.add_argument("--new-option")
    add_check_options(parser)
    options, args = parser.parse_known_args()
    assert hasattr(options, "check")
    assert hasattr(options, "syntax")
    assert hasattr(options, "diff")


# Generated at 2022-06-20 12:56:43.671318
# Unit test for function add_output_options
def test_add_output_options():
    class OptionStringParser(argparse.ArgumentParser):
        def __init__(self):
            super(OptionStringParser, self).__init__('prog')

        def parse_known_args(self, args=None, namespace=None):
            return super(OptionStringParser, self).parse_known_args(args=['-t', 'some/tree'], namespace=namespace)

    parser = OptionStringParser()
    add_output_options(parser)
    opts = parser.parse_args()
    assert opts.tree == 'some/tree'



# Generated at 2022-06-20 12:56:46.794925
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog='test')
    parser = add_verbosity_options(parser)
    args = parser.parse_args(args=['-v'])
    assert args.verbosity == 1
# Unit test end



# Generated at 2022-06-20 12:56:47.645899
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    assert AnsibleVersion



# Generated at 2022-06-20 12:56:54.266327
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    p = argparse.ArgumentParser()
    p.add_argument('--foo')
    p.add_argument('--bar')
    assert '--bar' < '--foo'
    assert p.format_help().index('--foo') < p.format_help().index('--bar')
    p = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    p.add_argument('--foo')
    p.add_argument('--bar')
    assert 'foo' > 'bar'
    assert p.format_help().index('--bar') < p.format_help().index('--foo')


# Generated at 2022-06-20 12:56:58.954514
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    p = argparse.ArgumentParser()
    add_tasknoplay_options(p)
    options = p.parse_args(['--task-timeout', '66'])
    assert options.task_timeout == 66
    options = p.parse_args([])
    assert options.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-20 12:56:59.422243
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    pass


# Generated at 2022-06-20 12:57:09.084714
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class Args:
        def __init__(self, foo=None):
            self.foo = foo

    args = Args()

    parser = argparse.ArgumentParser(argument_default=[])
    parser.add_argument('-f', '--foo', dest='foo', action=PrependListAction, default=[])
    parser.add_argument('args', nargs=argparse.REMAINDER)

    parser.parse_args(['-f', 'argf1', '--foo', 'argf2', '--', 'arg1', 'arg2'], namespace=args)
    assert args.foo == ['argf2', 'argf1']
    assert args.args == ['arg1', 'arg2']



# Generated at 2022-06-20 12:57:14.188447
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.parsing.dataloader import DataLoader
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    cliargs = parser.parse_args(['-e', 'foo=bar', '-e', '@varfile', '-e', '{ "qux": "quux" }'])
    assert cliargs.extra_vars == ['foo=bar', '@varfile', '{ "qux": "quux" }']



# Generated at 2022-06-20 12:57:16.321879
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_fork_options(parser)
    options = parser.parse_args(['-f', '10'])
    assert(options.forks == 10)


# Generated at 2022-06-20 12:57:16.849811
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass

# Generated at 2022-06-20 12:57:36.717669
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", action="store_true")
    parser.add_argument("-b", action="store_true")
    parser.add_argument("-c", action="store_true")
    t1 = parser.format_help()
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-a", action="store_true")
    parser.add_argument("-b", action="store_true")
    parser.add_argument("-c", action="store_true")
    t2 = parser.format_help()
    assert t1 != t2
    assert t2[:6] == "-a, -b"



# Generated at 2022-06-20 12:57:43.536830
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible', description='does stuff')
    add_runas_options(parser)
    options = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'foo'])
    assert options.become
    assert options.become_method == 'sudo'
    assert options.become_user == 'foo'
    assert not options.become_ask_pass



# Generated at 2022-06-20 12:57:54.392634
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(args=[])
    assert args.module_path == C.DEFAULT_MODULE_PATH
    args = parser.parse_args(args=['--module-path', 'mymodulepath:mymodulepath'])
    assert args.module_path == 'mymodulepath:mymodulepath:%s' % C.DEFAULT_MODULE_PATH
    # Test using a directory as module path
    args = parser.parse_args(args=['--module-path', '/'])
    assert args.module_path == '/'
    # Test using a relative directory as module path
    args = parser.parse_args(args=['--module-path', 'relative_dir'])
    assert args.module_path == os.path

# Generated at 2022-06-20 12:57:57.450053
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    result = maybe_unfrack_path('@@')('@@/abc')
    assert result == '@@' + unfrackpath('/abc')


#
# Specialized CLI parse functions
#

# Generated at 2022-06-20 12:58:01.559245
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from argparse import Namespace
    parser = AnsibleCliParser()
    args = Namespace()
    args.new_data = ['value1']
    values = ['value2']
    args.new_data.__class__ = list
    parser.append_list('new_data', values, args)
    assert args.new_data == ['value2', 'value1']
#
# Utility functions
#



# Generated at 2022-06-20 12:58:11.320286
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(description="Testing for method __call__ of class UnrecognizedArgument")
    parser.add_argument('--foo', action=UnrecognizedArgument, help='foo help')
    try:
        unparsed = parser.parse_args([r'--foo',r'This is the argument of the option \'--foo\'!\n'])
    except SystemExit:
        pass
    try:
        unparsed = parser.parse_args([r'--foolest\n', r'This is the argument of the option \'--foolest\'!\n'])
    except SystemExit:
        pass


# Generated at 2022-06-20 12:58:20.751737
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('prog', usage='usage', desc="desc", epilog="epilog")
    assert parser.prog == 'prog'
    assert parser._actions[0].const == version(prog='prog')
    assert parser._actions[0].nargs == 0
    assert parser._actions[0].help == 'show program\'s version number, config file location, configured module search path, module location, executable location and exit'
    assert parser.description == 'desc'
    assert parser.usage == 'usage'
    assert parser.epilog == 'epilog'
    assert parser.conflict_handler == 'resolve'




# Generated at 2022-06-20 12:58:24.328416
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    obj = UnrecognizedArgument(option_strings=[], dest='test', default=True, required=True, help='test')
    assert obj.nargs == 0



# Generated at 2022-06-20 12:58:31.442257
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    argv = ['-v']
    args = parser.parse_args(argv)
    test_AnsibleVersion = AnsibleVersion(args)
    assert test_AnsibleVersion.__call__(parser, args, option_string='-v') == ansible.constants.__version__


#
# Common methods shared by commands
#


# Generated at 2022-06-20 12:58:33.788508
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    action = AnsibleVersion(option_strings=['--version'])
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=action)
    args = parser.parse_args(['--version'])


# Generated at 2022-06-20 12:58:56.513645
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # Instantiation
    try:
        UnrecognizedArgument(option_strings=['-m'], dest='module_path', help='DEPRECATED. Ansible modules/action plugins search path')
    except TypeError:
        assert False, "UnrecognizedArgument constructor fails with default arguments"

    # Instantiation with non-default arguments
    try:
        UnrecognizedArgument(option_strings=['-m'], dest='module_path', const=False, default='/home/ansible', help='DEPRECATED. Ansible modules/action plugins search path')
    except TypeError:
        assert False, "UnrecognizedArgument constructor fails with non-default arguments"



# Generated at 2022-06-20 12:59:06.259781
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = AnsibleVersion('--version', action='version', version='test_version')
    parser = argparse.ArgumentParser()
    parser.add_argument = Mock()
    parser.add_argument.return_value = ansible_version
    parser.exit = Mock()
    parser.prog = 'test_prog'
    ansible_version(parser, namespace=None, values=None, option_string=None)
    parser.add_argument.assert_called_once_with('--version', action='version', version='test_version')
    parser.exit.assert_called_once_with()


#
# Top-level option parsing
#

# Generated at 2022-06-20 12:59:12.256044
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_meta_options(parser)
    return parser.parse_args(['--force-handlers', '--flush-cache'])



# Generated at 2022-06-20 12:59:16.080790
# Unit test for function ensure_value
def test_ensure_value():
    class MockNamespace(object):
        pass
    mock_namespace = MockNamespace()
    ensure_value(mock_namespace, "foo", "bar")
    assert getattr(mock_namespace, "foo", None) == "bar"



# Generated at 2022-06-20 12:59:26.744633
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.cli import CLI
    import io
    import contextlib

    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    test_prog = os.path.join(path, 'test', 'cli', 'test_ansible-playbook')


# Generated at 2022-06-20 12:59:30.617399
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_tasknoplay_options(parser)
    assert_equal(parser._actions[-1].option_strings, ['--task-timeout'])



# Generated at 2022-06-20 12:59:35.072346
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():

    parser = argparse.ArgumentParser()
    parser.set_defaults(func=None)
    parser.add_argument('--version', action=AnsibleVersion, nargs=0,
                        help='Show version number and exit')

    return parser

# Generated at 2022-06-20 12:59:40.516678
# Unit test for function add_inventory_options
def test_add_inventory_options():
  parser = argparse.ArgumentParser()
  add_inventory_options(parser)
  opts = parser.parse_args(["-i","--inventory", "--inventory-file", "dest='inventory'", "action=append", "--list-hosts", "dest=listhosts", "action=store_true", "-l", "--limit", "dest=subset", "help=further limit selected hosts to an additional pattern"])
  assert opts.inventory == 'dest=inventory'
  assert opts.listhosts == True
  assert opts.subset == 'further limit selected hosts to an additional pattern'


# Generated at 2022-06-20 12:59:44.030261
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    args = ['--verbose', '--verbose', '--verbose']
    options = parser.parse_args(args)
    assert options.verbosity == 3

# Generated at 2022-06-20 12:59:52.208666
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='test_add_connect_options')
    add_connect_options(parser)
    assert parser.get_default('private_key_file') == C.DEFAULT_PRIVATE_KEY_FILE, 'default value of private_key_file'
    assert parser.get_default('remote_user') == C.DEFAULT_REMOTE_USER, 'default value of remote_user'
    assert parser.get_default('connection') == C.DEFAULT_TRANSPORT, 'default value of connection'
    assert parser.get_default('timeout') == C.DEFAULT_TIMEOUT, 'default value of timeout'
    assert parser.get_default('ask_pass') == C.DEFAULT_ASK_PASS, 'default value of ask_pass'

# Generated at 2022-06-20 13:00:23.972564
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.utils.display import Display
    from ansible.cli import CLI
    from ansible.config.manager import ensure_type
    display = Display()
    options = CLI.base_parser(None, usage="%prog some_module.name", runas_opts=True, async_opts=True, output_opts=True)
    print(options)
    #assert options.seconds ==0
    #assert options.poll_interval == 0

# Generated at 2022-06-20 13:00:28.279039
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser('test-tool')
    add_check_options(parser)
    opts = parser.parse_args(['--check', '--syntax-check', '--diff'])
    assert opts.check
    assert opts.syntax
    assert opts.diff

# Generated at 2022-06-20 13:00:34.347542
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # set up a parser to test the SortingHelpFormatter
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        add_help=False)
    # use a list of strings to prevent any sort operation
    expected_option_strings = ['--verbose', '-v']
    parser.add_argument(expected_option_strings[0],
                        expected_option_strings[1],
                        dest='verbose',
                        action='count',
                        default=0,
                        help='turn on verbose output')
    # render the help message
    out = parser.format_help()
    # extract the table of options from help message
    lines = out.split('\n')
    start = lines.index('optional arguments:')
    lines = lines[start + 2:]
    stop = lines.index

# Generated at 2022-06-20 13:00:41.109191
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    output = "2.9.2"
    class_under_test = AnsibleVersion()
    parser = argparse.ArgumentParser()
    if sys.version_info[0] > 2:
        unittest.mock.patch('ansible.release.version', return_value=output)
    else:
        unittest.mock.patch('ansible.release.version', return_value=output)

    namespace = argparse.Namespace()
    result = class_under_test(parser, namespace, None, None)
    assert result == None


# Generated at 2022-06-20 13:00:49.746712
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.errors import AnsibleOptionsError
    from ansible.cli.arguments import OptionParser

    parser = OptionParser(
        usage='usage: %prog [options]',
        connection='connection',
        remote_user='remote_user',
        private_key_file='private_key_file',
        verbosity='verbosity',
        ask_pass='ask_pass',
        timeout='timeout',
        connection_password_file='connection_password_file',
    )

    add_connect_options(parser)

    # test that the parser accepts --ask-pass
    options = parser.parse_args(['-k'])
    assert options.ask_pass

    # test that the parser accepts --connection-password-file

# Generated at 2022-06-20 13:00:52.532798
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """Test to check that an exception is raised if nargs is 0"""
    try:
        PrependListAction(option_strings='--test',
                          dest='test',
                          nargs=0)
    except ValueError:
        pass



# Generated at 2022-06-20 13:00:57.135309
# Unit test for function add_fork_options
def test_add_fork_options():
    my_parser = argparse.ArgumentParser(prog='argparse_test')
    add_fork_options(my_parser)
    options = my_parser.parse_args([])
    assert options.forks == C.DEFAULT_FORKS
    options = my_parser.parse_args(['--forks', '5'])
    assert options.forks == 5


# Generated at 2022-06-20 13:01:01.393422
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    ua = UnrecognizedArgument(['-f', '--foo'], 'foo', nargs=1)
    assert ua.option_strings == ['-f', '--foo']
    assert ua.dest == 'foo'
    assert ua.nargs == 1


#
# Default to parsing only first CLI arg as the command
#

# Generated at 2022-06-20 13:01:06.375585
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser("test")
    add_meta_options(parser)
    args = parser.parse_args("")
    assert args.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert args.flush_cache == False
    assert args.tags == C.DEFAULT_TAGS
    assert args.skip_tags == C.DEFAULT_SKIP_TAGS


# Generated at 2022-06-20 13:01:11.089863
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    test_parser = argparse.ArgumentParser()
    add_runas_prompt_options(test_parser)
    return test_parser
ansible_options_parser = test_add_runas_prompt_options()

