

# Generated at 2022-06-20 12:52:05.799965
# Unit test for function add_basedir_options
def test_add_basedir_options():
    '''test add_basedir_options'''
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    arguments = parser.parse_args('-b /home/test'.split())
    assert arguments.basedir == '/home/test'



# Generated at 2022-06-20 12:52:14.473478
# Unit test for function add_module_options
def test_add_module_options():
  parser = argparse.ArgumentParser()
  add_module_options(parser)
  args = parser.parse_args(['-M','/home/joe/func/ansible/lib/ansible/modules/','--module-path','/another/path'])
  assert args.module_path == ['/home/joe/func/ansible/lib/ansible/modules/','/another/path']


# Generated at 2022-06-20 12:52:24.037095
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-1a')
    parser.add_argument('-1b')
    parser.add_argument('-1c')
    parser.add_argument('--1a')
    parser.add_argument('--1b')
    parser.add_argument('--1c')
    parser.add_argument('-2a')
    parser.add_argument('-2b')
    parser.add_argument('-2c')
    parser.add_argument('--2a')
    parser.add_argument('--2b')
    parser.add_argument('--2c')
    parser.add_argument('-3a')
    parser.add_argument('-3b')

# Generated at 2022-06-20 12:52:31.383818
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options, args = parser.parse_known_args()
    assert options.private_key_file == unfrackpath(C.DEFAULT_PRIVATE_KEY_FILE)
    assert options.remote_user == C.DEFAULT_REMOTE_USER
    assert options.connection == C.DEFAULT_TRANSPORT
    assert options.timeout == C.DEFAULT_TIMEOUT



# Generated at 2022-06-20 12:52:43.490297
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='foo')
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '/path/to/identity'])
    assert args.private_key_file == '/path/to/identity'
    assert args.remote_user == 'root'
    assert args.connection == 'smart'
    assert args.timeout == 10
    assert args.ssh_common_args is None
    assert args.sftp_extra_args is None
    assert args.scp_extra_args is None
    assert args.ssh_extra_args is None
    assert args.ask_pass is False
    assert args.connection_password_file == '/etc/ansible/connection_password'


# Generated at 2022-06-20 12:52:45.291183
# Unit test for function add_fork_options
def test_add_fork_options():
    def create_parser(**kwargs):
        parser = argparse.ArgumentParser()
        add_fork_options(parser, **kwargs)
        return parser

    parser = create_parser()
    args = parser.parse_args(['--forks', '10'])
    assert args.forks == 10



# Generated at 2022-06-20 12:52:52.495181
# Unit test for function add_inventory_options
def test_add_inventory_options():
    class Object(object):
        pass
    args = Object()
    args.verbosity = 0
    parser = argparse.ArgumentParser(
        prog='ansible', epilog='Use "ansible-playbook --help" for more information'
    )
    add_inventory_options(parser)
    parser.parse_args(['-i', 'test_inventory_options'], args)
    assert args.inventory == ['test_inventory_options']
    assert args.listhosts is False
    assert args.subset is None



# Generated at 2022-06-20 12:52:57.798841
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-a")
    parser.add_argument("-c")
    parser.add_argument("-b")
    parser._get_kwargs()
    assert operator.attrgetter("option_strings")(parser._actions[0]) == ("-a",)
    assert operator.attrgetter("option_strings")(parser._actions[1]) == ("-b",)
    assert operator.attrgetter("option_strings")(parser._actions[2]) == ("-c",)


# Generated at 2022-06-20 12:53:05.849290
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    old_stdout = sys.stdout
    sys.stdout = open('stdout_file', 'w')
    parser = argparse.ArgumentParser()
    action = AnsibleVersion(option_strings=[], dest='version')
    action(parser, namespace=None, values=None, option_string=None)
    parser.parse_args(args=[])
    sys.stdout.close()
    sys.stdout = old_stdout
    assert os.path.exists('stdout_file')
    os.remove('stdout_file')



# Generated at 2022-06-20 12:53:14.179680
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value = "~/test"
    beacon = '~'
    answer = maybe_unfrack_path(beacon)(value)
    assert answer == value, "invalid value"

    value = "~/test"
    beacon = '~/'
    answer = maybe_unfrack_path(beacon)(value)
    assert answer == value, "invalid value"

    value = "~/test"
    beacon = '~/t'
    answer = maybe_unfrack_path(beacon)(value)
    assert answer == value, "invalid value"


# Generated at 2022-06-20 12:53:40.742324
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runtask_options(parser)

    args = parser.parse_args(['-e', 'a=b', '-e', 'c=d', '-e', '@/a/b/c', '-e', '@/a/b/d', '--extra-vars', '{"a":"b","c":"d"}'])
    assert args.extra_vars == [('a', 'b'), ('c', 'd'), ('a', 'b'), ('c', 'd'), ('a', 'b'), ('c', 'd')]

    args = parser.parse_args(['--extra-vars', '@non-existing-file.yaml'])

# Generated at 2022-06-20 12:53:42.896817
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='ansible-doc')
    result = add_subset_options(parser)
    assert result == 0


# Generated at 2022-06-20 12:53:55.660731
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__(): # pylint: disable=no-self-use
    """
    :return:
    """
    from collections import namedtuple
    from ansible.constants import DOCUMENTATION_URL
    from ansible.module_utils.six.moves import StringIO
    out = StringIO()
    sys.stdout = out

    ans_arg = UnrecognizedArgument(option_strings=['--help'], dest='help', const=True, default=None, required=False,
                                   help='Show this help message and exit')
    parser = argparse.ArgumentParser()
    args = namedtuple('args', 'display_args_to_stdout')
    args.display_args_to_stdout = True

    ans_arg(parser, args, '--help')
    sys.stdout = sys.__stdout__


# Generated at 2022-06-20 12:54:00.172075
# Unit test for function unfrack_path
def test_unfrack_path():
    current_path = os.path.dirname(os.path.realpath(__file__))
    assert unfrack_path()(os.path.join(current_path, 'test_utils.py')) == os.path.join(current_path, 'test_utils.py')



# Generated at 2022-06-20 12:54:07.688244
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_module_options(parser)

    # None values
    options = parser.parse_args(args=[])
    assert options.module_path == None

    # Multiple path values
    options = parser.parse_args(args=['-M', '/path/to/modules', '-M', '/path/to/more/modules'])
    assert '/path/to/modules:/path/to/more/modules' == options.module_path


# Generated at 2022-06-20 12:54:09.674151
# Unit test for function add_runtask_options
def test_add_runtask_options():
    fake_parser= argparse.ArgumentParser()
    add_runtask_options(fake_parser)



# Generated at 2022-06-20 12:54:13.680410
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args('--foo a --foo b'.split())
    assert args.foo == ['b', 'a']



# Generated at 2022-06-20 12:54:21.647180
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path()('relative/path') == 'relative/path'
    assert unfrack_path()('~/relative/path') == os.path.expanduser('~/relative/path')
    assert unfrack_path(pathsep=True)('/etc/ansible:/dev/null') == ['/etc/ansible', '/dev/null']
    assert unfrack_path(pathsep=True)('relative/path:~/relative/path') == ['relative/path', os.path.expanduser('~/relative/path')]



# Generated at 2022-06-20 12:54:27.551224
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """ Unit test for function add_tasknoplay_options """
    mock_parser = argparse.ArgumentParser()
    add_tasknoplay_options(mock_parser)
    assert mock_parser.get_default('task_timeout') == '3600'
    assert mock_parser.get_default('task_timeout') == str(C.TASK_TIMEOUT)



# Generated at 2022-06-20 12:54:29.676713
# Unit test for function add_async_options
def test_add_async_options():
    assert add_async_options == argparse.ArgumentParser.add_arguments



# Generated at 2022-06-20 12:54:59.129075
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    parser.add_argument('--is-test', action='store_true')
    parser.add_argument('--z-test', action='store_true')
    parser.add_argument('--a-test', action='store_true')
    parser.add_argument('--no-test', action='store_true')
    namespace = parser.parse_args([])  # Dummy call - help is generated from arguments
    help_t = namespace.__doc__
    parser = argparse.ArgumentParser(prog='test', formatter_class=argparse.HelpFormatter)
    parser.add_argument('--is-test', action='store_true')

# Generated at 2022-06-20 12:55:08.836016
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--arg1', default='1')
    parser.add_argument('--arg2', default='2')
    parser.add_argument('--arg3', default='3')
    OutputValue = parser.format_help()
    #
    # Output is:
    #
    # usage: [-h] [--arg1 ARG1] [--arg2 ARG2] [--arg3 ARG3]
    #
    # optional arguments:
    #   -h, --help   show this help message and exit
    #   --arg1 ARG1  (default: 1)
    #   --arg2 ARG2  (default: 2)
    #   --arg3 ARG3  (default

# Generated at 2022-06-20 12:55:13.696595
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # Construct a parser
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', dest='version', action=AnsibleVersion)

    # Fake the args to have the --version
    namespace, argv = parser.parse_known_args(['--version'])

    # Make sure the args were set
    assert namespace.version is True



# Generated at 2022-06-20 12:55:16.938275
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    parser.parse_args()



# Generated at 2022-06-20 12:55:24.403410
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    from ansible.cli import CLI

    test_args = ['ansible', '--help']
    test_parser = CLI.base_parser(test_args)

    test_parser.add_argument('-t', '--targets', dest='targets', action=UnrecognizedArgument, nargs='*', default=None,
                              required=False, help=argparse.SUPPRESS)

    # This test ensures that the constructor of the UnrecognizedArgument class
    # is working without raising an exception
    test_parser.parse_known_args(test_args)

#
# Parser for version control commands
#

# Generated at 2022-06-20 12:55:36.676059
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from unittest.mock import patch
    from ansible.cli.arguments import add_runtask_options, AnsibleOptions
    from ansible.module_utils.common.text.formatters import human_to_bytes

    mocked_parser = (
        AnsibleOptions()
    )
    mocked_parser.add_argument = (
        patch.object(AnsibleOptions, 'add_argument'),
        patch.object(AnsibleOptions, 'add_argument').start()
    )

    # Check if all extra_vars options are added correctly
    add_runtask_options(mocked_parser)

    # Check if extra_vars options are added correctly without type

# Generated at 2022-06-20 12:55:46.649516
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    args = ['--version']
    stdout = sys.stdout
    sys.stdout = sys.stderr
    stdin = sys.stdin
    sys.stdin = open(os.devnull, 'r')
    with open('/dev/null', 'w') as fnull:
        sys.stderr = fnull
        try:
            parser = argparse.ArgumentParser()
            parser.add_argument('--version', action=AnsibleVersion, nargs=0)
            args = parser.parse_args(args)
        except SystemExit:
            pass
        sys.stdout = stdout
        sys.stdin = stdin
        sys.stderr = stdout



# Generated at 2022-06-20 12:55:50.562531
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)

    assert(parser.parse_args(['-o']).one_line == True)
    assert(parser.parse_args(['-t', './']).tree == './')


# Generated at 2022-06-20 12:55:57.830167
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # test inventory host path and comma separated host list
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'abc'])
    assert args.inventory == ['abc']
    args = parser.parse_args(['-i', 'abc', '-i', 'def'])
    assert args.inventory == ['abc', 'def']
    args = parser.parse_args(['-i', 'abc,def'])
    assert args.inventory == ['abc,def']
    args = parser.parse_args(['-i', 'abc,def', '-i', 'ghi,jkl'])
    assert args.inventory == ['abc,def', 'ghi,jkl']
    # test list-hosts and limit
    args = parser.parse_args

# Generated at 2022-06-20 12:56:02.220768
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # Get the args we need to pass to argparse.ArgumentParser
    parser = argparse.ArgumentParser(description='Test class UnrecognizedArgument')
    parser.add_argument('--verbose', action=UnrecognizedArgument)
    args = parser.parse_args(['--verbose'])


# Generated at 2022-06-20 12:56:23.777595
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_tasknoplay_options(parser)
    parser.parse_args(['--task-timeout', '60'])
    parser.parse_args(['--task-timeout', '0'])


# Generated at 2022-06-20 12:56:26.598732
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    assert C.DEFAULT_VERBOSITY == 0



# Generated at 2022-06-20 12:56:29.929190
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    argv = "--verbose -vvv".split()
    opt = parser.parse_args(argv)
    assert opt.verbosity == 3



# Generated at 2022-06-20 12:56:34.652929
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.parse_args(['--module-path', '/foo:/bar', '--module-path', '/baz'])
    assert parser.module_path == ['/baz', '/foo', '/bar']



# Generated at 2022-06-20 12:56:39.392809
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog="ansible", usage="%(prog)s [options]", formatter_class=SortingHelpFormatter)
    add_connect_options(parser)
    return parser


# Generated at 2022-06-20 12:56:48.409252
# Unit test for function add_meta_options
def test_add_meta_options():
    test_parser = argparse.ArgumentParser()
    add_meta_options(test_parser)
    expected = dict(force_handlers=C.DEFAULT_FORCE_HANDLERS,flush_cache=False)
    test_args = []
    args=test_parser.parse_args(test_args)
    for option in expected.keys():
        if not hasattr(args, option):
            raise AssertionError("add_meta_options() does not contain expected option %s" % option)
    for option in expected.keys():
        if getattr(args, option) != expected[option]:
            raise AssertionError("add_meta_options() does not set expected value %s.%s=%s"%(args, option, expected[option]))



# Generated at 2022-06-20 12:56:51.171303
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])

    assert args.force_handlers
    assert args.flush_cache


# Generated at 2022-06-20 12:56:51.747343
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    pass



# Generated at 2022-06-20 12:56:55.137169
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser("ansible-test")
    add_verbosity_options(parser)
    options = parser.parse_args(args=["-vvvv"])
    assert options.verbosity == 4



# Generated at 2022-06-20 12:56:57.262055
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    args = add_verbosity_options(parser)
    assert args is parser



# Generated at 2022-06-20 12:57:13.015480
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict
    display = Display()
    options = ImmutableDict(
        display=display,
        DEFAULT_LOAD_CALLBACK_PLUGINS=True
    )
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--prepend', action=PrependListAction, dest='list')

    # Test basic functionality
    args = parser.parse_args(['-p', '1', '--prepend', '2', '--prepend', '3'])
    assert args.list == ['3', '2', '1']

    # Test with nargs='+'
    parser = argparse.ArgumentParser()

# Generated at 2022-06-20 12:57:18.895257
# Unit test for function add_vault_options
def test_add_vault_options():
    # Initialize objects for test
    parser = argparse.ArgumentParser()
    FakeResult = namedtuple('FakeResult', ['ask_vault_pass', 'vault_password_files'])
    fake_result = FakeResult(False, [])
    # Invoke function add_vault_options
    add_vault_options(parser)
    # Perform assertions
    # Check parser
    assert isinstance(parser, argparse.ArgumentParser), "parser is not an argparse.ArgumentParser"
    # Check parser.add_argument
    _, actual_call1 = parser.add_argument.call_args_list[0]
    assert actual_call1['dest'] == 'vault_ids', "parser.add_argument dest is not vault_ids"

# Generated at 2022-06-20 12:57:28.995922
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    opts = parser.parse_args('-k -u root --ssh-common-args="hostname" --sftp-extra-args="-a" --scp-extra-args="-l" --ssh-extra-args="-R"'.split())
    assert opts.ask_pass is True
    assert opts.remote_user == 'root'
    assert opts.ssh_common_args == 'hostname'
    assert opts.sftp_extra_args == '-a'
    assert opts.scp_extra_args == '-l'
    assert opts.ssh_extra_args == '-R'


# Generated at 2022-06-20 12:57:34.192754
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-c')
    parser.add_argument('-b')
    parser.add_argument('-a')

    help_text = parser.format_help()
    print(help_text)
    assert help_text.splitlines()[1] == '  -a  -b  -c'



# Generated at 2022-06-20 12:57:45.652254
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-password-file', 'vault_password_file'])
    assert len(args.vault_password_files) == 1
    assert args.vault_password_files[0] == 'vault_password_file'
    args = parser.parse_args(['--vault-password-file', 'vault_password_file', '--vault-password-file', 'vault_password_file2'])
    assert len(args.vault_password_files) == 2
    assert args.vault_password_files[0] == 'vault_password_file'
    assert args.vault_password_files[1] == 'vault_password_file2'




# Generated at 2022-06-20 12:57:46.658735
# Unit test for function add_module_options
def test_add_module_options():
    p = argparse.ArgumentParser()
    add_module_options(p)
    return p



# Generated at 2022-06-20 12:57:56.956215
# Unit test for function add_connect_options
def test_add_connect_options():
    """Tests add_connect_options"""
    parser = argparse.ArgumentParser(prog='')
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', '/dev/null'])
    assert args.private_key_file == '/dev/null'

    args = parser.parse_args(['--private-key', '/dev/null', '-T', '2', '--ssh-common-args', '--foo', '--sftp-extra-args', '--bar', '-k', '--scp-extra-args', '--baz', '--ssh-extra-args', '--fob'])
    assert args.private_key_file == '/dev/null'
    assert args.timeout == 2
    assert args.ssh_common_args == '--foo'

# Generated at 2022-06-20 12:57:57.742578
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    a = AnsibleVersion()


# Generated at 2022-06-20 12:58:01.848297
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class TestParser(argparse.ArgumentParser):
        def print_help(self):
            print(self.format_help())

    parser = TestParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--b')
    parser.add_argument('--a')
    parser.add_argument('-f')
    parser.print_help()
    assert 1 == 1


# Generated at 2022-06-20 12:58:05.073040
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='ansible')
    version = AnsibleVersion(option_strings=('--version',))
    version(parser, None, None)
    assert parser.exit.call_count == 1



# Generated at 2022-06-20 12:58:20.957803
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    runas_group = parser.add_argument_group('Privilege Escalation Options')
    add_runas_prompt_options(parser, runas_group)
    assert parser.parse_known_args(['-K'])[1] == []
    assert parser.parse_known_args(['--ask-become-pass'])[1] == []
    assert parser.parse_known_args(['--become-password-file', 'somefile'])[1] == ['somefile']
    assert parser.parse_known_args(['--become-pass-file', 'somefile'])[1] == ['somefile']



# Generated at 2022-06-20 12:58:27.411800
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Env var ANSIBLE_CONFIG is defined, unfrackpath applied
    os.environ['ANSIBLE_CONFIG'] = '/tmp/does_not_exist/ansible.cfg'
    assert maybe_unfrack_path('@')('@ansible.cfg') == '/tmp/does_not_exist/ansible.cfg'
    # Env var ANSIBLE_CONFIG is not defined, string is unchanged
    os.environ['ANSIBLE_CONFIG'] = ''
    assert maybe_unfrack_path('@')('@ansible.cfg') == '@ansible.cfg'
    # Env var ANSIBLE_CONFIG is defined, leading @ is missing, string is unchanged
    os.environ['ANSIBLE_CONFIG'] = '/tmp/does_not_exist/ansible.cfg'

# Generated at 2022-06-20 12:58:34.387741
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'one.ini'])
    assert options.inventory == ['one.ini']
    options = parser.parse_args(['--inventory', 'two.ini'])
    assert options.inventory == ['two.ini']
    options = parser.parse_args(['--inventory', 'two.ini', '--inventory-file', 'three.ini'])
    assert options.inventory == ['two.ini', 'three.ini']



# Generated at 2022-06-20 12:58:38.200169
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args(['--playbook-dir', 'test/data'])
    assert args.playbook_dir == 'test/data'



# Generated at 2022-06-20 12:58:42.943141
# Unit test for function add_meta_options
def test_add_meta_options():
    
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    (options, args) = parser.parse_known_args()
    
    assert options.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert options.flush_cache == None


# Generated at 2022-06-20 12:58:45.782068
# Unit test for function add_output_options
def test_add_output_options():
    """
    add_output_options test cases
    """
    args = ['--tree', 'test']
    assert Options(listify_lookup_plugin_terms=False).parse(args)[0].tree == 'test'



# Generated at 2022-06-20 12:58:49.246365
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options = parser.parse_args(['--force-handlers'])
    assert options.force_handlers == True


# Generated at 2022-06-20 12:59:00.595222
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    test_args = ['--ask-become-pass']
    args = parser.parse_args(test_args)
    assert 'become_ask_pass' in args
    assert args.become_ask_pass == True
    test_args = ['--become-password-file', 'unittest_become_password']
    args = parser.parse_args(test_args)
    assert 'become_password_file' in args
    assert args.become_password_file == 'unittest_become_password'
    test_args = ['--ask-become-pass', '--become-password-file', 'unittest_become_password']

# Generated at 2022-06-20 12:59:07.081169
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    av = AnsibleVersion(option_strings = ['-v'],
                        dest = 'version',
                        const = 'version',
                        default = argparse.SUPPRESS,
                        required = False,
                        help = None,
                        nargs = argparse.OPTIONAL,
                        type = None)

    parser = argparse.ArgumentParser()
    parser.add_argument('-v', action = av)

    args = parser.parse_args(['-v'])
    args.version()

#
# Base Classes
#

# Generated at 2022-06-20 12:59:15.962934
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ['', ''] == list(map(unfrack_path()(os.pathsep), ['', '']))
    assert [os.path.join('foo', 'bar'), 'spam'] == list(map(unfrack_path(True)(os.pathsep), ['foo/bar', '/spam']))
    assert [os.path.join('foo', 'bar'), 'eggs'] == list(map(unfrack_path(True)(os.pathsep), ['foo/bar', 'spam/../eggs']))


# Generated at 2022-06-20 12:59:26.474717
# Unit test for function add_basedir_options
def test_add_basedir_options():
    my_parser = argparse.ArgumentParser()
    add_basedir_options(my_parser)
    args = my_parser.parse_args(['--playbook-dir', 'foo'])
    assert args.basedir == 'foo'
#
# Functions to add pre-canned options to an OptionParser
#



# Generated at 2022-06-20 12:59:31.378238
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    print("\n".join(["%s = %s" % (k, v) for k, v in parser.__dict__.items()]))
test_add_tasknoplay_options()


# Generated at 2022-06-20 12:59:39.307888
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.cli.arguments import AnsibleCLIArguments
    arg_set = ['--tags=tag1','--tags=tag2','--skip-tags=tag3','--skip-tags=tag4']
    parser = AnsibleCLIArguments.base_parser(constants=C)
    add_subset_options(parser)
    arg_dict = vars(parser.parse_known_args(arg_set, None)[0])
    assert arg_dict['tags'] == ['tag1', 'tag2']
    assert arg_dict['skip_tags'] == ['tag3', 'tag4']

#
# Functions to add common options to an OptionsParser
#


# Generated at 2022-06-20 12:59:46.606152
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir','/abc'])
    assert options.basedir == '/abc'
    options = parser.parse_args(['--playbook-dir','/abc/'])
    assert options.basedir == '/abc'
    try:
        options = parser.parse_args(['--playbook-dir','/abc/../'])
        assert False
    except SystemExit:
        assert True



# Generated at 2022-06-20 12:59:51.494944
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, dest='foo')
    try:
        check_args = parser.parse_args('--foo 1'.split())
    except SystemExit as e:
        assert e.code == 2, "Did not throw error: unrecognized arguments: --foo"
    else:
        raise AssertionError('Did not throw error: unrecognized arguments: --foo')



# Generated at 2022-06-20 13:00:01.851145
# Unit test for function add_vault_options
def test_add_vault_options():
    # Test for option vault_ids
    parser = create_base_parser('test')
    add_vault_options(parser)
    with pytest.raises(SystemExit):
        parser.parse_args(['--vault-id'])
    with pytest.raises(SystemExit):
        parser.parse_args(['--vault-id', 'unittest_vault_id'])
    options = parser.parse_args(['--vault-id', 'unittest-vault-id'])
    assert options.vault_ids == ['unittest-vault-id']
    options = parser.parse_args(['--vault-id', 'unittest-vault-id', '--vault-id', 'unittest-vault-id2'])
    assert options.vault_

# Generated at 2022-06-20 13:00:08.745033
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import ansible.constants as C

    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action=PrependListAction, type=str, default=[])
    parser.add_argument('--aa', action='store_true', default=False)
    parser.add_argument('--bb', action='store_false', default=False)
    parser.add_argument('--cc', default='ccc')
    parser.add_argument('--dd', default=['ddd'])
    parser.add_argument('--ee', default=dict(eee='eee'))
    parser.add_argument('--ff', default=set(['fff']))
    parser.add_argument('--gg', default=5)
    parser.add_argument('--hh', default=5.5)
    parser.add

# Generated at 2022-06-20 13:00:14.209587
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options, args = parser.parse_known_args(['-e', '@foo.yml', '-e', 'key1=value1'])
    assert options.extra_vars == ['@foo.yml', 'key1=value1'], options.extra_vars



# Generated at 2022-06-20 13:00:19.408979
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    # Test that instantiating the object does not throw an exception
    x = UnrecognizedArgument(['-x'], 'dest')



# Generated at 2022-06-20 13:00:27.098801
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """Note: this is not a formal test. It just prints the code examples
    written in its docstring.
    """
    class Args: pass
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", "--append", action=PrependListAction, help="append some strings.")
    args = Args()
    args.append = []
    parser.parse_args(['-a1', '-a2', '-a3'], namespace=args)
    args.append = []
    parser.parse_args(['-a1', '-a2', '-a[1,2]'], namespace=args)
    parser.parse_args(['-a1', '-a', '-a3'], namespace=args)
    print("Done.")
# if __name__ == '__main__':

# Generated at 2022-06-20 13:00:39.199292
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(["--ask-become-pass","--become-password-file=/tmp/passfile"])
    assert args.become_ask_pass == True
    assert args.become_password_file == "/tmp/passfile "


# Generated at 2022-06-20 13:00:40.966333
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_instance = SortingHelpFormatter()
    assert isinstance(test_instance, argparse.HelpFormatter)


# Generated at 2022-06-20 13:00:43.917123
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args(['-b', '--become-method=su', '--become-user=root'])
    assert options.become == True
    assert options.become_method == 'su'
    assert options.become_user == 'root'



# Generated at 2022-06-20 13:00:47.421174
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    opts = parser.parse_args(['-t', 'tag1', '--tags', 'tag2', '--skip-tags', 'skip_tag1', '--skip-tags', 'skip_tag2'])
    assert opts.tags == ['tag1', 'tag2']
    assert opts.skip_tags == ['skip_tag1', 'skip_tag2']



# Generated at 2022-06-20 13:00:50.949786
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('-U', action=UnrecognizedArgument)
    parser.parse_args('-U'.split())
    try:
        parser.parse_args('-U foo'.split())
    except SystemExit as e:
        rc = e.code
    assert rc == 2



# Generated at 2022-06-20 13:00:52.876176
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    assert parser.get_default("tags") == C.TAGS_RUN
    assert parser.get_default("skip_tags") == C.TAGS_SKIP

# Generated at 2022-06-20 13:01:01.947357
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    def sut(actions):
        parser = argparse.ArgumentParser()
        formatter = SortingHelpFormatter()
        parser.add_argument('foo')
        parser.add_argument('bar')
        parser.add_argument('-f', '--foo')
        parser.add_argument('-b', '--bar')
        parser.add_argument('-c', '--baz')
        parser.add_argument('-x', '-y', '--qux')
        parser.add_argument('-1', '-2', '-3', '--quux')
        formatter.add_arguments(actions)
        return parser._actions


# Generated at 2022-06-20 13:01:13.004194
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    group = parser.add_argument_group()
    group.add_argument('--foo', action=UnrecognizedArgument, default='x', choices=['x', 'y'])
    group.add_argument('--bar', action='store_true')

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser.parse_args(['--foo', 'x', '--bar'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser.parse_args(['--foo', 'x', '--bogus'])

# Generated at 2022-06-20 13:01:16.682711
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_meta_options(parser)
    args = parser.parse_args(['--flush-cache'])
    print(args.flush_cache)
    assert args.flush_cache
# Called to add a vars_prompt option to an OptionParser

# Generated at 2022-06-20 13:01:18.165449
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = Mock()
    add_runas_options(parser)
    parser.add_argument_group.assert_called_with("Privilege Escalation Options", "control how and which user you become as on target hosts")



# Generated at 2022-06-20 13:01:30.644166
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    argv = []
    options, argv = parser.parse_known_args(argv)
    assert options.one_line is None
    assert options.tree is None
    argv = []
    argv = ['--one-line']
    options, argv = parser.parse_known_args(argv)
    assert options.one_line
    assert options.tree is None
    argv = []
    argv = ['--tree', '/tmp/']
    options, argv = parser.parse_known_args(argv)
    assert options.one_line is None
    assert options.tree == '/tmp/'
    argv = []
    argv = ['--one-line', '--tree', '/tmp/']
    options