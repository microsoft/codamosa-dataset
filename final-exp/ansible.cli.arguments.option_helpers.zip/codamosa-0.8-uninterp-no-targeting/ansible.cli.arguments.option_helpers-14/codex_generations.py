

# Generated at 2022-06-20 12:52:19.149125
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion(nargs=0)
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert True



# Generated at 2022-06-20 12:52:21.834333
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--s', action=UnrecognizedArgument)
    parser.parse_args(['--s', 'hello'])



# Generated at 2022-06-20 12:52:29.001942
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    script = "/tmp/ansible-script"
    usage = "usage"
    desc = "desc"
    prog = "prog"
    parser = create_base_parser(prog, usage, desc)
    add_verbosity_options(parser)
    parsed = parser.parse_args([script, '-vvvv', '-v'])
    assert parsed.verbosity == 6



# Generated at 2022-06-20 12:52:37.094180
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # issue#11075
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action='append', type=int)
    parser.add_argument('--test2', action=PrependListAction, type=int)
    args = parser.parse_args(['--test', '1', '--test', '2', '--test2', '3', '--test2', '4'])
    assert args.test == [1, 2]
    assert args.test2 == [4, 3]


#
# Common OptionGroups and Options
#

# Generated at 2022-06-20 12:52:41.346851
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(description="test_add_module_options")
    add_module_options(parser)
    options, args = parser.parse_known_args(['-M', '~/ansible/backend', '-M', '/tmp/test-collections/ansible_collections/awx/test'])
    assert options.module_path == ['/tmp/test-collections/ansible_collections/awx/test', '~/ansible/backend']
    C.config.set_config_value('DEFAULT_MODULE_PATH', '/home/testuser/ansible/modules')
    options, args = parser.parse_known_args(['-M', '/tmp/test-collections/ansible_collections/awx/test'])

# Generated at 2022-06-20 12:52:53.339886
# Unit test for function add_meta_options
def test_add_meta_options():
    # The following two lines replace argparse.ArgumentParser(parser.py) because
    # if it is imported from there, then options like --version, --help will already be added
    # and the options related with meta tasks will not be added by function add_meta_options().
    # The details can be seen in the function __init__() in parser.py
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    parser.description = "description"
    add_meta_options(parser)
    args = parser.parse_args([])

    assert args.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert args.flush_cache == False
    args = parser.parse_args(["--force-handlers"])
    assert args.force_handlers

# Generated at 2022-06-20 12:53:01.476277
# Unit test for function create_base_parser
def test_create_base_parser():
    print("\nRunning function tests for create_base_parser()")
    test_parser = create_base_parser(prog='test', usage='test', desc='test', epilog='test')
    assert test_parser.prog == 'test'
    assert test_parser.formatter_class == SortingHelpFormatter
    assert test_parser.epilog == 'test'
    assert test_parser.description == 'test'
    assert test_parser.conflict_handler == 'resolve'



# Generated at 2022-06-20 12:53:06.873544
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    fix_parser = argparse.ArgumentParser()
    fix_parser.add_argument("--list", action=PrependListAction, metavar='VAL', default=[])

#
# Options parsers for commands
#

# Generated at 2022-06-20 12:53:11.592461
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # FIXME: argparse.Namespace or argparse.Action
    parser = argparse.ArgumentParser()
    parser.add_argument('-f')
    parser.add_argument('-g')
    parser.parse_known_args(['-f', '-g', '-a'])



# Generated at 2022-06-20 12:53:17.385852
# Unit test for function add_check_options
def test_add_check_options():
    parser = prepare_for_func()
    add_check_options(parser)
    options = parser.parse_args()
    assert options.check == False
    assert options.syntax == False
    assert options.diff == 'always'
    options = parser.parse_args(['--check','--syntax-check','--diff'])
    assert options.check == True
    assert options.syntax == True
    assert options.diff == 'always'



# Generated at 2022-06-20 12:53:32.557454
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve',)
    add_verbosity_options(parser)
    raw = parser.parse_args(['-vvvv'])
    assert raw.verbosity == 4


# Generated at 2022-06-20 12:53:35.242556
# Unit test for function add_output_options
def test_add_output_options():
    parser = create_base_parser('TestParser')
    add_output_options(parser)
    options = parser.parse_args(['-o'])
    assert options.one_line is True


# Generated at 2022-06-20 12:53:41.575859
# Unit test for function add_connect_options
def test_add_connect_options():
    import os,sys
    #sys.argv.append("--private-key=private_key_path")
    #sys.argv.append("-u")
    #sys.argv.append("test_user")
    #sys.argv.append("-c")
    #sys.argv.append("test_connection")
    #sys.argv.append("-T")
    #sys.argv.append("test_timeout")
    #sys.argv.append("--ssh-extra-args")
    #sys.argv.append("-R")
    #sys.argv.append("--sftp-extra-args")
    #sys.argv.append("-f")
    #sys.argv.append("--scp-extra-args")
    #sys.argv.append("-l

# Generated at 2022-06-20 12:53:48.106074
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', action=AnsibleVersion,
                        help='Ansible version')
    parser.prog = 'ansible script'
    args = parser.parse_args(['-v'])
    assert args.version == None



# Generated at 2022-06-20 12:53:59.351251
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_vault_options(parser)

    args = parser.parse_args(['--vault-password-file', '@vault_pass', '--ask-vault-password', '--vault-id', 'myvault'])
    assert args.vault_password_files == ['@vault_pass']
    assert args.ask_vault_pass is True
    assert args.vault_ids == ['myvault']

    args = parser.parse_args(['--ask-vault-pass'])
    assert args.vault_password_files == []
    assert args.ask_vault_pass is True
    assert args.vault_ids == []


#
# Options for specific commands


# Generated at 2022-06-20 12:54:09.851535
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    test_list = []
    # option_strings, dest, nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None
    arg_action = PrependListAction(option_strings = ['-p', '--prepend'],
                                   dest = 'test_list',
                                   default = test_list,
                                   )
    assert arg_action.type is list
    assert arg_action.default is test_list
    assert arg_action.required is False
    assert arg_action.nargs is not 0

    # Unit test for __call__ of class PrependListAction
    test_parser = argparse.ArgumentParser()

# Generated at 2022-06-20 12:54:20.262559
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument("--foo", nargs='*', default=[])
    parser.add_argument("--bar", action=PrependListAction, nargs='*', default=[])
    args = parser.parse_args("--foo foo --bar bar".split())
    assert args.foo == ['foo']
    assert args.bar == ['bar']
    args = parser.parse_args("--foo foo --foo bar --bar bar".split())
    assert args.foo == ['foo', 'bar']
    assert args.bar == ['bar', 'foo']
    args = parser.parse_args("--foo foo --foo bar --bar bar --bar bar2".split())
    assert args.foo == ['foo', 'bar']
    assert args.bar == ['bar', 'bar2', 'foo']


# Generated at 2022-06-20 12:54:21.275277
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    # print(parser.format_help())



# Generated at 2022-06-20 12:54:25.760032
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    '''Unit test for constructor of class AnsibleVersion.'''
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])

#
# Shared parser
#

# Generated at 2022-06-20 12:54:32.352187
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.parse_args(args=['--vault-id', 'cheese'])
    parser.parse_args(args=['--vault-id', 'apple', 'cheese'])
    parser.parse_args(args=['--vault-id', 'apple', 'cheese', '--vault-id', 'onion'])
    # no password files
    parser.parse_args(args=[])
    # one password file
    parser.parse_args(args=['--vault-password-file', 'cheese'])
    # one password file and one ask
    parser.parse_args(args=['--vault-password-file', 'cheese', '--ask-vault-password'])
    # three password files

# Generated at 2022-06-20 12:55:11.452835
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert 'Privilege Escalation Options' in parser._action_groups[0].title
    assert ('-b', '--become') in parser._actions

    group = parser._action_groups[1]
    assert 'Privilege Escalation Prompting Options' in group.title
    assert ('-K', '--ask-become-pass') in group._actions
    assert ('--ask-sudo-pass') in parser._actions
    assert ('-k', '--ask-pass') in parser._actions
    assert not parser._mutually_exclusive_groups



# Generated at 2022-06-20 12:55:12.957565
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_fork_options(parser)
    args = parser.parse_args(['-f', '10'])
    assert args.forks == 10



# Generated at 2022-06-20 12:55:13.820430
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass



# Generated at 2022-06-20 12:55:16.746702
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='test')
    add_meta_options(parser)
    result = parser.parse_args([])
    assert result.force_handlers
    assert not result.flush_cache
    result = parser.parse_args(['--force-handlers'])
    assert result.force_handlers
    result = parser.parse_args(['--flush-cache'])
    assert result.flush_cache


# Generated at 2022-06-20 12:55:21.180484
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()
    namespace.foo = [0, 1]
    a = PrependListAction(option_strings=[], dest='foo', nargs=1)
    a(parser=None, namespace=namespace, values=[2], option_string=None)
    #assert namespace.foo == [2, 0, 1]


# Generated at 2022-06-20 12:55:31.833119
# Unit test for function add_runtask_options
def test_add_runtask_options():
    import argparse
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['--extra-vars', 'first=1', '--extra-vars', 'second=2', '--extra-vars', '@varfile', '--extra-vars', '{"variable": 3}'])
    assert args.extra_vars == [{'first': '1'}, {'second': '2'}, {'variable': 3}]
    args = parser.parse_args(['--extra-vars', 'first=1', '--extra-vars', 'second_file=@varfile', '--extra-vars', 'variable=3'])

# Generated at 2022-06-20 12:55:37.485174
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(description="Empty parser")
    add_async_options(parser)
    options, args = parser.parse_known_args(['-B', '1', '-P', '2'])
    assert options.seconds == 1
    assert options.poll_interval == 2



# Generated at 2022-06-20 12:55:40.420730
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog="Test Parser")
    add_output_options(parser)
    assert parser.format_help()


# Generated at 2022-06-20 12:55:51.308775
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    vars = VariableManager(loader=None)
    vars.extra_vars = dict()
    vars.host_vars = HostVars(vars, "")
    play_context = PlayContext()

    play = Play.load(dict(name="test", hosts='localhost'), vars=vars, options=dict(), play_context=play_context, loader=None)

    parser = argparse.ArgumentParser(description='ansible-console parser')

# Generated at 2022-06-20 12:55:58.308836
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from ansible.cli.file_reader import FileReader
    from ansible.cli.arguments.default_config import DefaultConfigCLI
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars_file

    def test_configuration(x1, x2, z1, z2, z3):
        assert(x1 == z1)
        assert(x2 == z2)

    # Setup the environment
    cwd = os.getcwd()
    os.chdir(os.path.abspath(os.path.dirname(__file__) + '/../../'))

# Generated at 2022-06-20 12:56:09.281161
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    parser.parse_args(['-f', '10'])



# Generated at 2022-06-20 12:56:14.344533
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    import argparse
    prog = 'demo_prog'
    ansible_version = version(prog)

    # Generate a parser and add version argument
    parser = argparse.ArgumentParser(prog=prog)
    parser.add_argument('-v', '--version', action=AnsibleVersion)

    # Unit test for __call__()
    # if --version is passed in, it shall print version and exit
    try:
        sys.argv.append('--version')
        args = parser.parse_args()
    except SystemExit as e:
        assert e.code == 0
    finally:
        sys.argv.remove('--version')


# Generated at 2022-06-20 12:56:19.321150
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    assert parser.format_help().startswith('usage:')


#
# OptionParsers for commands used by bin/ansible-playbook
#

# Generated at 2022-06-20 12:56:19.906466
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    pass


# Generated at 2022-06-20 12:56:26.488180
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from units.compat.mock import patch
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    with patch('argparse.ArgumentParser.add_argument_group') as mock_argparse:
        mock_argparse.return_value = parser
        with patch('argparse.ArgumentParser.add_mutually_exclusive_group') as mock_mutually_exclusive_group:
            mock_mutually_exclusive_group.return_value = parser
            with patch('argparse.ArgumentParser.add_argument') as mock_add_argument:
                mock_add_argument.return_value = parser
                with patch('argparse.ArgumentParser.set_defaults') as mock_set_defaults:
                    mock_set_defaults.return_value = parser
                    add_run

# Generated at 2022-06-20 12:56:28.719159
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser('test_add_inventory_options')
    add_inventory_options(parser)
    options = parser.parse_args()

# Generated at 2022-06-20 12:56:34.871856
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    from ansible.release import __version__
    beacon = C.DEFAULT_BECOME_METHOD
    assert maybe_unfrack_path(beacon)('/home/username/secret') == '/home/username/secret'
    assert maybe_unfrack_path(beacon)('$ANSIBLE_VAULT;/home/username/secret') == C.DEFAULT_BECOME_METHOD + '/home/username/secret'



# Generated at 2022-06-20 12:56:39.584750
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    opt = parser.parse_args(['-o','-t'])
    assert opt.one_line is True
    assert opt.tree is not None


# Generated at 2022-06-20 12:56:45.537161
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    test_parser = argparse.ArgumentParser()
    add_tasknoplay_options(test_parser)
    assert test_parser._actions[-1].dest == "task_timeout"
    assert test_parser._actions[-1].type == int
    assert test_parser._actions[-1].default == C.TASK_TIMEOUT
    assert test_parser._actions[-1].help == "set task timeout limit in seconds, must be positive integer."



# Generated at 2022-06-20 12:56:49.159662
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args('-K --become-password-file=../t/unit/ansible_module_ping/become_pass'.split())
    assert args.become_ask_pass is True
    assert args.become_password_file == '../t/unit/ansible_module_ping/become_pass'



# Generated at 2022-06-20 12:57:10.176868
# Unit test for function add_vault_options
def test_add_vault_options():
    """
    Check whether function of add_vault_options works well
    """
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    assert '--vault-id' in parser._actions
    assert '--ask-vault-password' in parser._actions
    assert '--vault-password-file' in parser._actions


#
# Option Parsing
#


# Generated at 2022-06-20 12:57:13.586519
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert args.one_line == True
    args = parser.parse_args(['-t', '/tmp/dir'])
    assert args.tree == '/tmp/dir'



# Generated at 2022-06-20 12:57:16.126316
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args = parser.parse_args()
    assert args.basedir == C.config.get_config_value('PLAYBOOK_DIR')



# Generated at 2022-06-20 12:57:26.415238
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():

    from ansible.cli.arguments import EnsuredAttributeDict

    action = PrependListAction(
        option_strings=["-A", "--append"],
        dest='append_list',
        nargs='*',
        const=None,
        default=['default', 'value'],
        type=None,
        choices=None,
        required=False,
        help=None,
        metavar=None
    )
    parser = argparse.ArgumentParser()
    action.container = parser

    namespace = EnsuredAttributeDict()
    values = []
    option_string = None

    # test empty value
    action(parser, namespace, values, option_string)
    assert namespace['append_list'] == ['default', 'value']

    # test with value
    values = [1, 2]

# Generated at 2022-06-20 12:57:27.674799
# Unit test for function add_meta_options
def test_add_meta_options():
    import optparse
    parser = optparse.OptionParser()
    add_meta_options(parser)
    options, args = parser.parse_args()


# Generated at 2022-06-20 12:57:33.919881
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)

    with pytest.raises(SystemExit):
        options = parser.parse_args(['--tags', 'x', '--skip-tags', 'y'])

    with pytest.raises(SystemExit):
        options = parser.parse_args(['--tags', 'x', '--skip-tags', 'y', '--skip-tags', 'z'])



# Generated at 2022-06-20 12:57:35.510829
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args()
    assert args.forks == C.DEFAULT_FORKS



# Generated at 2022-06-20 12:57:39.480393
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', action=UnrecognizedArgument, help='unrecognized')
    try:
        parser._parse_known_args(['-u', 'this_is_unrecognized'])
    except SystemExit:
        pass



# Generated at 2022-06-20 12:57:43.164445
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    parser.parse_args('--version'.split())



# Generated at 2022-06-20 12:57:46.198039
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test_create_base_parser")
    assert str(parser) == "create_base_parser"



# Generated at 2022-06-20 12:58:06.997566
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        prog='test_add_check_options',
        conflict_handler='resolve',
    )
    add_check_options(parser)
    parser.parse_args(['-C', '--syntax-check', '-D'])
# Run unit test
test_add_check_options()



# Generated at 2022-06-20 12:58:13.026532
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class args(object):
        def __init__(self, prog):
            self.prog = prog
    _parser = args('bin/ansible')
    ansible_version = AnsibleVersion()
    ansible_version(_parser, namespace=None, values=None, option_string=None)
    assert _parser.exit_value == 0



# Generated at 2022-06-20 12:58:16.748613
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from argparse import Namespace
    parser = argparse.ArgumentParser(description="Argparse")
    add_inventory_options(parser)
    arg = parser.parse_args()
    assert arg.listhosts is False
    assert arg.inventory is None
    assert arg.subset == C.DEFAULT_SUBSET
    arg = parser.parse_args(['-i', 'foo', '-l', 'bar', '--inventory-file', 'baz', '--list-hosts', '--inventory', 'baz'])
    assert arg.listhosts is True
    assert arg.inventory == ['foo', 'baz', 'baz']
    assert arg.subset == 'bar'



# Generated at 2022-06-20 12:58:18.741527
# Unit test for function add_runas_options
def test_add_runas_options():
    """test function add_runas_options"""
    my_option = add_runas_options()



# Generated at 2022-06-20 12:58:26.277289
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-b')
    parser.add_argument('-a')
    parser.add_argument('-d')
    parser.add_argument('-c')
    try:
        parser.add_argument('--test')
    except Exception:
        # --test is not allowed in 2.6
        # as argparse does not recognize negative integers as valid dest names
        # or in CI testing environments where argparse is older than 2.7
        # so we ignore the failure in these cases.
        pass
    help_str = parser.format_help()
    # verify that help was formatted in the correct order
    assert help_str.index('-a') < help_str.index('-b')

# Generated at 2022-06-20 12:58:32.170526
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """Test to check whether the function add_tasknoplay_options is working"""
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    options = parser.parse_args(args=[])
    assert options.task_timeout == C.TASK_TIMEOUT


# Generated at 2022-06-20 12:58:42.474262
# Unit test for function add_check_options
def test_add_check_options():
    issue_num=156
    issue_description="Add unit tests for add_check_options"
    parser = argparse.ArgumentParser(
        prog="unit_test",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    expected_output=["-C","--check","-D","--diff"]
    actual_output=[]
    add_check_options(parser)
    for arg in parser._actions:
        if arg.option_strings[0] in expected_output:
            actual_output.append(arg.option_strings[0])
    if len(list(set(expected_output) - set(actual_output))) == 0:
        print("{0}:{1}".format(issue_num,issue_description))
        sys.exit(0)

# Generated at 2022-06-20 12:58:50.481452
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    import StringIO

    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        prog='test_SortingHelpFormatter'
    )
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b2', action='store_false')
    parser.add_argument('-b1', action='store_true')

    stream = StringIO.StringIO()
    parser.print_help(stream)
    helpstr = stream.getvalue()
    assert helpstr.startswith('usage: test_SortingHelpFormatter [-h] [-a] [-b1] [-b2] [-c]')



# Generated at 2022-06-20 12:58:51.177522
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
  assert True



# Generated at 2022-06-20 12:58:54.182524
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args()
    assert options.basedir == C.config.get_config_value('PLAYBOOK_DIR')



# Generated at 2022-06-20 12:59:16.081678
# Unit test for function add_async_options
def test_add_async_options():
    """Create an options parser for testing add_async_options"""
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args()

    assert not options.poll
    assert not options.seconds

    options = parser.parse_args(['-P', '20'])
    assert options.poll == 20
    assert not options.seconds

    options = parser.parse_args(['-B', '20'])
    assert not options.poll
    assert options.seconds == 20



# Generated at 2022-06-20 12:59:19.503271
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    p = argparse.ArgumentParser()
    p.add_argument('--test', action=UnrecognizedArgument)
    p.parse_args(['--test'])


#
# Option Parsers
#

# Generated at 2022-06-20 12:59:23.549015
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    args = parser.parse_args(['--foo', 'bar'])



# Generated at 2022-06-20 12:59:27.105424
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo-bar', action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args(['--foo-bar'])

# Generated at 2022-06-20 12:59:37.821279
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import mock
    persons = "harry,ron,hermione"
    p = argparse.ArgumentParser(prog='Persons')
    p.add_argument('--persons', action=PrependListAction, nargs='+')
    args = p.parse_args(['--persons', persons])
    args.persons[0] = "snape"
    with mock.patch.object(p, 'print_help') as print_help:
        p.parse_args(['--persons', persons])
        print_help.assert_not_called()
    with mock.patch.object(p, 'print_help') as print_help:
        p.parse_args(['--persons', persons, '--persons', 'snape'])
        print_help.assert_not_called()

# Generated at 2022-06-20 12:59:48.531898
# Unit test for function version
def test_version():
    """ Unit test for version() """
    from ansible.constants import VERSION

    with open(os.devnull, 'w') as null_fd:
        sys.stderr.write('\n')
        sys.stderr = null_fd
        if sys.version_info < (3,):
            import __builtin__
            __builtin__._ = '_'
        else:
            import builtins
            builtins._ = '_'

# Generated at 2022-06-20 12:59:49.072793
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    assert AnsibleVersion.__call__()



# Generated at 2022-06-20 12:59:52.799728
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument, help='foo help')
    args = parser.parse_args(['--foo', 'bar'])
    parser.exit()


# Generated at 2022-06-20 12:59:56.610032
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    args = add_tasknoplay_options
    args.add_argument('--task-timeout', type=int, dest="task_timeout", action="store", default=str(C.TASK_TIMEOUT),
                        help="set task timeout limit in seconds, must be positive integer.")



# Generated at 2022-06-20 13:00:01.615138
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()

    add_inventory_options(parser)

    parser.add_argument.assert_any_call(
        '-i',
        '--inventory',
        '--inventory-file',
        action='append',
        dest='inventory', 
        help='specify inventory host path or comma separated host list. --inventory-file is deprecated'
    )

# Generated at 2022-06-20 13:00:40.242714
# Unit test for function add_module_options
def test_add_module_options():
    parser = create_base_parser('test')
    add_module_options(parser)

    opts = parser.parse_args(['-M', './modules'])
    assert opts.module_path == './modules'
    assert opts.connection == 'smart'

    opts = parser.parse_args(['-M', './modules', '-M', './mymodules'])
    assert opts.module_path == ['./mymodules', './modules']

    opts = parser.parse_args(['-M', './modules', '-M', './mymodules:./foobar', '-M', './baz'])
    assert opts.module_path == ['./baz', './foobar', './mymodules', './modules']


# Generated at 2022-06-20 13:00:42.759460
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', action=UnrecognizedArgument)
    parser.parse_args(['-u'])



# Generated at 2022-06-20 13:00:46.501227
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='test parser')
    add_runas_options(parser)
    args = parser.parse_args(['--become', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'
    return parser



# Generated at 2022-06-20 13:00:54.554693
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # create the parser only the first time
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--frob')
    parser.add_argument('--foof')
    parser.add_argument('--foobar')
    # capture help content
    parser.print_help()
    # create the help content with lines
    helpcontent = parser.format_help().split('\n')
    # remove first 4 lines (usage, description, arguments, -----)
    helpcontent = helpcontent[4:-1]
    # remove first column with option_strings
    helpcontent = [line[33:] for line in helpcontent]
    # remove whitespaces at beginnig of each line
    helpcontent

# Generated at 2022-06-20 13:00:58.572697
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    # assert that add_runas_options also calls add_runas_prompt_options
    parser.add_argument('--become-pass', dest='become_pass', help="run become with this password")
    args = parser.parse_args(args=['-b', '--become-user=root', '--become-pass=test'])

    assert vars(args) == dict(become=True, become_method=C.DEFAULT_BECOME_METHOD, become_user='root',
                              become_pass='test', become_ask_pass=False)



# Generated at 2022-06-20 13:01:02.632691
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, args = parser.parse_known_args(["-C", "-D", "--syntax-check"])
    assert options.check == True
    assert options.syntax == True
    assert options.diff == True
    return True

#
# Functions to extract options from the current OptionParser
#



# Generated at 2022-06-20 13:01:06.339770
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'tree'])
    assert args.one_line is True
    assert args.tree == 'tree'



# Generated at 2022-06-20 13:01:12.021479
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class ParserMock(object):
        def _exit(code=0, msg='', err=True):
            pass

    parser = ParserMock()
    parser.prog = "name_of_prog"
    ansible_version = AnsibleVersion()
    ansible_version(parser, None, None)
    assert True



# Generated at 2022-06-20 13:01:20.026999
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    ap = argparse.ArgumentParser()
    ap.add_argument('-l', action=PrependListAction, nargs='+', dest='l',
                    help='Prepends list of items (DO NOT USE unless very well understood)')
    ap.add_argument('-a', action=PrependListAction, nargs='+', default=[1, 2, 3], dest='a',
                    help='Prepends list of items (DO NOT USE unless very well understood)')
    ap.add_argument('-b', action=PrependListAction, nargs='+', dest='b')
    ap.add_argument('opt', help='A positional option')

# Generated at 2022-06-20 13:01:27.886074
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)