

# Generated at 2022-06-20 12:52:05.720382
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    ns = Namespace()
    ensure_value(ns, 'foo', None)
    assert not hasattr(ns, 'foo')
    ensure_value(ns, 'foo', 1)
    assert ns.foo == 1



# Generated at 2022-06-20 12:52:12.926894
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class Namespace(object):
        pass
    namespace = Namespace()
    prepend_list_action = PrependListAction(
        option_strings = ['-f'],
        dest='f',
        nargs=2,
        const=None,
        default=None,
        type=None,
        choices=None,
        required=False,
        help='test',
        metavar=None
    )
    prepend_list_action(
        parser=None,
        namespace=namespace,
        values=['5', '6', '7'],
        option_string=None
    )
    prepend_list_action(
        parser=None,
        namespace=namespace,
        values=['1', '2', '3', '4'],
        option_string=None
    )

# Generated at 2022-06-20 12:52:23.198132
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    """ test constructor of class UnrecognizedArgument"""
    opt_str = ['-z']
    dest = 'arg_name'
    const = True
    default = 'default'
    required = True
    help = 'Help for this argument.'
    nargs = 1
    obj = UnrecognizedArgument(option_strings=opt_str, dest=dest, nargs=nargs, const=const,
                               default=default, required=required, help=help, metavar=None)
    assert obj.option_strings == opt_str, "option_strings does not match in constructor of class UnrecognizedArgument"
    assert obj.dest == dest, "dest does not match in constructor of class UnrecognizedArgument"
    assert obj.nargs == nargs, "nargs does not match in constructor of class UnrecognizedArgument"


# Generated at 2022-06-20 12:52:35.211950
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class MyParser(argparse.ArgumentParser):
        def error(self, message):
            raise RuntimeError()

    action = PrependListAction(["--option"], "dest", nargs=3,
                               help="store three strings")
    try:
        action = PrependListAction(["--option"], "some_dest")
    except ValueError:
        pass
    try:
        action = PrependListAction(["--option"], "other_dest", nargs=argparse.OPTIONAL, const="some_const")
    except ValueError:
        pass

    parser = MyParser(add_help=False)
    parser.add_argument("some_dest", action=PrependListAction, nargs=1)

# Generated at 2022-06-20 12:52:39.495536
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser=create_base_parser('name',usage='',desc=None,epilog=None)
    add_verbosity_options(parser)
    parser.parse_args(['-vvvvvvvv'])
    parser.parse_args(['-v'])

# Generated at 2022-06-20 12:52:51.907856
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cli.console import CLI
    from ansible.module_utils._text import to_text

    argv = ['./ansible-console', '--help', '--foo', '--bar']
    cli = CLI(args=argv)
    a = UnrecognizedArgument(option_strings='--foo', dest=None)
    #
    # Check parser error message
    #
    try:
        a(parser=cli.parser, namespace=cli.parser.parse_args(argv), values=None, option_string='--foo')
        assert False, 'Should raise an exception'
    except SystemExit as e:
        assert e.code == 2
    except Exception as e:
        print(e)
        assert False, 'Should raise SystemExit'
    #
    # Check exit code
    #
   

# Generated at 2022-06-20 12:52:58.782442
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    expected_parser = argparse.ArgumentParser()
    test_runas_group = argparse.ArgumentParser()
    test_runas_pass_group = argparse.ArgumentParser()

    test_runas_pass_group.add_argument('-K', '--ask-become-pass', dest='become_ask_pass', action='store_true',
                                       default=C.DEFAULT_BECOME_ASK_PASS,
                                       help='ask for privilege escalation password')

# Generated at 2022-06-20 12:53:01.135802
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['--become-method','xyz'])
    assert args.become_method == 'xyz','--become-method option'
    assert args.become==True,'--become option'


# Generated at 2022-06-20 12:53:07.414691
# Unit test for function add_output_options
def test_add_output_options():   
    from nose.tools import assert_equals
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    assert_equals(parser.format_help(), 'usage:  [-h] [-o] [-t TREE]\n\noptional arguments:\n  -h, --help            show this help message and exit\n  -o, --one-line        condense output\n  -t TREE, --tree TREE  log output to this directory\n')
    


# Generated at 2022-06-20 12:53:10.968751
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', 'tmp'])
    assert(args.tree == 'tmp')


# Generated at 2022-06-20 12:53:34.359369
# Unit test for function add_meta_options
def test_add_meta_options():
    assert callable(getattr(add_meta_options, 'func_code', None))
    parser = argparse.ArgumentParser()
    parser.add_argument('--force-handlers', default=C.DEFAULT_FORCE_HANDLERS, dest='force_handlers', action='store_true',
                        help="run handlers even if a task fails")
    parser.add_argument('--flush-cache', dest='flush_cache', action='store_true',
                        help="clear the fact cache for every host in inventory")
    assert add_meta_options(parser) == parser.add_argument_group(parser)


# Generated at 2022-06-20 12:53:42.465272
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['-u', 'user'])
    assert args.remote_user == 'user'
    args = parser.parse_args(['--timeout', '20'])
    assert args.timeout == 20
    args = parser.parse_args(['--connection', 'network_cli'])
    assert args.connection == 'network_cli'
    args = parser.parse_args(['-k'])
    assert args.ask_pass == True
    args = parser.parse_args(['--connection-password-file', 'test'])
    assert args.connection_password_file == 'test'


# Generated at 2022-06-20 12:53:52.336713
# Unit test for function ensure_value
def test_ensure_value():
    import unittest
    class TestEnsureValue(unittest.TestCase):
        def setUp(self):
            self.namespace = argparse.Namespace(name='bob')
            self.name = 'name'
            self.value = 'value'

        def tearDown(self):
            pass

        def test_ensure_value(self):
            self.assertEqual(ensure_value(self.namespace, self.name, self.value), self.value)
    unittest.main(argv=[''], verbosity=2, exit=False)



# Generated at 2022-06-20 12:53:54.856327
# Unit test for function add_output_options
def test_add_output_options():
    p = argparse.ArgumentParser()
    add_output_options(p)
    assert '-o', '--one-line' in p.format_help()


# Generated at 2022-06-20 12:53:56.798197
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options = parser.parse_args(args=["--force-handlers"])
    assert options.force_handlers
    options = parser.parse_args(args=["--flush-cache"])
    assert options.flush_cache


# Generated at 2022-06-20 12:54:01.588419
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='test')
    add_connect_options(parser)
    options = parser.parse_args()

    assert options.ssh_common_args is None
    assert options.ssh_extra_args is None
    assert options.scp_extra_args is None
    assert options.sftp_extra_args is None



# Generated at 2022-06-20 12:54:09.035373
# Unit test for function add_check_options
def test_add_check_options():
    # create parser
    parser = argparse.ArgumentParser()
    # add options
    add_check_options(parser)
    # read test file
    test_file = open('test_file.txt', 'r')
    try:
        # parse test file
        options = parser.parse_args(test_file.read().split())
        # check values
        assert options.check is True
        assert options.syntax is True
        assert options.diff is True
    finally:
        test_file.close()


# Generated at 2022-06-20 12:54:16.270835
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    try:
        add_verbosity_options(parser)
        parser.parse_args(['-v'])
        parser.parse_args(['-vvv'])
        parser.parse_args(['-vvvv'])
        parser.parse_args(['--verbose'])
        parser.parse_args(['--verbose', '--verbose', '--verbose'])
    except Exception as e:
        assert False, "unexpected error: {}".format(e)



# Generated at 2022-06-20 12:54:20.251141
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = 'ansible 2.8.0'
    with open('version.txt', 'w') as f:
        f.write(ansible_version)
    with open('version.txt', 'r') as f:
        assert to_native(version(f.name))


# Generated at 2022-06-20 12:54:24.368012
# Unit test for function add_meta_options
def test_add_meta_options():

    parser = create_base_parser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers == True
    assert args.flush_cache == True



# Generated at 2022-06-20 12:54:34.233632
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    """
    Sanity-check function add_tasknoplay_options by making sure it throws no exceptions when run against a
    mock subcommand.
    """
    # Create a mock parser
    mock_parser = argparse.ArgumentParser()

    # Call the method we're testing, passing in the mock parser
    add_tasknoplay_options(mock_parser)



# Generated at 2022-06-20 12:54:44.838935
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():

    from ansible.utils.display import Display

    class DummyParser(object):
        def add_mutually_exclusive_group(self):
            return DummyGroup()
        def set_defaults(self, defaults={}):
            self.defaults = defaults

        def add_argument_group(self, *args, **kwargs):
            return DummyGroup()

    def parse(args):
        d = DummyParser()
        add_runas_prompt_options(d)
        # Use returncode because that's what a controller
        # would do if the authentication failed
        d.set_defaults(defaults={'ask_pass': True})
        d.args = d.parse_args(args)
        return d

    # test 1
    d = parse(['--ask-pass'])

# Generated at 2022-06-20 12:54:52.697054
# Unit test for function add_runas_options
def test_add_runas_options():
    # Test passing option through parser
    parser = argparse.ArgumentParser(prog="ansible")

    add_runas_options(parser)

    parsed_args = parser.parse_args(["-b", "--become-method", "sudo", "--become-user", "testuser"])

    assert parsed_args.become is True
    assert parsed_args.become_method == "sudo"
    assert parsed_args.become_user == "testuser"
    # Test passing options through parser without values



# Generated at 2022-06-20 12:55:03.395050
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(prog='ansible')
    parser.add_argument('--version', dest='version', action='version', version=__version__)
    parser.add_argument('--version1', dest='version1', action=UnrecognizedArgument)
    if sys.version_info >= (3, 0):
        from io import StringIO
        from contextlib import contextmanager
        import io
        @contextmanager
        def stdoutIO(stdout=None):
            old = sys.stdout
            if stdout is None:
                stdout = StringIO()
            sys.stdout = stdout
            yield stdout
            sys.stdout = old
    else:
        from StringIO import StringIO
        from contextlib import contextmanager
        import StringIO

# Generated at 2022-06-20 12:55:11.539134
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # type: () -> None
    class ActionSortingHelpFormatter(SortingHelpFormatter):
        def __init__(self, prog):
            self.added_arguments = []
            super(ActionSortingHelpFormatter, self).__init__(prog)

        def add_argument(self, action):
            self.added_arguments.append(action.dest)
            super(ActionSortingHelpFormatter, self).add_argument(action)
    # Test case 1
    option_parser = argparse.ArgumentParser(prog='ansible', usage=argparse.SUPPRESS, add_help=False)
    option_parser.add_argument("command", choices=("list", "show"), help=argparse.SUPPRESS)
    option_parser.add_argument("--version", action="version", version=__version__)

# Generated at 2022-06-20 12:55:22.671876
# Unit test for function add_runas_options
def test_add_runas_options():
    # try passing options manually
    tmp_parser = argparse.ArgumentParser()
    add_runas_options(tmp_parser)
    namespace, args = tmp_parser.parse_known_args([])
    assert namespace.become
    assert namespace.become_method == 'sudo'
    assert namespace.become_user == 'root'
    assert not namespace.ask_become_pass
    assert not namespace.ask_become_pass_prompt

    # pass options on commandline
    tmp_parser = argparse.ArgumentParser()
    add_runas_options(tmp_parser)
    namespace, args = tmp_parser.parse_known_args(['-b','--become-method', 'su', '--become-user', 'bob', '--ask-become-pass'])
    assert namespace.bec

# Generated at 2022-06-20 12:55:25.824063
# Unit test for function add_runtask_options
def test_add_runtask_options():
  parser=add_runtask_options(argparse.ArgumentParser(prog="ansible.py"))
  options=parser.parse_args(["-e","foo=bar"])
  assert options.extra_vars == ["foo=bar"]


# Generated at 2022-06-20 12:55:35.360410
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args('-M /home/test_dir'.split())
    assert options.module_path == [os.path.expanduser('/home/test_dir')]
    options = parser.parse_args('-M /home/test_dir1:/home/test_dir2'.split())
    assert options.module_path == [os.path.expanduser('/home/test_dir1'), os.path.expanduser('/home/test_dir2')]



# Generated at 2022-06-20 12:55:40.323498
# Unit test for function add_meta_options
def test_add_meta_options():
    test_parser = argparse.ArgumentParser()
    add_meta_options(test_parser)
    args, remaining = test_parser.parse_known_args(['--flush-cache',
                                                    '--force-handlers'])
    assert args.flush_cache
    assert args.force_handlers
# end test



# Generated at 2022-06-20 12:55:45.147287
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    x = add_vault_options(parser=parser)
    options = parser.parse_args(args=['--vault-id', '@prompt', '--ask-vault-pass'])
    assert options.vault_ids == ['@prompt']
    assert options.ask_vault_pass
    assert not options.vault_password_files
    
    options = parser.parse_args(args=['--vault-id', '@prompt', '--vault-password-file', 'blah'])
    assert options.vault_ids == ['@prompt']
    assert not options.ask_vault_pass
    assert options.vault_password_files == ['blah']
    

# Generated at 2022-06-20 12:56:00.384461
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    with pytest.raises(SystemExit):
        # Make sure the function exits successfully without errors
        parser.parse_args(['--task-timeout', 'nonint'])
    with pytest.raises(SystemExit):
        # Make sure the function exits successfully without errors
        parser.parse_args(['--task-timeout', '0'])
    with pytest.raises(SystemExit):
        # Make sure the function exits successfully without errors
        parser.parse_args(['--task-timeout', '-1'])



# Generated at 2022-06-20 12:56:04.772385
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    (unit test) test the add_runas_prompt_options function.
    """
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    parser.parse_args(['--become', '--ask-become-pass'])



# Generated at 2022-06-20 12:56:12.204737
# Unit test for function version
def test_version():
    assert version("core") == "core {}  config file = {}  configured module search path = Default w/o overrides  ansible python module location = {}  ansible collection location = {}  executable location = {}  python version = {}  jinja version = {}  libyaml = {}".format(__version__, C.CONFIG_FILE, ':'.join(ansible.__path__), ':'.join(C.COLLECTIONS_PATHS), sys.argv[0], ''.join(sys.version.splitlines()), j2_version, HAS_LIBYAML)

# Generated at 2022-06-20 12:56:18.182799
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='Test parser')
    add_verbosity_options(parser)
    add_vault_options(parser)
    parser.parse_args(['-v', '--ask-vault-password'])
    parser.parse_args(['-vvvv', '--vault-password-file', '/tmp/junk.txt'])

# Generated at 2022-06-20 12:56:23.299436
# Unit test for function create_base_parser
def test_create_base_parser():
    ''' Test module for create_base_parser'''
    prog = 'ansible'
    usage = ''
    desc = 'desc'
    epilog = 'epilog'
    parser = create_base_parser(prog, usage, desc, epilog)
    # Verify the Output
    assert parser.prog == prog
    assert parser.usage == usage
    assert parser.description == desc
    assert parser.epilog == epilog



# Generated at 2022-06-20 12:56:28.910714
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-x', action=UnrecognizedArgument, help='no such option')
    try:
        parser.parse_args(['-x'])
        assert False, "Exception not raised"
    except SystemExit as e:
        assert e.code == 2



# Generated at 2022-06-20 12:56:33.046283
# Unit test for function add_runas_options
def test_add_runas_options():
    from ansible.utils.display import Display
    from ansible.cli import CLI

    mock_parser = Mock()
    cli = CLI(mock_parser)

    result = cli._add_runas_options()

    assert result.opts.become



# Generated at 2022-06-20 12:56:44.451176
# Unit test for function add_module_options
def test_add_module_options():
    from mock import Mock, MagicMock
    from ansible.config.manager import ConfigManager
    class TestAnsibleModule:
        # A mock for testing
        def __init__(self):
            self.x = 5
        def __str__(self):
            return "Some module"

        def __call__(self, *args, **kwargs):
            return None
    class TestOptions:
        def __init__(self, dictopt):
            self.__dict__.update(dictopt)

    # Test add_module_options function with module_path, default=None
    # where module_path is prepended to the  
    # 1. Update config.DEFAULT_MODULE_PATH to a value
    # 2. Create an option parser
    # 3. Add the option using add_module_options()
    # 4. Par

# Generated at 2022-06-20 12:56:46.505296
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    """Unit test"""
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    return parser


# Generated at 2022-06-20 12:56:49.254223
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():

    # default options are disabled
    parser = argparse.ArgumentParser(conflict_handler='resolve')

    add_runas_prompt_options(parser)
    args = parser.parse_args([])
    assert args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS



# Generated at 2022-06-20 12:56:56.317882
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
  argparse.HelpFormatter.add_arguments = lambda self, actions: actions
  SortingHelpFormatter.add_arguments(None, [1, 2, 3, 4])


# Generated at 2022-06-20 12:57:00.357047
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """ validates that we can initialize the class """

    # initialize the class
    formatter = SortingHelpFormatter()

    # if init was successful, then this class will have an add_arguments() method
    return True



# Generated at 2022-06-20 12:57:03.091410
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args('-b -b --become-user=root --become-method=su'.split())
    assert options.become is True
    assert options.become_method == 'su'
    assert options.become_user == 'root'



# Generated at 2022-06-20 12:57:12.832923
# Unit test for function create_base_parser
def test_create_base_parser():
    epilog="help"
    desc="help description"
    parser = create_base_parser('test', epilog=epilog, desc=desc)

    assert parser.formatter_class == SortingHelpFormatter
    assert parser.epilog == epilog
    assert parser.description == desc
    assert parser._conflict_handler == 'resolve'
    assert parser._actions[0].dest == 'version'
    assert parser._actions[0].option_strings == ['--version']
    assert parser._actions[0].nargs == 0
    assert parser._actions[0].help == "show program's version number, config file location, configured module search path, module location, executable location and exit"
    assert parser._actions[0]._defaults == 0
    # one class instance overridden
    assert parser._actions[0].__class

# Generated at 2022-06-20 12:57:17.029771
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)

    # FIXME: Find a better way to test a function that modifies a parser instance
    # and that does not require comparing a string representation of the parsed args
    add_meta_options(parser)
    parsed_args = parser.parse_known_args([])[0]
    assert parsed_args.flush_cache is None
    assert parsed_args.force_handlers is False

    add_meta_options(parser)
    parsed_args = parser.parse_known_args(['--flush-cache'])[0]
    assert parsed_args.flush_cache is True
    assert parsed_args.force_handlers is False

    add_meta_options(parser)

# Generated at 2022-06-20 12:57:20.723521
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--flush-cache', dest='flush_cache', action='store_true',
                    help="clear the fact cache for every host in inventory")
    parser.add_argument('--force-handlers', default=C.DEFAULT_FORCE_HANDLERS, dest='force_handlers', action='store_true',
                    help="run handlers even if a task fails")
    args = parser.parse_args()
    assert args.flush_cache == True
    assert args.force_handlers == False



# Generated at 2022-06-20 12:57:31.484977
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    testargs = ["ansible-doc", "-M", "./lib/ansible/modules/network/"]


# Generated at 2022-06-20 12:57:40.791087
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    This function is used to verify that the constructor of class PrependListAction
    works as designed.
    """
    actual = PrependListAction(
        option_strings=['--option'],
        dest='output_file',
        nargs='?',
        const='C',
        default='D',
        type='string',
        choices=None,
        required=False,
        help='help text',
        metavar='METAVAR'
    )

# Generated at 2022-06-20 12:57:42.549417
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("ansible")
    assert parser != None


# Generated at 2022-06-20 12:57:49.098820
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = create_base_parser('test-parser')
    add_vault_options(parser)
    pargs = parser.parse_args(['--vault-password-file', '/some/path/vault.txt'])
    assert len(pargs.vault_password_files) == 1
    assert pargs.vault_password_files[0] == '/some/path/vault.txt'



# Generated at 2022-06-20 12:57:59.446262
# Unit test for function add_module_options
def test_add_module_options():
    parser = create_base_parser("test_add_module_options")
    add_module_options(parser)
    options = parser.parse_args([])
    assert options.module_path is None



# Generated at 2022-06-20 12:58:01.984145
# Unit test for function add_check_options
def test_add_check_options():
    """ test for add_check_options"""
    parser = argparse.ArgumentParser(prog="mock")
    add_check_options(parser)
    assert isinstance(parser, argparse.ArgumentParser)


# Generated at 2022-06-20 12:58:10.056185
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)

    # check default values
    assert not parser.parse_args([]).check
    assert C.DIFF_ALWAYS == parser.parse_args([]).diff
    assert 'store_true' == parser.parse_args([]).syntax

    # check set values
    assert parser.parse_args(['-C']).check
    assert parser.parse_args(['--syntax-check']).syntax
    assert parser.parse_args(['-D']).diff

# Generated at 2022-06-20 12:58:13.434559
# Unit test for function add_module_options
def test_add_module_options():
    assert 'help' in add_module_options.__code__.co_varnames
    assert 'parser' in add_module_options.__code__.co_varnames



# Generated at 2022-06-20 12:58:18.130952
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser(prog='ansible-test')
    assert not hasattr(parser, 'verbosity')
    add_verbosity_options(parser)
    assert hasattr(parser, 'verbosity')
    assert parser.verbosity.default == C.DEFAULT_VERBOSITY


# Generated at 2022-06-20 12:58:22.655819
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args('--vault-id a --vault-id b --ask-vault-password'.split())
    assert "a" in args.vault_ids and "b" in args.vault_ids and args.ask_vault_pass


# Generated at 2022-06-20 12:58:29.454566
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_basedir_options(parser)
    args = parser.parse_args([])
    assert args.basedir == C.config.get_config_value('PLAYBOOK_DIR')



# Generated at 2022-06-20 12:58:36.486899
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # See if the Ansible pathnames are correctly preserved
    assert maybe_unfrack_path('@tmpdir@')('@tmpdir@/foobar') == '@tmpdir@/foobar'
    assert maybe_unfrack_path('@localstatedir@')('@localstatedir@/foobar') == '@localstatedir@/foobar'
    assert maybe_unfrack_path('@execdir@')('@execdir@/foobar') == '@execdir@/foobar'
    # See if absolute paths are correctly modified
    assert maybe_unfrack_path('@tmpdir@')('/bar') == unfrackpath('/bar')
    # See if relative paths are correctly modified
    assert maybe_unfrack_path('@tmpdir@')('bar') == unfrackpath('bar')



# Generated at 2022-06-20 12:58:37.327444
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-20 12:58:39.484344
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    a = PrependListAction(None, None)
    a(None, None, ['a', 'b'], None)



# Generated at 2022-06-20 12:58:54.267836
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    err_msg = 'unrecognized arguments: --foo'
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', nargs=0, action=UnrecognizedArgument)
    try:
        args = parser.parse_args()
        assert False
    except SystemExit as exception:
        assert exception.code == 2
        assert err_msg in exception.args[0]



# Generated at 2022-06-20 12:58:57.794998
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    #instantiate the arguments parser
    parser = argparse.ArgumentParser()
    #call the function which adds the desired arguments
    add_verbosity_options(parser)
    #pass the argument -vvvv to the arguments parser
    result = parser.parse_args(["-vvvvv"])
    #assert that the result corresponds to what we want
    assert result.verbosity == 5



# Generated at 2022-06-20 12:59:05.808855
# Unit test for function add_fork_options
def test_add_fork_options():
    # New Parser
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )

    # Add function
    add_fork_options(parser)

    # Read arguments
    args, unknown_args = parser.parse_known_args(args=['--forks', '100'])

    # Verify
    assert args.forks == 100
    assert unknown_args == []

    # Destruct
    del parser



# Generated at 2022-06-20 12:59:13.566962
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    assert parser.parse_args(['-C']).check == True
    assert parser.parse_args(['--syntax-check']).syntax == True
    assert parser.parse_args([]).check == False
    assert parser.parse_args([]).syntax == False
    assert parser.parse_args(['-D']).diff == True
    assert parser.parse_args([]).diff == False


# Generated at 2022-06-20 12:59:19.218573
# Unit test for function add_inventory_options
def test_add_inventory_options():
     parser = argparse.ArgumentParser()
     add_inventory_options(parser)
     args = parser.parse_args(
         ['-i', 'somefile.py',
          '--list-hosts',
          '-l', 'limit'])
     assert args.inventory == ['somefile.py']
     assert args.listhosts
     assert args.subset == 'limit'



# Generated at 2022-06-20 12:59:28.200018
# Unit test for function version
def test_version():
    reload(C)  # Restores defaults if a test has overwritten them

    # Create a temporary config file to test with
    (fd, config_file) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as fobj:
        fobj.write("[defaults]\n")
        fobj.write("inventory_paths = /some/path")
    ansible_v = version(prog='test_prog')
    os.remove(config_file)

    assert "test_prog [core" in ansible_v
    assert "config file" in ansible_v
    assert "configured module search" in ansible_v
    assert "ansible python module" in ansible_v
    assert "executable location" in ansible_v
    assert "python version" in ansible

# Generated at 2022-06-20 12:59:35.727756
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    assert(parser.parse_args([]).verbosity == C.DEFAULT_VERBOSITY)
    assert(parser.parse_args(['-v']).verbosity == 1)
    assert(parser.parse_args(['-vv']).verbosity == 2)
    assert(parser.parse_args(['-vvv']).verbosity == 3)
    assert(parser.parse_args(['-vvvv']).verbosity == 4)



# Generated at 2022-06-20 12:59:41.672908
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = create_base_parser(prog="test_add_vault_options",
                                desc="test add_vault_options function")
    add_vault_options(parser)
    opts = parser.parse_args()
    assert opts.vault_ids == []
test_add_vault_options.run_tests = False



# Generated at 2022-06-20 12:59:50.791897
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--user', 'ansible-test',
                              '-u', 'test-user',
                              '-k',
                              '--ssh-common-args', "ProxyCommand foo",
                              '--sftp-extra-args', '-f',
                              '--scp-extra-args', '-l',
                              '--ssh-extra-args', '-R',
                              '--ask-pass',
                              '--connection-password-file', '/home/ansible/.pass'])
    assert args.remote_user == 'test-user'
    assert args.ask_pass is True
    assert args.connection_password_file == '/home/ansible/.pass'
    assert args

# Generated at 2022-06-20 12:59:57.049360
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_inventory_options(parser)
    opts = vars(parser.parse_args(['-i', 'foo.bar', '-i', 'foo.baz', '-l', 'qux']))
    assert opts['inventory'] == ['foo.bar', 'foo.baz']
    assert opts['subset'] == 'qux'



# Generated at 2022-06-20 13:00:09.524151
# Unit test for function add_subset_options
def test_add_subset_options():
    prog = 'test_prog'
    usage = 'test_usage'
    desc = 'test_description'
    epilog = 'test_epilog'
    parser = create_base_parser(prog, usage, desc, epilog)
    add_subset_options(parser)
    parser.add_argument(dest='arg1')
    parser.add_argument(dest='arg2')
    parser.add_argument(dest='arg3')
    parser.add_argument(dest='arg4')
    options = parser.parse_args(['test_arg1', 'test_arg2', 'test_arg3', 'test_arg4'])
    assert options.arg1 == 'test_arg1'
    assert options.arg2 == 'test_arg2'

# Generated at 2022-06-20 13:00:18.015060
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Create a parser
    parser = argparse.ArgumentParser()

    # Call function
    add_runas_prompt_options(parser)

    # Check that it adds a group
    assert parser._action_groups.__len__() == 1
    assert parser._action_groups[0].title == 'runas_pass_group'

    # Check that it adds correct arguments
    assert parser._action_groups[0]._group_actions.__len__() == 2
    assert parser._action_groups[0]._group_actions[0].dest == 'become_password_file'
    assert parser._action_groups[0]._group_actions[1].dest == 'become_ask_pass'
    assert parser._action_groups[0]._group_actions[0]._type is unfrack_path
    assert parser._action_

# Generated at 2022-06-20 13:00:19.884040
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog=None, formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_basedir_options(parser)
    return parser



# Generated at 2022-06-20 13:00:24.869492
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_subset_options(parser)
    args = parser.parse_args(['-t','foo','--skip-tags','bar','--tags','t1','--skip-tags','t2'])
    assert args.tags == ['foo','t1']
    assert args.skip_tags == ['bar','t2']


# Generated at 2022-06-20 13:00:28.951761
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', action=PrependListAction, nargs=2, dest='list')
    opts = parser.parse_args('-p one two -p three four'.split())
    assert opts.list == ['three', 'four', 'one', 'two']



# Generated at 2022-06-20 13:00:34.996277
# Unit test for function add_vault_options
def test_add_vault_options():
    def run(args, extra_vars=None):
        parser = argparse.ArgumentParser()
        add_vault_options(parser)
        return vars(parser.parse_args(args)), extra_vars
    assert run([]) == ({'vault_ids': [], 'ask_vault_pass': None, 'vault_password_files': []}, None)
    assert run(['--vault-id', 'one']) == ({'vault_ids': ['one'], 'ask_vault_pass': None, 'vault_password_files': []}, None)

# Generated at 2022-06-20 13:00:44.304155
# Unit test for function create_base_parser
def test_create_base_parser():
    base_parser = create_base_parser("ansible-prog", usage="%(prog)s [options]")

    # in case verbosity is not set, it should default to 0
    assert base_parser._actions[2].default == 0
    assert base_parser._verbosity == (False, [], 0)

    # setup predictable args for checking the verbosity options
    test_args = [
        "ansible-prog",
        "-v",
        "--vvvv",
        "-q",
        "--version",
    ]

    args = base_parser.parse_args(test_args)
    # verbosity should be 3
    assert args.verbosity == 3

    # check that the rest of the args are correct
    assert args.quiet == True
    assert args.v == True

# Generated at 2022-06-20 13:00:49.459077
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_verbosity_options(parser)
    options_dict = {('-v', '--verbose'): 'verbosity'}
    for arg in zip(parser._actions[0].option_strings, parser._actions[1].option_strings):
        assert arg in options_dict


# Generated at 2022-06-20 13:00:51.405684
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    av = AnsibleVersion(prog='test_prog')
    assert av.__call__(None, None, None, None) == None



# Generated at 2022-06-20 13:00:56.771155
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value='@/foo/bar'
    assert(maybe_unfrack_path('@')(value) == value)
    assert(maybe_unfrack_path('@')('@' + value) == value)
    assert(maybe_unfrack_path('@')('@' + value + '_') == value + '_')
    assert(maybe_unfrack_path('@')('@' + value + '/') == value + '/')



# Generated at 2022-06-20 13:01:14.186358
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    cmd = '%s ___call__' % sys.argv[0]
    parser = argparse.ArgumentParser(cmd)
    parser.add_argument('--version', action=AnsibleVersion)
    namespace = parser.parse_args(cmd.split())


# Generated at 2022-06-20 13:01:15.018719
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
  #TODO
  assert False



# Generated at 2022-06-20 13:01:15.679816
# Unit test for function version
def test_version():
    """
    Return version if running from ansible/ module
    """
    assert version()

# Generated at 2022-06-20 13:01:20.751161
# Unit test for function add_subset_options
def test_add_subset_options():

    import argparse
    from io import StringIO
    from ansible.utils.plugin_docs import get_docstring

    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.print_help()
    help_msg = StringIO()
    parser.print_help(file=help_msg)
    help_msg = help_msg.getvalue()

    assert '-t' in help_msg
    assert '--tags' in help_msg
    assert 'only run plays and tasks tagged with these values' in help_msg



# Generated at 2022-06-20 13:01:24.702936
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='test', usage='test usage message')
    assert parser.prog == 'test', 'prog attribute should be set'
    assert parser.description is None, 'description attribute should be None'
    assert parser.formatter_class == SortingHelpFormatter
    assert parser.conflict_handler == 'resolve'
    assert parser._optionals._actions[-1].__class__ == AnsibleVersion, 'AnsibleVersion should be last action'
    assert parser._optionals._actions[-2].__class__ == argparse.HelpAction, 'HelpAction should be second last action'



# Generated at 2022-06-20 13:01:27.884171
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs=2, default=[])
    args = parser.parse_args('--foo 1 --foo 1 2'.split())
    assert args.foo == ['1', '1', '2']

# Generated at 2022-06-20 13:01:31.008261
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    UnrecognizedArgument('-t', dest='t', const=True)(None, None, None, option_string='-t')
#
# Generic OptionParsers
#


# base class for all parsers