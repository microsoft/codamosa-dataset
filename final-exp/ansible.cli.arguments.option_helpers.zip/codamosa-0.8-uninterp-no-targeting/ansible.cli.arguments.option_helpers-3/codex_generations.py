

# Generated at 2022-06-20 12:52:08.930678
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from io import StringIO
    from textwrap import dedent
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--bee')
    parser.add_argument('-t', '--tux')
    parser.add_argument('-z', '--zoo')
    parser.add_argument('-a', '--alpha')
    test_stdout = StringIO()
    parser.print_help(file=test_stdout)

# Generated at 2022-06-20 12:52:12.313985
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    import argparse
    parser = argparse.ArgumentParser(description='description')
    parser.add_argument('-f', help="-f help")
    parser.print_help()
    parser.parse_args(['-f' , '-e'])
    print("Unit test end.")


#
# Alternative to running with a subcommand but using a plain vanilla parser
#

# Generated at 2022-06-20 12:52:20.197508
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0, default='', help='print version')
    parser.prog = 'test'
    with open('tests/unit/cli/test_ansible_version', 'r') as ansible_version:
        expected = ansible_version.read().strip()
    args = parser.parse_args(['--version'])
    assert args == argparse.Namespace()
    assert expected == ansible_version.read().strip()



# Generated at 2022-06-20 12:52:26.833717
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    opts, args = parser.parse_known_args(['-t', 'TESTTREE', '--one-line'])
    assert opts.tree == 'TESTTREE'
    assert opts.one_line



# Generated at 2022-06-20 12:52:37.908239
# Unit test for function add_async_options
def test_add_async_options():
    '''test for the add_async_options function'''
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_async_options(parser)
    options = parser.parse_args([])
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL
    assert options.seconds == 0
    options = parser.parse_args(['-P','10'])
    assert options.poll_interval == 10
    assert options.seconds == 0
    options = parser.parse_args(['-B','20'])
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL
    assert options.seconds == 20
    options = parser.parse_args(['-P','10','-B','20'])
    assert options.poll_interval == 10


# Generated at 2022-06-20 12:52:50.443934
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # Check if the lines are sorted
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.formatter_class = SortingHelpFormatter
    lines = parser.format_help().split('\n')
    assert lines.index('  --bar') < lines.index('  --foo'), 'The order of lines are mixed'
# Unit tests for method add_argument of class SortingHelpFormatter
    # Check if the lines are sorted even if the order of arguments are mixed
    parser = argparse.ArgumentParser()
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--foo', action='store_true')
    parser.formatter_class = Sorting

# Generated at 2022-06-20 12:52:54.281895
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(
        prog='ansible-prog',
        usage='usage',
        desc='desc',
        epilog='epilog',
    )
    assert(isinstance(parser, argparse.ArgumentParser))


# Generated at 2022-06-20 12:52:56.411977
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args([])
    assert args.vault_ids == []
    assert not args.ask_vault_pass
    assert args.vault_password_files == []


#
# Options which take files (and can support '@filename')
#


# Generated at 2022-06-20 12:53:06.928123
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(
        prog="ansible-test",
    )
    add_output_options(parser)
    # Default is false
    args = parser.parse_args(args=[])
    assert not args.one_line
    assert not args.tree
    # '-o' set one_line to True
    args = parser.parse_args(args=['-o'])
    assert args.one_line
    assert not args.tree
    # '-t' set tree to a directory
    args = parser.parse_args(args=['-t', 'log'])
    assert not args.one_line
    assert args.tree == 'log'


# Generated at 2022-06-20 12:53:12.442640
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, add_help=False)
    add_inventory_options(parser)
    # just testing it parses
    parser.parse_args(['--inventory', 'test_inventory', '-i', 'test_hosts', '-l', 'test_limit', '--list-hosts'])



# Generated at 2022-06-20 12:53:29.218780
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    args, _ = parser.parse_known_args(['--playbook-dir', '/a/b/c'])
    assert args.basedir == '/a/b/c'


# Generated at 2022-06-20 12:53:33.817752
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args(['--become-method', 'sudo', '--become-user', 'bob'])
    assert args.become_method == 'sudo' and args.become_user == 'bob'
    C.DEFAULT_BECOME_METHOD = 'sudo'
    C.DEFAULT_BECOME_USER = 'bob'


# Generated at 2022-06-20 12:53:43.261184
# Unit test for function add_connect_options

# Generated at 2022-06-20 12:53:55.278775
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.constants import TAGS_RUN, TAGS_SKIP
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args=parser.parse_args(['--tags', 'TAG_1', '--tags', 'TAG_2', '--skip-tags', 'SKIP_TAG_1', '--skip-tags', 'SKIP_TAG_2'])
    assert args.tags == ['TAG_1', 'TAG_2']
    assert args.skip_tags == ['SKIP_TAG_1', 'SKIP_TAG_2']
    args=parser.parse_args([])
    assert args.tags == TAGS_RUN
    assert args.skip_tags == TAGS_SKIP



# Generated at 2022-06-20 12:54:00.840866
# Unit test for function add_check_options
def test_add_check_options():
    p = argparse.ArgumentParser()
    add_check_options(p)
    opt = p.parse_args([])
    assert not opt.check
    assert not opt.syntax
    assert opt.diff

    opt = p.parse_args(["-C", "-D", "--syntax-check"])
    assert opt.check
    assert opt.syntax
    assert not opt.diff



# Generated at 2022-06-20 12:54:05.678260
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog="ansible-test", formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_async_options(parser)
    opts = parser.parse_args(['-B', '3600'])
    assert opts.seconds == 3600


# Generated at 2022-06-20 12:54:07.643029
# Unit test for function create_base_parser
def test_create_base_parser():
    assert create_base_parser("ansible-test").parse_args(["--version"]).version == True


# Generated at 2022-06-20 12:54:12.680505
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class FakeParser:
        def __init__(self, ansible_version):
            self.prog = ansible_version

        def exit(self):
            return

    action = AnsibleVersion(None, None, None, None)

    fake_parser = FakeParser(ansible_version)
    action(fake_parser, None, None, None)



# Generated at 2022-06-20 12:54:19.128103
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', 'key1=value1', '-e', '@/path/to/file.yml'])
    assert (options.extra_vars == ['key1=value1', '/path/to/file.yml'])
    options = parser.parse_args([])
    assert (options.extra_vars == [])



# Generated at 2022-06-20 12:54:28.594951
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='program')
    add_output_options(parser)
    args = parser.parse_args()
    assert args.one_line is None
    assert args.tree is None
    parser = argparse.ArgumentParser(prog='program')
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert args.one_line is True
    parser = argparse.ArgumentParser(prog='program')
    add_output_options(parser)
    args = parser.parse_args(['-t', 'tree'])
    assert args.tree == 'tree'



# Generated at 2022-06-20 12:54:46.152839
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True)('a=b:c:d') == ['b', 'c', 'd']
    assert unfrack_path(pathsep=True)('a=b:.:d') == ['b', '.', 'd']
    assert unfrack_path()('a=b') == 'b'
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-20 12:54:54.356262
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():

    test_prog = "ansible-playbook"
    test_version = __version__
    test_version.rstrip()
    test_version = "ansible-playbook " + test_version
    ansible_version = AnsibleVersion(test_prog, "version")
    assert ansible_version
    assert ansible_version.__call__(test_prog, test_version, 'version') == "ansible-playbook " + version()


# Generated at 2022-06-20 12:55:04.936052
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    options = parser.parse_args(['--task-timeout', '-1'])
    assert options.task_timeout == -1
    options = parser.parse_args(['--task-timeout', '0'])
    assert options.task_timeout == '0'
    options = parser.parse_args(['--task-timeout', '123'])
    assert options.task_timeout == 123
    options = parser.parse_args(['--task-timeout', '1999999999'])
    assert options.task_timeout == 1999999999
    options = parser.parse_args(['--task-timeout', 'not_a_number'])
    assert options.task_timeout == 'not_a_number'



# Generated at 2022-06-20 12:55:06.273472
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(["-f", "50"])
    assert args.forks == 50


# Generated at 2022-06-20 12:55:08.161603
# Unit test for function add_connect_options
def test_add_connect_options():
    connect_group = argparse.ArgumentParser(description='Connect Options')
    connect_group = add_connect_options(connect_group)



# Generated at 2022-06-20 12:55:13.865601
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    assert parser.parse_args().tags == C.TAGS_RUN
    assert parser.parse_args().skip_tags == C.TAGS_SKIP
    assert parser.parse_args(['-t', 'foo']).tags == ['foo']
    assert parser.parse_args(['--skip-tags', 'bar']).skip_tags == ['bar']



# Generated at 2022-06-20 12:55:15.247375
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    assert True



# Generated at 2022-06-20 12:55:21.806432
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options = parser.parse_args('-o -t /'.split())
    assert options.one_line == True
    assert options.tree == '/'

"""def add_test_options(parser):
    #Add options for commands which can run on test-mode
    parser.add_argument('--check-mode', dest='check', action='store_true',
                        help="run all tasks in check mode (default=False)")"""



# Generated at 2022-06-20 12:55:28.558491
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    parser._validate_args(["-i", "localhost,", "--list-hosts", "-l", "localhost"])

    with pytest.raises(SystemExit) as cm:
        parser._validate_args(["-i", "localhost,", "--list-hosts", "-l"])
    assert cm.value.code == 2

    with pytest.raises(SystemExit) as cm:
        parser.parse_args(["-i", "localhost,", "--list-hosts", "-l"])
    assert cm.value.code == 2



# Generated at 2022-06-20 12:55:39.884580
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test_parser", epilog="test_epilog", desc="test_desc")
    parser.add_argument('-t', '--to_time', action='store_true', dest='to_time', default=False,
                        help="Display time in human-readable format "
                             "(e.g. 1 day, 2 hours, 30 minutes)")
    opts, args = parser.parse_known_args(['--version'])
    assert opts.__dict__ == {'verbosity': 0, 'version': True}
    opts, args = parser.parse_known_args(['-v', '-v', '-v'])
    assert opts.__dict__ == {'verbosity': 3, 'version': False}



# Generated at 2022-06-20 12:55:51.855596
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser('ansible-doc')
    add_meta_options(parser)
    result = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert result.force_handlers is True
    assert result.flush_cache is True


# Generated at 2022-06-20 12:56:01.071309
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(["-C"])
    assert args.check
    args = parser.parse_args(["--syntax-check"])
    assert args.syntax
    args = parser.parse_args(["-D"])
    assert args.diff

parser = argparse.ArgumentParser()
add_check_options(parser)
args = parser.parse_args(["-C"])
assert args.check
args = parser.parse_args(["--syntax-check"])
assert args.syntax
args = parser.parse_args(["-D"])
assert args.diff


# Generated at 2022-06-20 12:56:03.213237
# Unit test for function create_base_parser
def test_create_base_parser():
    assert create_base_parser("prog",usage="",desc=None,epilog=None)


# Generated at 2022-06-20 12:56:13.620972
# Unit test for function ensure_value
def test_ensure_value():
    class ns(object):
        pass
    assert ensure_value(ns, 'foo', [1, 2, 3]) == [1, 2, 3]
    assert ns.foo == [1, 2, 3]
    assert ensure_value(ns, 'foo', [4, 5, 6]) == [1, 2, 3]
    assert ns.foo == [1, 2, 3]


#
# CLI Parsers
#

# base parser
base_parser = argparse.ArgumentParser(
    formatter_class=SortingHelpFormatter,
)
base_parser.add_argument('--version', action=AnsibleVersion,
                         help='show program\'s version number and exit')

# parser for subcommands

# Generated at 2022-06-20 12:56:19.537787
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=UnrecognizedArgument)
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser.parse_args(['--version'])
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == 2



# Generated at 2022-06-20 12:56:25.886630
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        conflict_handler='resolve',
    )
    add_check_options(parser)
    args = parser.parse_args(["--check"])
    assert args.check
    args = parser.parse_args(["--syntax-check"])
    assert args.syntax
    args = parser.parse_args(["--diff"])
    assert args.diff



# Generated at 2022-06-20 12:56:29.840139
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser('')
    add_runas_options(parser)
    args = parser.parse_args([])
    assert args.become_user == C.DEFAULT_BECOME_USER


# runas user and password prompting options

# Generated at 2022-06-20 12:56:34.971726
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
    )
    add_output_options(parser)
    options = parser.parse_args(['-o', '-t', '.'])
    assert options.one_line
    assert options.tree == '.'


# Generated at 2022-06-20 12:56:43.224784
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser()
    add_meta_options(parser)

    assert parser
    options = parser.parse_args([])
    assert not options.force_handlers
    assert not options.flush_cache

    options = parser.parse_args(['--force-handlers'])
    assert options.force_handlers
    assert not options.flush_cache

    options = parser.parse_args(['--flush-cache'])
    assert not options.force_handlers
    assert options.flush_cache


# Generated at 2022-06-20 12:56:46.376838
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    """Ensure UnrecognizedArgument can be constructed without error."""
    foo = UnrecognizedArgument('-x', '--x', help='x', dest='x', required=False, const=True, default=None, metavar='X')



# Generated at 2022-06-20 12:57:08.953783
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    (options, args) = parser.parse_known_args(['-o', '-t'])
    assert options.one_line is True
    assert options.tree == ''



# Generated at 2022-06-20 12:57:13.081501
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        mypath = '/etc/ansible/ansible.cfg'
        mynewpath = unfrack_path()
        assert mypath == mynewpath, ("mypath is %s, and mynewpath is %s" % (mypath, mynewpath))

    except Exception as e:
        print("ERROR: %s" % e)


# helper to split args from playbooks

# Generated at 2022-06-20 12:57:14.923609
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'foo'
    AnsibleVersion()(parser, None, None, '--version')


# Generated at 2022-06-20 12:57:18.135545
# Unit test for function ensure_value
def test_ensure_value():
    class A:
        pass
    a = A()
    ensure_value(a, 'b', 1)
    assert a.b == 1
    ensure_value(a, 'b', 2)
    assert a.b == 1


#
# Option Parsing
#

# Generated at 2022-06-20 12:57:24.162856
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action=UnrecognizedArgument)
    try:
        parser.parse_args(['--test', 'foo'])
    except SystemExit as e:
        assert e.code == 2
    else:
        assert False, "Expected SystemExit exception was not thrown"

#
# Options parsers for ansible-playbook
#

# Generated at 2022-06-20 12:57:29.407784
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        description='test',
        conflict_handler='resolve',
    )
    add_output_options(parser)
    args = parser.parse_args(['-o','-t','test'])
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-20 12:57:33.918557
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    from ansible.cli import CLI
    cli = CLI(args=["-vv"])
    assert cli.options.verbosity == 2
    cli = CLI(args=["-v"])
    assert cli.options.verbosity == 1
    cli = CLI(args=[])
    assert cli.options.verbosity == 0



# Generated at 2022-06-20 12:57:36.270228
# Unit test for function add_basedir_options
def test_add_basedir_options():
    '''
    Test function add_basedir_options to make sure no argument passed to the function
    raises an exception.
    '''
    try:
        add_basedir_options(None)
    except:
        pytest.fail("argparse.ArgumentParser has not been passed to the function add_basedir_options()")



# Generated at 2022-06-20 12:57:38.693976
# Unit test for function add_output_options
def test_add_output_options():
    parser = MockCLI().add_output_options(MockOptionParser())
    assert parser.get_option('-o')
    assert parser.get_option('-t')


# Generated at 2022-06-20 12:57:49.394828
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog="test_subset_options",
                                     formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve')
    add_subset_options(parser)

    # Test default options
    args = parser.parse_args(args=[])
    assert(args.tags == C.TAGS_RUN)
    assert(args.skip_tags == C.TAGS_SKIP)

    # Test new options
    args = parser.parse_args(args=['-t', 'test', '--skip-tags', 'skip'])
    assert(args.tags == ['test'])
    assert(args.skip_tags == ['skip'])



# Generated at 2022-06-20 12:58:12.498291
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert parser._actions[0].dest == 'flush_cache'

# Generated at 2022-06-20 12:58:18.786880
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    # test it returns the value if it is not None
    n = Namespace()
    n.foo = 1
    assert ensure_value(n, 'foo', 3) == 1
    # test it returns the provided value if the value is None
    n = Namespace()
    assert ensure_value(n, 'foo', 3) == 3
    assert n.foo == 3



# Generated at 2022-06-20 12:58:26.328757
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.cli.arguments import DEFAULT_UNFRACK_PATHS
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    opt = parser.parse_args(["-e", "k=v", "-e", "@foo", "-e", "@" + os.path.join(os.getcwd(), "bar"), "-e", '@' + os.path.join(os.getcwd(), 'baz')])

# Generated at 2022-06-20 12:58:32.998746
# Unit test for function add_meta_options

# Generated at 2022-06-20 12:58:41.059943
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Unit test for method __call__ of class AnsibleVersion
    # Create option parser instance
    parser = argparse.ArgumentParser(prog='test-ansible-version')
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    parser.add_argument('--extra-version', action='append')
    # Check exit code
    try:
        parser.parse_args(['--version'])
    except SystemExit as err:
        if err.code != 0:
            raise AssertionError('AnsibleVersion --version returned wrong exit code')



# Generated at 2022-06-20 12:58:42.608027
# Unit test for function version
def test_version():
  C.DEFAULT_MODULE_PATH = ''

# Generated at 2022-06-20 12:58:47.903850
# Unit test for function add_fork_options
def test_add_fork_options():
  print("Test for function add_fork_options")
  parser = argparse.ArgumentParser()
  add_fork_options(parser)
  print(parser.get_default('forks'))
  args = parser.parse_args(['-f', '2'])
  print(args.forks)



# Generated at 2022-06-20 12:58:52.892532
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # create the parser
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', dest='version', action=AnsibleVersion, nargs=0)
    parser.prog = 'ansible'
    # parse the command line arguments
    parser.parse_args(['--version'])


# Generated at 2022-06-20 12:58:57.568047
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='test_add_basedir_options', conflict_handler='resolve')
    add_basedir_options(parser)
    options = parser.parse_args('--playbook-dir '.split())
    assert options.basedir == os.path.expanduser('~/.ansible/test')
    options = parser.parse_args('--playbook-dir /testdir'.split())
    assert options.basedir == '/testdir'



# Generated at 2022-06-20 12:59:07.789216
# Unit test for function version
def test_version():
    from ansible import context
    context.CLIARGS = {}
    assert version('ansible') == 'ansible [core 2.5.5]  config file = %s  configured module search path = Default w/o overrides  ansible python module location = %s  ansible collection location = %s  executable location = %s  python version = 2.7.15 (default, Jul  3 2018, 17:30:36) [GCC 4.2.1 Compatible Apple LLVM 9.1.0 (clang-902.0.39.2)]  jinja version = 2.10  libyaml = False' % (C.CONFIG_FILE, ':'.join(ansible.__path__), ':'.join(C.COLLECTIONS_PATHS), sys.executable)

# Generated at 2022-06-20 13:01:02.395443
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog='foo',
        formatter_class=SortingHelpFormatter,
        epilog='',
        description='bar',
    )
    add_basedir_options(parser)
    options = parser.parse_args(["--playbook-dir", "/foo/bar"])
    assert options.basedir == "/foo/bar"



# Generated at 2022-06-20 13:01:05.682409
# Unit test for function ensure_value
def test_ensure_value():
    a = argparse.Namespace()
    ensure_value(a, 'b', 3)
    assert a.b == 3
    ensure_value(a, 'b', 4)
    assert a.b == 3  # Should still be 3



# Generated at 2022-06-20 13:01:08.473167
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    actual = SortingHelpFormatter().add_arguments([3,2,1])
    expected = None
    assert actual == expected


# Generated at 2022-06-20 13:01:11.418640
# Unit test for function add_module_options
def test_add_module_options():
    parser = create_base_parser('test', 'test desc', 'test epilog')
    add_module_options(parser)
    return parser



# Generated at 2022-06-20 13:01:16.501846
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    try:
        PrependListAction(['-a', '--a'], 'a', nargs=0, const=None)
        assert False, "Expected ValueError"
    except ValueError:
        assert True
    try:
        PrependListAction(['-a', '--a'], 'a', nargs=argparse.OPTIONAL, const=None)
        assert True
    except ValueError:
        assert False



# Generated at 2022-06-20 13:01:19.956358
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from io import StringIO
    from unittest.mock import patch
    stdout = StringIO()
    with patch('sys.stdout', stdout):
        parser = argparse.ArgumentParser()
        action = AnsibleVersion(option_strings=[])
        parser.exit = lambda x: None
        action(parser, None, None)
    return stdout.getvalue()



# Generated at 2022-06-20 13:01:24.211625
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'foo', 'bar')
    assert namespace.foo == 'bar'
    namespace = argparse.Namespace(foo='fuz')
    ensure_value(namespace, 'foo', 'bar')
    assert namespace.foo == 'fuz'


#
# Base parser
#

# Generated at 2022-06-20 13:01:26.523892
# Unit test for function add_check_options
def test_add_check_options():
    result = add_check_options("-C")
    assert result == "-C"
    assert result == '-C'

#
# Functions to process Options
#


# Generated at 2022-06-20 13:01:27.821847
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)



# Generated at 2022-06-20 13:01:33.165282
# Unit test for function add_verbosity_options
def test_add_verbosity_options():

    parser = argparse.ArgumentParser(
        prog='mock',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )

    add_verbosity_options(parser)
    opts = parser.parse_args(['-vvvvv'])
    assert opts.verbosity == 5

