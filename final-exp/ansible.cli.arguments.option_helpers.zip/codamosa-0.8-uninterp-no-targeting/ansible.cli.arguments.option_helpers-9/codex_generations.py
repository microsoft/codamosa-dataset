

# Generated at 2022-06-20 12:52:13.278521
# Unit test for function ensure_value
def test_ensure_value():
    class Args(object):
        pass
    args = Args()
    ensure_value(args, 'foo', 'bar')
    assert args.foo == 'bar'
    ensure_value(args, 'foo', 'baz')
    assert args.foo == 'bar', "foo was changed from 'bar' to '%s'" % args.foo
    ensure_value(args, 'bar', 'foo')
    assert args.bar == 'foo'

#
# OptionParser base classes
#
# BaseParser is the main base class for AnsibleOptionParser.  It provides most of the
# common required features and abstracts all common options.  The remaining parsers
# below extend BaseParser to provide more options, but also exclude options that
# may conflict.  For example, ansible-playbook will exclude options which are only
# relevant to ansible or

# Generated at 2022-06-20 12:52:15.274884
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    obj = AnsibleVersion('ansible-version')
    obj(None, None, None, None)


# Generated at 2022-06-20 12:52:18.790833
# Unit test for function add_module_options
def test_add_module_options():
    """just ensure the function runs without error"""
    parser = argparse.ArgumentParser(description="Ansible options")
    add_module_options(parser)


# Generated at 2022-06-20 12:52:25.315888
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    sys.argv = shlex.split("--limit localhost test")
    args = parser.parse_args()
    assert(args.subset == 'localhost')
    assert(args.inventory == ['test'])
        


# Generated at 2022-06-20 12:52:30.278544
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-c')
    parser.add_argument('--foo')
    parser.add_argument('bar')
    args = parser.parse_args([])
    assert args.bar is None



# Generated at 2022-06-20 12:52:37.269242
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    r = parser.parse_args(['--check'])
    assert r.check
    r = parser.parse_args(['-C'])
    assert r.check
    r = parser.parse_args(['-D'])
    assert r.diff
    r = parser.parse_args(['--syntax-check'])
    assert r.syntax
    # TODO: assert the "help" message.


# Generated at 2022-06-20 12:52:46.753435
# Unit test for function add_runas_options
def test_add_runas_options():
    input_args = ['-b']
    parser = create_base_parser(prog='ansible-inventory', usage='', desc="", epilog="")
    add_runas_options(parser)
    options = parser.parse_args(input_args)
    assert options.become is True
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user == C.DEFAULT_BECOME_USER
    assert options.become_ask_pass == False



# Generated at 2022-06-20 12:52:48.205799
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    assert add_tasknoplay_options is not None, "add_tasknoplay_options function not defined"



# Generated at 2022-06-20 12:52:56.761108
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()

# Generated at 2022-06-20 12:52:59.269743
# Unit test for function add_meta_options
def test_add_meta_options():
    parser= argparse.ArgumentParser()
    add_meta_options(parser)
    # check if options are added successfully
    assert('--force-handlers' in parser._actions[0].option_strings)
    assert('--flush-cache' in parser._actions[1].option_strings)


# Generated at 2022-06-20 12:53:17.385951
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    default = parser.parse_args([])
    assert default.force_handlers == C.DEFAULT_FORCE_HANDLERS, \
        "force_handlers should be true by default."
    assert default.flush_cache == False, \
        "flush_cache should be false by default."
    args = parser.parse_args(['--force-handlers'])
    assert args.force_handlers == True, \
        "force_handlers should be true if user specified."
    args = parser.parse_args(['--flush-cache'])
    assert args.flush_cache == True, \
        "flush_cache should be true if user specified."



# Generated at 2022-06-20 12:53:19.485919
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args()
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP

# Generated at 2022-06-20 12:53:21.725852
# Unit test for function add_output_options
def test_add_output_options():
    """add_output_options unit test"""

    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args()



# Generated at 2022-06-20 12:53:24.437514
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    assert add_connect_options(parser) == 0
    parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'admin', '-c', 'local'])
    parser.parse_args(['--private-key', '~/.ssh/id_rsa', '-u', 'admin'])



# Generated at 2022-06-20 12:53:33.280295
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args(['-e', 'var1=value', '-e', 'var2=value2', '-e', '"{\"var3\": \"value3\"}"', '-e', '{"var4": "value4"}'])
    assert options.extra_vars == ['var1=value', 'var2=value2', '{"var3":"value3"}', '{"var4":"value4"}']


# Generated at 2022-06-20 12:53:37.929788
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    try:
        args = parser.parse_args(["-M", "/path/to/module"])
    except SystemExit as e:
        raise AssertionError("unexpected SystemExit exception: %s" % e)



# Generated at 2022-06-20 12:53:40.439272
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check == True


# Generated at 2022-06-20 12:53:43.269713
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args('-o -t test'.split())
    assert args.one_line == True
    assert args.tree == 'test'


# Generated at 2022-06-20 12:53:50.175795
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog="ansible-connection")
    add_connect_options(parser)
    parser.add_argument("-T", "--timeout", default=C.DEFAULT_TIMEOUT, dest='timeout',
                        help="override the connection timeout in seconds (default=%s)" % C.DEFAULT_TIMEOUT)


# Generated at 2022-06-20 12:53:54.693345
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from argparse import ArgumentParser
    from ansible.utils import prepend_list_action

    # Sample usage
    arg_parser = ArgumentParser()
    arg_parser.add_argument(
        '-a', dest='foo', action=prepend_list_action, nargs='+', default=[]
    )
    args = arg_parser.parse_args([])
    assert args.foo == []
    args = arg_parser.parse_args(['-a', 'a', 'b'])
    assert args.foo == ['a', 'b']
    args = arg_parser.parse_args(['-a', 'a', 'b', 'c'])
    assert args.foo == ['a', 'b', 'c']
    args = arg_parser.parse_args(['-a', 'a'])

# Generated at 2022-06-20 12:54:05.902076
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    origin_path = '/home/ansible/.ansible/collections/ansible_collections/ns/net_tools/plugins/inventory/cisco.py'
    beacon = '@'
    new_path = maybe_unfrack_path(beacon)(beacon + origin_path)
    assert new_path.startswith('@/home/ansible/.ansible/collections/ansible_collections/ns/net_tools/plugins/inventory/cisco.py')


# Generated at 2022-06-20 12:54:12.808359
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_module_options(parser)
    args = parser.parse_args(['-M', 'a:b'])
    assert args.module_path == ['a', 'b']
    args = parser.parse_args(['-Ma:b'])
    assert args.module_path == ['a:b']
    args = parser.parse_args(['-M.'])
    assert args.module_path == ['.']



# Generated at 2022-06-20 12:54:17.804959
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(
        ['-c', 'ssh', '--ssh-extra-args', '-R']
    )
    assert args.connection == 'ssh'
    assert args.ssh_extra_args == '-R'



# Generated at 2022-06-20 12:54:28.735360
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

    # Check default values
    options = parser.parse_args([])
    assert options.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert options.remote_user == C.DEFAULT_REMOTE_USER
    assert options.connection == C.DEFAULT_TRANSPORT
    assert options.timeout == C.DEFAULT_TIMEOUT
    assert options.ssh_common_args == None
    assert options.sftp_extra_args == None
    assert options.scp_extra_args == None
    assert options.ssh_extra_args == None
    assert options.ask_pass == False
    assert options.connection_password_file is None

    # Check setting values


# Generated at 2022-06-20 12:54:31.353881
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(add_basedir_options)
    add_basedir_options(parser)
    return parser

# test_add_basedir_options()


# Generated at 2022-06-20 12:54:37.851730
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version_parser = argparse.ArgumentParser()
    version_parser.add_argument('-v', action=AnsibleVersion, nargs=0, help='Display Ansible version')
    args = version_parser.parse_args(['-v'])
    assert args.v == None



# Generated at 2022-06-20 12:54:47.231275
# Unit test for function create_base_parser
def test_create_base_parser():
    fake_usage = "fake usage"
    fake_desc = "fake description"
    fake_epilog = "fake epilog"
    fake_prog = "test create_base_parser"
    fake_version = "test version"
    real = create_base_parser(fake_prog, fake_usage, fake_desc, fake_epilog)
    assert real.prog == fake_prog
    assert real.formatter_class == SortingHelpFormatter
    assert real.epilog == fake_epilog
    assert real.description == fake_desc
    assert real.conflict_handler == 'resolve'
    assert len(real.actions) == 2
    version = real.actions[0]
    assert version.option_strings == ['--version']
    assert version.dest is None

# Generated at 2022-06-20 12:54:49.650166
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t','tag1','tag2','--skip-tags','tag3','tag4'])
    assert args.tags == ['tag1','tag2'], "Error in setting tags"
    assert args.skip_tags == ['tag3','tag4'], "Error in setting skip-tags"
#end of Unit Test

# Generated at 2022-06-20 12:54:55.428807
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    name = 'test_var'
    value = True
    assert getattr(namespace, name, None) is None
    assert ensure_value(namespace, name, value) is value
    assert getattr(namespace, name, None) is value


#
# Helper methods for parsing command line options.
#

# Generated at 2022-06-20 12:54:59.785637
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+', default=None)
    opts = parser.parse_args(['--foo', 'a', '--foo', 'b'])
    print(opts.foo)


# Generated at 2022-06-20 12:55:09.918047
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(['-P', 10, '-B', 5])
    assert (options.poll_interval == 10)
    assert (options.seconds == 5)



# Generated at 2022-06-20 12:55:21.089645
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(beacon='#')('#foo') == '#' + unfrackpath('foo')
    assert maybe_unfrack_path(beacon='#')('#foo/bar') == '#' + unfrackpath('foo/bar')
    assert maybe_unfrack_path(beacon='#')('#/foo/bar') == '#' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path(beacon='#')('#/') == '#/'
    assert maybe_unfrack_path(beacon='#')('#~') == '#~'
    assert maybe_unfrack_path(beacon='#')('#~/foo') == '#~' + unfrackpath('/foo')
    assert maybe_un

# Generated at 2022-06-20 12:55:23.716268
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args(['-v','-v'])
    assert options.verbosity == 2


# Generated at 2022-06-20 12:55:28.978236
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    given = ['--extra-vars', 'key1=value1', '--extra-vars', 'key2=value2', '--extra-vars', '@test.yaml']
    expect = {'extra_vars': ['key1=value1', 'key2=value2', '@test.yaml']}
    parsed = parser.parse_args(given)
    assert vars(parsed) == expect



# Generated at 2022-06-20 12:55:30.468361
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(prog='ansible-test')
    add_fork_options(parser)
    opts = parser.parse_args()
    assert opts.forks == C.DEFAULT_FORKS



# Generated at 2022-06-20 12:55:42.494313
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace, const, parser, option_string, values, items = \
        argparse.Namespace(), [1], argparse.ArgumentParser(), '--items', [2], []
    PrependListAction(option_strings=option_string, dest='items', const=const, nargs='?') \
        .__call__(parser=parser, namespace=namespace, values=values, option_string=option_string)
    assert getattr(namespace, 'items') == [2, 1]
    namespace, values = argparse.Namespace(), [3, 4]
    PrependListAction(option_strings=option_string, dest='items', const=const, nargs='*') \
        .__call__(parser=parser, namespace=namespace, values=values, option_string=option_string)

# Generated at 2022-06-20 12:55:52.913245
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)


# Generated at 2022-06-20 12:55:57.111728
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '5', '-B', '10'])
    assert args.poll_interval == 5
    assert args.seconds == 10

# Generated at 2022-06-20 12:56:00.424277
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    data = parser.parse_args(['--tags', 'test1', '--tags', 'test2', '--skip-tags', 'test3', '--skip-tags', 'test4'])
    assert data.tags == ['test1', 'test2']
    assert data.skip_tags == ['test3', 'test4']


# Generated at 2022-06-20 12:56:04.449058
# Unit test for function add_module_options
def test_add_module_options():
    p = argparse.ArgumentParser()
    add_module_options(p)
    args = p.parse_args(['-M', 'path1', '-M', 'path2'])
    assert args.module_path == ['path1', 'path2']



# Generated at 2022-06-20 12:56:20.664804
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument('abc')
    parser.add_argument('def', default=[])
    parser.add_argument('ghi', action=PrependListAction)
    namespace = parser.parse_args([])
    assert namespace.abc is None
    namespace = parser.parse_args(['one'])
    assert namespace.abc == 'one'
    # Ensure that our custom action returns the same as argparse's default
    # _AppendAction
    correct_namespace = parser.parse_args(['--ghi', 'two'])
    assert correct_namespace.ghi == ['two']
    assert namespace.ghi == correct_namespace.ghi
    # Ensure that we correctly prepend list items to an existing list

# Generated at 2022-06-20 12:56:32.499677
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args('--extra-vars @/path/to/file.yml --extra-vars @/path/to/file.json --extra-vars foo=bar'.split())
    eq_(args.extra_vars[0], '/path/to/file.yml')
    eq_(args.extra_vars[1], '/path/to/file.json')
    eq_(args.extra_vars[2], 'foo=bar')

# Generated at 2022-06-20 12:56:36.953537
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(
        prog='ansible-config',
        formatter_class=SortingHelpFormatter,
    )
    add_vault_options(parser)
    opts, _ = parser.parse_known_args(['--vault-id', '123', '--vault-id', '456', '--ask-vault-pass'])
    assert opts.vault_ids == ['123', '456']
    assert opts.ask_vault_pass is True
    assert opts.vault_password_files == []

# Generated at 2022-06-20 12:56:43.115971
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_inventory_options(parser)
    options = parser.parse_args(["-i", "my-inventory-file.ini", "--list-hosts", "-l", "*_hosts"])
    assert options.inventory == ["my-inventory-file.ini"]
    assert options.listhosts == True
    assert options.subset == "*_hosts"



# Generated at 2022-06-20 12:56:51.317242
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class Argument:
        def __init__(self, option_string, action):
            self.option_strings = option_string
            self.action = action

    actions = [Argument('-b', 'store_true'),
               Argument('-c', 'store_true'),
               Argument('-d', 'store_true'),
               Argument('-a', 'store_true'),
               Argument('-b', 'store_true'),
               Argument('-bc', 'store_true')]
    # call the target function
    SortingHelpFormatter().add_arguments(actions)
    # check
    assert actions[0].option_strings == '-a'
    assert actions[1].option_strings == '-b'
    assert actions[2].option_strings == '-b'

# Generated at 2022-06-20 12:57:01.945755
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ANSIBLE', formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_vault_options(parser)
    argv = ['--ask-vault-password', '--vault-id=myvault', '--vault-password-file=vaultpass.txt', '--vault-id=myvault2', '--vault-password-file=vaultpass2.txt']
    options = parser.parse_args(args=argv)
    assert options.ask_vault_pass is True
    assert options.vault_ids == ['myvault', 'myvault2']
    assert options.vault_password_files == ['vaultpass.txt', 'vaultpass2.txt']



# Generated at 2022-06-20 12:57:06.787324
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parsed_cmd = parser.parse_args(['--playbook-dir', '/tmp/test/'])
    parsed_cmd = parser.parse_args(['--playbook-dir', './rel/path'])



# Generated at 2022-06-20 12:57:14.798318
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import types
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        test_add_arguments="test value")
    parser.add_argument('-h', '--help', dest='help', action='store_true', help='show help')
    parser.add_argument('-d', '--debug', dest='debug', action='store_true', help='show debug')
    parser.add_argument('-f', '--foo', dest='foo', action='store_true', help='show foo')
    parser.add_argument('-bar', dest='bar', action='store_true', help='show bar')
    parser.add_argument('-c', dest='c', action='store_true', help='show c')

# Generated at 2022-06-20 12:57:24.923106
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args_list = ['', '--connection=local', '--connection=ssh', '--connection=paramiko']
    for args in args_list:
        res = parser.parse_args(args.split())
        assert res.connection == 'local' or res.connection == 'ssh' or res.connection == 'paramiko'
        assert res.timeout == 300
        assert res.ask_pass == False
        assert res.remote_user == 'default_user'
        assert res.private_key_file == '/home/default_user/.ssh/id_rsa'
        assert res.connection_password_file == '/home/default_user/.vault_pass.txt'
        assert res.ssh_common_args is None
        assert res.sftp

# Generated at 2022-06-20 12:57:26.334184
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(["-f","10"])
    assert options.forks == 10


# Generated at 2022-06-20 12:57:42.376948
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path_1 = "~/ansible/test_module.py"
    path_2 = "%s/ansible/test_module.py" % os.path.expanduser("~")
    assert maybe_unfrack_path('~')(path_1) == path_2
#
# Standard Options
#

# Generated at 2022-06-20 12:57:44.778702
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
  parser = argparse.ArgumentParser()
  add_runas_prompt_options(parser)
  options = parser.parse_args('-K --become-password-file sample-become-password-file'.split())
  assert options.become_ask_pass == True
  assert options.become_password_file == 'sample-become-password-file'



# Generated at 2022-06-20 12:57:50.659257
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# This is to avoid putting holes in the parser.  By default, argparse
# makes '--' mean the end of the options.  Since we want to allow '--' in
# args that would come later, we need to explicitly state this.

# Generated at 2022-06-20 12:57:54.988807
# Unit test for function add_async_options
def test_add_async_options():
    parser = MockOptionParser()
    add_async_options(parser)
    assert isinstance(parser.actions[0], argparse.Action)
    assert isinstance(parser.actions[1], argparse.Action)
    assert parser.actions[0].dest == 'poll_interval'
    assert parser.actions[1].dest == 'seconds'



# Generated at 2022-06-20 12:58:01.917339
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = vars(parser.parse_args(["--tags", "web", "--skip-tags", "ini"]))
    assert ["web"] == args["tags"]
    assert ["ini"] == args["skip_tags"]

# Test for idempotency
    args = vars(parser.parse_args(["--tags", "web", "--skip-tags", "ini", "--tags", "all", "--skip-tags", "none"]))
    assert ["all"] == args["tags"]
    assert ["none"] == args["skip_tags"]



# Generated at 2022-06-20 12:58:02.483916
# Unit test for function add_module_options
def test_add_module_options():
    assert True


# Generated at 2022-06-20 12:58:14.450415
# Unit test for function version
def test_version():
    if sys.version_info >= (3, 6):
        assert version('prog_name') == 'prog_name [core 2.10.6]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/local/lib/python3.6/dist-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible\n  python version = 3.6.9 (default, Nov  7 2019, 10:44:02)\n[GCC 8.3.0]\n  jinja version = 2.10.3\n  libyaml = True'

# Generated at 2022-06-20 12:58:24.090201
# Unit test for function version
def test_version():
    """
    Check the format of the version output
    :return: True if the version output matches the expected format
    :rtype: bool
    """
    import re
    v = version()

# Generated at 2022-06-20 12:58:29.031786
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser('test.py', 'test')
    add_fork_options(parser)
    cli_args = parser.parse_args(['-f 2'])
    assert cli_args.forks == 2


# Generated at 2022-06-20 12:58:36.286431
# Unit test for function add_check_options
def test_add_check_options():
    # construct the parser
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    # create a fake args namespace
    args = argparse.Namespace()
    # parse '--check' option
    opt = '--check'
    opts = [opt] if isinstance(opt, str) else opt
    parser.parse_args(opts, args)
    assert getattr(args, 'check') is True
    # parse '--syntax-check' option
    opt = '--syntax-check'
    opts = [opt] if isinstance(opt, str) else opt
    parser.parse_args(opts, args)
    assert getattr(args, 'syntax') is True
    # parse '--diff' option
    opt = '--diff'

# Generated at 2022-06-20 12:58:53.362674
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.basedir == C.config.get_config_value('PLAYBOOK_DIR')
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    (options, args) = parser.parse_known_args(['--playbook-dir', '/tmp'])
    assert options.basedir == '/tmp'



# Generated at 2022-06-20 12:59:04.147593
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from io import StringIO
    from unittest import TestCase

    class AnsibleVersionTester(TestCase):
        def setUp(self):
            self.parser = argparse.ArgumentParser()
            self.action = AnsibleVersion(self.parser)

        def test_AnsibleVersion__call__(self):
            stdout = sys.stdout

            try:
                sys.stdout = StringIO()

                self.action(self.parser, 'prog')
                self.assertEqual(sys.stdout.getvalue(), 'prog\n')
            finally:
                sys.stdout.close()
                sys.stdout = stdout

    AnsibleVersionTester().setUp().test_AnsibleVersion__call__()

# Generated at 2022-06-20 12:59:09.123994
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = './foo/bar'
    beacon = '~'
    expected_result = '~/foo/bar'
    result = maybe_unfrack_path(beacon)(test_path)
    assert result == expected_result
    test_path_2 = 'foo/bar'
    result_2 = maybe_unfrack_path(beacon)(test_path_2)
    assert result_2 == test_path_2
# end of unit test for maybe_unfrack_path


# Generated at 2022-06-20 12:59:12.161590
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

    with open(C.DEFAULT_PRIVATE_KEY_FILE) as f:
        f.close()


# Generated at 2022-06-20 12:59:17.260972
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser(description='test PrependListAction')
    parser.add_argument('--foo', action=PrependListAction, type=str, dest='foo')
    namespace = parser.parse_args(args=['--foo=1', '--foo=2', '--foo=3'])
    assert namespace.foo == ['3', '2', '1']



# Generated at 2022-06-20 12:59:22.771080
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    mup = maybe_unfrack_path('@')
    assert mup('@/foo/bar') == '@/foo/bar'
    assert mup('@@/baz') == '@@/baz'
    assert mup('@/foo/bar') != '@@/baz'



# Generated at 2022-06-20 12:59:29.514332
# Unit test for function add_check_options
def test_add_check_options():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common import filters, warnings

    for _warnings_manager in (warnings, filters):
        _warnings_manager.reset()

        parser = argparse.ArgumentParser()
        add_check_options(parser)

        # Checked or not, diff should be True because of the default
        args = parser.parse_args(['-D'])
        assert args.check, 'set check false'
        assert args.diff, 'set diff false'
        assert args.syntax is False, 'set syntax true'

        args = parser.parse_args(['--check'])
        assert args.check, 'set check false'
        assert args.diff, 'set diff false'

# Generated at 2022-06-20 12:59:33.142490
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    if os.name != "nt":
        parser = argparse.ArgumentParser()
        parser.prog = "ansible-playbook"
        args = parser.parse_args([])
        #__call__(parser, namespace, values, option_string=None)



# Generated at 2022-06-20 12:59:37.862831
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    ns = argparse.Namespace()
    test = PrependListAction(option_strings="-o", dest="pos_args")
    test(parser=None, namespace=ns, values=['test'], option_string=None)
    assert ns.pos_args == ['test']


#
# General purpose OptionParsers
#

# Generated at 2022-06-20 12:59:43.944771
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # No beacon
    assert 'foo' == maybe_unfrack_path('@')('foo')
    # Beacon with no path modification
    assert '@foo' == maybe_unfrack_path('@')('@foo')
    # Beacon with path modification
    assert '@' + unfrackpath('foo') == maybe_unfrack_path('@')('@foo')



# Generated at 2022-06-20 13:00:13.896914
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    parser.parse_args(['--private-key=xyz', '--connection', 'xyz', '-u', 'xyz'])


# Generated at 2022-06-20 13:00:25.898414
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    prog = "ansible-playbook"
    desc = "Run Ansible playbooks, specifying the playbook and inventory filenames as arguments."
    epilog = "more info about %s" % prog
    parser = create_base_parser(prog, usage="%(prog)s [options] playbook.yml", desc=desc, epilog=epilog)
    add_runtask_options(parser)
    args = parser.parse_args(["-i", "localhost,", "--extra-vars", "@test.json", "--become","-K", "--inventory-file", "test.ini", "--list-tasks", "test.yml"])
    assert args.inventory == ['localhost,']
    assert args.extra_vars == ['@test.json']
    assert args.become == True

# Generated at 2022-06-20 13:00:28.817965
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    testargs = ['--task-timeout', '5']
    parser = argparse.ArgumentParser(prog='test')
    add_tasknoplay_options(parser)
    parser.parse_args(testargs)



# Generated at 2022-06-20 13:00:34.886259
# Unit test for function add_vault_options

# Generated at 2022-06-20 13:00:44.304984
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    formatter = SortingHelpFormatter()
    group = argparse.ArgumentParser(description='description')
    group.add_argument('--aaa')
    group.add_argument('--bbb')
    group.add_argument('--ccc')
    group.add_argument('--111')
    group.add_argument('--222')
    help_group = copy.copy(group)
    help_group.formatter = formatter
    with capture_output() as (stdout, stderr):
        help_group.print_help()
        generated_help = stdout.getvalue()
    assert "--111" in generated_help
    assert "--222" in generated_help
    assert "--aaa" in generated_help
    assert "--bbb" in generated_help
    assert "--ccc" in generated_

# Generated at 2022-06-20 13:00:47.289642
# Unit test for function add_runtask_options
def test_add_runtask_options():
    a = parser = argparse.ArgumentParser(
        prog='ansible-2.8',
        description='test for ansible-doc'
    )
    add_runtask_options(a)
    cmd = a.parse_args(["--extra-vars", "test"])
    assert cmd.extra_vars == ['test']

# Generated at 2022-06-20 13:00:50.359404
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(''))
    # Parser for testing class
    parser = argparse.ArgumentParser()
    # call method
    AnsibleVersion(option_string='--version')(parser, None, None)
    assert ansible_version == parser.exit()


# Generated at 2022-06-20 13:00:55.287361
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser("test_add_check_options")
    add_check_options(parser)
    options = parser.parse_args(['--check'])
    assert options.check == True
    options = parser.parse_args(['--syntax-check'])
    assert options.syntax == True
    options = parser.parse_args(['-D'])
    assert options.diff == True



# Generated at 2022-06-20 13:00:59.358540
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_known_args(['-f', '10'])
    assert args == (argparse.Namespace(forks=10), [])



# Generated at 2022-06-20 13:01:02.436883
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)

    options = parser.parse_args(['-o', '-t'])

    assert options.one_line is True
    assert options.tree is not None


# Generated at 2022-06-20 13:01:34.630915
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook', conflict_handler='resolve')
    add_async_options(parser)
    options = parser.parse_args(['-P', '15', '-B', '30'])
    assert options.poll_interval == 15
    assert options.seconds == 30

