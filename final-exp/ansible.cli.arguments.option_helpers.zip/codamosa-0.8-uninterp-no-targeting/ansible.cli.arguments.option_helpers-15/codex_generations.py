

# Generated at 2022-06-20 12:52:03.885964
# Unit test for function add_subset_options
def test_add_subset_options():
    #Test Case 1:
    parser1 = Mock()
    draw_option_pairs(parser=parser1, options_def={"tags": ("-t", "--tags"), "skip-tags": ("", "--skip-tags")})
    assert parser1.add_argument.call_count == 2

    #Test Case 2:
    parser2 = Mock()
    draw_option_pairs(parser=parser2, options_def={"tags": ("-t", "--tags")})
    assert parser2.add_argument.call_count == 1


# Logic for option-pair (short and long)

# Generated at 2022-06-20 12:52:11.695535
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.cli import CLI
    from ansible.utils.path import unfrackpath

    parser = CLI.base_parser(
        usage='%(prog)s [options]',
        desc='Ansible command line tool to orchestrate software deployments',
        epilog='# Alternatively, a YAML file can be provided to the command via stdin'
    )
    parser.add_argument('--foo', action=PrependListAction)
    namespace = parser.parse_args(['--foo', 'one', 'two'])
    assert namespace.foo == ['two', 'one']
    namespace = parser.parse_args(['--foo', 'one', '--foo', 'two'])
    assert namespace.foo == ['one', 'two']

# Generated at 2022-06-20 12:52:12.366903
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    assert True


# Generated at 2022-06-20 12:52:16.267289
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = create_base_parser("ansible-test-1")
    add_tasknoplay_options(parser)
    options = parser.parse_args(["--task-timeout", "10"])
    assert options.task_timeout == 10
    options = parser.parse_args(["--task-timeout", "0"])
    assert options.task_timeout == C.TASK_TIMEOUT
    options = parser.parse_args(["--task-timeout", "-10"])
    assert options.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-20 12:52:20.367331
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '1'])
    assert args.task_timeout == 1



# Generated at 2022-06-20 12:52:33.100138
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace(object):
        pass
    ns = FakeNamespace()
    ensure_value(ns, 'new_var', None)
    assert 'new_var' in dir(ns)
    assert ns.new_var is None
    ensure_value(ns, 'new_var', 'a value')
    assert ns.new_var == 'a value'
    ensure_value(ns, 'existing_var', 'a value')
    assert ns.existing_var == 'a value'
    ns.existing_var = 'another value'
    ensure_value(ns, 'existing_var', 'a value')
    assert ns.existing_var == 'another value'

#
# Constants
#
SETUP_PARSER = 'setup_parser'
PARSE_ARGS = 'parse_args'


#
# Module attributes

# Generated at 2022-06-20 12:52:35.774463
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='Acceptance test for function add_runas_options')
    add_runas_options(parser)


# Generated at 2022-06-20 12:52:43.438806
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, args = parser.parse_known_args(['-C'])
    assert options.check is True
    options, args = parser.parse_known_args(['--syntax-check'])
    assert options.syntax is True
    options, args = parser.parse_known_args(['-D'])
    assert options.diff is True


# Generated at 2022-06-20 12:52:47.652723
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser('test')
    parser.add_argument('--foo', action=PrependListAction, default=[])
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']

# Generated at 2022-06-20 12:52:53.075767
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    par = argparse.ArgumentParser()
    par.add_argument('--arg',action=PrependListAction,nargs='*',type=int,choices=[1,2,3,4,5],help='help')
    assert par.parse_args(['--arg','1','2','3']).arg == [1,2,3]

# Generated at 2022-06-20 12:53:39.395423
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("~") == unfrackpath("~")
    assert unfrack_path()("~/") == unfrackpath("~/")
    assert unfrack_path()("~/foo") == unfrackpath("~/foo")
    assert unfrack_path()("~/1/../") == unfrackpath("~/")
    assert unfrack_path()("~/1/..") == unfrackpath("~")
    assert unfrack_path()("~/1/../../") == unfrackpath("~/")
    assert unfrack_path()("~/1/../../..") == unfrackpath("~")
    assert unfrack_path()("~/1/2/../../../..") == unfrackpath("~")

# Generated at 2022-06-20 12:53:49.318835
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(
        prog='ansible-test',
        formatter_class=SortingHelpFormatter,
        epilog='Use the test-module utility module to test modules.',
        description='Runs a module against a specific host or list of hosts.'
    )
    add_tasknoplay_options(parser)
    add_connection_options(parser)
    add_verbosity_options(parser)
    opts = parser.parse_args()
    if opts.task_timeout < 0:
        raise AnsibleOptionsError("task timeout must be positive integer")
# END of Unit test for function add_tasknoplay_options



# Generated at 2022-06-20 12:53:50.803662
# Unit test for function add_meta_options
def test_add_meta_options():
    x = argparse.ArgumentParser()
    add_meta_options(x)
    args = x.parse_args([])
    assert args.force_handlers == C.DEFAULT_FORCE_HANDLERS
    

# Generated at 2022-06-20 12:54:01.131035
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    class Arguments(object):
        def __init__(self):
            self.version = False
            self.connection = None
            self.module_name = None
            self.check = False
            self.inventory = None
            self.module_paths = None
            self.forks = None
            self.become = False
            self.become_method = None
            self.become_user = None
            self.listhosts = None
            self.subset = None
            self.remote_user = None
            self.verbosity = None
            self.extra_vars = None
            self.ask_vault_pass = False
            self.vault_password_file = None
            self.new_vault_password_file = None
            self.output_file = None
            self.one_line = None

# Generated at 2022-06-20 12:54:07.451897
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    options = _parse_args(parser, 'dev')
    assert options.task_timeout == C.TASK_TIMEOUT
    options = _parse_args(parser, 'dev', ['--task-timeout', '30'])
    assert options.task_timeout == 30



# Generated at 2022-06-20 12:54:17.983050
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args([])
    assert args.module_path == None
    args = parser.parse_args(['-M', '/path/one', '-M', '/path/two'])
    assert args.module_path == ['/path/two', '/path/one']
    args = parser.parse_args(['-M', '/path/one:/path/two'])
    assert args.module_path == ['/path/one:/path/two']
    args = parser.parse_args(['-M', '/path/one', '-M', '/path/two:/path/three'])
    assert args.module_path == ['/path/two:/path/three', '/path/one']



# Generated at 2022-06-20 12:54:27.172185
# Unit test for function unfrack_path
def test_unfrack_path():
    path_sep = os.pathsep
    os.pathsep = ';'
    assert ['playbooks', 'playbooks/library', 'playbooks/library/module_utils'] == unfrack_path(True)('playbooks;playbooks/library;playbooks/library/module_utils')
    os.pathsep = ':'
    assert ['playbooks', 'playbooks/library', 'playbooks/library/module_utils'] == unfrack_path(True)('playbooks:playbooks/library:playbooks/library/module_utils')
    os.pathsep = path_sep
    assert './' == unfrack_path()('./')


# Generated at 2022-06-20 12:54:31.869350
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    global parser
    parser = argparse.ArgumentParser(
        prog="test_argparse_play",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_tasknoplay_options(parser)
    parser.parse_args("-h".split())



# Generated at 2022-06-20 12:54:36.893063
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    options = parser.parse_args(['--forks', '42'])
    assert options.forks == 42



# Generated at 2022-06-20 12:54:43.383702
# Unit test for function add_vault_options
def test_add_vault_options():
    my_parser = Mock()

    my_parser.add_argument = MagicMock()
    my_parser.add_mutually_exclusive_group = MagicMock()
    add_vault_options(my_parser)

    assert my_parser.add_argument.call_count == 3 
    assert my_parser.add_mutually_exclusive_group.call_count == 1
    assert my_parser.add_mutually_exclusive_group().add_argument.call_count == 2


# Generated at 2022-06-20 12:54:55.821991
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    assert UnrecognizedArgument('--not-a-real-arg', 'bar').option_strings == ['--not-a-real-arg']
    assert UnrecognizedArgument(['--not-a-real-arg'], 'bar').dest == 'bar'
    assert UnrecognizedArgument(['--not-a-real-arg'], 'bar', required=True).required is True



# Generated at 2022-06-20 12:54:58.262952
# Unit test for function ensure_value
def test_ensure_value():
    class Dummy:
        pass
    assert ensure_value(Dummy(), 'var', []) == []


#
# Argument parsing helper functions
#

# Generated at 2022-06-20 12:55:05.202259
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # unfrack_path
    assert(maybe_unfrack_path('@')('@/tmp/path') == '@' + unfrackpath('/tmp/path') )
    # do not unfrack_path
    assert(maybe_unfrack_path('@')('@@') == '@@')
    assert(maybe_unfrack_path('@')('@1') == '@1')
    assert(maybe_unfrack_path('@')('@/tmp/path') == '@/tmp/path')


# Generated at 2022-06-20 12:55:10.785717
# Unit test for function add_meta_options
def test_add_meta_options():
    p = argparse.ArgumentParser()
    add_meta_options(p)
    d = p.parse_args('--force-handlers'.split())
    assert d.force_handlers
    assert d.flush_cache is None
    assert d.flush_cache is None
    d = p.parse_args('--flush-cache'.split())
    assert d.flush_cache
    d = p.parse_args('--flush-cache --force-handlers'.split())
    assert d.flush_cache
    assert d.force_handlers


# Generated at 2022-06-20 12:55:17.334680
# Unit test for function add_async_options
def test_add_async_options():
    # Test AddAsyncOptionsParser()
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    # Test call of the parser
    my_args = ['-P 5', '-B 7']
    my_ns = parser.parse_args(my_args)
    assert my_ns.poll_interval == 5
    assert my_ns.seconds == 7



# Generated at 2022-06-20 12:55:19.959942
# Unit test for function add_fork_options
def test_add_fork_options():
    fork_options = ['forks']
    for i in fork_options:
        if i not in sys.argv:
            raise Exception("Failed to find option %s" % i)
    print("test_add_fork_options: pass")

test_add_fork_options()


# Generated at 2022-06-20 12:55:28.308914
# Unit test for function add_basedir_options
def test_add_basedir_options():
    """ Unit test for function add_basedir_options"""
    # pylint: disable=too-many-branches,too-many-locals,too-many-statements,protected-access
    from ansible import context
    from ansible.config.manager import ConfigManager
    from ansible.cli import CLI
    from ansible.executor import playbook_executor

    cli = CLI(args=[])
    cli.options, cli.args = cli.parser.parse_known_args()
    context.CLIARGS = cli.args

    config_manager = ConfigManager(cli.options, constants=C)
    config_manager.options = cli.options
    config_manager.options.config_file = os.devnull

    # pylint: disable=protected-access
    context._init_global_context

# Generated at 2022-06-20 12:55:33.041174
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'user1', '--vault-id', 'user2', '--ask-vault-password'])
    assert options.vault_ids == ['user1', 'user2'] and options.ask_vault_pass is True
    options = parser.parse_args(['--vault-id', 'user1', '--vault-password-file', '~/vault-password.txt'])
    assert options.vault_ids == ['user1'] and options.vault_password_files == ['~/vault-password.txt']



# Generated at 2022-06-20 12:55:38.966910
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    test constructor of class PrependListAction
    """
    action = PrependListAction(option_strings=['-Q', '--quiet'], dest='quiet', const=None, default=None, type=int,
                               choices=None, required=False, help='Decrease verbosity of module output', metavar='speed')
    assert action != None



# Generated at 2022-06-20 12:55:50.017392
# Unit test for function add_basedir_options
def test_add_basedir_options():
    input_json_file = '{"PLAYBOOK_DIR": "/Users/selvam/.ansible/plugins/playbooks"}'
    C.CONFIG_DATA[C.CONFIG_FILE_NAME] = os.path.join(C.DEFAULT_LOCAL_TMP, C.CONFIG_FILE_NAME)
    with open(C.CONFIG_DATA[C.CONFIG_FILE_NAME], 'w') as config_file:
        config_file.write(input_json_file)
    parser = create_base_parser('ansible-connection', usage="", desc=None, epilog=None)
    add_basedir_options(parser)

# Generated at 2022-06-20 12:55:57.597061
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options, args = parser.parse_known_args(['-o', '-t', 'tree'])
    assert options.one_line == True
    assert options.tree == 'tree'


# Generated at 2022-06-20 12:56:07.892415
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    test_namespace = argparse.Namespace()
    test_action = PrependListAction(
        option_strings=['action_option_1', 'action_option_2'],
        dest='test_dest',
        nargs='*',
        const=None,
        default=None,
        type=None,
        choices=None,
        required=False,
        help=None,
        metavar='action_metavar'
    )
    test_action(parser=None, namespace=test_namespace, values=['test_value_1', 'test_value_2'], option_string=None)
    assert ['test_value_1', 'test_value_2'] == ensure_value(test_namespace, 'test_dest', [])



# Generated at 2022-06-20 12:56:18.888370
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = Mock()
    add_vault_options(parser)
    parser.add_argument.assert_called_with('--vault-id', default=[], dest='vault_ids', action='append', type=str, help='the vault identity to use')
    parser.add_mutually_exclusive_group.return_value.add_argument.assert_any_call('--ask-vault-password', '--ask-vault-pass', default=C.DEFAULT_ASK_VAULT_PASS, dest='ask_vault_pass', action='store_true', help='ask for vault password')

# Generated at 2022-06-20 12:56:24.539627
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class A(object):
        def __init__(self, option_strings):
            self.option_strings = option_strings
    parser = SortingHelpFormatter() # do not use default_main_parser to avoid
                                    # loop import
    parser.add_arguments([A(['-z']), A(['-a']), A(['-b', '--B'])])
    assert parser._action_max_length == 7
    assert parser._actions == [A(['-a']), A(['-b', '--B']), A(['-z'])]



# Generated at 2022-06-20 12:56:32.820614
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args([])
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP

    args = parser.parse_args(['-t', '1', '-t', '2', '--skip-tags', '3', '--skip-tags', '4'])
    assert args.tags == ['1', '2']
    assert args.skip_tags == ['3', '4']



# Generated at 2022-06-20 12:56:37.588579
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    """
    >>> parser = argparse.ArgumentParser()
    >>> parser.add_argument = UnrecognizedArgument
    >>> parser.add_argument('--foo')
    Traceback (most recent call last):
    ...
    SystemExit: 2
    """



# Generated at 2022-06-20 12:56:43.624717
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    from ansible.utils.display import Display
    from ansible.bin.cli import CLI
    display = Display()
    parser = CLI.base_parser(constants=C, display=display)
    parser.prog = "ansible-config"
    parser.parse_args([])
    ansible_version = to_native(version(getattr(parser, 'prog')))
    assert ansible_version is not None



# Generated at 2022-06-20 12:56:49.019260
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)

    parser.add_argument.assert_any_call('--force-handlers', default='yes', dest='force_handlers', action='store_true',
                        help="run handlers even if a task fails")
    parser.add_argument.assert_any_call('--flush-cache', dest='flush_cache', action='store_true',
                        help="clear the fact cache for every host in inventory")


# Generated at 2022-06-20 12:57:00.401676
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        prog='ansible-test',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_check_options(parser)
    options = parser.parse_args([])
    assert options.check == False
    assert options.syntax == False
    assert options.diff == C.DIFF_ALWAYS
    options = parser.parse_args(["--check"])
    assert options.check == True
    assert options.syntax == False
    assert options.diff == C.DIFF_ALWAYS
    options = parser.parse_args(["--syntax-check"])
    assert options.check == False
    assert options.syntax == True
    assert options.diff == C

# Generated at 2022-06-20 12:57:07.460024
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    for nargs in (1, 2, None):
        parser = AnsibleParser(_files=[])
        parser.add_option('-a')
        parser.add_option('-b', action=PrependListAction)
        options, args = parser.parse_args(['-a', 'b', '-b', 'c', 'd'])
        assert options.a == 'b'
        assert options.b == ['c', 'd']


#
# AnsibleOptionParser
#

# Generated at 2022-06-20 12:57:21.101809
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    p = argparse.ArgumentParser()
    p.add_argument('-a', action=PrependListAction)
    a = p.parse_args(['-a', 'b', '-a', 'c', '-a', 'a'])
    print(a)
    assert a.a == ['a', 'c', 'b']



# Generated at 2022-06-20 12:57:22.561027
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert parser.get_default('force_handlers') == C.DEFAULT_FORCE_HANDLERS


# Generated at 2022-06-20 12:57:32.866630
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    parsed = parser.parse_args([""])
    assert not parsed.check
    assert not parsed.syntax
    assert not parsed.diff
    parsed = parser.parse_args(["-C"])
    assert parsed.check
    assert not parsed.syntax
    assert not parsed.diff
    parsed = parser.parse_args(["--syntax-check"])
    assert not parsed.check
    assert parsed.syntax
    assert not parsed.diff
    parsed = parser.parse_args(["-D"])
    assert not parsed.check
    assert not parsed.syntax
    assert parsed.diff
    parsed = parser.parse_args(["-C","--syntax-check","-D"])
    assert parsed.check

# Generated at 2022-06-20 12:57:36.622236
# Unit test for function add_fork_options
def test_add_fork_options():
    sample_cmd = 'ansible-playbook --version'
    sample_parser = create_base_parser('ansible-playbook', desc='Test for add_fork_option', epilog='Test for add_fork_options')
    add_fork_options(sample_parser)
    sample_args = sample_parser.parse_args(sample_cmd.split())

    output = '-f, --forks INTEGER\n    specify number of parallel processes to use (default=5)'
    assert output in sample_parser.format_help()
    assert sample_args.forks == 5


# Generated at 2022-06-20 12:57:38.262624
# Unit test for function create_base_parser
def test_create_base_parser():
    assert isinstance(create_base_parser("test_prog"), argparse.ArgumentParser)


# Generated at 2022-06-20 12:57:48.898250
# Unit test for function add_runtask_options
def test_add_runtask_options():
    # Check for newly added options in add_runtask_options
    my_option = '-e'  # option to be tested
    usage = "usage: ansible <host-pattern> [options]"
    parser = argparse.ArgumentParser(
        prog='ansible',
        usage=usage,
        formatter_class=argparse.RawTextHelpFormatter,
        epilog='''
        Other commands:
        '''
    )
    add_runtask_options(parser)
    result = parser.parse_known_args(['-e'])
    assert result[0].extra_vars == [], 'Error: add_runtask_options is not working'



# Generated at 2022-06-20 12:57:58.036176
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(
        prog='ansible-playbook',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_subset_options(parser)
    options, args = parser.parse_known_args(args=['--skip-tags=test_skip_tags'])
    assert options.tags == None
    assert options.skip_tags == 'test_skip_tags'
    options, args = parser.parse_known_args(args=['--skip-tags=test_skip_tags', '--skip-tags=test_skip_tags_2'])
    assert options.skip_tags == ['test_skip_tags', 'test_skip_tags_2']



# Generated at 2022-06-20 12:58:00.416986
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args=parser.parse_args(["-t", "adir"])
    assert args.tree == "adir"



# Generated at 2022-06-20 12:58:11.216545
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@/foo/bar") == "@/foo/bar"
    assert maybe_unfrack_path("@")("@@/foo/bar") == "@/foo/bar"
    assert maybe_unfrack_path("@")("@@/foo/@@bar") == "@/foo/@@bar"
    assert maybe_unfrack_path("@")("@/foo/@@bar") == "@/foo/@bar"
    assert maybe_unfrack_path("@")("@@/foo/@bar") == "@/foo/bar"
    assert maybe_unfrack_path("!")("!/foo/bar") == "!/foo/bar"
    assert maybe_unfrack_path("!")("!/foo/!") == "!/foo/!"
    assert maybe_unfrack_

# Generated at 2022-06-20 12:58:16.591568
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # AnsibleVersion action should print ansible version and exit
    parser = argparse.ArgumentParser(description='Ansible Version Test')
    parser.add_argument('--version', action=AnsibleVersion, required=False)
    namespace = parser.parse_args(['--version'])
    assert namespace.version == ''



# Generated at 2022-06-20 12:58:44.529906
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='test_prog')
    add_check_options(parser)
    args = parser.parse_args(['--check', '--syntax-check', '--diff'])
    expected = argparse.Namespace(check=True, diff=True, syntax=True)
    assert args == expected, 'Add check options: Expected %s, got %s' % (expected, args)



# Generated at 2022-06-20 12:58:52.892149
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(["--ask-vault-password"])
    assert args.ask_vault_pass
    args = parser.parse_args(["--ask-vault-pass"])
    assert args.ask_vault_pass
    args = parser.parse_args(["--vault-password-file", "unittest_path"])
    assert args.vault_password_files == ["unittest_path"]

# Generated at 2022-06-20 12:59:04.019402
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace():
        pass

    n = Namespace()
    assert ensure_value(n, "test_ensure_value", "value") == 'value'
    assert getattr(n, "test_ensure_value", None) == 'value'
    assert ensure_value(n, "test_ensure_value", "value2") == 'value'
    assert getattr(n, "test_ensure_value", None) == 'value'

    # Test function ensure_value again to make sure it works
    # as expected when a default value has already been set
    n = Namespace()
    setattr(n, "test_ensure_value", "default")
    assert ensure_value(n, "test_ensure_value", "value") == 'default'

# Generated at 2022-06-20 12:59:10.730612
# Unit test for function version
def test_version():
    assert not version().startswith("\n")
    assert version("ansible").startswith("ansible")
    assert version("ansible-config").startswith("ansible-config")
    # C.CONFIG_FILE is a NoneType when running test_version in test_version module
    # when running test_version in test_version module, we won't have configured
    # search paths, etc.
    assert "config file = " in version("ansible")
    assert "configured module search path = " in version("ansible")
    assert "ansible python module location = " in version("ansible")
    assert "ansible collection location = " in version("ansible")
    assert "executable location = " in version("ansible")
    assert "python version = " in version("ansible")

# Generated at 2022-06-20 12:59:18.444733
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser("Test usage for argparse", usage="")
    add_inventory_options(parser)
    opt = parser.parse_args("-i inventory host path".split())
    assert opt.inventory == ["inventory host path"]
    # test --list-hosts
    opt = parser.parse_args("--list-hosts".split())
    assert opt.listhosts == True
    # test -l
    opt = parser.parse_args("-l limit".split())
    assert opt.subset == 'limit'
    return True


# Generated at 2022-06-20 12:59:26.320278
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.unittest_utils.ansible_module_runner import AnsibleModuleRunner
    args = ['foo.yml']
    namespace = QueryNamespace()
    module_runner = AnsibleModuleRunner()
    parser = module_runner.create_parser()
    dest = 'tags'
    prepend_list_action = PrependListAction(option_strings=['-t'], dest=dest, nargs=argparse.OPTIONAL)
    prepend_list_action(parser, namespace, args, option_string='-t')
    pass

# Generated at 2022-06-20 12:59:35.480407
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_basedir_options(parser)
    args = ['--playbook-dir', './', '--help']
    opts = parser.parse_args(args)
    assert opts.basedir == './'
    assert type(opts.basedir) == str
    assert repr(opts) == 'Namespace(basedir=\'./\', playbook_dir=\'./\')'


# Generated at 2022-06-20 12:59:40.302669
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(["-C","--syntax-check","-D"])
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True



# Generated at 2022-06-20 12:59:43.605724
# Unit test for function version
def test_version():
    assert version() == version('test')
    # This test passes with standard ansible installation, but it will fail in
    # developpement environment.
    # assert 'last updated' in version('test')



# Generated at 2022-06-20 12:59:46.735994
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    add_check_options(parser)
    assert parser.parse_args(['-C', '--diff'])



# Generated at 2022-06-20 13:00:17.871588
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(description="argparse unittest")
    runas_group = parser.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")
    add_runas_prompt_options(parser, runas_group)
    args = parser.parse_args([])
    assert args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS
    assert args.become_password_file == C.BECOME_PASSWORD_FILE
    args = parser.parse_args(['-K'])
    assert args.become_ask_pass == True
    assert args.become_password_file == C.BECOME_PASSWORD_FILE

# Generated at 2022-06-20 13:00:24.593185
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog="test", formatter_class=SortingHelpFormatter, epilog=None,
                                     add_help=True,
                                     conflict_handler='resolve')
    add_inventory_options(parser)
    options, args = parser.parse_known_args()

    assert not hasattr(options, 'inventory')
    assert not options.listhosts
    assert not hasattr(options, 'subset')

#
# Functions to add pre-canned options to an OptionGroups
#


# Generated at 2022-06-20 13:00:30.335857
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    o = UnrecognizedArgument(('--foo',), dest='bar', const=True, default=False, required=True, help='', metavar='', nargs=1)
    assert o.option_strings == ('--foo',)
    assert o.dest == 'bar'
    assert o.const == True
    assert o.default == False
    assert o.required == True
    assert o.help == ''
    assert o.metavar == ''


#
# The Base class for our CLI tools
#

# Generated at 2022-06-20 13:00:34.671601
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    parsed = parser.parse_args(["--task-timeout", "60"])
    assert parsed.task_timeout == 60



# Generated at 2022-06-20 13:00:36.941858
# Unit test for function version
def test_version():
    assert " [core" in version("ansible-test")
# Make sure changing the name of the executable doesn't break version()

# Generated at 2022-06-20 13:00:46.214168
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from argparse import Namespace
    from ansible.module_utils.common import json
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    input_list = parser.parse_args('-e key=value -e @file --extra-vars \'{"key":"value"}\' --extra-vars @file --extra-vars key=value'.split())
    assert input_list.extra_vars[0] == "key=value"
    assert input_list.extra_vars[1] == "@file"
    assert isinstance(json.loads(input_list.extra_vars[2]), dict)
    assert input_list.extra_vars[3] == "@file"
    assert input_list.extra_vars[4] == "key=value"



# Generated at 2022-06-20 13:00:51.695937
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='test_add_vault_options')
    add_vault_options(parser)
    results = parser.parse_args('--vault-id test-vault-id vault-id-1 --vault-password-file vault-password-file-1'.split())
    assert results.vault_ids == ['test-vault-id', 'vault-id-1']
    assert results.vault_password_files == ['vault-password-file-1']


# Generated at 2022-06-20 13:00:55.298292
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(args=[])
    assert options.inventory is None
    assert not options.listhosts
    assert not options.subset
    options = parser.parse_args(args=["-i", "foo", "--inventory", "bar"])
    assert options.inventory == ["foo", "bar"]
    options = parser.parse_args(args=["--limit", "foo"])
    assert options.subset == "foo"



# Generated at 2022-06-20 13:01:02.886901
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['--extra-vars', '@test'])
    assert args.extra_vars[0] == '@test'
    args = parser.parse_args(['--extra-vars', 'key=value'])
    assert args.extra_vars[0] == 'key=value'
    args = parser.parse_args(['--extra-vars', '{\"key\":\"value\"}'])
    print(args.extra_vars[0])
    assert json.loads(args.extra_vars[0]) == {"key":"value"}


# Generated at 2022-06-20 13:01:14.187058
# Unit test for function version
def test_version():
    expected = """core 2.0.0
  config file = /etc/ansible/ansible.cfg
  configured module search path = Default w/o overrides
  ansible python module location = /usr/local/lib/python2.7/dist-packages/ansible
  ansible collection location = /usr/local/lib/python2.7/dist-packages/ansible_collections
  executable location = /usr/local/lib/python2.7/dist-packages/ansible/bin/ansible-2.0
  python version = 2.7.5 (default, Mar  9 2014, 22:15:05)
[GCC 4.8.2 20140120 (Red Hat 4.8.2-16)]
  jinja version = 2.9.6
  libyaml = True""".strip()