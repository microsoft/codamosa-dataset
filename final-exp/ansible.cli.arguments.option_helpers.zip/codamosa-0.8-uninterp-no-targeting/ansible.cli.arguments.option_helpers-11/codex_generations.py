

# Generated at 2022-06-20 12:52:05.602341
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options, args = parser.parse_known_args(['-t', 'this', '--skip-tags', 'that'])
    assert isinstance(options.tags, ListAction)
    assert isinstance(options.skip_tags, ListAction)
    assert options.tags == ['this']
    assert options.skip_tags == ['that']
    options, args = parser.parse_known_args(['-t', 'this', '-t', 'that'])
    assert options.tags == ['this', 'that']
    options, args = parser.parse_known_args(['-t', 'this', '--tags', 'that'])
    assert options.tags == ['this', 'that']
    options, args = parser.parse_known_args

# Generated at 2022-06-20 12:52:11.833307
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    options = parser.parse_args()
    assert options.extra_vars == []


# Generated at 2022-06-20 12:52:22.451481
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    namespace = parser.parse_args(['-e', '@test.yml', '-e', '@test.json', '-e', 'key1=value1', 'yaml={"key":true}', 'json={"key":true}'])
    assert len(namespace.extra_vars) == 6
    assert namespace.extra_vars[0] == '@test.yml'
    assert namespace.extra_vars[1] == '@test.json'
    assert namespace.extra_vars[2] == 'key1=value1'

# Generated at 2022-06-20 12:52:26.268742
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    parser.parse_args()



# Generated at 2022-06-20 12:52:28.538950
# Unit test for function add_meta_options
def test_add_meta_options():
    """
    Unittest for add_meta_options
    """
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options, args = parser.parse_known_args(["--force-handlers",
                                             "--flush-cache"])
    assert(options.force_handlers is True)
    assert(options.flush_cache is True)



# Generated at 2022-06-20 12:52:39.923327
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # Simple case of fomatting three arguments
    prog_text = "prog"
    description_text = "description"
    formatter = SortingHelpFormatter(prog=prog_text)
    parser = argparse.ArgumentParser(description=description_text,
                                     formatter_class=formatter)
    parser.add_argument('a1')
    parser.add_argument('a3')
    parser.add_argument('a2')
    output = parser.format_help()
    expected = "%s: error: unrecognized arguments: a1 a3 a2\n" % (prog_text,)
    expected += "\n%s: error: too few arguments\n" % (prog_text,)

# Generated at 2022-06-20 12:52:51.965120
# Unit test for function add_connect_options
def test_add_connect_options():
    # Create a sub_parser and add connect_options
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(metavar='<subcommand>')
    for i, (name, data) in enumerate(C.CLI_TOOLS.items()):
        command_parser = subparsers.add_parser(name, add_help=False)
        add_connect_options(command_parser)

    argv = ["ansible-console", "-c", "docker", "-u", "root", "-k", "--ask-pass"]
    args = parser.parse_args(argv[1:])
    assert args.connection == "docker"
    assert args.remote_user == "root"
    assert args.ask_pass == True


# Generated at 2022-06-20 12:52:54.584460
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check is True


# Generated at 2022-06-20 12:53:07.492638
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    We test that the constructor of class ``PrependListAction`` raises expected exceptions.
    """
    arg_strings = ['--foo']

    # Test nargs and const
    nargs_choices = [argparse.OPTIONAL, argparse.ZERO_OR_MORE, argparse.ONE_OR_MORE]
    const_choices = [None, "some_const"]
    for nargs in nargs_choices:
        for const in const_choices:
            if nargs == 0:
                with pytest.raises(ValueError):
                    PrependListAction(option_strings=arg_strings, dest="foo", nargs=nargs, const=const)
            else:
                assert PrependListAction(option_strings=arg_strings, dest="foo", nargs=nargs, const=const)



# Generated at 2022-06-20 12:53:18.045277
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/')('/foo') == '/foo'
    assert maybe_unfrack_path('/')('~/foo') == '~/foo'
    assert maybe_unfrack_path('~')('~/.foo') == '~/.foo'
    assert maybe_unfrack_path('~')('~/.foo/../bar') == '~/bar'
    assert maybe_unfrack_path('~')('$HOME/foo') == '$HOME/foo'
    assert maybe_unfrack_path('~')('$HOME/./foo') == '~/foo'
    assert maybe_unfrack_path('~')('@BASE_DIR@/.foo/../bar') == '~/bar'

# Generated at 2022-06-20 12:53:44.886300
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    runas_group = parser.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")
    runas_group.add_argument("-b", "--become", default=C.DEFAULT_BECOME, action="store_true", dest='become',
                             help="run operations with become (does not imply password prompting)")
    runas_group.add_argument('--become-method', dest='become_method', default=C.DEFAULT_BECOME_METHOD,
                             help='privilege escalation method to use (default=%s)' % C.DEFAULT_BECOME_METHOD +
                                  ', use `ansible-doc -t become -l` to list valid choices.')
    runas_group.add

# Generated at 2022-06-20 12:53:56.015822
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # sorting is done by alphabetical order of option_strings
    # following test is to ensure the order of option_strings of the actions
    # before calling add_arguments are important
    actions = [
            argparse.Action(option_strings=['-b', '-c'], dest='action'),
            argparse.Action(option_strings=['-a'], dest='action'),
    ]
    output = SortingHelpFormatter().format_help()
    # two options are added to output
    assert 2 == output.count('-a') + output.count('-b')
    # first option is '-a'
    # see the order of actions in the argument passed to the test
    assert output.find('-a') < output.find('-b')



# Generated at 2022-06-20 12:53:58.460061
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser=argparse.ArgumentParser()
    add_tasknoplay_options(parser)



# Generated at 2022-06-20 12:54:02.165648
# Unit test for function add_check_options
def test_add_check_options():
    p = argparse.ArgumentParser()
    add_check_options(p)
    args = p.parse_args()
    assert args.check == False
    assert args.syntax == False
    assert args.diff == 'always'


# Generated at 2022-06-20 12:54:09.493866
# Unit test for function unfrack_path
def test_unfrack_path():
    import tempfile

    # Create tempfile to test against
    (filehandle, path) = tempfile.mkstemp()
    os.close(filehandle)

    # Test without pathsep
    assert unfrack_path()(path) == path
    assert unfrack_path()('-') == '-'

    # Test with pathsep
    assert unfrack_path(pathsep=True)(os.pathsep.join([path, path])) == [path, path]

    # Clean up
    os.remove(path)



# Generated at 2022-06-20 12:54:10.413905
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    print(AnsibleVersion)


# Generated at 2022-06-20 12:54:14.141565
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', nargs=0, action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version is None


# Generated at 2022-06-20 12:54:23.488994
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options, _ = parser.parse_known_args()
    assert options.become == C.DEFAULT_BECOME
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user == C.DEFAULT_BECOME_USER
    assert options.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS
    assert options.become_ask_sudo_pass == C.DEFAULT_BECOME_ASK_SUDO_PASS
    assert options.become_ask_su_pass == C.DEFAULT_BECOME_ASK_SU_PASS



# Generated at 2022-06-20 12:54:27.657035
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', type=UnrecognizedArgument, help='Print ansible version')
    args = parser.parse_args(['--version'])
    assert args.version is True



# Generated at 2022-06-20 12:54:31.526687
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Given
    beacon = '<'
    path = '/abc/def'
    path_beacon = '<' + path

    # When
    result = maybe_unfrack_path(beacon)(path)

    # Then
    assert result == path_beacon


# Generated at 2022-06-20 12:54:39.298018
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i'])



# Generated at 2022-06-20 12:54:48.121679
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    This unit test is testing the function above directly via constructor.
    """
    # nargs=0
    action = PrependListAction(option_strings='-o', dest='output', nargs=0)
    assert action.option_strings == ['-o']
    assert action.dest == 'output'
    assert action.nargs == 0
    assert action.const is None
    assert action.default is None
    assert action.type is None
    assert action.choices is None
    assert action.required is False
    assert action.help is None
    assert action.metavar is None

    # nargs=argparse.OPTIONAL
    action = PrependListAction(option_strings='-o', dest='output', nargs=argparse.OPTIONAL, const=True)

# Generated at 2022-06-20 12:55:00.612671
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class T(argparse.ArgumentParser):
        def error(self):
            pass

    parser = T()

    parser.add_argument('--foo', '-f', action=PrependListAction)
    parser.parse_args(['-f', '1'])

    parser.add_argument('--foo', '-f', action=PrependListAction, required=True)
    parser.parse_args(['-f', '1'])

    parser.add_argument('--foo', '-f', action=PrependListAction, required=True)
    parser.parse_args(['-f', '1', '-f', '2'])

    parser.add_argument('--foo', '-f', action=PrependListAction, nargs=2)

# Generated at 2022-06-20 12:55:04.200092
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.connection == C.DEFAULT_TRANSPORT


# Generated at 2022-06-20 12:55:10.361847
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    args = parser.parse_args(['--become-pass-file', '~/.ansible_become_pass'])

    assert args.become_password_file == '~/.ansible_become_pass'
    assert args.become_ask_pass is False

    args = parser.parse_args(['--ask-become-pass'])

    assert args.become_password_file is None
    assert args.become_ask_pass is True



# Generated at 2022-06-20 12:55:21.410834
# Unit test for function unfrack_path
def test_unfrack_path():
    backwards = sys.platform == 'win32'
    orig = os.environ.get('ANSIBLE_CONFIG')
    if os.environ.get('ANSIBLE_CONFIG') is None or not os.path.exists(os.environ.get('ANSIBLE_CONFIG')):
        os.environ['ANSIBLE_CONFIG'] = os.path.join(os.getcwd(), 'test/ansible.cfg')
    test_path = os.path.join('test','ansible.cfg')

    assert unfrack_path(test_path) == unfrack_path(test_path)
    assert unfrack_path(test_path) != unfrack_path(test_path+".bak")
    assert unfrack_path(test_path) == unfrack_path("test/ansible.cfg")
    assert unf

# Generated at 2022-06-20 12:55:24.786338
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser(prog='ansible-config', usage='ansible-config view [options]')
    assert parser == parser.parse_args('-v'.split())
    assert parser != parser.parse_args('-vvv'.split())



# Generated at 2022-06-20 12:55:25.315149
# Unit test for function version
def test_version():
    assert version() != ''

# Generated at 2022-06-20 12:55:30.066107
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_verbosity_options(parser)
    assert '-v' in parser._option_string_actions
    assert '--verbose' in parser._option_string_actions


# Generated at 2022-06-20 12:55:33.297774
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-20 12:55:49.608674
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(['--module-path', 'default_path1:default_path2'])
    assert args.module_path == ['default_path2', 'default_path1']


# Generated at 2022-06-20 12:55:52.953560
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    assert parser.get_default('module_path') == C.config.get_configuration_definition('DEFAULT_MODULE_PATH').get('default', '')


# Generated at 2022-06-20 12:55:54.480916
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)



# Generated at 2022-06-20 12:55:59.174732
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    results = parser.parse_args(['--playbook-dir', './test-module'])
    assert results.basedir == os.path.abspath('./test-module')


# Generated at 2022-06-20 12:56:03.906424
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    # default
    args = parser.parse_args([])
    assert args.module_path is None
    # empty string should use default
    args = parser.parse_args(['-M', ''])
    assert args.module_path is None



# Generated at 2022-06-20 12:56:14.529999
# Unit test for function add_connect_options
def test_add_connect_options():
    test_parser = create_base_parser('ansible', '', '', '')
    add_connect_options(test_parser)
    test_parser._check_value(None, 'connection')
    test_parser._check_value(None, 'private_key_file')
    test_parser._check_value('ansible', 'remote_user')
    test_parser._check_value(C.DEFAULT_TIMEOUT, 'timeout')
    test_parser._check_value(C.DEFAULT_ASK_PASS, 'ask_pass')
    test_parser._check_value(None, 'ssh_common_args')
    test_parser._check_value(None, 'sftp_extra_args')
    test_parser._check_value(None, 'scp_extra_args')
    test_parser._check_value

# Generated at 2022-06-20 12:56:20.540303
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
   parser = argparse.ArgumentParser(prog='test')
   add_tasknoplay_options(parser)
   args = parser.parse_args(['--task-timeout', '1'])
   assert args.task_timeout == 1
   # Invalid option
   try:
       args = parser.parse_args(['--task-timeout', '0'])
       assert False
   except SystemExit as e:
       assert e.code == 2



# Generated at 2022-06-20 12:56:24.236846
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/') == '@/tmp'
    assert maybe_unfrack_path('@')('/tmp') == '/tmp'



# Generated at 2022-06-20 12:56:34.300570
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--version', action='version', version='%(prog)s 2.0')
    parser.add_argument('-b', action='store', metavar='BAR')
    parser.add_argument('-a', action='store', metavar='FOO')
    parser.add_argument('-def', action='store', metavar='BAZ')
    test_list = ['--help', '-a', 'FOO', '-b', 'BAR', '-def', 'BAZ']
    assert parser.format_help().split('\n')[4:8] == test_list



# Generated at 2022-06-20 12:56:35.214233
# Unit test for function add_connect_options
def test_add_connect_options():
    add_connect_options()



# Generated at 2022-06-20 12:56:44.308069
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.parse_args('-M /custom/module'.split())
    assert C.DEFAULT_MODULE_PATH == ['/custom/module']

# Generated at 2022-06-20 12:56:47.412912
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options = parser.parse_args(['--playbook-dir', '../testdata'])
    assert(options.basedir == '../testdata')


# Generated at 2022-06-20 12:56:50.222566
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    parser = add_tasknoplay_options(parser)
    argv = ['--task-timeout', '30']
    parsed_args = parser.parse_args(argv)
    assert 30 == parsed_args.task_timeout



# Generated at 2022-06-20 12:56:55.225420
# Unit test for function add_vault_options
def test_add_vault_options():
    def safe_dict(d):
        return dict((k, v) for k, v in iteritems(d) if k in ('vault_ids', 'vault_password_files'))

    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'dev', '--vault-password-file', '@vault.txt', '--vault-password-file', 'v2.txt'])
    assert safe_dict(vars(options)) == dict(vault_ids=['dev'], vault_password_files=['@vault.txt', 'v2.txt'])


# Generated at 2022-06-20 12:57:04.659789
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
  parser = argparse.ArgumentParser(
      prog="test",
      formatter_class=SortingHelpFormatter,
      description="Test for add_verbosity_options function",
      conflict_handler='resolve',
  )

  add_verbosity_options(parser)
  args = parser.parse_args('')
  assert args.verbosity == "0"

  args = parser.parse_args('-v'.split())
  assert args.verbosity == "1"

  args = parser.parse_args('-v -v'.split())
  assert args.verbosity == "2"

  args = parser.parse_args('-vvvv'.split())
  assert args.verbosity == "3"

# Generated at 2022-06-20 12:57:09.169765
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--column', dest='column', action=PrependListAction, nargs='+', type=int)
    args = parser.parse_args(['--column', '1', '2'])
    assert args.column == [1, 2]

# Generated at 2022-06-20 12:57:10.510851
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    assert parser

# unittest.main(module=__name__, verbosity=2)


# Generated at 2022-06-20 12:57:14.166287
# Unit test for function ensure_value
def test_ensure_value():
    class Mock(object):
        pass
    mock_obj = Mock()
    assert ensure_value(mock_obj, 'foo', 'bar') == 'bar'
    assert mock_obj.foo == 'bar'
    assert ensure_value(mock_obj, 'foo', 'baz') == 'bar'
    assert mock_obj.foo == 'bar'


# Generated at 2022-06-20 12:57:20.349340
# Unit test for function add_runas_options
def test_add_runas_options():

    parser = create_base_parser(usage='', epilog='')
    add_runas_options(parser)
    results = parser.parse_args('-b -k'.split(' '))
    assert(results.become == True)
    assert(results.ask_pass == True)

    results = parser.parse_args('--become-method=su --become-user=root'.split(' '))
    assert(results.become_method == 'su')
    assert(results.become_user == 'root')



# Generated at 2022-06-20 12:57:21.826555
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    assert_equal(parser._get_kwargs()[1]['dest'], 'forks')


# Generated at 2022-06-20 12:57:30.913882
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    (options, args) = parser.parse_known_args()
    assert options.one_line == False
    assert options.tree == None



# Generated at 2022-06-20 12:57:36.573707
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Create an instance of a parser
    parser = argparse.ArgumentParser()
    # Create an instance of 'AnsibleVersion'
    action = AnsibleVersion(option_strings=['--version'])
    # Call method __call__ of 'AnsibleVersion' instance
    action.__call__(parser, None, None, '--version')
    # Check if the parser exits after method __call__ of 'AnsibleVersion' instance is called
    assert parser.exit.called



# Generated at 2022-06-20 12:57:42.591984
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='test')
    add_vault_options(parser)
    parser.parse_args([])
    parser.parse_args(['--vault-ids', 'test'])
    parser.parse_args(['--vault-ids', 'test', '--vault-ids', 'test2'])
    parser.parse_args(['--ask-vault-pass'])

# Generated at 2022-06-20 12:57:50.228915
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('foo')('foo/bar') == 'foo/bar'
    assert maybe_unfrack_path('foo')('foo/baz') == 'foo/baz'
    assert maybe_unfrack_path('/')('/bar') == '/bar'
    assert maybe_unfrack_path('/')('/baz') == '/baz'
    assert maybe_unfrack_path('foo')('/baz') == 'foo/baz'



# Generated at 2022-06-20 12:57:59.667946
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class TestActions(argparse.Action):
        def __init__(self, option_strings=['--arg1'], dest='arguments', nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None):
            super(TestActions, self).__init__(option_strings=option_strings, dest=dest, nargs=nargs, const=const, default=default, type=type, choices=choices, required=required, help=help)
    class TestParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super(TestParser, self).__init__(*args, **kwargs)
            self.add_argument('--arg2')
            self.add_argument('--arg3')
            self.add_

# Generated at 2022-06-20 12:58:02.473067
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/foo/bar") == unfrackpath("/foo/bar")
    assert unfrack_path(pathsep=True)("/foo:/bar:/baz") == [unfrackpath("/foo"), unfrackpath("/bar"), unfrackpath("/baz")]



# Generated at 2022-06-20 12:58:14.540339
# Unit test for function add_meta_options
def test_add_meta_options():
    def check_add_meta_options(expected, actual):
        assert expected.dest == actual.dest
        assert expected.default == actual.default
        assert expected.action == actual.action
        assert expected.help == actual.help
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    for action in parser._actions:
        if action.dest == 'force_handlers':
            check_add_meta_options(action, argparse.ArgumentParser().add_argument(
                '--force-handlers', default=C.DEFAULT_FORCE_HANDLERS, dest='force_handlers', action='store_true',
                help="run handlers even if a task fails"))

# Generated at 2022-06-20 12:58:19.146955
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='foo')
    add_connect_options(parser)
    args, _ = parser.parse_known_args()
    assert args.timeout == C.DEFAULT_TIMEOUT
    assert args.remote_user == C.DEFAULT_REMOTE_USER

# Generated at 2022-06-20 12:58:20.754103
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    with pytest.raises(SystemExit):
        parser.parse_args(["--become-password-prompt"])



# Generated at 2022-06-20 12:58:25.240815
# Unit test for function ensure_value
def test_ensure_value():
    class fake_namespace():
        pass
    fake_var = fake_namespace()
    fake_var = ensure_value(fake_var, 'fake_attr', 'test')
    assert fake_var.fake_attr == 'test'
    fake_var.fake_attr = 'changed'
    fake_var = ensure_value(fake_var, 'fake_attr', 'test')
    assert fake_var.fake_attr == 'changed'
# End unit test



# Generated at 2022-06-20 12:58:35.503527
# Unit test for function version
def test_version():
    assert 'ansible-playbook' in version('ansible-playbook')
    assert __version__ in version('ansible-playbook')
    assert 'configured module search path' in version('ansible-playbook')
    assert 'ansible python module location' in version('ansible-playbook')
    assert 'executable location' in version('ansible-playbook')
    assert 'jinja version' in version('ansible-playbook')
    assert 'python version' in version('ansible-playbook')
    assert 'libyaml' in version('ansible-playbook')

# Generated at 2022-06-20 12:58:39.085594
# Unit test for function add_basedir_options
def test_add_basedir_options():

    class MockParser(object):
        def add_argument(self, *args, **kwargs):
            pass

    parser = MockParser()
    add_basedir_options(parser)
    assert isinstance(parser, argparse.ArgumentParser)



# Generated at 2022-06-20 12:58:48.870347
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    # Test for default values for --vault-id and --vault-password-file
    args = parser.parse_args(['--vault-id'])
    assert args.vault_ids == []
    assert args.vault_password_files == []

    args = parser.parse_args(['--vault-password-file'])
    assert args.vault_ids == []
    assert args.vault_password_files == []

    # Test for Multiple --vault-password-file and --vault-id
    args = parser.parse_args(['--vault-id', '@a.txt', '@b.yaml', '--vault-password-file', 'c', 'd.txt'])
    assert args

# Generated at 2022-06-20 12:58:59.105269
# Unit test for function unfrack_path
def test_unfrack_path():
    """Make sure that we handle all cases in unfrack_path"""
    # Setup

# Generated at 2022-06-20 12:59:03.627927
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("foo") == "foo"
    assert unfrack_path()("foo/bar") == "foo/bar"
    assert unfrack_path("foo/bar/")("") == "foo/bar/"

# Generated at 2022-06-20 12:59:13.406460
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    arguments = parser.parse_args(["-i", "host_list"])
    assert arguments.inventory == ["host_list"]
    assert arguments.listhosts == False
    assert arguments.subset == C.DEFAULT_SUBSET
    arguments = parser.parse_args(["--limit=limit_pattern"])
    assert arguments.inventory == None
    assert arguments.listhosts == False
    assert arguments.subset == "limit_pattern"
    arguments = parser.parse_args(["--list-hosts"])
    assert arguments.inventory == None
    assert arguments.listhosts == True
    assert arguments.subset == C.DEFAULT_SUBSET



# Generated at 2022-06-20 12:59:18.292536
# Unit test for function add_runtask_options
def test_add_runtask_options():
    '''
        ansible-playbook -i unit/test_ansible.py --list-tasks unit/test_ansible.py
        This will test the add_runtask_options function
    '''
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    parser = argparse.ArgumentParser(description='Test for function add_runtask_options')
    add_runtask_options(parser)
    args = parser.parse_args(['-e','host_key_checking=False'])
    pprint(vars(args))



# Generated at 2022-06-20 12:59:25.757307
# Unit test for function add_output_options
def test_add_output_options():
    parser1 = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_output_options(parser1)
    parser2 = argparse.ArgumentParser(prog='test2', formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    try:
        args1 = parser1.parse_args(['-o','-t', 'a'])
        args2 = parser2.parse_args(['-o','-t', 'a'])
    except Exception as e:
        assert(False)
    assert(args1.one_line and args2.one_line)
    assert(args1.tree == 'a' and args2.tree == 'a')



# Generated at 2022-06-20 12:59:37.135664
# Unit test for function version
def test_version():
    import re
    import subprocess
    import sys

    # check function version returns value with git info
    gitinfo = _gitinfo()

# Generated at 2022-06-20 12:59:41.073827
# Unit test for function add_fork_options
def test_add_fork_options():
    args = ["-f", "5"]
    parser = create_base_parser("ansible")
    add_fork_options(parser)
    options = parser.parse_args(args)
    assert options.forks == 5



# Generated at 2022-06-20 13:00:02.456738
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', dest='foo', action=PrependListAction)
    assert parser.parse_args([]).foo == []
    assert parser.parse_args(['--foo', 'arg']).foo == ['arg']
    assert parser.parse_args(['--foo', 'arg1', 'arg2']).foo == ['arg1', 'arg2']
    assert parser.parse_args(['--foo', '--foo', 'arg']).foo == ['arg', 'arg']
    assert parser.parse_args(['--foo', 'arg', '--foo', 'arg']).foo == ['arg', 'arg']
    assert parser.parse_args(['--foo', 'arg', 'arg']).foo == ['arg', 'arg']

# Generated at 2022-06-20 13:00:09.261037
# Unit test for function add_basedir_options
def test_add_basedir_options():
    # Test playbook-dir input with a directory
    x = "/tmp/ansible-test"
    os.makedirs(os.path.join(x,"group_vars"))
    parser = create_base_parser("test_add_basedir_options()")
    add_basedir_options(parser)
    y = parser.parse_args(["--playbook-dir",x])
    assert y.basedir == unfrackpath(x)
    # Test playbook-dir input without a directory
    z = "/tmp/ansible-test2"
    parser = create_base_parser("test_add_basedir_options()")
    add_basedir_options(parser)
    y = parser.parse_args(["--playbook-dir",z])
    assert getattr(y,"basedir") is None
    # Test no

# Generated at 2022-06-20 13:00:12.956550
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(
        prog='test_add_tasknoplay_options',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_tasknoplay_options(parser)
    c = getattr(parser, "defaults", {})
    assert c['task_timeout'] == C.TASK_TIMEOUT



# Generated at 2022-06-20 13:00:20.467576
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args(args=['-t', 'debug', '--skip-tags', 'exec', '--skip-tags', 'exec'])
    assert options.tags == ['debug']
    assert options.skip_tags == ['exec', 'exec']



# Generated at 2022-06-20 13:00:27.539817
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """
    Test AnsibleVersion().__call__()
    """
    class TestAnsibleVersion(AnsibleVersion):
        def __init__(self, opt_str=None, **kwargs):
            super(TestAnsibleVersion, self).__init__(opt_str, **kwargs)

        def __call__(self, parser, namespace, values, option_string=None):
            super(TestAnsibleVersion, self).__call__(parser, namespace, values, option_string)

    # Test with no parameters
    test_ansible_version = TestAnsibleVersion()
    if sys.version_info[0] > 2:
        assert test_ansible_version.__call__.__code__.co_argcount == 4
        parser_expected = None
        namespace_expected = None
        values_expected

# Generated at 2022-06-20 13:00:37.610328
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.add_argument('--list-module', dest='list_module', action='store_true', help="list available modules")

    args = parser.parse_args(['-M', '/tmp/test'])
    assert args.module_path == ['/tmp/test']
    assert args.list_module == False

    args = parser.parse_args(['--module-path', '/tmp/test'])
    assert args.module_path == ['/tmp/test']
    assert args.list_module == False

    args = parser.parse_args(['--module-path', '/tmp/test', '-M', 'foo'])
    assert args.module_path == ['/tmp/test', 'foo']

# Generated at 2022-06-20 13:00:39.837231
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    from optparse import OptionParser
    parser = OptionParser()
    add_tasknoplay_options(parser)
    return parser

# Generated at 2022-06-20 13:00:41.964694
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    options = parser.parse_args(['-i', 'inv_file', '--list-hosts', '-l', 'inv_lim'])
    assert options.inventory == ['inv_file']
    assert options.listhosts
    assert options.subset == 'inv_lim'


# Generated at 2022-06-20 13:00:50.135689
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from ansible.cli.argparser import UnrecognizedArgument
    from ansible.module_utils._text import to_native
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--opt-1')
    parser.add_argument('--opt-2')
    parser.add_argument('opt-3')
    parser.add_argument('pos1')
    parser.add_argument('pos2')
    parser.add_argument('pos3')
    parser.add_argument = lambda *args, **kwargs: None
    parser.error = lambda msg: sys.exit(msg)
    UnrecognizedArgument(['--opt-3'], None)(parser, None, None, '--opt-3')
    sys.exit(1)



# Generated at 2022-06-20 13:00:59.529507
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument("-r", action=PrependListAction, nargs='+')
        parser.add_argument("-t", action=PrependListAction, nargs='+')
        parser.add_argument("-v", action=PrependListAction, nargs='+')
        parser.print_help()
        assert parser.parse_args(["-v", "00", "-r", "0", "-t", "1", "-v", "11", "-r", "3", "-t", "4"])
    except Exception as e:
        print("Exception: {}".format(e))
        assert False
    else:
        assert True


#
# General
#

# Generated at 2022-06-20 13:01:21.232122
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    parse_results = parser.parse_args(
        '-k -u ansible --private-key /path_to/file.pem --ssh-common-args "ProxyCommand ssh -W %h:%p jumphost" '
        '--sftp-extra-args "-f -l" --scp-extra-args "-l" --ssh-extra-args "-R" --connection-password-file /path_to/passfile'.split())
    assert parse_results.remote_user == 'ansible'
    assert parse_results.private_key_file == '/path_to/file.pem'
    assert parse_results.ssh_common_args == 'ProxyCommand ssh -W %h:%p jumphost'
    assert parse_results

# Generated at 2022-06-20 13:01:23.328205
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible-inventory')
    add_check_options(parser)
    args = parser.parse_args(['--check'])
    assert args.check



# Generated at 2022-06-20 13:01:25.813636
# Unit test for function add_vault_options
def test_add_vault_options():
    from optparse import OptionParser
    parser=OptionParser()
    add_vault_options(parser)
    #get all options
    options, args=parser.parse_args()
    #test all options
    assert options.vault_ids == []
    assert options.ask_vault_pass == False
    assert options.vault_password_files == []

test_add_vault_options()


# Generated at 2022-06-20 13:01:30.136203
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~/foo') == '~/foo'
    assert maybe_unfrack_path('/')('/foo') == '/foo'
    assert maybe_unfrack_path('~')('~foo') == '~foo'
    assert maybe_unfrack_path('~')('foo') == 'foo'



# Generated at 2022-06-20 13:01:34.589579
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser(description=__doc__)
    add_verbosity_options(parser)
    args = ['--verbose', '-vv', '-vvvv']
    options = parser.parse_args(args)
    assert options.verbosity == 4


