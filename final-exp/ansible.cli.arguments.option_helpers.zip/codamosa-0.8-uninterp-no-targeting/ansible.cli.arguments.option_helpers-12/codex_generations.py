

# Generated at 2022-06-20 12:52:26.477688
# Unit test for function add_basedir_options
def test_add_basedir_options():
    p = argparse.ArgumentParser()
    add_basedir_options(p)
    args = p.parse_args(['--playbook-dir','C:/Users/IBM_ADMIN/projects/ansible/test'])
    assert args.basedir == 'C:/Users/IBM_ADMIN/projects/ansible/test'


# Generated at 2022-06-20 12:52:37.672448
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog="program", usage="", desc=None, epilog=None)
    assert parser.prog == "program"
    assert parser.formatter_class == SortingHelpFormatter
    assert parser.epilog == None
    assert parser.description == None
    assert parser._conflict_handler == 'resolve'
    assert parser._actions[0].option_strings == ['--version']
    assert parser._actions[0].container == parser
    assert parser._actions[0].dest == 'version'
    assert parser._actions[0].default == None
    assert parser._actions[0].type == None
    assert parser._actions[0].choices == None
    assert parser._actions[0].required == False

# Generated at 2022-06-20 12:52:43.440251
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    results = parser.parse_args(['-B', '10', '-P', '1'])
    assert results.poll_interval == 1
    assert results.seconds == 10



# Generated at 2022-06-20 12:52:47.710846
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args()
    assert args.become_ask_pass == False
    assert args.become_password_file == False


# Generated at 2022-06-20 12:52:53.460198
# Unit test for function create_base_parser
def test_create_base_parser():
    ''' test create_base_parser '''
    from ansible.cli import CLI
    cli_obj = CLI()
    parser = create_base_parser(cli_obj.prog, usage="Usage: ", desc="Desc",
                                epilog="Epilog")
    options, args = parser.parse_known_args(['--version'])
    assert options.version == 0



# Generated at 2022-06-20 12:53:02.220637
# Unit test for function version
def test_version():
    ret = version()
    assert ret
    assert __version__ in ret
    assert j2_version in ret
    assert C.CONFIG_FILE in ret
    # Skip these assertions since we have no idea where the test suite is running.
    # if C.DEFAULT_MODULE_PATH is None:
    #     assert 'Default' in ret
    # else:
    #     assert C.DEFAULT_MODULE_PATH in ret
    # assert sys.argv[0] in ret
    # assert ''.join(sys.version.splitlines()) in ret
# End unit test for function version

# Generated at 2022-06-20 12:53:04.391680
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    assert True

# Generated at 2022-06-20 12:53:10.916094
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    from unittest import TestCase

    # Test case for passing option_string as argument

    # Args:
    #    argv: Command line arguments on which parser is to be run
    #    option_string: option string to be passed as argument in method __call__
    #    expected_message: expected error message
    def run_test(argv, option_string, expected_message):
        parser = argparse.ArgumentParser()
        const = "test_const"
        help_msg = "test_help_msg"
        parser.add_argument('-u', '--unknown', action=UnrecognizedArgument, const=const,
                            help=help_msg, nargs=0)

        # Resetting the sys.argv
        sys.argv = copy.deepcopy(argv)

        # Asserting the error

# Generated at 2022-06-20 12:53:20.826395
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    def test_int_positive_value(option_name, value, expected_value):
        args = { option_name : value }
        opt = add_tasknoplay_options(argparse.ArgumentParser())
        args = opt.parse_args(**args)
        assert args[option_name] == expected_value

    test_int_positive_value('task_timeout', None, C.TASK_TIMEOUT)
    test_int_positive_value('task_timeout', '', C.TASK_TIMEOUT)
    test_int_positive_value('task_timeout', '--task-timeout', C.TASK_TIMEOUT)
    test_int_positive_value('task_timeout', '-1', C.TASK_TIMEOUT)

# Generated at 2022-06-20 12:53:22.583118
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.parse_args(args=['--vault-pass-file', '/aaa'])



# Generated at 2022-06-20 12:53:51.486033
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--ask-vault-password'])
    assert options.ask_vault_pass


#
# Functions to load common options for ansible commands
#


# Generated at 2022-06-20 12:53:54.002479
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    # Construct a new object
    ansible_version = AnsibleVersion(None, None, None)

    # Just make sure we got a valid object
    assert(ansible_version)



# Generated at 2022-06-20 12:54:03.284674
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

# Generated at 2022-06-20 12:54:04.537284
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    from ansible.cli.argparser import AnsibleVersion
    assert AnsibleVersion



# Generated at 2022-06-20 12:54:15.043891
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    args = []
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    cmd_args = parser.parse_args(args)
    assert (cmd_args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS) and \
           (cmd_args.become_password_file == C.BECOME_PASSWORD_FILE)

    args = ['-K']
    cmd_args = parser.parse_args(args)
    assert (cmd_args.become_ask_pass == True) and \
           (cmd_args.become_password_file == None)

    args = ['--become-password-file', 'ansible.pw']
    cmd_args = parser.parse_args(args)

# Generated at 2022-06-20 12:54:20.345243
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-v', '--version', action=AnsibleVersion,
                        help="show program's version number and exit", default=argparse.SUPPRESS)
    parsed_args = parser.parse_args(["-v"])
    assert not hasattr(parsed_args, 'version')



# Generated at 2022-06-20 12:54:25.982466
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class AnsibleVersionTest():
        def __init__(self):
            self.prog = "AnsibleVersionTest"
        def exit(self):
            return True
    version_parser = AnsibleVersionTest()
    ansible = AnsibleVersion(version_parser)
    print (ansible.__call__(version_parser, False, False, False))



# Generated at 2022-06-20 12:54:34.969076
# Unit test for function add_runtask_options
def test_add_runtask_options():
    args = Mock()
    args.extra_vars = []
    args.extra_vars.append('key=value')
    args.extra_vars.append('@file.yml')
    parser = Mock()
    parser.add_argument = Mock()
    add_runtask_options(parser)

    assert parser.add_argument.call_count == 1
    assert parser.add_argument.call_args_list[0][0][0] == '-e'
    assert parser.add_argument.call_args_list[0][0][1] == '--extra-vars'
    assert parser.add_argument.call_args_list[0][1]['dest'] == "extra_vars"
    assert parser.add_argument.call_args_list[0][1]['action'] == "append"

# Generated at 2022-06-20 12:54:43.974459
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = SortingHelpFormatter()

    parser.add_argument('-z')
    parser.add_argument('-a')
    parser.add_argument('-10')
    parser.add_argument('--foo')
    try:
        parser.add_argument('bar')
    except TypeError:
        pass
    parser._add_action(argparse._HelpAction(option_strings=[], dest='', default=argparse.SUPPRESS, help=None))

    out = parser.format_help()

    assert '-10' in out
    assert '-z' in out
    assert '-a' in out
    assert '--foo' in out



# Generated at 2022-06-20 12:54:48.471684
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options, args = parser.parse_known_args(['--ask-vault-password','--vault-password-file','password.txt','--vault-password-file','password2.txt'])
    assert options.vault_password_files == ['password.txt', 'password2.txt']
    assert options.ask_vault_pass == True


# Generated at 2022-06-20 12:55:07.647119
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    # Test default result with no args from parser
    assert C.DEFAULT_BECOME_ASK_PASS == parser.parse_args([]).become_ask_pass
    assert C.BECOME_PASSWORD_FILE == parser.parse_args([]).become_password_file

    # Test that setting parser args overrides default
    assert True == parser.parse_args(['-K']).become_ask_pass
    assert False == parser.parse_args(['--become-password-file', '/tmp/foo']).become_ask_pass

    # Test that setting multiple args throws an exception

# Generated at 2022-06-20 12:55:11.114321
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--zebra')
    parser.add_argument('--apple')
    parser.add_argument('--lion')
    parser.parse_args([])


# Generated at 2022-06-20 12:55:13.875011
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = create_base_parser(prog="test_program")
    add_runtask_options(parser)
    result = parser.parse_args(['-e', '@for_test.yml'])
    assert (result.extra_vars == ['@for_test.yml'])

# test_add_runtask_options()


# Generated at 2022-06-20 12:55:20.852845
# Unit test for function add_runtask_options
def test_add_runtask_options():
    a1 = argparse.ArgumentParser(description="Test parser")
    add_runtask_options(a1)
    (options, args) = a1.parse_known_args(["-e", "key=value", "-e", "@/opt/ansible/jsonfile"])
    assert options.extra_vars
    assert "key=value" in options.extra_vars
    assert "/opt/ansible/jsonfile" in options.extra_vars



# Generated at 2022-06-20 12:55:30.773827
# Unit test for function add_async_options
def test_add_async_options():
    from unittest import TestCase
    class TestOptions(TestCase):
        def setUp(self):
            self.parser = argparse.ArgumentParser(prog='ansible-config')
            add_async_options(self.parser)

        def test_poll(self):
            # default poll interval is C.DEFAULT_POLL_INTERVAL
            args = self.parser.parse_args(['--poll'])
            self.assertEqual(args.poll_interval, C.DEFAULT_POLL_INTERVAL)

            # default poll interval is C.DEFAULT_POLL_INTERVAL when not setting poll interval explicitly
            args = self.parser.parse_args([])
            self.assertEqual(args.poll_interval, C.DEFAULT_POLL_INTERVAL)

            # poll interval can be set


# Generated at 2022-06-20 12:55:42.856937
# Unit test for function ensure_value
def test_ensure_value():
    from ansible.test.unit.test_runner import TestModule
    from ansible.test.unit.test_loader import TestDataLoader
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self):
            self.become_user = None
            self.become_ask_pass = None
            self.connection = None
            self.ask_pass = None
            self.private_key_file = None
            self.verbosity = None
            self.check = None
            self.diff = None
            self.listhosts = None
            self.subset = None
            self.module_path = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.vault_password_files = None

# Generated at 2022-06-20 12:55:53.222006
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_connect_options(parser)
    args = parser.parse_args(["--private-key", "/path/to/key", "-u", "john", "-k", "--connection-password-file", "/path/to/conn/file",
                              "-T", "1", "--ssh-common-args", "a b c", "--sftp-extra-args", "a b c", "--scp-extra-args", "a b c", "--ssh-extra-args", "a b c"])
    assert args.private_key_file == "/path/to/key"
    assert args.remote_user == "john"
    assert args.ask_pass

# Generated at 2022-06-20 12:55:58.420295
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    command = "ansible-playbook"
    version_list = [command, '--version']
    parser = argparse.ArgumentParser()
    action = AnsibleVersion(option_strings=version_list)
    action.__call__(parser=parser, namespace=None, values=None, option_string=None)



# Generated at 2022-06-20 12:56:02.501458
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='ansible')
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    name_space = parser.parse_args([])
    name_space = parser.parse_args(['--version'])



# Generated at 2022-06-20 12:56:03.981813
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(description='Ansible module option test')
    add_meta_options(parser)
    parser.parse_args()



# Generated at 2022-06-20 12:56:33.771974
# Unit test for function add_check_options
def test_add_check_options():
    # Set up args
    parser = argparse.ArgumentParser(prog="ansible-test")
    add_check_options(parser)
    # Test normal syntax check
    options = parser.parse_args("--syntax-check".split())
    assert options.syntax == True
    assert options.check == False
    assert options.diff == C.DIFF_ALWAYS
    # Test normal dry run check
    options = parser.parse_args("-C".split())
    assert options.syntax == False
    assert options.check == True
    assert options.diff == C.DIFF_ALWAYS
    # Test normal dry run check with differ
    options = parser.parse_args("-C -D".split())
    assert options.syntax == False
    assert options.check == True
    assert options.diff == True


# Generated at 2022-06-20 12:56:39.193161
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--unrecognized', action=UnrecognizedArgument,
        help="Ignored. This is only here to prevent typos from being silently ignored"
    )
    parser.parse_args(['--unrecognized'])



# Generated at 2022-06-20 12:56:41.001107
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    ansible_version = to_native(version("Test ansible version"))
    assert ansible_version


# Generated at 2022-06-20 12:56:48.409262
# Unit test for function version
def test_version():
    assert 'ansible-doc' in version(prog='ansible-doc')
    assert to_native(__version__) in version()
    assert 'config file = ' in version()
    assert 'configured module search path = ' in version()
    assert 'ansible python module location' in version()
    assert 'ansible collection location' in version()
    assert 'executable location = ' in version()
    assert 'python version = ' in version()
    assert 'jinja version = ' in version()
    assert 'libyaml' in version()
    assert 'ansible-config' in version(prog='ansible-config')



# Generated at 2022-06-20 12:56:54.186433
# Unit test for function add_inventory_options
def test_add_inventory_options():
    def temp():
        results = [
            "configured module search path = Default w/o overrides",
            "ansible python module location = /Users/clark/src/ansible",
            "executable location = /Users/clark/bin/ansible",
            "python version = 2.7.12 (default, Sep  1 2016, 22:14:00) \n[GCC 4.2.1 Compatible Apple LLVM 8.0.0 (clang-800.0.34)]",
            "config file = /Users/clark/src/ansible/ansible.cfg"
        ]
        parser = create_base_parser('ansible')
        add_inventory_options(parser)
        add_version_option(parser)
        add_pn_options(parser)
        v = version()

# Generated at 2022-06-20 12:56:56.901315
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    test_parser = argparse.ArgumentParser(conflict_handler='resolve')
    cmd_options = add_verbosity_options(test_parser)
    assert cmd_options == '-v'



# Generated at 2022-06-20 12:57:01.853996
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args(['-v'])
    assert options.verbosity == 1
    options = parser.parse_args(['-vvvv'])
    assert options.verbosity == 4

# Generated at 2022-06-20 12:57:11.782024
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f1')
    parser.add_argument('-f2')
    parser.add_argument('-f3')
    parser.add_argument('-f4')
    parser.add_argument('-f5')
    orig_data = parser.format_help()
    parser = argparse.ArgumentParser()
    parser.add_argument('-f5')
    parser.add_argument('-f4')
    parser.add_argument('-f3')
    parser.add_argument('-f2')
    parser.add_argument('-f1')
    parser.formatter_class = SortingHelpFormatter
    new_data = parser.format_help()

# Generated at 2022-06-20 12:57:19.473467
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3

    # Test positional argument
    args = ['--one', 'a', 'b', '--one', 'c', 'd']
    parser = argparse.ArgumentParser()
    parser.add_argument('--one', action=PrependListAction, help='Stuff')
    opt = parser.parse_args(args)
    display.vvv('opt: %s' % opt)
    assert opt.one == ['a', 'b', 'c', 'd']

    # Test optional argument
    args = ['--one', 'a', 'b', '--one', 'c', 'd']
    parser = argparse.ArgumentParser()

# Generated at 2022-06-20 12:57:28.590315
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('test', 'test')
    assert parser.get_default('action') == 'store_true'
    assert parser.get_default('version') == 'show program\'s version number, config file location, configured module search path,' \
                                            ' module location, executable location and exit'
    assert parser.get_default('v') == False
    assert parser.get_default('vv') == False
    assert parser.get_default('vvv') == False
    assert parser.get_default('vvvv') == False
    assert parser.get_default('vvvvv') == False
    assert parser.get_default('vvvvvv') == False



# Generated at 2022-06-20 12:57:50.699210
# Unit test for function version
def test_version():
    assert version()

# Generated at 2022-06-20 12:57:59.706448
# Unit test for function add_async_options
def test_add_async_options():
    test_values = [('-B100', 100), ('-B100 -P40', 100), ('-B0 -P40', 0)]
    fail_values = ('-B', '-B0', '-B0 -P0', '-Ba -P40')
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    for test_cmd in test_values:
        namespace = parser.parse_args(test_cmd[0].split())
        assert namespace.seconds == test_cmd[1]

    for test_cmd in fail_values:
        try:
            namespace = parser.parse_args(test_cmd.split())
            assert False
        except SystemExit:
            pass
        except Exception:
            assert False



# Generated at 2022-06-20 12:58:03.945566
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    import ansible.utils.module_docs_fragments as mdf

    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    # add the arguments
    parser.add_argument('--bar', action="store", help="bar help")
    parser.add_argument('--foo', action="store", help="foo help")
    parser.add_argument('baz', nargs='*', default="badger")
    # print the help
    parser.print_help()


# Generated at 2022-06-20 12:58:13.695911
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()
    names = ["name1", "name2", "name3", "name4", "name5"]
    dest = "test_dest"
    option_string = None
    # Test with values is empty list
    pla = PrependListAction(names, dest)
    pla.__call__(None, namespace, [], option_string)
    assert getattr(namespace, dest) == []
    # Test with values is not empty list
    pla.__call__(None, namespace, names, option_string)
    assert getattr(namespace, dest) == names



# Generated at 2022-06-20 12:58:21.081121
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args('-C'.split())
    assert args.check == True
    args = parser.parse_args('--syntax-check'.split())
    assert args.syntax == True
    args = parser.parse_args('-C --syntax-check --diff'.split())
    assert args.check == True
    assert args.syntax == True
    assert args.diff == True
#
# Option Parsers for command line tools
#


# Generated at 2022-06-20 12:58:21.627875
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass



# Generated at 2022-06-20 12:58:24.455541
# Unit test for function version
def test_version():
    assert version().startswith('2.9.0')

#
# Special purpose OptionGroups
#

# Generated at 2022-06-20 12:58:34.862820
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(description='Test adding arguments', formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--spam')
    parser.add_argument('--ham')
    parser.add_argument('--baz')
    options = parser.parse_args([])
    assert not options  # options is an empty Namespace
    help = parser.format_help()
    print(help)

# Generated at 2022-06-20 12:58:42.517487
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(add_help=False)
    add_runtask_options(parser)
    parser.add_argument('-t')
    args = parser.parse_args(['-e', 'a=b', '-e', 'c=d', '-t', 'e'])
    # Test if the values are saved as a list in args
    assert args.extra_vars == ['a=b', 'c=d']
    assert args.t == 'e'



# Generated at 2022-06-20 12:58:51.105413
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='Description from the command line')
    add_vault_options(parser)
    args = parser.parse_args(['vault_id_val', 'ask_vault_pass', 'vault_password_file_val'])
    assert args.vault_ids == ['vault_id_val'], "vault_id should be set to 'vault_id_val'"
    assert args.ask_vault_pass, "ask_vault_pass should be set to True"
    assert args.vault_password_files == ['vault_password_file_val'], "vault_password_files should be set to ['vault_password_file_val']"


#
# Options inheritance
#


# Generated at 2022-06-20 12:59:05.638667
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=UnrecognizedArgument)
    try:
        parser.parse_args(['--foo'])
        assert False, "parse_args did not raise exception"
    except SystemExit:
        pass


# Generated at 2022-06-20 12:59:15.806468
# Unit test for function add_module_options
def test_add_module_options():
    parser = add_module_options(optionparser.OptionParser())
    args = parser.parse_args([])
    assert args.module_path == None
    parser = add_module_options(optionparser.OptionParser())
    args = parser.parse_args(['-M', "test1:test2"])
    assert args.module_path == ["test1:test2"]
    parser = add_module_options(optionparser.OptionParser())
    args = parser.parse_args(['--module-path', "test1:test2"])
    assert args.module_path == ["test1:test2"]
    parser = add_module_options(optionparser.OptionParser())
    args = parser.parse_args(['-M', "test1:test2", '-M', "test3"])
    assert args.module_

# Generated at 2022-06-20 12:59:18.447786
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    parser.parse_args(['-M','/etc/ansible', '-M', '/tmp/ansible'])
    assert C.DEFAULT_MODULE_PATH == ['/tmp/ansible','/etc/ansible']



# Generated at 2022-06-20 12:59:21.903335
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    UnrecognizedArgument(option_strings=['--test'], dest='test')

#
# ansible [--version] [-v] [-h] [--help]
#

# Generated at 2022-06-20 12:59:24.660438
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser('foo', usage="bar")
    add_fork_options(parser)
    assert parser is not None

# Generated at 2022-06-20 12:59:27.907092
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    parser.parse_args(['-t', 'foo'])
    parser.parse_args(['-o'])



# Generated at 2022-06-20 12:59:39.307484
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.cli.arguments import ConnectionOptions
    from units.mock.parser import ArgParseMock
    import units.modules.test_utils as test_utils
    from collections import namedtuple

    args = ['-k', '-c', 'test', '--ssh-common-args', 'common_args',
                   '--ssh-extra-args', 'extra_args', '--sftp-extra-args', 'sftp_args',
                   '--scp-extra-args', 'scp_args', '-T', '10', '-u', 'test_user',
                   '--private-key', 'private.pem']
    spec = namedtuple('spec', 'extra_vars_files vault_password_files')


# Generated at 2022-06-20 12:59:49.540859
# Unit test for function create_base_parser
def test_create_base_parser():
    import ansible.cli.argparse
    prog='/path/to/ansible-command'
    def test_parser(prog, usage, desc, epilog):
        parser = ansible.cli.argparse.create_base_parser(prog, usage, desc, epilog)
        assert parser.prog == prog
        assert parser.formatter_class == SortingHelpFormatter
        assert parser.epilog == epilog
        assert parser.description == desc
        assert parser.conflict_handler == 'resolve'
        assert parser._actions[0].option_strings == ('--version',)
        assert parser._actions[0].nargs == 0
        parser.parse_args('--version'.split())
    test_parser(prog, 'usage', 'description', 'epilog')

# Generated at 2022-06-20 12:59:52.979452
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    a = AnsibleVersion()
    parser = argparse.ArgumentParser()
    try:
        a(parser, None, None)
        assert False, "AnsibleVersion didn't call exit"
    except SystemExit:
        pass


# Generated at 2022-06-20 12:59:53.533820
# Unit test for function add_check_options
def test_add_check_options():
    pass



# Generated at 2022-06-20 13:00:07.793586
# Unit test for function add_subset_options
def test_add_subset_options():

    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args('-t ')
    assert options.tags == C.TAGS_RUN


# Generated at 2022-06-20 13:00:12.081746
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser(prog='ansible', formatter_class=SortingHelpFormatter)
    add_tasknoplay_options(parser)
    args = parser.parse_args()
    assert args.task_timeout == C.TASK_TIMEOUT



# Generated at 2022-06-20 13:00:17.325562
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter,epilog="""
    epilog for add_fork_options
    """)
    add_fork_options(parser)
    parser.print_help()
    argv = ["-f","2"]
    options = parser.parse_args(argv)
    print(options.forks)

add_fork_options(create_base_parser(prog="",desc="""desc for add_fork_options"""))



# Generated at 2022-06-20 13:00:20.732312
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser('tmp', 'hello')
    # parser = create_base_parser('tmp', 'usage', 'hi')
    parser.print_help()



# Generated at 2022-06-20 13:00:23.603610
# Unit test for function add_fork_options
def test_add_fork_options():
    from ansible.utils.vars import combine_vars
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args([])
    vars = vars_from_args(args)
    # make sure vars are correct
    assert vars == combine_vars(C.config.running_config, dict())



# Generated at 2022-06-20 13:00:28.954012
# Unit test for function add_output_options
def test_add_output_options():
    parser_out = argparse.ArgumentParser(prog='ansible-doc',
                                         formatter_class=SortingHelpFormatter,
                                         description='Manage Ansible Modules',
                                         )
    add_output_options(parser_out)
    data = parser_out.parse_args()
    assert data.one_line == False
    assert data.tree == None



# Generated at 2022-06-20 13:00:31.941393
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['--inventory', 'test', '--list-hosts'])
    assert args.inventory == ['test']
    assert args.listhosts == True
    assert args.subset == 'all'



# Generated at 2022-06-20 13:00:38.062520
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog="ansible-cmdb")
    add_connect_options(parser)
    opts = parser.parse_args(['--ask-pass', '--timeout', '5', '-k',
                              '--ssh-common-args', "vagrant"])
    assert opts.ask_pass, 5
    assert opts.timeout == 5
    assert opts.ssh_common_args == "vagrant"



# Generated at 2022-06-20 13:00:40.795143
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_inventory_options(parser)
    args = parser.parse_args(['-i', '/etc/ansible/hosts', '--list-hosts', '-l', 'webserver'])
    assert args.inventory is not None
    assert args.listhosts is True
    assert args.subset == 'webserver'


# Generated at 2022-06-20 13:00:46.226638
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/bar') == '@' + unfrackpath('/bar')
    assert maybe_unfrack_path('@')('/bar') == '/bar'
    assert maybe_unfrack_path('@@')('@@/bar') == '@@' + '/bar'
    assert maybe_unfrack_path('@@')('@/bar') == '@/bar'


# Generated at 2022-06-20 13:01:24.869466
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options, args = parser.parse_known_args(['-B10'])
    
    # assert that the global variable C.DEFAULT_POLL_INTERVAL will be used
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL
    
    # assert additional arguments
    assert options.seconds == 10



# Generated at 2022-06-20 13:01:26.735014
# Unit test for function create_base_parser
def test_create_base_parser():
    base_parser = create_base_parser('ansible')
    assert isinstance(base_parser, argparse.ArgumentParser)



# Generated at 2022-06-20 13:01:36.666462
# Unit test for function version
def test_version():
    # Set up some fake file names and directories
    fake_prog = "test_version"
    fake_exe_dir = "/ansible/test"
    fake_python= "whatever"
    fake_jinja_version = "Jinja2 Test"
    fake_base_dir = "/ansible/base"
    fake_gitinfo = "{} Test".format(_git_repo_info.__name__)

    # Set up some fake file paths
    fake_config = os.path.join(fake_base_dir, "ansible.cfg")
    fake_ansible_path = os.path.join(fake_base_dir, "lib", "ansible")
    fake_collections_path = os.path.join(fake_base_dir, "collections")

    # Set up some fake environment variables
    fake_