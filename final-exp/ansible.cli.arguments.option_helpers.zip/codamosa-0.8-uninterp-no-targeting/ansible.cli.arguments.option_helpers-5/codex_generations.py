

# Generated at 2022-06-20 12:52:23.327224
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = maybe_unfrack_path("@")
    assert path("@/some/path") == "@%s/some/path" % unfrackpath("/some/path")
    assert path("@@/some/path") == "@@%s/some/path" % unfrackpath("/some/path")
    assert path("@./some/path") == "@.%s/some/path" % unfrackpath("/some/path")
    assert path("@../some/path") == "@../%s/some/path" % unfrackpath("/some/path")
    assert path("@./../some/path") == "@./../%s/some/path" % unfrackpath("/some/path")
    assert path(" ~/.ssh/id_rsa") == " ~/.ssh/id_rsa"

# Generated at 2022-06-20 12:52:26.788063
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)

    assert parser is not None

    help_str = 'specify number of parallel processes to use (default=%s)' % C.DEFAULT_FORKS
    r = parser.parse_args(['-f', '1'])
    assert r.forks == '1'



# Generated at 2022-06-20 12:52:31.187661
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    # this should look like verbose mode
    args = parser.parse_args(['-vvvvvvvvvvvv'])
    assert args.verbosity == 12



# Generated at 2022-06-20 12:52:32.424871
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)


#
# Functions to modify an AnsibleCommand object
#


# Generated at 2022-06-20 12:52:45.552544
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    arg_string = "--version"
    arg_string_with_one_v = "-v"
    arg_string_with_two_v = "-vv"
    arg_string_with_three_v = "-vvv"
    arg_string_with_four_v = "-vvvv"

    parser = create_base_parser("ansible", desc="Ansible")
    ret = add_verbosity_options(parser)

    # test version help
    args = parser.parse_args(arg_string.split())
    assert args.verbosity == 0

    # default
    args = parser.parse_args(arg_string.split())
    assert args.verbosity == C.DEFAULT_VERBOSITY

    # with one v
    args = parser.parse_args(arg_string_with_one_v.split())

# Generated at 2022-06-20 12:52:47.177175
# Unit test for function add_fork_options
def test_add_fork_options():
    parser=argparse.ArgumentParser()
    add_fork_options(parser)
    args_list=["-f","2"]
    args=parser.parse_args(args_list)
    assert args.forks==2,"add_fork_options failed"
# Test ends


# Generated at 2022-06-20 12:52:50.721239
# Unit test for function add_subset_options
def test_add_subset_options():
    parser=argparse.ArgumentParser()
    add_subset_options(parser)
    args=parser.parse_args(['-t','tag1','--skip-tags','tag2'])
    assert args.tags==['tag1']
    assert args.skip_tags==['tag2']

# Generated at 2022-06-20 12:52:58.334487
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """
    These test cases should be adjusted if function maybe_unfrack_path is refactored or changed
    :return:
    """
    t_f_a = ('test_path1', 'test_path2', 'test_path3')
    # Unfrcaking should always be true
    t_f_a1 = (False, False, False, False)
    # The results of maybe_unfrcak_path
    t_f_r1 = ('test_path1', 'test_path2', 'test_path3', 'test_path4')

    for f, a, r in zip(t_f_a, t_f_a1, t_f_r1):
        t_f = maybe_unfrack_path(f)
        assert t_f('test_path4') == r



# Generated at 2022-06-20 12:53:07.910375
# Unit test for function add_basedir_options
def test_add_basedir_options():
    p = argparse.ArgumentParser()
    add_basedir_options(p)
    # Test default
    # This is untestable as it depends on the current working directory
    # and the value of config.get_config_value('PLAYBOOK_DIR')
    # But we can check that running it with no arguments doesn't fail
    args = p.parse_args([])
    assert args.basedir is not None
    # Test an absolute path
    args = p.parse_args(['--playbook-dir', '/foo/bar/baz'])
    assert args.basedir == '/foo/bar/baz'
    # Test a relative path
    args = p.parse_args(['--playbook-dir', 'foo/bar/baz'])
    assert args.basedir == 'foo/bar/baz'




# Generated at 2022-06-20 12:53:12.820893
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class DummyNS(object):
        pass
    dummy = DummyNS()
    dummy.prog = 'ansible'
    av = AnsibleVersion(option_strings=('--version',),
                        dest='version', default=False,
                        help='show program version')
    av(dummy, dummy, True)



# Generated at 2022-06-20 12:53:44.516230
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    from ansible.utils.color import ANSIBLE_COLOR
    p = create_base_parser('test', 'testing')
    add_verbosity_options(p)
    options = p.parse_args([])
    assert options.verbosity == C.DEFAULT_VERBOSITY
    options = p.parse_args(['-v'])
    assert options.verbosity == 1
    options = p.parse_args(['-vvvv'])
    assert options.verbosity == 4
    options = p.parse_args(['-vvvvvvvv'])
    assert options.verbosity == C.DEFAULT_VERBOSITY



# Generated at 2022-06-20 12:53:50.109476
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # AnsibleVersion:__call__:1
    # exit_code: 0
    # stdout:
    # stderr:
    # AnsibleVersion:__call__:2
    # exit_code: 0
    # stdout:
    # stderr:
    pass



# Generated at 2022-06-20 12:53:57.743313
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog="test")
    add_connect_options(parser)

    # Ensure that connection_password_file arguments are all added
    args = parser.parse_args(['--conn-pass-file', 'some_file'])
    assert args.connection_password_file == 'some_file'

    args = parser.parse_args(['--connection-password-file', 'some_file'])
    assert args.connection_password_file == 'some_file'


# Generated at 2022-06-20 12:54:02.077635
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-foo')
    parser.add_argument('-bar')
    parser.parse_args(args=[])
    assert '-bar' in parser.format_help()
    assert parser.format_help().index('-foo') > parser.format_help().index('-bar')


# Generated at 2022-06-20 12:54:07.776754
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', 'A=B', '-e', '@TEST.yaml', '-e', '{"C": "D"}'])
    assert args.extra_vars == ['A=B', '@TEST.yaml', '{"C": "D"}']



# Generated at 2022-06-20 12:54:11.922653
# Unit test for function ensure_value
def test_ensure_value():
    m = argparse.Namespace()
    ensure_value(m, 'foo', 42)
    assert m.foo == 42
    m.foo = [1, 2, 3]
    ensure_value(m, 'foo', 42)
    assert m.foo == [1, 2, 3]



# Generated at 2022-06-20 12:54:16.966297
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import ansible.utils.display as D
    D.VERBOSITY = False
    print('1' + (' '*(21-len('1'))))
    parser = argparse.ArgumentParser()
    parser.prog = to_native('1')
    action = AnsibleVersion()
    action(parser,'namespace','values')


# Generated at 2022-06-20 12:54:17.936993
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    assert True == True



# Generated at 2022-06-20 12:54:24.744580
# Unit test for function add_basedir_options
def test_add_basedir_options():
    """Add options for commands which can set a playbook basedir"""
    parser = argparse.ArgumentParser(prog='Add basedir options', formatter_class=SortingHelpFormatter,description='description',
                                       conflict_handler='resolve')
    add_basedir_options(parser)
    assert parser.description == 'description'
    assert parser.prog == 'Add basedir options'
    assert parser.error == parser.exit
    assert parser.conflict_handler == 'resolve'


# Generated at 2022-06-20 12:54:29.350355
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options = parser.parse_args([])
    assert options.force_handlers == C.DEFAULT_FORCE_HANDLERS
    assert not options.flush_cache

# Generated at 2022-06-20 12:54:43.305930
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser('test')
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'host1,host2', 'host3,host4', '-l', 'host5'])
    assert args.inventory == ['host1,host2', 'host3,host4']
    assert args.subset == 'host5'
    assert args.listhosts is False



# Generated at 2022-06-20 12:54:50.493361
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class Row(object):
        def __init__(self, idx, option_strings, dest):
            self.idx = idx
            self.option_strings = option_strings
            self.dest = dest
    # Sorted by option strings and argument names

# Generated at 2022-06-20 12:54:58.508373
# Unit test for function add_output_options
def test_add_output_options():
    parser = Mock()
    add_output_options(parser)
    assert parser.add_argument.called
    args, kwargs = parser.add_argument.call_args
    assert args == (
            '-o', '--one-line',
        )
    assert 'dest' in kwargs
    assert kwargs['dest'] == 'one_line'
    assert 'action' in kwargs
    assert kwargs['action'] == 'store_true'
    assert 'help' in kwargs
    assert kwargs['help'] == 'condense output'



# Generated at 2022-06-20 12:55:03.251924
# Unit test for function version
def test_version():
    # testing with gitinfo
    assert version('test') == 'test [core {0}] ({1}) last updated 1970/01/01 04:00:00 (GMT +0400)'.format(__version__, 'test')
    # testing without git info
    assert version('test') == 'test [core {0}]'.format(__version__)

# Generated at 2022-06-20 12:55:07.937295
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    opts, _ = parser.parse_known_args()

    assert opts.become == C.DEFAULT_BECOME
    assert opts.become_method == C.DEFAULT_BECOME_METHOD
    assert opts.become_user is None



# Generated at 2022-06-20 12:55:12.906792
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = Namespace(a=[1])
    PrependListAction(option_strings=None, dest='a', nargs=argparse.OPTIONAL, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None).__call__(None, namespace, [2])
    assert namespace==Namespace(a=[2, 1])



# Generated at 2022-06-20 12:55:23.811221
# Unit test for function add_connect_options
def test_add_connect_options():
    """
    unit tests for add_connect_options method
    """
    parser = argparse.ArgumentParser(
        prog='ansible',
        description="Ansible mod1: validates arguments for connection options",
        epilog="shreekant"
    )
    add_connect_options(parser)
    option_args = ['--private-key', '/some/path', '-u', 'user', '-c', 'local', '-T', '5', '--ssh-common-args', 'test',
                   '--sftp-extra-args', 'test', '--scp-extra-args', 'test', '--ssh-extra-args', 'test', '-k', '--connection_password_file',
                   '/some/path']
    args = parser.parse_args(option_args)

# Generated at 2022-06-20 12:55:30.539977
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    assert len(parser.add_argument_group.mock_calls) == 1
    assert len(parser.add_argument_group().add_mutually_exclusive_group.mock_calls) == 1
    assert len(parser.add_argument_group().add_mutually_exclusive_group().add_argument.mock_calls) == 2



# Generated at 2022-06-20 12:55:36.883027
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    (args, _) = parser.parse_known_args()
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP
    #
#

#
# Functions to add collections usage to an OptionParser
#



# Generated at 2022-06-20 12:55:41.709388
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(beacon='@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path(beacon='@')('@@/foo/bar') == '@@/foo/bar'


# Generated at 2022-06-20 12:55:55.095676
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args([])
    assert args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS

    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True

    args = parser.parse_args(['--become-password-file', './password.txt'])
    assert args.become_ask_pass is False



# Generated at 2022-06-20 12:55:58.653998
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test", usage="test usage")
    assert isinstance(parser, argparse.ArgumentParser)
    assert parser.prog == "test"



# Generated at 2022-06-20 12:56:09.030161
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Create a parser to hold the options
    parser = argparse.ArgumentParser()
    # Add the options
    add_runas_prompt_options(parser)
    # Create a test args list with options selected
    test_args = ['--ask-become-pass']
    # Parse the arg list using both the args and the parser
    args = parser.parse_args(test_args)
    # test the result
    assert args.become_ask_pass

    # Create a test args list with options selected
    test_args = ['--become-password-file', 'mypath']
    # Parse the arg list using both the args and the parser
    args = parser.parse_args(test_args)
    # test the result
    assert args.become_password_file == "mypath"



# Generated at 2022-06-20 12:56:17.419421
# Unit test for function add_check_options
def test_add_check_options():
    from ansible.cli import CLI
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(None, None, display)

    parser = cli.base_parser()
    add_check_options(parser)

    assert '-C' in parser._option_string_actions
    assert '--check' in parser._option_string_actions

    assert '--syntax-check' in parser._option_string_actions

    assert '-D' in parser._option_string_actions
    assert '--diff' in parser._option_string_actions



# Generated at 2022-06-20 12:56:18.515562
# Unit test for function add_meta_options
def test_add_meta_options():
     # This is just a dummy function that is used for unit testing.
     return True


# Generated at 2022-06-20 12:56:24.022608
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    maybe_unfrack_path_test = maybe_unfrack_path('-')
    assert maybe_unfrack_path_test('-m') == '-m'
    assert maybe_unfrack_path_test('-~') == '-~'
    assert maybe_unfrack_path_test('-~/Downloads') == '-~/Downloads'
    assert maybe_unfrack_path_test('--version') == '--version'
    assert maybe_unfrack_path_test('--') == '--'



# Generated at 2022-06-20 12:56:25.976386
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    results = vars(parser.parse_args('-f 8'.split()))
    assert results['forks'] == 8


# Generated at 2022-06-20 12:56:37.495955
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version_test_parser = argparse.ArgumentParser(description='an Ansible version parser')
    ansible_version_test_parser.add_argument('--version', action=AnsibleVersion)
    ansible_version_test_parser.prog = 'ansible-test'
    with open('/tmp/_test_ansible_version_output', 'wb') as ansible_version_test_file:
        ansible_version_test_file.write(version('ansible-test').encode('utf-8'))
    os.environ['_ANSIBLE_TEST_PROG_NAME'] = 'ansible-test'
    ansible_version_test_parser.parse_args(['--version'])

# Generated at 2022-06-20 12:56:41.310660
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    p = create_base_parser('test_add_verbosity_options')
    result = p.parse_args(['-vvvv'])
    assert result.verbosity == 4
    assert result.verbosity > 3



# Generated at 2022-06-20 12:56:48.986747
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog="test")
    add_runas_options(parser)
    options = parser.parse_args(["-b", "--become-method=su", "--become-user=nobody", "--ask-become-pass"])
    # This might need to be updated depending on the default value of C.DEFAULT_BECOME_USER
    assert options.become_user == "nobody"
    assert options.ask_become_pass  # pylint: disable=no-member
    assert options.become  # pylint: disable=no-member
    assert options.become_method == "su"



# Generated at 2022-06-20 12:57:01.209503
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    base_parser = create_base_parser(parser.prog)
    base_opt = base_parser.parse_args()
    opt = parser.parse_args('-b'.split())

    assert opt.become == base_opt.become
    assert opt.become_method == base_opt.become_method
    assert opt.become_user == base_opt.become_user
    assert opt.become_ask_pass == base_opt.become_ask_pass
    assert opt.become_ask_su_pass == base_opt.become_ask_su_pass



# Generated at 2022-06-20 12:57:06.180967
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test =  maybe_unfrack_path('@')
    if '(detached HEAD' in test('@HEAD'):
        raise AssertionError('Test that the @ prefix is maintained in maybe_unfrack_path failed')


#
# OptionParser for all Ansible scripts which accept a subset of common options
#

# Generated at 2022-06-20 12:57:08.195294
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert parser.get_default('become') is True
    assert parser.get_default('become_method') == 'sudo'
    assert parser.get_default('become_user') is None



# Generated at 2022-06-20 12:57:11.410871
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)

    args = parser.parse_args(['-P', '1500', '-B', '6000'])
    assert args.poll_interval == 1500
    assert args.seconds == 6000


# Generated at 2022-06-20 12:57:17.796600
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~/template.j2') == '~/template.j2'
    if os.path.exists('/usr/share/ansible/template.j2'):
        assert maybe_unfrack_path('/usr/share/ansible')('~/template.j2') == '/usr/share/ansible/template.j2'
        assert maybe_unfrack_path('/usr/share/ansible')('/usr/share/ansible/template.j2') == '/usr/share/ansible/template.j2'
        assert maybe_unfrack_path('.')('~/template.j2') == './template.j2'

# Generated at 2022-06-20 12:57:27.075345
# Unit test for function add_async_options
def test_add_async_options():
    mock_parser = argparse.ArgumentParser(prog='test_add_async_options', add_help=False)
    add_async_options(mock_parser)
    arg_dict = vars(mock_parser.parse_args(['-P', '20', '-B', '300']))
    assert arg_dict['poll_interval'] == 20
    assert arg_dict['seconds'] == 300
    with pytest.raises(SystemExit):
        vars(mock_parser.parse_args(['-P']))
    with pytest.raises(SystemExit):
        vars(mock_parser.parse_args(['-B']))



# Generated at 2022-06-20 12:57:30.816183
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-t', './test_tree'])
    assert args.tree == './test_tree'



# Generated at 2022-06-20 12:57:37.177742
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    parser.parse_args([])
    #assert parser.add_argument.assert_called_with('--playbook-dir', default='~/', dest='basedir', action='store',
    #                help="Since this tool does not use playbooks, use this as a substitute playbook directory."
    #                        "This sets the relative path for many features including roles/ group_vars/ etc.",
    #                type='unfrack_path()')
    #sys.exit()

# Generated at 2022-06-20 12:57:40.516430
# Unit test for function add_output_options
def test_add_output_options():
    parser = create_base_parser('test')
    add_output_options(parser)    
    args = parser.parse_args(['-t', 'test_dir'])
    assert args.tree == 'test_dir' 


# Generated at 2022-06-20 12:57:49.150735
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    # Call method under test
    action = PrependListAction(
        option_strings = ['-t'],
        dest = 'target',
        help = "print a traceback on exceptions"
    )
    # Verify results
    assert action.__call__(
        parser = parser,
        namespace = None,
        values = ['target'],
        option_string = None
    ) == None, 'Test Failed'
test_PrependListAction___call__()


#
# OptionParser Factories
#

# Generated at 2022-06-20 12:58:14.961927
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/my/path') == '/my/path'
    assert unfrack_path()('../my/path') == '../my/path'
    assert unfrack_path()('./my/path') == './my/path'
    assert unfrack_path()('~/my/path') == os.path.expanduser('~/my/path')
    assert unfrack_path(pathsep=True)('~/my/path') == [os.path.expanduser('~/my/path')]
    assert unfrack_path(pathsep=True)('/my/path1:/my/path2') == ['/my/path1', '/my/path2']

#
# Base parser classes
#



# Generated at 2022-06-20 12:58:19.147771
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    args = argparse.Namespace(version=False)
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, nargs=0)
    parser.parse_args(namespace=args)
    assert args.version


# Generated at 2022-06-20 12:58:24.088659
# Unit test for function add_subset_options
def test_add_subset_options():
    # test when arg is not of type parser
    parser = argparse.ArgumentParser()
    try:
        add_subset_options(None)
        assert False
    except TypeError:
        assert True
    # test when arg is of type parser
    parser = argparse.ArgumentParser()
    try:
        add_subset_options(parser)
        assert True
    except TypeError:
        assert False



# Generated at 2022-06-20 12:58:30.378274
# Unit test for function add_fork_options
def test_add_fork_options():
    parser=argparse.ArgumentParser()
    add_fork_options(parser)

    opt1 = parser.parse_args(['-f', '1'])
    assert opt1.forks == 1

    opt2 = parser.parse_args([])
    assert opt2.forks == C.DEFAULT_FORKS


# Generated at 2022-06-20 12:58:38.675335
# Unit test for function add_runtask_options
def test_add_runtask_options():
    
    argv = [
        '-e', '@test.yml',
        '-e', '@test.json',
        '-e', '@test.txt',
        '-e', 'key=value',
        '-e', '@test.txt'
    ]

    parser = argparse.ArgumentParser(description='ansible runtask.py options')
    add_runtask_options(parser)

    (options, args) = parser.parse_known_args(argv)

    assert options.extra_vars == ['test.yml', 'test.json', '@test.txt', 'key=value', '@test.txt']


# Generated at 2022-06-20 12:58:43.182840
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--example',
        action=UnrecognizedArgument,
        option_strings=['--example']
    )
    parser.parse_args(['--example', 'foo'])



# Generated at 2022-06-20 12:58:51.261008
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runas_prompt_options(parser)
    args = parser.parse_args(['--ask-become-pass'])
    assert args.become_ask_pass is True
    args = parser.parse_args(['--become-password-file', 'myfile'])
    assert args.become_password_file == 'myfile'



# Generated at 2022-06-20 12:58:57.047245
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    ns = Namespace()
    assert getattr(ns, 'foo', None) is None
    v1 = ensure_value(ns, 'foo', 'bar')
    assert v1 == 'bar'
    assert getattr(ns, 'foo', None) == v1
    v2 = ensure_value(ns, 'foo', 'baz')
    assert v2 == 'bar'
    assert getattr(ns, 'foo', None) == v2



# Generated at 2022-06-20 12:59:07.900001
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():

    # test function with None as arg 
    parser = argparse.ArgumentParser(description="My test parser")
    add_runas_prompt_options(parser)
    results = parser.parse_args("")
    assert results.become_password_file is None
    assert results.become_ask_pass is False

    # test function with no option
    results = parser.parse_args("")
    assert results.become_password_file is None
    assert results.become_ask_pass is False

    # test function with -K option
    results = parser.parse_args("-K")
    assert results.become_password_file is None
    assert results.become_ask_pass is True

    # test function with --become-pass-file option

# Generated at 2022-06-20 12:59:13.050878
# Unit test for function add_async_options
def test_add_async_options():
    mock_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_async_options(mock_parser)
    mock_args = mock_parser.parse_args(['-P', '10', '-B', '20'])
    assert mock_args.poll_interval == 10
    assert mock_args.seconds == 20


# Generated at 2022-06-20 13:00:47.619471
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # If the argument is unrecognized, the parser will throw an error
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--unknown_argument', action=UnrecognizedArgument,
                        help='unknown argument', metavar='unknown_argument')
    args = parser.parse_args(['-u', 'unknown_argument'])
    args = parser.parse_args(['--unknown_argument', 'unknown_argument'])


# Generated at 2022-06-20 13:00:50.995767
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    (options, args) = parser.parse_known_args(args=['-o','--tree','.','-t','.'])
    assert options.one_line == True
    assert options.tree == '.'


# Generated at 2022-06-20 13:01:00.445615
# Unit test for constructor of class UnrecognizedArgument

# Generated at 2022-06-20 13:01:03.912607
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--unrecognized", action=UnrecognizedArgument)
    with pytest.raises(SystemExit):
        parser.parse_args(["--unrecognized"])
        assert parser.error.called



# Generated at 2022-06-20 13:01:15.125359
# Unit test for function add_check_options
def test_add_check_options():
    #test with default value
    from ansible.cli.argparse.default import create_base_parser
    parser = create_base_parser()
    add_check_options(parser)
    argv = ["-C","--syntax-check","-D"]
    parsed_args = parser.parse_args(argv)
    assert parsed_args.check is True
    assert parsed_args.syntax is True
    assert parsed_args.diff is True

    #test with other values
    parser = create_base_parser()
    add_check_options(parser)
    argv = ["--check=False","--syntax-check=False","--diff=False"]
    parsed_args = parser.parse_args(argv)
    assert parsed_args.check is False
    assert parsed_args.syntax is False
    assert parsed

# Generated at 2022-06-20 13:01:16.303310
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    parser.parse_args(["-C", "--syntax-check", "-D"])



# Generated at 2022-06-20 13:01:21.104050
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--verbosity', action='count', default=0)
    args = parser.parse_args([])
    assert args.verbosity == 0
    args = parser.parse_args(['-v'])
    assert args.verbosity == 1
    args = parser.parse_args(['-vv'])
    assert args.verbosity == 2
    args = parser.parse_args(['-v', '-v'])
    assert args.verbosity == 2
#
# END Special purpose OptionParsers
#


#
# Option Parsing
#

# Generated at 2022-06-20 13:01:24.657556
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    Tests the function: AnsibleModule.add_runas_prompt_options()

    Unit tests for the add_runas_prompt_options() function.  The function is called to make sure that it does not error
    when called.
    """
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    results = parser.parse_args()
    assert results.become_ask_pass == False
    assert results.become_password_file == None


# Generated at 2022-06-20 13:01:28.631224
# Unit test for function create_base_parser
def test_create_base_parser():
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import DocCLI
    cli = DocCLI()
    display = Display()
    parser = create_base_parser(prog="test_version",usage="", desc=None, epilog=None)
    options = parser.parse_args(["--version"])
    assert options

# Generated at 2022-06-20 13:01:33.584514
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    opt = PrependListAction(option_strings=['--foo'], dest='foo', nargs=1)
    args = argparse.Namespace(foo=['baz'])
    opt(None, args, ['bar'])
    assert args.foo == ['bar', 'baz']

