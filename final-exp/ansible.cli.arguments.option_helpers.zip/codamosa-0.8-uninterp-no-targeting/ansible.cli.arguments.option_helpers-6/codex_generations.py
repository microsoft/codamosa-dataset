

# Generated at 2022-06-20 12:52:36.972239
# Unit test for function add_module_options
def test_add_module_options():
    parser = MockParser()
    add_module_options(parser)
    assert parser.arguments[0].option_strings == ['-M', '--module-path']
    assert parser.arguments[0].dest == 'module_path'
    assert parser.arguments[0].default is None
    assert parser.arguments[0].help.startswith('prepend colon-separated path(s) to module library')
    assert parser.arguments[0].type == unfrack_path(pathsep=True)
    assert parser.arguments[0].action == PrependListAction



# Generated at 2022-06-20 12:52:49.607471
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='test_add_runtask_options.py')
    add_runtask_options(parser)
    # test extra_vars
    args = parser.parse_args(['-e', 'VAR1=1', '-e', '@FILE', '-e', '@JSON.txt'])
    assert args.extra_vars == [{'VAR1': '1'}, {'VAR2': '2'}, {'VAR3': 1, 'VAR4': '2'}]
    # test extra_vars with YAML
    if HAS_YAML:
        args = parser.parse_args(['-e', 'VAR1=1', '-e', '@YAML.txt'])

# Generated at 2022-06-20 12:52:54.214066
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible, test_add_async_options')
    add_async_options(parser)
    options = parser.parse_args(['-P', '1', '-B', '2'])
    assert options.poll_interval == 1
    assert options.seconds == 2



# Generated at 2022-06-20 12:52:57.417262
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    for opt in ['--force-handlers', '--flush-cache']:
        assert opt in parser._option_string_actions
    assert parser._long_opt.get('--force-handlers') == '--force-handlers'
    assert parser._long_opt.get('--flush-cache') == '--flush-cache'



# Generated at 2022-06-20 12:53:07.825738
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(['--private-key', '~/.ssh/testing', '--user', 'testuser',
                                 '--connection', 'connection_type', '--timeout', '300',
                                 '--ssh-common-args', '~/.ssh/testing', '--sftp-extra-args',
                                 'testing', '--scp-extra-args', 'testing', '--ssh-extra-args',
                                 'testing', '--ask-pass', '-k', '--connection-password-file',
                                 '~/.ssh/testconnpass'])
    assert options.private_key_file == '~/.ssh/testing'
    assert options.remote_user == 'testuser'

# Generated at 2022-06-20 12:53:16.823787
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('..') == os.path.abspath(os.path.join(os.getcwd(), '..'))
    assert unfrack_path(pathsep=True)('..'+os.pathsep+'.') == [os.path.abspath(os.path.join(os.getcwd(), '..')), os.getcwd()]
    assert unfrack_path()('/tmp/test') == '/tmp/test'
    assert unfrack_path(pathsep=True)('/tmp/test'+os.pathsep+'/tmp/test2') == ['/tmp/test', '/tmp/test2']



# Generated at 2022-06-20 12:53:25.406736
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)
    #
    # Check call count
    #
    assert parser.add_argument.call_count == 2
    #
    # Check first call
    #
    first_args = parser.add_argument.call_args_list[0]
    assert first_args[0] == ('--force-handlers',)
    assert first_args[1] == dict(dest='force_handlers', default=C.DEFAULT_FORCE_HANDLERS, action='store_true',
                                 help="run handlers even if a task fails")
    #
    # Check second call
    #
    second_args = parser.add_argument.call_args_list[1]
    assert second_args[0] == ('--flush-cache',)
    assert second_args

# Generated at 2022-06-20 12:53:35.631793
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
    )
    add_runtask_options(parser)
    args = ['-e', "passwd=abcdef", '-e', "ip=127.0.0.1", '-e', "@/home/user/test.json"]
    parsed = parser.parse_args(args)
    assert parsed.extra_vars == [{'passwd': "abcdef"}, {'ip': "127.0.0.1"}, "@/home/user/test.json"]


# Generated at 2022-06-20 12:53:44.347582
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    data = parser.parse_args(shlex.split('-e "var1=val1" -e @/test_vars_file.yml'))
    assert data.extra_vars == [b'var1=val1', '/test_vars_file.yml']
    data = parser.parse_args(shlex.split('-e @/test_vars_file.yml -e "var1=val1"'))
    assert data.extra_vars == ['/test_vars_file.yml', b'var1=val1']

# Generated at 2022-06-20 12:53:55.517814
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.module_utils.common.collections import ImmutableDict
    from units.compat.mock import patch, MagicMock
    parser = MagicMock()
    parser.add_argument_group.return_value = 'foo'
    parser.add_mutually_exclusive_group.return_value = 'bar'
    with patch.dict(C.__dict__, {'CONNECTION_PASSWORD_FILE': 'test'}):
        add_connect_options(parser)
        # check it doesn't crash
        assert parser.call_count == 6
        assert parser.add_argument_group.call_count == 2
        assert parser.add_mutually_exclusive_group.call_count == 1



# Generated at 2022-06-20 12:54:18.670375
# Unit test for function add_async_options
def test_add_async_options():
    parse = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_async_options(parse)
    args = parse.parse_args(['-P', '2'])
    assert args.poll_interval == 2
    args = parse.parse_args(['-B', '4'])
    assert args.seconds == 4


# Generated at 2022-06-20 12:54:26.264649
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    try:
        prog = "ansible-script-name"
        opt = "-a"
        AnsibleVersion(option_strings=opt, dest=None, nargs=0, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)(parser=None, namespace=None, values=None, option_string=opt)
        assert True
    except Exception as e:
        assert False, "Constructor of class AnsibleVersion threw an exception: " + str(e)



# Generated at 2022-06-20 12:54:33.653982
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    add_runas_prompt_options() function unit test
    """
    parser = argparse.ArgumentParser(prog='tests', description="Test add_runas_prompt_options() function")
    add_runas_prompt_options(parser)
    parse = parser.parse_args(['--become-password-file', 'become_password_file'])
    assert parse.become_password_file == 'become_password_file'
    parse = parser.parse_args(['-K'])
    assert parse.become_ask_pass == True



# Generated at 2022-06-20 12:54:39.188747
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.utils.display import Display
    from ansible.errors import AnsibleOptionsError

    display = Display()
    default_private_key_file = '/Users/username/.ssh/id_rsa'
    default_remote_user = 'username'
    default_transport = 'ssh'
    default_timeout = 10
    default_conn_pass_file = '/Users/username/.ssh/passfile'
    fake_argument_parser = argparse.ArgumentParser(prog='ansible')
    add_connect_options(fake_argument_parser)
    options = fake_argument_parser.parse_args(['-u', default_remote_user, '--private-key', default_private_key_file, '--connection-password-file', default_conn_pass_file])
    assert options.remote_user == default_remote

# Generated at 2022-06-20 12:54:41.955353
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='roots')
    add_meta_options(parser)

    args = parser.parse_args(['--force-handlers'])
    assert args.force_handlers

    args = parser.parse_args(['--flush-cache'])
    assert args.flush_cache



# Generated at 2022-06-20 12:54:47.823769
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(["--become-pass"])
    assert args.become_ask_pass is False
    args = parser.parse_args(["--become-pass-file", "foo"])
    assert args.become_ask_pass is False
    args = parser.parse_args(["--ask-become-pass"])
    assert args.become_ask_pass is True


# Generated at 2022-06-20 12:55:00.407535
# Unit test for method __call__ of class PrependListAction

# Generated at 2022-06-20 12:55:04.340791
# Unit test for function add_output_options
def test_add_output_options():
    cmd = ['test']
    parser = argparse.ArgumentParser(prog="test", usage="")
    add_output_options(parser)
    args = parser.parse_args(cmd)
    assert args.tree is None
    assert args.one_line is False


# Generated at 2022-06-20 12:55:04.936692
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    pass



# Generated at 2022-06-20 12:55:07.448642
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)



# Generated at 2022-06-20 12:55:17.430416
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    p = argparse.ArgumentParser()
    p.add_argument('--version', action=AnsibleVersion)
    args = p.parse_args(['--version'])



# Generated at 2022-06-20 12:55:24.125835
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.module_utils.common.argparse_utils import PrependListAction, UnrecognizedArgument
    parser = argparse.ArgumentParser(epilog='ERROR:', prog='test_add_async_option')
    add_async_options(parser)
    # add_async_options adds option "-P" it should be 'poll_interval'
    assert parser._option_string_actions['-P'].dest == 'poll_interval'
    assert parser._option_string_actions['-B'].dest == 'seconds'

# Generated at 2022-06-20 12:55:30.959888
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = argparse.ArgumentParser()
    add_verbosity_options(parser)
    options = parser.parse_args([])
    assert options.verbosity == 0

    options = parser.parse_args(['-v'])
    assert options.verbosity == 1

    options = parser.parse_args(['-vv'])
    assert options.verbosity == 2

    options = parser.parse_args(['-vvv'])
    assert options.verbosity == 3



# Generated at 2022-06-20 12:55:43.024665
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from io import StringIO
    import argparse
    optparser = argparse.ArgumentParser(usage='%(prog)s', formatter_class=SortingHelpFormatter)
    optparser.add_argument('-b')
    optparser.add_argument('--foo')
    optparser.add_argument('-d')
    optparser.add_argument('-a')
    optparser.add_argument('-c')
    outfile = StringIO()
    optparser.print_help(file=outfile)
    expectation = '\n'.join([
        'usage: %(prog)s',
        '',
        'optional arguments:',
        '  -a\n  -b\n  -c\n  -d\n  --foo\n',
    ])
    assert outfile.getvalue()

# Generated at 2022-06-20 12:55:45.230367
# Unit test for function add_async_options
def test_add_async_options():
    parser = create_base_parser('add_async_options')
    add_async_options(parser)



# Generated at 2022-06-20 12:55:46.343257
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)



# Generated at 2022-06-20 12:55:47.669511
# Unit test for function add_vault_options
def test_add_vault_options():
    """ Unit test for function add_vault_options """
    arg_list = []
    utils.add_vault_options(arg_list)
    return arg_list


# Generated at 2022-06-20 12:55:50.266420
# Unit test for function add_async_options
def test_add_async_options():
    test_args = ['-P', '5', '-B', '30']
    parser = argparse.ArgumentParser(prog='ansible-test',
                                     formatter_class=SortingHelpFormatter)
    add_async_options(parser)
    r = parser.parse_args(test_args)
    assert r.poll_interval == 5
    assert r.seconds == 30


# Generated at 2022-06-20 12:55:52.339913
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    assert parser is not None



# Generated at 2022-06-20 12:55:55.313203
# Unit test for function add_runtask_options
def test_add_runtask_options():
  parser = argparse.ArgumentParser()
  add_runtask_options(parser)
  args = parser.parse_args(["-e var=value"])
  assert args.extra_vars == ['var=value']

# Generated at 2022-06-20 12:56:06.557888
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser(prog='Test')
    options = parser.parse_args(['--version'])
    assert options.verbosity is None
    options = parser.parse_args(['-V'])
    assert options.verbosity == 0
    options = parser.parse_args(['--quiet'])
    assert options.verbosity == 0



# Generated at 2022-06-20 12:56:17.692375
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(prog='test_add_runtask_options',
                                     formatter_class=SortingHelpFormatter,
                                     epilog="defaults to '/etc/ansible/hosts'",
                                     description="Test case for function 'add_runtask_options'")
    add_runtask_options(parser)
    # If no options, print help
    args = parser.parse_args([])
    # -e is multi-line options, so we need to specify more than one option
    args = parser.parse_args(['-e', 'name=test_add_runtask_options1', '-e', 'name2=test_add_runtask_options2'])

# Generated at 2022-06-20 12:56:25.319100
# Unit test for function add_verbosity_options
def test_add_verbosity_options():  # pylint: disable=too-many-statements
    parser = argparse.ArgumentParser(prog='ansible', conflict_handler='resolve')
    try:
        add_verbosity_options(parser)
    except:
        assert False, "test_add_verbosity_options() add_verbosity_options() run failed"

    # test verbose mode
    args = parser.parse_args(['-v'])
    assert args.verbosity == 1, 'test_add_verbosity_options() -v verbosity level failed'
    args = parser.parse_args(['-vv'])
    assert args.verbosity == 2, 'test_add_verbosity_options() -vv verbosity level failed'
    args = parser.parse_args(['-vvv'])

# Generated at 2022-06-20 12:56:36.634583
# Unit test for function add_verbosity_options
def test_add_verbosity_options():
    parser = create_base_parser('test_prog', '', 'Test program')
    add_verbosity_options(parser)
    # No options passed - should return nothing
    assert [] == parser.parse_args([])
    # One option passed - should return the default verbosity of 0
    assert 0 == parser.parse_args(['-v']).verbosity
    # Two option passed - should return the verbosity of 1
    assert 1 == parser.parse_args(['-vv']).verbosity
    # Three option passed - should return the verbosity of 2
    assert 2 == parser.parse_args(['-vvv']).verbosity
    # Four option passed - should return the verbosity of 3
    assert 3 == parser.parse_args(['-vvvv']).verbosity



# Generated at 2022-06-20 12:56:41.673610
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    help_text = 'help text'
    parser = argparse.ArgumentParser()
    parser.add_argument('--unknown', action=UnrecognizedArgument, help=help_text)
    try:
        parser.parse_args(['--unknown'])
        sys.exit(1)
    except SystemExit:
        pass



# Generated at 2022-06-20 12:56:50.017658
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    add_module_options(parser)
    args = parser.parse_args()
    assert args.module_path is None

    args = parser.parse_args(['-M', 'test.py'])
    assert args.module_path == ['test.py']

    args = parser.parse_args(['-M', 'test.py', '-M', 'test2.py'])
    assert args.module_path == ['test2.py', 'test.py']

    args = parser.parse_args(['-M', '/test.py:/test2.py'])
    assert args.module_path == ['/test2.py', '/test.py']


# Generated at 2022-06-20 12:57:00.401543
# Unit test for function version
def test_version():
    prog = 'VERSION'
    assert version(prog) == 'VERSION [core {0}]\n  config file = {1}\n  configured module search path = {2}\n  ansible python module location = {3}\n  ansible collection location = {4}\n  executable location = {5}\n  python version = {6}\n  jinja version = {7}\n  libyaml = {8}'.format(__version__,C.CONFIG_FILE,C.DEFAULT_MODULE_PATH,':'.join(ansible.__path__),':'.join(C.COLLECTIONS_PATHS),sys.argv[0],''.join(sys.version.splitlines()),j2_version,HAS_LIBYAML)

# Generated at 2022-06-20 12:57:03.606188
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    # tests that the default value is set correctly
    args = parser.parse_args(['-o'])
    assert args.one_line is True
    assert args.tree is None
    args = parser.parse_args(['-t', 'ansible_tree_directory'])
    assert args.tree == 'ansible_tree_directory'
    assert args.one_line is False



# Generated at 2022-06-20 12:57:07.385146
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    Needs to check if we can get these two functions integrate with each other.
    """
    parser = argparse.ArgumentParser()
    add_runas_options(parser)



# Generated at 2022-06-20 12:57:10.009942
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    av = AnsibleVersion(option_strings=['--version'])(
        parser=None, namespace=None, values=None, option_string=None
    )
    assert type(av) == None.__class__



# Generated at 2022-06-20 12:57:16.701882
# Unit test for function version
def test_version():
    assert version()



# Generated at 2022-06-20 12:57:18.909592
# Unit test for function add_async_options
def test_add_async_options():
    parser = create_base_parser(prog='ansible', usage='%(prog)s ...')
    add_async_options(parser)
    return parser


# Generated at 2022-06-20 12:57:28.407628
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    args = parser.parse_args(['--task-timeout', '60'])
    assert args.task_timeout == 60, "Unexpected task timeout %s" % args.task_timeout
    # Negative numbers should fail
    assert_raises(SystemExit, parser.parse_args, ['--task-timeout', '-1'])
    # Zero should fail
    assert_raises(SystemExit, parser.parse_args, ['--task-timeout', '0'])
    # Non-numbers should fail
    assert_raises(SystemExit, parser.parse_args, ['--task-timeout', 'moo'])



# Generated at 2022-06-20 12:57:34.193067
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    opts = parser.parse_args(args=[])
    assert opts.connection_password_file == C.CONNECTION_PASSWORD_FILE
    opts = parser.parse_args(args=['--connection-password-file', 'creds.txt'])
    assert opts.connection_password_file == 'creds.txt'



# Generated at 2022-06-20 12:57:45.652797
# Unit test for method __call__ of class UnrecognizedArgument
def test_UnrecognizedArgument___call__():
    # Input data for tests
    test_data = [
        ['-e'],
        ['--extra-vars'],
        ['-e', 'delegate_to=127.0.0.1,foo.bar=test']
    ]
    # Expected output data for tests
    expected_output = [
        'unrecognized arguments: -e',
        'unrecognized arguments: --extra-vars',
        'unrecognized arguments: -e'
    ]
    # class object to be tested
    cli_parser = argparse.ArgumentParser()
    cli_parser.add_argument('-e', '--extra-vars', action=UnrecognizedArgument)
    # Our Unit test

# Generated at 2022-06-20 12:57:48.362189
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args('--list-hosts -i hosts.ini -i inventory -l 127.0.0.1'.split())
    assert args.listhosts
    assert args.inventory == ['hosts.ini', 'inventory']
    assert args.subset == '127.0.0.1'
    assert not args.listtasks
    assert not args.listtags


# Generated at 2022-06-20 12:57:52.732602
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', help='version', action=AnsibleVersion)
    parsed_args = parser.parse_args()

    if parsed_args.version:
        AnsibleVersion()(parser, parsed_args, vars(parsed_args))


# Generated at 2022-06-20 12:57:56.742221
# Unit test for function create_base_parser
def test_create_base_parser():
    """
    Sanity check to ensure config base parser doesn't fail basic functionality
    """
    parser = create_base_parser(prog='test')
    args = parser.parse_args()
    assert args.version is False
    assert args.verbosity >= 0



# Generated at 2022-06-20 12:57:59.116899
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options.module_help = 'bootstrap-xs'
    args = parser.parse_args(['--force-handlers'])
    assert args.force_handlers


# Generated at 2022-06-20 12:58:01.416819
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = create_base_parser('ansible-testvault')
    add_vault_options(parser)
    parser.parse_args()


#
# Common Parser
#


# Generated at 2022-06-20 12:58:19.576713
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    from ansible.cli.arguments import base_parser
    from ansible.cli.arguments import option_helpers
    from ansible.utils.display import Display
    display = Display()
    parser = SortingHelpFormatter(base_parser, display)
    parser.add_argument('-n', '--name', action='store', help='a name')
    parser.add_argument('-f', '--file', action='store', help='a file')
    parser.add_argument('-d', '--directory', action='store', help='a directory')
    parser.add_argument('-x', '--xor', action='store', help='--option1 xor --option2')
    options = parser.parse_args(['-h'])
    assert options.help_option is True
    help_str = parser.format_

# Generated at 2022-06-20 12:58:22.258057
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    opt = parser.parse_args(['--private-key', 'key', '--user', 'user', '-c', 'connection', '-T', '10'])
    assert opt.private_key_file == 'key'
    assert opt.remote_user == 'user'
    assert opt.connection == 'connection'
    assert opt.timeout == 10



# Generated at 2022-06-20 12:58:29.411824
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    dc = PrependListAction("--test", "dest")
    assert dc.choices is None
    assert dc.default is None
    assert dc.dest == "dest"
    assert dc.metavar is None
    assert dc.option_strings == ["--test"]
    assert dc.required is False
    assert dc.type is None
    assert dc.help is None


# Generated at 2022-06-20 12:58:30.065668
# Unit test for function add_subset_options
def test_add_subset_options():
    assert add_subset_options(parser)



# Generated at 2022-06-20 12:58:34.179555
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'foo', 'bar')
    assert namespace.foo == 'bar'
    ensure_value(namespace, 'foo', 'baz')
    assert namespace.foo == 'bar'
    ensure_value(namespace, 'foo', None)
    assert namespace.foo == 'bar'



# Generated at 2022-06-20 12:58:38.373957
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    arguments = parser.parse_args(['-P', '5', '-B', '10'])
    assert arguments.poll_interval == 5
    assert arguments.seconds == 10


# Generated at 2022-06-20 12:58:42.387121
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    assert parser.get_default('poll_interval') == C.DEFAULT_POLL_INTERVAL
    assert parser.get_default('seconds') == 0



# Generated at 2022-06-20 12:58:46.286999
# Unit test for function add_inventory_options
def test_add_inventory_options():
    a = argparse.ArgumentParser(prog='test')
    add_inventory_options(a)
    assert '-i' in [x.option_strings[0] for x in a._actions]
    assert '--inventory' in [x.option_strings[0] for x in a._actions]
    assert '--inventory-file' in [x.option_strings[0] for x in a._actions]
    assert '--list-hosts' in [x.option_strings[0] for x in a._actions]
    assert '-l' in [x.option_strings[0] for x in a._actions]
    assert '--limit' in [x.option_strings[0] for x in a._actions]



# Generated at 2022-06-20 12:58:49.209499
# Unit test for function create_base_parser
def test_create_base_parser():
    """
    create_base_parser() returns an options parser for all ansible scripts
    """
    parser = create_base_parser('program_name')
    assert parser is not None


# Generated at 2022-06-20 12:58:53.590928
# Unit test for constructor of class UnrecognizedArgument
def test_UnrecognizedArgument():
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('-f', '--foo', action=UnrecognizedArgument)
        parser.parse_known_args(['-f'])
    except SystemExit:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-20 12:59:09.459977
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ansible-doc')
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'foo'])
    assert options.vault_ids[0] == 'foo'
    # multiple vault options
    options = parser.parse_args(['--vault-id', 'foo', '--vault-id', 'bar'])
    assert options.vault_ids[0] == 'foo'
    assert options.vault_ids[1] == 'bar'
    options = parser.parse_args(['--vault-password-file', '/path/to/foo', '--vault-password-file', '/path/to/bar'])

# Generated at 2022-06-20 12:59:20.215404
# Unit test for function unfrack_path
def test_unfrack_path():
    if 'ANSIBLE_CONFIG' in os.environ:
        del os.environ['ANSIBLE_CONFIG']
    # existing file
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
    # file does not exist
    assert unfrack_path()('/etc/ansible/ansible.notcfg') == '/etc/ansible/ansible.notcfg'
    # default file with no path separator
    assert unfrack_path()('ansible.cfg') == os.path.normpath(os.path.realpath(os.path.join(os.getcwd(), 'ansible.cfg')))
    # default file with path separator

# Generated at 2022-06-20 12:59:25.508673
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog="test")
    add_vault_options(parser)
    opts = parser.parse_args(['--vault-id', 'x', '--vault-password-file', 'a', '--vault-password-file', 'b', '--ask-vault-password'])
    assert opts.vault_ids == ['x']
    assert opts.vault_password_files == ['a', 'b']
    assert opts.ask_vault_pass



# Generated at 2022-06-20 12:59:37.799826
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    if sys.version_info < (2, 7):
        return

    from ansible.cli.argparser import AnsibleVersion

    # setup fixtures
    from io import StringIO

    ansible_version = '2.7.0'
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-playbook'

    # mocks the sys.exit method
    def mock_exit(self, status=0, message=None):
        assert status == 0
        print("mock_exit called with message %s" % message)
        raise SystemExit

    # mock sys.exit with a custom exit method that raises a SystemExit exception
    old_exit = sys.exit
    sys.exit = mock_exit
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

   

# Generated at 2022-06-20 12:59:40.959948
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()

# Generated at 2022-06-20 12:59:45.026201
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action=PrependListAction, metavar='VALUE')
    args = parser.parse_args(['--list foo', '--list bar'])
    assert args.list == ['bar', 'foo']


# Generated at 2022-06-20 12:59:53.213512
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    options = [
        argparse.Option(option_strings=['--foo'], action='store_true'),
        argparse.Option(option_strings=['--foo-bar'], action='store_true'),
        argparse.Option(option_strings=['--bar'], action='store_true'),
    ]
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    group = parser.add_argument_group('some group')
    group.add_argument('--foo', action='store_true')
    group.add_argument('--foo-bar', action='store_true')
    group.add_argument('--bar', action='store_true')
    sorted_options = sorted(options, key=operator.attrgetter('option_strings'))
    assert parser._get_optional_actions()

# Generated at 2022-06-20 13:00:02.907463
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class MockAction(argparse.Action):
        def __init__(self, option_strings, dest=argparse.SUPPRESS, default=argparse.SUPPRESS, help=None):
            super(MockAction, self).__init__(option_strings=option_strings, dest=dest, default=default, help=help)
        def __call__(self, parser, namespace, values, option_string=None):
            pass

    parser = argparse.ArgumentParser(description="Test for method add_arguments of class SortingHelpFormatter", usage=argparse.SUPPRESS, add_help=False, formatter_class=SortingHelpFormatter)
    parser.add_argument("--foo", help="Option foo", nargs='?', action=MockAction)

# Generated at 2022-06-20 13:00:06.438659
# Unit test for constructor of class AnsibleVersion
def test_AnsibleVersion():
    a = AnsibleVersion()
    assert getattr(a, '__call__')(None, None, None, None) is None



# Generated at 2022-06-20 13:00:16.203940
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    class MockParser():
        def __init__(self):
            self.arguments = []

        def error(self, message):
            self.arguments.append(message)

        def set_defaults(self, **kwargs):
            self.arguments.append(kwargs)

    class MockNamespace():
        def __init__(self):
            self.my_args = []

        def __getattr__(self, item):
            self.my_args.append(item)
            return self.my_args

        def __setattr__(self, key, value):
            self.my_args.append(key)
            self.my_args.append(value)

    # Test case 1: value of nargs is 0
    mockParser = MockParser()
    mockNamespace = MockNamespace()
    prependList

# Generated at 2022-06-20 13:00:29.142409
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    """Smoke test for method __call__ of class PrependListAction.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', nargs='+', action=PrependListAction)
    args = parser.parse_args(['--foo', '1', '--foo', '2'])
    assert(args.foo == ['2', '1'])



# Generated at 2022-06-20 13:00:30.899023
# Unit test for function add_async_options
def test_add_async_options():
    testparser = argparse.ArgumentParser()
    result = add_async_options(testparser)
    assert type(result) == argparse.ArgumentParser



# Generated at 2022-06-20 13:00:34.398351
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser("test_parser")
    add_inventory_options(parser)
    opt = parser.parse_args(["--list-hosts", "-i", "/test/inventory_file.yml", "-l", "all"])
    assert opt.listhosts == True
    assert opt.inventory[0] == "/test/inventory_file.yml"
    assert opt.subset == "all"


# Generated at 2022-06-20 13:00:39.141893
# Unit test for function create_base_parser
def test_create_base_parser():
    parser = create_base_parser("test_prog")
    assert 'version' in parser._actions[0].option_strings
    assert 'ansible-config' in parser._actions[1].option_strings
    assert 'ansible-vault' in parser._actions[2].option_strings


# Generated at 2022-06-20 13:00:40.287923
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    list(iter(parser._actions))


# Generated at 2022-06-20 13:00:42.824272
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    cliargs = ['--become', '--become-user', 'fred', '--become-method', 'sudo']
    options = parser.parse_args(cliargs)
    assert options.become == True
    assert options.become_user == 'fred'
    assert options.become_method == 'sudo'



# Generated at 2022-06-20 13:00:50.726531
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    foo = argparse.ArgumentParser(description='foo', formatter_class=SortingHelpFormatter)
    foo.add_argument('-d', '--def', dest='foo', action='store_const', const='def', default='abc',
                     help='foo help abc')
    foo.add_argument('-a', '--abc', dest='foo', action='store_const', const='abc', default='def',
                     help='foo help def')

    def_help_string = '  -d, --def    foo help abc'
    abc_help_string = '  -a, --abc    foo help def'
    lines = foo.format_help().split('\n')

    # Test that help lines are in lexicographical order, accounting for help and usage strings

# Generated at 2022-06-20 13:01:00.412454
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert "~/.ansible/roles" == maybe_unfrack_path("~")("~/.ansible/roles")
    assert "~/.ansible/roles" == maybe_unfrack_path("~")("~/.ansible/roles")
    assert "~/.ansible/roles" == maybe_unfrack_path("~")("~/.ansible/roles")

    assert "~/.ansible/roles" == maybe_unfrack_path("~/")("~/.ansible/roles")
    assert "~/.ansible/roles" == maybe_unfrack_path("~/")("~/.ansible/roles")
    assert "~/.ansible/roles" == maybe_unfrack_path("~/")("~/.ansible/roles")


# Generated at 2022-06-20 13:01:05.710718
# Unit test for function add_module_options
def test_add_module_options():
    # First create a parser with a description
    desc = 'test description'
    parser = argparse.ArgumentParser(description=desc)

    # Call add_module_options on the parser
    add_module_options(parser)

    # Test if a -M argument has been added to the parser
    # The -M argument should have the dest 'module_path'
    assert parser._option_string_actions['-M'].dest == 'module_path'



# Generated at 2022-06-20 13:01:09.141776
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    arguments = parser.parse_args([])
    assert arguments.task_timeout == C.TASK_TIMEOUT

