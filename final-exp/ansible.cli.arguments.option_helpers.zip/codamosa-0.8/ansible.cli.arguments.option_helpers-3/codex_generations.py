

# Generated at 2022-06-10 21:59:07.321805
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args(['-b', '-vv'])
    assert options.become == True
    assert options.become_method == "sudo"
    assert options.become_user == "root"
    assert options.verbosity == 2


# Generated at 2022-06-10 21:59:12.165674
# Unit test for function add_inventory_options
def test_add_inventory_options():
    '''test for function add_inventory_options
    '''
    test_cases = [
        {
            "stdout": "Usage: ansible-playbook [options] playbook.yml\n\nPlaybook Options:\n  -i INVENTORY, --inventory INVENTORY, --inventory-file INVENTORY\n                        specify inventory host path or comma separated host list.\n                        --inventory-file is deprecated\n  --list-hosts           outputs a list of matching hosts; does not execute anything else\n  -l SUBSET, --limit SUBSET\n                        further limit selected hosts to an additional pattern\n\nOptions: -h, --help            show this help message and exit\n",
        }
    ]

# Generated at 2022-06-10 21:59:21.352121
# Unit test for function add_module_options
def test_add_module_options():
    from ansible import constants as C
    args = parse_args(['--module-path','/etc/ansible/modules',
                       '--module-path=/usr/share/ansible/modules'],
                      ['-M','/etc/ansible/modules'],
                      None)
    assert args.module_path == [unfrack_path()(x) for x in
                                ['/etc/ansible/modules', '/usr/share/ansible/modules', C.DEFAULT_MODULE_PATH] if x]



# Generated at 2022-06-10 21:59:29.757127
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    (args, args2) = parser.parse_known_args(["-C"])
    assert args.check is True
    (args, args2) = parser.parse_known_args(["--syntax-check"])
    assert args.syntax is True
    (args, args2) = parser.parse_known_args(["-D"])
    assert args.diff is True


# Generated at 2022-06-10 21:59:40.248109
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(description="test options")
    add_async_options(parser)
    input_args = ["-B", "10"]
    args = parser.parse_args(input_args)
    assert args.seconds == 10, "set seconds right"
    assert args.poll_interval == C.DEFAULT_POLL_INTERVAL, "set poll_interval right"
    input_args = ["-B", "10", "-P", "10"]
    args = parser.parse_args(input_args)
    assert args.seconds == 10, "set seconds right"
    assert args.poll_interval == 10, "set poll_interval right"
    input_args = ["-P", "10"]
    args = parser.parse_args(input_args)

# Generated at 2022-06-10 21:59:42.869314
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)


# Generated at 2022-06-10 21:59:46.059392
# Unit test for function ensure_value
def test_ensure_value():
    class namespace:
        pass
    ensure_value(namespace(), 'a', 'b')
    assert namespace.a == 'b'
    namespace.a = 'c'
    ensure_value(namespace(), 'a', 'b')
    assert namespace.a == 'c'



# Generated at 2022-06-10 21:59:50.757086
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    (args, leftover) = parser.parse_known_args()


#
# Functions to handle options common to multiple commands
#


# Generated at 2022-06-10 21:59:54.815721
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("~")("~/ansible") == "~/ansible"
    assert maybe_unfrack_path("~")("/etc/ansible") == "/etc/ansible"
    assert maybe_unfrack_path("$")("$PATH") == "$PATH"



# Generated at 2022-06-10 22:00:06.870903
# Unit test for function add_check_options
def test_add_check_options():
    """
    Test whether the check options are recognized properly by the parser, and
    that a non-zero exit status is returned.
    """
    parser = argparse.ArgumentParser(
        prog = 'ansible',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_check_options(parser)
    options = parser.parse_args([])
    assert options.check == False, "unexpected default boolean value"
    assert options.syntax == False, "unexpected default boolean value"
    assert options.diff == False, "unexpected default boolean value"

    assert parser.parse_args(["--check"]).check == True, "argument not recognized"
    assert parser.parse_args(["--syntax-check"]).syntax == True, "argument not recognized"

# Generated at 2022-06-10 22:00:19.463326
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    a_path_test = '/home/user/ansible.cfg'
    a_beacon = '@'
    result = maybe_unfrack_path(beacon=a_beacon)(a_path_test)
    assert result.endswith(a_path_test)

# Generated at 2022-06-10 22:00:28.630312
# Unit test for function add_connect_options
def test_add_connect_options():

    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('---test', default='test', dest='test')
    add_connect_options(test_parser)
    assert set(['-u', '--user', '-c', '-T', '--ssh-common-args', '--sftp-extra-args', '--scp-extra-args', '--ssh-extra-args', '-k', '--ask-pass', '--connection-password-file']) == set(test_parser._option_string_actions.keys())



# Generated at 2022-06-10 22:00:32.182998
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    parser.add_argument('--playbook-dir', default=C.config.get_config_value('PLAYBOOK_DIR'), dest='basedir', action='store',
                        help="Since this tool does not use playbooks, use this as a substitute playbook directory."
                             "This sets the relative path for many features including roles/ group_vars/ etc.",
                        type=unfrack_path())
    
    
    
    
    



# Generated at 2022-06-10 22:00:36.983303
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parse_args(['-o', '-t', 'test'])
    assert args.one_line is True
    assert args.tree == 'test'



# Generated at 2022-06-10 22:00:42.410286
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """Unit test for constructor of class PrependListAction"""
    action = PrependListAction(
        option_strings=['-i', '--include'],
        dest='include_values',
        nargs=1,
        default=[],
        help='Add directory to playbook execution path'
    )



# Generated at 2022-06-10 22:00:44.194406
# Unit test for function add_subset_options
def test_add_subset_options():
    argument_list = ["-t", "--tags", "--skip-tags"]
    args, unknown_args = create_parser().parse_known_args(argument_list)
    assert args.tags is not None
    assert args.skip_tags is not None

# Generated at 2022-06-10 22:00:47.502712
# Unit test for function add_connect_options
def test_add_connect_options():
    # TODO: use object...
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    return parser

# Generated at 2022-06-10 22:00:53.982475
# Unit test for function add_meta_options
def test_add_meta_options():
    # pylint: disable=invalid-name
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    options, args = parser.parse_known_args(['--force-handlers', '--flush-cache'])
    assert options.force_handlers
    assert options.flush_cache

    options, args = parser.parse_known_args([])
    assert not options.force_handlers
    assert not options.flush_cache

# End unit tests



# Generated at 2022-06-10 22:00:59.016887
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args1 = parser.parse_args("--flush-cache --force-handlers".split())
    assert(args1.flush_cache == True)
    assert(args1.force_handlers==True)


# Generated at 2022-06-10 22:01:05.246661
# Unit test for function version
def test_version():
    v = version()
    assert v.startswith('2.2')
    assert 'config file = ' in v
    assert 'configured module search path = ' in v
    assert 'ansible python module location = ' in v
    assert 'executable location =' in v
    assert 'python version = ' in v
    assert 'jinja version = ' in v
    assert 'libyaml = ' in v

# Generated at 2022-06-10 22:01:12.058377
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-10 22:01:20.716700
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~/x') == '~/x'
    assert maybe_unfrack_path('~')('~/x/y') == '~/x/y'
    assert maybe_unfrack_path('~')('~/x/y/z/') == '~/x/y/z/'
    assert maybe_unfrack_path('~')('~/x/y/z') == '~/x/y/z'
    assert maybe_unfrack_path('~')('~z') == '~z'



# Generated at 2022-06-10 22:01:22.683129
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'webservers', '--skip-tags', 'databases'])
    assert args.tags == ['webservers']
    assert args.skip_tags == ['databases']



# Generated at 2022-06-10 22:01:33.978099
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    assert( maybe_unfrack_path('@')('@/etc/ansible') == '@/etc/ansible' )
    assert( maybe_unfrack_path('@')('@/etc/ansible/') == '@/etc/ansible' )
    assert( maybe_unfrack_path('@')('@@/etc/ansible') == '@@/etc/ansible' )
    assert( maybe_unfrack_path('@')('@@/etc/ansible/') == '@@/etc/ansible' )

    assert( maybe_unfrack_path('@@')('@@/etc/ansible') == '@@/etc/ansible' )

# Generated at 2022-06-10 22:01:37.853470
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    options, args = parser.parse_known_args(["--playbook-dir", "test_value"])
    assert options.basedir == os.path.abspath('test_value')

# Generated at 2022-06-10 22:01:47.918043
# Unit test for function add_subset_options
def test_add_subset_options():
    kwargs = _options_to_kwargs(add_subset_options)
    assert 'tags' in kwargs['tags'].dest
    assert 'skip-tags' in kwargs['skip-tags'].dest
    assert kwargs['tags'].action == 'append'
    assert kwargs['skip-tags'].action == 'append'
    assert kwargs['tags'].default == C.TAGS_RUN
    assert kwargs['skip-tags'].default == C.TAGS_SKIP
    assert kwargs['tags'].help.startswith('only run plays and tasks tagged with these values')
    assert kwargs['skip-tags'].help.startswith('only run plays and tasks whose tags do not match these values')



# Generated at 2022-06-10 22:01:59.421233
# Unit test for function add_subset_options
def test_add_subset_options():
    # Test for valid input, whether it can be returned as expected
    parser = argparse.ArgumentParser(description='test parser')
    add_subset_options(parser)
    # command line opts
    args = ["-t", "test_tag",
            "--skip-tags", "skip_tag1",
            "--skip-tags", "skip_tag2"]
    result = vars(parser.parse_args(args))
    # expect result
    expect_ans = {'tags': ['test_tag'], 'skip_tags': ['skip_tag1', 'skip_tag2']}
    # assert test result
    assert result == expect_ans

    #
    # Test for invalid input, whether it can exit with error
    #
    parser = argparse.ArgumentParser(description='test parser')
    add_subset

# Generated at 2022-06-10 22:02:06.037570
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert '~/' == maybe_unfrack_path('~')('~/')
    assert '~/' == maybe_unfrack_path('~')('~/')
    assert '~/' == maybe_unfrack_path('~')('~/')
    assert '/tmp/' == maybe_unfrack_path('~')('/tmp/')
    assert '/tmp' == maybe_unfrack_path('~')('/tmp')
    assert './' == maybe_unfrack_path('~')('./')
    assert './' == maybe_unfrack_path('~')('./')



# Generated at 2022-06-10 22:02:11.252860
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible'
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert getattr(args, 'version', None) is None
    assert args.version == None
    # TODO: check if the method parser.exit() was properly called



# Generated at 2022-06-10 22:02:17.697536
# Unit test for function add_subset_options
def test_add_subset_options():
    """
    Test add_subset_options
    """
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
    )
    add_subset_options(parser)
    parser.parse_args(['-t', 'tag1', '--skip-tags', 'skip1', '--skip-tags', 'skip2'])



# Generated at 2022-06-10 22:02:29.988953
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path('/foo:/bar')('/bar:/foo') == ['/foo', '/bar']
    assert unfrack_path('/foo:/bar')('/bar/./foo') == ['/foo', '/bar']
    assert unfrack_path(False)('/bar') == '/bar'
    assert unfrack_path(False)('/bar/./foo') == '/bar/foo'
    assert unfrack_path(False)('-') == '-'



# Generated at 2022-06-10 22:02:42.820622
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-c', action="store_true", default=False, dest='foo', help="Enable foo")
    parser.add_argument('--first', action="store_true", default=True, dest='bar', help="Enable bar")
    testargs = ["-h"]
    with open(os.devnull, 'wb') as f:
        try:
            parser.print_help(file=f)
            parser.parse_args(testargs)
        except SystemExit as e:
            # sys.exit(status) if status is zero or None, sys.exit() otherwise.
            # When sys.exit() is called,  it raises SystemExit exception with
            # status argument.
            if e.code == 0:
                pass

# Generated at 2022-06-10 22:02:54.093122
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("dir")("dir/path/../ansible") == 'dir/path/../ansible'
    assert maybe_unfrack_path("dir")("dir./path/../ansible") == 'dir/path/../ansible'
    assert maybe_unfrack_path("dir")("dir/path/../ansible/") == 'dir/path/../ansible'
    assert maybe_unfrack_path("dir")("dir/path/../") == 'dir/path/../'
    assert maybe_unfrack_path("dir")("dir/path/..///") == 'dir/path/..///'
    assert maybe_unfrack_path("dir")("dir/path\\../") == 'dir/path\\../'

# Generated at 2022-06-10 22:03:05.280849
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('../foo') == unfrackpath('../foo')
    assert unfrack_path(pathsep=True)('../foo:../bar') == [unfrackpath('../foo'), unfrackpath('../bar')]
    assert unfrack_path(pathsep=True)('../foo:') == [unfrackpath('../foo')]
    assert unfrack_path(pathsep=True)('../foo') == [unfrackpath('../foo')]
    assert unfrack_path(pathsep=True)('../foo:-../bar') == [unfrackpath('../foo'), unfrackpath('-../bar')]

# Generated at 2022-06-10 22:03:14.739866
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # argparse.ArgumentParser.__init__(self, formatter_class=SortingHelpFormatter)
    parser = argparse.ArgumentParser()
    # argparse.ArgumentParser.add_argument(self, "--version", action='version', version=ansible_version, help="show program's version number and exit")
    parser.add_argument("--version", action=AnsibleVersion, help="show program's version number and exit")
    # argparse.ArgumentParser.parse_args(self, args=None, namespace=None)
    parser.parse_args(["--version"])



# Generated at 2022-06-10 22:03:15.550806
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    pass


# Generated at 2022-06-10 22:03:21.114259
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path("/tmp:/etc")("/tmp:/etc") == ['/tmp', '/etc']
    assert unfrack_path("/tmp:/etc")("/path/to/dir") == '/path/to/dir'
    assert unfrack_path("/tmp:/etc")("-") == '-'



# Generated at 2022-06-10 22:03:25.320560
# Unit test for function add_module_options
def test_add_module_options():
    from units.compat.mock import patch, MagicMock, call
    from tempfile import gettempdir
    from ansible.cli.adhoc import AdHocCLI as cls
    from ansible.config.manager import ConfigManager
    from ansible.config.module_finder import ModuleFinder
    c = ConfigManager()
    c.DEFAULT_MODULE_PATH = ['a', 'b']
    c.get_configuration_definition = MagicMock(return_value={'default': ''})
    m = ModuleFinder()
    m.module_paths = ['x', 'y']
    m.get_module_path = MagicMock(return_value='')

# Generated at 2022-06-10 22:03:32.483429
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + os.path.realpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@/home/user/../me') == '@' + os.path.realpath('/home/me')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'


# Generated at 2022-06-10 22:03:45.738406
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # prepare arguments
    class _Action(argparse.Action):
        def __init__(self, option_strings, dest, nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None):
            argparse.Action.__init__(self, option_strings=option_strings, dest=dest, nargs=nargs, const=const, default=default, type=type, choices=choices, required=required, help=help, metavar=metavar)


# Generated at 2022-06-10 22:03:52.317271
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(description='Ansible Options Parser')
    add_module_options(parser)
    assert parser.parse_args(['-M','/home/abcd/test'])


# Generated at 2022-06-10 22:03:53.952979
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # No test written for this method, yet
    return 0

# Generated at 2022-06-10 22:04:02.854577
# Unit test for function add_module_options
def test_add_module_options():
    parser = Mock()
    add_module_options(parser)
    assert parser.add_argument.call_count == 1
    assert parser.add_argument.call_args_list[0][0] == ('-M', '--module-path')
    assert parser.add_argument.call_args_list[0][1]['dest'] == 'module_path'
    assert parser.add_argument.call_args_list[0][1]['default'] == None
    assert parser.add_argument.call_args_list[0][1]['type'] == unfrack_path(pathsep=True)
    assert parser.add_argument.call_args_list[0][1]['action'] == PrependListAction


# Generated at 2022-06-10 22:04:10.247671
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()(None) == None
    assert unfrack_path(pathsep=True)(None) == None
    assert unfrack_path()('.') == os.path.abspath('.')
    assert unfrack_path(pathsep=True)('{0}/bar:{0}/baz'.format(os.getcwd())) == [os.path.abspath('bar'), os.path.abspath('baz')]


# Generated at 2022-06-10 22:04:15.462729
# Unit test for function unfrack_path
def test_unfrack_path():
    os.environ['HOME'] = '/home/test'
    assert unfrack_path('~/test') == '/home/test/test'
    assert unfrack_path(pathsep=True)('~/test:/home/rick/test') == ['/home/test/test', '/home/rick/test']
    del os.environ['HOME']


# Generated at 2022-06-10 22:04:16.069086
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass



# Generated at 2022-06-10 22:04:21.110449
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-d')
    parser.add_argument('-c')
    options = parser.parse_args([])
    help = parser.format_help()
    assert help.find('-a') < help.find('-b') < help.find('-c') < help.find('-d')

#
# Basic building blocks
#

# Generated at 2022-06-10 22:04:28.650861
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)("~/foo") == os.path.expanduser("~") + "/foo"
    test_path = "~/foo" + os.pathsep + "~/bar"
    assert unfrack_path(pathsep=True)(test_path) == [os.path.expanduser("~") + "/foo", os.path.expanduser("~") + "/bar"]



# Generated at 2022-06-10 22:04:33.877248
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # GIVEN
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    # WHEN
    given_args = parser.parse_args(['--foo', 'bar'])
    # THEN
    assert given_args.foo == ['bar']



# Generated at 2022-06-10 22:04:46.107838
# Unit test for function version
def test_version():
    import ansible
    import ansible.constants as C
    import sys
    import os
    import os.path
    import time

# Generated at 2022-06-10 22:04:54.772849
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/test') == '@' + unfrackpath('/test')
    assert maybe_unfrack_path('@')('@test') == '@test'


# Generated at 2022-06-10 22:05:04.901592
# Unit test for function unfrack_path
def test_unfrack_path():
    value = '/this/is/a/test/:value' # linux style path separator
    value2 = '/another/path/:/and/yet/another/one/' # multiple path separators
    value3 = '/and/yet/more/one'
    value4 = '-TMPFILE'
    value5 = '/one/' + os.path.sep + '/two'

    assert unfrack_path()(value) == value.split(':')
    assert unfrack_path()(value2) == value2.split(':')
    assert unfrack_path()(value3) == value3
    assert unfrack_path()(value4) == value4
    assert unfrack_path()(value5) == value5

    assert unfrack_path(pathsep=True)(value) == value.split(':')
   

# Generated at 2022-06-10 22:05:05.747399
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass



# Generated at 2022-06-10 22:05:18.515336
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    paths = ['./roles', 'ansible/roles']
    pathextra = []
    for path in paths:
        pathextra.append(maybe_unfrack_path('.')(path))
    assert pathextra == ['./roles', 'ansible/roles'], 'maybe_unfrack_path failed with .-relative paths'
    pathextra = []
    for path in paths:
        pathextra.append(maybe_unfrack_path('~')(path))
    assert pathextra == [os.path.expanduser('~') + '/roles', os.path.expanduser('~') + '/ansible/roles'], 'maybe_unfrack_path failed with ~-relative paths'



# Generated at 2022-06-10 22:05:29.262544
# Unit test for function unfrack_path
def test_unfrack_path():
    import os
    from ansible.release import __version__

    assert unfrack_path(pathsep=False)("") == ""
    assert unfrack_path(pathsep=False)("/") == "/"
    assert unfrack_path(pathsep=False)("foo") == "foo"
    assert unfrack_path(pathsep=False)("foo/bar") == "foo/bar"
    assert unfrack_path(pathsep=False)("foo/bar/baz") == "foo/bar/baz"
    assert unfrack_path(pathsep=False)("./foo") == "./foo"
    assert unfrack_path(pathsep=False)("../foo") == "../foo"

# Generated at 2022-06-10 22:05:34.775385
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """Assert that a string is returned that represents a file path in a valid Ansible location"""
    from ansible.constants import DEFAULT_ROLES_PATH
    assert maybe_unfrack_path('@')('@/test_roles') == '@' + DEFAULT_ROLES_PATH + '/test_roles'



# Generated at 2022-06-10 22:05:44.303071
# Unit test for function ensure_value
def test_ensure_value():
    class namespace:
        pass
    setattr(namespace, 'attr', None)
    assert ensure_value(namespace, 'attr', "value") == "value"
    assert getattr(namespace, 'attr') == "value"
    setattr(namespace, 'attr', "orig_value")
    assert ensure_value(namespace, 'attr', "value") == "orig_value"
    assert getattr(namespace, 'attr') == "orig_value"
    delattr(namespace, 'attr')
    assert ensure_value(namespace, 'attr', "value") == "value"
    assert getattr(namespace, 'attr') == "value"
    return True

#
# Public API function
#


# Generated at 2022-06-10 22:05:55.944632
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert '@/etc/ansible/hosts' == maybe_unfrack_path('@')('@./ansible/hosts')
    assert '@./ansible/hosts' == maybe_unfrack_path('@')('@./ansible/hosts')



# Generated at 2022-06-10 22:06:04.946215
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    val1 = 'a/b/c'
    val2 = '~/a/foo'
    val3 = '@@bar'

    assert maybe_unfrack_path('@')(val1) == val1
    assert maybe_unfrack_path('@')(val2) == '~/a/foo'
    assert maybe_unfrack_path('@')(val3) == '@@' + unfrackpath(val3[1:])



# Generated at 2022-06-10 22:06:11.545018
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('^')('^/tmp/foo') == '^/tmp/foo'
    assert maybe_unfrack_path('^')('^t/ansible') == '^t/ansible'
    assert maybe_unfrack_path('^')('t/ansible') == 't/ansible'
    assert maybe_unfrack_path('^')('^/tmp/foo') == '^/tmp/foo'
    assert maybe_unfrack_path('^')('^t/ansible') == '^t/ansible'



# Generated at 2022-06-10 22:06:29.525365
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument("-a")
    parser.add_argument("-foo")
    parser.add_argument("-bar")
    parser.add_argument("-baaz")
    parser.add_argument("-bazz")
    parser.add_argument("-B")
    parser.add_argument("-C")
    parser.add_argument("-D")
    parser.add_argument("-E")
    parser.add_argument("-F")
    parser.add_argument("-G")
    parser.add_argument("-H")
    parser.add_argument("-I")
    parser.add_argument("-J")
    parser.add_argument("-K")
    parser.add_argument("-L")
    parser.add_argument("-M")

# Generated at 2022-06-10 22:06:32.797330
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@test") == "@test"
    assert maybe_unfrack_path("@")("@/test") == "@/test"
    assert maybe_unfrack_path("@")("/test") == "/test"

#
# Callbacks to validate and normalize Positional options
#

# Generated at 2022-06-10 22:06:35.612594
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/usr/local/bin:/usr/bin:/bin') == ['/usr/local/bin', '/usr/bin', '/usr/bin/python']
    assert unfrack_path(True)('/usr/local/bin:/usr/bin:/bin') == ['/usr/local/bin', '/usr/bin', '/bin']


# Generated at 2022-06-10 22:06:39.860018
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test = AnsibleVersion()
    parser = argparse.ArgumentParser()
    parser.prog = sys.argv[0]
    test_args = []
    namespace = argparse.Namespace()
    test_values = []
    test.__call__(parser, namespace, test_values)



# Generated at 2022-06-10 22:06:44.136852
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('-r')('-r/abcd') == '-r' + os.path.abspath('/abcd')
    assert maybe_unfrack_path('-r')('/abcd') == '/abcd'


# Generated at 2022-06-10 22:06:48.619605
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo/bar') == unfrackpath('foo/bar')
    assert unfrack_path()('foo/bar/') == unfrackpath('foo/bar')
    assert unfrack_path()('/foo/bar') == unfrackpath('/foo/bar')
    assert unfrack_path()('$HOME/foo/bar') == unfrackpath('$HOME/foo/bar')



# Generated at 2022-06-10 22:06:56.661343
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@pecan') == '@' + unfrackpath('pecan')
    assert maybe_unfrack_path('@')('@pecan/pie') == '@' + unfrackpath('pecan/pie')
    assert maybe_unfrack_path('@')('@/pecan') == '@' + unfrackpath('/pecan')
    assert maybe_unfrack_path('@')('@./pecan') == '@./pecan'
    assert maybe_unfrack_path('@')('@') == '@'


# Generated at 2022-06-10 22:07:03.753478
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    '''
    :case 1: Check with Ansible version 2.6.3
    :expected result: should print the ansible version number
    '''
    class Namespace:
        program = "test_program"
    namespace = Namespace()
    values = ""
    option_string = None
    parser = argparse.ArgumentParser()
    ansibleversion = AnsibleVersion()
    ansibleversion(parser, namespace, values, option_string)
    assert True



# Generated at 2022-06-10 22:07:11.157180
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action=PrependListAction)
    args = parser.parse_args(['--list', 'val1', 'val2'])
    assert args.list == ['val1', 'val2']
    args = parser.parse_args(['--list', 'val1', '--list', 'val2'])
    assert args.list == ['val2', 'val1']



# Generated at 2022-06-10 22:07:18.311233
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = '~'
    try:
        unfrack_path = os.path.expanduser
    except:
        unfrack_path = str
    # Ensure it doesn't modify paths that don't start with the beacon
    assert maybe_unfrack_path(beacon)('asdf') == 'asdf'
    # Ensure it calls unfrack_path on paths that start with the beacon
    assert maybe_unfrack_path(beacon)('~/asdf') == beacon + unfrack_path('~/asdf')[1:]


# Generated at 2022-06-10 22:07:59.478125
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    if C.DEFAULT_LOG_PATH.startswith(C.DEFAULT_LOCAL_TMP):
        assert maybe_unfrack_path(C.DEFAULT_LOCAL_TMP)('/tmp/ansible.log') == '/private/tmp/ansible.log'
    else:
        assert maybe_unfrack_path(C.DEFAULT_LOCAL_TMP)('/tmp/ansible.log') == '/tmp/ansible.log'

#
# Special purpose Options
#

# Generated at 2022-06-10 22:08:04.105517
# Unit test for function version
def test_version():
    assert version() == "2.4.0.0 (core 2.4.0.0)\n  config file = /home/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  executable location = ./bin/ansible\n  python version = 2.7.14 (default, Dec 10 2017, 15:05:25) \n[GCC 5.4.1 20160904]]\n  jinja version = 2.8\n  libyaml = 0"

# Generated at 2022-06-10 22:08:13.548924
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('a.py') == unfrackpath('a.py')
    assert unfrack_path(pathsep=True)('/a.py') == [unfrackpath('/a.py')]
    assert unfrack_path(pathsep=True)('/a.py:/b.py') == [unfrackpath('/a.py'), unfrackpath('/b.py')]
    assert unfrack_path(pathsep=True)('/a.py::/b.py') == [unfrackpath('/a.py'), None, unfrackpath('/b.py')]
    assert unfrack_path(pathsep=True)('/a.py:::/b.py') == [unfrackpath('/a.py'), None, None, unfrackpath('/b.py')]