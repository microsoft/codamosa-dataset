

# Generated at 2022-06-10 21:59:07.814306
# Unit test for function add_runas_options
def test_add_runas_options():
    class MockOptions(object):
        def __init__(self, become_user, become_method, become, become_pass):
            self.become_user = become_user
            self.become_method = become_method
            self.become = become
            self.become_pass = become_pass

    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = MockOptions(None, None, False, False)
    parser.parse_args('-b --become-method sudo --become-user root --ask-become-pass'.split(), options)
    assert options.become_user == 'root', options.become_user
    assert options.become_method == 'sudo', options.become_method
    assert options.become, options.become
    assert options

# Generated at 2022-06-10 21:59:09.197517
# Unit test for function add_connect_options
def test_add_connect_options():
    assert add_connect_options



# Generated at 2022-06-10 21:59:21.896469
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = runas_options(argparse.ArgumentParser(prog='ansible'))
    assert 'Privilege Escalation Options' in parser.format_help()
    assert '-b' in parser.format_help()
    assert '--become' in parser.format_help()
    assert '--become-method' in parser.format_help()
    assert '--become-user' in parser.format_help()

    runas_prompt_group = parser._action_groups[4]
    assert 'Password Prompt Options' in parser.format_help()
    assert '--ask-become-pass' in parser.format_help()
    assert '--ask-vault-pass' in runas_prompt_group.format_help()
    assert '--vault-password-file' in runas_prompt_

# Generated at 2022-06-10 21:59:24.799828
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    # parser.print_help()



# Generated at 2022-06-10 21:59:34.939359
# Unit test for function add_vault_options
def test_add_vault_options():
    from ansible.cli.help import VaultAction
    from ansible.errors import AnsibleError
    # test vault password file
    parser = argparse.ArgumentParser(prog='ansible')
    add_vault_options(parser)
    # test empty
    args = parser.parse_args([])
    assert hasattr(args, 'vault_password_files')
    assert args.vault_password_files is not None
    assert args.vault_password_files == []
    # test encrypted file
    vault_action = VaultAction('--vault-password-file', dest='vault_password_files',
                               help="vault password file", type=unfrack_path(), action='append')
    args = parser.parse_args([])
    vault_action(parser, args, "_parser")
    vault_file

# Generated at 2022-06-10 21:59:37.112360
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('!')('!helloworld') == '!%s/hello/world' % to_native(os.path.abspath('.'))



# Generated at 2022-06-10 21:59:40.269716
# Unit test for function version
def test_version():
    print(version())



# Generated at 2022-06-10 21:59:52.713910
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    opt = "--opt1"
    val = 1
    parser = argparse.ArgumentParser()
    parser.add_argument(opt, action=PrependListAction, type=int)
    ns = parser.parse_args([opt, val])
    assert getattr(ns, "opt1") == [val]

    nv = 2
    ns = parser.parse_args([opt, val, opt, nv])
    assert getattr(ns, "opt1") == [nv, val]

    # Make sure that we don't append, but instead prepend
    parser.add_argument(opt, action="append", type=int)
    ns = parser.parse_args([opt, val, opt, nv])
    assert getattr(ns, "opt1") == [val, nv]



# Generated at 2022-06-10 21:59:57.911532
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)("ansible/tests") == unfrackpath("ansible/tests")
    assert unfrack_path(pathsep=False)("-") == "-"
    assert unfrack_path(pathsep=True)("ansible/tests/playbooks:test") == [unfrackpath("ansible/tests/playbooks"), unfrackpath("test")]



# Generated at 2022-06-10 22:00:01.721328
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(description='Test add_runas_options')
    add_runas_options(parser)
    add_runas_prompt_options(parser)



# Generated at 2022-06-10 22:00:42.762890
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.utils.path import unfrackpath
    # Test with path separator
    path_list = ["$HOME/abc", "/etc/xyz", "$HOME/def/"]
    result = unfrack_path(True)(os.pathsep.join(path_list))
    assert result == [unfrackpath(x) for x in path_list]

    # Test without path separator
    result = unfrack_path()("~/test")
    assert result == unfrackpath("~/test")

    # Test with empty path
    result = unfrack_path()("")
    assert result == unfrackpath("")

#
# Special purpose OptionParser overrides
#

# Generated at 2022-06-10 22:00:50.974724
# Unit test for function unfrack_path
def test_unfrack_path():
    os.environ['ANSIBLE_CONFIG'] = "a"
    os.environ['ANSIBLE_CONFIG_FILE'] = "b"
    os.environ['ANSIBLE_CONFIG_DIR'] = "c"
    test_list = [
        ["a/b/c", "a/b/c"],
        ["~/a/b/c", "/home/test/a/b/c"],
        ["$ANSIBLE_CONFIG", "a"],
        ["$ANSIBLE_CONFIG_FILE", "b"],
        ["$ANSIBLE_CONFIG_DIR", "c"],
        ["a:b:c", ["a", "b", "c"]],
    ]


# Generated at 2022-06-10 22:00:57.571753
# Unit test for function unfrack_path
def test_unfrack_path():
    cwd = os.getcwd()
    # test with a list of fracked paths
    inpaths = ['~', os.path.join('~', 'this', 'is', 'fracked'), '~whoknowswherethiscomesfrom', os.path.join('.')]
    outpaths = unfrack_path(pathsep=True)(os.pathsep.join(inpaths))
    assert len(outpaths) == 4
    assert outpaths[0] == os.path.expanduser(inpaths[0])
    assert outpaths[1] == os.path.expanduser(inpaths[1])
    assert outpaths[2] == os.path.expanduser(inpaths[2])

# Generated at 2022-06-10 22:01:04.831927
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test path normalization (run in the base directory to avoid problems
    # with '..').
    for path in [
        './foo',
        'foo/bar',
        'foo/bar/',
        'foo/bar/.',
        './foo/bar',
        'foo/../foo/bar',
    ]:
        normalized = unfrackpath(path)
        assert normalized == 'foo/bar'



# Generated at 2022-06-10 22:01:07.259023
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['--extra-vars', '@test_extra_vars.yml', '--extra-vars', '@test_extra_vars.json'])
    assert args.extra_vars == ['test_extra_vars.yml', 'test_extra_vars.json']



# Generated at 2022-06-10 22:01:13.680303
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    '''
    PrependListAction class name changed to PrependListAction (camel case)
    to avoid conflicts with the original append action class
    '''
    args = ['--foo']
    opts = {'foo': ['bar']}
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.parse_args(args, namespace=opts)
    assert opts['foo'] == ['bar']



# Generated at 2022-06-10 22:01:20.445172
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    optparse = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    optparse.add_argument('-z')
    optparse.add_argument('--bar')
    optparse.add_argument('--foo')
    parsed = optparse.parse_args([])
    usage = optparse.format_usage()
    assert usage == 'usage: [ -z --bar --foo ]\n'


# Generated at 2022-06-10 22:01:27.360866
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test 1
    result1 = unfrack_path(pathsep=False)('./file')
    true_result1 = './file'
    if result1 == true_result1:
        print('Test 1 passed')
    else:
        print('Test 1 failed')
        print('Exp: %s, Result %s' % (true_result1, result1))

    # Test 2
    result2 = unfrack_path(pathsep=True)('./file')
    true_result2 = ['./file']
    if result2 == true_result2:
        print('Test 2 passed')
    else:
        print('Test 2 failed')
        print('Exp: %s, Result %s' % (true_result2, result2))

    # Test 3

# Generated at 2022-06-10 22:01:33.173318
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass
    namespace = Namespace()
    assert ensure_value(namespace, 'foo', True) is True
    assert ensure_value(namespace, 'foo', False) is True
    assert namespace.foo is True
    setattr(namespace, 'foo', False)
    assert ensure_value(namespace, 'foo', True) is False


#
# Common Parsers
#

# Generated at 2022-06-10 22:01:38.121419
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@foo/bar') == '@' + unfrackpath('foo/bar')
    assert maybe_unfrack_path('@')('@rm') == '@rm'
    assert maybe_unfrack_path('@')('/dev/null') == '/dev/null'



# Generated at 2022-06-10 22:02:02.200986
# Unit test for function unfrack_path

# Generated at 2022-06-10 22:02:10.238365
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()(os.path.expanduser('~/foo')) == os.path.expanduser('~/foo')
    assert unfrack_path(pathsep=True)('~/foo') == []
    assert unfrack_path(pathsep=True)('~/foo:') == [os.path.expanduser('~/foo')]
    assert unfrack_path(pathsep=True)('~/foo:' + os.path.expanduser('~/bar')) == [os.path.expanduser('~/foo'), os.path.expanduser('~/bar')]


# Generated at 2022-06-10 22:02:22.663992
# Unit test for function unfrack_path
def test_unfrack_path():
    os.getcwd = lambda: '/foo'
    assert unfrack_path()('bar') == os.path.join('/foo', 'bar')
    assert unfrack_path()('/bar') == '/bar'
    assert unfrack_path()('file:///bar') == '/bar'

    assert unfrack_path(pathsep=True)('bar:baz') == [os.path.join('/foo', 'bar'), os.path.join('/foo', 'baz')]
    assert unfrack_path(pathsep=True)('bar:file:///baz') == [os.path.join('/foo', 'bar'), '/baz']
    assert unfrack_path(pathsep=True)('file:///bar:file:///baz') == ['/bar', '/baz']



# Generated at 2022-06-10 22:02:28.008878
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test the case where the augmented value is returned
    assert maybe_unfrack_path('@')('@foo') == '@{0}'.format(unfrackpath('foo'))
    # Test the case where the original value is returned
    assert maybe_unfrack_path('@')('foo') == 'foo'


#
# Base OptionParser for Ansible CLI tools
#

# Generated at 2022-06-10 22:02:35.798504
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/tmp") == "/tmp"
    assert unfrack_path()("~/.ssh/id_rsa") == os.path.expanduser("~/.ssh/id_rsa")
    assert unfrack_path()("~/foo:~/.ssh/id_rsa") == [os.path.expanduser("~/foo"), os.path.expanduser("~/.ssh/id_rsa")]


# Generated at 2022-06-10 22:02:45.260440
# Unit test for function version
def test_version():
    """ unit tests for ansible --version output """
    (mock_stdout, ) = ansible.utils.unsafe_proxy.AnsibleUnsafeText("")


# Generated at 2022-06-10 22:02:48.816842
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    try:
        PrependListAction(None, None, 0, None, None, None, None, None, None, None)
        assert(False)
    except ValueError:
        pass



# Generated at 2022-06-10 22:02:50.804822
# Unit test for function version
def test_version():
    print(version(prog='ansible-playbook'))



# Generated at 2022-06-10 22:02:58.299154
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_cases = [
        ('@DEFAULT_ROLES_PATH@/my_role', '@DEFAULT_ROLES_PATH@/my_role'),
        ('@ROLES_PATH@/my_role', '@ROLES_PATH@' + unfrackpath('/my_role')),
    ]
    for test_case in test_cases:
        assert maybe_unfrack_path('@ROLES_PATH@')(test_case[0]) == test_case[1], \
            test_case[0] + ' -> ' + test_case[1]

#
# Options
#

# Generated at 2022-06-10 22:03:02.420321
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('a')('ab') == 'ab'
    assert maybe_unfrack_path('a')('a/b') == 'a/b'



# Generated at 2022-06-10 22:03:30.758653
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/b/c') == os.path.join(os.path.sep, 'a', 'b', 'c')
    assert unfrack_path()('/some/thing') == os.path.join(os.path.sep, 'some', 'thing')
    assert unfrack_path()('~/some/thing') == os.path.expanduser('~/some/thing')
    assert unfrack_path()('/some/../thing') == os.path.join(os.path.sep, 'some', '..', 'thing')
    assert unfrack_path()('/some/./thing') == os.path.join(os.path.sep, 'some', '.', 'thing')
    # With pathsep

# Generated at 2022-06-10 22:03:35.455453
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo/bar') == unfrackpath('foo/bar')
    assert unfrack_path(pathsep=True)('foo/bar:foo/baz') == [unfrackpath('foo/bar'), unfrackpath('foo/baz')]
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-10 22:03:46.363931
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    Unit test for constructor of class PrependListAction
    """
    class Foo(argparse.Action):
        def __call__(self, parser, args, values, optionals=None):
            pass

    # test defaults
    pa = PrependListAction(option_strings=['-a'], dest='ansible_foo_arg')
    assert isinstance(pa, Foo)
    assert pa.option_strings == ['-a']
    assert pa.dest == 'ansible_foo_arg'
    assert pa.required is False
    assert pa.choices is None
    assert pa.type is None
    assert pa.default is None
    assert pa.metavar is None
    assert pa.const is None
    assert pa.help is None
    assert pa.nargs == argparse.OPTIONAL
    assert pa.n

# Generated at 2022-06-10 22:03:53.625008
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/my_playbook_dir') == '@/tmp/my_playbook_dir'
    assert maybe_unfrack_path('@')('@/tmp/my_playbook_dir/') == '@/tmp/my_playbook_dir/'
    assert maybe_unfrack_path('@')('@/tmp/my_playbook_dir//') == '@/tmp/my_playbook_dir//'
    assert maybe_unfrack_path('@')('@@/tmp/my_playbook_dir//') == '@@/tmp/my_playbook_dir//'

# Generated at 2022-06-10 22:03:59.280714
# Unit test for function unfrack_path
def test_unfrack_path():
    if sys.platform == 'win32':
        # windows paths do not have a leading path separator
        assert unfrack_path()(r"/tmp/foo") == r"\tmp\foo"
    else:
        # On Unix, no changes are made
        assert unfrack_path()("/tmp/foo") == "/tmp/foo"



# Generated at 2022-06-10 22:04:10.802834
# Unit test for function unfrack_path
def test_unfrack_path():
    '''We need to run the argparse callback function unfrack_path from this function
    since the callback itself is inside of a function and not at the module scope.
    The callback function is skipped when the module scope is imported by the
    Ansible test module for unit testing.
    '''
    cwd = os.getcwd()
    os.environ[b'HOME'] = cwd
    os.environ[b'USERPROFILE'] = cwd
    os.environ[b'ANSIBLE_CONFIG'] = os.path.join(cwd, '.ansible.cfg')
    os.environ[b'ANSIBLE_DATA_DIR'] = os.path.join(cwd, '.ansible')

# Generated at 2022-06-10 22:04:14.956934
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == unfrackpath('foo')
    assert unfrack_path(pathsep=True)('/tmp/foo:~/bar') == [unfrackpath('/tmp/foo'), unfrackpath('~/bar')]



# Generated at 2022-06-10 22:04:20.372283
# Unit test for function version
def test_version():
    __version__ = '0.99.99'
    C.CONFIG_FILE = 'config.file'
    assert '0.99.99' in version()
    assert 'config file = ' + C.CONFIG_FILE in version()
    assert 'ansible python module location = ' in version()
    assert 'ansible collection location = ' in version()
    assert 'executable location = ' in version()
    assert 'python version = ' in version()
    assert 'jinja version = ' in version()
    assert 'libyaml = ' in version()

# Generated at 2022-06-10 22:04:28.007699
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('./foo') == unfrackpath('./foo')
    assert unfrack_path(pathsep=True)('./foo' + os.pathsep + './bar') == [unfrackpath('./foo'), unfrackpath('./bar')]
    assert unfrack_path()('./foo') == unfrackpath('./foo')
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-10 22:04:36.568990
# Unit test for function unfrack_path
def test_unfrack_path():
    class Args:
        def __init__(self, path, paths):
            self.path = path
            self.paths = paths
    args = Args('/a/path', ['/b/path', '/c/path'])
    colargs = Args('/a/path', '/b/path:/c/path')
    unfrack_path(False)(colargs)
    assert colargs.path == '/a/path'
    assert colargs.paths == ['/b/path', '/c/path']
    unfrack_path(False)(args)
    assert args.path == '/a/path'
    assert args.paths == ['/b/path', '/c/path']



# Generated at 2022-06-10 22:05:42.178947
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    tmp = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'test', 'unit', 'test_utils_path.py'))
    assert maybe_unfrack_path('@')('@{0}'.format(tmp)) == '@{0}'.format(tmp)



# Generated at 2022-06-10 22:05:48.538648
# Unit test for function unfrack_path
def test_unfrack_path():
    value = unfrack_path()
    assert value('ansible-config') == 'ansible-config'
    assert value('/path/to/ansible-config') == '/path/to/ansible-config'
    assert value('~/path/to/ansible-config') == '/Users/dummy/path/to/ansible-config'



# Generated at 2022-06-10 22:05:57.635804
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/var/run/ansible') == '/var/run/ansible'
    assert unfrack_path()('var/run/ansible') == 'var/run/ansible'
    assert unfrack_path()('/etc/ansible') == '/etc/ansible'
    assert unfrack_path(True)('/etc/ansible:/etc/alternatives') == ['/etc/ansible', '/etc/alternatives']
    assert unfrack_path()('/etc/ansible:/etc/alternatives') == '/etc/ansible:/etc/alternatives'
    assert unfrack_path()('$HOME') == os.getenv('HOME')
    assert unfrack_path()('~') == os.getenv('HOME')

# Generated at 2022-06-10 22:06:08.705889
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    '''test for correct initialization of class SortingHelpFormatter'''

    test_arg1 = argparse.ArgumentParser()
    test_arg1.add_argument('-t')
    test_arg2 = argparse.ArgumentParser()
    test_arg2.add_argument('-g')

    test_actions = [test_arg1, test_arg2]
    testing_help_formatter = SortingHelpFormatter()
    result = testing_help_formatter.add_arguments(actions=test_actions)
    expected = None
    assert result == expected

#
# Main command line parser
#



# Generated at 2022-06-10 22:06:21.424054
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():

    # create a parser for testing
    parser = argparse.ArgumentParser(prog=sys.argv[0], formatter_class=SortingHelpFormatter)

    # add arguments in reverse order
    parser.add_argument('-n', '--name', action="store", dest="name")
    parser.add_argument('-a', '--age', action="store", dest="age")
    parser.add_argument('-g', '--gender', action="store", dest="gender")
    help_result = parser.format_help()

    # check the help result
    sorted_help_result = help_result.split('\n')[1]
    assert sorted_help_result.split() == ['-a', '-g', '-h', '-n'], "The arguments are not sorted"


# Generated at 2022-06-10 22:06:26.258550
# Unit test for function version
def test_version():
    assert version(prog='sample') == 'sample [core 2.9.9]\n  config file = sample\n  configured module search path = sample\n  ansible python module location = sample\n  ansible collection location = sample\n  executable location = sample\n  python version = sample\n  jinja version = sample\n  libyaml = sample'


# Generated at 2022-06-10 22:06:28.677083
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('ansible') == 'ansible'
    assert unfrack_path()('~/.ansible/test') == os.path.expanduser('~/.ansible/test')


# Generated at 2022-06-10 22:06:32.525330
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('.') == os.getcwd()
    assert unfrack_path(True)('.') == [os.getcwd()]
    assert unfrack_path(True)(os.getcwd()) == [os.getcwd()]
    assert unfrack_path(True)('.' + os.path.pathsep + 'random') == [os.getcwd(), 'random']



# Generated at 2022-06-10 22:06:36.286184
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path().__name__ == 'inner'
    assert unfrack_path().__doc__ == """Turn an Option's data into a single path in Ansible locations"""
    assert unfrack_path(pathsep=False)('special_dir') == unfrackpath('special_dir')
    assert unfrack_path(pathsep=False)('-') == '-'
    assert unfrack_path(pathsep=True)('special_dir') == [unfrackpath('special_dir')]



# Generated at 2022-06-10 22:06:38.625017
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path(True)("/etc/ansible:/usr/local/etc/ansible")

