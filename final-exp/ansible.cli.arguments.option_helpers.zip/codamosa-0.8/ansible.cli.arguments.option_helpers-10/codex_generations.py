

# Generated at 2022-06-10 21:59:01.484054
# Unit test for function add_async_options
def test_add_async_options():
    # Passing
    fp = '-P --poll'.split()
    sp = '-B --background'.split()
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_async_options(parser)
    assert fp == parser._option_string_actions['-P'].option_strings
    assert sp == parser._option_string_actions['-B'].option_strings

    # Failing
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_async_options(parser)
    assert fp != parser._option_string_actions['-B'].option_strings
    assert sp != parser._option_string_actions['-P'].option_strings



# Generated at 2022-06-10 21:59:05.187449
# Unit test for function add_runas_options
def test_add_runas_options():
    """Unit test for function add_runas_options"""
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    # TODO: more detailed test


# Generated at 2022-06-10 21:59:18.926615
# Unit test for function unfrack_path

# Generated at 2022-06-10 21:59:21.178326
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    return parser



# Generated at 2022-06-10 21:59:23.654448
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    parser.parse_args([])



# Generated at 2022-06-10 21:59:29.785033
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '10', '-B', '10'])
    assert args.poll_interval == 10
    assert args.seconds == 10
    assert args.poll_interval == 10
    assert args.seconds == 10



# Generated at 2022-06-10 21:59:40.276790
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from ansible.errors import AnsibleOptionsError
    from ansible.config.manager import ConfigManager
    from ansible.config.parser import ConfigParser

    # initialize option conflicts for ConfigManager
    ConfigManager(args=dict())

    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args([])
    assert args.become_ask_pass is False
    assert args.become_password_file is None

    # runas_pass_group should be mutually exclusive
    try:
        parser.parse_args(['-K', '--become-password-file=/foo/bar/baz'])
    except AnsibleOptionsError as e:
        options = dict((o.dest, o) for o in parser._actions)

# Generated at 2022-06-10 21:59:42.052830
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    return parser.parse_args(['-t', 'test1', '-t', 'test2', '--skip-tags', 'test3', '--skip-tags', 'test4'])

# Generated at 2022-06-10 21:59:46.492688
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)
    assert parser.parse_args(['--playbook-dir', '..']).basedir == '../'


# Generated at 2022-06-10 21:59:53.254792
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    (options, args) = parser.parse_known_args(["-t name1","-t","name2","--skip-tags", "name3","--skip-tags","name4"])
    assert options.tags == ["name1", "name2"]
    assert options.skip_tags == ["name3", "name4"]



# Generated at 2022-06-10 22:00:22.474986
# Unit test for function add_connect_options
def test_add_connect_options():
    def create_parser():
        parser = argparse.ArgumentParser()
        add_connect_options(parser)
        return parser

    # test defaults
    parser = create_parser()
    # print(parser.parse_args())
    # assert parser.parse_args().private_key_file == C.DEFAULT_PRIVATE_KEY_FILE, \
    #     "expected default private_key_file `%s' got `%s'" % (C.DEFAULT_PRIVATE_KEY_FILE, parser.parse_args().private_key_file)
    # assert parser.parse_args().remote_user == C.DEFAULT_REMOTE_USER, \
    #     "expected default remote_user `%s' got `%s'" % (C.DEFAULT_REMOTE_USER, parser.parse_args().remote_user)

# Generated at 2022-06-10 22:00:31.187831
# Unit test for function add_connect_options
def test_add_connect_options():
    expected_options = ['--private-key', '--key-file', '-u', '--user', '-c',
                        '--connection', '-T', '--timeout', '--ssh-common-args',
                        '--sftp-extra-args', '--scp-extra-args', '--ssh-extra-args',
                        '-k', '--ask-pass', '--connection-password-file',
                        '--conn-pass-file']

    expected_ssh_options = ['--ssh-common-args', '--sftp-extra-args', '--scp-extra-args',
                            '--ssh-extra-args']

    expected_password_options = ['-k', '--ask-pass', '--connection-password-file',
                                 '--conn-pass-file']

    parser = argparse

# Generated at 2022-06-10 22:00:43.932154
# Unit test for function add_vault_options
def test_add_vault_options():
    """
    Test the function to add Vault options to an OptionParser object
    """
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.parse_args(["--vault-id", "dev_vault"])
    parser.parse_args(["--vault-id", "dev_vault", "--vault-id", "prod_vault"])
    parser.parse_args(["--vault-id", "dev_vault", "--vault-id", "prod_vault", "--vault-id", "test_vault"])
    parser.parse_args(["--ask-vault-pass"])
    parser.parse_args(["--vault-password-file", "vault.pass"])



# Generated at 2022-06-10 22:00:47.426003
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(description='Ansible version module')
    add_connect_options(parser)
    assert parser



# Generated at 2022-06-10 22:00:52.320458
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/')('/bin/python') == '/bin/python'
    assert maybe_unfrack_path('@')('@random_unfrackable') == '@random_unfrackable'
    assert maybe_unfrack_path('@')('@/python') == '@/python'



# Generated at 2022-06-10 22:00:54.270776
# Unit test for function version
def test_version():
    assert type(version()) is str

# Generated at 2022-06-10 22:01:06.019270
# Unit test for function add_vault_options
def test_add_vault_options():
    single_vault = parse_vault_ids(['@~/file.yml'])
    multiple_vault = parse_vault_ids(['@~/file1.yml', '@~/file2.yml'])

    # Test with one vault password file
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args(['--vault-password-file=~/file.yml'])
    assert args.vault_password_files == ['~/file.yml']
    assert args.vault_ids == single_vault

    # Test with multiple vault password files
    parser = argparse.ArgumentParser()
    add_vault_options(parser)

# Generated at 2022-06-10 22:01:08.970013
# Unit test for function add_vault_options
def test_add_vault_options():
    p = argparse.ArgumentParser()
    add_vault_options(p)
    assert p.parse_args().vault_ids == []



# Generated at 2022-06-10 22:01:20.130869
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.utils.display import Display
    parser = AdHocCLI.base_parser(constants=C)
    add_connect_options(parser)
    parser = Display().add_verbosity_options(parser)
    parser = Display().add_common_options(parser, 0)
    parser, options = AdHocCLI.parse(parser, os.path.basename(sys.argv[0]), sys.argv[1:])
    # Addition
    assert hasattr(options, 'private_key_file')
    assert hasattr(options, 'remote_user')
    assert hasattr(options, 'connection')
    # Default Value
    assert options.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE

# Generated at 2022-06-10 22:01:25.777084
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    with open(os.devnull, 'w') as fd_devnull:
        # Neither --version will be printed
        parser.print_help(file=fd_devnull)
        # Neither ansible version will be printed
        parser.print_version(file=fd_devnull)
        # Neither ansible version will be printed
        parser.exit()



# Generated at 2022-06-10 22:01:39.524145
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.cli import CLI
    from io import StringIO
    from contextlib import redirect_stdout
    output = StringIO()
    with redirect_stdout(output):
        parser = CLI.base_parser()
        parser.add_argument = MagicMock()
        AnsibleVersion(None, None, None)(parser, None, None)
    assert output.getvalue() == to_native(version('ansible'))

# Generated at 2022-06-10 22:01:45.719124
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from ansible.cli.arguments import Options

    parser = argparse.ArgumentParser(prog='ansible')

    add_inventory_options(parser)

    options = Options([])
    options.parse(['-i', 'test,test_pattern', '--inventory', 'another_test,another_pattern', '--list-hosts', '-l', 'subset_pattern'])

    assert options.inventory[0] == 'test,test_pattern'
    assert options.inventory[1] == 'another_test,another_pattern'
    assert options.listhosts == True
    assert options.subset == 'subset_pattern'



# Generated at 2022-06-10 22:01:57.505985
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo-bar')
    parser.add_argument('--foo-bar', nargs='+', action=PrependListAction)
    args = parser.parse_args([])
    assert args.foo_bar == None
    args = parser.parse_args(['--foo-bar', 'one'])
    assert args.foo_bar == ['one']
    args = parser.parse_args(['--foo-bar', 'one', '--foo-bar', 'two'])
    assert args.foo_bar == ['one', 'two']
    args = parser.parse_args(['--foo-bar', 'one', '--foo-bar', 'two', '--foo-bar', 'three'])

# Generated at 2022-06-10 22:02:06.407730
# Unit test for function unfrack_path
def test_unfrack_path():
    test_env = {'ANSIBLE_ROLES_PATH': "/my/path/to/roles:/my/other/roles:/roles",
                'FOO': "FOO"}
    expected_paths = ["/my/path/to/roles", "/my/other/roles", "/roles"]

    # test_env isn't defined until this point, so this has to be inside the
    # function to be tested
    def test_function(pathsep):
        def inner(value):
            if pathsep:
                return [unfrackpath(x, local_tmp=test_env) for x in value.split(os.pathsep) if x]
            return unfrackpath(value, local_tmp=test_env)
        return inner

    test_path = test_function(False)

# Generated at 2022-06-10 22:02:15.233603
# Unit test for constructor of class SortingHelpFormatter

# Generated at 2022-06-10 22:02:23.049031
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path('@')('@/path/to') == '@%s/path/to' % unfrackpath(''))
    assert(maybe_unfrack_path('@')('@/path/to/') == '@%s/path/to/' % unfrackpath(''))
    assert(maybe_unfrack_path('@')('/path/to') == '/path/to')



# Generated at 2022-06-10 22:02:28.389728
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('path') == unfrackpath('path')
    assert unfrack_path()('path' + os.pathsep + 'path') == unfrackpath('path')
    assert unfrack_path(pathsep=True)('path1' + os.pathsep + 'path2') == [unfrackpath('path1'), unfrackpath('path2')]
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-10 22:02:37.100089
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_args = [
        ('$ANSIBLE_CONFIG/lots/of/paths', 'ANSIBLE_CONFIG'),
        ('/etc/ansible/ansible.cfg', 'ANSIBLE_CONFIG'),
        ('/etc/ansible/ansible.cfg', 'somethingelse'),
    ]
    for (res_value, what) in test_args:
        assert maybe_unfrack_path(what)(res_value) == res_value



# Generated at 2022-06-10 22:02:45.786241
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/') == '/tmp'
    assert unfrack_path()('/tmp//') == '/tmp'
    assert unfrack_path(True)('/tmp:/tmp2') == ['/tmp', '/tmp2']
    assert unfrack_path(True)('/tmp//:/tmp2/') == ['/tmp', '/tmp2']
    assert unfrack_path(True)('/tmp:/tmp2/') == ['/tmp', '/tmp2']
    assert unfrack_path(True)('/tmp/:/tmp2') == ['/tmp', '/tmp2']
    assert unfrack_path(True)('/tmp1:/tmp2') == ['/tmp1', '/tmp2']
    assert unfrack_path(True)('/tmp1://tmp2') == ['/tmp1', '/tmp2']

# Generated at 2022-06-10 22:02:56.237337
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_inventory_options(parser)

# Generated at 2022-06-10 22:03:15.559947
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.parser import ensure_value
    # Ensure that list value is created if necessary
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == ['bar']
    # Ensure that existing list value is copied and prepended
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['baz', 'bar']
    # Ensure that items are copied when not a list value
    parser = argparse.ArgumentParser()

# Generated at 2022-06-10 22:03:20.096117
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_value = "/test/path"
    test_value_beacon = "~/test/path"
    test_beacon = "@"

    unfracked = maybe_unfrack_path(test_beacon)(test_value)
    assert unfracked == test_value

    unfracked = maybe_unfrack_path(test_beacon)(test_value_beacon)
    assert unfracked == "@" + unfrackpath(test_value)



# Generated at 2022-06-10 22:03:24.524284
# Unit test for function unfrack_path
def test_unfrack_path():
    assert '/path/to/something' == unfrack_path()('/path/to/something')
    assert '/path/to/something' == unfrack_path(pathsep=True)('/path/to/something')
    assert ['/path/to/something1', '/path/to/something2'] == unfrack_path(pathsep=True)('/path/to/something1:/path/to/something2')



# Generated at 2022-06-10 22:03:35.664603
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """Check if ansible version is displayed and exit
    """
    args = ['ansible-playbook', '--version']
    expected = """ansible-playbook x.x.x
  config file =
  configured module search path = [u'/home/user/.ansible/plugins/modules', u'/usr/share/ansible/plugins/modules']
  ansible python module location = /usr/lib/python2.7/site-packages/ansible
  executable location = /usr/bin/ansible-playbook
  python version = 2.7.5 (default, Nov  6 2016, 00:28:07) [GCC 4.8.5 20150623 (Red Hat 4.8.5-11)]
"""


# Generated at 2022-06-10 22:03:39.820368
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    p = argparse.ArgumentParser()
    p.add_argument('-a', action=PrependListAction, nargs=2)
    p.add_argument('-b', action='append', nargs=2)
    args = p.parse_args('-a 1 2 -a 3 4 -b 1 2 -b 3 4'.split())
    print(args)
    args = p.parse_args('-b 1 2 -b 3 4 -a 1 2 -a 3 4'.split())
    print(args)
# test_PrependListAction___call__()



# Generated at 2022-06-10 22:03:44.092850
# Unit test for function ensure_value
def test_ensure_value():
    class Class:
        def __init__(self):
            self.list = []

    obj = Class()
    ensure_value(obj, 'list', [1, 2, 3])
    obj.list.append(4)
    assert obj.list == [1, 2, 3, 4]



# Generated at 2022-06-10 22:03:51.544620
# Unit test for function ensure_value
def test_ensure_value():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--test1', action='append_const', dest='in_list')
    parser.add_argument('--test2', action='append_const', dest='in_list', default='in_default')
    parser.add_argument('--test3', action='append_const', dest='in_list', default=['in_default'])
    parser.add_argument('--test4', action='append_const', dest='in_list', default=['in_default', 'other_default'])

    for i in range(4):
        args = parser.parse_args(['--test%i' % i, '--test%i' % i])

# Generated at 2022-06-10 22:03:57.722764
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    namespace = argparse.Namespace()
    values = argparse.Values()
    option_string = '--version'
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-playbook'
    AnsibleVersion().__call__(parser, namespace, values, option_string)
    assert parser.exit.called



# Generated at 2022-06-10 22:04:04.089558
# Unit test for function version
def test_version():
    assert version(prog="TestProg") == "TestProg [core %s]\n  config file = %s\n  configured module search path = %s\n  ansible python module location = %s\n  ansible collection location = %s\n  executable location = %s\n  python version = %s\n  jinja version = %s\n  libyaml = %s" % (__version__, C.CONFIG_FILE, C.DEFAULT_MODULE_PATH, ':'.join(ansible.__path__), ':'.join(C.COLLECTIONS_PATHS), sys.argv[0], sys.version, j2_version, HAS_LIBYAML)

# Generated at 2022-06-10 22:04:13.299536
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.cli.arguments import Parser

    p = Parser()
    unparsed = dict(dest='unparsed', action=PrependListAction)
    p.add_argument('--prepend', **unparsed)
    args = ['--prepend', '1', '2']
    ns = p.parse_args(args)
    assert ns.unparsed == ['1', '2']

    args = ['--prepend', '1', '--prepend', '2']
    ns = p.parse_args(args)
    assert ns.unparsed == ['2', '1']



# Generated at 2022-06-10 22:04:31.658775
# Unit test for function unfrack_path
def test_unfrack_path():
    """Unit test for function unfrack_path"""
    working_path = '/etc/ansible'
    withworking_path = './hello'
    new_path = unfrack_path()(withworking_path)
    assert new_path == os.path.join(working_path, withworking_path)



# Generated at 2022-06-10 22:04:38.421240
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    #
    # Monkey patch class AnsibleVersion and its method __call__
    #
    saved_AnsibleVersion___call__ = AnsibleVersion.__call__

    def monkey__call__(self, parser, namespace, values, option_string=None):
        #
        # Save object state and parameters
        #
        self.saved_AnsibleVersion__call___parser = copy.deepcopy(parser)
        self.saved_AnsibleVersion__call___namespace = copy.deepcopy(namespace)
        self.saved_AnsibleVersion__call___values = copy.deepcopy(values)
        self.saved_AnsibleVersion__call___option_string = copy.deepcopy(option_string)
        #
        # Monkey patch object state and parameters when running method __call__
        #


# Generated at 2022-06-10 22:04:40.606511
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print(maybe_unfrack_path('@')('@/path/to/playbook'))


# Generated at 2022-06-10 22:04:50.659784
# Unit test for function version
def test_version():
    assert version(prog='ansible-program') == """ansible-program [core {0}] ({1}) last updated {2} (GMT {3:+04d})
  config file = N/A
  configured module search path = N/A
  ansible python module location = N/A
  ansible collection location = N/A
  executable location = N/A
  python version = {4}
  jinja version = {5}
  libyaml = N/A""".format(
        __version__, sys.version.split()[0], sys.platform,
        __import__('time').timezone if __import__('time').daylight else __import__('time').altzone,
        j2_version, HAS_LIBYAML
    )

# Generated at 2022-06-10 22:04:54.988764
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction, nargs=2)
    parser.add_argument('--baz', action=PrependListAction, nargs='+')

    # MUT
    args = parser.parse_args('--foo a --bar x y --bar p q --baz 1 2 3'.split())
# /Unit test for method __call__ of class PrependListAction


# Generated at 2022-06-10 22:05:03.011181
# Unit test for function unfrack_path
def test_unfrack_path():
    """
    >>> unfrack_path(True)('a')
    ['/var/tmp/ansible/a']
    >>> unfrack_path(True)('a:b')
    ['/var/tmp/ansible/a', '/var/tmp/ansible/b']
    >>> unfrack_path(True)('b:a')
    ['/var/tmp/ansible/b', '/var/tmp/ansible/a']
    >>> unfrack_path()('-')
    '-'
    >>> unfrack_path()('a')
    '/var/tmp/ansible/a'
    """
    pass


# Generated at 2022-06-10 22:05:06.709127
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Just tests if the version can be printed
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])



# Generated at 2022-06-10 22:05:11.749419
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('$')('$ANSIBLE/foo') == '$ANSIBLE/foo'


# Generated at 2022-06-10 22:05:20.021284
# Unit test for function ensure_value
def test_ensure_value():
    parser = argparse.ArgumentParser()
    parser.add_argument('--arg', action=ensure_value, value={})

    ns = parser.parse_args([])
    assert ns.arg == {}, 'Failure 1 in ensure_value'

    ns = parser.parse_args([])
    assert ns.arg == {}, 'Failure 2 in ensure_value'

    ns = parser.parse_args(['--arg', '{"a": 1}'])
    assert ns.arg == {"a": 1}, 'Failure 3 in ensure_value'

    print("Test for function ensure_value completed successfully.")
    sys.exit(0)

#
# Basic OptionParser
#



# Generated at 2022-06-10 22:05:27.649565
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrackpath('nonexistent') is None
    assert unfrackpath('-') == '-'
    assert unfrackpath('/nonexistent') == '/nonexistent'
    # os.path.isdir('/tmp')
    assert unfrackpath('/tmp') == '/tmp'
    assert unfrackpath('/tmp') == '/tmp'
    assert unfrackpath('/tmp') == '/tmp'
    assert unfrackpath('/tmp') == '/tmp'
    # /etc/ansible
    assert unfrackpath('/etc/ansible')



# Generated at 2022-06-10 22:05:54.333868
# Unit test for function unfrack_path
def test_unfrack_path():
    """Unit test for function unfrack_path"""
    from ansible.config.data import ConfigData
    from ansible.module_utils.common._collections_compat import UserList

    config = ConfigData('')

    # Pass in a list, make sure it gets returned as a list
    mylist = UserList()
    mylist.append('/path/to/something/new')
    mylist.append('/path/to/something/old')
    ret = unfrack_path(pathsep=True)(mylist)
    assert isinstance(ret, UserList), "Got the wrong return type back"

    # Pass in a string that contains a pathsep
    ret = unfrack_path(pathsep=True)('/path/to/something/new:/path/to/something/old')

# Generated at 2022-06-10 22:05:57.369414
# Unit test for function unfrack_path
def test_unfrack_path():
    new_path = unfrack_path()("/home/user/ansible:/etc/ansible")
    assert new_path == ['/home/user/ansible', '/etc/ansible']



# Generated at 2022-06-10 22:06:07.170520
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path('~')('~/foo') == '~/foo')
    assert(maybe_unfrack_path('@')('@/foo') == '@/foo')
    assert(maybe_unfrack_path('$')('$/foo') == '$/foo')
    assert(maybe_unfrack_path('%')('%/foo') == '%/foo')
    assert(maybe_unfrack_path('#')('#/foo') == '#/foo')



# Generated at 2022-06-10 22:06:10.090248
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@/path/to/something") == "@/path/to/something"
    assert maybe_unfrack_path("@")("/path/to/something") == "/path/to/something"



# Generated at 2022-06-10 22:06:22.623401
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('ansible/foo.py') == to_native('ansible/foo.py')
    assert unfrack_path(pathsep=False)('./foo.py') == to_native('ansible/foo.py')
    assert unfrack_path(pathsep=False)('~/foo.py') == to_native(os.path.join(os.path.expanduser('~'), 'foo.py'))
    assert unfrack_path(pathsep=True)('~/foo.py:ansible/bar.py:./baz.py') == [to_native(os.path.join(os.path.expanduser('~'), 'foo.py')), to_native('ansible/bar.py'), to_native('ansible/baz.py')]

# Generated at 2022-06-10 22:06:25.443167
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_value = maybe_unfrack_path('@')('@/dev/null')
    assert test_value == '@/dev/null'



# Generated at 2022-06-10 22:06:33.133419
# Unit test for function unfrack_path
def test_unfrack_path():
    cwd = os.getcwd()
    assert cwd == unfrack_path()(cwd)
    assert '~' + os.sep == unfrack_path()('~')
    assert os.path.join(cwd, 'a', 'b', 'c') == unfrack_path()(os.path.join(cwd, 'a', '..', 'a', 'b', 'c'))
    assert ['~' + os.sep + 'bin', '~' + os.sep + 'build'] == unfrack_path(True)('~' + os.sep + 'bin:/usr/bin')

# Generated at 2022-06-10 22:06:37.330978
# Unit test for function ensure_value
def test_ensure_value():
    class Foo(object):
        pass
    args = Foo()
    # empty namespace
    assert ensure_value(args, "bar", 3) == 3
    # existing attribute
    setattr(args, "bar", 5)
    assert ensure_value(args, "bar", 3) == 5



# Generated at 2022-06-10 22:06:44.670598
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    ns = argparse.Namespace()
    parser.print_usage = lambda x: None
    parser.exit = lambda x: None
    action = AnsibleVersion(option_strings=[])
    Ansi = "Ansible %s\n" % __version__
    action.__call__(parser, ns, '', option_string=None)
    assert Ansi == sys.stdout.getvalue()


#
# Ansible Modules
#

# Generated at 2022-06-10 22:06:47.929228
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@foo') == '@' + unfrackpath('foo')
    assert maybe_unfrack_path('@')('bar') == 'bar'


#
# Utility functions when working with OptionParsers
#

# Generated at 2022-06-10 22:07:32.199942
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == unfrackpath('foo')
    assert unfrack_path()('-') == '-'
    assert unfrack_path(pathsep=True)('foo') == [unfrackpath('foo')]
    assert unfrack_path(pathsep=True)('foo' + os.pathsep + 'bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('foo' + os.pathsep + '-') == [unfrackpath('foo'), '-']



# Generated at 2022-06-10 22:07:41.257473
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    dest = 'dummy_dest'
    args_list = ['-f', '-a', '-b', '-c']
    namespace = argparse.Namespace()
    setattr(namespace, dest, [])
    arg_dict = {'option_strings': args_list, 'dest': dest, 'nargs': '*'}
    action = PrependListAction(**arg_dict)
    action.__call__(None, namespace, values=None, option_string=None)
    assert getattr(namespace, dest) == []



# Generated at 2022-06-10 22:07:44.831857
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()

    argument = PrependListAction('--append', dest='append', metavar='metavar', const=42)
    result = argument(
        parser=None,
        namespace=namespace,
        values=[10, 20],
        option_string='--append'
    )
    assert result is None
    assert namespace.append == [10, 20, 42]



# Generated at 2022-06-10 22:07:54.318406
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("%")("%foo") == "%" + unfrackpath("foo")
    assert maybe_unfrack_path("%")("%") == "%"
    assert maybe_unfrack_path("%")("%foo/") == "%" + unfrackpath("foo") + "/"
    assert maybe_unfrack_path("%")("%foo/%bar") == "%" + unfrackpath("foo") + "/%bar"
    assert maybe_unfrack_path("%")("bar") == "bar"
    assert maybe_unfrack_path("%")("foo/%bar") == "foo/%bar"



# Generated at 2022-06-10 22:07:59.434645
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    args = [r'~bar', r'#foo/bar', r'#foo/~bar', '/foo/bar', 'bar']
    expected = [r'~bar', '#foo/bar', '#foo/~bar', '/foo/bar', 'bar']
    for (a, e) in zip(args, expected):
        result = maybe_unfrack_path(r'#foo/')(a)
        assert result == e



# Generated at 2022-06-10 22:08:01.423454
# Unit test for function unfrack_path
def test_unfrack_path():
    # Unfrackpath is impossible to test for in this case
    # unfrackpath calls getattr(C, 'DEFAULT_xxxx'), but C is not in scope
    pass



# Generated at 2022-06-10 22:08:09.256824
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from collections import namedtuple
    from unittest import TestCase
    class MockParser(object):
        def error(self, message):
            raise TypeError(message)
    args = namedtuple('args', 'a')
    namespace = args(a=None)
    pla = PrependListAction(
        option_strings=[],
        dest='a',
        nargs=0
    )
    pla(parser=MockParser(), namespace=namespace, values=['a', 'b'], option_string=None)
    self.assertEqual(namespace.a, ['a', 'b'])

