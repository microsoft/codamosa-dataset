

# Generated at 2022-06-10 21:58:51.943478
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    opt = parser.parse_args([])
    assert opt.poll_interval == 10
    assert opt.seconds == 0



# Generated at 2022-06-10 21:58:58.734337
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    args = parser.parse_args(['--ask-become-pass', '--become-password-file'])
    assert not args.become_ask_pass
    assert isinstance(args.become_password_file, str)


# Generated at 2022-06-10 21:59:01.617167
# Unit test for function version
def test_version():
    assert 'ansible-playbook 2.8.0' in version('ansible-playbook')

# Generated at 2022-06-10 21:59:09.847226
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/path') == '@/tmp/path'
    assert maybe_unfrack_path('@')('@/tmp/../ansible') == '@/ansible'
    assert maybe_unfrack_path('@')('/tmp/../ansible') == '/tmp/../ansible'
    assert maybe_unfrack_path('@')('@//tmp/path') == '@/tmp/path'



# Generated at 2022-06-10 21:59:17.666524
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class dummy_parser(object):
        def error(self, value):
            pass
    action = PrependListAction(['--list'], 'list', const='a', nargs=2)
    namespace = argparse.Namespace(list=[])
    action(dummy_parser(), namespace, ['b', 'c'], '--list')
    assert namespace.list == ['b', 'c', 'a']



# Generated at 2022-06-10 21:59:19.431914
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    argv = ['-o', '-t','test']
    args = parser.parse_args(argv)
    assert args.one_line
    assert args.tree == 'test'
    

# Generated at 2022-06-10 21:59:20.428738
# Unit test for function version
def test_version():
    assert version()



# Generated at 2022-06-10 21:59:30.888229
# Unit test for function add_connect_options
def test_add_connect_options():
    def test_parser(parser):
        parser.add_argument('-v', '--verbose', dest='verbosity', default=C.DEFAULT_VERBOSITY, action="count",
                            help="verbose mode (-vvv for more, -vvvv to enable connection debugging)")
        parser.add_argument('--connection', dest='connection', default=C.DEFAULT_TRANSPORT,
                            help="connection type to use (default=%s)" % C.DEFAULT_TRANSPORT)
        add_connect_options(parser)
    return test_parser



# Generated at 2022-06-10 21:59:37.659401
# Unit test for function unfrack_path
def test_unfrack_path():
    test = [
        ('$HOME', '$HOME'),
        ('~', '~'),
        ('/etc', '/etc'),
        ('/etc:$HOME', '/etc:$HOME'),
        ('/etc:/home', ['/etc', '/home'])
    ]

    for value, expected in test:
        assert unfrack_path(True)(value) == expected



# Generated at 2022-06-10 21:59:44.906648
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '@/test/path'
    test_path_expectation = '@' + unfrackpath('/test/path')
    assert test_path_expectation == maybe_unfrack_path('@')(test_path)
    assert test_path == maybe_unfrack_path('@')('@/test/path')



# Generated at 2022-06-10 22:00:27.466237
# Unit test for function ensure_value
def test_ensure_value():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument('--foo', action="store", default=None)

    result = ensure_value(parser.parse_args([]), 'foo', 'bar')
    assert result == 'bar'
    result = ensure_value(parser.parse_args([]), 'foo', 'bar')
    assert result == 'bar'



# Generated at 2022-06-10 22:00:39.539307
# Unit test for function add_vault_options
def test_add_vault_options():
    from os.path import dirname, join, basename
    from ansible.cli.arguments import get_valid_vault_secrets
    from ansible.utils.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader

    this_path = dirname(__file__)
    secrets = [
        VaultSecret(
            'password',
            join(this_path, '../test/test_vault/vault.yml'),
            'ansible_test_decrypt',
        ),
    ]
    patterns = get_valid_vault_secrets(
        secrets,
        vault_prompts={'password': lambda x: True},
    )
    assert len(patterns) == 1
    assert 'all'

# Generated at 2022-06-10 22:00:44.318040
# Unit test for function add_vault_options
def test_add_vault_options():
    options = {}
    add_vault_options(options)
    assert options['vault-id'] is None
    assert options['ask-vault-pass'] is False
    assert options['vault-password-file'] is not None


#
# Functions to add pre-canned options to an OptionParser
#


# Generated at 2022-06-10 22:00:48.530178
# Unit test for function add_vault_options
def test_add_vault_options():
    parser=argparse.ArgumentParser()
    add_vault_options(parser)
    args=parser.parse_args(["--ask-vault-password","--vault-password-file=test"])
    assert args.ask_vault_pass == True
    assert args.vault_password_files == ['test']


# Generated at 2022-06-10 22:00:51.517188
# Unit test for function add_runas_options
def test_add_runas_options():
    optparse.OptionParser.add_argument = Mock()
    parser = optparse.OptionParser()
    add_runas_options(parser)
    success = False

# Generated at 2022-06-10 22:00:55.127042
# Unit test for function add_meta_options
def test_add_meta_options():
    from argparse import ArgumentParser
    parser = ArgumentParser(prog='prog')
    add_meta_options(parser)
    options = parser.parse_args(['--force-handlers', '--flush-cache'])
    print(options)
    assert options.force_handlers and options.flush_cache


# Generated at 2022-06-10 22:00:59.591506
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers'])
    assert args is not None
    assert args.force_handlers is True


# Generated at 2022-06-10 22:01:06.964494
# Unit test for function unfrack_path
def test_unfrack_path():
    assert (unfrack_path(True)("/usr/share/ansible:/usr/local/ansible/lib::~:~/local/ansbile/lib:/usr/share/ansible/roles:/usr/share/ansible/plugins")
        == ["/usr/share/ansible", "/usr/local/ansible/lib", "~", "~/local/ansbile/lib", "/usr/share/ansible/roles", "/usr/share/ansible/plugins"])



# Generated at 2022-06-10 22:01:15.698515
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace(object):
        pass
    ns = FakeNamespace()
    assert ensure_value(ns, 'foo', 'bar') == 'bar'
    assert ns.foo == 'bar'
    assert ensure_value(ns, 'foo', None) == 'bar'
    assert ns.foo == 'bar'
    assert ensure_value(ns, 'foo', 'new_value') == 'bar'
    assert ns.foo == 'bar'
    assert ensure_value(ns, 'bar', 'baz') == 'baz'
    assert ns.bar == 'baz'


#
# OptionParser support
#


# Generated at 2022-06-10 22:01:25.257785
# Unit test for function version
def test_version():
    ansible_path = ansible.__path__[0]
    python_path = ''.join(sys.version.splitlines())
    python_executable = sys.executable

# Generated at 2022-06-10 22:01:41.805391
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/ansible') == unfrackpath('/tmp/ansible')
    assert unfrack_path(pathsep=True)('/tmp/ansible:/tmp/ansible2') == [unfrackpath('/tmp/ansible'), unfrackpath('/tmp/ansible2')]
    assert unfrack_path(pathsep=True)('/tmp/ansible:/tmp/ansible2:') == [unfrackpath('/tmp/ansible'), unfrackpath('/tmp/ansible2')]
    assert unfrack_path(pathsep=True)('::/tmp/ansible:/tmp/ansible2') == [unfrackpath('/tmp/ansible'), unfrackpath('/tmp/ansible2')]

# Generated at 2022-06-10 22:01:53.074256
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('../../test') == os.path.normpath(os.path.join(os.getcwd(),'../test'))
    assert unfrack_path()('test') == os.path.join(C.DEFAULT_LOCAL_TMP, 'test')
    assert unfrack_path(True)('../../test') == [os.path.normpath(os.path.join(os.getcwd(),'../test'))]
    assert unfrack_path(True)('../../test:../../test2') == [os.path.normpath(os.path.join(os.getcwd(),'../test')), os.path.normpath(os.path.join(os.getcwd(),'../test2'))]


# Generated at 2022-06-10 22:01:58.564623
# Unit test for constructor of class SortingHelpFormatter

# Generated at 2022-06-10 22:02:06.345263
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    args = parser.parse_args()
    assert not args.become_user
    assert args.become
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    args = parser.parse_args(['--become-user', 'john_doe'])
    assert args.become_user == 'john_doe'
    assert args.become
    assert args.become_method == C.DEFAULT_BECOME_METHOD



# Generated at 2022-06-10 22:02:15.206274
# Unit test for function version
def test_version():
    import ansible.constants as C
    from ansible.release import __version__

# Generated at 2022-06-10 22:02:27.799583
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Create a sample parser
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", action='store_true')
    parser.add_argument("-b", action='store_true')
    parser.add_argument("-c", action='store_true')

    # create a sample help formatter and make sure it is sorting
    formatter = SortingHelpFormatter()
    parser.add_argument("-a", action='store_true')
    parser.add_argument("-b", action='store_true')
    parser.add_argument("-c", action='store_true')

# Generated at 2022-06-10 22:02:40.567302
# Unit test for function add_runas_options
def test_add_runas_options():
    """
    Test for add_runas_options
    """
    fake_parser = Mock()
    add_runas_options(fake_parser)
    runas_group = fake_parser.add_argument_group.call_args[0][0]
    sudo_prompt_group = fake_parser.add_mutually_exclusive_group.call_args[0][0]
    sudo_pass_group = fake_parser.add_mutually_exclusive_group.call_args[0][0]
    assert runas_group == "Privilege Escalation Options"
    assert sudo_prompt_group == "Privilege Escalation Prompt Options"
    assert sudo_pass_group == "Privilege Escalation Password Options"



# Generated at 2022-06-10 22:02:52.360999
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print("Testing function maybe_unfrack_path")
    result = maybe_unfrack_path('@mock')
    print(result('@mock/foo/bar'))
    try:
        assert(result('@mock/foo/bar') == '@mock/foo/bar')
    except AssertionError:
        print("Test 1 of function maybe_unfrack_path FAILED")
        print("Expected: @mock/foo/bar")
        print("Received: " + result('@mock/foo/bar'))
    else:
        print("Test 1 of function maybe_unfrack_path passed")


# Generated at 2022-06-10 22:03:03.042588
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    argv = ['--become-method', 'sudo', '--become-user', 'admin', '--become', '--ask-become-pass', '--ask-su-pass']
    args = parser.parse_args(argv)
    assert args.become == True
    assert args.become_method == 'sudo'
    assert args.become_user == 'admin'
    assert args.ask_become_pass == True
    assert args.become_ask_pass == True
    assert args.ask_su_pass == True


# Generated at 2022-06-10 22:03:10.855307
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='test_add_runas_options')
    add_runas_options(parser)
    options = vars(parser.parse_args('-b --become-method su --become-user foo'.split()))

    assert options['become'] is True
    assert options['become_method'] == 'su'
    assert options['become_user'] == 'foo'



# Generated at 2022-06-10 22:03:22.471910
# Unit test for function ensure_value
def test_ensure_value():
    class N(object): pass
    n = N()
    assert not hasattr(n, 'foo')
    assert ensure_value(n, 'foo', 'bar') is n.foo
    assert n.foo == 'bar'
    assert ensure_value(n, 'foo', 'baz') is n.foo
    assert n.foo == 'bar'



# Generated at 2022-06-10 22:03:33.188670
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        pass
    namespace = Namespace()
    assert ensure_value(namespace, 'foo1', 'bar1') == 'bar1'
    assert ensure_value(namespace, 'foo2', ['bar2']) == ['bar2']
    assert ensure_value(namespace, 'foo3', {}) == {}
    assert ensure_value(namespace, 'foo1', None) == 'bar1'
    assert ensure_value(namespace, 'foo2', None) == ['bar2']
    assert ensure_value(namespace, 'foo3', None) == {}

usage = '''
%(prog)s [options]

Show Ansible version.'''



# Generated at 2022-06-10 22:03:46.464067
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = maybe_unfrack_path('@')('@/tmp/ansible_test')
    assert path == '@{0}'.format(unfrackpath('/tmp/ansible_test'))
    path = maybe_unfrack_path('@@')('@@{0}/ansible_test'.format(C.DEFAULT_REMOTE_TMP))
    assert path == '@@{0}/ansible_test'.format(unfrackpath(C.DEFAULT_REMOTE_TMP))
    path = maybe_unfrack_path('@@')('@@/tmp/ansible_test')
    assert path == '@@{0}'.format(unfrackpath('/tmp/ansible_test'))
    path = maybe_unfrack_path('@@')('/tmp/ansible_test')

# Generated at 2022-06-10 22:03:51.643418
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@test') == '@' + unfrackpath('test')
    assert maybe_unfrack_path('@')('test') == 'test'
    assert maybe_unfrack_path('@')('@/test') == '@/test'
    assert maybe_unfrack_path('@')('@/test/') == '@' + unfrackpath('/test')



# Generated at 2022-06-10 22:03:57.314427
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = '/home/ansible/config'
    beacon = '@'
    unfrackpath_path = maybe_unfrack_path(beacon)(beacon+path)
    assert path == unfrackpath_path, unfrackpath_path
    assert unfrackpath_path != beacon + path


# Generated at 2022-06-10 22:04:03.396979
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = SortingHelpFormatter()
    parser.add_argument('--zzz')
    parser.add_argument('--aaa')
    usage = parser.format_help()
    assert '--aaa' in usage
    assert usage.find('--aaa') < usage.find('--zzz')
    parser = SortingHelpFormatter()
    parser.add_argument('--aaa')
    parser.add_argument('--zzz')
    usage = parser.format_help()
    assert '--aaa' in usage
    assert usage.find('--aaa') < usage.find('--zzz')



# Generated at 2022-06-10 22:04:15.037997
# Unit test for function unfrack_path
def test_unfrack_path():
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    os.environ['ANSIBLE_SECRETS'] = '/etc/ansible/secrets.yml'
    os.environ['ANSIBLE_DATA_DIR'] = '/etc/ansible/data'
    os.environ['ANSIBLE_SSH_DIR'] = '/etc/ansible/ssh'
    os.environ['ANSIBLE_PLUGIN_DIR'] = '/etc/ansible/plugins'
    os.environ['ANSIBLE_ROLES_PATH'] = '/etc/ansible/roles:/var/lib/awx/projects/_8__ansible-for-tests__/roles'
    os.environ['ANSIBLE_LIBRARY'] = '/etc/ansible/lib'
    os.en

# Generated at 2022-06-10 22:04:16.678410
# Unit test for function version
def test_version():
    assert version().startswith(__version__)
    assert version(prog="ansible-console")



# Generated at 2022-06-10 22:04:22.982744
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    try:
        os.chdir('/home/thecafeloaf/')
    except OSError as e:
        print("Could not change to /home/thecafeloaf " + str(e))

    test_string = "thecafeloaf"
    test_path = "/home/thecafeloaf/fakefile.txt"

    assert(maybe_unfrack_path(test_string)('/' + test_string + test_path) == test_string + "/home/thecafeloaf/fakefile.txt")
    assert(maybe_unfrack_path(test_string)('~' + test_string + test_path) == test_string + "/home/thecafeloaf/fakefile.txt")

# Generated at 2022-06-10 22:04:32.986225
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfrack_path_beacon = '@'
    unfrack_path_value = '~/config'
    beacon_value = maybe_unfrack_path(unfrack_path_beacon)(unfrack_path_value)
    assert beacon_value == '@' + unfrackpath(unfrack_path_value)
    no_beacon_value = maybe_unfrack_path(unfrack_path_beacon)('@' + unfrack_path_value)
    assert no_beacon_value == '@' + unfrackpath(unfrack_path_value)



# Generated at 2022-06-10 22:04:49.219504
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('ansible.cfg') == unfrackpath('ansible.cfg')
    assert unfrack_path(pathsep=False)('-') == '-'
    assert unfrack_path(pathsep=True)('ansible.cfg') == [unfrackpath('ansible.cfg')]
    assert unfrack_path(pathsep=True)('/usr/share/ansible/:/usr/share/myansible/') == [unfrackpath('/usr/share/ansible/'), unfrackpath('/usr/share/myansible/')]
    assert unfrack_path(pathsep=True)('') == []


# Generated at 2022-06-10 22:04:58.033270
# Unit test for function unfrack_path
def test_unfrack_path():

    tempdir_tuple = tempfile.mkdtemp()
    tempdir = tempdir_tuple.replace('\\', '/')
    test_file = 'test_file.txt'
    test_path = '%s/%s' % (tempdir, test_file)

    def reset_env(var):
        if var in os.environ.keys():
            os.environ[var] = ''
        else:
            os.environ.update({var: ''})

    reset_env('ANSIBLE_CONFIG')


# Generated at 2022-06-10 22:05:07.217765
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('!')('!~/.ansible/tmp/') == '!~/.ansible/tmp/'
    assert maybe_unfrack_path('!')('!~/test') == '!~/test'
    assert maybe_unfrack_path('!')('~/.ansible/tmp/') == '~/.ansible/tmp/'
    assert maybe_unfrack_path('!')('~/test') == '~/test'
    assert maybe_unfrack_path('!')('!~\\repo/test') == '!~\\repo/test'
    assert maybe_unfrack_path('!')('~\\repo/test') == '~\\repo/test'


# Generated at 2022-06-10 22:05:16.835194
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('lib/') == 'lib/'
    assert unfrack_path(True)('lib/') == ['lib/']
    assert unfrack_path(True)('lib/:$HOME:/tmp') == ['lib/', '$HOME', '/tmp']
    assert unfrack_path()('$HOME') == '$HOME'
    if 'HOME' in os.environ:
        assert unfrack_path()('~') == os.path.expanduser('~')
    else:
        assert unfrack_path()('~') == '~'



# Generated at 2022-06-10 22:05:23.836686
# Unit test for function unfrack_path
def test_unfrack_path():
    with open(os.devnull, "w") as fdnull:
        old_stdout = sys.stdout
        sys.stdout = fdnull
        assert unfrack_path(False)("""./foo""") == """./foo"""
        assert unfrack_path(False)("""~/foo""") == os.path.expanduser("""~/foo""")
        assert unfrack_path(True)("""./foo:~/foo""") == """./foo:"""+os.path.expanduser("""~/foo""")
        sys.stdout = old_stdout


# Generated at 2022-06-10 22:05:31.283449
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # maybe_unfrack_path should preprend the path with a beacon if it
    # is not present and call unfrackpath on the test
    test_path = "~/.ansible/test"
    test_path_resolved = os.path.expanduser(test_path)
    beacon = "("
    unfrackpath_beacon = maybe_unfrack_path(beacon)(test_path)
    # beacon should not be added if already present
    assert unfrackpath_beacon == beacon + test_path_resolved
    unfrackpath_no_beacon = maybe_unfrack_path(beacon)(beacon + test_path)
    assert unfrackpath_no_beacon == beacon + test_path_resolved
    # if the utils path does not start with a beacon, the return value
    # should be

# Generated at 2022-06-10 22:05:35.731757
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    maybe_unfrack_path_func = maybe_unfrack_path('@')
    assert maybe_unfrack_path_func('@/foo') == '@' + unfrackpath('/foo')
    assert maybe_unfrack_path_func('@@/foo') == '@@/foo'
    assert maybe_unfrack_path_func('@foo') == '@foo'



# Generated at 2022-06-10 22:05:44.303590
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~/') == '~/'
    assert maybe_unfrack_path('~')('~/foo') == '~/foo'
    assert maybe_unfrack_path('~')('~root/foo') == '~root/foo'
    assert maybe_unfrack_path('~')('~/foo~/bar') == '~/foo~/bar'
    assert maybe_unfrack_path('~')('~/foo/~bar') == '~/foo/~bar'
    assert maybe_unfrack_path('~')('~/foo/~/bar') == '~/foo/~/bar'



# Generated at 2022-06-10 22:05:53.633944
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class DummyArgs(object):
        def __init__(self, option_strings=None):
            self.option_strings = option_strings
    actions = [DummyArgs(['-a']), DummyArgs(['-b', '--badger'])]
    f = SortingHelpFormatter()
    f.add_arguments(actions)
    assert f.item_help_func(actions[0])[0] == '-a'
    assert f.item_help_func(actions[1])[0] == '-b, --badger'


# Generated at 2022-06-10 22:06:01.405672
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    class Opts:
        ansible_config_file = '~/path/config.cfg'

    maybe_unfrack_path(beacon='@')(Opts)
    assert Opts.ansible_config_file == '@' + unfrackpath('~/path/config.cfg')[1:]

    class Opts:
        ansible_config_file = '/path/config.cfg'

    maybe_unfrack_path(beacon='@')(Opts)
    assert Opts.ansible_config_file == '/path/config.cfg'



# Generated at 2022-06-10 22:06:28.338438
# Unit test for function unfrack_path
def test_unfrack_path():
    temp_dir1 = "/tmp/ansible_temp1"
    temp_dir2 = "/tmp/ansible_temp2/"
    temp_dir3 = "/tmp/ansible_temp3"

    # Test with a single directory
    assert unfrackpath(temp_dir1) == temp_dir1
    # Test with a single directory ending with a trailing slash
    assert unfrackpath(temp_dir2) == temp_dir2
    # Test with a set of directories separated by os.pathsep
    assert unfrack_path(True)("%s%s%s" % (temp_dir1, os.pathsep, temp_dir3)) == [temp_dir1, temp_dir3]
    # Test with a set of directories separated by os.pathsep, one with a trailing slash

# Generated at 2022-06-10 22:06:31.413179
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('ansible/roles') == unfrackpath('ansible/roles')
    assert unfrack_path(pathsep=True)('ansible/roles') == [unfrackpath(item) for item in ['ansible/roles']]

# Generated at 2022-06-10 22:06:34.022771
# Unit test for function unfrack_path
def test_unfrack_path():
    # Passing a single item
    assert unfrack_path()('hello') == unfrackpath('hello')

    # Passing a list
    assert unfrack_path(pathsep=True)('hello,world') == [unfrackpath('hello'), unfrackpath('world')]


# Generated at 2022-06-10 22:06:42.118463
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    from ansible.module_utils.parsing.convert_bool import boolean
    test_unfrack_path = maybe_unfrack_path('@')
    # Prefix the value string with '@'
    assert test_unfrack_path('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    # Prefix the value string with '@' and convert bool
    assert test_unfrack_path(boolean('@yes')) == '@' + 'yes'
    # Don't prefix the value string with '@' and convert bool
    assert test_unfrack_path(boolean('no')) == unfrackpath('no')


# Generated at 2022-06-10 22:06:49.937499
# Unit test for function unfrack_path
def test_unfrack_path():
    # Expected True
    assert unfrack_path()(".") == unfrackpath(".")
    assert unfrack_path()("./test/") == unfrackpath("./test/")
    assert unfrack_path()("test/test/test") == unfrackpath("test/test/test")
    assert unfrack_path()("test/*/test") == unfrackpath("test/*/test")
    assert unfrack_path()("test/~/test") == unfrackpath("test/~/test")

    # Expected False
    assert unfrack_path()("test/../test") == unfrackpath("test/../test")
    assert unfrack_path()("../test/test") == unfrackpath("../test/test")



# Generated at 2022-06-10 22:06:56.370282
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/path/to/file') == '/path/to/file'
    assert unfrack_path(pathsep=True)('/path/to/file') == ['/path/to/file']
    assert unfrack_path(pathsep=True)('/path/to/file1,/path/to/file2') == ['/path/to/file1', '/path/to/file2']



# Generated at 2022-06-10 22:07:05.198639
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo.cfg') == 'foo.cfg'
    assert unfrack_path()('~/foo.cfg') == '~/foo.cfg'
    assert unfrack_path()('/tmp/foo.cfg') == '/tmp/foo.cfg'
    assert unfrack_path()('~/foo.cfg/bar') == '~/foo.cfg/bar'
    assert unfrack_path(pathsep=True)('~/foo.cfg/bar:/tmp/baz.cfg') == ['~/foo.cfg/bar', '/tmp/baz.cfg']


# Generated at 2022-06-10 22:07:15.906778
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@@@/some/path') == '@@@some/path'
    assert maybe_unfrack_path('@')('@/some/path') == '@some/path'
    assert maybe_unfrack_path('@')('@some/path') == '@some/path'
    assert maybe_unfrack_path('@')('@/some/./path') == '@some/./path'
    assert maybe_unfrack_path('@')('@@@/some/./path') == '@@@some/./path'
    assert maybe_unfrack_path('@')('@some/./path') == '@some/./path'

#
# Utility functions for handling configuration
#

# Generated at 2022-06-10 22:07:19.122267
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp') == '@' + os.path.abspath('/tmp')
    assert maybe_unfrack_path('@')('/tmp') == '/tmp'



# Generated at 2022-06-10 22:07:29.117643
# Unit test for function version
def test_version():
    sys.argv[0] = 'ansible-console'