

# Generated at 2022-06-10 21:59:03.117238
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_async_options(parser)

    args = parser.parse_args(['-B', '60', '-P', '30'])
    assert args.seconds == 60
    assert args.poll_interval == 30


# Generated at 2022-06-10 21:59:06.852300
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/')('/~/playbooks') == '/playbooks'
    assert maybe_unfrack_path('/')('/playbooks') == '/playbooks'



# Generated at 2022-06-10 21:59:13.607666
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from ansible.utils.display import Display
    from unit.mock.argparse import MockArgumentParser
    display = Display()
    parser = MockArgumentParser(None, None, None, display, 'test', True)
    add_runas_prompt_options(parser)
    assert parser.args['become_ask_pass'] == C.DEFAULT_BECOME_ASK_PASS
    assert parser.args['become_password_file'] == C.BECOME_PASSWORD_FILE



# Generated at 2022-06-10 21:59:15.785959
# Unit test for function add_inventory_options
def test_add_inventory_options():
    """Function to test add_inventory_options function"""
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'test_inventory1', '--inventory', 'test_inventory2', '--list-hosts', '-l', 'test_subset'])
    print(args)



# Generated at 2022-06-10 21:59:16.318949
# Unit test for function add_output_options
def test_add_output_options():
    add_output_options(ArgumentParser())


# Generated at 2022-06-10 21:59:23.600864
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)("file.yaml") == ['/usr/share/ansible/file.yaml']
    assert unfrack_path(True)("/usr/share/ansible/file.yaml") == ['/usr/share/ansible/file.yaml']
    assert unfrack_path(True)("/usr/share/ansible/file.yaml:file2.yaml") == ['/usr/share/ansible/file.yaml', '/usr/share/ansible/file2.yaml']



# Generated at 2022-06-10 21:59:33.243437
# Unit test for function add_output_options
def test_add_output_options():
    from ansible.cli.arguments import OptionParser

    opts = OptionParser(None, None, usage="", connect_opts=False,
                        meta_opts=False, runas_opts=False,
                        subset_opts=False, check_opts=False,
                        vault_opts=False, fork_opts=False,
                        module_opts=False, async_opts=False,
                        output_opts=True)

    assert opts.parser._actions[-1].dest == 'one_line'
    assert opts.parser._actions[-2].dest == 'tree'



# Generated at 2022-06-10 21:59:35.041887
# Unit test for function add_meta_options
def test_add_meta_options():
    assert create_base_parser(prog="test_prog")



# Generated at 2022-06-10 21:59:42.402884
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'localhost:43','--list-hosts', '-l', 'localhost'])
    assert args.inventory == ['localhost:43']
    assert args.listhosts == True
    assert args.subset == 'localhost'


# Generated at 2022-06-10 21:59:51.000901
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options = parser.parse_args()
    assert options.check is False
    assert options.diff is True
    assert options.syntax is False
    options = parser.parse_args(['-C'])
    assert options.check is True
    options = parser.parse_args(['--syntax-check'])
    assert options.syntax is True
# Unit test end



# Generated at 2022-06-10 22:00:08.237847
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    base_group = parser.add_mutually_exclusive_group()
    assert base_group == parser.add_mutually_exclusive_group()


# Generated at 2022-06-10 22:00:12.091194
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    return parser
    # function_test(test_add_meta_options)



# Generated at 2022-06-10 22:00:13.074172
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass


# Generated at 2022-06-10 22:00:15.464100
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert parser.parse_args(['-b', '--become-method', 'su', '--become-user', 'some_user']) == \
           argparse.Namespace(become=True, become_method='su', become_user='some_user')



# Generated at 2022-06-10 22:00:24.141882
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    values=[1,2,3]
    dest='test'
    namespace='test'
    option_string=None
    arg1=PrependListAction(option_strings=['test'],dest=dest,nargs=1,const=None, default=None, type=None,
                 choices=None, required=False, help=None, metavar=None)
    result=arg1.__call__(namespace, namespace, values, option_string)
    assert result is None



# Generated at 2022-06-10 22:00:27.087452
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)



# Generated at 2022-06-10 22:00:34.172027
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = "~/roles"
    test_home = "/home/test_user"

    expanded_path = unfrackpath(path, test_home)
    expected_path = os.path.join(test_home, 'roles')
    assert expected_path == expanded_path

    expanded_path_beacon = maybe_unfrack_path("@")(path)
    assert expanded_path_beacon == '@' + expected_path



# Generated at 2022-06-10 22:00:45.965145
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible/roles') == '/etc/ansible/roles'
    assert unfrack_path()('/etc/ansible/roles/') == '/etc/ansible/roles'
    assert unfrack_path()('etc/ansible/roles/') == os.path.join(os.getcwd(), 'etc/ansible/roles')
    assert unfrack_path()('roles') == os.path.join(os.getcwd(), 'roles')
    assert unfrack_path()('roles/') == os.path.join(os.getcwd(), 'roles')
    assert unfrack_path()('roles/r1') == os.path.join(os.getcwd(), 'roles/r1')

# Generated at 2022-06-10 22:00:48.952704
# Unit test for function add_connect_options
def test_add_connect_options():
    """
    Unit test function for add_connect_options() in cli/cli.py
    """
    import unittest

    # TODO


# Generated at 2022-06-10 22:00:53.177793
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = '+'
    assert maybe_unfrack_path(beacon)('+' + os.path.join('foo', 'bar')) == '+' + unfrackpath(os.path.join('foo', 'bar'))
    assert maybe_unfrack_path(beacon)('+foobar') == '+foobar'



# Generated at 2022-06-10 22:01:11.475924
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class Namespace(object):
        def __init__(self):
            self.var1 = ['one', 'two', 'three']

    expected = ['four', 'five', 'six', 'one', 'two', 'three']
    input_values = ['four', 'five', 'six']
    parser = argparse.ArgumentParser(prog='test', add_help=False)
    parser.add_argument('--var1', action=PrependListAction, dest='var1')
    args = parser.parse_args(['--var1', 'four', 'five', 'six'], Namespace())
    if args.var1 == expected:
        pass
    else:
        print('Values do not match')

# Generated at 2022-06-10 22:01:13.231048
# Unit test for function add_connect_options
def test_add_connect_options():
    mock_parser = argparse.ArgumentParser()
    add_connect_options(mock_parser)

# Generated at 2022-06-10 22:01:15.298149
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)



# Generated at 2022-06-10 22:01:20.983615
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(["-u", "foo"])
    assert args.remote_user == "foo"
    args = parser.parse_args(["-u", "foo", "--user", "bar"])
    assert args.remote_user == "bar"



# Generated at 2022-06-10 22:01:26.088108
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('foo') == unfrackpath('foo')
    assert unfrack_path(pathsep=True)('foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('foo') == [unfrackpath('foo')]



# Generated at 2022-06-10 22:01:33.268798
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog="Test")
    add_connect_options(parser)
    options = parser.parse_args(["-c", "winrm", "--private-key", "~/.ssh/id_rsa", "-u", "testuser", "-T", "10"])
    assert options.connection == "winrm"
    assert options.private_key_file == "~/.ssh/id_rsa"
    assert options.remote_user == "testuser"
    assert options.timeout == 10

# Generated at 2022-06-10 22:01:37.264267
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(sys.argv[0]))
    print(ansible_version)
#
# load module code only after check for ansible_version
#
from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-10 22:01:42.657538
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    fake_beacon = '@FAKE_BEACON@/'
    x = '@@FAKE_BEACON@@/not_a_real_file'
    res = maybe_unfrack_path(fake_beacon)(x)
    assert res == '@FAKE_BEACON@/not_a_real_file'
    assert maybe_unfrack_path(fake_beacon)('not_a_beacon') == 'not_a_beacon'



# Generated at 2022-06-10 22:01:49.923449
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    argv = '''-t first -t second --skip-tags first
              --skip-tags second --tags first --tags second'''.split()
    actual = parser.parse_args(argv)
    expected = argparse.Namespace(
        skip_tags=['first', 'second'],
        tags=['first', 'second'],
    )
    assert expected.__dict__ == actual.__dict__



# Generated at 2022-06-10 22:01:53.685723
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp') == '@/tmp'
    assert maybe_unfrack_path('@')('/tmp') == '/tmp'


# Generated at 2022-06-10 22:02:01.206160
# Unit test for function version
def test_version():
    # This is not really testable, but at least make sure the code doesn't
    # blow up.
    version() == version()

# Generated at 2022-06-10 22:02:06.408229
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class Parser(object):
        def error(self, msg):
            pass
    parser = Parser()
    namespace = argparse.Namespace()
    arg_action = PrependListAction('--foo-bar', 'foo_bar', nargs=2, default=[4,5,6])
    arg_action(parser, namespace, [1,2,3], '--foo-bar')
    assert namespace.foo_bar == [1,2,3,4,5,6]


# Generated at 2022-06-10 22:02:15.233875
# Unit test for function unfrack_path
def test_unfrack_path():
    assert len(unfrackpath('')) == 0
    for pathsep in [os.pathsep, ':']:
        assert len(unfrack_path(pathsep=True)(pathsep.join(['', '', '']))) == 0
        assert len(unfrack_path(pathsep=True)(pathsep.join(['', 'foo', '']))) == 1
        assert len(unfrack_path(pathsep=True)(pathsep.join(['', 'foo', 'bar']))) == 2
        assert len(unfrack_path(pathsep=True)(pathsep.join(['', 'foo', 'foo']))) == 2
        assert len(unfrack_path(pathsep=True)(pathsep.join(['foo', 'foo']))) == 2
        assert len

# Generated at 2022-06-10 22:02:27.593981
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction)
    parser.add_argument('--bar', action=PrependListAction, nargs='*')
    parser.add_argument('--baz', action=PrependListAction, nargs='?')
    parser.add_argument('--spam', action=PrependListAction, nargs=2)


# Generated at 2022-06-10 22:02:40.265405
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(':')('') == ''
    assert maybe_unfrack_path('~')('~/') == '~/'
    assert maybe_unfrack_path(':')(':/') == ':/'
    assert maybe_unfrack_path(':')(':~') == ':%s' % os.path.expanduser('~')
    assert maybe_unfrack_path(':')(':~/') == ':%s' % os.path.expanduser('~')
    assert maybe_unfrack_path(':')(':/tmp') == ':/tmp'
    assert maybe_unfrack_path(':')(':~/tmp') == ':%s/tmp' % os.path.expanduser('~')


# Generated at 2022-06-10 22:02:52.180638
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class TestClass(object):
        def __init__(self, v1, v2):
            self.v1 = v1
            self.v2 = v2
        def __repr__(self):
            return "TestClass(v1={}, v2={})".format(self.v1, self.v2)
    def test_case(const, nargs, value_1, value_2, expected):
        arg_strings = ["-a"]
        dest = "attrib"
        type = TestClass
        action = PrependListAction(arg_strings, dest, const=const, nargs=nargs, type=type)
        namespace = argparse.Namespace()
        action(None, namespace, [value_1, value_2], "-a")
        actual = getattr(namespace, "attrib")
       

# Generated at 2022-06-10 22:02:59.859286
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    try:
        parser = argparse.ArgumentParser(description='Unit test for AnsibleVersion')
        parser.add_argument('--ansible-version', dest='ansible_version', action=AnsibleVersion, required=False)
        args = parser.parse_known_args()[0]
        args.ansible_version
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-10 22:03:04.767486
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test for presence of unfrackpth
    my_path = '/path/to/file'
    assert (my_path != maybe_unfrack_path('@')('@%s' % my_path)), \
        "Test failed! Maybe_unfrack_path failed to return the original path when a @ symbol was appended"
    # Test for absence of unfrackpath
    my_other_path = '/other/path'
    assert (my_other_path == maybe_unfrack_path('@')(my_other_path)), \
        "Test failed! Maybe_unfrack_path failed to pass through the path when no @ symbol was appended"



# Generated at 2022-06-10 22:03:16.006012
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('-a')
    arg_parser.add_argument('-b')
    arg_parser.add_argument('-c')
    arg_parser.add_argument('foo')

    txt = arg_parser.format_help()
    assert txt.startswith('usage: ')
    assert txt.count('-a') == 1
    assert txt.count('-b') == 1
    assert txt.count('-c') == 1
    assert txt.count('foo') == 1
    lines = txt.split()
    print(lines)
    assert lines[14] == '-a'
    assert lines[16] == '-b'
    assert lines[18] == '-c'
    assert lines[20]

# Generated at 2022-06-10 22:03:22.112299
# Unit test for function version
def test_version():
    import sys
    import unittest
    import warnings
    from ansible.module_utils.common.version import AnsibleVersion, __version__
    class TestVersion(unittest.TestCase):
        def setUp(self):
            self.orig_version = sys.version
            self.orig_prog = sys.argv[0]

        def tearDown(self):
            sys.version = self.orig_version
            sys.argv[0] = self.orig_prog

        def test_version(self):
            ver = version()
            self.assertTrue(type(ver) is str)
            self.assertTrue('config file = ' in ver)
            self.assertTrue('configured module search path = ' in ver)
            self.assertTrue('ansible python module location = ' in ver)

# Generated at 2022-06-10 22:03:36.892081
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp') == '@' + os.path.abspath('/tmp')
    assert maybe_unfrack_path('@')('@@/tmp') == '@@/tmp'


# Generated at 2022-06-10 22:03:42.209455
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'AnsibleVersion'
    parser.add_argument('-V', '--version', action=AnsibleVersion)
    arg_values = parser.parse_args(['-V'])

#
# Common Parser Factory stuff
#

# Generated at 2022-06-10 22:03:46.723393
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(False)('/etc/ansible/') == '/etc/ansible'
    assert unfrack_path(True)('/etc/ansible/:/tmp') == ['/etc/ansible','/tmp']


# Generated at 2022-06-10 22:03:53.707026
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path_result = unfrack_path(pathsep=True)
    assert unfrack_path_result("/dummy/path") == ['/dummy/path']
    assert unfrack_path_result("/dummy/path:/dummy/path2") == ['/dummy/path', '/dummy/path2']
    assert unfrack_path_result("/dummy/path:/dummy/path2:") == ['/dummy/path', '/dummy/path2']
    assert unfrack_path_result("/dummy/path::/dummy/path2") == ['/dummy/path', '/dummy/path2']
    assert unfrack_path_result("/dummy/path::/dummy/path2:") == ['/dummy/path', '/dummy/path2']
    assert unf

# Generated at 2022-06-10 22:04:03.163531
# Unit test for function unfrack_path
def test_unfrack_path():
    #from os.path import join, dirname, realpath, normpath, abspath
    #from lib.ansible.cli import __file__ as cli_file
    NORM_CLI_FILE = '/path/to/cli.py'
    #assert normpath(abspath(join(dirname(realpath(cli_file)), '../lib/ansible/cli.py'))) == NORM_CLI_FILE
    # Wrap it in a list
    NORM_CLI_FILE = [NORM_CLI_FILE]
    #print("NORM_CLI_FILE: %s" % NORM_CLI_FILE)
    # Verify that the path is always valid
    assert unfrack_path()(NORM_CLI_FILE[0]) == NORM_CLI_FILE[0]
    assert unfrack_

# Generated at 2022-06-10 22:04:14.871544
# Unit test for function version
def test_version():
    """
    This is a unit test for the version function.
    """
    # bug_17399
    import sys
    import platform
    import time
    from ansible import constants as C
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 1

    # Test 1: Check version output when no program name is given
    result = version()
    assert result.startswith(__version__), "Version is not starting with '%s'" % __version__

    # Test 2: Check version output when a program name is given
    prog = 'test_version'
    result = version(prog)
    assert result.startswith("test_version"), "Version is not starting with program name 'test_version'"

# Generated at 2022-06-10 22:04:19.303569
# Unit test for function ensure_value
def test_ensure_value():
    m = argparse.Namespace()
    assert ensure_value(m, 'name', 123) == 123
    assert m.name == 123
    assert ensure_value(m, 'name2', 456) == 456
    assert m.name2 == 456
    assert ensure_value(m, 'name', 789) == 123
    assert m.name == 123


#
# OptionsParser
#

# Generated at 2022-06-10 22:04:25.889809
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    # Doesn't check paths exist
    assert unfrack_path()('/foo/bar/baz') == '/foo/bar/baz'

    assert unfrack_path(pathsep=True)('bar:baz') == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-10 22:04:36.319638
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ['', '', ''] == unfrack_path(True)('')
    assert ['', '', '/tmp/myfile'] == unfrack_path(True)(' /tmp/myfile')
    assert ['', '', '/tmp/myfile'] == unfrack_path(True)(' /tmp/myfile:')
    assert ['', '', '/tmp/myfile'] == unfrack_path(True)(' /tmp/myfile: ')
    assert ['', '', '/tmp/myfile', '/tmp/myfile2'] == unfrack_path(True)(' /tmp/myfile: /tmp/myfile2')
    assert ['', '', '/tmp/myfile', '/tmp/myfile2'] == unfrack_path(True)(' /tmp/myfile:: /tmp/myfile2::')
    assert '-' == unfrack_

# Generated at 2022-06-10 22:04:48.382775
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/usr/new/') == '@' + unfrackpath('/usr/new')
    assert maybe_unfrack_path('@')('@/usr/new') == '@' + unfrackpath('/usr/new')
    assert maybe_unfrack_path('@')('@/usr/new/') == '@' + unfrackpath('/usr/new')
    assert maybe_unfrack_path('@')('@@/usr/new/') == maybe_unfrack_path('@')('@@/usr/new/')
    assert maybe_unfrack_path('@')('n@@/usr/new/') == maybe_unfrack_path('@')('n@@/usr/new/')
    assert maybe_unfr

# Generated at 2022-06-10 22:05:09.740241
# Unit test for function unfrack_path
def test_unfrack_path():
    assert os.path.isabs(unfrack_path()(u'/path/to/module'))
    # unfrack_path('-') returned '-' as is, but it should be normalized to an absolute path
    assert os.path.isabs(unfrack_path()(u'-'))
    assert os.path.isabs(unfrack_path()(u'~/path/to/file'))
    assert os.path.isabs(unfrack_path()(u'~/path/to/file/'))
    assert os.path.isabs(unfrack_path()(u'~/path/to/file//'))
    assert os.path.isabs(unfrack_path()(u'~/ansible/module/file'))

# Generated at 2022-06-10 22:05:22.608961
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass

    # Create the option parser and feed it some lines from the
    # output of ``my_program --help``.
    parser = argparse.ArgumentParser(description='a test app', fromfile_prefix_chars='@')
    parser.add_argument('-a', action=PrependListAction)
    parser.add_argument('-b', action=PrependListAction, nargs=2)
    parser.add_argument('-c', action=PrependListAction, nargs='+')
    parser.add_argument('-d', action=PrependListAction, nargs='*')
    args = parser.parse_args('-a a -b b1 b2 -c c1 c2 c3 -d d1 d2 d3 -a a2'.split())

    # Verify the results.

# Generated at 2022-06-10 22:05:30.862298
# Unit test for function version
def test_version():
    from ansible.constants import DEFAULT_MODULE_PATH
    # With a param, returns version info
    version("ansible-test")
    assert version("ansible-test") is not None
    # Without a param, returns version
    assert version() == __version__
    # Check that the output contains at least the config path
    assert C.CONFIG_FILE in version("ansible-test")
    # Check that the output contains at least the configured module path
    assert DEFAULT_MODULE_PATH in version("ansible-test")
    # Check that the output contains the ansible python module location
    assert ansible.__path__[0] in version("ansible-test")
    # Check that the output contains the executable location
    assert sys.argv[0] in version("ansible-test")
    # Check that the output contains the

# Generated at 2022-06-10 22:05:33.044282
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass

# end class PrependListAction


#
# Common actions
#

# Generated at 2022-06-10 22:05:38.793789
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '/test_path'
    test_beacon = '/test_beacon'
    test_path_unfracked = maybe_unfrack_path(test_beacon)(test_beacon + test_path)
    assert test_path_unfracked == test_beacon + test_path



# Generated at 2022-06-10 22:05:44.405633
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    print('Test method __call__ for class PrependListAction')
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', '-t', action=PrependListAction, metavar='T')
    parser.print_help()
    ns = parser.parse_args(['-t1', '-t2', '-t3', '-t4'])
    assert ns.test == ['1', '2', '3', '4']



# Generated at 2022-06-10 22:05:47.506540
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print(maybe_unfrack_path('/')('/home/user/dir'))


# Generated at 2022-06-10 22:05:50.366353
# Unit test for function unfrack_path
def test_unfrack_path():
    """
    >>> test_unfrack_path()
    True
    """
    return True


# Generated at 2022-06-10 22:05:58.592817
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser(prog='test', add_help=False)
    parser.add_argument('--foo', action=PrependListAction, nargs='+')
    args = parser.parse_args(['--foo', 'bar', 'baz'])
    assert args.foo == ['bar', 'baz']

    try:
        parser.add_argument('--foo', action=PrependListAction)
        assert False
    except ValueError:
        assert True

    try:
        parser.add_argument('--foo', action=PrependListAction, nargs=0)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-10 22:06:04.043851
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    x = AnsibleVersion(option_strings='-v')
    parser = argparse.ArgumentParser(prog='ansible')
    y = x(parser, argparse.Namespace(), '', '-v')
    print (y)

# Generated at 2022-06-10 22:06:51.314909
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-10 22:06:55.070451
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    f = maybe_unfrack_path('@')
    assert f('@~/foo') == '@%s/foo' % os.path.expanduser('~')



# Generated at 2022-06-10 22:07:06.557559
# Unit test for function version
def test_version():
    # Prep a bunch of junk, so we can test all the infos
    basedir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))

    repo_path = os.path.join(basedir, '.git')

# Generated at 2022-06-10 22:07:17.980703
# Unit test for function version
def test_version():
    """
    Unit test: ansible.cli.CLI.version
    """
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils import get_module_path
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFact
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import WindowsDistributionFactory

# Generated at 2022-06-10 22:07:25.267884
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('./foo') == './foo'
    assert unfrack_path()('/bar') == '/bar'
    assert unfrack_path()('~baz') == os.path.expanduser('~baz')
    assert unfrack_path()('<foo') == '<foo'
    assert sorted(unfrack_path(pathsep=True)('./foo:/bar:~baz:<foo')) == sorted(['./foo', '/bar', os.path.expanduser('~baz'), '<foo'])
    assert unfrack_path()('-') == '-'

# Generated at 2022-06-10 22:07:38.715365
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.module_utils.common.parameters import config_file
    from ansible.module_utils.common.parameters import display
    from ansible.module_utils.common.parameters import env_fallback
    from ansible.module_utils.common.parameters import module_common_argspec
    from ansible.module_utils.common.parameters import option_helpers
    from ansible.module_utils.common.parameters import remove_unchanged_default_params
    from ansible.module_utils.common.parameters import strip_internal_keys
    from ansible.module_utils.common.parameters import strip_nones_from_return
    from ansible.module_utils.common.parameters import fail_on_undefined_args
    from ansible.module_utils.common.parameters import module_params

# Generated at 2022-06-10 22:07:45.324142
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = ['NARGS=']
    dest = 'nargs'
    nargs = 40
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = None
    metavar = None
    parser = argparse.ArgumentParser(description="test_PrependListAction___call__()")
    action = PrependListAction(option_strings, dest, nargs, const, default, type, choices, required, help, metavar)
    action.__call__(parser, namespace=argparse.Namespace(), values=['test'], option_string=None)
    print(parser.__dict__)



# Generated at 2022-06-10 22:07:55.979149
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from tempfile import TemporaryDirectory
    from ansible.cli.arguments import AnsibleOptions
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    display = Display()
    option_string = None
    parser = argparse.ArgumentParser(description="This is a test")
    parser.add_argument('--test_value', action=PrependListAction)
    namespace = argparse.Namespace(test_value=[])
    parser.parse_args(['--test_value', '123'], namespace=namespace)

# Generated at 2022-06-10 22:08:02.523222
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    maybe_ufp = maybe_unfrack_path('@')

    assert maybe_ufp('@foo') == '@foo'
    assert maybe_ufp('@@foo') == '@foo'
    assert maybe_ufp('foo') == 'foo'

    assert maybe_ufp('@/foo') == '@/foo'
    assert maybe_ufp('@./foo') == '@foo'
    assert maybe_ufp('@/foo/bar') == '@/foo/bar'
    assert maybe_ufp('@./foo/bar') == '@foo/bar'
    assert maybe_ufp('@././foo/bar/') == '@foo/bar/'
    assert maybe_ufp('@./././foo/bar/') == '@foo/bar/'

# Generated at 2022-06-10 22:08:07.614399
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    test_data = [
        ('@/test/file.yml', '@./test/file.yml'),
        ('@./test/file.yml', '@./test/file.yml'),
    ]

    for (source, dest) in test_data:
        assert dest == maybe_unfrack_path('@')(source)

#
# ArgumentParser for subcommands
#

