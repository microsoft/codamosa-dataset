

# Generated at 2022-06-10 21:58:38.076823
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print(maybe_unfrack_path('@')('@/malformed/path'))
    print(maybe_unfrack_path('@')('/valid/path'))
    print(maybe_unfrack_path('@')('@~/malformed/path'))


# Generated at 2022-06-10 21:58:49.398168
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~') == os.path.realpath(os.path.expanduser('~'))
    if os.path.isabs('/'):
        test_abs = '/'
    else:
        test_abs = 'c:\\'
    assert unfrack_path()(test_abs) == test_abs
    assert unfrack_path()(os.getcwd()) == os.getcwd()
    assert unfrack_path()('.') == os.getcwd()
    assert unfrack_path()('./') == os.path.join(os.getcwd(), './')

# Generated at 2022-06-10 21:58:52.281505
# Unit test for function add_output_options
def test_add_output_options():
    """Test add_output_options"""
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    parsed_args = parser.parse_args("-o".split())
    assert parsed_args.one_line



# Generated at 2022-06-10 21:58:54.463146
# Unit test for function add_check_options
def test_add_check_options():
    parser = add_check_options('')
    assert parser.check == 'I am here'

# Generated at 2022-06-10 21:59:01.631831
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    prepend_list_action = PrependListAction(option_strings=['--tags'], dest='tags', nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)
    parser = argparse.ArgumentParser()
    namespace = argparse.Namespace()
    values = ['value']
    prepend_list_action.__call__(parser=parser, namespace=namespace, values=values)


# Generated at 2022-06-10 21:59:06.853109
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path('yes')('/tmp/a:/tmp/b:/tmp/c') == ['/tmp/a', '/tmp/b', '/tmp/c']
    assert unfrack_path('no')('one') == 'one'
    assert unfrack_path(False)('-') == '-'


# Generated at 2022-06-10 21:59:20.500403
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog='ansible-connection-test',
        formatter_class=SortingHelpFormatter,
    )
    add_connect_options(parser)
    options = parser.parse_args(['--private-key', 'key.pem', '-u', 'user', '-c', 'local', '-T', '50',
                                 '--ssh-common-args', 'myproxy', '--sftp-extra-args', '-f', '--scp-extra-args', '-l', '--ssh-extra-args', '-R',
                                 '-k', '--connection-password-file', 'mypassword.txt'])

    assert not options.ask_pass
    assert options.connection_password_file == 'mypassword.txt'
    assert options.private_

# Generated at 2022-06-10 21:59:27.006498
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_meta_options(parser)
    (options, args) = parser.parse_known_args(['--force-handlers=False'])
    assert not options.force_handlers

# Generated at 2022-06-10 21:59:35.533419
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-10 21:59:37.590137
# Unit test for function version
def test_version():
    from ansible.module_utils.common import version
    test_version=version()
    assert "ansible" in str(test_version)

# Generated at 2022-06-10 22:00:11.608498
# Unit test for function add_subset_options
def test_add_subset_options():
    import doctest
    failed, total = doctest.testmod()
    if failed != 0:
        print(f"{total} tests failed")
    else:
        print(f"{total} tests passed")


test_add_subset_options()


# Generated at 2022-06-10 22:00:14.004854
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@foo') == '@/etc/ansible/foo'



# Generated at 2022-06-10 22:00:16.575149
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='test')
    ret = add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'sudo', '--become-user', 'root'])
    assert args.become is True
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'



# Generated at 2022-06-10 22:00:19.921510
# Unit test for function add_connect_options
def test_add_connect_options():
  from argparse import ArgumentParser
  parser = ArgumentParser(formatter_class=SortingHelpFormatter)
  add_connect_options(parser)
  parser.print_help()

test_add_connect_options()



# Generated at 2022-06-10 22:00:24.483800
# Unit test for function add_inventory_options
def test_add_inventory_options():
    obj = argparse.ArgumentParser(prog='ansible', usage="%(prog)s [options] [inventory-file] or -i [inventory-file] or --inventory-file=[inventory-file]", 
        description="The Ansible Inventory File can be specified as a single file, a directory or a list of either.  The format should be ini or yaml, it is recommended yaml format is used as it is more feature rich.  The inventory file can be specified as a CLI option and this overrides any other inventory file that may be present.", 
        epilog="For more information about Ansible, see https://ansible.com/.", 
        conflict_handler='resolve', 
        fromfile_prefix_chars='@', 
        argument_default=None)
    parser = obj

# Generated at 2022-06-10 22:00:31.561145
# Unit test for function add_connect_options
def test_add_connect_options():
    from six.moves import configparser

    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    result = parser.parse_args(['--private-key', '~/.ssh/id_rsa', '--ssh-common-args', 'ProxyCommand ssh -W %h:%p'])
    assert isinstance(result, argparse.Namespace)
    assert result.private_key_file == os.path.expanduser('~/.ssh/id_rsa')
    assert result.remote_user == C.DEFAULT_REMOTE_USER
    assert result.connection == C.DEFAULT_TRANSPORT
    assert result.timeout == C.DEFAULT_TIMEOUT
    assert result.ssh_common_args == 'ProxyCommand ssh -W %h:%p'
    assert result.sftp_

# Generated at 2022-06-10 22:00:44.192306
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/etc/ansible') == '/etc/ansible'
    assert unfrack_path(pathsep=False)('../etc/ansible') == '../etc/ansible'
    assert unfrack_path(pathsep=False)('../etc/../ansible') == '../ansible'
    assert unfrack_path(pathsep=False)('../etc/../ansible/../../bin') == '../../bin'
    assert unfrack_path(pathsep=False)('~/.ansible') == '~/.ansible'
    assert unfrack_path(pathsep=False)('~/.ansible/../../bin') == '~/../../bin'

# Generated at 2022-06-10 22:00:45.384034
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    assert parser.print_help()



# Generated at 2022-06-10 22:00:47.724450
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/usr/share/ansible/my_collection/') == '/usr/share/ansible/my_collection'


# Generated at 2022-06-10 22:00:52.108257
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/home/dibya') == '@' + unfrackpath('/home/dibya')
    assert maybe_unfrack_path('@')('/home/dibya/ansible') == '/home/dibya/ansible'


# Generated at 2022-06-10 22:01:10.196339
# Unit test for constructor of class SortingHelpFormatter

# Generated at 2022-06-10 22:01:21.069711
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path_test = unfrack_path()
    assert unfrack_path_test('/foo/bar') == '/foo/bar'
    assert unfrack_path_test('library') == os.path.join('.', 'library')
    assert unfrack_path_test('roles/library') == os.path.join('.', 'roles', 'library')
    assert unfrack_path_test('~/roles/library') == os.path.join(os.path.expanduser('~'), 'roles', 'library')
    assert unfrack_path_test('bar') == os.path.join('.', 'bar')
    assert unfrack_path_test('./bar') == os.path.join('.', 'bar')
    assert unfrack_path_test('./bar/') == os.path

# Generated at 2022-06-10 22:01:32.070817
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_args = ['-f', '-a', '-k', '-c', '-m', '-t']
    parser = argparse.ArgumentParser(prog='test_help_parser',
                                     formatter_class=SortingHelpFormatter,
                                     add_help=False)

    for arg in test_args:
        parser.add_argument(arg, action='store_true')

    help_text = parser.format_help()

# Generated at 2022-06-10 22:01:33.643875
# Unit test for function unfrack_path
def test_unfrack_path():
    # This function doesn't really make sense to unit test
    pass



# Generated at 2022-06-10 22:01:42.946635
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    examples = {
        "~/.ansible": "~/.ansible",
        "~/.ansible/callback_plugins": "~/.ansible/callback_plugins",
        "./callback_plugins": "./callback_plugins",
    }

    # Running in a folder that contains a 'callback_plugins' subfolder.
    thisdir = os.path.dirname(os.path.realpath(__file__))

    for example in examples:
        assert maybe_unfrack_path('~/.ansible')(example) == examples[example]
        assert maybe_unfrack_path('./callback_plugins')(example) == examples[example]
        assert maybe_unfrack_path(thisdir + '/callback_plugins')(example) == examples[example]

    # Testing the default beacon ('~/.ansible')
    assert maybe_

# Generated at 2022-06-10 22:01:53.251932
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    open_beacon = '@'
    parser = argparse.ArgumentParser(description='This is a unit test')
    parser.add_argument('--test-path', metavar='PATH', default=[], action='append', type=maybe_unfrack_path(open_beacon))
    options, args = parser.parse_known_args(['--test-path', open_beacon + 'roles/foo'])
    assert options.test_path == [open_beacon + 'roles/foo'], \
        "maybe_unfrack_path failed to unfrack PATH with prefix option of '%s' and value '%s'" % (open_beacon, options.test_path)
    return True


# Generated at 2022-06-10 22:01:55.499562
# Unit test for function ensure_value
def test_ensure_value():
    n = argparse.Namespace()
    assert ensure_value(n, 'a', []) == []
    assert ensure_value(n, 'a', []) is n.a

#
# Functions to build argument parsers
#


# Generated at 2022-06-10 22:02:02.781404
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == 'foo'
    assert unfrack_path(pathsep=True)('.') == ['.']
    assert unfrack_path(pathsep=True)('.' + os.pathsep) == ['.']
    assert unfrack_path(pathsep=True)('') == []
    assert unfrack_path(pathsep=True)('.' + os.pathsep + 'foo' + os.pathsep + 'bar') == ['.', 'foo', 'bar']



# Generated at 2022-06-10 22:02:04.186209
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-10 22:02:07.065916
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@/tmp") == "@" + unfrackpath("/tmp")
    assert maybe_unfrack_path("@")("/tmp") == "/tmp"



# Generated at 2022-06-10 22:02:14.786007
# Unit test for function unfrack_path
def test_unfrack_path():
    result = unfrack_path()('/etc/ansible/ansible.cfg')
    assert result == unfrackpath('/etc/ansible/ansible.cfg'), result



# Generated at 2022-06-10 22:02:23.860177
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('$')('$/foo/bar') == '$' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('$')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('$')('@/foo/bar') == '@/foo/bar'
    # No leading beacon
    assert maybe_unfrack_path('$')('foo/bar') == 'foo/bar'



# Generated at 2022-06-10 22:02:30.254487
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfracked_paths = ["~/ansible", "/home/user/ansible"]
    fracked_paths = ["~~/ansible", "~~~/ansible"]
    for fracked_path, unfracked_path in zip(fracked_paths, unfracked_paths):
        assert maybe_unfrack_path("~")(fracked_path) == unfracked_path
# test_maybe_unfrack_path()



# Generated at 2022-06-10 22:02:43.022260
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    if os.pathsep == ';':
        os_path = r'c:\\foo\\bar'
        yml_path = r'c:\foo\bar'
    else:
        os_path = r'/foo/bar'
        yml_path = r'/foo/bar'
    assert maybe_unfrack_path('@')('@' + yml_path) == '@' + os_path
    assert maybe_unfrack_path('@')('%' + yml_path) == '%' + yml_path
    assert maybe_unfrack_path('@')('@@' + yml_path) == '@@' + yml_path
    assert maybe_unfrack_path('@')('@' + 'foo') == '@' + 'foo'
    assert maybe_

# Generated at 2022-06-10 22:02:51.869563
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/filepath') == '@' + unfrackpath('/tmp/filepath')
    assert maybe_unfrack_path('@')('cat /tmp/filepath') == 'cat /tmp/filepath'
    assert maybe_unfrack_path('@@')('@@/tmp/filepath') == '@@' + unfrackpath('/tmp/filepath')
    assert maybe_unfrack_path('@@')('@@@/tmp/filepath') == '@@@/tmp/filepath'



# Generated at 2022-06-10 22:03:04.215537
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(beacon='@')('@/home/usr/test') == '@/home/usr/test'
    assert maybe_unfrack_path(beacon='@')('@test/test/test') == '@test/test/test'
    assert maybe_unfrack_path(beacon='@')('@./test') == '@./test'
    assert maybe_unfrack_path(beacon='@')('@@/test') == '@@/test'
    assert maybe_unfrack_path(beacon='@')('@/test') == '@/home/usr/test'
    assert maybe_unfrack_path(beacon='@')('test') == 'test'

# Generated at 2022-06-10 22:03:15.710756
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    data = '?'
    beacon = '?'
    assert data == maybe_unfrack_path(beacon)(data)
    data = '?/path/to/file'
    beacon = '?'
    assert '?/path/to/file' == maybe_unfrack_path(beacon)(data)
    data = '?/path/to/file'
    beacon = '?'
    assert '?/path/to/file' == maybe_unfrack_path(beacon)(data)
    data = '@/path/to/file'
    beacon = '@'
    assert '@/path/to/file' == maybe_unfrack_path(beacon)(data)
    data = '@@/path/to/file'
    beacon = '@@'
    assert '@@/path/to/file' == maybe

# Generated at 2022-06-10 22:03:18.818655
# Unit test for function version
def test_version():
    version_string = version("foo")
    assert "foo" in version_string
    assert __version__ in version_string
    assert sys.argv[0] in version_string
    assert ''.join(sys.version.splitlines()) in version_string



# Generated at 2022-06-10 22:03:24.704364
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(False)('/a/b') == '/a/b'
    assert unfrack_path(False)('/a/../c') == '/c'
    assert unfrack_path(True)('/a/b:/a/../c') == ['/a/b', '/c']



# Generated at 2022-06-10 22:03:32.722375
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert '@/home/joeuser' == maybe_unfrack_path('@')('@/home/joeuser')
    assert '@/home/joeuser' == maybe_unfrack_path('@')('@../joeuser')
    assert '@../joeuser' == maybe_unfrack_path('@')('@../joeuser')
    assert '~/joeuser' == maybe_unfrack_path('@')('~/joeuser')



# Generated at 2022-06-10 22:03:52.452136
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.release import __version__
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    if __version__.startswith('2.9') or __version__.startswith('2.10'):
        base_path = sys.prefix
    else:
        base_path = os.getcwd()
    unfrackpath_path = os.path.expanduser(C.DEFAULT_LOCAL_TMP)
    arg = '-a'
    assert unfrack_path()(arg) == arg
    arg = '-m'
    assert unfrack_path()(arg) == arg
    arg = '-a "ls -l"'
    assert unfrack_path()(arg) == arg
    arg = '-m "echo foo"'
    assert unf

# Generated at 2022-06-10 22:03:53.861002
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~/ansible') == os.path.expanduser('~/ansible')

# Generated at 2022-06-10 22:03:57.220032
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='ansible', conflict_handler='resolve')
    add_meta_options(parser)

    options = parser.parse_args(['--force-handlers', '--flush-cache'])

    assert options.force_handlers == True
    assert options.flush_cache == True

    options = parser.parse_args([])

    assert options.force_handlers == False
    assert options.flush_cache == False


# Generated at 2022-06-10 22:04:04.391709
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():

    args = ['-a', '-b', '-c']
    class FakeAction(object):
        def __init__(self, args):
            self.option_strings = args
    actions = [FakeAction(x) for x in args]

    # sort actions based on their option_string
    actions_1 = sorted(actions, key=operator.attrgetter('option_strings'))
    assert actions_1[0].option_strings == ['--a']
    assert actions_1[1].option_strings == ['--b']
    assert actions_1[2].option_strings == ['--c']

    # instantiate SortingHelpFormatter and call its _format_arguments()
    sf = SortingHelpFormatter(argparse.ArgumentDefaultsHelpFormatter)
    sf._add_item = lambda x,y: None

# Generated at 2022-06-10 22:04:12.886861
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    maybe_unfrack_path_test_data = [
        ('@/etc/file', '@/etc/file'),
        ('~/etc/file', '~/etc/file'),
        ('/etc/file', '/etc/file'),
        ('@spam/file', '@spam/file'),
        ('@/spam/file', '@/etc/spam/file'),
    ]
    for value, expected in maybe_unfrack_path_test_data:
        assert maybe_unfrack_path('@')(value) == expected

# Generated at 2022-06-10 22:04:21.169009
# Unit test for function version
def test_version():
    import pytest
    import ansible.constants as C
    import ansible.release as r
    C.AUTOMATION_TRACE_ONLY = True
    C.ANSIBLE_RELEASE = r.__version__
    C.ANSIBLE_VERSION = '2.8'

# Generated at 2022-06-10 22:04:33.703203
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_value = ['~/test/path', "~/test/with_tilde~", "/test/base_path/with_tilde~", "/test/base_path", "./test/base_path", "../test/base_path"]
    expected_value = ['~/test/path', "~/test/with_tilde~", "/test/base_path/with_tilde~", "/test/base_path", "./test/base_path", "../test/base_path"]

    for test in zip(test_value, expected_value):
        assert maybe_unfrack_path('~')(test[0]) == test[1], '%s does not equal expected %s' % (
            test[0], test[1])

# Generated at 2022-06-10 22:04:41.373751
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/usr/local/ansible/playbooks") == "/usr/local/ansible/playbooks"
    assert unfrack_path()("/usr/local/ansible/playbooks:test") == "/usr/local/ansible/playbooks:test"
    assert unfrack_path(pathsep=True)("/usr/local/ansible/playbooks:test") == ['/usr/local/ansible/playbooks', 'test']


# Generated at 2022-06-10 22:04:46.976815
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path('/usr/share/ansible:/etc/ansible') == ['/usr/share/ansible', '/etc/ansible']
    assert unfrack_path('-') == '-'
    assert unfrack_path('/etc/ansible') == '/etc/ansible'
    assert unfrack_path('/tmp') == '/tmp'



# Generated at 2022-06-10 22:04:53.332735
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_paths = ['/tmp/foo/bar', '@my_collection/my_module']
    maybe_unfrack_path_func = maybe_unfrack_path('@')

    for test_path in test_paths:
        result = maybe_unfrack_path_func(test_path)
        if test_path.startswith('@'):
            print("Success: {0}".format(result))
        else:
            print("Failure: {0}".format(result))

    # assert result == '@my_collection/my_module'

#test_maybe_unfrack_path()


# Generated at 2022-06-10 22:05:07.591537
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test1 = maybe_unfrack_path('@')
    assert test1('@test1') == '@/etc/ansible/test1'
    test2 = maybe_unfrack_path('@@')
    assert test2('@@test2') == '@@/etc/ansible/test2'



# Generated at 2022-06-10 22:05:13.026896
# Unit test for function unfrack_path
def test_unfrack_path():
    assert [unfrackpath('/etc/ansible')] == unfrack_path(pathsep=False)('/etc/ansible')
    assert [unfrackpath('/etc/ansible/foo')] == unfrack_path(pathsep=True)('/etc/ansible/foo')

# Generated at 2022-06-10 22:05:17.029373
# Unit test for function version
def test_version():
    assert version('foo').startswith('foo')
    assert version().startswith('ansible')
    # assert version().startswith('ansible 2.0')


#
# Return parsed command line options
#

# Generated at 2022-06-10 22:05:24.451538
# Unit test for function unfrack_path
def test_unfrack_path():
    test1 = unfrack_path()('/etc/ansible/facts.d')
    test2 = unfrack_path()('/etc/ansible/facts.d:/tmp/facts')
    assert test1 == unfrackpath('/etc/ansible/facts.d')
    assert test2 == [unfrackpath('/etc/ansible/facts.d'), unfrackpath('/tmp/facts')]


# Generated at 2022-06-10 22:05:31.440323
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    #Test Value
    test_string = ('@/etc/ansible/ansible.cfg,/etc/ansible/hosts')
    #Create a list of all values using the maybe_unfrack_path
    test_value = maybe_unfrack_path('@')(test_string)
    # Split the test value based on comma
    test_value = test_value.split(',')

    unfrackpath = unfrack_path()
    #Iterate and check for the correct value
    for i in test_value:
        # check for the first character, if it starts with @
        # then check for the abs path
        if i[0] == '@':
            i = i[1:]
        if not os.path.isabs(i):
            raise AssertionError('Unfracked path not absolute')
    return

# Generated at 2022-06-10 22:05:37.439012
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrackpath = unfrack_path()
    assert unfrackpath == unfrack_path()  # This does not actually test anything!!!
    # Test value=='-' is returned immediately
    assert unfrackpath('-') == '-'
    # Test os.path.expanduser is applied
    assert unfrackpath('~/') == os.path.expanduser('~/')
    # Test os.path.expanduser always returns a full path
    assert unfrackpath('~/.') == os.path.expanduser('~/.')
    # Test os.sep is used
    assert unfrackpath('~/.') == os.sep.join((os.path.expanduser('~'), '.'))



# Generated at 2022-06-10 22:05:43.041864
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = '/etc/ansible/examples'
    unfrack = maybe_unfrack_path('@')('@{0}'.format(path))
    assert unfrack == '@{0}'.format(unfrackpath(path))
    assert maybe_unfrack_path('@')('@/etc/ansible/examples') == '@/etc/ansible/examples'



# Generated at 2022-06-10 22:05:50.747127
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~') == '~'
    assert maybe_unfrack_path('~')('~/') == '~'
    assert maybe_unfrack_path('~')('~/something/path') == '~/something/path'
    assert maybe_unfrack_path('~')('~/something/path/') == '~/something/path'



# Generated at 2022-06-10 22:06:02.188988
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    tmp_parser = argparse.ArgumentParser()
    tmp_parser._positionals.title = '[Positional Arguments]'
    tmp_parser._optionals.title = '[Options]'
    tmp_parser.add_argument('foo', nargs='*')
    tmp_parser.add_argument('-a', '--alpha', default='a', type='str')
    tmp_parser.add_argument('-b', '--bravo', default='b', type='str')
    tmp_parser.add_argument('-c', '--charlie', default='c', type='str')
    tmp_parser.add_argument('-d', '--delta', default='d', type='str')

    output = tmp_parser.format_help()
    lines = [to_native(s) for s in output.splitlines()]
   

# Generated at 2022-06-10 22:06:09.157955
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')(u'@/path/') == u'@' + unfrackpath(u'/path/')
    assert maybe_unfrack_path('@')(u'/path/') == u'/path/'
    assert maybe_unfrack_path('@')(u'@~/path/') == u'@~/path/'

#
# Options and OptionGroups
#

# Generated at 2022-06-10 22:06:40.588055
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/path/to/file") == unfrackpath("/path/to/file")
    tmp_path = "/path/to/file"
    unfracked_path = unfrack_path()(tmp_path)
    assert unfracked_path.endswith("/path/to/file")
    # if set True, path must be separated by os.pathsep
    assert unfrack_path(pathsep=True)("foo/bar:/path/to/file:./baz") == [unfracked_path, "./baz"]



# Generated at 2022-06-10 22:06:48.092424
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    os.environ['HOME'] = '/bar'
    os.environ['FOO'] = '/foo'
    os.environ['BAZ'] = '/baz'
    assert maybe_unfrack_path(beacon='@')('@~') == '@/bar'
    assert maybe_unfrack_path(beacon='@')('@$FOO') == '@/foo'
    assert maybe_unfrack_path(beacon='@')('@$BAZ@$BAZ') == '@/baz@/baz'



# Generated at 2022-06-10 22:06:55.279428
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('#beacon#')('#beacon#' + unfrackpath('#beacon#/path/to/file')) == '#beacon#' + unfrackpath('#beacon#/path/to/file')
    assert maybe_unfrack_path('#beacon#')('#nobeacon#/path/to/file') == '#nobeacon#/path/to/file'



# Generated at 2022-06-10 22:07:02.689674
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Test with default dest
    PrependListAction(["-a","--app"], default=[])
    # Test with custom dest
    PrependListAction(["-a","--app"], dest="app", default=[])
    # Test with nargs
    PrependListAction(["-a","--app"], nargs="?", default=[])
    # Test with nargs and dest
    PrependListAction(["-a","--app"], nargs="?", dest="app", default=[])


# Generated at 2022-06-10 22:07:10.109265
# Unit test for function version
def test_version():
    ansible_version = version()
    for line in (
        'ansible',
        'ansible 2',
        # 'config file = ',
        # 'configured module search path = ',
        'ansible python module location = ',
        'ansible collection location = ',
        'executable location = ',
        'python version = ',
        'jinja version = ',
        'libyaml = ',
    ):
        assert line in ansible_version

# Generated at 2022-06-10 22:07:11.308022
# Unit test for function version
def test_version():
    assert version().startswith(__version__)



# Generated at 2022-06-10 22:07:19.779632
# Unit test for function unfrack_path
def test_unfrack_path():
    ''' Test function Unfrack_path '''
    assert unfrack_path(False)("/tmp") == "/tmp"
    assert unfrack_path(False)("/tmp/") == "/tmp/"
    assert unfrack_path(False)("$HOME") != "$HOME"
    assert unfrack_path(True)("/tmp") == ["/tmp"]
    assert unfrack_path(True)("$HOME") != ["$HOME"]
    assert unfrack_path(True)("/tmp/:/tmp") == ["/tmp/", "/tmp"]
    assert unfrack_path(True)(":") == []
    assert unfrack_path(True)("/tmp/:$HOME") != ["/tmp/", "$HOME"]



# Generated at 2022-06-10 22:07:23.946219
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    if not sys.platform.startswith(('linux', 'darwin')):
        return # no need to test
    import pytest
    with pytest.raises(SystemExit):
        maybe_unfrack_path('~')('~/fake_file')


#
# The actual Option Parsers
#

# Generated at 2022-06-10 22:07:33.963188
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    def assert_unfrack_path(beacon, expected):
        actual = maybe_unfrack_path(beacon)(beacon + 'path')
        if actual != expected:
            raise ValueError('assert_unfrack_path:{} failed, expected {} actual {}'.format(beacon, expected, actual))

    assert_unfrack_path('@', '@path')
    assert_unfrack_path('@tmp', '@tmp/path')
    assert_unfrack_path('', '/tmp/path')
    assert_unfrack_path('~', os.path.expanduser('~/path'))
    assert_unfrack_path('~/', os.path.expanduser('~/path'))

# Generated at 2022-06-10 22:07:43.622238
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert '@/tmp/foo' == maybe_unfrack_path('@')('@./tmp/foo'), "Should not unfrack path when not starting with @"
    assert '@@/tmp/foo' == maybe_unfrack_path('@')('@@./tmp/foo'), "Should not strip leading @ when there are two"
    assert '@/tmp/foo' == maybe_unfrack_path('@')('@./tmp/foo'), "Should unfrack path when starting with @"
    assert '@/tmp/foo/' == maybe_unfrack_path('@')('@./tmp/foo/'), "Should unfrack path with trailing slash"

