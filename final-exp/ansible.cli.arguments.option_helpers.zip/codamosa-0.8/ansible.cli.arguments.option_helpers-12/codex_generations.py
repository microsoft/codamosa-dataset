

# Generated at 2022-06-10 21:59:01.579666
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-10 21:59:07.753744
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument = Mock()
    namespace = Mock()
    values = Mock()
    option_string = Mock()
    ansible_version = AnsibleVersion()
    ansible_version(parser, namespace, values, option_string)
    assert AnsibleVersion.__call__.call_count == 1

# Generated at 2022-06-10 21:59:10.824102
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    o = AnsibleVersion()
    setattr(o, 'prog', 'programme')
    o.__call__(o, None, None, None)



# Generated at 2022-06-10 21:59:13.636871
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = create_base_parser('test')
    add_connect_options(parser)


# Generated at 2022-06-10 21:59:23.850474
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.utils.display import Display
    from ansible.cli.arguments import option_helpers
    from ansible.errors import AnsibleError
    display = Display()
    parser = argparse.ArgumentParser(description='test_add_connect_options',
                                     usage='', prog='test_add_connect_options')
    option_helpers.add_connect_options(parser)
    pargs = parser.parse_args([])
    assert pargs.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pargs.remote_user == C.DEFAULT_REMOTE_USER
    assert pargs.connection == C.DEFAULT_TRANSPORT
    assert pargs.timeout == C.DEFAULT_TIMEOUT
    assert pargs.ssh_common_args is None
    assert pargs

# Generated at 2022-06-10 21:59:34.477462
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = MockParser('1.0')
    add_runas_options(parser)

# Generated at 2022-06-10 21:59:38.545414
# Unit test for function add_fork_options
def test_add_fork_options():
    parser=argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_fork_options(parser)
    assert '-f' in parser._option_string_actions
    assert '--forks' in parser._option_string_actions

# Generated at 2022-06-10 21:59:48.488925
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(False)('$HOME/abc') == os.path.expanduser('~/abc')
    assert unfrack_path(False)('$HOME/abc:$HOME/def') == os.path.expanduser('~/abc:~/def')
    assert unfrack_path(True)('$HOME/abc') == [os.path.expanduser('~/abc')]
    assert unfrack_path(True)('$HOME/abc:$HOME/def') == [os.path.expanduser('~/abc'), os.path.expanduser('~/def')]
    assert unfrack_path(False)('-') == '-'
    assert unfrack_path(True)('-') == ['-']


# Generated at 2022-06-10 21:59:49.887600
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = argparse.ArgumentParser()
    add_tasknoplay_options(parser)
    assert parser._option_string_actions['--task-timeout'].default == C.TASK_TIMEOUT



# Generated at 2022-06-10 21:59:55.118895
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='test_add_output_options')
    add_output_options(parser)
    options, _ = parser.parse_known_args(['-t', '/tmp'])
    assert options.tree == '/tmp'
    args, _ = parser.parse_known_args(['-t', '/tmp'])
    assert args.tree == '/tmp'



# Generated at 2022-06-10 22:00:13.222366
# Unit test for function unfrack_path
def test_unfrack_path():
    data = ['a', 'b', 'c']
    unfrack_data = ['a', 'b', 'c']
    assert unfrack_path()(data) == unfrack_data


# Generated at 2022-06-10 22:00:17.389020
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # Test that given no options, parser has default options
    parser = argparse.ArgumentParser(prog='')
    add_inventory_options(parser)
    assert parser.parse_args([]).inventory == [C.DEFAULT_HOST_LIST]
    assert parser.parse_args([]).listhosts == False
    assert parser.parse_args([]).subset == C.DEFAULT_SUBSET

    # Test that -i option works
    assert parser.parse_args(['-i', 'abc']).inventory == ['abc']

    # Test that --inventory works
    assert parser.parse_args(['--inventory', 'abc']).inventory == ['abc']

    # Test that multiple -i and --inventory options are supported

# Generated at 2022-06-10 22:00:19.944564
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('', action=AnsibleVersion)
    assert parser.parse_args(['--version'])



# Generated at 2022-06-10 22:00:26.963260
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = ArgparseCLI()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-id', 'test', '--vault-password-file', 'test.txt'])
    assert 'test' in options.vault_ids
    assert 'test.txt' in options.vault_password_files
    assert not options.ask_vault_pass



# Generated at 2022-06-10 22:00:32.107165
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Check that a TypeError is raised if nargs is zero
    try:
        PrependListAction(option_strings=(), dest='foo', nargs=0)
    except TypeError:
        pass
    else:
        raise AssertionError("nargs=0 should raise TypeError")


# Generated at 2022-06-10 22:00:37.994400
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True)('a' + os.pathsep + 'b') == [unfrackpath('a'), unfrackpath('b')]

    assert unfrack_path()('-') == '-'

    assert unfrack_path()(unfrackpath('a')) == unfrackpath('a')



# Generated at 2022-06-10 22:00:42.760656
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/data') == '@' + unfrackpath('/path/to/data')
    assert maybe_unfrack_path('@')('/path/to/data') == '/path/to/data'
    assert maybe_unfrack_path('@')('') == ''
#
# Standard OptionParser classes
#


# Generated at 2022-06-10 22:00:44.762253
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)


#
# Option parsing
#

# Generated at 2022-06-10 22:00:47.208396
# Unit test for function version
def test_version():
    assert __version__ in version()
    assert 'config file =' in version(prog='ansible')

# Generated at 2022-06-10 22:00:50.914144
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    (options, args) = parser.parse_known_args(['-b', '--become-method=su'])
    assert options.become == True
    assert options.become_method == 'su'
    assert options.become_user == C.DEFAULT_BECOME_USER



# Generated at 2022-06-10 22:01:12.693798
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("bar/baz") == "bar/baz"
    assert unfrack_path()("~/bar/baz") == os.path.expanduser("~/bar/baz")
    assert unfrack_path()("~/bar/baz") != "~/bar/baz"

    assert unfrack_path(pathsep=True)("bar/baz") == ["bar/baz"]
    assert unfrack_path(pathsep=True)("/bar/baz:/tmp") == ["/bar/baz", "/tmp"]
    assert unfrack_path(pathsep=True)("~/bar/baz:/tmp") == [os.path.expanduser("~/bar/baz"), "/tmp"]

# Generated at 2022-06-10 22:01:17.851995
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@' + unfrackpath('/path/to/file')
    assert maybe_unfrack_path('@')('path/to/file') == 'path/to/file'
# Unit test



# Generated at 2022-06-10 22:01:21.453155
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args(["-P", "42", "-B", "43"])
    assert options.poll_interval == 42
    assert options.seconds == 43

# Generated at 2022-06-10 22:01:23.627333
# Unit test for function add_fork_options
def test_add_fork_options():
	parser=argparse.ArgumentParser()
	add_fork_options(parser)


# Generated at 2022-06-10 22:01:32.466733
# Unit test for function add_async_options
def test_add_async_options():
    """ unit testing for function "add_async_options" """
    mock = argparse.ArgumentParser()
    add_async_options(mock)
    assert mock._actions[0].dest == 'poll_interval'
    assert mock._actions[0].default == C.DEFAULT_POLL_INTERVAL
    assert mock._actions[0].type == int
    assert mock._actions[1].dest == 'seconds'
    assert mock._actions[1].default == 0
    assert mock._actions[1].type == int
    assert mock._actions[1].help == 'run asynchronously, failing after X seconds (default=N/A)'



# Generated at 2022-06-10 22:01:42.197148
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test with multiple paths
    paths = ['/tmp/foo.yml', '/tmp/bar.yml']
    unfracked_paths = unfrack_path(pathsep=True)(os.pathsep.join(paths))
    assert unfracked_paths == paths

    # Test with a single path
    path = '/tmp/foo.yml'
    unfracked_path = unfrack_path(pathsep=True)(path)
    assert unfracked_path == [path]

    # Test without path seperation
    path = '/tmp/foo.yml'
    unfracked_path = unfrack_path(pathsep=False)(path)
    assert unfracked_path == path

    # Test with '-' as a path
    path = '-'
    unfracked_path = unf

# Generated at 2022-06-10 22:01:46.928728
# Unit test for function unfrack_path
def test_unfrack_path():
    path = '/etc/ansible/roles:/etc/ansible/playbooks'
    result = ['/etc/ansible/roles', '/etc/ansible/playbooks']
    assert result == unfrack_path(True)(path)
    assert result == unfrack_path(True)(path)


# Generated at 2022-06-10 22:01:50.417651
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('hello') == u'hello'
    assert unfrack_path()('hello%s' % os.pathsep) == u'hello'


# Generated at 2022-06-10 22:01:54.110515
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    parser.parse_args('-f 10'.split())
    assert 10 == C.DEFAULT_FORKS



# Generated at 2022-06-10 22:01:58.176392
# Unit test for function unfrack_path
def test_unfrack_path():
    parser = argparse.ArgumentParser()
    parser.add_argument('path', type=unfrack_path())
    args = parser.parse_args(['/tmp'])
    assert args.path == '/tmp'



# Generated at 2022-06-10 22:02:09.753772
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args([])
    assert options.tags == C.TAGS_RUN
    assert options.skip_tags == C.TAGS_SKIP
    options = parser.parse_args(['--tags', 'a1,a2', '--tags', 'b1,b2'])
    assert options.tags == ['a1', 'a2', 'b1', 'b2']
    assert options.skip_tags == C.TAGS_SKIP
    options = parser.parse_args(['--skip-tags', 'c1,c2', '--skip-tags', 'd1,d2'])
    assert options.skip_tags == ['c1', 'c2', 'd1', 'd2']

# Generated at 2022-06-10 22:02:14.123450
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('x') == unfrackpath('x')
    assert unfrack_path(pathsep=True)('x') == [unfrackpath('x')]
    assert unfrack_path(pathsep=True)('x:y:z') == [unfrackpath('x'), unfrackpath('y'), unfrackpath('z')]



# Generated at 2022-06-10 22:02:21.324156
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_beacon='./'
    assert maybe_unfrack_path(test_beacon)('./test') == './test'
    assert maybe_unfrack_path(test_beacon)('./tmp') == './tmp'
    assert maybe_unfrack_path(test_beacon)('./../') == './../'


# Generated at 2022-06-10 22:02:24.609124
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~/.ansible/roles') == '%s/.ansible/roles' % os.path.expanduser('~')



# Generated at 2022-06-10 22:02:29.012121
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~/.ansible/tmp') == os.path.expanduser('~/.ansible/tmp')
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-10 22:02:37.619170
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)("~/.ansible/roles:/usr/share/ansible/roles:/some/other/path") == [
        "~/.ansible/roles",
        "/usr/share/ansible/roles",
        "/some/other/path",
    ]
    assert unfrack_path()("~/.ansible/roles") == "~/.ansible/roles"
    assert unfrack_path()("-") == "-"



# Generated at 2022-06-10 22:02:45.726417
# Unit test for function unfrack_path
def test_unfrack_path():
    args = 'test-1:test-2:test-3'
    test_list = [unfrackpath(x) for x in args.split(os.pathsep) if x]
    assert test_list == unfrack_path(pathsep=True)('test-1:test-2:test-3')
    assert test_list == ['test-1', 'test-2', 'test-3']
    if os.name == 'nt':
        assert unfrack_path()(r'c:\adir\anotherfile') == r'c:\adir\anotherfile'
        assert unfrack_path()('c:/adir/anotherfile') == r'c:\adir\anotherfile'
    else:
        assert unfrack_path()('/home/something/file.txt') == '/home/something/file.txt'

# Generated at 2022-06-10 22:02:56.172415
# Unit test for function version
def test_version():
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from ansible.cli.cli import CLI
    from ansible.release import __version__
    from ansible.errors import AnsibleError

    display = Display()
    cli = CLI()
    config_manager = ConfigManager()
    display.verbosity = 0

    # Test w/o config, without --version
    try:
        args = cli.parse(['ansible', '--help'], None, display, config_manager)
    except SystemExit:
        pass
    else:
        raise Exception("SystemExit should be raised, if --version was not used and no config")

    # Test w/o config, w/ --version

# Generated at 2022-06-10 22:03:05.356964
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("~")("~/foo") == "~/foo"
    assert maybe_unfrack_path("~")("~/bar/../foo") == "~/foo"
    assert maybe_unfrack_path("/")("/foo/bar") == "/foo/bar"
    assert maybe_unfrack_path("/")("/foo//bar") == "/foo/bar"
    assert maybe_unfrack_path("/")("/foo/bar/../../baz") == "/baz"
    assert maybe_unfrack_path("/")("foo") == "foo"



# Generated at 2022-06-10 22:03:15.114512
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_subset_options(parser)

    args = ['--tags', 'first_tag', '--tags', 'second_tag', '--skip-tags', 'skip_tag1', '--skip-tags', 'skip_tag2']
    parsed = parser.parse_args(args)
    assert (parsed.tags == ['first_tag', 'second_tag'])
    assert (parsed.skip_tags == ['skip_tag1', 'skip_tag2'])



# Generated at 2022-06-10 22:03:24.769038
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    inputfile = '@/etc/ansible/ansible.cfg'
    outputfile = maybe_unfrack_path('@')(inputfile)
    assert outputfile == '@' + unfrackpath(inputfile[1:])



# Generated at 2022-06-10 22:03:27.381803
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@{0}'.format(unfrackpath('/foo'))



# Generated at 2022-06-10 22:03:38.694305
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('ansible') == 'ansible'
    assert unfrack_path(pathsep=False)('../ansible') == '../ansible'
    assert unfrack_path(pathsep=False)('~/ansible') == os.path.expanduser('~/ansible')
    assert unfrack_path(pathsep=False)(os.path.join('~', '.ansible')) == os.path.expanduser(os.path.join('~', '.ansible'))
    assert unfrack_path(pathsep=False)('.ansible') == os.path.join(os.getcwd(), '.ansible')
    assert unfrack_path(pathsep=False)('ansible') == 'ansible'

# Generated at 2022-06-10 22:03:50.751488
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/y') == '@/tmp/y'
    assert maybe_unfrack_path('@')('@TMPDIR/y') == '@/tmp/y'
    assert maybe_unfrack_path('@')('@/tmp/y/') == '@/tmp/y'
    assert maybe_unfrack_path('@')('@TMPDIR/y/') == '@/tmp/y'
    assert maybe_unfrack_path('@')('@tmp/y') == '@tmp/y'
    assert maybe_unfrack_path('@')('@tmp/y/') == '@tmp/y'
    assert maybe_unfrack_path('@')('@tmp') == '@tmp'
   

# Generated at 2022-06-10 22:03:58.651070
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, dest='bar', type=str)
    args = parser.parse_args(['--foo', 'x', '--foo', 'y', '--foo', 'z'])
    result = ['x', 'y', 'z']
    assert args.bar == result


# Generated at 2022-06-10 22:04:06.723674
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp/foo') == '@' + unfrackpath('/tmp/foo')
    assert maybe_unfrack_path('@')('@@/tmp/foo') == '@@/tmp/foo'
    assert maybe_unfrack_path('@')('@/tmp/foo/') == '@' + unfrackpath('/tmp/foo/')
    assert maybe_unfrack_path('@')('@/tmp/') == '@' + unfrackpath('/tmp/')



# Generated at 2022-06-10 22:04:08.588222
# Unit test for function version
def test_version():
    """ return ansible version test """
    assert isinstance(version(), str)

# Generated at 2022-06-10 22:04:18.680735
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    import tempfile
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.common.file import azure_write_file
    # Create temp directory to store test file
    temp_dir = tempfile.mkdtemp()
    # Create temp file inside temp directory to test for_file
    test_file = os.path.join(temp_dir, 'for_file')
    makedirs_safe(test_file)
    fd, dummy = tempfile.mkstemp(dir=test_file)
    os.close(fd)
    test_file_name = os.path.split(dummy)[-1]
    test_file1 = os.path.join(test_file, test_file_name)
    # Create temp file inside temp directory to test for_host
    test_file

# Generated at 2022-06-10 22:04:26.791119
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == unfrackpath('foo')
    assert unfrack_path()('foo:bar') == unfrackpath('bar')
    assert unfrack_path(pathsep=True)('foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]
    assert unfrack_path(pathsep=True)('bar') == [unfrackpath('bar')]
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-10 22:04:37.009151
# Unit test for function unfrack_path
def test_unfrack_path():
    if (sys.version_info < (3, 0)):
        if C.DEFAULT_PRIVATE_ROOT_PATH is not None:
            # default_private_root_path was set
            assert unfrack_path()("{{inventory_dir}}/foo.cfg") == os.path.join(C.DEFAULT_PRIVATE_ROOT_PATH, "inventory", "foo.cfg")

        if C.DEFAULT_PRIVATE_DATA_PATH is not None:
            # default_private_data_path was set
            assert unfrack_path()("{{vars_dir}}/foo.yaml") == os.path.join(C.DEFAULT_PRIVATE_DATA_PATH, "vars", "foo.yaml")

        assert unfrack_path()("{{role_path}}/foo.yaml") == os

# Generated at 2022-06-10 22:04:52.400249
# Unit test for function unfrack_path
def test_unfrack_path():
    """Tests for function unfrack_path"""
    # unit test to check unfrack_path function with single path
    assert unfrack_path(pathsep=False)('/home/user/git/file.yml') == '/home/user/git/file.yml'
    # unit test to check unfrack_path function with multiple path seperated by colon
    assert unfrack_path(pathsep=True)('/home/user/git:/home/user/test') == ['/home/user/git', '/home/user/test']



# Generated at 2022-06-10 22:04:58.240194
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    paths = [
        ('@foo', '@/usr/local/home/foo'),
        ('foo', 'foo'),
        ('@', '@/usr/local/home'),
        ('@@foo', '@@foo'),
        ('@foo1@foo2', '@/usr/local/home/foo1@foo2'),
    ]
    for input, output in paths:
        assert maybe_unfrack_path('@')(input) == output



# Generated at 2022-06-10 22:05:07.984163
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    def assert_unfract_equal(beacon, path, result):
        assert maybe_unfrack_path(beacon)(path) == result

    assert_unfract_equal('@', '@foo', '@foo')
    assert_unfract_equal('@', '@/foo', '@foo')
    assert_unfract_equal('@', '@', '@')
    assert_unfract_equal('@', 'foo', 'foo')

    assert_unfract_equal('@@', '@@/foo', '@@foo')
    assert_unfract_equal('@@', '@@', '@@')
    assert_unfract_equal('@@', '@/foo', '@foo')
    assert_unfract_equal('@@', 'foo', 'foo')



# Generated at 2022-06-10 22:05:20.766457
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test usage of unfrack_path with pathsep=False
    call = 'unfrack_path()'
    assert unfrack_path()('/dev/null') == '/dev/null', \
        '%s returned "%s" instead of "/dev/null"' % (call, unfrack_path()('/dev/null'))

    # Test usage of unfrack_path with pathsep=True
    call = 'unfrack_path(pathsep=True)'
    assert unfrack_path(pathsep=True)('foo:/dev/null') == ['foo', '/dev/null'], \
        '%s returned "%s" instead of "foo:/dev/null"' % (call, unfrack_path(pathsep=True)('foo:/dev/null'))


# Generated at 2022-06-10 22:05:29.954057
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # the following lines result in a list of 5 argparse.Actions
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store', dest='foo')
    parser.add_argument('bar', action='store', nargs='?')
    parser.add_argument('--baz', action='store', dest='baz')
    parser.add_argument('--hello', action='store', dest='hello')
    parser.add_argument('--bar', action='store', dest='bar')
    # store only the 'actions' part from the argument parser
    actions = parser._actions
    # store the list of option_strings for each action
    option_strings = [a.option_strings for a in actions]
    # check that the strings are indeed sorted alphabetically
    option_strings.sort()

# Generated at 2022-06-10 22:05:36.513935
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    help_text = 'help text'
    opt_str = '-x'
    p.add_argument(opt_str, action=PrependListAction, help=help_text)
    args = p.parse_args(['-x', 'val1', 'val2', '-x', 'val3'])
    assert getattr(args, 'x') == ['val3', 'val1', 'val2']
    assert '-x val3,val1,val2' in p.format_help().replace('\n', ' ')



# Generated at 2022-06-10 22:05:40.449614
# Unit test for function version
def test_version():
    # For now, just make sure it does not crash
    actual = version()
    assert isinstance(actual, str)
    actual = version('ansible-playbook')
    assert isinstance(actual, str)



# Generated at 2022-06-10 22:05:47.059160
# Unit test for function unfrack_path
def test_unfrack_path():
    """Assert that unfrackpath can turn ordinary paths into friedly paths for windows.
    """
    assert unfrack_path()('C:\\Windows\\System32') == 'C:/Windows/System32'
    assert unfrack_path()('C:/Windows/System32') == 'C:/Windows/System32'
    assert unfrack_path()('/etc/passwd') == '/etc/passwd'
    assert unfrack_path()('C:\\Windows\\System32\\;C:\\Windows\\System') == 'C:/Windows/System32/;C:/Windows/System'
    assert unfrack_path(True)('C:\\Windows\\System32\\;C:\\Windows\\System') == ['C:/Windows/System32', 'C:/Windows/System']


#
# ArgumentSpecs for displaying Options
#

# Generated at 2022-06-10 22:05:56.793651
# Unit test for function unfrack_path
def test_unfrack_path():
    """Unit tests for unfrackpath.  (We want to test that it works in every
    location that ansible can be invoked from.)
    """
    assert unfrack_path()('INVALID/FILE/PATH') == 'INVALID/FILE/PATH'
    assert unfrack_path(pathsep=True)('INVALID/FILE/PATH') == ['INVALID/FILE/PATH']
    assert unfrack_path()('-') == '-'
    assert unfrack_path(pathsep=True)('-') == ['-']
    assert unfrack_path()('../INVALID/PATH') == '../INVALID/PATH'
    assert unfrack_path(pathsep=True)('../INVALID/PATH') == ['../INVALID/PATH']



# Generated at 2022-06-10 22:06:05.707189
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    test_path = C.DEFAULT_LOCAL_TMP
    beacon = '@'
    not_beacon = 'not_beacon'
    expected = beacon+test_path
    result = maybe_unfrack_path(beacon)(beacon+test_path)
    assert result == expected
    result = maybe_unfrack_path(beacon)(not_beacon+test_path)
    assert result == not_beacon+test_path


# Generated at 2022-06-10 22:06:35.978759
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_input = '@/path/with/f'
    expected_output = '@' + unfrackpath('/path/with/f')
    assert maybe_unfrack_path('@')(test_input) == expected_output
    test_input = '@@/second/@path'
    expected_output = '@@' + unfrackpath('/second/@path')
    assert maybe_unfrack_path('@')(test_input) == expected_output



# Generated at 2022-06-10 22:06:41.210499
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~/foo') == '~/foo'
    assert unfrack_path()('file:///foo/bar') == '/foo/bar'
    assert unfrack_path()('file://~/bar') == '~/bar'
    assert unfrack_path()('file:///foo/bar/baz') == '/foo/bar/baz'
    return True

# Generated at 2022-06-10 22:06:42.709076
# Unit test for function version
def test_version():
    assert "ansible-console" in version("ansible-console")


# Generated at 2022-06-10 22:06:48.592050
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/usr/local/bin') == '/usr/local/bin'
    assert unfrack_path()('/usr/local/bin:/usr/local') == '/usr/local/bin:/usr/local'
    assert unfrack_path(pathsep=True)('/usr/local/bin:/usr/local') == ['/usr/local/bin', '/usr/local']
    assert unfrack_path()('-') == '-'


# Generated at 2022-06-10 22:06:57.843916
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(False)('/dev/null/') == '/dev/null'
    assert unfrack_path(True)('/dev/null/') == ['/dev/null']
    assert unfrack_path(False)('foo:-') == 'foo'
    assert unfrack_path(True)('foo:-') == ['foo']
    assert unfrack_path(False)('foo') == 'foo'
    assert unfrack_path(True)('foo') == ['foo']
    assert unfrack_path(False)('foo/:bar') == 'foo/:bar'
    assert unfrack_path(True)('foo/:bar') == ['foo/:bar']
    assert unfrack_path(False)('foo/:/bar') == 'foo/:/bar'
    assert unfrack_path(True)('foo/:/bar')

# Generated at 2022-06-10 22:07:03.684900
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/./b//c/d') == '/a/b/c/d'
    assert unfrack_path(pathsep=True)('/a/./b//c/d:/e/./f//g/h') == ['/a/b/c/d', '/e/f/g/h']
# Unit tests for function validated_dump

# Generated at 2022-06-10 22:07:15.187920
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """Test for function maybe_unfrack_path()"""
    # data with beacon that starts with a '~'
    data = ['/home/joe/ansible', '~/ansible']
    result = [maybe_unfrack_path('/home/joe')(x) for x in data]
    assert result[0] == '/home/joe/ansible'
    assert result[1] == '/home/joe/ansible'
    # data without beacon that starts with a '~'
    data = ['/home/joe/ansible', '~/ansible']
    result = [maybe_unfrack_path('/tmp')(x) for x in data]
    assert result[0] == '/home/joe/ansible'
    assert result[1] == '~/ansible'
    #

# Generated at 2022-06-10 22:07:21.851830
# Unit test for function version
def test_version():
    from ansible.module_utils.six import PY3
    if PY3:
        assert '3.4.9' in version("foo")
    else:
        assert '2.7.13' in version("foo")
    assert 'ansible 2.8.4' in version()
    assert 'ansible 2.9.0.dev0 [core foo]' in version("foo")
    assert 'last updated' in version("foo")
    assert 'config file = bar' in version("foo")
    assert 'configured module search path = Default w/o overrides' in version("foo")
    assert 'ansible python module location = foo:bar' in version("foo")
    assert 'executable location = foobar' in version("foo")

# Generated at 2022-06-10 22:07:31.608401
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('/')('/foo/var/bar') == '/foo/var/bar'
    assert maybe_unfrack_path('@')('@foo/bar') == '@foo/bar'
    assert maybe_unfrack_path('@')('@foo/var/bar') == '@foo/var/bar'
    assert maybe_unfrack_path('@DEFAULT')('@DEFAULT/foo/var/bar') == '@DEFAULT/foo/var/bar'
    assert maybe_unfrack_path('@/')('@/foo/var/bar') == '/foo/var/bar'



# Generated at 2022-06-10 22:07:32.902345
# Unit test for function version
def test_version():
    assert version() is not None