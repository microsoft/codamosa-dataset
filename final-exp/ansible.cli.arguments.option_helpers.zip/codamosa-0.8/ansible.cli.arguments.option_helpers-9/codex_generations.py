

# Generated at 2022-06-10 21:58:44.641810
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-e', '--extra-var', action='store', dest='extra_var')
    parser.add_argument('-f', '--foo-bar', action='store', dest='foo_bar')
    parser.add_argument('-a', '--bar-foo', action='store', dest='bar_foo')
    parser.add_argument('-z', '--play-hosts', action='store', dest='play_hosts')
    parser.add_argument('-h', '--help', action='help')
    parser.print_help()


# Generated at 2022-06-10 21:58:50.476432
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    import argparse
    parser = argparse.ArgumentParser(prog='ansible-config')
    parser.add_argument('--foo', action=PrependListAction)
    parser.parse_args(args=['--foo', 'one', '--foo', 'two'])
    assert parser.parse_args(args=['--foo', 'one', '--foo', 'two']).foo == ['one', 'two']



# Generated at 2022-06-10 21:59:00.587804
# Unit test for function add_runtask_options
def test_add_runtask_options():
    "Test for function add_runtask_options"
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    assert parser.parse_args(["-e", "A=B"]).extra_vars == ["A=B"]
    assert parser.parse_args(["-e", "@A"]).extra_vars == ["@A"]
    assert parser.parse_args(["-e", "@A", "-e", "@B"]).extra_vars == ["@A", "@B"]
    assert parser.parse_args(["-e", "@A", "-e", "@B@"]).extra_vars == ["@A", "@B@"]



# Generated at 2022-06-10 21:59:10.187304
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    # arguments in mutually exclusive group
    parser.parse_args(['--ask-pass', '--connection-password-file', 'test'])
    parser.parse_args(['--connection-password-file', 'test'])
    # parsing error by including both arguments
    try:
        parser.parse_args(['--ask-pass', '--connection-password-file', 'test'])
        assert False # 'must raise SystemExit'
    except SystemExit:
        pass



# Generated at 2022-06-10 21:59:17.111204
# Unit test for function add_connect_options
def test_add_connect_options():
    parser=create_base_parser('ansible', usage='%(prog)s [options]')
    add_connect_options(parser)
    return parser.parse_args(['-u', 'root', '-c', 'myconnection', '-T', '123', '--ssh-common-args', 'mysshcommon'])



# Generated at 2022-06-10 21:59:24.904546
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import unittest
    class MyTest(unittest.TestCase):
        def test(self):
            # Set test data
            mock_actions = [
                argparse.Action(option_strings=['-d', '--defg'], dest='abc'),
                argparse.Action(option_strings=['-a', '--abc'], dest='abc'),
                argparse.Action(option_strings=['-c', '--cde'], dest='abc'),
                argparse.Action(option_strings=['-b', '--bcd'], dest='abc'),
            ]

            # Mock class SortingHelpFormatter
            SortingHelpFormatterMock = SortingHelpFormatter

            # Create instance
            instance = SortingHelpFormatterMock()

            # Execute

# Generated at 2022-06-10 21:59:30.714783
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args(['-K', '--ask-become-pass', '--become-password-file', 'test.yml'])
    assert args.become_ask_pass == True
    assert args.become_password_file == 'test.yml'



# Generated at 2022-06-10 21:59:40.691084
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['--private-key', 'a', '--ssh-common-args', 'b', '--sftp-extra-args', 'c', '--scp-extra-args', 'd', '--ssh-extra-args', 'e', '--connection-password-file', 'f'])
    assert args.private_key_file == 'a'
    assert args.connection_password_file == 'f'
    assert args.ssh_common_args == 'b'
    assert args.sftp_extra_args == 'c'
    assert args.scp_extra_args == 'd'
    assert args.ssh_extra_args == 'e'



# Generated at 2022-06-10 21:59:45.562616
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    h = parser.parse_args(['-e', '@my_file.txt', '-e', 'foo=bar'])
    assert(h.extra_vars == ['@my_file.txt', 'foo=bar'])



# Generated at 2022-06-10 21:59:53.753500
# Unit test for function unfrack_path
def test_unfrack_path():
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    assert unfrack_path()('$ANSIBLE_CONFIG') == '/etc/ansible/ansible.cfg', "unfrack_path did not return the expected value."
    ansible_cfg = '/etc/ansible/ansible.cfg'
    assert unfrack_path()(ansible_cfg) == ansible_cfg, "unfrack_path did not return the expected value."


# Generated at 2022-06-10 22:00:13.024892
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('--version', action=AnsibleVersion)
    test_args = test_parser.parse_known_args(['--version'])


# Generated at 2022-06-10 22:00:19.662270
# Unit test for function add_subset_options
def test_add_subset_options():
    parser1 = argparse.ArgumentParser()
    add_subset_options(parser1)
    parser2 = argparse.ArgumentParser()
    args = parser1.parse_args(['-t', 'a', 'b', '--skip-tags', 'x', 'y'])
    assert args.tags == ['a', 'b']
    assert args.skip_tags == ['x', 'y']


#
# Functions to add pre-canned options for a particular command
#


# Generated at 2022-06-10 22:00:27.615771
# Unit test for function add_subset_options
def test_add_subset_options():
    print("TEST: add_subset_options")

    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args([])

    assert options.tags == C.TAGS_RUN
    assert options.skip_tags == C.TAGS_SKIP

    options = parser.parse_args(["--tags", "foo,bar,baz", '--skip-tags', 'bing,bang,bong'])

    assert options.tags == ["foo,bar,baz"]
    assert options.skip_tags == ["bing,bang,bong"]


# Generated at 2022-06-10 22:00:31.301843
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrackpath(__file__) == __file__
    assert unfrackpath(__file__ + ".bogus") == __file__
    assert unfrackpath(__file__ + ".bogus1", None) == __file__ + ".bogus1"


# Generated at 2022-06-10 22:00:44.018050
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('/h/p') == '/h/p'
    assert unfrack_path()('h/p') == 'h/p'
    assert unfrack_path()(':h:p') == ':h:p'
    assert unfrack_path(pathsep=True)('h:/p:') == ['h', '/p']
    assert unfrack_path(pathsep=True)('h:p') == ['h', 'p']
    assert unfrack_path(pathsep=True)('::h::p:') == [':h:p']
    assert unfrack_path(pathsep=True)(':::::') == ['']
    assert unfrack_path(pathsep=True)('') == []


# Generated at 2022-06-10 22:00:54.347315
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()
    add_inventory_options(parser)
    parser.add_argument.assert_any_call('-i', '--inventory', '--inventory-file', dest='inventory', action="append",
                                        help="specify inventory host path or comma separated host list. --inventory-file is deprecated")
    parser.add_argument.assert_any_call('--list-hosts', dest='listhosts', action='store_true',
                                        help='outputs a list of matching hosts; does not execute anything else')
    parser.add_argument.assert_any_call('-l', '--limit', default='all', dest='subset',
                                        help='further limit selected hosts to an additional pattern')


# Generated at 2022-06-10 22:00:55.636072
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
# End of unit test


# Generated at 2022-06-10 22:00:59.898132
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    from ansible.cli import CLI
    parser = argparse.ArgumentParser(prog='ansible')
    subparsers = parser.add_subparsers(metavar="<subcommand>")
    sub = CLI.add_parser_args(subparsers, 'vault')
    add_tasknoplay_options(sub)
    args = parser.parse_args(['--task-timeout', '10', 'vault', 'view', 'somefile.yml'])
    assert args.task_timeout == 10

    parser = argparse.ArgumentParser(prog='ansible')
    subparsers = parser.add_subparsers(metavar="<subcommand>")
    sub = CLI.add_parser_args(subparsers, 'vault')
    add_tasknoplay_options

# Generated at 2022-06-10 22:01:02.159286
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser =  argparse.ArgumentParser(prog='test-add-tasknoplay-options', description='sample code')
    add_tasknoplay_options(parser)
    assert parser._defaults['task_timeout'] == C.TASK_TIMEOUT
    results = parser.parse_args(['--task-timeout', '100'])
    assert results.task_timeout == 100



# Generated at 2022-06-10 22:01:09.286564
# Unit test for function version
def test_version():
    from ansible.module_utils._text import to_bytes
    assert isinstance(version(), six.text_type)
    assert isinstance(version(b'foo'), six.text_type)
    assert isinstance(to_bytes(version(), errors='surrogate_or_strict'), six.binary_type)
    assert isinstance(to_bytes(version(b'foo'), errors='surrogate_or_strict'), six.binary_type)



# Generated at 2022-06-10 22:01:24.576589
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = MockArgumentParser()
    add_vault_options(parser)
    assert parser.called
    expected_calls = [
        call('--vault-id', default=[], dest='vault_ids', action='append', type=str, help='the vault identity to use'),
        call('--ask-vault-password', '--ask-vault-pass', default=C.DEFAULT_ASK_VAULT_PASS, dest='ask_vault_pass', action='store_true', help='ask for vault password'),
        call('--vault-password-file', '--vault-pass-file', default=[], dest='vault_password_files', help='vault password file', type=unfrack_path(), action='append'),
    ]
    parser.assert_has_calls(expected_calls)



# Generated at 2022-06-10 22:01:27.151808
# Unit test for function version
def test_version():
    """
    test version
    """
    assert(version('/path/a') == version('/path/a')), 'version does not match'

# Generated at 2022-06-10 22:01:38.122786
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class AssertionHelpFormatter(SortingHelpFormatter):
        def __init__(self, testcase):
            self.testcase = testcase
            super(AssertionHelpFormatter, self).__init__()
        def add_arguments(self, actions):
            super(AssertionHelpFormatter, self).add_arguments(actions)
            last_option_strings = None
            for action in actions:
                option_strings = action.option_strings
                self.testcase.assertGreaterEqual(option_strings, last_option_strings)
                last_option_strings = option_strings
    testcase = unittest.TestCase()
    parser = argparse.ArgumentParser(formatter_class=AssertionHelpFormatter(testcase))
    actions = []

# Generated at 2022-06-10 22:01:44.916422
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(parser.prog))
    assert ansible_version == 'ansible 2.6.1.0\n  config file = /home/user/ansible/ansible.cfg\n  configured module search path = [u\'/home/user/ansible/library\']\n  ansible python module location = /home/user/ansible/lib/ansible\n  executable location = /home/user/ansible/bin/ansible\n  python version = 2.7.16 (default, Apr 16 2020, 18:15:34) [GCC 9.2.1 20190827 (Red Hat 9.2.1-1)]\n'



# Generated at 2022-06-10 22:01:55.982932
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("-z", action='store_true')
    parser.add_argument("--abc", action='store_true')
    parser.add_argument("--only-xyz", action='store_true', dest='onlyxyz')
    parser.add_argument("-x")
    parser.add_argument("--with-xyz", action='store_true', dest='withxyz')
    parser.add_argument("-v", "--verbose", action="count", default=1)
    parser.add_argument("-q", "--quiet", action="count", default=0)
    parser.formatter_class = SortingHelpFormatter
    parser.print_help()


# Generated at 2022-06-10 22:02:05.336041
# Unit test for function version
def test_version():
    # Test for gitinfo
    C.ANSIBLE_GIT_REPO_PATH = None
    assert _gitinfo() == ''
    C.ANSIBLE_GIT_REPO_PATH = 'test'
    assert _gitinfo() == ''
    basedir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    C.ANSIBLE_GIT_REPO_PATH = os.path.join(basedir, '.git')
    assert _gitinfo() != ''

    # Test for version
    import ansible.constants as C
    C.DEFAULT_MODULE_PATH = None
    assert version('test') != ''
    C.DEFAULT_MODULE_PATH = 'test'
    assert version('test') != ''

# Generated at 2022-06-10 22:02:07.444247
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=argparse.ArgumentParser()
    assert_equals(argparse.Action,type(parser))
    assert_equals(argparse.ArgumentParser,type(parser.add_meta_options))


# Generated at 2022-06-10 22:02:08.872744
# Unit test for function add_meta_options
def test_add_meta_options():
    with pytest.raises(SystemExit):
        parser = argparse.ArgumentParser(description='description')
        add_meta_options(parser)
        parser.parse_args([])


# Generated at 2022-06-10 22:02:12.768475
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(description='test')
    add_output_options(parser)
    opts = ['--one-line', '-t', '/tmp']
    parsed = parser.parse_args(opts)
    assert parsed.one_line
    assert parsed.tree == '/tmp'

# Generated at 2022-06-10 22:02:25.628132
# Unit test for function version
def test_version():
    from ansible.cli.help import add_base_parser
    parser = add_base_parser(constants=C, usage="%(prog)s")
    assert "ansible-playbook" in parser.prog
    C.config = {}
    C.config["DEFAULT_MODULE_PATH"] = "/module/path" # pylint: disable=no-member
    C.DEFAULT_MODULE_PATH = C.config["DEFAULT_MODULE_PATH"]
    C.COLLECTIONS_PATHS.append("/collection/path")
    sys.argv[0] = "/executable/path"

# Generated at 2022-06-10 22:02:43.228685
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class FakeAction(object):
        def __init__(self, name, help, option_strings=None):
            self.help = help
            self.option_strings = option_strings
            self.name = name
        def __repr__(self):
            return "<%s %r>" % (self.__class__.__name__, self.name)

# Generated at 2022-06-10 22:02:54.457300
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    import io
    import sys
    argv = sys.argv
    parser = argparse.ArgumentParser(
        prog=argv[0],
        formatter_class=SortingHelpFormatter,
    )
    parser.add_argument('-B', dest='B')
    parser.add_argument('-a', dest='X')
    parser.add_argument('-b', dest='b')
    parser.add_argument('-c', dest='c')
    parser.add_argument('-A', dest='A')
    name = parser.prog
    out = sys.stdout
    sys.stdout = io.StringIO()
    parser.print_help()
    out.write(sys.stdout.getvalue())
    sys.stdout = out

# Generated at 2022-06-10 22:03:05.317351
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.add_argument('--extra', default=None, dest='extra',
                        help="some extra stuff")

    result = parser.parse_args(['--vault-id', '@prompt',
                                '--vault-id', 'dev',
                                '--ask-vault-password',
                                '--vault-password-file', '/foo/bar',
                                '--extra=baz'])
    assert result.vault_ids == ['@prompt', 'dev']
    assert result.ask_vault_pass is True
    assert result.vault_password_files == ['/foo/bar']
    assert result.extra == 'baz'


# Generated at 2022-06-10 22:03:14.696559
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    # empty list
    parser = argparse.ArgumentParser()
    actions = []
    parser._actions = actions
    SortingHelpFormatter().add_arguments(actions)

    # single item list
    parser = argparse.ArgumentParser()
    actions = ["one"]
    parser._actions = actions
    SortingHelpFormatter().add_arguments(actions)

    # simple two item list
    parser = argparse.ArgumentParser()
    actions = ["one", "two"]
    parser._actions = actions
    SortingHelpFormatter().add_arguments(actions)


#
# Common parsers
#

# Generated at 2022-06-10 22:03:18.504816
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class MockArgs:
        pass
    arg = MockArgs()
    arg.prog = 'ansible --version'
    action = AnsibleVersion()
    action(arg, None, None)



# Generated at 2022-06-10 22:03:24.910637
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(
        parser
    )
    parser.parse_args([
        "--vault-id", "foo@prompt",
        "--ask-vault-password",
        "--vault-password-file", "bar@prompt"
    ])
    parser.parse_args([
        "--vault-id", "@prompt",
        "--vault-password-file", "foo@prompt"
    ])
    parser.parse_args([
        "--vault-id", "@prompt",
        "--ask-vault-password"
    ])



# Generated at 2022-06-10 22:03:34.349071
# Unit test for function add_vault_options
def test_add_vault_options():
  parser = argparse.ArgumentParser(
      prog='ansible-vault',
      formatter_class=SortingHelpFormatter,
      epilog=None,
      description=None,
      conflict_handler='resolve',
  )
  add_vault_options(parser)
  args = parser.parse_args(' --vault-id foo bar --ask-vault-password --vault-password-file /tmp/bar baz'.split())
  assert args.vault_ids == ['foo','bar']
  assert args.ask_vault_pass == True
  assert args.vault_password_files == ['/tmp/bar','baz']

# Generated at 2022-06-10 22:03:43.752871
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion)

    # pylint: disable=protected-access
    # Unit test for method __call__ when passed a valid option
    args = parser.parse_args(['--version'])
    assert not args.version is None
    ansible_version = to_native(version(parser.prog))
    assert sys.stdout.getvalue() == "{}\n".format(ansible_version)
    # pylint: enable=protected-access



# Generated at 2022-06-10 22:03:49.836778
# Unit test for function version
def test_version():
    '''test for ansible version'''
    global C
    argparse_version = version("test-version")
    assert "test-version" in argparse_version
    assert "config file" in argparse_version
    assert "configured module search path = %s" % C.DEFAULT_MODULE_PATH in argparse_version
    assert "ansible python module location" in argparse_version
    assert "ansible collection location" in argparse_version
    assert "jinja version" in argparse_version
    assert "libyaml" in argparse_version



# Generated at 2022-06-10 22:03:57.358585
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args()
    # The defaults for vault passwords is to neither ask for nor
    # read from a file.
    assert args.ask_vault_pass is False
    assert args.vault_password_files == []

# Generated at 2022-06-10 22:04:13.166075
# Unit test for function version
def test_version():
    # Unit test for function version that was lost when refactoring.
    ansible_version = version("program name").splitlines()
    assert ansible_version[0].split()[0] == "program name"
    assert ansible_version[0].split()[2] == "core"
    assert ansible_version[1].split()[0] == "config"
    assert ansible_version[2].split()[0] == "configured"
    assert ansible_version[3].split()[0] == "ansible"
    assert ansible_version[4].split()[0] == "executable"
    assert ansible_version[5].split()[0] == "python"
    assert ansible_version[6].split()[0] == "jinja"

# Generated at 2022-06-10 22:04:18.867422
# Unit test for function version
def test_version():
    from ansible.utils import version as version_util
    from ansible.utils import config as config_util
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    display = Display()
    config_util.set_config_file(unfrackpath("/etc/ansible/ansible.cfg"))
    display.verbosity = 4
    assert version("ansible") == version_util.version("ansible")


# Generated at 2022-06-10 22:04:32.125154
# Unit test for method add_arguments of class SortingHelpFormatter
def test_SortingHelpFormatter_add_arguments():
    class Dummy:
        def __init__(self):
            self.option_strings=[]
    #
    class Dummy2(Dummy):
        def __init__(self,*args):
            super(Dummy2,self).__init__()
            self.option_strings=args
    #
    actions=[
        Dummy2('-a'),
        Dummy2('-c',''),
        Dummy2('-b'),
        Dummy(),
        Dummy2('-d','','--arg2'),
    ]
    #
    parser=argparse.ArgumentParser()
    parser.add_argument='DUMMY'
    parser.print_help='DUMMY'
    parser._actions=['DUMMY']
    parser._actions_append='DUMMY'
    #
    formatter=S

# Generated at 2022-06-10 22:04:38.921429
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Assert simple positional args are sorted alphanumerically by help
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('foo', help='a')
    parser.add_argument('bar', help='c')
    parser.add_argument('baz', help='b')
    assert_equals(parser.format_help(), 'usage: test_argparse.py [-h] foo bar baz\n\npositional arguments:\n  foo         a\n  bar         c\n  baz         b\n\noptional arguments:\n  -h, --help  show this help message and exit\n')

    # Assert optional args are sorted alphanumerically by help,
    # but with short args grouped before long args.

# Generated at 2022-06-10 22:04:48.174662
# Unit test for function version
def test_version():
    assert 'ansible-config version' in version('ansible-config')
    assert 'configured module search path =' in version('ansible-config')
    assert 'ansible python module location =' in version('ansible-config')
    assert 'ansible collection location =' in version('ansible-config')
    assert 'executable location =' in version('ansible-config')
    assert 'python version =' in version('ansible-config')
    assert 'jinja version =' in version('ansible-config')
    assert 'libyaml =' in version('ansible-config')

#
# Callback to record a help opt
#

# Generated at 2022-06-10 22:04:55.901464
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == unfrackpath('/foo/bar')
    assert unfrack_path()('-') == '-'
    assert unfrack_path(pathsep=True)('/foo/bar:/foo/bam:/foo/baz') == [unfrackpath('/foo/bar'), unfrackpath('/foo/bam'), unfrackpath('/foo/baz')]
    assert unfrack_path(pathsep=True)('%s/foo/bar' % os.pathsep) == [unfrackpath('/foo/bar')]
    assert unfrack_path(pathsep=True)('/foo/bar%s' % os.pathsep) == [unfrackpath('/foo/bar')]

# Generated at 2022-06-10 22:04:58.649517
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    aV = AnsibleVersion()
    try:
        aV.__call__(None, None, None, None)
    except SystemExit:
        assert True



# Generated at 2022-06-10 22:05:07.484793
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():

    class Args:
        def __init__(self, prog):
            self.prog = prog

    args = Args('foo')
    action = AnsibleVersion()
    assert action(None, args, None) == None
    assert "\n" not in ansible_version
    assert "ansible-config" in ansible_version
    assert args.prog in ansible_version
    assert ansible.__version__ in ansible_version
    assert j2_version in ansible_version
    if HAS_LIBYAML:
        assert "with the pyyaml Python library" in ansible_version
    else:
        assert "without the pyyaml Python library" in ansible_version



# Generated at 2022-06-10 22:05:20.764789
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    def get_options(f):
        return [x.option_strings for x in f._actions]
    f = SortingHelpFormatter()
    f.add_argument("-c", "--ccc")
    f.add_argument("-b", "--bbb")

    f1 = SortingHelpFormatter()
    f1.add_argument("-a", "--aaa")
    f1.add_argument("-d", "--ddd")

    f.add_arguments(f1._actions)
    expected = [['-a', '--aaa'], ['-b', '--bbb'], ['-c', '--ccc'], ['-d', '--ddd']]
    assert get_options(f) == expected

#
# General purpose OptionParsers
#

# Generated at 2022-06-10 22:05:22.108437
# Unit test for function version
def test_version():
    assert version().startswith(__version__)



# Generated at 2022-06-10 22:05:34.616438
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    v=AnsibleVersion("ansible-version")
    with pytest.raises(SystemExit):
        v("ansible-version")



# Generated at 2022-06-10 22:05:43.761426
# Unit test for function unfrack_path
def test_unfrack_path():
    '''Verify function unfrack_path returns correct value with and without options'''
    path = "~/.ansible"
    expected_path = os.path.expanduser(path)
    actual_path = unfrack_path()(path)
    assert(actual_path == expected_path)
    path = "~/.ansible:~/.ansible/plugins"
    expected_path = [os.path.expanduser(x) for x in path.split(':')]
    actual_path = unfrack_path(True)(path)
    assert(actual_path == expected_path)


#
# Functions that build specific OptionParsers
#

# Generated at 2022-06-10 22:05:52.896696
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/test/path') == '/test/path'
    assert unfrack_path()('/test/path/../foo') == '/test/foo'
    assert unfrack_path(pathsep=True)('/test/path:/test/path2') == ['/test/path', '/test/path2']
    assert unfrack_path(pathsep=True)('/test/path/../foo:../foo') == ['/test/foo', '../foo']
    assert unfrack_path(pathsep=True)('../foo') == ['../foo']



# Generated at 2022-06-10 22:05:56.004393
# Unit test for function unfrack_path
def test_unfrack_path():
    # data is not a path
    assert unfrack_path()('') == ''
    # data is a path
    assert unfrack_path()('/path') == '/path'



# Generated at 2022-06-10 22:05:59.617147
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # ansible_version = to_native(version(getattr(parser, 'prog')))
    # print(ansible_version)
    # parser.exit()
    pass


# Generated at 2022-06-10 22:06:04.298293
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog='ansible')
    parser.add_argument('--version', dest='version', action=AnsibleVersion)
    parser.parse_args(['--version'])



# Generated at 2022-06-10 22:06:08.937622
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~/foo') == '~/foo'
    assert unfrack_path()('./foo') == './foo'
    assert unfrack_path(True)('~/foo:./bar') == ['~/foo', './bar']


#
# OptionParsers
#

# Generated at 2022-06-10 22:06:10.818020
# Unit test for function version
def test_version():
    assert version() == '2.11.0.dev0'

# Generated at 2022-06-10 22:06:21.443636
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    import io
    import sys
    import tempfile
    test_argv = [
        sys.executable,
        '-c',
        'from __main__ import SortingHelpFormatter, test_SortingHelpFormatter; test_SortingHelpFormatter()'
    ]
    output = tempfile.TemporaryFile(mode='w+')

# Generated at 2022-06-10 22:06:25.820575
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    sys.argv=['ansible', '--version']
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action=AnsibleVersion, default=argparse.SUPPRESS)
    args = parser.parse_args()
    assert args.version is None


# Generated at 2022-06-10 22:07:11.732066
# Unit test for function unfrack_path
def test_unfrack_path():
    # Usage of unfrack_path without pathsep
    assert unfrack_path()('test') == 'test', 'unfrack_path should return string as is'
    assert unfrack_path()('test/test') == 'test/test', 'unfrack_path should return string as is'
    assert unfrack_path(pathsep=True)('test/test') != 'test/test', 'unfrack_path should return list'
    # Usage of unfrack_path with pathsep=True
    assert unfrack_path(pathsep=True)('test/test:test/test') == ['test/test', 'test/test'], 'unfrack_path should return list splitted by :'


# Generated at 2022-06-10 22:07:20.235994
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """
    Test the PrependListAction class
    """
    # Test that a ValueError is raised if nargs is zero
    try:
        PrependListAction(
            "--foo",
            "--foo",
            nargs=0
        )
        assert False, "Should not reach this block, should raise ValueError for nargs=0"
    except ValueError:
        pass

    # Test that a ValueError is raised if const is not OPTIONAL and nargs is OPTIONAL
    try:
        PrependListAction(
            "--foo",
            "--foo",
            nargs=argparse.OPTIONAL,
            const=['foo']
        )
        assert False, "Should not reach this block, should raise ValueError for const and nargs not OPTIONAL"
    except ValueError:
        pass

    #

# Generated at 2022-06-10 22:07:30.564225
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()

    parser.add_argument('--foo', action='store_true', help='this is foo')
    parser.add_argument('--bar', action='store_true', help='this is bar')
    parser.add_argument('--apple', action='store_true', help='this is apple')
    parser.add_argument('--zebra', action='store_true', help='this is zebra')

    f = SortingHelpFormatter()
    new = parser.parse_args(args=[], namespace=argparse.Namespace())


# Generated at 2022-06-10 22:07:35.939379
# Unit test for function unfrack_path
def test_unfrack_path():
    expected_path = 'ansible/test/test_module.py'
    unfrack_path_result = unfrack_path()(expected_path)
    assert unfrack_path_result == expected_path, 'unfrack_path value not correct'


# Generated at 2022-06-10 22:07:44.388596
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    with tempfile.NamedTemporaryFile('w+t') as tmpfile:
        filename = tmpfile.name
        infile = open(filename, "w")
        outfile = open("/tmp/outfile", "r")
        sys.stdin = infile
        sys.stdout = outfile
        parser = argparse.ArgumentParser()
        parser.add_argument('--version', action=AnsibleVersion)
        ns = parser.parse_args(["--version"])
        assert ns == argparse.Namespace(version=None)
        assert outfile.read() == version("ansible-playbook")
        infile.close()
        outfile.close()



# Generated at 2022-06-10 22:07:55.142500
# Unit test for function unfrack_path
def test_unfrack_path():
    """Unit test for function unfrack_path"""
    assert unfrack_path()('/usr/share/ansible:/usr/share/ansible/roles') == ['/usr/share/ansible', '/usr/share/ansible/roles']
    assert unfrack_path(pathsep=True)('/usr/share/ansible:/usr/share/ansible/roles') == '/usr/share/ansible:/usr/share/ansible/roles'
    assert unfrack_path()('./library:/usr/share/ansible/roles') == ['./library', '/usr/share/ansible/roles']

# Generated at 2022-06-10 22:07:58.539322
# Unit test for function version
def test_version():
    prog = 'ansible-playbook'
    ver = version(prog)
    assert ver.startswith(prog)
    assert prog in ver
    assert __version__ in ver
#
# OptionParser preparation/creation
#

# Generated at 2022-06-10 22:08:01.392323
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/foo") == "/foo"
    assert unfrack_path()("foo") == "['foo']"
    assert unfrack_path(pathsep=True)("foo:/bar/yoo") == ["foo", "/bar/yoo"]


# Generated at 2022-06-10 22:08:05.049435
# Unit test for function unfrack_path
def test_unfrack_path():
    # Not testing os.pathsep because it's platform dependent
    assert unfrack_path(pathsep=False)('~/testing') == os.path.expanduser('~/testing')
    assert unfrack_path(pathsep=False)('-') == '-'

