

# Generated at 2022-06-10 21:58:49.865837
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    opt, _ = parser.parse_known_args(['-o', '-t', 'pwd'])
    assert opt.one_line == True and opt.tree == 'pwd'


# Generated at 2022-06-10 21:58:54.353816
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    p = parser.parse_args(args=[])
    assert p.check == False
    assert p.syntax == False
    assert p.diff == False



# Generated at 2022-06-10 21:58:59.637111
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    try:
        parser = argparse.ArgumentParser()
        add_tasknoplay_options(parser)
        # No Exception was raised
        assert True
        # print("Test for add_tasknoplay_options passed")
    except:
        # print("Test for add_tasknoplay_options FAILED")
        assert False

test_add_tasknoplay_options()



# Generated at 2022-06-10 21:59:10.074999
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = create_base_parser('ansible-playbook')
    add_vault_options(parser)
    options, args = parser.parse_known_args(['--ask-vault-password'])
    assert options.ask_vault_pass is True
    options, args = parser.parse_known_args(['--ask-vault-pass'])
    assert options.ask_vault_pass is True
    options, args = parser.parse_known_args(['--vault-password-file', 'passwd'])
    assert options.vault_password_files[0] == 'passwd'
    options, args = parser.parse_known_args(['--vault-pass-file', 'passwd'])
    assert options.vault_password_files[0] == 'passwd'



# Generated at 2022-06-10 21:59:16.683167
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options, args = parser.parse_known_args(['--vault-id', 'joe','--ask-vault-pass','--vault-password-file',
                                             'test/test_ansible_vault.txt'])

    assert options.vault_ids == ['joe']
    assert options.vault_password_files == ['test/test_ansible_vault.txt']
    assert options.ask_vault_pass == True




# Generated at 2022-06-10 21:59:22.009791
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    args = parser.parse_args(['-b', '--become-user', 'some_user'])

    assert args.become == True
    assert args.become_user == 'some_user'
    assert args.become_prompt == False



# Generated at 2022-06-10 21:59:24.637729
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    assert parser._actions



# Generated at 2022-06-10 21:59:36.656117
# Unit test for function unfrack_path
def test_unfrack_path():
    if not os.path.isfile('/usr/bin/env'):
        raise AssertionError('This test requires /usr/bin/env to be a file')
    if not os.path.isdir('/usr/bin'):
        raise AssertionError('This test requires /usr/bin to be a directory')

    # test with True
    ret = unfrack_path(True)
    if ret('/usr/bin/env:/usr/bin'):
        raise AssertionError('Expected the return of [\'/usr/bin/env\', \'/usr/bin\'] got %s' % ret('/usr/bin/env:/usr/bin'))

# Generated at 2022-06-10 21:59:45.527632
# Unit test for function ensure_value
def test_ensure_value():
    argparse_namespace = argparse.Namespace()
    x = ensure_value(argparse_namespace, "foo", [1, 2, 3])
    assert x == [1, 2, 3]
    assert argparse_namespace.foo == x
    x.append(4)
    assert argparse_namespace.foo == x
    assert ensure_value(argparse_namespace, "foo", [0]) == x


#
# Main OptionParsers
#

# Generated at 2022-06-10 21:59:48.858114
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)


# Generated at 2022-06-10 22:00:00.159625
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument("--append", action=PrependListAction)
    args = parser.parse_args("--append 1 --append 2 3 --append 4 5 6".split())
    assert args.append == [1, 4, 5, 6, 2, 3]


# Generated at 2022-06-10 22:00:08.248470
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path/to/file') == '@./path/to/file'
    assert maybe_unfrack_path('@')('@@/path/to/file') == '@@/path/to/file'
    assert maybe_unfrack_path('@@')('@@/path/to/file') == '@@./path/to/file'
    assert maybe_unfrack_path('@@')('@/path/to/file') == '@/path/to/file'



# Generated at 2022-06-10 22:00:21.209154
# Unit test for function add_connect_options
def test_add_connect_options():
    ansible = __import__('ansible')
    options = ansible.utils.args.Namespace()

# Generated at 2022-06-10 22:00:25.694348
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = Mock()
    add_inventory_options(parser)
    assert parser.add_argument.call_count == 3
    assert parser.add_argument.call_args_list[0][0][0] == '-i'
    assert parser.add_argument.call_args_list[0][1]['help'].split(' ')[0] == 'specify'
    assert parser.add_argument.call_args_list[0][1]['action'] == 'append'
    assert parser.add_argument.call_args_list[1][0][0] == '--list-hosts'
    assert parser.add_argument.call_args_list[2][0][0] == '-l'
    assert parser.add_argument_group.call_count == 0
#
# Functions to add an OptionParser and Options for

# Generated at 2022-06-10 22:00:38.637229
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser(prog='ansible-inventory')
    parser.add_argument('--extra-var', action=PrependListAction, dest='extra_vars', metavar='key=value')
    parser.parse_args(['--extra-var', 'foo=bar', '--extra-var', 'baz=baz'])

    ns = parser.parse_args([])
    assert isinstance(getattr(ns, 'extra_vars'), list)
    assert not getattr(ns, 'extra_vars')

    ns = parser.parse_args(['--extra-var', 'foo=bar', '--extra-var', 'baz=baz'])
    assert getattr(ns, 'extra_vars') == ['foo=bar', 'baz=baz']



# Generated at 2022-06-10 22:00:42.366288
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/path/to/yaml') == '/path/to/yaml'
    assert unfrack_path()('/path/to/yaml/') == '/path/to/yaml/'
    assert unfrack_path()('../../yaml') == '../../yaml'

# Generated at 2022-06-10 22:00:44.139040
# Unit test for function add_inventory_options
def test_add_inventory_options():
    v = vars(parser.parse_args(args=[].append('-i', 'hosts', '--list-hosts')))
    assert v['inventory'] == 'hosts'
    assert v['listhosts'] == True
    assert v['subset'] == C.DEFAULT_SUBSET



# Generated at 2022-06-10 22:00:45.161166
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)

    assert parser is not None



# Generated at 2022-06-10 22:00:47.663809
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == '/foo'
    assert unfrack_path(pathsep=True)('/foo:/bar') == ['/foo', '/bar']

# Generated at 2022-06-10 22:00:50.884434
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(prog="ansible-playbook")
    add_subset_options(parser)
    opts = parser.parse_args([])

    assert opts.tags == []
    assert opts.skip_tags == []

    opts = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip1', '--skip-tags', 'skip2'])

    assert opts.tags == ['tag1', 'tag2']
    assert opts.skip_tags == ['skip1', 'skip2']



# Generated at 2022-06-10 22:01:03.998586
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-t', action=PrependListAction, dest='targets',
        default=[]
    )
    args = parser.parse_args('-t a -t b'.split())
    assert args.targets == ['a', 'b']



# Generated at 2022-06-10 22:01:10.803555
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@/test") == "@" + unfrackpath("/test")
    assert maybe_unfrack_path("@")("~/test") == "~/test"
    assert maybe_unfrack_path("@")("@/test") == "@" + unfrackpath("/test")
    assert maybe_unfrack_path("@")("@/test") == "@" + unfrackpath("/test")


# Generated at 2022-06-10 22:01:17.794118
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from ansible.cli.argparse.__init__ import AnsibleVersion
    ansible_version = to_native(version('ansible'))
    assert AnsibleVersion.__call__(None, parser=None, namespace=None, values=None, option_string=None) == print(ansible_version)
    assert AnsibleVersion.__call__(None, parser=None, namespace=None, values=None, option_string=None) == parser.exit()


# Generated at 2022-06-10 22:01:22.439090
# Unit test for function unfrack_path
def test_unfrack_path():
    expected_single = '/some/path'
    expected_multi = ['/some/path1', '/some/path2']
    result_single = unfrack_path()(expected_single)
    result_multi = unfrack_path(pathsep=True)(":".join(expected_multi))

    assert expected_single == result_single
    assert expected_multi == result_multi



# Generated at 2022-06-10 22:01:27.555311
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    prepend_list_action = PrependListAction([], "append_const", const=None, default=None)
    parser = Parser()
    parser.parse_args(["-a"])
    parser.add_argument("-a")
    parser.add_argument("-b", action="PrependListAction")



# Generated at 2022-06-10 22:01:35.865629
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace_obj = argparse.Namespace()
    for value1 in ['all', '192.168.1.1', '192.168.1.2']:
        action_obj = PrependListAction(option_strings = [], dest = 'ip', required = False, help = None, metavar = None)
        value2 = [value1]
        action_obj(parser = None, namespace = namespace_obj, values = value2, option_string = None)
        assert getattr(namespace_obj, 'ip') == value2

#
# Option Paser Factories
#

# Generated at 2022-06-10 22:01:38.073503
# Unit test for function add_inventory_options
def test_add_inventory_options():
    obj = argparse.ArgumentParser()
    add_inventory_options(obj)
    return obj
# Test function add_inventory_options



# Generated at 2022-06-10 22:01:40.981486
# Unit test for function add_connect_options
def test_add_connect_options():
   parser = argparse.ArgumentParser()
   add_connect_options(parser)
   args = parser.parse_args('--private-key=test'.split())
   assert type(args.private_key_file) is str
   pass



# Generated at 2022-06-10 22:01:46.046193
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('somepath') == 'somepath'
    assert unfrack_path()('/somepath') == '/somepath'
    assert unfrack_path()('/somepath/') == '/somepath'
    assert unfrack_path()('~/somepath') == os.path.expanduser('~/somepath')
    assert unfrack_path()('~/somepath/') == os.path.expanduser('~/somepath')



# Generated at 2022-06-10 22:01:52.610886
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action=PrependListAction, nargs='+')

    ns = parser.parse_args('--foo a b c'.split())
    assert ns.foo == ['a', 'b', 'c']
    ns = parser.parse_args('--foo a --foo b --foo c'.split())
    assert ns.foo == ['a', 'b', 'c']


# Generated at 2022-06-10 22:02:13.737452
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = Mock()
    add_runtask_options(parser)
    assert parser.add_argument.call_count == 1
    assert parser.add_argument.call_args[1]['dest'] == "extra_vars"
    assert parser.add_argument.call_args[1]['action'] == "append"
    #assert parser.add_argument.call_args[1]['type'] == maybe_unfrack_path('@')
    assert parser.add_argument.call_args[1]['help'] == "set additional variables as key=value or YAML/JSON, if filename prepend with @"
    assert parser.add_argument.call_args[1]['default'] == []



# Generated at 2022-06-10 22:02:21.787808
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.config.manager import ConfigManager
    from ansible.utils import context_objects as co
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib

    args = ['--become']
    parser = ConfigManager._get_parser()
    ns = parser.parse_args(args)
    co.GlobalCLIArgs._set(ns)

# Generated at 2022-06-10 22:02:27.131462
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    extra_vars = parser.parse_args(['-e', 'a=b'])
    assert extra_vars.extra_vars == ['a=b']
    extra_vars = parser.parse_args(['-e', 'x=1', '-e', '@yaml.json'])
    assert extra_vars.extra_vars == ['x=1', '@yaml.json']
    extra_vars = parser.parse_args(['-e', '{\"x\": 3}'])
    assert extra_vars.extra_vars == ['{\"x\": 3}']

# Generated at 2022-06-10 22:02:35.405500
# Unit test for function unfrack_path
def test_unfrack_path():
    # Parameter None
    assert unfrack_path()(None) == ''
    # Parameter empty
    assert unfrack_path()('') == ''
    # Parameter '-'
    assert unfrack_path()('-') == '-'
    # Parameter with os.pathsep
    assert unfrack_path(True)('a' + os.pathsep + 'b') == ['a', 'b']
    # Parameter ending in os.sep
    assert unfrack_path()('a' + os.sep) == 'a'



# Generated at 2022-06-10 22:02:37.122729
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # FIXME: Add tests!
    raise NotImplementedError


# Generated at 2022-06-10 22:02:39.396370
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/test') == '@' + unfrackpath('/test')
    assert maybe_unfrack_path('@')('/test') == '/test'
    assert maybe_unfrack_path('@')('hello') == 'hello'



# Generated at 2022-06-10 22:02:46.603079
# Unit test for function unfrack_path
def test_unfrack_path():
    if 'FRACK' in os.environ:
        del os.environ['FRACK']

    if os.path.sep == '\\':
        path1 = os.path.expanduser('~\\ansible')
        path2 = os.path.expanduser('~\\ansible\\mydir')
    else:
        path1 = os.path.expanduser('~/ansible')
        path2 = os.path.expanduser('~/ansible/mydir')

    p = unfrack_path()
    assert p(path1) == path1
    assert p(path2) == path2

    if os.path.sep == '\\':
        path1 = 'FRACK\\ansible'
        path2 = 'FRACK\\ansible\\mydir'

# Generated at 2022-06-10 22:02:50.858262
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    TestParser = argparse.ArgumentParser()
    TestParser.add_argument('--version', action=AnsibleVersion)
    TestParser.parse_args(['--version'])
    assert True



# Generated at 2022-06-10 22:02:58.324905
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/path/to/file") == "/path/to/file"
    assert unfrack_path(pathsep=True)("/path/to/file:/path/to/another") == ['/path/to/file', '/path/to/another']
    assert unfrack_path(pathsep=True)("/path/to/file:") == ['/path/to/file']
    assert unfrack_path(pathsep=True)("/path/to/file:/path/to/another:") == ['/path/to/file', '/path/to/another']
    assert unfrack_path()("-") == "-"
    assert unfrack_path(pathsep=True)("") == []
    assert unfrack_path(pathsep=True)(":") == []
    assert unfrack

# Generated at 2022-06-10 22:03:07.600037
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    expect_extra_vars = []
    got_extra_vars = getattr(parser.parse_args([]), "extra_vars")
    assert got_extra_vars == expect_extra_vars, test_msg.format(expect_extra_vars, got_extra_vars)
    got_extra_vars = getattr(parser.parse_args(["--extra-vars", "k1=v1", "--extra-vars", "@file.yml"]), "extra_vars")
    expect_extra_vars = ["k1=v1", "@file.yml"]

# Generated at 2022-06-10 22:03:24.564525
# Unit test for function add_async_options
def test_add_async_options():
    from ansible.cli import CLI

    parser = CLI.base_parser(constants=C)
    add_async_options(parser)
    args = parser.parse_args([])
    assert args.poll_interval == 5
    args = parser.parse_args(["-P", "42"])
    assert args.poll_interval == 42
    assert args.seconds == 0

    # There is no test coverage for this code path and there is no other way to cover it
    args = parser.parse_args(["-B", "42"])  # pragma: no cover
    assert args.seconds == 42


# Generated at 2022-06-10 22:03:35.717747
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    # -P option
    args = parser.parse_args(['-P', '10'])
    assert 10 == args.poll_interval, 'Unexpected poll_interval returned by args'
    # --poll option
    args = parser.parse_args(['--poll', '10'])
    assert 10 == args.poll_interval, 'Unexpected poll_interval returned by args'
    # -B option
    args = parser.parse_args(['-B', '10'])
    assert 10 == args.seconds, 'Unexpected seconds returned by args'
    # --background option
    args = parser.parse_args(['--background', '10'])
    assert 10 == args.seconds, 'Unexpected seconds returned by args'
   

# Generated at 2022-06-10 22:03:39.846112
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class FakeParser():
        def exit(self):
            pass
    output = 'UNDEFINED'
    def fake_print(obj):
        global output
        output = obj
    old_print = print
    print = fake_print
    try:
        argparse.ArgumentParser().add_argument('test',
                                               action=AnsibleVersion)
    except SystemExit:
        pass
    print = old_print
    assert (output == to_native(version('UNDEFINED')))
test_AnsibleVersion___call__()



# Generated at 2022-06-10 22:03:46.750015
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)("/a/b/c:/c/d/e:/f/g/h:/i/j/k") == ['/a/b/c', '/c/d/e', '/f/g/h', '/i/j/k']
    assert unfrack_path()("/a/b/c:/c/d/e:/f/g/h:/i/j/k") == '/a/b/c:/c/d/e:/f/g/h:/i/j/k'



# Generated at 2022-06-10 22:03:50.815473
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path(pathsep=True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-10 22:03:59.681349
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description="Arguments sorted by option strings", formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', help="Foo help")
    parser.add_argument('--bar', help="Bar help")
    try:
        parser.parse_args(args=["--help"])
    except SystemExit:
        if parser.exit_code == 0:
            print("Tests passed in test_SortingHelpFormatter")
            return
        raise



# Generated at 2022-06-10 22:04:02.056538
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)("/path/to/nowhere") == "/path/to/nowhere"


# Generated at 2022-06-10 22:04:05.727852
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ['path1', 'path2'] == unfrack_path(True)('path1:path2')
    assert 'path1' == unfrack_path(False)('path1')
    assert '-' == unfrack_path(False)('-')


# Generated at 2022-06-10 22:04:09.953429
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo/bar') == '/foo/bar'
    assert unfrack_path()('/foo/bar::/qux/baz') == '/foo/bar::/qux/baz'



# Generated at 2022-06-10 22:04:14.875337
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(prog='ansible-config')
    add_async_options(parser)
    opts = parser.parse_args(['-P', '10', '-B', '30'])
    assert opts.poll_interval == 10
    assert opts.seconds == 30



# Generated at 2022-06-10 22:04:22.524960
# Unit test for function version
def test_version():
    assert version()
    assert version('ansible')



# Generated at 2022-06-10 22:04:29.555371
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # we can also call the append action to simulate the behavior of the prepend one
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='append')
    args = parser.parse_args('-a 1 -a 2 -a 2'.split())
    assert args.a == ['1','2','2']

#
# Utilities
#

# Generated at 2022-06-10 22:04:37.799960
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():

    class Namespace(object):
        pass

    parser = argparse.ArgumentParser()

    parser.add_argument('--test1', action=PrependListAction, dest='test')
    parser.add_argument('--test2', action=PrependListAction, dest='test')
    parser.add_argument('--test3', action=PrependListAction, dest='test')
    parser.add_argument('--test4', action=PrependListAction, dest='test')
    args = parser.parse_args(['--test1=one', '--test2', 'two', '--test3=three', '--test4', 'four'])

    assert args.test == ['three', 'two', 'one', 'four']  # The order is important
# Class PrependListAction is needed by ansible.constants.CONFIGURABLE

# Generated at 2022-06-10 22:04:41.990407
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    action = AnsibleVersion()
    namespace = argparse.Namespace()
    values = []
    option_string = None
    action(parser, namespace, values, option_string)



# Generated at 2022-06-10 22:04:49.954066
# Unit test for function unfrack_path
def test_unfrack_path():
    """Test for function unfrack_path"""
    normalize = unfrack_path()
    assert os.path.join('url', 'to', 'file') == normalize(os.path.join('url', 'to', 'file'))
    assert os.path.join('url', 'to', 'file') == normalize('url' + os.sep + 'to' + os.sep + 'file')
    assert os.path.join('url', 'to', 'file') == normalize('url' + os.path.sep + 'to' + os.path.sep + 'file')


# Generated at 2022-06-10 22:04:56.024143
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.parsing.vault import VaultLib
    try:
        from ansible.parsing.vault import VaultEditor
    except ImportError:
        pass

    assert unfrack_path()('ansible.cfg') == unfrackpath('ansible.cfg')
    assert unfrack_path()('~/ansible.cfg') == os.path.join(os.path.expanduser("~"), 'ansible.cfg')
    assert unfrack_path()('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'

# Generated at 2022-06-10 22:05:06.470315
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from io import StringIO
    from ansible import __version__ as ansible_version
    from ansible.cli.arguments import AnsibleVersion
    from ansible.cli.arguments import SortingHelpFormatter
    from ansible.utils._text import to_bytes

    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-v', '--version', nargs=0, default=False, action=AnsibleVersion)
    args = parser.parse_args(['-v'])
    assert args.version is True

    # parser.exit() prints to stderr, check stdout separately to compare with ansible --version output
    output = StringIO()
    sys.stdout = output

# Generated at 2022-06-10 22:05:08.306829
# Unit test for function version
def test_version():
    assert version() is not None
    assert len(version()) > 1


# Generated at 2022-06-10 22:05:21.523519
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from collections import namedtuple
    from ansible.utils.collection_loader import _get_collection_version
    _namespace = namedtuple('Fake_Namespace', ['config', 'config_file', 'debug', 'diff', 'inventory', 'skip_tags', 'start_at_task', 'subset', 'tags', 'verbosity'])
    # First test
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--prepend-list', nargs='+', action=PrependListAction)
    arg1 = ['-b', 'foo', '-b', 'bar']
    args = vars(parser.parse_args(arg1))
    namespace = _namespace(**args)
    # Second test
    parser = argparse.ArgumentParser()

# Generated at 2022-06-10 22:05:29.648752
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    line = 'test_line'
    attr = 'test_attr'
    option_string = 'test_option_string'
    parser = 'test_parser'
    namespace = type('test', (object,), {})()
    ensure_value(namespace, attr, []).append(1)
    ensure_value(namespace, attr, []).append(2)
    ensure_value(namespace, attr, []).append(3)
    values = [4, 5]
    PrependListAction([]).__call__(parser, namespace, values, option_string=option_string)
    assert getattr(namespace, attr) == [4, 5, 1, 2, 3]



# Generated at 2022-06-10 22:05:54.881708
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("foo/bar") == unfrackpath("foo/bar")
    assert unfrack_path(pathsep=True)("foo/bar:bam/baz") == [unfrackpath("foo/bar"), unfrackpath("bam/baz")]
    assert unfrack_path()("-") == "-"
    assert unfrack_path(pathsep=True)("--") is None
    assert unfrack_path(pathsep=True)("-:--:foo/bar:bam/baz") == [unfrackpath("foo/bar"), unfrackpath("bam/baz")]

# Generated at 2022-06-10 22:06:01.501314
# Unit test for function unfrack_path
def test_unfrack_path():
    # call the function to test
    result1 = unfrack_path()("..")
    if result1 == ".":
        print("test unfrack_path()('..') success!")
    else:
        print("test unfrack_path()('..') failed!")
    result2 = unfrack_path()("..")
    if result2 == ".":
        print("test unfrack_path()('..') success!")
    else:
        print("test unfrack_path()('..') failed!")


# Generated at 2022-06-10 22:06:06.992291
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass

    # testing for
    #     items = copy.copy(ensure_value(namespace, self.dest, []))
    #     items[0:0] = values
    #     setattr(namespace, self.dest, items)
    # callwith


#
# Private utils
#

# Generated at 2022-06-10 22:06:10.768099
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(False)('/path/to/file') == unfrackpath('/path/to/file')
    assert unfrack_path(True)('/path/to/file:/path/to/file2') == [unfrackpath('/path/to/file'), unfrackpath('/path/to/file2')]



# Generated at 2022-06-10 22:06:11.640074
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass



# Generated at 2022-06-10 22:06:15.758053
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('a_b') == unfrack_path()('a_b') # True
    assert unfrack_path()('a_b') != unfrack_path()('c_d') # False
# Fin de unit test


# Generated at 2022-06-10 22:06:26.534770
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    '''
    This test module is used to detect whether this class can prepend the list value
    instead of appending.
    '''
    class MockParser(object):
        def error(self, message):
            raise Exception(message)
    mock_parser = MockParser()
    mock_namespace = argparse.Namespace()
    option_strings = None
    dest = 'mock_value'
    nargs = 1
    values = ['a', 'b']

    action = PrependListAction(option_strings, dest, nargs=nargs)
    action(mock_parser, mock_namespace, values)
    assert mock_namespace.mock_value == ['a', 'b']
    values.extend(['c', 'd'])
    action(mock_parser, mock_namespace, values)
   

# Generated at 2022-06-10 22:06:29.466602
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('~/xyz') == unfrackpath('~/xyz')
    assert unfrack_path(True)('~/xyz:/etc/xyz') == [unfrackpath('~/xyz'), unfrackpath('/etc/xyz')]


# Generated at 2022-06-10 22:06:35.993060
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    #
    # Test for method __call__(self, parser, namespace, values, option_string=None)
    #
    # Verify the expected Ansible version string is printed to stdout when the --version option is supplied to the
    # ansible-console executable.
    #
    import tempfile
    import unittest.mock as mock
    tf = tempfile.TemporaryFile()
    with mock.patch.object(sys, 'stdout', tf):
        argv = ['ansible-console', '--version']
        parser = argparse.ArgumentParser(argv[0])
        parser.add_argument('--version', action=AnsibleVersion)
        args = parser.parse_args(argv[1:])

    tf.seek(0)
    output = tf.read()
    tf.close()
    expected

# Generated at 2022-06-10 22:06:40.587168
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--list', action=PrependListAction)
        parser.parse_args(['--list', 'a'])
        parser.parse_args(['--list', 'a', 'b'])
    except:
        raise AssertionError



# Generated at 2022-06-10 22:07:16.303453
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action=PrependListAction)
    parser.add_argument('--list_with_const', action=PrependListAction, const='const')

    args = parser.parse_args('--list 1 --list 2 --list_with_const 3 4'.split())
    assert args.list == ['1', '2']
    assert args.list_with_const == ['3', 'const', '4']



# Generated at 2022-06-10 22:07:21.492446
# Unit test for function version
def test_version():
    assert version("test") == 'test [core 2.0.0.0]\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = /usr/share/ansible\n  ansible python module location = /usr/lib/python2.7/site-packages/ansible\n  executable location = /usr/bin/ansible-config\n  python version = 2.7.14 (default, Sep 23 2017, 22:06:14) \n[GCC 7.2.0]\n  jinja version = 2.9.6\n  libyaml = False'
test_version.unittest = True

# Generated at 2022-06-10 22:07:26.956000
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('-') == '-'
    assert unfrack_path()('/some/path') == '/some/path'
    assert unfrack_path(True)('/some/path') == ['/some/path']
    assert unfrack_path(True)('/some/path:/some/other/path') == ['/some/path', '/some/other/path']


#
# Helper Functions
#

# Generated at 2022-06-10 22:07:33.219775
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument = mock.MagicMock()
    parser.exit = mock.MagicMock()
    action = AnsibleVersion()
    action(someargs)
    parser.add_argument.assert_any_call()
    parser.exit.assert_any_call()

# Generated at 2022-06-10 22:07:38.052779
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()
    PrependListAction(option_strings=('-p', '--prepend'), dest='names', nargs='+')(namespace, ['foo'], option_string='-p')
    assert namespace.names == ['foo']



# Generated at 2022-06-10 22:07:43.862925
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    action_instance = PrependListAction('--foo', dest='bar', nargs='+', help='help msg')
    assert action_instance.__getattribute__('option_strings') == ['--foo']
    assert action_instance.__getattribute__('dest') == 'bar'
    assert action_instance.__getattribute__('nargs') == '+'
    assert action_instance.__getattribute__('help') == 'help msg'


# Generated at 2022-06-10 22:07:48.840912
# Unit test for function unfrack_path
def test_unfrack_path():
    # Path separator
    assert unfrack_path(True)('foo:/bar:../baz') == ['foo', '/bar', '../baz']
    # No path separator
    assert unfrack_path(False)('foo') == 'foo'
    assert unfrack_path(False)('-') == '-'


# Generated at 2022-06-10 22:07:52.533280
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == unfrackpath('foo')
    assert unfrack_path(pathsep=True)('foo:bar') == [unfrackpath('foo'), unfrackpath('bar')]



# Generated at 2022-06-10 22:07:59.943261
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()

    action = PrependListAction(
        option_strings=['--test'],
        dest='test_name'
    )

    action(
        parser=object(),
        namespace=namespace,
        values=['test_value1']
    )
    assert namespace.test_name == ['test_value1']

    action(
        parser=object(),
        namespace=namespace,
        values=['test_value2']
    )
    assert namespace.test_name == ['test_value2', 'test_value1']
# end of test case 

# Generated at 2022-06-10 22:08:09.448549
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path_test = unfrack_path()
    assert unfrack_path_test('/tmp') == ['/tmp']
    assert unfrack_path_test('/tmp/path/') == ['/tmp/path']
    assert unfrack_path_test('/tmp/path') == ['/tmp/path']
    assert unfrack_path_test('~/file') == [os.path.expanduser('~') + '/file']
    assert unfrack_path_test('~/file/') == [os.path.expanduser('~') + '/file']
    assert unfrack_path_test('~/file/') == [os.path.expanduser('~') + '/file']
    assert unfrack_path_test('/tmp') == ['/tmp']