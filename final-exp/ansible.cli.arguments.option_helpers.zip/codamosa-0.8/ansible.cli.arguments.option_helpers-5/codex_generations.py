

# Generated at 2022-06-10 21:59:00.155012
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(prog='test')
    add_connect_options(parser)
    args = parser.parse_args(['-c', 'connection-test', '-T', '10', '--ssh-common-args', 'common-test', '--sftp-extra-args', 'sftp-test', '--scp-extra-args', 'scp-test', '--ssh-extra-args', 'ssh-test', '-k', '-D'])
    assert args.connection == 'connection-test'
    assert args.timeout == 10
    assert args.ssh_common_args == 'common-test'
    assert args.sftp_extra_args == 'sftp-test'
    assert args.scp_extra_args == 'scp-test'
    assert args.ssh_

# Generated at 2022-06-10 21:59:08.371497
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    tests = {
        # Does not have the beacon, should be the same
        'hello': 'hello',

        # Has the beacon, but is already an absolute path, should be the same
        '@/hello': '@/hello',

        # Has the beacon, but is a relative path, should be transformed
        '@hello': '@/ansible/hello',
    }

    for value, expected in tests.items():
        assert maybe_unfrack_path('@')(value) == expected



# Generated at 2022-06-10 21:59:21.500281
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='test_add_runas_option')
    add_runas_options(parser)
    options, args = parser.parse_known_args()
    assert options.become == True, "default become value not True"
    assert options.become_method == C.DEFAULT_BECOME_METHOD, "default become_method value not %s" % C.DEFAULT_BECOME_METHOD
    assert options.become_user == C.DEFAULT_BECOME_USER, "default become_user value not %s" % C.DEFAULT_BECOME_USER
    # Special call to test options added by the "prompt" version of the option
    testargs = ['--become-password', '-k', '--ask-become-pass']
    options, args = parser

# Generated at 2022-06-10 21:59:27.945607
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    (options, args) = parser.parse_known_args(["-o","-t","tree"])
    assert options.one_line == True, options.one_line
    assert options.tree == 'tree', options.tree


# Generated at 2022-06-10 21:59:39.153616
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    assert parser.parse_args('--private-key  /foo/bar/abcde').private_key_file == '/foo/bar/abcde'
    maybe_unfrack_path('/foo/bar')('/foo/bar/abcde') == '/foo/bar/abcde'
    assert parser.parse_args('--ssh-common-args -o ConnectionAttempts=N').ssh_common_args == '-o ConnectionAttempts=N'
    assert parser.parse_args('--sftp-extra-args -o ConnectionAttempts=N').sftp_extra_args == '-o ConnectionAttempts=N'

# Generated at 2022-06-10 21:59:50.990476
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.utils.sentinel import Sentinel

    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    (args, extra_args) = parser.parse_known_args(['--private-key', '/path/to/key', '--connection', 'mock', '--timeout', '1',
                                                  '--ssh-common-args', 'common1 common2', '--sftp-extra-args', 'sftp1 sftp2',
                                                  '--scp-extra-args', 'scp1 scp2', '--ssh-extra-args', 'ssh1 ssh2',
                                                  '--connection-password-file', '/path/to/passwords'])
    assert args.private_key_file == '/path/to/key'

# Generated at 2022-06-10 21:59:55.158950
# Unit test for function add_vault_options
def test_add_vault_options():
    src_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_vault_options(src_parser)
    args = src_parser.parse_args('--vault-id qwerty --vault-id password --ask-vault-password --vault-password-file /etc/fizz'.split())
    assert len(args.vault_ids) == 2
    assert args.vault_ids[0].strip() == 'qwerty'
    assert args.vault_ids[1].strip() == 'password'
    assert args.ask_vault_pass is True
    assert len(args.vault_password_files) == 1
    assert args.vault_password_files[0].strip() == '/etc/fizz'

# Generated at 2022-06-10 22:00:05.463881
# Unit test for function add_connect_options
def test_add_connect_options():

    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args()

    assert args.private_key_file == unfrackpath(C.DEFAULT_PRIVATE_KEY_FILE)
    assert args.remote_user == C.DEFAULT_REMOTE_USER
    assert args.connection == C.DEFAULT_TRANSPORT
    assert args.timeout == C.DEFAULT_TIMEOUT
    assert args.ssh_common_args is None
    assert args.sftp_extra_args is None
    assert args.scp_extra_args is None
    assert args.ssh_extra_args is None



# Generated at 2022-06-10 22:00:15.272308
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true', help='aaa')
    parser.add_argument('-b', action='store_true', help='bbb')
    parser.add_argument('-z', action='store_true', help='zzz')
    output = parser.format_help()
    if output.index('-a') > output.index('-b') or output.index('-a') > output.index('-z'):
        raise Exception('Help not sorted properly')


#
# CLI arguments
#

# Generated at 2022-06-10 22:00:21.347432
# Unit test for function add_connect_options
def test_add_connect_options():
    """
    Dummy function to test add_connect_options
    :return:
    """
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_connect_options(parser)



# Generated at 2022-06-10 22:00:46.111700
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)

    # assert defaults are correct
    args = parser.parse_args([])
    assert args.vault_ids == []
    assert args.ask_vault_pass == C.DEFAULT_ASK_VAULT_PASS
    assert args.vault_password_files == []

    # assert -vault-id works
    args = parser.parse_args(['--vault-id', 'foo'])
    assert args.vault_ids == ['foo']

    # assert --vault-password-file works
    args = parser.parse_args(['--vault-password-file', '@filename'])
    assert args.vault_password_files == ['filename']

    # assert --vault-password-file=FOO is allowed


# Generated at 2022-06-10 22:00:51.461388
# Unit test for function add_vault_options
def test_add_vault_options():
    parser=argparse.ArgumentParser()
    add_vault_options(parser)
    args=parser.parse_args("--vault-id v-test --vault-password-file path".split())
    assert(args.vault_ids==["v-test"])
    assert(args.vault_password_files==["path"])

# Should we use the connection cache from an Ansible.cfg file?
# This method can be used to bypass the connection cache for a specific connection plug-in.
# Set config.cache_connection = False to globally bypass the connection cache

# Generated at 2022-06-10 22:01:03.324507
# Unit test for function add_module_options
def test_add_module_options():

    import os, sys
    from ansible.cli.argparse.utils import extend_parser
    from ansible.config.manager import ConfigManager

    new_arg_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter,
                                             conflict_handler='resolve')

    add_module_options(new_arg_parser)

    # Unit test to check add_module_options function works properly
    assert '-M' in new_arg_parser._option_string_actions
    assert new_arg_parser._option_string_actions['-M'].dest == 'module_path'

# Generated at 2022-06-10 22:01:07.599628
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args("-C -D".split())
    assert args.check, "check option should be set"
    assert args.diff, "diff option should be set"



# Generated at 2022-06-10 22:01:10.189517
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(["--inventory", "file.yaml"])
    assert args.inventory == ["file.yaml"]
    args = parser.parse_args(["--inventory", "file1.yaml",
                              "--inventory", "file2.yaml"])
    assert args.inventory == ["file1.yaml", "file2.yaml"]



# Generated at 2022-06-10 22:01:13.775120
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    options, _args = parser.parse_known_args(['-C', '-D'])
    assert options.check and options.diff
#
# Commands
#


# Generated at 2022-06-10 22:01:23.188141
# Unit test for function add_check_options
def test_add_check_options():
    parser=argparse.ArgumentParser(prog='test')
    add_check_options(parser)
    argv = ['ansible-playbook', '--version', '-P', '15', '-B', '30', '-C', '--syntax-check', '--diff']
    args = parser.parse_args(argv[1:])
    assert args.poll_interval == 15, "Poll interval is 15"
    assert args.seconds == 30, "Seconds is 30"
    assert args.check == True, "Check is true"
    assert args.syntax == True, "Syntax is True"
    assert args.diff == True, "Diff is True"

# Generated at 2022-06-10 22:01:28.349308
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacons = ('@', '@@', '@@@', '@@@,@@@,@@@', '@@@,@@@,@@@,@@@')
    value = '@~/ansible/var'
    for beacon in beacons:
        assert maybe_unfrack_path(beacon)(beacon + value) == beacon + value



# Generated at 2022-06-10 22:01:30.457870
# Unit test for function add_meta_options
def test_add_meta_options():
    """
    Unit test for function add_meta_options
    """
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert args.force_handlers is True
    assert args.flush_cache is True

# Generated at 2022-06-10 22:01:34.739215
# Unit test for function add_vault_options
def test_add_vault_options():
  parser = argparse.ArgumentParser(
      prog='test',
      formatter_class=SortingHelpFormatter,
      epilog=None,
      description=None,
      conflict_handler='resolve',
  )
  add_vault_options(parser)
  group = parser.add_mutually_exclusive_group()
  group.add_argument('--ask-vault-password', '--ask-vault-pass', default=C.DEFAULT_ASK_VAULT_PASS, dest='ask_vault_pass', action='store_true',
                            help='ask for vault password')

# Generated at 2022-06-10 22:02:01.670618
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    options = parser.parse_args('-t fred --tags chris -t jim --skip-tags=sally --skip-tags=dave'.split())

    assert options.tags == ['fred', 'chris', 'jim'], options.tags
    assert options.skip_tags == ['sally', 'dave'], options.skip_tags



# Generated at 2022-06-10 22:02:08.655709
# Unit test for function add_module_options
def test_add_module_options():
    """This is to test module option -M and --module-path
    """
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic

    # Test with -M
    basic.AnsibleModule.fail_json = lambda self, *args, **kwargs: None
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    options = parser.parse_args(['-M', 'test_module_path'])
    assert options.module_path == ['test_module_path']

    # Test with --module-path
    basic.AnsibleModule.fail_json = lambda self, *args, **kwargs: None
    parser = argparse.ArgumentParser()
    add_module_options(parser)

# Generated at 2022-06-10 22:02:13.976513
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog=sys.argv[0],
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_async_options(parser)
    (args, dummy_args) = parser.parse_known_args()
    assert args.poll_interval == C.DEFAULT_POLL_INTERVAL
    assert args.seconds == 0

# Generated at 2022-06-10 22:02:26.523222
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)("/path/to/some") == unfrackpath("/path/to/some")
    assert unfrack_path(pathsep=True)("/path/to/some:/some/other") == [unfrackpath('/path/to/some'), unfrackpath('/some/other')]
    assert unfrack_path(pathsep=True)("/path/to/some") == [unfrackpath('/path/to/some')]
    assert unfrack_path(pathsep=True)("/path/to/some:") == [unfrackpath('/path/to/some')]
    assert unfrack_path(pathsep=True)(":") == [unfrackpath('')]



# Generated at 2022-06-10 22:02:33.398824
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Test execution method __call__ of class version
    # Define a namespace to populate
    namespace = argparse.Namespace(version=C.__version__)

    # Create a fake parser
    parser = argparse.ArgumentParser(
        description="Test args",
        usage="Usage: test_version [options]")
    parser.add_argument('--version', action=AnsibleVersion)
    # Define arguments that should be parsed
    args = parser.parse_args([
        '--version'
    ])
    # Define expected result
    expected_result = argparse.Namespace(version=C.__version__)
    # Check if __call__ method of class AnsibleVersion returns the expected result
    assert namespace == expected_result
import sys
# Define the path to the directory that contains the fakes
path_fakes_

# Generated at 2022-06-10 22:02:39.448405
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', action=AnsibleVersion)
    options = parser.parse_args()
    ansible_version = to_native(version(getattr(parser, 'prog')))
    assert ansible_version == getattr(options, 'ansible_version')



# Generated at 2022-06-10 22:02:42.539767
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))

    assert(ansible_version is not None)



# Generated at 2022-06-10 22:02:46.329673
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ['a/b/c', 'b/c/d'] == unfrack_path(True)('a/b/c:b/c/d')
    assert 'a/b/c' == unfrack_path(False)('a/b/c')



# Generated at 2022-06-10 22:02:56.577628
# Unit test for function version
def test_version():
    """ validate the version string matches what is expected """
    venv = os.environ.copy()
    venv['ANSIBLE_TRANSPORT'] = 'local'
    venv['ANSIBLE_REMOTE_USER'] = 'localuser'
    venv['ANSIBLE_CONFIG'] = './test/utils/config_files/ansible.cfg'
    p = subprocess.Popen("python -m ansible.cli.adhoc --version", shell=True, env=venv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    assert(len(err) == 0)
    assert("ansible-adhoc" in out) # header
    assert("configured module search path" in out)

# Generated at 2022-06-10 22:03:05.240782
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)("/dev/null:/") == ["/dev/null"]
    assert unfrack_path(True)("/dev/null") == ["/dev/null"]
    assert unfrack_path(True)("/dev/null:/dev/null") == ["/dev/null", "/dev/null"]
    assert unfrack_path()("/dev/null") == "/dev/null"
    assert unfrack_path()("/") == "/"
    assert unfrack_path()("/:") == "/"
    assert unfrack_path()("/:/") == "/"



# Generated at 2022-06-10 22:03:24.601144
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@user') == '@user'
    assert maybe_unfrack_path('@')('@INVALID') == '@/usr/share/ansible/plugins/INVALID'
    assert maybe_unfrack_path('@')('user') == 'user'
    assert maybe_unfrack_path('@')('/do/not/unfrack') == '/do/not/unfrack'


# Generated at 2022-06-10 22:03:29.301828
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_async_options(parser)
    c = parser.parse_args(['-P', '5', '-B', '10'])
    assert c.poll_interval == 5
    assert c.seconds == 10



# Generated at 2022-06-10 22:03:31.692873
# Unit test for function version
def test_version():
    result = version("test_version")
    assert "test_version [core %s]" % __version__ in result



# Generated at 2022-06-10 22:03:38.591013
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('-a')
    parser.add_argument('bar')
    parser.add_argument('-b')

    help = parser.format_help()

    assert help.split()[:3] == ['-a,', '--foo', 'bar']


# Generated at 2022-06-10 22:03:44.020488
# Unit test for function add_async_options
def test_add_async_options():
    """Unit test for function add_async_options"""
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args('-B10'.split())
    assert args.seconds == 10, 'Failed to set seconds to 10'


# Generated at 2022-06-10 22:03:45.627552
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert isinstance(SortingHelpFormatter(), SortingHelpFormatter)


# Generated at 2022-06-10 22:03:50.320352
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfracked = maybe_unfrack_path('@')('@foo/bar')
    assert unfracked == '@' + unfrackpath('foo/bar')
    unchanged = maybe_unfrack_path('@')('/foo/bar')
    assert unchanged == '/foo/bar'



# Generated at 2022-06-10 22:04:02.165225
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    data = [
        (["ansible", "--version"], True),
        (["ansible-playbook", "--version"], True),
        (["ansible-galaxy", "--version"], True),
        (["ansible-console", "--version"], True),
        (["ansible-pull", "--version"], True),
        (["ansible-doc", "--version"], True),
        (["ansible-vault", "--version"], True),
        (["ansible-inventory", "--version"], True),
        (["ansible-config", "--version"], True),
        (["ansible-connection", "--version"], True),
        (["ansible-test", "--version"], True),
        (["ansible-connection"], False),
        (["ansible-console"], False)
    ]

# Generated at 2022-06-10 22:04:05.176174
# Unit test for function version
def test_version():
    assert version().startswith(__version__)
    assert version('foo').startswith('foo [core {0}]'.format(__version__))


# Generated at 2022-06-10 22:04:09.059675
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', nargs=0, help='Print ansible version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])



# Generated at 2022-06-10 22:04:28.927614
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class AnsibleVersion_Mock():
        def __init__(self, message):
            self.message = message
        def verbose_msg(self, message):
            self.message = message
        def exit(self):
            pass
    mock = AnsibleVersion_Mock("Nothing")
    ansible_version_instance = AnsibleVersion(option_strings=["-v"])
    ansible_version_instance(mock, "", "", "")
    assert mock.message == version("ansible")



# Generated at 2022-06-10 22:04:31.621839
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    obj = AnsibleVersion()
    try:
        obj.__call__()
    except NotImplementedError:
        pass



# Generated at 2022-06-10 22:04:38.404855
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_beacon = '@test_beacon'
    test_value = '@test_beacon/test_value'
    unfrack_test_value = unfrack_path(test_beacon)
    assert unfrack_test_value(test_value) == '@test_beacon/test_value'
    test_value = '@test_beacon/test_value'
    unfrack_test_value = maybe_unfrack_path(test_beacon)
    assert unfrack_test_value(test_value) == '@test_beacon/test_value'

    test_value = 'test_value/test_value2'
    unfrack_test_value = maybe_unfrack_path(test_beacon)

# Generated at 2022-06-10 22:04:42.644796
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    func = maybe_unfrack_path('@')
    value = '/home/user/ansible/roles'
    actual = func(beacon + value)
    expected = beacon + unfrackpath(value)
    assert actual == expected



# Generated at 2022-06-10 22:04:52.092322
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # TODO: Use unittest
    parser = argparse.ArgumentParser()
    parser.add_argument(u'--sc', action=u'store_true', help=u'help')
    parser.add_argument(u'--sa', action=u'store_true', help=u'help')
    parser.add_argument(u'--sf', action=u'store_true', help=u'help')
    parser.add_argument(u'--sb', action=u'store_true', help=u'help')
    parser.add_argument(u'--sa2', action=u'store_true', help=u'help')
    parser.add_argument(u'--sd', action=u'store_true', help=u'help')

# Generated at 2022-06-10 22:04:59.430896
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    from ansible.constants import DEFAULT_LOCAL_TMP
    tmp = os.environ.get('ANSIBLE_LOCAL_TMP', DEFAULT_LOCAL_TMP)
    test_str = DEFAULT_LOCAL_TMP + "/test_str"
    test_str_expected = tmp + "/test_str"
    assert maybe_unfrack_path(C.DEFAULT_LOCAL_TMP)(test_str) == test_str_expected
    assert maybe_unfrack_path(C.DEFAULT_LOCAL_TMP)(test_str_expected) == test_str_expected



# Generated at 2022-06-10 22:05:08.958574
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    #
    # Test framework
    #
    changed = False
    class Exit(Exception):
        pass
    class FakeNamespace(object):
        def __eq__(self, other):
            return False
    class Output(object):
        def __init__(self):
            self.msg = []
        def write(self, data):
            self.msg.append(data)
    output = Output()
    def fake_exit(msg):
        raise Exit(msg)
    class FakeArgParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            self.version = '1.2.3'
        def exit(self, msg):
            fake_exit(msg)
    parser = FakeArgParser()
    #
    # End of test framework
    #

# Generated at 2022-06-10 22:05:22.104654
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/foo') == "/foo"
    assert unfrack_path()('/foo/') == "/foo/"
    assert unfrack_path()('/foo/bar') == "/foo/bar"
    assert unfrack_path()('/foo/bar/') == "/foo/bar/"
    assert unfrack_path()('/foo/bar/../') == "/foo/"
    assert unfrack_path()('/foo/../bar/../') == "/"
    assert unfrack_path()('/foo/bar/../baz') == "/foo/baz"
    assert unfrack_path()('/foo/bar/../../baz') == "/baz"
    assert unfrack_path()('/foo/bar/../baz/../../baz') == "/baz"


# Generated at 2022-06-10 22:05:30.766821
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/b/c') == '/a/b/c'
    assert unfrack_path()('/a/b/c:') == '/a/b/c:'
    assert unfrack_path(pathsep=True)('/a/b/c') == ['/a/b/c']
    assert unfrack_path(pathsep=True)('/a/b/c:/a/d/e') == ['/a/b/c', '/a/d/e']
    assert unfrack_path(pathsep=True)('/a/b/c:') == []
    assert unfrack_path(pathsep=True)('/a/b/c:/a/d/e:') == []
    assert unfrack_path(pathsep=True)('') == []
    assert unfrack_

# Generated at 2022-06-10 22:05:37.670550
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-10 22:05:57.149705
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # test 1
    assert maybe_unfrack_path('@')('@foo') == '@' + unfrackpath('foo')
    # test 2
    assert maybe_unfrack_path('@')('/foo') == '/foo'
    # test 3
    assert maybe_unfrack_path('/')('/foo') == unfrackpath('/foo')
    # test 4
    assert maybe_unfrack_path('/')('foo') == 'foo'
    # test 5
    assert maybe_unfrack_path('foo')('foo') == 'foo'
    # test 6
    assert maybe_unfrack_path('foo')('bar') == 'bar'


# Generated at 2022-06-10 22:06:01.762174
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = "myprog"
    action = AnsibleVersion(option_strings=[])
    action(parser, argparse.Namespace(), None)



# Generated at 2022-06-10 22:06:05.424473
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """
    This is a unit test for AnsibleVersion() function
    """
    version_test = AnsibleVersion("test")
    version_test.__call__("test")



# Generated at 2022-06-10 22:06:12.936169
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    '''Test __call__ of class AnsibleVersion
    Given a set of arguments
    When AnsibleVersion __call__ is called
    Then an Ansible version should be printed and exit the program
    '''
    # Fake args for AnsibleVersion
    fake_args = ["1.2.3.4",
                 "src/ansible/ansible",
                 "--version"]

    # Create a fake parser to be able to call AnsibleVersion
    class FakeParser:
        prog = "src/ansible/ansible"

    # Create fake namespace
    fake_namespace = Namespace()

    parser = FakeParser()

    try:
        AnsibleVersion("version")(parser, fake_namespace, fake_args, "--version")
    except SystemExit:
        assert True
    else:
        assert False


#
# helper functions

# Generated at 2022-06-10 22:06:20.940563
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description='description',
                                     formatter_class=SortingHelpFormatter)
    parser.add_argument('-m', action='store_true',
                        help='help message of -m')
    parser.add_argument('-k', action='store_true',
                        help='help message of -k')
    parser.add_argument('-o', action='store_true',
                        help='help message of -o')
    help = parser.format_help()
    assert len(help.split('\n')) == 5


# Generated at 2022-06-10 22:06:26.072949
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('../../foo') == unfrackpath('../../foo')
    assert unfrack_path(pathsep=True)('../../foo:/tmp') == [unfrackpath('../../foo'), unfrackpath('/tmp')]
    assert unfrack_path(pathsep=False)('-') == '-'



# Generated at 2022-06-10 22:06:26.736785
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    pass

# Generated at 2022-06-10 22:06:27.916162
# Unit test for function version
def test_version():
    test = version()
    assert "ansible" in test
    assert "python" in test

# Generated at 2022-06-10 22:06:29.886820
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    namespace = parser.parse_args([])
    AnsibleVersion(version)(parser, namespace, version, option_string=None)


# Generated at 2022-06-10 22:06:32.327014
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    try:
        ansible_version = AnsibleVersion()
        ansible_version(argparse.ArgumentParser(), None, None, None)
        sys.exit(0)
    except SystemExit:
        pass
    sys.exit(-1)



# Generated at 2022-06-10 22:06:55.268142
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    result = to_native(version('ansible'))
    parser = argparse.ArgumentParser()
    parser.add_argument = lambda *args, **kwargs: None
    parser.exit = lambda *args, **kwargs: None
    action = AnsibleVersion(option_strings=[])
    namespace = argparse.Namespace()
    namespace.verbosity = 0
    action(parser, namespace, None)
    assert namespace.verbosity == 0
    assert result



# Generated at 2022-06-10 22:07:06.658854
# Unit test for function unfrack_path
def test_unfrack_path():
    # Some of the following tests are checking for the non-posix behavior of
    # join(), because unfrackpath() relies on posixpath.join() to make the
    # replacement '//' -> '/' (posixpath.join() allows multiple //, even if
    # os.path.join() doesn't). Note that '/' isn't considered a 'special'
    # separator for join() like it is for split().
    assert unfrackpath('/tmp/./') == '/tmp/'
    assert unfrackpath('/tmp/.//') == '/tmp/'
    assert unfrackpath('/tmp//.//') == '/tmp/'
    assert unfrackpath('/tmp//.//.//') == '/tmp/'
    assert unfrackpath('/tmp//././/') == '/tmp/'

# Generated at 2022-06-10 22:07:17.147932
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    #  Path for running test script is at 'test/'
    #  A valid fracked path must have '/./' like this one '/test/../test/./'
    fracked_path = os.path.join(os.path.abspath(os.path.curdir), '..', 'test', '..', 'test', '.')
    fracked_path = maybe_unfrack_path('@')('@%s' % fracked_path)
    assert(fracked_path == '@%s' % unfrackpath(fracked_path))
    assert(fracked_path == '@%s' % os.path.abspath(os.path.curdir))



# Generated at 2022-06-10 22:07:19.292243
# Unit test for function version
def test_version():
    real_stdout = sys.stdout
    sys.stdout = result = []
    version()
    sys.stdout = real_stdout
    assert result[0] == __version__


# Generated at 2022-06-10 22:07:22.966177
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ansible-version', action=AnsibleVersion)
    args = parser.parse_args(['--ansible-version'])
    assert args.ansible_version == None



# Generated at 2022-06-10 22:07:29.260916
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Arrange
    parser = argparse.ArgumentParser()
    args = []
    action = AnsibleVersion(
        option_strings=[],
        dest=argparse.SUPPRESS,
        default=argparse.SUPPRESS,
        help='show program\'s version number and exit'
    )

    # Act
    try:
        action(parser, argparse.Namespace(), args)
    except SystemExit:
        pass

    # Assert
    assert True



# Generated at 2022-06-10 22:07:42.686974
# Unit test for function unfrack_path
def test_unfrack_path():
    import os
    os.environ['HOME'] = '/home/user'
    os.environ['ANSIBLE_LIBRARY'] = '/usr/share/ansible'
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    os.environ['ANSIBLE_ACTION_PLUGINS'] = '/usr/share/ansible/action_plugins'
    os.environ['ANSIBLE_CACHE_PLUGINS'] = '/usr/share/ansible/cache_plugins'
    os.environ['ANSIBLE_CALLBACK_PLUGINS'] = '/usr/share/ansible/callback_plugins'
    os.environ['ANSIBLE_CONNECTION_PLUGINS'] = '/usr/share/ansible/connection_plugins'

# Generated at 2022-06-10 22:07:44.528481
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from test_ansible_version import clo_parser
    a_version = AnsibleVersion('store_false')
    try:
        a_version(clo_parser, None, None)
    except SystemExit:
        pass
    return True

# Generated at 2022-06-10 22:07:48.232249
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    if len(tuple(filter(lambda s: s.startswith('/'), ['test/test', '/test']))) == 0:
        print("maybe_unfrack_path does not work")



# Generated at 2022-06-10 22:07:51.689970
# Unit test for function unfrack_path
def test_unfrack_path():
    value = "/etc/ansible:/tmp/ansible/playbooks"
    expected_result = ["/etc/ansible", "/tmp/ansible/playbooks"]
    result = unfrack_path(True)
    assert result == expected_result
