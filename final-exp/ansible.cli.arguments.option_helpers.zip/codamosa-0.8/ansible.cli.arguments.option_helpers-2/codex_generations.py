

# Generated at 2022-06-10 21:59:02.355231
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/')('/etc/hosts') == '/etc/hosts'
    assert maybe_unfrack_path('{0}/'.format(C.DEFAULT_LOCAL_TMP))(C.DEFAULT_LOCAL_TMP + '/blah') == '/tmp/blah'
    assert maybe_unfrack_path('{0}'.format(C.DEFAULT_LOCAL_TMP))(C.DEFAULT_LOCAL_TMP) == '/tmp'
    assert maybe_unfrack_path('{0}/'.format(C.DEFAULT_LOCAL_TMP))('/not_tmp/blah') == '/not_tmp/blah'



# Generated at 2022-06-10 21:59:09.163582
# Unit test for function add_check_options
def test_add_check_options():
    def checked_function(args):
        try:
            assert args.check == True
            assert args.syntax == True
            assert args.diff == True
        except AssertionError as e:
            raise AssertionError(e)

    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args_list = ['--check', '--syntax-check', '--diff']
    args = parser.parse_args(args_list)
    assert checked_function(args)


# Generated at 2022-06-10 21:59:17.728095
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    abspath = maybe_unfrack_path('@')
    relpath = maybe_unfrack_path('%')
    envpath = maybe_unfrack_path('$')

    # a PATH is a string containing paths separated by os.pathsep
    if os.pathsep == ':':
        # POSIX
        path = ':'.join([
            '/foo/bar',
            '~/baz',
            '$HOME/qux',
            '%dir/fred',
            '@dir/jane'
        ])
        # PATHs shouldn't change
        assert abspath(path) == path
        assert relpath(path) == path
        assert envpath(path) == path

# Generated at 2022-06-10 21:59:29.180486
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    class FakeOptions:
        def __init__(self, opt_dict):
            self.__dict__ = opt_dict

    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    namespace_args, unknown_args = parser.parse_known_args(['--ask-become-pass'])
    opts = FakeOptions(vars(namespace_args))
    assert opts.become_ask_pass == True, "--ask-become-pass should set become_ask_pass to True"

    namespace_args, unknown_args = parser.parse_known_args(['--become-pass-file'])
    opts = FakeOptions(vars(namespace_args))

# Generated at 2022-06-10 21:59:34.317675
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """Method __call__"""
    # FIXME - better test
    class Parse(object):
        def exit(self):
            return True
    v = AnsibleVersion(None, None, None, None)
    assert v.__call__(Parse(), None, None, None)



# Generated at 2022-06-10 21:59:43.745989
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog="ansible-config",
        formatter_class=SortingHelpFormatter,
        description='Ansible configuration file utility',
        conflict_handler='resolve',
    )
    add_connect_options(parser)

    # for options with default value to be tested
    options = parser.parse_args(['-v'])
    assert options.verbosity == 1
    assert options.ask_pass == C.DEFAULT_ASK_PASS
    assert options.timeout == C.DEFAULT_TIMEOUT

    # change default value to test
    options.timeout = 10
    assert options.timeout == 10
    options.ask_pass = True
    assert options.ask_pass == True

    # for options with no default value to be tested

# Generated at 2022-06-10 21:59:46.661398
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

# Generated at 2022-06-10 21:59:55.545164
# Unit test for function add_subset_options
def test_add_subset_options():
    parser=argparse.ArgumentParser(prog='ansible-playbook', usage="%(prog)s [options] playbook.yml",
                        formatter_class=SortingHelpFormatter, conflict_handler='resolve')
    add_subset_options(parser)
    parser.parse_args(['--tags', 'Test'])
    parser.parse_args(['--tags', 'Test1', '--tags', 'Test2'])
    parser.parse_args(['--skip-tags', 'Test1'])
    parser.parse_args(['--skip-tags', 'Test1', '--skip-tags', 'Test2'])



# Generated at 2022-06-10 22:00:02.473849
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(
        prog='test_argparse',
        formatter_class=SortingHelpFormatter,
        description='test_argparse description',
        conflict_handler='resolve',
    )
    add_vault_options(parser)
    options = parser.parse_args([])
    assert options.vault_ids == []
    assert options.ask_vault_pass
    assert options.vault_password_files == []



# Generated at 2022-06-10 22:00:11.524799
# Unit test for function add_vault_options
def test_add_vault_options():
    import json
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    argv = ['--vault-id', 'foo', '--vault-id', 'bar']
    results = parser.parse_args(argv)
    assert json.dumps(results.vault_ids, sort_keys=True) == '["bar", "foo"]'
    argv = ['--ask-vault-pass']
    results = parser.parse_args(argv)
    assert results.ask_vault_pass is True
    argv = ['--ask-vault-password']
    results = parser.parse_args(argv)
    assert results.ask_vault_pass is True

# Generated at 2022-06-10 22:00:47.092631
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = create_base_parser('ansible')
    add_connect_options(parser)
    arguments = [
        '/tmp/test',
        '-k',
        '--connection=ssh',
        '--timeout=10',
        '--ssh-extra-args=-vvv',
    ]
    parsed = parser.parse_known_args(arguments)[0]
    assert parsed.timeout == 10
    assert parsed.connection == 'ssh'
    assert parsed.ask_pass is True
    assert parsed.ssh_extra_args == '-vvv'



# Generated at 2022-06-10 22:00:52.656410
# Unit test for function ensure_value
def test_ensure_value():
    class namespace:
        foo = None
    ensure_value(namespace, 'foo', ['bar'])
    assert namespace.foo == ['bar']
    ensure_value(namespace, 'foo', ['something'])
    assert namespace.foo == ['bar']

    namespace.foo = []
    ensure_value(namespace, 'foo', ['bar'])
    assert namespace.foo == []



# Generated at 2022-06-10 22:01:05.302316
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test for when default is None
    import argparse as ap
    pla_default_none = PrependListAction(option_strings=[], dest='dest', nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)
    # Instance shouldn't have '__call__' attribute (it's a descriptor)
    assert not hasattr(pla_default_none, '__call__')
    # A PrependListAction instance must implement __call__ to be callable
    assert callable(pla_default_none)
    # __call__() takes five positional arguments (self, parser, namespace, values, option_string=None)
    # Three of them are provided by the call

# Generated at 2022-06-10 22:01:11.925224
# Unit test for function add_subset_options
def test_add_subset_options():
    from ansible.cli import CLI

    args = ['--tags', 'a', '--tags', 'b', '--skip-tags', 'c', '--skip-tags', 'd']
    p = CLI.base_parser(args)
    CLI.add_subset_options(p)
    options = p.parse_args(args)
    assert options.tags == ['a', 'b']
    assert options.skip_tags == ['c', 'd']



# Generated at 2022-06-10 22:01:19.517463
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible-test')
    add_runas_options(parser)
    args = parser.parse_args('-b'.split())
    assert args.become
    args = parser.parse_args('-b --become-method sudo'.split())
    assert args.become_method == 'sudo'
    args = parser.parse_args('-b --become-user ansible'.split())
    assert args.become_user == 'ansible'



# Generated at 2022-06-10 22:01:26.544427
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(description='description')
    add_connect_options(parser)

    opts = parser.parse_args('-c ssh -u myuser -T 60 --ssh-extra-args -R'.split())
    assert opts.connection == 'ssh'
    assert opts.remote_user == 'myuser'
    assert opts.timeout == 60
    assert opts.ssh_extra_args == '-R'

    opts = parser.parse_args('-c local -u myuser -T 60 -k'.split())
    assert opts.connection == 'local'
    assert opts.remote_user == 'myuser'
    assert opts.timeout == 60
    assert opts.ask_pass



# Generated at 2022-06-10 22:01:36.678065
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('$')('$/file.yml') == '$/file.yml'
    assert maybe_unfrack_path('@')('@/file.yml') == '@/file.yml'

    assert maybe_unfrack_path('$')('$./file.yml') == '$./file.yml'
    assert maybe_unfrack_path('@')('@./file.yml') == '@./file.yml'

    assert maybe_unfrack_path('$')('$hosts') == '$hosts'
    assert maybe_unfrack_path('@')('@hosts') == '@hosts'



# Generated at 2022-06-10 22:01:41.868804
# Unit test for function add_runas_options
def test_add_runas_options():
    my_parser = argparse.ArgumentParser()
    add_runas_options(my_parser)
    options = my_parser.parse_args(['-b', '--become-user', 'newbecomeuser', '--become-method', 'sudo'])
    assert options.become
    assert options.become_method == 'sudo'
    assert options.become_user == 'newbecomeuser'



# Generated at 2022-06-10 22:01:50.938033
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    base_opts = [
        '--private-key', '--key-file', '-u', '--user', '-c', '--connection', '-T', '--timeout',
        '--ssh-common-args', '--sftp-extra-args', '--scp-extra-args', '--ssh-extra-args',
        '-k', '--ask-pass', '--connection-password-file', '--conn-pass-file'
    ]
    for opt in base_opts:
        assert opt in parser._option_string_actions

# Generated at 2022-06-10 22:02:02.321637
# Unit test for function add_connect_options
def test_add_connect_options():
    testparser = argparse.ArgumentParser()
    add_connect_options(testparser)
    args = testparser.parse_args(['-k', '-c', 'local', '-u', 'testuser','-T', '100', '--ssh-common-args', 'test', '--sftp-extra-args', 'test', '--scp-extra-args', 'test', '--ssh-extra-args', 'test'])
    assert args.ask_pass == True
    assert args.connection == 'local'
    assert args.remote_user == 'testuser'
    assert args.timeout == 100
    assert args.ssh_common_args == 'test'
    assert args.sftp_extra_args == 'test'
    assert args.scp_extra_args == 'test'
    assert args.ssh_

# Generated at 2022-06-10 22:02:11.252039
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test:__call__:0
    assert True



# Generated at 2022-06-10 22:02:22.830523
# Unit test for function unfrack_path
def test_unfrack_path():
    '''
    This test function verifies if the unfrack_path function returns expected
    results for a given set of inputs.
    '''

    # Test with multiple args - verify if it returns a list of paths in
    # Ansible locations.
    assert unfrack_path(pathsep=True)(u'/foo/bar:/bar/baz') == [u'/foo/bar', u'/bar/baz']

    # Test with a single arg - verify if it returns a single path in
    # Ansible path.
    assert unfrack_path(pathsep=False)(u'/foo/bar') == u'/foo/bar'

    # Test with a single arg that is '-' - verify if it returns a single path
    # as it is.
    assert unfrack_path(pathsep=False)(u'-') == u'-'



# Generated at 2022-06-10 22:02:27.326080
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = os.path.abspath('test.txt')
    assert '@' + path == maybe_unfrack_path('@')('@' + path)
    assert '@' + path == maybe_unfrack_path('@')('@' + os.path.relpath(path))



# Generated at 2022-06-10 22:02:33.674270
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # With beacon characters:
    assert maybe_unfrack_path('./')('./unfrackme') == './unfrackme'
    assert maybe_unfrack_path('./')('./unfrackme/') == './unfrackme'
    assert maybe_unfrack_path('~/')('~/unfrackme') == os.path.expanduser('~/unfrackme')
    assert maybe_unfrack_path('~/')('~/unfrackme/') == os.path.expanduser('~/unfrackme')
    # Without beacon characters:
    assert maybe_unfrack_path('./')('unfrackme') == 'unfrackme'

# Generated at 2022-06-10 22:02:44.632680
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ['~/ansible/test1:~/ansible/test2'] == unfrack_path(True)('~/ansible/test1:~/ansible/test2')
    assert ['/home/user/ansible/test1:/home/user/ansible/test2'] == unfrack_path(True)('~/ansible/test1:~/ansible/test2')
    assert ['~/ansible/test1:~/ansible/test2'] == unfrack_path(True)('~/ansible/test1:~/ansible/test2:')
    assert ['/home/user/ansible/test1:/home/user/ansible/test2'] == unfrack_path(True)('~/ansible/test1:~/ansible/test2:')

# Generated at 2022-06-10 22:02:55.439330
# Unit test for function version

# Generated at 2022-06-10 22:02:59.965435
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@test@')('@test@/blah') == maybe_unfrack_path('@test@')('@test@/blah')



# Generated at 2022-06-10 22:03:06.913905
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    assert parser._actions[1].help == "only run plays and tasks tagged with these values"
    assert parser._actions[1].dest == 'tags'
    assert parser._actions[1].type == str
    assert parser._actions[1].default == ['all']
    assert parser._actions[2].help == "only run plays and tasks whose tags do not match these values"
    assert parser._actions[2].dest == 'skip_tags'
    assert parser._actions[2].type == str
    assert parser._actions[2].default == ['none']



# Generated at 2022-06-10 22:03:17.675905
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args(['-t', 'tag1', 'tag2', 'tag3', '--skip-tags', 'tag4', 'tag5', 'tag6'])
    assert parser.parse_args(['-t', 'tag1', 'tag2', 'tag3', '--skip-tags', 'tag4', 'tag5', 'tag6']).tags == ['tag1', 'tag2', 'tag3']
    assert parser.parse_args(['-t', 'tag1', 'tag2', 'tag3', '--skip-tags', 'tag4', 'tag5', 'tag6']).skip_tags == ['tag4', 'tag5', 'tag6']

# Generated at 2022-06-10 22:03:27.466984
# Unit test for function ensure_value
def test_ensure_value():
    ns = argparse.Namespace()
    ensure_value(ns, 'new_attr', 'new_value')
    assert ns.new_attr == 'new_value'
    ensure_value(ns, 'existing_attr', 'new_value')
    assert ns.existing_attr == 'new_value'
    ensure_value(ns, 'existing_attr', 'new_value')
    assert ns.existing_attr == 'new_value'

#
# An OptionParser, which converts boolean options to True or False and
# inserts default values.
#

# Generated at 2022-06-10 22:03:44.349214
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test with an absolute path
    unfracked_path = maybe_unfrack_path(os.path.sep)('/Users/ansible/test')
    assert(unfracked_path == '/Users/ansible/test')

    # Test with a relative path
    unfracked_path = maybe_unfrack_path(os.path.sep)('~/test')
    assert(unfracked_path == '~/test')
# END unit test for maybe_unfrack_path



# Generated at 2022-06-10 22:03:51.618873
# Unit test for function unfrack_path
def test_unfrack_path():
    base_file_path = unfrack_path()

    assert base_file_path('../test/test.yml') == '../test/test.yml'
    assert base_file_path('test/test.yml') == os.path.join(C.DEFAULT_ROLES_PATH, 'test/test.yml')
    assert base_file_path('~/test/test.yml') == os.path.expanduser('~/test/test.yml')
    assert base_file_path('/etc/test.yml') == '/etc/test.yml'

    # test with pathsep
    base_file_path = unfrack_path(pathsep=True)

    assert base_file_path('../test/test.yml') == ['../test/test.yml']
   

# Generated at 2022-06-10 22:03:53.351471
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path('foo/bar')=='foo/bar'
    assert unfrack_path(pathsep=True)


# Generated at 2022-06-10 22:04:03.056900
# Unit test for function unfrack_path

# Generated at 2022-06-10 22:04:10.431404
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~/foo') == '~/foo'
    assert maybe_unfrack_path('~')('./foo') == './foo'
    assert maybe_unfrack_path('~')('~/.foo') == '~/.foo'
    assert maybe_unfrack_path('~')('~/.foo/') == '~/.foo/'

#
# Special purpose OptionGroups
#

# Generated at 2022-06-10 22:04:14.489368
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('.') == unfrackpath('.')
    assert unfrack_path(pathsep=True)('a:b:c') == [unfrackpath('a'), unfrackpath('b'), unfrackpath('c')]



# Generated at 2022-06-10 22:04:21.878383
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.utils.path import mux_dir, unfrackpath
    os.environ['ANSIBLE_HOME'] = '/foo/bar'
    os.environ['ANSIBLE_CONFIG'] = '../baz/ansible.cfg'
    assert unfrack_path(False)('ansible.cfg') == '/foo/bar/ansible.cfg'
    assert unfrack_path(False)('etc/ansible/ansible.cfg') == '/foo/bar/etc/ansible/ansible.cfg'
    assert unfrack_path(False)('../baz/ansible.cfg') == '../baz/ansible.cfg'
    assert unfrack_path(True)('/tmp:/usr/local') == ['/tmp', '/usr/local']

# Generated at 2022-06-10 22:04:29.680190
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test on valid path
    path = unfrack_path()("/home/myuser/myproject")
    assert path == "/home/myuser/myproject"
    # Test on path.sep paths
    assert unfrack_path(pathsep=True)("/home/ansible/roles;/etc/ansible/roles") == ["/home/ansible/roles", "/etc/ansible/roles"]


# Generated at 2022-06-10 22:04:33.979606
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('@@/foo/bar') == '@@/foo/bar'



# Generated at 2022-06-10 22:04:46.157700
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/etc/my.cnf") == "/etc/my.cnf"
    if os.path.sep == '/':
        assert unfrack_path()("~/.my.cnf") == os.path.expanduser("~/.my.cnf")
    else:
        assert unfrack_path()("~\.my.cnf") == os.path.expanduser("~\.my.cnf")
    assert unfrack_path(pathsep=False)("/etc/my.cnf:/etc/mysql.cnf") == \
        "/etc/my.cnf:/etc/mysql.cnf"

# Generated at 2022-06-10 22:05:05.749781
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = argparse.Namespace()
    namespace.tag_value = ['tag1']
    action = PrependListAction(['--tags'], 'tag_value')
    action(parser=None, namespace=namespace, values=['tag2'], option_string=None)
    assert namespace.tag_value == ['tag2', 'tag1']



# Generated at 2022-06-10 22:05:15.392791
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = ''
    dest = ''
    nargs = ''
    const = ''
    default = ''
    type = ''
    choices = ''
    required = ''
    help = ''
    metavar = ''
    prependlistaction = PrependListAction(option_strings, dest, nargs, const, default, type, choices, required, help, metavar)
    parser = ''
    namespace = ''
    values = ''
    option_string = ''
    prependlistaction.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-10 22:05:18.255264
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@{0}/foo'.format(unfrackpath(''))



# Generated at 2022-06-10 22:05:23.205685
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    unfrack_value = maybe_unfrack_path('@')
    assert unfrack_value('@/tmp/has/path') == '@/tmp/has/path'
    assert unfrack_value('foo/bar') == 'foo/bar'
    assert unfrack_value('@foo/bar') == '@' + unfrackpath('foo/bar')


# Generated at 2022-06-10 22:05:28.988025
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('+')('+foo') == '+' + unfrackpath('foo')
    assert maybe_unfrack_path('+')('+foo/') == '+' + unfrackpath('foo/')
    assert maybe_unfrack_path('+')('foo') == 'foo'
    assert maybe_unfrack_path('+')('~/foo') == '~/foo'


#
# Option Groups
#

# Generated at 2022-06-10 22:05:37.399762
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('hello') == 'hello'
    assert unfrack_path()('-') == '-'
    for x in ('_', './_', '~/__', './_/__',
              '/__/../some/other/./_',
              '/this/one/should/./be/../../unchanged'):
        assert unfrack_path()(x) == x
        if sys.platform != 'win32':
            assert unfrack_path()('/%s/' % x) == '/%s' % x
            assert unfrack_path()('/%s/.' % x) == '/%s' % x
            assert unfrack_path()('/%s/./' % x) == '/%s' % x

# Generated at 2022-06-10 22:05:43.617464
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
        parser = argparse.ArgumentParser()
        parser.add_argument("-c", "--config-file")
        parser.add_argument("-f", "--flag")
        parser.add_argument("-a", "--arg")
        parser = SortingHelpFormatter(parser)
        parser.add_argument("-d")
        parser.add_argument("-e")
        parser.print_help()

#
# Main option parsers
#

# Generated at 2022-06-10 22:05:55.236756
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    expected_value ='*~/some/path'
    actual_value = maybe_unfrack_path('*')('*~/some/path')
    assert actual_value == expected_value

    expected_value ='*~/some/path'
    actual_value = maybe_unfrack_path('*')('*~/some/path')
    assert actual_value == expected_value

    expected_value = '!~/some/path'
    actual_value = maybe_unfrack_path('!')('!~/some/path')
    assert actual_value == expected_value

    expected_value = '!~/some/path/?.yml'
    actual_value = maybe_unfrack_path('!')('!~/some/path/?.yml')
    assert actual_value == expected

# Generated at 2022-06-10 22:06:08.871983
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = '/etc'
    unfrack = unfrack_path()
    assert unfrack('/etc/test') == '/etc/test'
    assert maybe_unfrack_path(beacon)(beacon + '/test') == beacon + '/test'
    assert maybe_unfrack_path(beacon)('/etc/test') == '/etc/test'
    assert maybe_unfrack_path('/tmp/foo')('foobar/test') == 'foobar/test'
    assert maybe_unfrack_path('/tmp/foo')('/tmp/foo/test') == '/tmp/foo/test'
    assert maybe_unfrack_path('/tmp/foo')('@tmp/foo/test') == '@tmp/foo/test'

# Generated at 2022-06-10 22:06:21.557778
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--command")
    parser.add_argument("-a", "--array")
    parser.add_argument("-b", "--bar")
    parser.add_argument("-d", "--dog")
    parser.add_argument("-t", "--turtle")
    parser.add_argument("-s", "--silly")
    parser.add_argument("-e", "--emu")

    output = parser.format_help()


# Generated at 2022-06-10 22:07:07.972672
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = '/home/user1/repo'
    assert maybe_unfrack_path('@')('@/home/user1/repo') == '@{}'.format(path)
    assert maybe_unfrack_path('//')('//home/user1/repo') == '//{}'.format(path)
    assert maybe_unfrack_path('/')('/home/user1/repo') == '/home/user1/repo'



# Generated at 2022-06-10 22:07:15.336847
# Unit test for function version
def test_version():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2

    out = StringIO()
    sys.stdout = out

    version()
    sys.stdout = sys.__stdout__

    # Check that version is in the output.
    assert 'ansible' in out.getvalue()

    # Check that there is no problem with encoding of unicode characters (PY2)
    if PY2:
        out.getvalue()

# Generated at 2022-06-10 22:07:21.909514
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('../../foo') == '../../foo'
    assert unfrack_path()('/etc/ansible/foo.yml') == '/etc/ansible/foo.yml'
    assert unfrack_path()('/etc/ansible/foo.yml') == '/etc/ansible/foo.yml'
    assert unfrack_path()('foo.yml') == os.path.abspath('foo.yml')
    # unfrackpath() won't expand home directory, but this is not a problem as
    # os.path.expanduser() expands ~ to home directory.
    assert unfrack_path()('~/foo') == os.path.abspath('~/foo')
    assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')

# Generated at 2022-06-10 22:07:32.016554
# Unit test for method __call__ of class PrependListAction

# Generated at 2022-06-10 22:07:33.785566
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == unfrackpath('/tmp')



# Generated at 2022-06-10 22:07:36.185435
# Unit test for function version
def test_version():
    """ make sure the version is sane """
    v = version()
    assert isinstance(v, str)

# Generated at 2022-06-10 22:07:45.163589
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Basic test
    a_path = '~/foo'
    a_beacon = '~'
    a_result = '~/foo'
    b_result = '~/foo/bar'
    c_result = '~/foo/bar/baz'
    c_result = '~/foo/bar/baz'
    c_path = '~/foo/bar/baz'
    c_beacon = '~'
    assert maybe_unfrack_path(a_beacon)(a_path) == a_result
    assert maybe_unfrack_path(a_beacon)(a_path+'/bar') == b_result
    assert maybe_unfrack_path(a_beacon)(a_path+'/bar/baz') == c_result

# Generated at 2022-06-10 22:07:51.245469
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert (maybe_unfrack_path('@')
            ('@/var/tmp') == '@/var/tmp')
    assert (maybe_unfrack_path('@')
            ('/var/tmp') == '/var/tmp')
    assert (maybe_unfrack_path('@')
            ('@$HOME/var/tmp') == '@/home/bob/var/tmp')


# Generated at 2022-06-10 22:07:52.567253
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("foo") == unfrack_path("foo")



# Generated at 2022-06-10 22:08:01.484856
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.config.manager import ConfigManager
    from ansible.config.cli.parser import CLI

    prepend_list_action = CLI.PrependListAction('', '', '', [])
    namespace = argparse.Namespace()
    prepend_list_action.__call__(None, namespace, ['a'], '')