

# Generated at 2022-06-10 21:59:21.500316
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = OptionParser()
    add_meta_options(parser)
    options = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert options.force_handlers is True
    assert options.flush_cache is True
    options = parser.parse_args([])
    assert options.force_handlers is False
    assert options.flush_cache is False



# Generated at 2022-06-10 21:59:27.885351
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.format_help()



# Generated at 2022-06-10 21:59:39.155751
# Unit test for function add_runas_options
def test_add_runas_options():
    class TestParser(argparse.ArgumentParser):
        def __init__(self):
            super(TestParser, self).__init__(conflict_handler='resolve')

    parser = TestParser()

    add_runas_options(parser)

    # Test defaults
    options = parser.parse_args([])
    assert options.become == C.DEFAULT_BECOME
    assert options.become_method == C.DEFAULT_BECOME_METHOD
    assert options.become_user == C.DEFAULT_BECOME_USER
    assert options.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS

    # Test --become-user
    options = parser.parse_args(['--become-user=testuser'])

# Generated at 2022-06-10 21:59:42.198950
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    return parser



# Generated at 2022-06-10 21:59:49.681258
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    extra = ['-B', '--background']
    opts, args = parser.parse_known_args(extra)
    assert opts.seconds == 0
    extra = ['-B', '10']
    opts, args = parser.parse_known_args(extra)
    assert opts.seconds == 10


# Generated at 2022-06-10 21:59:53.921582
# Unit test for function add_output_options
def test_add_output_options():
    # Test add_output_options
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    options = parser.parse_args(['-t', 'testtree', '-o'])
    assert options.tree == 'testtree'
    assert options.one_line is True



# Generated at 2022-06-10 21:59:57.264709
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict
    cli = CLI()
    with pytest.raises(TypeError) as excinfo:
        cli.parser.add_runtask_options()
    assert "add_runtask_options() takes exactly 2 arguments (1 given)" in str(excinfo.value)



# Generated at 2022-06-10 22:00:06.621085
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI

    cli = CLI(args=[])
    cli.parser = CLI.base_parser(constants=constants)
    cli.CLI.setup_parser()
    assert not cli.parser._groups[1]._group_actions[0].required
    add_runas_prompt_options(cli.parser, cli.parser._groups[1])
    assert cli.parser._groups[1]._group_actions[0].required



# Generated at 2022-06-10 22:00:20.219243
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    import ansible.constants as C
    import ansible.cli.common as A
    # test mutually exclusive group
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    assert len(parser.choices_actions) == 1
    assert 'mutually exclusive' in parser.choices_actions[0].description
    mutex_group = parser.choices_actions[0].choices
    assert len(mutex_group) == 2
    A.config_init(['--become-ask-pass'], parser=parser)
    assert C.DEFAULT_BECOME_ASK_PASS is False
    assert C.config.get_config_value('BECOME_ASK_PASS') is True

# Generated at 2022-06-10 22:00:24.805583
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options = parser.parse_args()
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL
    assert options.seconds == 0



# Generated at 2022-06-10 22:00:47.802759
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(
        prog='test',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_inventory_options(parser)
    args = parser.parse_args(['-i', 'foo', '-i', 'bar'])
    assert args.inventory == ['foo', 'bar']



# Generated at 2022-06-10 22:00:53.138409
# Unit test for function add_check_options
def test_add_check_options():
    """ unit test using argparse to verify the options added by add_check_options """
    parser = create_base_parser("test")
    add_check_options(parser)

    opts = parser.parse_args(["-C","--check", "-D","--diff", "--syntax-check"])
    assert opts.check
    assert opts.diff
    assert opts.syntax



# Generated at 2022-06-10 22:01:03.157381
# Unit test for function version
def test_version():
    correct_version = '1.0.0 [core 1.0.0]\n  config file = \n  configured module search path = Default w/o overrides\n  ansible python module location = \n  ansible collection location = \n  executable location = <unknown>\n  python version = 2.7.14 (default, May 23 2018, 13:02:35) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-28)]\n  jinja version = 2.10\n  libyaml = n'
    version_out = version()
    assert version_out == correct_version


# Generated at 2022-06-10 22:01:11.475894
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument("--d")
    parser.add_argument("-a")
    parser.add_argument("-b")
    parser.add_argument("--c")

    sorter = SortingHelpFormatter()
    sorter.add_arguments(parser._actions)
    # the original list (parser._actions) should be sorted
    orig = ['-a', '-b', '--c', '--d']
    test = [a.option_strings[0] for a in parser._actions]
    assert orig == test



# Generated at 2022-06-10 22:01:12.830464
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    result = version()
    sys.exit(0)



# Generated at 2022-06-10 22:01:18.005122
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '/home/user/ansible/tests/output/test_path'
    test_path_unfracked = unfrackpath(test_path)
    assert test_path_unfracked.startswith(beacon)
    assert test_path_unfracked[1:] == test_path


# Generated at 2022-06-10 22:01:19.369607
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/tmp/foo") == "/tmp/foo"
    assert unfrack_path()("../tmp/foo") == "../tmp/foo"
    assert unfrack_path("foo")("../tmp/foo") == ['../tmp/foo']



# Generated at 2022-06-10 22:01:28.350439
# Unit test for function add_inventory_options
def test_add_inventory_options():
    from unittest import TestCase
    from units.mock.parser import MockParser
    try:
        add_inventory_options(MockParser())
    except TypeError:
        raise AssertionError('Function add_inventory_options raises TypeError')

    class TestInventoryOptions(TestCase):
        def setUp(self):
            self.parser = MockParser()
            add_inventory_options(self.parser)
            self.args = self.parser.parse_args('-i inventory.file --list-hosts -l host-pattern'.split(' '))

        def test_inventory(self):
            self.assertEqual(self.args.inventory, ['inventory.file'])

        def test_list_hosts(self):
            self.assertTrue(self.args.listhosts)


# Generated at 2022-06-10 22:01:39.059273
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # sample option string with '-' and '--'
    sample_options = ['-f', '--foo', '-r', '--req-one', '-b', '--bar', '-z', '--zoom']
    # shuffle the options
    shuffled_options = copy.copy(sample_options)
    import random
    random.shuffle(shuffled_options)
    # create a parser with the shuffled options
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, add_help=False)
    parser.add_argument(shuffled_options[0])
    parser.add_argument(shuffled_options[1])
    parser.add_argument(shuffled_options[2])
    parser.add_argument(shuffled_options[3])
    parser.add

# Generated at 2022-06-10 22:01:42.575021
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    assert parser._actions[1].option_strings == ['-i']
    assert parser._actions[2].option_strings == ['--list-hosts']
    assert parser._actions[3].option_strings == ['-l']



# Generated at 2022-06-10 22:02:00.671120
# Unit test for function add_meta_options
def test_add_meta_options():
    from ansible.cli import CLI
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    parser = CLI.base_parser(constants.DEFAULT_MODULE_NAME, constants.DEFAULT_MODULE_PATH, 'test', '', '', '', '', False)
    add_meta_options(parser)
    add_runtime_options(parser)

    args = parser.parse_args([])
    assert(isinstance(args.flush_cache, bool))
    assert(args.flush_cache is False)

    args = parser.parse_args(['--flush-cache'])
    assert(isinstance(args.flush_cache, bool))
    assert(args.flush_cache is True)




# Generated at 2022-06-10 22:02:07.825116
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ['path'] == unfrack_path()(u'path')
    assert [u'path', u'path2'] == unfrack_path(True)(u'path' + os.pathsep + u'path2')
    assert [] == unfrack_path(True)('nonexistent_path1' + os.pathsep + 'nonexistent_path2' + os.pathsep)
    assert ['-'] == unfrack_path()(u'-')
    assert ['-'] == unfrack_path()(u'.')
    assert u'-' == unfrack_path()(u'-')
    assert u'-' == unfrack_path()(u'.')
    assert u'.' == unfrack_path()(u'.')



# Generated at 2022-06-10 22:02:14.705184
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import ansible.constants as C

    # Create the parser
    #OptionsParser() is an alias name of AnsibleOptionsParser()
    #No custom code except for invokation of parent.__init__ method
    parser = AnsibleOptionsParser()
    #Create action for parser
    action = AnsibleVersion()
    #Add action to parser
    parser.add_action(action, "--version", default=None)
    #Parse command line
    options = parser.parse()[0]
    #Invoke method of class AnsibleVersion
    print(options.version)

#
# Parse command line arguments
#

# Generated at 2022-06-10 22:02:27.503040
# Unit test for function version
def test_version():
    try:
        orig = os.environ['PWD']
    except KeyError:
        orig = None


# Generated at 2022-06-10 22:02:40.191197
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    if sys.version_info >= (3, 4):
        pass  #  Starting with Python 3.4 class argparse.HelpFormatter has a method name 'add_arguments'
    else:
        # create a parser with a flag
        parser = argparse.ArgumentParser()
        parser.add_argument('-f', '--foo-bar')
        # get the output from the default parser
        parser_default = parser.format_help().splitlines()
        # get the output from the modified parser
        parser.formatter_class = SortingHelpFormatter
        parser_sorted = parser.format_help().splitlines()
        # assert that the sorted output is different, and matches our expectations
        assert parser_default != parser_sorted

# Generated at 2022-06-10 22:02:51.714021
# Unit test for function unfrack_path
def test_unfrack_path():
    result_val = unfrack_path(pathsep=True)(f"foobar{os.pathsep}/baz/qux{os.pathsep}~/bang")
    assert result_val == ["foobar", "/baz/qux", os.path.expanduser("~/bang")]

    result_val = unfrack_path(pathsep=False)("foobar")
    assert result_val == "foobar"

    result_val = unfrack_path(pathsep=False)("-")
    assert result_val == "-"

    if os.name == 'posix':
        assert unfrack_path(pathsep=False)("~/foobar") == os.path.expanduser("~/foobar")



# Generated at 2022-06-10 22:02:54.656826
# Unit test for function version
def test_version():
    result = version()
    assert isinstance(result, basestring)
    assert result.startswith('{0} [core {1}]'.format(os.path.basename(sys.argv[0]), __version__))


# Generated at 2022-06-10 22:03:00.949928
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/home/not/a/vm') == '@/home/not/a/vm'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@test') == '@test'



# Generated at 2022-06-10 22:03:08.311473
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.path import unfrackpath
    result = maybe_unfrack_path('@')('@test')
    assert result == '@' + unfrackpath('test')
    assert maybe_unfrack_path('@')('@@test') == '@@test'

    result = maybe_unfrack_path('@@')('@@test')
    assert result == '@@' + unfrackpath('test')
    assert maybe_unfrack_path('@@')('@test') == '@test'
    assert maybe_unfrack_path('@@')('@@@test') == '@@@test'


# Generated at 2022-06-10 22:03:15.647069
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(
        prog='ansible-connection',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description='',
        conflict_handler='resolve',
    )
    add_meta_options(parser)
    act_scr= parser.parse_args(['--force-handlers', '--flush-cache'])
#    print (act_scr.force_handlers, act_scr.flush_cache )


# Generated at 2022-06-10 22:03:26.200881
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    arg = argparse.Namespace()
    arg.prog = 'executable'
    AnsibleVersion.__call__(None, argparse.ArgumentParser, arg, None, None)
    assert True


# Generated at 2022-06-10 22:03:37.148629
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Test version command while Ansible is installed in site-packages
    sys.modules['ansible'].__version__ = '2.9.1'
    sys.modules['ansible'].release.__version__ = '2.9.1'
    sys.modules['ansible'].release.__author__ = 'Ansible Project'
    sys.modules['ansible'].release.__copyright__ = 'Copyright (c) 2017 Red Hat, Inc. and others'
    sys.modules['ansible'].release.__email__ = 'info@ansible.com'
    sys.modules['ansible'].release.__license__ = 'GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)'

# Generated at 2022-06-10 22:03:43.556237
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class MockParser(object):
        def __init__(self):
            self.prog = 'yolo'
        def exit(self):
            pass
    option_string = 'version'
    namespace = None
    values = None
    args = MockParser()
    a = AnsibleVersion()
    a(args, namespace, values, option_string)



# Generated at 2022-06-10 22:03:52.379068
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    """Simple test for PrependListAction class."""
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', nargs='*', action=PrependListAction)
    try:
        parser.parse_args(['--foo', 'spam', '--foo', 'eggs'])
    except:
        pass
    else:
        assert 0, "Round 1: --foo argument failed to raise ValueError"
    try:
        parser.parse_args(['--foo', 'spam', 'eggs', '--foo'])
    except:
        assert 0, "Round 2: --foo argument failed to raise ValueError"
    else:
        pass


#
# General purpose functions
#

# Generated at 2022-06-10 22:03:58.685780
# Unit test for function version
def test_version():
    C.ANSIBLE_REPO_LOCATION = "/home/user/ansible/ansible"
    C.ANSIBLE_MODULE_UTILS = "/home/user/ansible/lib/ansible/module_utils"
    ansible.__path__ = ['/home/user/ansible/lib/ansible']
    C.COLLECTIONS_PATHS = ["/home/user/ansible/ansible/collections"]
    sys.argv[0] = "/home/user/ansible/bin/ansible"
    result = version('ansible-playbook')
    assert result == "ansible-playbook [core 2.0.0.0] (/ansible 2.0.0.0-1-g7cb0ebd4)" \
                     "  config file = /etc/ansible/ansible.cfg"

# Generated at 2022-06-10 22:04:09.903471
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # setup
    expected_version = to_native(version('foo'))
    parser = argparse.ArgumentParser()
    parser.prog = 'foo'
    action = AnsibleVersion()
    # test
    try:
        action(parser, None, None, None)
    except SystemExit:
        ansible_version = sys.stdout.getvalue().splitlines()[-1]
        # assert
        assert ansible_version == expected_version
        assert sys.exit_code == 0
    else:
        # assert
        raise AssertionError()
    finally:
        # clean-up
        try:
            sys.stdout.close()
            sys.stdout = sys.__stdout__
        except AttributeError:
            pass



# Generated at 2022-06-10 22:04:11.735614
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path()
    unfrack_path(pathsep=True)

# Generated at 2022-06-10 22:04:18.327370
# Unit test for function unfrack_path
def test_unfrack_path():
    '''asserts for unfrack_path'''
    assert unfrack_path(pathsep=False)('~/a/b/c') == os.path.join(os.path.expanduser('~'), 'a', 'b', 'c')
    assert unfrack_path(pathsep=True)('~/a/b/c:/d/e/f') == [os.path.join(os.path.expanduser('~'), 'a', 'b', 'c'), '/d/e/f']



# Generated at 2022-06-10 22:04:27.818816
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c')
    parser.add_argument('-b')
    parser.add_argument('-a')

    x = SortingHelpFormatter(parser)

    # C0103: *Invalid name "%s" (should match %s)*
    # pylint: disable=C0103
    assert x._actions[1].option_strings == ['-a']
    assert x._actions[2].option_strings == ['-b']
    assert x._actions[3].option_strings == ['-c']



# Generated at 2022-06-10 22:04:30.608865
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test with pathsep option
    # Test with value '-'
    # Test with value '/usr/bin'
    pass


# Generated at 2022-06-10 22:04:40.878039
# Unit test for function version
def test_version():
    import ansible.constants as C
    C.ANSIBLE_CONFIG = '/dev/null'
    C.COLLECTIONS_PATHS = '/dev/null'
    assert version()
    assert not version('foo')

# Generated at 2022-06-10 22:04:42.643437
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/var/tmp') == '/var/tmp'


# Generated at 2022-06-10 22:04:50.362994
# Unit test for function version
def test_version():
    # Show help if no argument has been received
    if len(sys.argv) == 1:
        sys.argv.append("--help")

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-v", "--version", action=AnsibleVersion, help="show program's version number and exit")
    parser.add_argument("--version", action=AnsibleVersion, help="show program's version number and exit")
    args = parser.parse_args()
    print(args)


if __name__ == "__main__":
    test_version()

# Generated at 2022-06-10 22:04:53.908356
# Unit test for function add_meta_options
def test_add_meta_options():
    #returns exit code 0 to indicate success
    #set it to 1 to indicate failure
    exit_code = 0
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_meta_options(parser)
    command_line = ['--force-handlers','--flush-cache']
    namespace = parser.parse_args(command_line)
    if not namespace.force_handlers:
        print("force_handlers is set to False")
        exit_code = 1
    if not namespace.flush_cache:
        print("flush_cache is set to False")
        exit_code = 1
    return exit_code


# Generated at 2022-06-10 22:05:01.931838
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter, add_help=False)
    parser.add_argument('--foo', action='store', help='foo help')
    parser.add_argument('--bar', action='store', help='bar help')
    parser.add_argument('--baz', action='store', help='baz help')
    parser.add_argument('--zzz', action='store', help='zzz help')
    output = parser.format_help()
    assert '--bar' in output
    assert output.find('--bar') < output.find('--baz')



# Generated at 2022-06-10 22:05:04.186236
# Unit test for function add_meta_options
def test_add_meta_options():
    parser=argparse.ArgumentParser()
    add_meta_options(parser)
    (args, remaining_argv) = parser.parse_known_args(['--force-handlers','--flush-cache'])
    assert args.force_handlers
    assert args.flush_cache


add_meta_options(CLI.base_parser)



# Generated at 2022-06-10 22:05:11.050656
# Unit test for function version
def test_version():
    assert version() == """2.8.0
  config file = /dev/null
  configured module search path = Default w/o overrides
  ansible python module location = /home/vagrant/ansible/lib/ansible
  ansible collection location = []
  executable location = /home/vagrant/ansible/bin/ansible
  python version = 2.7.5 (default, Nov 20 2015, 02:00:19) 
  [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
  jinja version = 2.7.3
  libyaml = False"""
#
# Command line parser
#


# Generated at 2022-06-10 22:05:20.632886
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # when beacon not in value
    assert maybe_unfrack_path('@@')('bar') == 'bar'
    # when beacon in value (local path)
    assert maybe_unfrack_path('@@')('@@bar') == '@@' + unfrackpath('bar')
    # when beacon in value (playbook path)
    assert maybe_unfrack_path('@@')('@@bar') == '@@' + unfrackpath('bar')
    # when beacon in value (system path)
    assert maybe_unfrack_path('@@')('@@bar') == '@@' + unfrackpath('bar')
    # when beacon in value (a full local path)
    assert maybe_unfrack_path('@@')('@@/home/user/file') == '@@/home/user/file'
    # when

# Generated at 2022-06-10 22:05:24.885479
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/tmp') == '@' + unfrackpath('/tmp')
    assert maybe_unfrack_path('@')('/tmp') == '/tmp'
# Test end



# Generated at 2022-06-10 22:05:25.866614
# Unit test for function version
def test_version():
    assert isinstance(version(), str)

# Generated at 2022-06-10 22:05:40.532749
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    sys.argv = ['ansible-playbook', '--version']
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--version',
        action=AnsibleVersion,
        help='Show ansible version',
    )
    args = parser.parse_args()
    sys.argv = []


# Generated at 2022-06-10 22:05:47.128947
# Unit test for function unfrack_path
def test_unfrack_path():
    if sys.platform == 'win32':
        assert unfrack_path(pathsep=False)('foo') == 'foo'
        assert unfrack_path(pathsep=False)('') == ''
        assert unfrack_path(pathsep=True)('/foo/bar:/a/b/c:/foo/./baz') == ['foo\\bar', 'a\\b\\c', 'foo\\baz']
    else:
        assert unfrack_path(pathsep=False)('foo') == 'foo'
        assert unfrack_path(pathsep=False)('') == ''
        assert unfrack_path(pathsep=True)('/foo/bar:/a/b/c:/foo/./baz') == ['/foo/bar', '/a/b/c', '/foo/baz']



# Generated at 2022-06-10 22:05:51.185281
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    a = AnsibleVersion
    class parser(object):
        prog = 'ansible-playbook'
        def exit(self):
            return
    a.__call__(a, parser, None, None)


# Generated at 2022-06-10 22:06:02.461886
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('a')[0] == 'a'
    assert unfrack_path(pathsep=True)('a')[0] == 'a'
    assert unfrack_path(pathsep=False)('/a')[0] == '/a'
    assert unfrack_path(pathsep=True)('/a')[0] == '/a'
    assert unfrack_path(pathsep=False)('../a')[0] == '../a'
    assert unfrack_path(pathsep=True)('../a')[0] == '../a'
    assert unfrack_path(pathsep=False)('~/a')[0] == '~/a'

# Generated at 2022-06-10 22:06:11.868690
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument("-b")
    parser.add_argument("-a")
    parser._positionals.title = "positional arguments"
    parser._optionals.title = "optional arguments"

    formatter = SortingHelpFormatter()
    formatter.add_argument = lambda *args, **kwargs: None
    formatter.start_section = lambda *args: None
    formatter.end_section = lambda: None
    formatter._add_item = lambda *args: None

    formatter.add_usage(parser.usage, parser._actions,
                        parser._mutually_exclusive_groups)
    formatter.add_arguments(parser._positionals._group_actions)
    formatter.add_arguments(parser._optionals._group_actions)

# Generated at 2022-06-10 22:06:13.996687
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path('@libexecdir@')('@libexecdir@/foo') ==
           '@libexecdir@/foo')



# Generated at 2022-06-10 22:06:22.768137
# Unit test for function unfrack_path
def test_unfrack_path():
    '''
    Test unfrack_path()
    '''
    # Test pathsep = False
    result = unfrack_path(False)('~/ansible')
    assert result == os.path.expanduser('~/ansible'), result
    result = unfrack_path(False)('')
    assert result == '', result
    # Test pathsep = True
    result = unfrack_path(True)('~/ansible')
    assert result == [os.path.expanduser('~/ansible')], result
    result = unfrack_path(True)('')
    assert result == [], result


# Generated at 2022-06-10 22:06:27.146529
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path('@')('@/roles/common')) == '@/roles/common'
    assert(maybe_unfrack_path('@')('@@/roles/common')) == '@@/roles/common'
    assert(maybe_unfrack_path('@')('@tmp/roles/common')) == '@tmp/roles/common'


# Generated at 2022-06-10 22:06:33.629342
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(to_native(os.path.sep))('/ansible/tests/') == unfrackpath('/ansible/tests/')
    assert maybe_unfrack_path(to_native(os.pathsep))('/ansible/tests/' + os.pathsep + '/foo/bar') == unfrackpath('/ansible/tests/' + os.pathsep + '/foo/bar')
    assert maybe_unfrack_path(to_native(os.pathsep))('/ansible/tests/' + os.pathsep + '/foo/bar') != '/ansible/tests/:' + unfrackpath('/foo/bar')


# Generated at 2022-06-10 22:06:35.956821
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    sub_parser = parser.add_subparsers()
    AnsibleVersion()(sub_parser, None, None, None)


# Generated at 2022-06-10 22:06:56.016860
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion(option_strings="--version")
    parser = argparse.ArgumentParser()
    action(parser, argparse.Namespace(), option_string="--version")



# Generated at 2022-06-10 22:06:58.583632
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version())
    assert ansible_version == 'ansible-base 2.10.1'


# Generated at 2022-06-10 22:07:04.381572
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    begin_v = '-r'
    v = maybe_unfrack_path(begin_v)(begin_v)
    assert v.startswith(begin_v)
    assert unfrackpath(v[1:]) == v[1:]

# python3 gives a very weird error if the callback has the same name as in the
# decorator, use a different name so that decorators don't break.

# Generated at 2022-06-10 22:07:13.905645
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import tempfile
    version_output = __version__
    with tempfile.TemporaryFile() as f:
        saved_stdout = sys.stdout
        sys.stdout = f
        try:
            AnsibleVersion(None, None, None, option_string=None)(None, None, None)
            sys.stdout, f = f, sys.stdout
            f.seek(0)
            out = f.read().strip()
        finally:
            sys.stdout = saved_stdout
        assert out == version_output


#
# More or less direct translations of some existing code
#

# Generated at 2022-06-10 22:07:15.979051
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # ansible_version = to_native(version(getattr(parser, 'prog')))
    # print(ansible_version)
    # parser.exit()
    pass


# Generated at 2022-06-10 22:07:19.150487
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrackpath('$ANSIBLE_HOME/test') == '%s/test' % os.environ['ANSIBLE_HOME']
    assert unfrackpath('~/test') == os.environ['HOME'] + '/test'


# Generated at 2022-06-10 22:07:20.663074
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # FIXME: add unit tests
    maybe_unfrack_path("@")



# Generated at 2022-06-10 22:07:29.797542
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('a/b/c') == 'a/b/c'
    assert unfrack_path()('~/a/b/c') == os.path.join(os.path.expanduser('~'), 'a/b/c')
    assert unfrack_path()('/a/b/c') == '/a/b/c'

    custom_path_list = '~/ansible/playbooks:/etc/ansible/playbook'
    assert unfrack_path(pathsep=True)(custom_path_list) == [os.path.join(os.path.expanduser('~'), 'ansible/playbooks'), '/etc/ansible/playbook']



# Generated at 2022-06-10 22:07:30.601331
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    assert True



# Generated at 2022-06-10 22:07:32.277782
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Not implemented
    pass

