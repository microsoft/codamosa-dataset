

# Generated at 2022-06-10 21:58:52.336317
# Unit test for function add_runas_options
def test_add_runas_options():
    prog = 'internal-test'
    desc = 'test program'
    parser = create_base_parser(prog, desc)
    add_runas_options(parser)
    add_runas_prompt_options(parser)

    args = ['--become', '--become-method', 'test',
            '--become-prompt', 'becomme prompt',
            '--become-user', 'test-user']
    parsed_args = parser.parse_args(args)

    assert parsed_args.become is True
    assert parsed_args.become_method == 'test'
    assert parsed_args.become_user == 'test-user'
    assert parsed_args.ask_become_pass is False
    assert parsed_args.ask_su_pass is False


# Generated at 2022-06-10 21:58:57.006981
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    opts, args = parser.parse_known_args(['-C', '-D'])
    assert opts.check == True
    assert opts.diff == True


# Generated at 2022-06-10 21:59:00.165510
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    """
    Unit test for function add_runas_prompt_options
    """
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)
    args = parser.parse_args([])
    assert args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS



# Generated at 2022-06-10 21:59:05.494993
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    f = maybe_unfrack_path("@")
    v1 = f("@/test/test")
    assert v1 == "@" + os.path.abspath("/test/test")
    v2 = f("~/test/test")
    assert v2 == "~/test/test"


# Generated at 2022-06-10 21:59:10.216506
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.parse_args(['--ask-vault-password'])
    parser.parse_args(['--ask-vault-pass'])


#
# Functions to add pre-canned options to an OptionParser for environ overrides
#


# Generated at 2022-06-10 21:59:16.117580
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args('')
    assert args.tags == C.TAGS_RUN
    assert args.skip_tags == C.TAGS_SKIP

    args = parser.parse_args('-t foo -t bar --skip-tags baz'.split())
    assert args.tags == ['foo', 'bar']
    assert args.skip_tags == ['baz']



# Generated at 2022-06-10 21:59:17.598506
# Unit test for function add_check_options
def test_add_check_options():
    assert add_check_options()


# Generated at 2022-06-10 21:59:29.025970
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()
    add_runas_prompt_options(parser)

    args = parser.parse_args(['--become-pass-file', '/etc/passwd'])
    assert args.become_password_file == '/etc/passwd'

    args = parser.parse_args(['--become-password-file', '/etc/shadow'])
    assert args.become_password_file == '/etc/shadow'

    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True

    args = parser.parse_args([])
    assert args.become_ask_pass == C.DEFAULT_BECOME_ASK_PASS
    assert args.become_password_file == C.BECOME_PASSWORD_FILE



# Generated at 2022-06-10 21:59:32.154803
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = Mock()
    add_meta_options(parser)
    assert_true(parser.add_argument.called)
    assert_equal(parser.add_argument.call_count, 2)


# Generated at 2022-06-10 21:59:39.621653
# Unit test for function add_subset_options
def test_add_subset_options():

    class Options:
        tags = C.TAGS_RUN
        skip_tags = C.TAGS_SKIP

    options = Options()

    parser = argparse.ArgumentParser()
    add_subset_options(parser)

    args = parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip_tag1'])
    parser.parse_args(['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip_tag1'], namespace=options)

    assert options.tags == ['tag1', 'tag2']
    assert options.skip_tags == ['skip_tag1']

    # not empty, but also not specified in args
    assert options.tags != C.TAGS_RUN
    assert options.skip_

# Generated at 2022-06-10 22:00:00.164342
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = create_base_parser("Test")
    add_connect_options(parser)
    assert parser.has_option('--private-key')
    assert parser.has_option('-u')
    assert parser.has_option('-c')
    assert parser.has_option('-T')
    assert parser.has_option('--ssh-common-args')
    assert parser.has_option('--ssh-extra-args')
    assert parser.has_option('--sftp-extra-args')
    assert parser.has_option('--scp-extra-args')
    assert parser.has_option('-k')
    assert parser.has_option('--connection-password-file')



# Generated at 2022-06-10 22:00:07.891001
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()(to_native("~/.ansible/tmp/foo")) == unfrackpath("~/.ansible/tmp/foo")
    assert unfrack_path()(to_native("~/.ansible/tmp/foo:~/bar")) == unfrackpath("~/.ansible/tmp/foo:~/bar")
    assert unfrack_path()(to_native("~/.ansible/tmp/foo:~bar")) == unfrackpath("~/.ansible/tmp/foo:~bar")



# Generated at 2022-06-10 22:00:16.119347
# Unit test for function add_async_options
def test_add_async_options():
    """Test whether debug options can be accepted by a OptionParse"""
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    opt = parser.parse_args([])
    assert opt.seconds == 0
    assert opt.poll_interval == 10
    opt = parser.parse_args(['-B', '20', '-P', '30'])
    assert opt.seconds == 20
    assert opt.poll_interval == 30



# Generated at 2022-06-10 22:00:18.488864
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    add_module_options(parser)
    args = parser.parse_args(['-M', '~/path1:~/path2'])
    expected = [os.path.expanduser('~/path1'), os.path.expanduser('~/path2')]
    assert args.module_path == expected, '-M path not handled as expected'



# Generated at 2022-06-10 22:00:19.324219
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)


# Generated at 2022-06-10 22:00:21.538552
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser(
        prog='test_add_fork_options',
        formatter_class=SortingHelpFormatter,
        epilog='Show default value of parallel processes to use',
        description='test for function add_fork_options',
    )
    add_fork_options(parser)
    parser.parse_args()


# Generated at 2022-06-10 22:00:29.258536
# Unit test for function version
def test_version():
    assert version('foo') == 'foo [core 1.0.0] () last updated (GMT +0000)  config file = /path/to/ansible.cfg  configured module search path = Default w/o overrides  ansible python module location = /path/to/ansible:foo  ansible collection location = :bar  executable location = /path/to/ansible  python version = 2.7.5 (default, Nov  6 2016, 00:28:07)  [GCC 4.8.5 20150623 (Red Hat 4.8.5-11)]  jinja version = 2.8  libyaml = True'


# Generated at 2022-06-10 22:00:31.805247
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo') == '@/foo'
    assert maybe_unfrack_path('@')('@/bar/test') == '@/bar/test'
    assert maybe_unfrack_path('@')('@/baz/test') == '@/baz/test'



# Generated at 2022-06-10 22:00:39.892533
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('!')('!unfracked') == '!%s' % unfrackpath('unfracked')
    assert maybe_unfrack_path('!')('../unfracked') == '../unfracked'
    assert maybe_unfrack_path('!')('/unfracked') == '/unfracked'
    assert maybe_unfrack_path('!')('unfracked') == 'unfracked'



# Generated at 2022-06-10 22:00:41.235306
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = argparse.ArgumentParser()
    add_fork_options(parser)
    args = parser.parse_args(['-f', '1'])
    assert args.forks == 1

# Generated at 2022-06-10 22:01:00.484132
# Unit test for function version
def test_version():
    assert isinstance(version(), str)

# Generated at 2022-06-10 22:01:09.756183
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument("-b", "--bar")
    parser.add_argument("-a", "--foo")
    parser.add_argument("-c", "--baz")
    actions = parser._get_positional_actions()
    options = parser._get_optional_actions()

    assert actions == []
    assert options == [
        parser._option_string_actions["-b"][0],
        parser._option_string_actions["-a"][0],
        parser._option_string_actions["-c"][0],
    ]


# Generated at 2022-06-10 22:01:20.762715
# Unit test for function version
def test_version():
    from ansible import release
    version_string = version()
    # verify version_string
    assert __version__ in version_string
    assert release.__version__ in version_string
    if sys.version_info < (3,):
        assert 'executable location =' in version_string
        assert sys.executable in version_string
    assert 'python version =' in version_string
    assert ''.join(sys.version.splitlines()) in version_string
    assert 'jinja version =' in version_string
    assert j2_version in version_string
    assert 'libyaml =' in version_string
    assert str(HAS_LIBYAML) in version_string
    # test to ensure a custom installed ansible will display the correct path
    assert 'ansible python module location =' in version_string

# Generated at 2022-06-10 22:01:25.366188
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(prog='test', formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--foo-bar')
    args = parser.parse_args(['--help'])



# Generated at 2022-06-10 22:01:31.806893
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('-a', '--alpha')
    parser.add_argument('-b', '--beta')
    parser.add_argument('-c', '--gamma')
    args = ['-a', '--beta', '--gamma']
    opts = parser.parse_args(args)
    assert args[1] in opts



# Generated at 2022-06-10 22:01:33.122849
# Unit test for function version
def test_version():
    assert version() == '2.8.0+dev0'

# Generated at 2022-06-10 22:01:38.122181
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = create_base_parser(prog='ansible')
    add_runtask_options(parser)
    options = parser.parse_args(['-e', 'var1=value1', '-e', 'var2=value2'])
    assert options.extra_vars[1] == 'var1=value1'


# Generated at 2022-06-10 22:01:42.275271
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    a = AnsibleVersion()
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", dest="version", action=AnsibleVersion)
    out = ''
    try:
        out = version(parser.prog)
    except SystemExit:
        pass
    assert out == to_native(ansible.__version__)

# Generated at 2022-06-10 22:01:42.813640
# Unit test for function add_runtask_options
def test_add_runtask_options():
    assert False


# Generated at 2022-06-10 22:01:43.749212
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter(): assert SortingHelpFormatter


# Generated at 2022-06-10 22:01:57.833476
# Unit test for function ensure_value
def test_ensure_value():
    class obj(object):
        pass
    # Test 1: ensure that an attribute is set if not present, and return the attribute value
    assert(ensure_value(obj(), 'foo', 1) == 1)
    assert(obj().foo == 1)
    # Test 2: ensure that an attribute is *not* set if already present, and return the attribute value
    obj.foo = 2
    assert(ensure_value(obj(), 'foo', 3) == 2)
    assert(obj().foo == 2)


#
# Command line parsing
#

# Generated at 2022-06-10 22:02:02.780727
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '/foo/bar'
    test_path2 = '~/foo/bar'
    test_path3 = '-/foo/bar'
    assert maybe_unfrack_path('-/')(test_path2) == test_path2
    assert maybe_unfrack_path('-/')(test_path3) == test_path



# Generated at 2022-06-10 22:02:12.424050
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    """Tests that actions are sorted alphabetically by default."""
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--d')
    parser.add_argument('-a')
    parser.add_argument('--c')
    parser.add_argument('-b')
    expected_stdout = '''usage: [-h] [--d D] [-a A] [--c C] [-b B]

optional arguments:
  -h, --help  show this help message and exit
  --d D       a usage message
  -a A        a usage message
  --c C       a usage message
  -b B        a usage message
'''
    output = parser.format_help()
    assert output == expected_stdout


# Generated at 2022-06-10 22:02:19.913110
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """
    Unit test for method __call__ of class AnsibleVersion
    """
    adhoc = AnsibleVersion(None, None, None, None)
    parser = argparse.ArgumentParser()
    parser.prog = 'unit-test'
    ansible_version = to_native(version(getattr(parser, 'prog')))
    assert ansible_version == adhoc.__call__(parser, None, None, None)



# Generated at 2022-06-10 22:02:27.920328
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/path') == '@/path'
    assert maybe_unfrack_path('@')('@./path') == '@./path'
    assert maybe_unfrack_path('@')('@~/path') == '@/path'
    assert maybe_unfrack_path('@')('@/~/path') == '@/~/path'
    assert maybe_unfrack_path('@')('@./~/path') == '@./~/path'



# Generated at 2022-06-10 22:02:36.363040
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # we don't want to unfrack absolute paths, only paths
    # given as `~/`
    assert maybe_unfrack_path('~')('~/a') == '~/a'
    assert maybe_unfrack_path('~')('/a') == '/a'
    assert maybe_unfrack_path('-')('-') == '-'
    assert maybe_unfrack_path('-')('~/a') == '~/a'



# Generated at 2022-06-10 22:02:39.906724
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr('prog', 'ansible-config')))
    assert ansible_version == ansible.__version__


# Generated at 2022-06-10 22:02:51.924690
# Unit test for function version
def test_version():
    import json
    from ansible.module_utils.common.text.converters import to_text
    out = to_text(version())

# Generated at 2022-06-10 22:02:58.006339
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    from ansible.cli import CLI

    cli = CLI(args=[])
    parser = cli.base_parser()
    cli.setup_parser(parser)
    cli.parser = parser
    cli.parser.formatter_class = SortingHelpFormatter
    h = cli.parser.format_help()
    assert h == ''



# Generated at 2022-06-10 22:03:06.139174
# Unit test for function ensure_value
def test_ensure_value():
    class FakeNamespace:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __getattr__(self, attr):
            return self.name

    ensure_value(FakeNamespace('foo', None), 'value', 'bar')
    assert FakeNamespace('foo', None).value == 'bar'
    ensure_value(FakeNamespace('foo', 'baz'), 'value', None)
    assert FakeNamespace('foo', 'baz').value == 'baz'
    # We are done with these tests
    del test_ensure_value



# Generated at 2022-06-10 22:03:21.919774
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    l = data_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    data_dir = unfrackpath(data_dir)
    assert maybe_unfrack_path('l@')('l@%s' % l) == 'l@%s' % data_dir
    assert maybe_unfrack_path('l@')(os.path.join(l, 'foo')) == os.path.join(data_dir, 'foo')



# Generated at 2022-06-10 22:03:32.408947
# Unit test for function version
def test_version():
    assert version('foo') == version()
    assert version() == '''foo [core 2.0.0.0.0]
  config file = /Users/username/ansible.cfg
  configured module search path = /Users/username/ansible/modules
  ansible python module location = /Users/username/ansible/lib/ansible
  ansible collection location = /Users/username/ansible/collections:/Users/username/ansible/plugins/collections:/usr/share/ansible/collections:/usr/share/ansible/plugins/collections
  executable location = /usr/bin/ansible-playbook
  python version = 2.7.15 (default, Jun  1 2018, 04:53:35)
  jinja version = 2.10
  libyaml = False'''

#
# Options that are common to

# Generated at 2022-06-10 22:03:45.610990
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # This should be the safe way to test if the current path is not in the
    # default ansible search locations.
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    cwd = os.getcwd()
    test_path = os.path.join(cwd, "nonexistentdir")
    input_dirs = [os.path.join(root, 'lib'),
                  os.path.join(root, 'doc'),
                  os.path.join(root, 'test'),
                  test_path]
    # If the current working directory is the base of the repository, this
    # test will not work, so we need to skip it.

# Generated at 2022-06-10 22:03:49.763490
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar/') == '@/foo/bar/'



# Generated at 2022-06-10 22:03:57.359262
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('lib') == unfrackpath('lib')
    assert unfrack_path()('lib/') == unfrackpath('lib')
    assert unfrack_path(pathsep=True)('lib/') == [unfrackpath('lib')]
    assert unfrack_path()('') == None


# Generated at 2022-06-10 22:04:03.612500
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description='parser for testing', formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action="store", help='2nd')
    parser.add_argument('-a', action="store", help='1st')
    parser.parse_args([])
    return


_DISPLAY_ARGS = [
    'listhosts',
    'listtasks',
    'listtags',
    'syntax',
    'module_path',
    'inventory',
    'v2_playbook_compat',
    'vault_identity_list',
]


# Generated at 2022-06-10 22:04:14.886417
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    result = maybe_unfrack_path('/')('')
    assert result == '', "result was %s" % result
    result = maybe_unfrack_path('/')('~/foo')
    assert result == '~/foo', "result was %s" % result
    result = maybe_unfrack_path('/')('/foo')
    assert result == '/foo', "result was %s" % result
    result = maybe_unfrack_path('/')('/~/foo')
    assert result == '~foo', "result was %s" % result
    result = maybe_unfrack_path('/')('/bar/~/foo')
    assert result == '/bar/~foo', "result was %s" % result



# Generated at 2022-06-10 22:04:19.154877
# Unit test for function version
def test_version():
    ansible_version = version('ansible')
    assert ansible_version.startswith('ansible [core ')
    assert ansible_version.splitlines()[1].startswith('  config file = ')
    assert ansible_version.splitlines()[2].startswith('  configured module search path = ')
    assert ansible_version.splitlines()[3].startswith('  ansible python module location = ')
    assert ansible_version.splitlines()[4].startswith('  ansible collection location = ')
    assert ansible_version.splitlines()[5].startswith('  executable location = ')
    assert ansible_version.splitlines()[6].startswith('  python version = ')

# Generated at 2022-06-10 22:04:32.377162
# Unit test for function version
def test_version():
    sys.argv = ['ansible-playbook']
    v = version()
    assert 'ansible-playbook [core' in v
    assert 'config file = (detected)' in v
    assert 'executable location =' in v
    assert 'python version = ' in v
    assert 'jinja version =' in v
    assert 'libyaml =' in v
    sys.argv = ['foo']
    v = version('test')
    assert 'test [core' in v
    assert 'config file = (detected)' in v
    assert 'executable location =' in v
    assert 'python version = ' in v
    assert 'jinja version =' in v
    assert 'libyaml =' in v
    sys.argv = ['foo']
    v = version('test')
    assert 'test [core'

# Generated at 2022-06-10 22:04:39.078439
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-10 22:04:58.199974
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('=')('=') == '='
    assert maybe_unfrack_path('=')('=./') == '=./'
    assert maybe_unfrack_path('=')('=/') == '=./'
    assert maybe_unfrack_path('=')('=a') == '=a'
    assert maybe_unfrack_path('=')('=a/') == '=./a'
    assert maybe_unfrack_path('=')('=a/b') == '=./a/b'

    assert maybe_unfrack_path('+')('+') == '+'
    assert maybe_unfrack_path('+')('+./') == '+./'
    assert maybe_unfrack_path('+')('+/') == '+./'


# Generated at 2022-06-10 22:05:05.243230
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('$')('$asd/fghj') == '$' + unfrackpath('$asd/fghj'[1:])
    assert maybe_unfrack_path('$')('@asd/fghj') == '@asd/fghj'
    assert maybe_unfrack_path('$')('asd/fghj') == 'asd/fghj'
    assert maybe_unfrack_path('$')('') == ''


# Generated at 2022-06-10 22:05:09.511602
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('--one', help='first argument')
    parser.add_argument('--two', help='second argument')
    parser.add_argument('--three', help='third argument')
    assert parser.format_usage().strip() == "usage: [-h] [--one ONE] [--two TWO] [--three THREE]"


# Generated at 2022-06-10 22:05:13.867417
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@' + unfrackpath('/foo/bar')
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'



# Generated at 2022-06-10 22:05:23.889143
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # NOTE: if this function is changed, the signature of may_unfrack_path can't be changed
    #  because the signature is used to determine if the function needs to be applied in the
    #  module_common code.  This is why the assertTrue function is used, as opposed to assertEquals.
    from ansible.cli import CLI

    cli = CLI(args=[])
    for beacon in cli.BECOME_PROMPT_LOCALHOSTS:
        assertTrue('@' in beacon)

    test_string_1 = 'abc@def'
    test_string_2 = 'abcdef'
    test_string_3 = 'XYZ@def'

    # test strings that don't begin with a beacon

# Generated at 2022-06-10 22:05:26.886029
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    expected_path = unfrackpath('~/.ansible/roles')
    assert maybe_unfrack_path('~')('~/.ansible/roles') == expected_path
    assert maybe_unfrack_path('~')('/etc/ansible/roles') == '/etc/ansible/roles'
#/ Unit test for function maybe_unfrack_path


# Generated at 2022-06-10 22:05:31.283131
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_dir = '/foo/bar'
    beacon = '-c'
    value = beacon + test_dir

    result = maybe_unfrack_path(beacon)(value)

    assert result == value

    # canonicalize path by converting forward slashes to backslashes on Windows
    if sys.platform == 'win32':
        test_dir = test_dir.replace(os.path.sep, '/')
    result = maybe_unfrack_path(beacon)(test_dir)
    assert len(result) > 3


# Generated at 2022-06-10 22:05:36.704763
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # The '+' is prepended to the path to test unfracking of different paths than
    # /etc/ansible/anything.
    test_paths = ['+/etc/ansible/ansible-test', '+/home/foo']
    unfracked_paths = ['+/etc/ansible/ansible-test', '+/home/foo']
    for path in test_paths:
        assert maybe_unfrack_path('+')(path) == unfracked_paths[test_paths.index(path)]
    return True



# Generated at 2022-06-10 22:05:43.725179
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description='description', formatter_class=SortingHelpFormatter)
    parser.add_argument('-b', action='store_true', help='b help')
    parser.add_argument('-c', action='store_true', help='c help')
    parser.add_argument('-a', action='store_true', help='a help')
    parser.parse_args(['-b', '-c', '-a'])


#
# Main AnsibleOptionParser object
#

# Generated at 2022-06-10 22:05:54.333462
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    p = maybe_unfrack_path("::")
    assert p("::some/path") == "::some/path"
    assert p("::%s" % os.sep) == "::%s" % os.sep
    assert p("::/") == "::%s" % os.sep
    assert p("::%s/" % os.sep) == "::%s/" % os.sep
    assert p("::/some/path") == "::%s/some/path" % os.sep
    assert p("/some/path") == "/some/path"
    assert p("::") == "::"
    assert p("") == ""



# Generated at 2022-06-10 22:06:28.302882
# Unit test for function version
def test_version():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict

    display = Display()
    v = version('ansible-playbook')
    for line in v.split('\n'):
        display.debug(line)
    assert 'ansible-playbook [core 2.9.0' in v
    assert 'config file = %s' % os.path.expanduser('~/.ansible.cfg') in v
    assert 'configured module search path = %s' % os.path.expanduser('~/.ansible/plugins/modules') in v
    assert 'ansible python module location = %s' % os.path.dirname(os.path.dirname(ansible.__file__)) in v

# Generated at 2022-06-10 22:06:35.238343
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@.') == '@.'
    assert maybe_unfrack_path('@')('@./') == '@.'
    assert maybe_unfrack_path('@')('@@') == '@@'
    assert maybe_unfrack_path('@')('@@/') == '@@'
    assert maybe_unfrack_path('@')('@./foo') == '@./foo'
    assert maybe_unfrack_path('@')('@./foo/') == '@./foo'
    assert maybe_unfrack_path('@')('@@/foo') == '@@/foo'

# Generated at 2022-06-10 22:06:39.153530
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_path = '/home/ansible/playbook/test.yaml'
    expected_path = '/home/ansible/playbook/test.yaml'
    result = maybe_unfrack_path(beacon)
    assert result(test_path) == expected_path



# Generated at 2022-06-10 22:06:45.379345
# Unit test for function unfrack_path
def test_unfrack_path():
    # unfrackpath is a function in utils/path and not mocked.  Use a real test
    # to make sure that the function works as expected.
    assert unfrack_path()('test') == unfrackpath('test')
    assert unfrack_path(pathsep=True)('test:test') == [unfrackpath('test'), unfrackpath('test')]
    assert unfrack_path()('-') == '-'



# Generated at 2022-06-10 22:06:49.387378
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test with unfracking
    value = '@/test_path'
    result = maybe_unfrack_path('@')(value)
    expected = '@' + unfrackpath('/test_path')
    assert result == expected

    # Test without unfracking
    value = '$HOME'
    result = maybe_unfrack_path('@')(value)
    expected = '$HOME'
    assert result == expected



# Generated at 2022-06-10 22:06:55.683036
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@a/b/c") == "@a/b/c"
    assert maybe_unfrack_path("@")("@/a/b/c") == "@a/b/c"
    assert maybe_unfrack_path("@")("/a/b/c") == "/a/b/c"

#
# The Base OptParser
#

# Generated at 2022-06-10 22:07:01.805000
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Should return beacon + unfrackpath when string starts with beacon
    val = "./testing"
    outcome = maybe_unfrack_path("./")
    assert outcome(val) == "./testing"

    # Should return value if string does not start with beacon
    val = "/testing"
    outcome = maybe_unfrack_path("./")
    assert outcome(val) == "/testing"


# Generated at 2022-06-10 22:07:08.411024
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    home_dir = os.path.expanduser("~")
    assert maybe_unfrack_path("~")("~/test.yml") == home_dir+"/test.yml"
    assert maybe_unfrack_path("~")("/test.yml") == "/test.yml"
    assert maybe_unfrack_path("~")("test.yml") == "test.yml"



# Generated at 2022-06-10 22:07:18.947542
# Unit test for function version

# Generated at 2022-06-10 22:07:28.863495
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    prefix = "@@@"
    assert maybe_unfrack_path(prefix)(prefix + './library') == prefix + unfrackpath('./library')
    assert maybe_unfrack_path(prefix)(prefix + '~/library') == prefix + unfrackpath('~/library')
    assert maybe_unfrack_path(prefix)(prefix + '/library') == prefix + unfrackpath('/library')
    assert maybe_unfrack_path(prefix)(prefix + 'library') == prefix + unfrackpath('library')
    assert maybe_unfrack_path(prefix)(prefix) == prefix
    assert maybe_unfrack_path(prefix)('library') == 'library'
    assert maybe_unfrack_path(prefix)('/library') == '/library'