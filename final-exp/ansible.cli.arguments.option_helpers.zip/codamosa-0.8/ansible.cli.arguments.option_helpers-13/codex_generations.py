

# Generated at 2022-06-10 21:58:49.025780
# Unit test for function add_vault_options
def test_add_vault_options():
    obj = AnsibleOptions()
    parser = obj.parser
    add_vault_options(parser)


# Generated at 2022-06-10 21:58:55.951827
# Unit test for function add_subset_options
def test_add_subset_options():
    import argparse
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    results = parser.parse_args(args=[])

    assert results.tags == C.TAGS_RUN, "the default tags are not set correctly"
    assert results.skip_tags == C.TAGS_SKIP, "the default skip_tags are not set correctly"



# Generated at 2022-06-10 21:59:01.734356
# Unit test for function add_async_options
def test_add_async_options():
    result = ['-P', '--poll', '-B', '--background']
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    parser_result = []
    for option in parser._actions:
        parser_result.append(option.option_strings)
    assert sorted(result) == sorted(parser_result)




# Generated at 2022-06-10 21:59:11.888243
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@@")("@@a") == "@@a"
    assert maybe_unfrack_path("@@")("@@a/b") == "@@a/b"
    assert maybe_unfrack_path("@@")("@@a/../b") == "@@a/../b"
    assert maybe_unfrack_path("@@")("@@~/b") == "@@/home/b"
    assert maybe_unfrack_path("@@")("@@/root/b") == "@@/root/b"
    assert maybe_unfrack_path("@@")("@a") == "@a"



# Generated at 2022-06-10 21:59:13.837283
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args, _ = parser.parse_known_args()
    assert args.inventory is None
    assert args.listhosts is None
    assert args.subset == C.DEFAULT_SUBSET
    assert args.limit == C.DEFAULT_SUBSET



# Generated at 2022-06-10 21:59:18.902454
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description="whatever")
    add_vault_options(parser)
    try:
        parser.parse_args(args=['--vault-password-file', '@password.txt',
                                '--vault-password-file', '/etc/passwd',
                                '--ask-vault-password',
                                '--vault-password-file', '/etc/passwd',
                                '--ask-vault-password',
                                '--vault-id', 'foo',
                                '--vault-id', 'bar'])
    except SystemExit:
        assert False, 'Parse Failed'


# Generated at 2022-06-10 21:59:26.513906
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    options, args = parser.parse_known_args(['-B', '20'])
    assert options.seconds == 20
    assert options.poll_interval == C.DEFAULT_POLL_INTERVAL
    options, args = parser.parse_known_args(['-P', '20'])
    assert options.seconds == 0
    assert options.poll_interval == 20



# Generated at 2022-06-10 21:59:37.995317
# Unit test for function add_connect_options
def test_add_connect_options():
    """
    Check if add_connect_options function is behaving as expected
    """
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    options = parser.parse_args(['-u', 'test', '-c', 'local', '-T', '1', '--ssh-common-args', 'proxycommand',
                                 '--sftp-extra-args', '-f', '-l', '--ssh-extra-args', '-R', '--ask-pass', '-k'])
    assert options.remote_user == 'test'
    assert options.connection == 'local'
    assert options.timeout == 1
    assert options.ssh_common_args == 'proxycommand'
    assert options.sftp_extra_args == '-f -l'
    assert options.ssh_extra

# Generated at 2022-06-10 21:59:48.655015
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    from ansible.cli import CLI
    from ansible.utils.display import Display
    cli = CLI(['ping'], display=Display())
    cli.parser.add_argument('-K', '--ask-become-pass', dest='become_ask_pass', action='store_true',
                                  default=C.DEFAULT_BECOME_ASK_PASS,
                                  help='ask for privilege escalation password')
    cli.parser.add_argument('--become-password-file', '--become-pass-file', default=C.BECOME_PASSWORD_FILE, dest='become_password_file',
                                  help="Become password file", type=unfrack_path(), action='store')
    cli.parse()



# Generated at 2022-06-10 21:59:59.632553
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        usage="%(prog)s [options]",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_connect_options(parser)
    assert len(parser._actions) == 10
    assert isinstance(parser._actions[0], argparse.ArgumentDefaultsHelpFormatter)
    assert parser._actions[0].dest == 'private_key_file'
    assert isinstance(parser._actions[1], argparse.ArgumentDefaultsHelpFormatter)
    assert parser._actions[1].dest == 'remote_user'
    assert isinstance(parser._actions[2], argparse.ArgumentDefaultsHelpFormatter)
    assert parser._actions[2].dest == 'connection'
    assert isinstance

# Generated at 2022-06-10 22:00:16.052405
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser()
    add_check_options(parser)
    options = parser.parse_args()
    assert options.check == False
    assert options.syntax == False
    assert options.diff == C.DIFF_ALWAYS
    options = parser.parse_args('--check --syntax-check --diff'.split())
    assert options.check == True
    assert options.syntax == True
    assert options.diff == True


# Generated at 2022-06-10 22:00:19.807959
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(description='Test add_output_options')
    add_output_options(parser)
    data = parser.parse_args(['-t', 'temp_tree'])
    assert data.tree == 'temp_tree'


# Generated at 2022-06-10 22:00:26.884880
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    help = parser.format_help()
    if not help.startswith('usage: '):
        raise AssertionError('Unexpected help: %s' % help)



# Generated at 2022-06-10 22:00:35.532230
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    parser.add_argument('a_arg')
    options = parser.parse_args("-b -K --become-method foo --become-user bar -K baz".split())
    assert_equal(options.become, True)
    assert_equal(options.become_method, 'foo')
    assert_equal(options.become_user, 'bar')
    assert_equal(options.become_pass, 'baz')
    assert_equal(options.ask_become_pass, True)

# Generated at 2022-06-10 22:00:40.648272
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    base_path = '/path/to/ansible/files'
    assert maybe_unfrack_path("@")("@foo") == base_path + "/foo"
    assert maybe_unfrack_path("@")("not@foo") == "not@foo"



# Generated at 2022-06-10 22:00:43.032089
# Unit test for function add_output_options
def test_add_output_options():
    opt = argparse.ArgumentParser()
    add_output_options(opt)
    opts = opt.parse_args(args="-o -t /tree/path".split())
    assert opts.one_line
    assert opts.tree == "/tree/path"



# Generated at 2022-06-10 22:00:47.352031
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='test')
    add_output_options(parser)
    options = parser.parse_args(args=['-t', './'])
    assert options.tree == './'

# Generated at 2022-06-10 22:00:56.180632
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    from unittest import TestCase
    from unittest.mock import patch
    from ansible.cli import CLI, OPTION_FLAGS
    from ansible.config._parser import ConfigParser

    # mock the config and option parser
    class MockOptionParser:
        def __init__(self, *args, **kwargs):
            self.prog = 'test_ansible'
            self.cwd_path = '/home/bob' #make sure we dont do anything with this path
            self.version = '2.9.2'

            self.config_file_settings = set([])

    # Execute the method under test
    action = AnsibleVersion(option_strings=OPTION_FLAGS, dest='version')


# Generated at 2022-06-10 22:01:01.988461
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_check_options(parser)
    options = parser.parse_args(['-C -D'])
    assert options.check == True
    assert options.syntax == False
    assert options.diff == True

#
# Functions to generate subsets of Options suitable for individual apps
#


# Generated at 2022-06-10 22:01:07.642269
# Unit test for function add_runas_options
def test_add_runas_options():
    options = ['--become', '--become-method', '--become-user']
    for arg in options:
        parser = argparse.ArgumentParser()
        add_runas_options(parser)
        assert any(opt.option_strings == arg for opt in parser._actions), 'add_runas_options() failed to add option ' + arg


# Generated at 2022-06-10 22:01:19.598885
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace(object):
        pass

    n = Namespace
    ensure_value(n, 'foo', 1)
    assert n.foo == 1
    ensure_value(n, 'bar', 2)
    assert n.foo == 1 and n.bar == 2
    ensure_value(n, 'foo', 3)
    assert n.foo == 1 and n.bar == 2


#
# Main option parsers
#

# Generated at 2022-06-10 22:01:23.615523
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(description='Test for add_meta_options')
    add_meta_options(parser)
    options = vars(parser.parse_args())

    assert options['force_handlers'] == C.DEFAULT_FORCE_HANDLERS
    assert options['flush_cache'] == None


# Generated at 2022-06-10 22:01:32.842784
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@home/user') == '@' + unfrackpath('home/user')
    assert maybe_unfrack_path('@')('@/home/user') == '@' + unfrackpath('/home/user')
    assert maybe_unfrack_path('@')('@@home/user') == '@@home/user'
    assert maybe_unfrack_path('@@')('@@home/user') == '@@' + unfrackpath('home/user')
    assert maybe_unfrack_path('@@')('@@/home/user') == '@@' + unfrackpath('/home/user')



# Generated at 2022-06-10 22:01:38.563277
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = '/beacon'
    values = ['~/test', '/foo', beacon + '~/test', beacon + '/foo']
    expected_results = ['~/test', '/foo', '/beacon~/test', '/beacon/foo']
    for i, value in enumerate(values):
        assert maybe_unfrack_path(beacon)(value) == expected_results[i]



# Generated at 2022-06-10 22:01:44.226558
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)('/ansible/foo') == '/ansible/foo'
    assert unfrack_path(pathsep=False)('./ansible/foo') == './.ansible/foo'
    assert unfrack_path(pathsep=True)('.') == ['./.ansible']
    assert unfrack_path(pathsep=True)('') == []


#
# Parsers
#



# Generated at 2022-06-10 22:01:48.491524
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser(prog='ansible-playbook')
    add_meta_options(parser)
    args = parser.parse_args(['--flush-cache'])
    assert args.flush_cache == True



# Generated at 2022-06-10 22:01:50.592436
# Unit test for function ensure_value
def test_ensure_value():
    class Namespace:
        a = None
    namespace = Namespace()
    ensure_value(namespace, 'a', 'b')
    assert namespace.a == 'b'


#
# Option Parser
#

# Generated at 2022-06-10 22:01:54.570783
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/etc') == '@' + unfrackpath('@/etc')[1:]
    assert maybe_unfrack_path('!')('!test') == '!test'



# Generated at 2022-06-10 22:01:59.353623
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    ns = argparse.Namespace()
    setattr(ns, 'dest', [])
    ACTION = PrependListAction('-P', 'dest')
    ACTION(None, ns, [1, 2, 3], None)
    assert getattr(ns, 'dest') == [1, 2, 3]

# Generated at 2022-06-10 22:02:07.859484
# Unit test for function ensure_value
def test_ensure_value():
    import mock
    namespace = mock.Mock()
    # object does not have the attribute
    assert ensure_value(namespace, 'attr1', 'foo') == 'foo'
    setattr.assert_called_with(namespace, 'attr1', 'foo')
    # object has attribute with value None
    setattr.reset_mock()
    namespace.attr2 = None
    assert ensure_value(namespace, 'attr2', 'foo') == 'foo'
    setattr.assert_called_with(namespace, 'attr2', 'foo')
    # object has attribute with existing value
    setattr.reset_mock()
    namespace.attr3 = 'bar'
    assert ensure_value(namespace, 'attr3', 'foo') == 'bar'
    setattr.assert_not_called()

#
# Shared

# Generated at 2022-06-10 22:02:14.384918
# Unit test for function version
def test_version():
    assert version()

#
# Definition of options for AnsibleCli tool
#

# Generated at 2022-06-10 22:02:25.681447
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/a/relative/path') == '/a/relative/path'
    assert unfrack_path()('~/a/relative/path') == '~/a/relative/path'
    assert unfrack_path()('$HOME/a/relative/path') == '$HOME/a/relative/path'
    assert unfrack_path()('/an/absolute/path') == '/an/absolute/path'
    assert unfrack_path()('~/an/absolute/path') == '~/an/absolute/path'
    assert unfrack_path()('$HOME/an/absolute/path') == '$HOME/an/absolute/path'


# Generated at 2022-06-10 22:02:33.194087
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # beacon surrounded by absolute path
    assert maybe_unfrack_path('@')('@/absolute/path') == '@' + unfrackpath('/absolute/path')
    # beacon surrounded by relative path (with a leading '/')
    assert maybe_unfrack_path('@')('@./relative/path') == '@' + unfrackpath('./relative/path')
    # beacon surrounded by relative path (with two leading './')
    assert maybe_unfrack_path('@')('@././relative/path') == '@' + unfrackpath('././relative/path')
    # beacon surrounded by relative path (with a leading '../')
    assert maybe_unfrack_path('@')('@../relative/path') == '@' + unfrackpath('../relative/path')
    #

# Generated at 2022-06-10 22:02:44.368113
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # During testing we use a different argument parsing module to avoid
    # polluting the global namespace
    class TestingParsingModule(argparse.ArgumentParser):
        def error(self, message):
            raise Exception(message)

    argument_parser = TestingParsingModule()
    argument_parser.add_argument('--test', action=PrependListAction, nargs='+')
    namespace = argparse.Namespace(test=[])
    argument_parser.parse_args(['--test', '1'], namespace)
    assert namespace.test == ['1']
    argument_parser.parse_args(['--test', '2'], namespace)
    assert namespace.test == ['2', '1']
    argument_parser.parse_args(['--test', '3', '4'], namespace)

# Generated at 2022-06-10 22:02:51.347758
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("@")("@/tmp/test") == "@" + unfrackpath("/tmp/test")
    assert maybe_unfrack_path("@")("/tmp/test") == "/tmp/test"
    assert maybe_unfrack_path("@")("@.") == "@" + unfrackpath(".")
    assert maybe_unfrack_path("@")(".") == "."
#


# Generated at 2022-06-10 22:02:55.331671
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = None
    namespace = None
    values = None
    action = AnsibleVersion(option_strings=[])
    action.__call__(parser=parser, namespace=namespace, values=values)
    sys.stdout.seek(0)
    assert sys.stdout.read() == 'ansible %s\n' % __version__



# Generated at 2022-06-10 22:03:00.889020
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("{{mypath}}") == os.path.join("~", ".ansible", "mypath")
    assert unfrack_path()("{{mypath}}:{{ oneside }}") == os.path.join("~", ".ansible", "mypath")



# Generated at 2022-06-10 22:03:07.304263
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    p = argparse.ArgumentParser()
    p.add_argument('-ns', action=PrependListAction, nargs='*')
    options = p.parse_args('-ns a'.split())
    assert options.ns == ['a']
    options = p.parse_args('-ns a b'.split())
    assert options.ns == ['a', 'b']

    options = p.parse_args('-ns a --ns b'.split())
    assert options.ns == ['a', 'b']
    options = p.parse_args('-ns a -ns b'.split())
    assert options.ns == ['a', 'b']



# Generated at 2022-06-10 22:03:11.107848
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument = Mock(return_value=None)
    AnsibleVersion()(parser, None, None)
    assert parser.add_argument.called


# Generated at 2022-06-10 22:03:18.513930
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-test'
    parser.add_argument('--ansible-version', nargs=0, action=AnsibleVersion)
    args = parser.parse_args(['--ansible-version'])

#
# General purpose Options
#
parser = argparse.ArgumentParser(
    formatter_class=SortingHelpFormatter,
    usage='%(prog)s <host-pattern> [options]',
    epilog="For more information, please visit https://docs.ansible.com/ansible/")



# Generated at 2022-06-10 22:03:31.815625
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser(prog="test")
    parser.add_argument("-e", dest="env", action=PrependListAction, nargs="+")
    args, remaining_args = parser.parse_known_args(["-e", "one", "-e", "two"])
    assert args.env == ['two', 'one']
    args, remaining_args = parser.parse_known_args(["-e", "one"])
    assert args.env == ['one']



# Generated at 2022-06-10 22:03:36.767169
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # import os
    # from ansible.cli import CLI
    #
    # os.sys.argv = [os.sys.argv[0], '--version']
    # cli = CLI()
    # cli.run()
    # assert True
    pass


# Generated at 2022-06-10 22:03:49.727427
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    import inspect
    from collections import namedtuple

    # Get a list of all the options
    opts = namedtuple('Options', [o.dest for o in CLICommand.base_parser.option_list])(*[None] * len(CLICommand.base_parser.option_list))

    # Set the values to known values, that will be changed
    opts.roles_path = '-/.ansible/roles'
    opts.inventory = '@x'

    # Call the functions
    opts.roles_path = unfrack_path(pathsep=True)(opts.roles_path)
    opts.inventory = maybe_unfrack_path('@')(opts.inventory)

    # Check that the functions did what we wanted

# Generated at 2022-06-10 22:04:02.026294
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/foo') == '/tmp/foo'
    assert unfrack_path(True)('/tmp/foo:/tmp/bar') == ['/tmp/foo', '/tmp/bar']
    assert unfrack_path()('/tmp/foo:/tmp/bar') == '/tmp/foo:/tmp/bar'

    # assert unfrack_path()('~/foo') == os.path.expanduser('~/foo')
    # assert unfrack_path()('~root/foo') == '/root/foo'
    # assert unfrack_path()('~nobody/foo') == None

    # assert unfrack_path()('$HOME/foo') == os.path.expanduser('~/foo')
    # assert unfrack_path()('$FOO/foo') == os.environ.get('FOO',

# Generated at 2022-06-10 22:04:05.367749
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("a")("a/b") == "a/b"
    assert maybe_unfrack_path("a")("a/b") != "a/B"



# Generated at 2022-06-10 22:04:10.743982
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/fred') == '/tmp/fred'
    assert unfrack_path()('/tmp/fred:/tmp/barney') == '/tmp/fred:/tmp/barney'
    assert unfrack_path(True)('/tmp/fred:/tmp/barney') == ['/tmp/fred', '/tmp/barney']



# Generated at 2022-06-10 22:04:15.250830
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__(): # noqa: E302
    parser = argparse.ArgumentParser()

    action = AnsibleVersion(option_strings=['--version'])
    assert action.__call__(parser=parser, namespace=None, values=None, option_string=None) is None
    assert hasattr(parser, 'exit')

# Generated at 2022-06-10 22:04:22.250212
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    from ansible.utils.display import Display
    display = Display()

    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)

    parser.add_argument('--y', action="store_true", help="foo")
    parser.add_argument('-z', action="store_true", help="bar")
    parser.add_argument('--foo', action="store_true", help="baz")

    out = parser.format_help().rstrip()
    display.display(out, screen_only=True)
    assert out == '''\
usage: \
[-h] [--foo] [-y] [-z]

optional arguments:
  -h, --help   show this help message and exit
  --foo        baz
  -y           foo
  -z           bar'''
# /

# Generated at 2022-06-10 22:04:27.242966
# Unit test for function version
def test_version():
    assert __version__ in version()
    assert len(version().split('\n')) == 10
    # test executable location for a different function location
    __test_version = version
    def version():
        return __test_version('test_version')
    assert '/test_version' in version()

# Generated at 2022-06-10 22:04:34.484692
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/foo/bar') == '@/foo/bar'
    assert maybe_unfrack_path('@')('@/foo/bar') == '@/foo/bar'
    assert maybe_unfrack_path('@')('/foo/bar') == '/foo/bar'
    assert maybe_unfrack_path('@')('@.') == '@.'


# Generated at 2022-06-10 22:04:50.329966
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """Make sure the function maybe_unfrack_path is operating properly."""
    beacon = '@'
    check_paths = [
        # path, expected
        ['@/etc/ansible/', '@/etc/ansible/'],
        ['@.', '@./'],
        ['@./', '@./'],
        ['@/../../file', '@/../../file'],
        ['/etc/ansible/', '/etc/ansible/'],
        ['.', './'],
        ['./', './'],
        ['/../../file', '/../../file'],
    ]
    for path, expected in check_paths:
        actual = maybe_unfrack_path(beacon)(path)
        assert expected == actual



# Generated at 2022-06-10 22:04:56.236738
# Unit test for function unfrack_path
def test_unfrack_path():
    os.environ["A2_LOCALCALL_PATH"] = "/opt/ansible"
    os.environ["A2_LOCALCALL_PLUGINS"] = "/opt/ansible/plugins"
    os.environ["A2_LOCALCALL_PLUGIN_PATHS"] = "/opt/ansible/plugins/modules:/opt/ansible/plugins/lookup"
    os.environ["A2_LOCALCALL_ACTION_PLUGINS"] = "/opt/ansible/plugins/actions"
    os.environ["A2_LOCALCALL_CACHE"] = "/opt/ansible/.ansible/cache"
    os.environ["A2_LOCALCALL_DATA"] = "/opt/ansible/data"

# Generated at 2022-06-10 22:05:06.549027
# Unit test for function ensure_value
def test_ensure_value():
    class pnamespace(object):
        def __init__(self):
            self.attribs = {}

        def __getattr__(self, attrib):
            return self.attribs.get(attrib)

        def __setattr__(self, attrib, value):
            if attrib == 'attribs':
                super(pnamespace, self).__setattr__(attrib, value)
            else:
                self.attribs[attrib] = value

    class pargs():
        def __init__(self):
            self.one = None
            self.two = None
            self.three = None

    ar = pargs()
    assert ar.one is None
    assert ar.two is None
    assert ar.three is None

    # ensure that ensure_value behaves as expected
    # create a

# Generated at 2022-06-10 22:05:16.241579
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Ensure that a value is set on a namespace, even if the namespace already
    # exists and already has a value set.
    #
    # namespace: The namespace to set a value on
    # name: The name of the value to set
    # default_value: The default value to use if the namespace already has name
    #   set.
    def ensure_value(namespace, name, default_value):
        if not hasattr(namespace, name):
            setattr(namespace, name, default_value)
        return getattr(namespace, name)

# Generated at 2022-06-10 22:05:20.639817
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version_str = version('/usr/bin/ansible-console')
    assert version_str.startswith(b'ansible-console ')
    assert version_str.endswith(b'\n')



# Generated at 2022-06-10 22:05:26.238160
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Return value when beacon is at the beginning of the string
    value = '@foo'
    assert maybe_unfrack_path('@')(value) == '@' + unfrackpath('foo')

    # Return value when beacon is not at the beginning of the string
    value = 'foo'
    assert maybe_unfrack_path('@')(value) == 'foo'



# Generated at 2022-06-10 22:05:28.301342
# Unit test for function unfrack_path
def test_unfrack_path():
    """ Return the passed value if it is a single hypen, else perform unfrack_path on it """
    assert unfrack_path()('foo') == unfrackpath('foo')

# Generated at 2022-06-10 22:05:33.911330
# Unit test for function ensure_value
def test_ensure_value():
    ns = argparse.Namespace()
    ensure_value(ns, 'foo', 'bar')
    assert ns.foo == 'bar'

    ensure_value(ns, 'foo', 'baz')
    assert ns.foo == 'bar'



# Generated at 2022-06-10 22:05:44.730024
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    # Create an instance of PrependListAction with nargs=1
    test_case = PrependListAction(option_strings=[], dest='test', nargs=1,
                                  const=None, default=None, required=False)
    # Test default attribute values
    assert test_case.option_strings == []
    assert test_case.dest == 'test'
    assert test_case.nargs == 1
    assert test_case.const is None
    assert test_case.default is None
    assert test_case.required is False
    # Test attribute values set by constructor
    assert test_case.help == argparse.SUPPRESS
    assert test_case.metavar is None
    assert test_case.type == None
    assert test_case.choices is None
    assert test_case.default is None
    assert test_case

# Generated at 2022-06-10 22:05:53.774078
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path_paths = ['/foo', '../foo', '/bar/../foo', '~/foo', 'bar', './bar', './foo//bar']
    unfrack_path_expected = ['foo', 'foo', 'foo', 'foo', 'bar', 'bar', 'foo/bar']

    for path, expected in zip(unfrack_path_paths, unfrack_path_expected):
        result = unfrack_path()(path)
        assert result == expected, "For path %s expected %s, got %s" % (path, expected, result)



# Generated at 2022-06-10 22:06:06.886444
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', action=AnsibleVersion)
    argv_orig = copy.copy(sys.argv)
    sys.argv = ['prog', '-v']
    args = parser.parse_args()
    sys.argv = argv_orig


#
# Parser factories
#

# Generated at 2022-06-10 22:06:13.509217
# Unit test for function unfrack_path
def test_unfrack_path():
    def inner_test(test, expected, pathsep):
        assert test == expected

# Generated at 2022-06-10 22:06:24.661042
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = ['--deprecated']
    dest = 'deprecated'
    nargs = 0
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = None
    metavar = None
    parser = MockArgumentParser()
    namespace = MockNamespace()
    values = ['value']
    option_string = '--deprecated'
    pa = PrependListAction(option_strings=option_strings, dest=dest, nargs=nargs, const=const, default=default, type=type,
                        choices=choices, required=required, help=help, metavar=metavar)
    pa(parser=parser, namespace=namespace, values=values, option_string=option_string)

# Generated at 2022-06-10 22:06:27.771811
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--version', action=AnsibleVersion)
    args = parser.parse_args(['--version'])
    assert args.version == False



# Generated at 2022-06-10 22:06:29.164347
# Unit test for function unfrack_path
def test_unfrack_path():
    # This test is skipped because the function depends on ansible.utils.path.unfrackpath
    pass



# Generated at 2022-06-10 22:06:30.456064
# Unit test for function unfrack_path
def test_unfrack_path():
    print(unfrack_path())
    print(unfrack_path(True))


# Generated at 2022-06-10 22:06:35.128319
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action=PrependListAction)
    # sanity check
    args = parser.parse_args(['--test', 'foo', '--test', 'bar'])
    assert args.test == ['foo', 'bar']
    # prepends
    args = parser.parse_args(['--test', 'baz', '--test', 'foo', '--test', 'bar'])
    assert args.test == ['baz', 'foo', 'bar']



# Generated at 2022-06-10 22:06:39.323285
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    file_path = '../../test'
    result = maybe_unfrack_path('@')('@'+file_path)
    assert result == '@../../test'
    result = maybe_unfrack_path('@')(file_path)
    assert result == file_path



# Generated at 2022-06-10 22:06:48.758929
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@test/config.yml') == '@/tmp/config.yml'
    assert maybe_unfrack_path('/')('@test/config.yml') == '@test/config.yml'
    assert maybe_unfrack_path('$')('$@test/config.yml') == '$@/tmp/config.yml'
    assert maybe_unfrack_path('$')('@test/config.yml') == '@test/config.yml'
    assert maybe_unfrack_path('/')('/dev/null') == '/dev/null'
    assert maybe_unfrack_path('@')('@/dev/null') == '@/dev/null'



# Generated at 2022-06-10 22:06:54.454792
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', dest='version', action=AnsibleVersion, nargs=0, help="Print version and exit")
    args = parser.parse_args(['--version'])
    # Return code is 0
    assert args is not None


# Generated at 2022-06-10 22:07:14.083616
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'foo'
    ao = AnsibleVersion(option_strings='-foo', dest='version')
    ao(parser, {}, 'foo')



# Generated at 2022-06-10 22:07:18.130755
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    """
    Test method __call__ of class AnsibleVersion
    """
    parser = None
    namespace = None
    values = None
    option_string = None
    ansible_version = AnsibleVersion()
    ansible_version.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-10 22:07:19.764417
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    sut = SortingHelpFormatter()
    None


#
# Method to get an OptionParser instance for collecting CLI options
#

# Generated at 2022-06-10 22:07:29.602828
# Unit test for function version
def test_version():
    assert version('test') == \
           'test [core %s]\n  config file = %s\n  configured module search path = %s\n  ansible python module location = %s\n  ansible collection location = %s\n  executable location = %s\n  python version = %s\n  jinja version = %s\n  libyaml = %s'\
           % (__version__, C.CONFIG_FILE, ':'.join(C.DEFAULT_MODULE_PATH), ':'.join(ansible.__path__), ':'.join(C.COLLECTIONS_PATHS), sys.argv[0], ''.join(sys.version.splitlines()), j2_version, HAS_LIBYAML)



# Generated at 2022-06-10 22:07:31.902159
# Unit test for function version
def test_version():
    """unit test for function version"""
    assert isinstance(version(), str)

# Generated at 2022-06-10 22:07:41.978555
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible import context
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    parser = argparse.ArgumentParser()
    parser.add_argument('--tags', action=PrependListAction)
    args = parser.parse_args(['-vvv'])
    context.CLIARGS = args
    assert args.tags[0] == '-vvv'
    context.CLIARGS = None
    display = Display()
    variables = combine_vars(loader=None, variables={})
    assert isinstance(variables, dict)


# Generated at 2022-06-10 22:07:46.453901
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    class FakeParser(object):
        def __init__(self, exit_code, version):
            self.exit_code = exit_code
            self.prog = version

        def exit(self):
            sys.exit(self.exit_code)

    ver = AnsibleVersion(None, None, None)
    try:
        ver(FakeParser(0, 'ansible-playbook'), None, None, None)
    except SystemExit as e:
        assert e.code == 0

    try:
        ver(FakeParser(1, 'ansible-playbook'), None, None, None)
    except SystemExit as e:
        assert e.code == 1


# Generated at 2022-06-10 22:07:56.454975
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("/a/path") == unfrackpath("/a/path")
    assert unfrack_path(pathsep=True)("/a/path:other/path") == [unfrackpath("/a/path"), unfrackpath("other/path")]
    assert unfrack_path(pathsep=True)("/a/path::") == [unfrackpath("/a/path"), unfrackpath("")]
    assert unfrack_path(pathsep=True)("/a/path:") == [unfrackpath("/a/path")]
    assert unfrack_path(pathsep=True)("/a/path::/a/path") == [unfrackpath("/a/path"), unfrackpath(""), unfrackpath("/a/path")]



# Generated at 2022-06-10 22:07:59.991423
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_string = '-t'
    namespace_dest = 'myList'
    values = [1, 2]
    p = argparse.ArgumentParser()
    p.add_argument(option_string, dest=namespace_dest, action=PrependListAction, default=[])
    #print(vars(p.parse_args([option_string, '1', '2', option_string, '3', '4'])))
    # Should produce {'myList': [1, 2, 3, 4]}



# Generated at 2022-06-10 22:08:04.070720
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(description="Unit testing for AnsibleVersion class")
    parser.add_argument('--version', action=AnsibleVersion)
    parser.prog = "ansible-test"
    args = parser.parse_args(['--version'])
# End test for method __call__ of class AnsibleVersion

