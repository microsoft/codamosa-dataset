

# Generated at 2022-06-24 17:34:23.778999
# Unit test for function add_async_options
def test_add_async_options():
    tp_0 = argparse.ArgumentParser()
    tp_1 = argparse.ArgumentParser()
    tp_2 = argparse.ArgumentParser()
    tp_3 = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    tp_4 = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    tp_5 = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    tp_6 = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    tp_7 = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    tp_8 = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    tp_9 = arg

# Generated at 2022-06-24 17:34:27.345276
# Unit test for function add_connect_options
def test_add_connect_options():
    var_0 = create_base_parser('test',desc='test')
    add_connect_options(var_0)
    var_0.parse_args(["-c", "default", "-u", "root", "-k", "y"])


# Generated at 2022-06-24 17:34:30.438278
# Unit test for function add_vault_options
def test_add_vault_options():
    a = argparse.ArgumentParser()
    add_vault_options(a)


# Generated at 2022-06-24 17:34:37.190315
# Unit test for function add_runas_options
def test_add_runas_options():
    cmd = 'command'
    desc = 'description'
    epilog = 'epilog'
    parser = create_base_parser(cmd, desc, epilog)
    add_runas_options(parser)
    arguments = ['-b']
    options = parser.parse_args(arguments)
    assert options.become == True


# Generated at 2022-06-24 17:34:38.790117
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    
    # Argument count does not match what we are testing here
    assert 1 == test_case_0()

# Generated at 2022-06-24 17:34:42.692419
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # Set up test case
    # Arrange
    var_0 = None
    # Act
    argparser = create_base_parser('ansible-playbook')
    add_inventory_options(argparser)
    # Assert
    assert argparser.add_argument('-i', '--inventory', '--inventory-file', dest='inventory', action="append",
                                  help="specify inventory host path or comma separated host list. --inventory-file is deprecated")



# Generated at 2022-06-24 17:34:44.592556
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)



# Generated at 2022-06-24 17:34:48.417844
# Unit test for function add_connect_options
def test_add_connect_options():
    try:
        print(unit_test_0)
    except NameError:
        print("Unable to find unit_test_0")
    else:
        unit_test_0()


# Generated at 2022-06-24 17:34:50.224587
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert("~" == maybe_unfrack_path("~")("~/"))


# Generated at 2022-06-24 17:34:55.096610
# Unit test for function add_fork_options
def test_add_fork_options():
    parser = create_base_parser()
    add_fork_options(parser)
    opts = parser.parse_args(['--forks', '10'])
    assert opts.forks == 10



# Generated at 2022-06-24 17:35:18.294414
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(
        prog="ansible-playbook",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_check_options(parser)
    return parser

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:35:22.377052
# Unit test for function add_output_options
def test_add_output_options():
    print(test_case_0.__name__)
    try:
        test_case_0()
    except Exception as e:
        print(e)
        return 1

    try:
        parser = argparse.ArgumentParser(
            prog='program',
            formatter_class=SortingHelpFormatter,
            epilog=None,
            description=None,
            conflict_handler='resolve',
        )
        add_output_options(parser)
        args = parser.parse_args(['-o', '--one-line'])
        print(args)
        print(args.one_line)
        print(parser.format_help())
    except Exception as e:
        print(e)
        return 1

    return 0


# Generated at 2022-06-24 17:35:33.702192
# Unit test for function unfrack_path
def test_unfrack_path():

    opt = Option('value', 'dest', type='str', callback=unfrack_path())
    opt.process('value', None, {})
    assert opt.value == unfrackpath('value')
    assert opt.dest == 'dest'
    assert opt.type == 'str'

    opt = Option('value', 'dest', type='str', callback=unfrack_path(True))
    opt.process('value1' + os.pathsep + 'value2', None, {})
    assert opt.value == [unfrackpath('value1'), unfrackpath('value2')]
    assert opt.dest == 'dest'
    assert opt.type == 'str'



# Generated at 2022-06-24 17:35:35.148411
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = version()

#
# Option groups of Arguments
#

# Generated at 2022-06-24 17:35:38.519151
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('~/ansible')
    assert type(var_0) == types.FunctionType, "maybe_unfrack_path is not a function type"
    var_1 = var_0('~/ansible/./devel')
    assert str(var_1) == '~/ansible/./devel', "Failed to run maybe_unfrack_path"


# Generated at 2022-06-24 17:35:46.850301
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()


#
# Options for argparse to use
#

# Options common to all Ansible applications

_COMMON_ARGS = (
    dict(
        dest='version',
        action='version',
        version=ansible_version,
        help='shows the Ansible version and exit',
    ),

    dict(
        dest='verbosity',
        default=0,
        type=int,
        choices=(0, 1, 2),
        metavar='<0-2>',
        help='verbose level (default=0)',
    ),
)



# Generated at 2022-06-24 17:35:49.423722
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()


# Test: run test_case_0

# Generated at 2022-06-24 17:35:53.888386
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = version()
    pathsep = False
    def inner(value):
        if pathsep:
            return [unfrackpath(x) for x in value.split(os.pathsep) if x]
        if value == '-':
            return value
        return unfrackpath(value)
    return inner

# Generated at 2022-06-24 17:35:59.911675
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test with the default value of pathsep
    res = unfrack_path()
    try:
        assert res == None
    except AssertionError as e:
        print(res)


#
# Special purpose callbacks for use in OptionParser.add_option()
#

# Generated at 2022-06-24 17:36:01.731019
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(
        prog="test",
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_module_options(parser)
    parser.parse_args(['-M', 'my_module_path'])


# Generated at 2022-06-24 17:36:41.571725
# Unit test for function add_basedir_options
def test_add_basedir_options():
    with pytest.raises(SystemExit):
        parser = argparse.ArgumentParser(prog='ansible-playbook')
        add_basedir_options(parser)
        args = parser.parse_args()
        args.func(args)
        test_case_0()


# Generated at 2022-06-24 17:36:43.295454
# Unit test for function unfrack_path
def test_unfrack_path():
    path = '/etc/ansible'
    function_result = unfrackpath(path)
    assert function_result == path


# Generated at 2022-06-24 17:36:46.029778
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser()
    add_basedir_options(parser)


# Generated at 2022-06-24 17:36:47.828377
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path() != "ansible-playbook"



# Generated at 2022-06-24 17:36:52.482260
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(
        prog=sys.argv[0],
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_output_options(parser)



# Generated at 2022-06-24 17:36:57.278337
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:37:01.513881
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    s = SortingHelpFormatter()
    assert s.indent_increment == 2
    assert s.max_help_position == 24



# Generated at 2022-06-24 17:37:04.243315
# Unit test for function unfrack_path
def test_unfrack_path():
    parser = MockArgParser()
    result = unfrack_path(parser)
    assert result == None


# Generated at 2022-06-24 17:37:07.694334
# Unit test for function add_basedir_options
def test_add_basedir_options():
    """
    Test add_basedir_options
    """
    # setUp
    parser = create_base_parser("test")
    # Test
    add_basedir_options(parser)
    # tearDown
    print(parser)

# Generated at 2022-06-24 17:37:16.253822
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 =['~/../dev///', '/home/../home//dev/', '/../../home']
    new_var_1 = [maybe_unfrack_path('~')('~/../dev///'), maybe_unfrack_path('~')('/home/../home//dev/'), maybe_unfrack_path('~')('/../../home')]
    assert(var_1 == new_var_1)


# Generated at 2022-06-24 17:37:40.153325
# Unit test for function unfrack_path
def test_unfrack_path():
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--path", dest="paths",
                        help="path", metavar="PATH", action="append",
                        type=unfrack_path(pathsep=True))
    args = parser.parse_args()
    # Test unfrack_path() in single path mode
    args.paths = unfrack_path()("/path/to/something")
    if args.paths != "/path/to/something":
        raise Exception("unfrack_path() failed! Expected: {0}, Actual: {1}".format("/path/to/something", args.paths))
    # Test unfrack_path() in multiple path mode

# Generated at 2022-06-24 17:37:52.860846
# Unit test for function unfrack_path
def test_unfrack_path():
    var1 = 'myhost'
    var2 = 15
    var3 = './myhost/home/'
    var4 = 1
    var5 = '#'
    var6 = '#'
    var7 = '#'
    var8 = 1
    var9 = './myhost/home/'
    var10 = '#'
    var11 = '#'
    var12 = 15
    var13 = 'd:/'
    var14 = 1
    var15 = '#'
    var16 = './myhost/home/'
    var17 = '#'
    var18 = 15
    var19 = 1
    var20 = '../test'
    var21 = 0
    var22 = './myhost/home/'
    var23 = '#'
    var24 = '#'


# Generated at 2022-06-24 17:37:54.427691
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()


# Generated at 2022-06-24 17:38:00.905405
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path(beacon='/')
    assert callable(var_0)
    var_1 = var_0(value='/s')
    assert (var_1 == '/s')


# Generated at 2022-06-24 17:38:02.343000
# Unit test for function unfrack_path
def test_unfrack_path():
    unfrack_path()


# Generated at 2022-06-24 17:38:06.257485
# Unit test for function unfrack_path
def test_unfrack_path():
    # var/function name
    var_0 = unfrack_path()

    # var/function reference
    ref_0 = [unfrackpath(x) for x in var_0.split(os.pathsep) if x]

    # Test
    assert ref_0 == var_0


# Generated at 2022-06-24 17:38:09.686157
# Unit test for function unfrack_path
def test_unfrack_path():
    var_a = unfrack_path()
    return var_a


# Generated at 2022-06-24 17:38:13.913563
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = "~/Ansible/ansible"
    beacon = '~'
    res = maybe_unfrack_path(beacon)
    assert res(path) == path


# Generated at 2022-06-24 17:38:15.997958
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path("-")


# Generated at 2022-06-24 17:38:20.231902
# Unit test for function add_output_options
def test_add_output_options():
    # Initialize parser
    parser = create_base_parser('usage', 'description', 'epilog')
    # Add option to parser
    add_output_options(parser)
    # Capture output of parser.print_help()
    buf = io.StringIO()
    with redirect_stdout(buf):
        parser.print_help()
    # Check if "--one-line" option is in the output
    assert re.search(r'-o\s+--one-line', buf.getvalue()) is not None
    # Check if "--tree" option is in the output
    assert re.search(r'-t\s+--tree', buf.getvalue()) is not None


# Generated at 2022-06-24 17:38:38.883823
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('~')
    var_1 = var_0('~')
    assert var_1 == '~'
    var_2 = var_0('~/ansible/contrib')
    assert var_2 == '~/ansible/contrib'


# Generated at 2022-06-24 17:38:49.072368
# Unit test for function unfrack_path
def test_unfrack_path():
    print("unfrack_path")
    path = "/path/to/file"
    unfrack_path(path)
    try:
        assert unfrack_path(path) == "/path/to/file"
    except:
        e = sys.exc_info()[0]
        print("<p>Error: %s</p>" % e)


    path = "~/path/to/file"
    unfrack_path(path)
    try:
        assert unfrack_path(path) == "/home/list/path/to/file"
    except:
        e = sys.exc_info()[0]
        print("<p>Error: %s</p>" % e)

    path = "/path/to/dir/"
    unfrack_path(path)

# Generated at 2022-06-24 17:38:50.119525
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():

    test_case_0()

# Generated at 2022-06-24 17:38:52.005237
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)
    assert unfrack_path() == inner


# Generated at 2022-06-24 17:38:53.985264
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print(maybe_unfrack_path(''))
    sys.exit(0)


# Generated at 2022-06-24 17:38:57.482760
# Unit test for function unfrack_path
def test_unfrack_path():
    os.path.exists = MagicMock(return_value=True)
    assert(unfrack_path('test_path') == 'test_path')
    # assert(unfrack_path('test_path') == 'test_path')


# Generated at 2022-06-24 17:39:00.149150
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)
    var_0 = version()


# Generated at 2022-06-24 17:39:05.960566
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Instantiate SortingHelpFormatter class
    # var_0 = SortingHelpFormatter()
    tests = [
        # TODO:
        # (expected, inputs)
    ]
    for expected, inputs in tests:
        with pytest.raises(expected) as excinfo:
            var_0 = SortingHelpFormatter()
    # void return


# Generated at 2022-06-24 17:39:10.124750
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('.') == unfrackpath('.')
    assert unfrack_path()('/tmp') == unfrackpath('/tmp')
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path()('-') == '-'

#
# Returns the version of Ansible as a string
#

# Generated at 2022-06-24 17:39:19.868937
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Locally disable the pylint check for useless-object-inheritance
    # pylint: disable=useless-object-inheritance
    class test_object(object):
        """This is a test class that mimics the argparse.Action class"""
        # pylint: disable=too-few-public-methods
        def __init__(self, option_strings, dest, nargs=None, const=None,
                     default=None, type=None, choices=None, required=False,
                     help=None, metavar=None):
            self.option_strings = option_strings
            self.dest = dest
            self.nargs = nargs
            self.const = const
            self.default = default
            self.type = type
            self.choices = choices
            self.required = required
            self

# Generated at 2022-06-24 17:39:38.656480
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path("test")
    assert var_0("~test") == "test~test"


# Generated at 2022-06-24 17:39:41.951597
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('beacon_0')
    var_1 = maybe_unfrack_path('beacon_1')


# Generated at 2022-06-24 17:39:44.583890
# Unit test for function unfrack_path
def test_unfrack_path():
    print("test 1")
    test_case_0()


#
# Main OptionParser code
#

# Generated at 2022-06-24 17:39:47.459090
# Unit test for function unfrack_path
def test_unfrack_path():
    assert getattr(constants, "_ANSIBLE_ARGS", None) is not None, "constants._ANSIBLE_ARGS must not be None"
    assert constants._ANSIBLE_ARGS == [], "constants._ANSIBLE_ARGS must be empty"
    assert len(constants._ANSIBLE_ARGS) == 0, "constants._ANSIBLE_ARGS must be empty"
    test_case_0()

import json


# Generated at 2022-06-24 17:39:54.276708
# Unit test for function unfrack_path
def test_unfrack_path():
    path = os.path.expanduser('~').replace(':', '')
    expected = [os.path.expanduser('~')]
    actual = unfrack_path(True)(path)
    assert actual == expected, 'actual: %s, expected: %s' % (actual, expected)
test_case_0()

#
# Parser Factories
#

# Generated at 2022-06-24 17:39:56.067941
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()
    var_2 = maybe_unfrack_path()



# Generated at 2022-06-24 17:39:57.596144
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = unfrack_path(True)


# Generated at 2022-06-24 17:39:58.730487
# Unit test for function version
def test_version():
    assert version() is not None


# Generated at 2022-06-24 17:40:10.942632
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    output = maybe_unfrack_path("value")
    assert maybe_unfrack_path('value') == output, 'Expected might_unfrack_path("value") = {}, but got: {}'.format(maybe_unfrack_path('value'), output)
    assert maybe_unfrack_path("value") == "value", 'Expected might_unfrack_path("value") = {}, but got: {}'.format("value", output)
    assert maybe_unfrack_path("value") == "value", 'Expected might_unfrack_path("value") = {}, but got: {}'.format("value", output)


# Generated at 2022-06-24 17:40:13.297368
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_0 = SortingHelpFormatter()


# Generated at 2022-06-24 17:40:46.345585
# Unit test for function unfrack_path
def test_unfrack_path():
    assert func_0('/') == '/'

#
# Custom Parsers for Options
#

# Generated at 2022-06-24 17:40:53.107481
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = "C:\\"
    var_1 = "C:\\Users\\"
    var_2 = "C:\\Users\\Jared\\"
    var_3 = "C:\\Users\\Jared\\Anaconda3\\"
    var_4 = "C:\\Users\\Jared\\Anaconda3\\envs\\"
    var_5 = "C:\\Users\\Jared\\Anaconda3\\envs\\py36\\"
    var_6 = "C:\\Users\\Jared\\Anaconda3\\envs\\py36\\Scripts\\"
    var_7 = "C:\\Users\\Jared\\Anaconda3\\envs\\py36\\Scripts\\ansible-config-Settings.ini"

# Generated at 2022-06-24 17:40:57.412876
# Unit test for function unfrack_path
def test_unfrack_path():
    assert ('/etc/ansible' == unfrack_path()('/etc/ansible'))
    assert ('/etc/ansible/hosts' == unfrack_path()('/etc/ansible/hosts'))
    assert ('/etc/ansible/hosts' == unfrack_path()('hosts'))
    assert ('/etc/ansible/hosts' == unfrack_path()('/etc/ansible/hosts'))
    assert ('/etc/ansible/hosts' == unfrack_path()('/etc/ansible/hosts'))



# Generated at 2022-06-24 17:41:01.933640
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)("a/b/c") == ["a/b/c"]


# Generated at 2022-06-24 17:41:06.825978
# Unit test for function version
def test_version():
    # No program name
    v = version(prog="")

# Generated at 2022-06-24 17:41:10.206992
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path(beacon='-')

    assert  isinstance(var_0, type(unfrack_path()))



# Generated at 2022-06-24 17:41:13.552568
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()


# Generated at 2022-06-24 17:41:19.958510
# Unit test for function unfrack_path
def test_unfrack_path():

    # Setup
    pathsep = False
    expected = 'expected'
    expected__pathsep_false = expected

    # Mocking a class
    class MockValue(object):
        pass
    value = MockValue()
    value.split = Mock(return_value=[expected])

    # Invoke the function
    actual = unfrack_path(pathsep)(value)

    # Verify the results
    assert expected__pathsep_false == actual



# Generated at 2022-06-24 17:41:21.818525
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("") == ' '


# Generated at 2022-06-24 17:41:30.552031
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    print(" SortingHelpFormatter() ", end="")
    hf = SortingHelpFormatter()

    # add arguments
    actions = ["action_0", "action_1", "action_2"]
    actions = sorted(actions, key=operator.attrgetter('option_strings'))
    # super(SortingHelpFormatter, self).add_arguments(actions)
    SortingHelpFormatter.add_arguments(actions)

#
# Main test driver routine
#
if __name__ == "__main__":
    # Perform setup
    (var_0, var_1) = setup()
    # Begin testing
    test_case_0()
    # Perform teardown
    (var_0, var_1) = teardown()
else:
    pass

# Generated at 2022-06-24 17:42:46.166883
# Unit test for function version
def test_version():
    assert 'ansible-test [core 2.10.0]' in version('ansible-test')
    assert 'config file = /dev/null' in version()

# Generated at 2022-06-24 17:42:48.421534
# Unit test for function unfrack_path
def test_unfrack_path():
    assert isinstance(unfrack_path(), types.FunctionType)


# Generated at 2022-06-24 17:42:49.409274
# Unit test for function unfrack_path
def test_unfrack_path():
    assert var_0==None

test_case_0()


# Generated at 2022-06-24 17:42:55.392532
# Unit test for function unfrack_path
def test_unfrack_path():
    path = "/a/b/c"
    assert unfrack_path()(path) == os.path.abspath(path)
    assert unfrack_path(pathsep = True)(path) == os.path.abspath(path)

# Disable pylint because it doesn't recognize the callback decorator
# pylint: disable=unused-argument

# Generated at 2022-06-24 17:42:58.990868
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:43:07.538741
# Unit test for function unfrack_path
def test_unfrack_path():
    if not HAS_LIBYAML:
        parser = argparse.ArgumentParser(description='test_unfrack_path')
        parser.add_argument('--extra-vars', dest='extra_vars', type=unfrack_path(), default=[],
        action=PrependListAction, metavar='var_name=value', help='set additional variables as key=value or YAML/JSON',
        )
        args = parser.parse_args()
        print(args.extra_vars)


# Generated at 2022-06-24 17:43:10.592694
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("beacon")("beacon/") == "beacon/home/sleven/.ansible"

#
# Internal Helpers
#

# Generated at 2022-06-24 17:43:24.090501
# Unit test for function unfrack_path
def test_unfrack_path():
    assert os.path.normpath(unfrack_path()('/usr/bin/')) == os.path.normpath('/usr/bin/')
    assert os.path.normpath(unfrack_path()('/usr/bin/ansible')) == os.path.normpath('/usr/bin/ansible')
    assert os.path.normpath(unfrack_path()('/usr/bin/ansible/')) == os.path.normpath('/usr/bin/ansible/')
    assert os.path.normpath(unfrack_path()('/usr/bin/ansible/ansible.cfg')) == os.path.normpath('/usr/bin/ansible/ansible.cfg')