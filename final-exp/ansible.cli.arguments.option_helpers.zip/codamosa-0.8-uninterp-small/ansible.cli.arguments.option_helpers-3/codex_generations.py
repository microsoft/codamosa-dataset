

# Generated at 2022-06-24 17:34:24.421024
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(desc="usage: %(prog)s [options] [hosts] ...")

    parser = add_subset_options(parser)

    args = parser.parse_args(args=['-t', 'main', '--skip-tags', 'secondary', '--skip-tags', 'third'])
    assert args.tags == ['main'], "tags: {}".format(args.tags)
    assert args.skip_tags == ['secondary', 'third'], "skip tags: {}".format(args.skip_tags)

    print("Test completed successfully")


# Generated at 2022-06-24 17:34:28.124391
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_known_args(['-t', 'tag0', '-t', 'tag1', '--skip-tags', 'tag2', '--skip-tags', 'tag3'])[0]
    assert args.tags == [ 'tag0', 'tag1' ], "Parse args failed"
    assert args.skip_tags == [ 'tag2', 'tag3' ], "Parse args failed"


# Generated at 2022-06-24 17:34:30.636179
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)



# Generated at 2022-06-24 17:34:40.585348
# Unit test for function add_connect_options
def test_add_connect_options():
    arg_parser = argparse.ArgumentParser()
    add_connect_options(arg_parser)
    parser_state = arg_parser.parse_args(["-u", "ansible", "-c", "local", "--private-key", "~/.ssh/id_rsa"])
    test_case_0()
    assert parser_state.remote_user == "ansible"
    assert parser_state.connection == "local"
    assert parser_state.private_key_file == "~/.ssh/id_rsa"
    print("\n test_add_connect_options: Test passed")


# Generated at 2022-06-24 17:34:41.332153
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # test case 0
    test_case_0()


# Generated at 2022-06-24 17:34:47.315196
# Unit test for function unfrack_path
def test_unfrack_path():
    # Create a test file

    # Call unfrack_path with an argument
    ret_0 = unfrack_path(False)

    # Call unfrack_path without an argument

    # Check the return value is equal to what we expect
    assert ret_0 == True


# Generated at 2022-06-24 17:34:54.108117
# Unit test for function add_connect_options
def test_add_connect_options():
    ansible_options = {
        'version': False,
        'verbosity': 1,
        'ask_pass': False,
        'connection_password_file': '~/.ansible/connection_passwords',
        'private_key_file': '~/.ssh/id_rsa',
        'remote_user': 'root',
        'connection': 'smart',
        'timeout': 10,
        'ssh_common_args': None,
        'sftp_extra_args': None,
        'scp_extra_args': None,
        'ssh_extra_args': None,
    }
    parser = create_base_parser('test_add_connect_options', usage="", desc=None, epilog=None)
    add_connect_options(parser)

# Generated at 2022-06-24 17:34:58.130160
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = add_runas_prompt_options()
    assert parser.dest == 'become_ask_pass'
    assert parser.const is True
    assert parser.default == False
    assert parser.type == None
    assert parser.nargs == 0
    assert parser.action == 'store_true'
    assert parser.choices is None
    assert parser.required == False
    assert parser.help == 'ask for privilege escalation password'
    assert parser.metavar is None
    assert parser._option_string == []


# Generated at 2022-06-24 17:35:03.094943
# Unit test for function unfrack_path
def test_unfrack_path():
    case_0 = (
        "abc"
    )
    expect_0 = os.path.abspath("abc")

    real_0 = unfrack_path(case_0)

    assert expect_0 == real_0



# Generated at 2022-06-24 17:35:06.987007
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser('testing', 'test')
    add_check_options(parser)
    try:
        parser.parse_args(['--syntax-check', '--check'])
    except SystemExit:
        test_case_0()


# Generated at 2022-06-24 17:35:19.972758
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(prog="ansible-doc")
    add_runas_prompt_options(parser)
    options = parser.parse_args()
    assert not options.become_ask_pass
    assert options.become_password_file is None
    assert options.become_user is None
    assert options.become_method == "sudo"
    assert not options.become


# Generated at 2022-06-24 17:35:22.805793
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    class TestParser(argparse.ArgumentParser):
        """ArgumentParser class for unit tests"""
        def error(self, *args, **kwargs):
            """Overriding error method for unit tests"""
            raise Exception("ERROR: " + str(args[0]))

    parser = TestParser(description="Test argument parser")
    add_runas_prompt_options(parser)
    add_runas_prompt_options(parser)
    return parser


# Generated at 2022-06-24 17:35:28.706082
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)

    args = parser.parse_args(['--vault-password-file', '--vault-pass-file', 'test_vault_password_files', 'test_vault_pass_file'])
    assert args.vault_password_files == ['test_vault_password_files', 'test_vault_pass_file']


# Generated at 2022-06-24 17:35:30.337709
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(prog='ansible-console')
    add_vault_options(parser)



# Generated at 2022-06-24 17:35:37.956990
# Unit test for function add_output_options
def test_add_output_options():
    print('test case for function add_output_options')
    parser = create_base_parser(prog='test_prog')
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert args.one_line == True
    args1 = parser.parse_args(['-t', 'test_tree'])
    assert args1.tree == 'test_tree'
    print('unit test success')


# Generated at 2022-06-24 17:35:45.017295
# Unit test for function add_inventory_options
def test_add_inventory_options():
    # Init argparse
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    # Parse cmd
    cmd = "--list-hosts -l 'a b c'"
    args = parser.parse_args(shlex.split(cmd))
    # Assert
    assert args.listhosts == True
    assert args.subset == 'a b c'


# Generated at 2022-06-24 17:35:48.819415
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(prog='ansible')
    runas_pass_group = parser.add_mutually_exclusive_group()
    add_runas_prompt_options(parser, runas_pass_group)
    
    with pytest.raises(SystemExit):
        test_case_0()


# Generated at 2022-06-24 17:35:56.123522
# Unit test for function add_meta_options
def test_add_meta_options():
    var_0 = argparse.ArgumentParser(description='description')
    add_meta_options(var_0)
    var_0.parse_args(['--force-handlers', '--flush-cache'])
    var_1 = argparse.ArgumentParser(description='description')
    add_meta_options(var_1)
    var_1.parse_args(['--force-handlers'])
    var_2 = argparse.ArgumentParser(description='description')
    add_meta_options(var_2)
    var_2.parse_args(['--flush-cache'])



# Generated at 2022-06-24 17:36:01.257754
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()

# Code to validate the version of Jinja2 in case we are bundled with it

# Generated at 2022-06-24 17:36:02.935363
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()

#
# Function to get version information
#

# Generated at 2022-06-24 17:36:13.950001
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path("/")
    var_1 = var_0("/var/lib/")
    assert var_1 == "/var/lib/"


# Generated at 2022-06-24 17:36:20.142355
# Unit test for function unfrack_path
def test_unfrack_path():
    path_0 = unfrack_path()
    print("this is test for ansible_version.py")
    print("unfrack_path: {}".format(path_0))

#
# Shared OptionGroups
#

# Generated at 2022-06-24 17:36:22.156504
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible' # set by default
    namespace = argparse.Namespace()
    values = None
    option_string = None
    test_case_0()


# Generated at 2022-06-24 17:36:24.140609
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser()
    add_runas_options(parser)
    args = parser.parse_args(['--version'])
    var_0 = version()
    assert var_0 == '2.11.0'


# Generated at 2022-06-24 17:36:29.189882
# Unit test for function ensure_value
def test_ensure_value():
    class namespace:
        var = None

    # check that the value is set if it's None
    ensure_value(namespace, 'var', 'value')
    assert namespace.var == 'value'

    # if not None, don't set the value
    ensure_value(namespace, 'var', 'another_value')
    assert namespace.var == 'value'


# Generated at 2022-06-24 17:36:36.289581
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    args = parser.parse_args()
    var_0 = args.become
    var_1 = args.become_method
    var_2 = args.become_user
    #assert var_0 == False
    #assert var_1 == "sudo"
    #assert var_2 == "root"


# Generated at 2022-06-24 17:36:38.542581
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()


# Generated at 2022-06-24 17:36:44.738903
# Unit test for function version
def test_version():
    test_case_0()

# Initialize mock_modules if necessary
try:
    from ansible.utils.module_docs_fragments import mock_modules
except ImportError:
    pass

# Add additional functions to mock module if necessary.
if 'mock_modules' in sys.modules:
    mock_modules.version = version
    mock_modules.gitinfo = _gitinfo



# Generated at 2022-06-24 17:36:53.073054
# Unit test for function add_runas_options
def test_add_runas_options():
    from ansible.cli.arguments import SortingHelpFormatter
    from ansible.cli.arguments import AnsibleVersion
    from ansible.config import defaults as C
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runas_options(parser)
    args = parser.parse_args()
    str_0 = str(args['become'])
    assert str_0 == 'False'
    str_0 = str(args['become_method'])
    assert str_0 == 'sudo'
    str_0 = str(args['become_user'])
    assert str_0 == 'None'


# Generated at 2022-06-24 17:36:55.859212
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert isinstance(parser, argparse.ArgumentParser)


# Generated at 2022-06-24 17:37:13.539044
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Test for method __call__(self, parser, namespace, values, option_string=None)
    # of class AnsibleVersion
    # Test case 0
    # cmd = "python ansible/__init__.py"
    # command = (cmd, )
    # p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # stdout, stderr = p.communicate()
    #
    # stdout = stdout.decode('utf-8')
    # assert stdout == var_0
    assert True == True


# Generated at 2022-06-24 17:37:15.885280
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """
    Test maybe_unfrack_path function
    """
    assert maybe_unfrack_path() == None


# Generated at 2022-06-24 17:37:23.832191
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = version()
    var_1 = __version__
    var_2 = "%s %s\n  config file = %s\n  configured module search path = %s\n  ansible python module location = %s\n  executable location = %s\n  python version = %s (%s)\n" % (var_0, to_native(var_1), to_native(unfrackpath(C.CONFIG_FILE)), to_native(C.DEFAULT_MODULE_PATH), to_native(ansible.__file__), to_native(sys.argv[0]), to_native(sys.version[:5]), to_native(sys.platform))
    var_3 = SysExit()
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None

# Generated at 2022-06-24 17:37:29.953020
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    print("add_async_options")
    add_async_options(parser)
    parser.print_help()


# Generated at 2022-06-24 17:37:31.593465
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('/') == '/'


# Generated at 2022-06-24 17:37:35.992901
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog='example',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_async_options(parser)
    parser.parse_args(['-P', '1', '-B', '2'])


# Generated at 2022-06-24 17:37:38.243333
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = version()
    assert ansible_version == ansible.__version__


# Generated at 2022-06-24 17:37:41.617476
# Unit test for function ensure_value
def test_ensure_value():
    try:
        TestEnsureValue = Namespace(0)
        assert TestEnsureValue.var == 0
    except AssertionError:
        raise AssertionError('TestEnsureValue failed')

# Tester for the '--version' argument.

# Generated at 2022-06-24 17:37:45.009737
# Unit test for function unfrack_path
def test_unfrack_path():
    # Case #0
    with pytest.raises(Exception):
        test_case_0()


# Generated at 2022-06-24 17:37:47.922597
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    #b_0 = None
    #v_0 = maybe_unfrack_path(b_0)
    pass


# Generated at 2022-06-24 17:38:05.695622
# Unit test for constructor of class SortingHelpFormatter

# Generated at 2022-06-24 17:38:08.169208
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    x = AnsibleVersion()
    print(x.__call__(None, None, None, None))


# Generated at 2022-06-24 17:38:14.918026
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = '%s %s' % (constants.ANSIBLE_PRODUCT_NAME, __version__)
    if var_1 == var_0():
        print(var_1)
    else:
        print('AnsibleVersion.__call__ failed')
        

# Generated at 2022-06-24 17:38:19.043638
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = Parser()
    var_0.add_argument('-v', action=PrependListAction)
    var_0.parse_args(['-vvv'])



# Generated at 2022-06-24 17:38:21.743828
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path(1)

#
# Special OptionGroups (for CLI usage)
#

# Generated at 2022-06-24 17:38:31.350786
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_1 = argparse.Namespace()
    var_2 = ['ansible-playbook.py']
    var_3 = 'hello'
    var_4 = [var_3]
    var_5 = [var_4]
    var_6 = 'ansible-playbook.py'
    var_7 = 'ansible-playbook.py'
    var_8 = 'ansible-playbook.py'
    var_9 = 'ansible-playbook.py'
    var_10 = 'ansible-playbook.py'
    var_11 = 'ansible-playbook.py'
    var_12 = 'ansible-playbook.py'
    var_13 = 'ansible-playbook.py'
    var_14  = True

# Generated at 2022-06-24 17:38:41.084753
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version = version()
    parser = argparse.ArgumentParser()
    namespace = parser.parse_args()
    option_string = parser.add_argument_group()
    parser.exit()
    parser.add_argument('version', action='version', version=version)
    var_0 = namespace.version

    var_1 = argparse.ArgumentParser()
    var_2 = var_1.parse_args()
    var_3 = var_1.add_argument_group()
    var_1.exit()

    var_4 = argparse.ArgumentParser()
    var_5 = var_4.parse_args()
    var_6 = var_4.add_argument_group()
    var_4.exit()


# Generated at 2022-06-24 17:38:46.274536
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test_case_0()

#
# Base class for all cli parsers
#

# Generated at 2022-06-24 17:38:50.150318
# Unit test for function unfrack_path
def test_unfrack_path():
    assert (unfrack_path("/home/ansible/ansible/test") == "/home/ansible/ansible/test"), "Test #0 Failed!"
    assert (unfrack_path("-") == '-'), "Test #1 Failed!"



# Generated at 2022-06-24 17:38:51.637936
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('/var/path')


# Generated at 2022-06-24 17:39:11.748295
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert(maybe_unfrack_path('@/')('@/path') == '@/path')
    assert(maybe_unfrack_path('@/')('/path') == '/path')



# Generated at 2022-06-24 17:39:15.568837
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()

if __name__ == "__main__":
    test_case_0()
    test_maybe_unfrack_path()

# Generated at 2022-06-24 17:39:23.402021
# Unit test for function unfrack_path
def test_unfrack_path():
    from ansible.module_utils.path import unfrackpath as var_0
    var_1 = var_0('/usr/bin/lxc-ls')
    assert var_1 == '/usr/bin/lxc-ls'

    var_2 = var_0('/home/ansible/.ansible/plugins/modules:./library')
    assert var_2 == './library:/home/ansible/.ansible/plugins/modules'


# Generated at 2022-06-24 17:39:25.414593
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    to_native(SortingHelpFormatter.add_arguments())

#
# Main CLI Parser
#

# Generated at 2022-06-24 17:39:26.490466
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    test_case_0()


# Generated at 2022-06-24 17:39:37.210769
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = unfrack_path()

# Generated at 2022-06-24 17:39:40.096407
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = None
    namespace = None
    values = None
    option_string = None
    action = AnsibleVersion(parser, namespace, values, option_string)
    action.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-24 17:39:50.484102
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # set up implicit initialization of the parser
    parser = argparse.ArgumentParser(description='description')
    # set up implicit initialization of the parser
    namespace = parser.parse_args(args=[])
    # set up implicit initialization of the parser
    values = parser.parse_args(args=[])
    # set up implicit initialization of the parser
    option_string = parser.parse_args(args=[])
    # call the method of interest
    action = AnsibleVersion(option_strings='option_strings', dest='dest', nargs=0, const=None, default='default', type=None, choices=None, help='help', metavar=None)
    action.__call__(parser, namespace, values, option_string)



# Generated at 2022-06-24 17:39:53.440484
# Unit test for function unfrack_path
def test_unfrack_path():
    with pytest.raises(UnboundLocalError):
        test_case_0()
#
# Create an OptionParser for a given program
#

# Generated at 2022-06-24 17:39:57.220867
# Unit test for function unfrack_path
def test_unfrack_path():
    args = ["/foo/bar"]
    pathsep = False
    # Call unfrack_path
    result = unfrack_path(pathsep)(args[0])
    assert result == ["/foo/bar"]


# Generated at 2022-06-24 17:40:13.464544
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("test") == unfrackpath("test")

#
# Option Parser classes
#

# Generated at 2022-06-24 17:40:14.880993
# Unit test for function version
def test_version():
    ver = version()
    assert isinstance(ver,str)


# Generated at 2022-06-24 17:40:21.639325
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Create a new instance of the object being tested
    action = PrependListAction(option_strings, dest, nargs, const, default, type, choices, required, help, metavar)
    # Invoke method being tested
    action.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-24 17:40:23.784331
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('~')


# Generated at 2022-06-24 17:40:29.750926
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    cases = [
        # [input, expected],
        ["@/data/xxx.yml", "@data/xxx.yml"],
    ]
    for case in cases:
        var_1 = maybe_unfrack_path(case[0])
        if var_1 != case[1]:
            print("Fail")
        else:
            print("Pass")


# Generated at 2022-06-24 17:40:30.851104
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path() == inner


# Generated at 2022-06-24 17:40:32.398409
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp') == '/tmp'


#
# Options for Aggregates
#

# Generated at 2022-06-24 17:40:38.590711
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~/test') == "~" + os.path.expanduser('~/test')
    assert maybe_unfrack_path('~')('~') == "~" + os.path.expanduser('~')


# Generated at 2022-06-24 17:40:47.034470
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path_1 = b'/home/ubuntu/workspace/data/test_cases/test_data_0.txt'
    path_2 = b'/home/ubuntu/workspace/data/test_cases/test_data_1.txt'
    assert maybe_unfrack_path(path_1)([path_1, path_2]) == [path_1, path_2]
    assert maybe_unfrack_path(path_1)(path_1) == path_1
    assert maybe_unfrack_path(path_1)(path_2) == path_2



# Generated at 2022-06-24 17:40:49.326090
# Unit test for function unfrack_path
def test_unfrack_path():
    input_var = '-/usr/ansible'
    expected_output = '-/usr/ansible'
    actual_output = unfrack_path()(input_var)
    assert actual_output == expected_output



# Generated at 2022-06-24 17:41:33.072373
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert SortingHelpFormatter()


# Generated at 2022-06-24 17:41:45.962683
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = 'I am a beaon'
    var_2 = "I am a string with beaon"
    var_3 = '/I/am/a/path'
    var_4 = unfrack_path()
    var_5 = maybe_unfrack_path(var_1)()
    var_6 = maybe_unfrack_path(var_1)(var_2)
    var_7 = maybe_unfrack_path(var_1)(var_3)
    print(var_5)
    print(var_6)
    print(var_7)
    test_dict_1 = {'var_5': var_5, 'var_6': var_6, 'var_7': var_7}
    return test_dict_1



# Generated at 2022-06-24 17:41:50.050306
# Unit test for function unfrack_path
def test_unfrack_path():
    assert True


# Generated at 2022-06-24 17:42:03.751038
# Unit test for function version
def test_version():
    
        # Call function version with arguments:
        #   prog='ansible-console'
        ret_val = version('ansible-console')

        # Compare the return values

# Generated at 2022-06-24 17:42:07.942724
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test for exception.
    try:
        maybe_unfrack_path(5)
    except TypeError:
        pass
    # Test for default argument
    try:
        maybe_unfrack_path()
    except TypeError:
        pass
    # Test for correct argument.
    try:
        maybe_unfrack_path('-c')
    except TypeError:
        pass


# Generated at 2022-06-24 17:42:08.802448
# Unit test for function version
def test_version():
    assert isinstance(version("ansible"), str)


# Generated at 2022-06-24 17:42:16.793753
# Unit test for method __call__ of class PrependListAction

# Generated at 2022-06-24 17:42:20.780046
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('@')


# Generated at 2022-06-24 17:42:25.357359
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()("../../raw-data/grafana.yaml") == "../../raw-data/grafana.yaml"
#
# Options Parser
#

# Generated at 2022-06-24 17:42:28.449150
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()

