

# Generated at 2022-06-24 17:34:12.211390
# Unit test for function add_check_options
def test_add_check_options():
    parser_0 = argparse.ArgumentParser()
    dict_0 = {}
    var_0 = add_check_options(dict_0)

# Generated at 2022-06-24 17:34:19.231785
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    result = add_inventory_options(parser)
    # Should be 2 options
    assert len(result) == 2

    # Should have arg -i
    assert result.inventory

    # Should have arg -l
    assert result.subset


# Generated at 2022-06-24 17:34:25.637539
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    dict_0 = {}
    dict_0['test_case_0'] = 'test_case_0'
    dict_0['test_case_1'] = 'test_case_1'
    dict_0['test_case_2'] = 'test_case_2'
    dict_0['test_case_3'] = 'test_case_3'
    dict_0['test_case_4'] = 'test_case_4'
    dict_0['test_case_5'] = 'test_case_5'
    dict_0['test_case_6'] = 'test_case_6'
    dict_0['test_case_7'] = 'test_case_7'
    dict_0['test_case_8'] = 'test_case_8'

# Generated at 2022-06-24 17:34:29.696637
# Unit test for function add_runas_options
def test_add_runas_options():
    # Create parser object
    parser = argparse.ArgumentParser()

    # Call function add_runas_options
    add_runas_options(parser)


# Generated at 2022-06-24 17:34:32.277746
# Unit test for function unfrack_path
def test_unfrack_path():
    assert isinstance(unfrack_path(), Callable), "Failed to create proper callable"


# Generated at 2022-06-24 17:34:35.333671
# Unit test for function add_fork_options
def test_add_fork_options():
    dict_0 = {}
    var_0 = add_fork_options(dict_0)


# Generated at 2022-06-24 17:34:36.955659
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()

    # add_connect_options should return None
    assert add_connect_options(parser) == None
    assert parser.private_key_file.default == C.DEFAULT_PRIVATE_KEY_FILE


# Generated at 2022-06-24 17:34:38.921417
# Unit test for function add_async_options
def test_add_async_options():
    dict_0 = {}
    var_0 = add_async_options(dict_0)
    print(var_0)


# Generated at 2022-06-24 17:34:40.382543
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    add_subset_options(parser)



# Generated at 2022-06-24 17:34:51.599982
# Unit test for function ensure_value
def test_ensure_value():
    dict_0 = {}
    value_0 = {}
    var_0 = ensure_value(dict_0, "ansible_playbook_python", value_0)
    assert var_0 == value_0
    dict_1 = {}
    value_1 = {}
    var_1 = ensure_value(dict_1, "ansible_playbook_python", value_1)
    assert var_1 == value_1
    dict_2 = {}
    value_2 = {}
    var_2 = ensure_value(dict_2, "ansible_playbook_python", value_2)
    assert var_2 == value_2
    dict_3 = {}
    value_3 = {}
    var_3 = ensure_value(dict_3, "ansible_playbook_python", value_3)
    assert var_3

# Generated at 2022-06-24 17:35:29.870701
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    case_0 = SortingHelpFormatter()
    if case_0.__class__.__name__ != 'SortingHelpFormatter':
        print(test_case_0.__doc__)
    else:
        print("testCase 0 passed")


# Generated at 2022-06-24 17:35:35.582274
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args()
    assert args.check == False, 'unexpected add_check_options function result'
    assert args.syntax == False, 'unexpected add_check_options function result'
    assert args.diff == False, 'unexpected add_check_options function result'


# Generated at 2022-06-24 17:35:37.249610
# Unit test for function add_meta_options
def test_add_meta_options():
    from ansible.cli.argparse.default import create_base_parser
    parser = create_base_parser()
    add_meta_options(parser)
    options, args = parser.parse_known_args()



# Generated at 2022-06-24 17:35:43.497011
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_0 = '.'
    var_1 = '.'
    var_2 = '.'
    var_3 = '.'
    assert var_0 == var_1
    assert var_2 == var_3


# Generated at 2022-06-24 17:35:47.928707
# Unit test for function version
def test_version():
    var_1 = test_case_0()
    print(version(var_1))

test_version()

# Generated at 2022-06-24 17:35:57.484187
# Unit test for function add_output_options
def test_add_output_options():
    parser = create_base_parser('some_data')
    var_0 = {}
    add_output_options(parser)
    var_0['test_result'] = None
    var_0['test_exception'] = None
    try:
        var_0['test_result'] = parser.parse_args([])
    except Exception as var_1:
        var_0['test_exception'] = var_1
    a_0 = var_0['test_result']
    b_0 = argparse.Namespace(basedir=None, connection=None, connection_password_file=None, private_key_file=None, flush_cache=False, forks=5, inventory=None, subset=None, tree=None, listhosts=False, remote_user=None, verbosity=0, ask_pass=False)
   

# Generated at 2022-06-24 17:35:58.959471
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    args = parser.parser_args('-o -t')



# Generated at 2022-06-24 17:36:01.252722
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test with arguments that match test_case_0
    var_1 = "/usr/bin/ansible-vault"
    var_1 = unfrack_path(var_1)
    print(var_1)


# Generated at 2022-06-24 17:36:08.341432
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = {}
    var_0 = None
    var_0 = '-'
    var_1 = unfrack_path(var_0)
    assert var_1 == '-'
    var_1 = unfrack_path(var_0)
    assert var_1 == '-'
    var_0 = 'a'
    var_0 = 'a'
    var_1 = unfrack_path(var_0)
    assert var_1 == 'a'
    var_1 = unfrack_path(var_0)
    assert var_1 == 'a'
    var_0 = 'b'
    var_0 = 'b'
    var_1 = unfrack_path(var_0)
    assert var_1 == 'b'
    var_1 = unfrack_path(var_0)
    assert var

# Generated at 2022-06-24 17:36:10.491637
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert func_0(var_0) == None, 'Failed test #1'


# Generated at 2022-06-24 17:36:20.540995
# Unit test for function ensure_value
def test_ensure_value():
    var_0 = {}
    exp_0 = {}
    assert ensure_value(var_0, 'var_0', {}) == exp_0


# Generated at 2022-06-24 17:36:23.268649
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = "vagrant"
    var_0 = AnsibleVersion(option_strings=["-v", "--version"], dest="version")
    var_1 = var_0(parser, var_1, var_1, option_string=None)


# Generated at 2022-06-24 17:36:25.838251
# Unit test for function ensure_value
def test_ensure_value():
    assert "{}" == ensure_value(var_0, "", {"a": 1})


# Generated at 2022-06-24 17:36:29.593787
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Set up mock parser and mock namespace
    var_parser = mock.MagicMock()
    mock_namespace = mock.MagicMock()
    mock_namespace.option_string = None
    argparse.Action.__call__(AnsibleVersion(), var_parser, mock_namespace, mock_values)


# Generated at 2022-06-24 17:36:32.627957
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = {}
    var_0 = unfrack_path()
    if var_0 == '-':
        return True
    else:
        return False

# Generated at 2022-06-24 17:36:36.623657
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = {}
    if not var_0:
        raise Exception("AssertionError")

test_case_0()
test_maybe_unfrack_path()

# Generated at 2022-06-24 17:36:44.700813
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = '@DEFAULT'
    var_1 = maybe_unfrack_path(var_1)
    value = 'arg'
    var_1 = var_1(value)
    var_2 = 'arg'
    assert var_1 == var_2
    var_3 = '@DEFAULT'
    var_3 = maybe_unfrack_path(var_3)
    value = '$HOME'
    var_3 = var_3(value)
    var_4 = '$HOME'
    assert var_3 == var_4


# Generated at 2022-06-24 17:36:49.020310
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion(option_strings=[])
    assert action.option_strings == []

    parser = argparse.ArgumentParser()
    action(parser, None, None)

# Tests for method __call__ of class AnsibleVersion

# Generated at 2022-06-24 17:36:52.185969
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_case_0()


# Generated at 2022-06-24 17:36:55.422448
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    raw = "hosts: a"
    beacon = '~'
    value = maybe_unfrack_path(beacon)(raw)
    assert value == "hosts: a"




# Generated at 2022-06-24 17:37:03.996393
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))


# Generated at 2022-06-24 17:37:07.045341
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_0 = SortingHelpFormatter()
    assert type(var_0) == SortingHelpFormatter
    assert type(var_0) == argparse.HelpFormatter


# Generated at 2022-06-24 17:37:08.965471
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = {}
    # Check that the function was called in the expected way
    assert test_case_0() == var_0


# Generated at 2022-06-24 17:37:11.556903
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # TODO: support this
    return


# Generated at 2022-06-24 17:37:13.329446
# Unit test for function ensure_value
def test_ensure_value():
    ensure_value(var_0, "var_0", var_0)


# Generated at 2022-06-24 17:37:15.911995
# Unit test for function version
def test_version():
    print("test_version")
    try:
        version()
    except Exception as var_0:
        print(var_0)
        print("FAIL")
        return
    print("PASS")


# Generated at 2022-06-24 17:37:19.359342
# Unit test for function version
def test_version():
    #print(test_version.__name__)
    var_0 = version(prog="ansible")
    print(var_0)
if __name__ == '__main__':
    test_version()

# Generated at 2022-06-24 17:37:27.768321
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test_case = 0
    try:
        # Testing if the module imports correctly
        test_case = 1
        test_case_0()
        test_case = 2
    except Exception as e:
        print(e)
        if test_case == 0:
            print('The ansible module is not properly installed.')
        elif test_case == 1:
            print('The ansible module is installed but the "AnsibleVersion" class cannot be imported.')
        elif test_case == 2:
            print('The "AnsibleVersion" class is imported but the __call__ method cannot be called.')

test_AnsibleVersion___call__()

# Generated at 2022-06-24 17:37:34.690236
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = {}
    var_1 = {}
    def run(self, parser, namespace, values, option_string=None):
        ansible_version = to_native(version(getattr(parser, 'prog')))
        print(ansible_version)
        parser.exit()
    run(var_0, var_1, var_1)
    print(var_0)
    print(var_1)
    print(var_0)
    print(var_1)

# Generated at 2022-06-24 17:37:35.625686
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = {}


# Generated at 2022-06-24 17:37:45.007728
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()
    assert var_1 == False


# Generated at 2022-06-24 17:37:47.922563
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    variable_0 = unfrack_path()
    variable_0 = maybe_unfrack_path(variable_0)


# Generated at 2022-06-24 17:37:57.353425
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_1 = argparse.Action
    var_2 = argparse.Action.__call__
    var_3 = argparse.Action.__call__()
    var_4 = argparse.Action.__call__()
    var_5 = argparse.Action.__call__()
    var_6 = argparse.Action.__call__()
    var_7 = argparse.Action.__call__()
    var_8 = argparse.Action.__call__()
    var_9 = argparse.Action.__call__()
    var_10 = argparse.Action.__call__()
    var_11 = argparse.Action.__call__()
    var_12 = argparse.Action.__call__()
    var_13 = argparse.Action.__call__()

# Generated at 2022-06-24 17:37:58.564783
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()
    assert var_1("/usr/bin") == "/usr/bin"


# Generated at 2022-06-24 17:38:05.442867
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = _ansible_options(version=False)
    var_0.add_argument = mock.MagicMock()
    var_0._ansible_parse_args()
    var_0.add_argument.assert_any_call(
        '--version',
        action='version',
        version='%(prog)s 0.0.1',
        help='Show program\'s version number and exit.',
    )


# Generated at 2022-06-24 17:38:12.015923
# Unit test for function ensure_value
def test_ensure_value():
    var_1 = argparse.Namespace()
    var_2 = ensure_value(var_1, 'test_var', 'test_val')
    assert(var_1.test_var == 'test_val')
    assert(var_2 == 'test_val')


# Generated at 2022-06-24 17:38:19.106866
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    setattr(namespace, "a", None)
    assert ensure_value(namespace, "a", 10) == 10
    setattr(namespace, "b", 20)
    assert ensure_value(namespace, "b", 10) == 20
    assert namespace.a == 10
    assert namespace.b == 20



# Generated at 2022-06-24 17:38:21.211115
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert hasattr(SortingHelpFormatter, '__init__') == True
    assert hasattr(SortingHelpFormatter, 'add_arguments') == True


# Generated at 2022-06-24 17:38:27.463188
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = "/home/vagrant/ansible/ansible-tutorials/tutorials-2.0/skip/skip_tasks.yml"
    var_1 = "/home/vagrant/ansible/ansible-tutorials/tutorials-2.0/skip/skip_tasks.yml"
    var_res = unfrack_path()
    assert var_res == var_1, "Failure assert equals."


# Generated at 2022-06-24 17:38:36.357628
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('ansible/test/unit/module_utils/test_command_line.py') == '/Users/feather/ansible/test/unit/module_utils/test_command_line.py'
    assert unfrack_path()('test_command_line.py') == '/Users/feather/ansible/test_command_line.py'
    assert unfrack_path()('ansible/test/unit/util/test/test_args.py') == '/Users/feather/ansible/test/unit/util/test/test_args.py'


# Generated at 2022-06-24 17:38:46.457039
# Unit test for function unfrack_path
def test_unfrack_path():
    case_data = test_case_0()
    assert case_data == None, case_data


# Generated at 2022-06-24 17:38:49.848040
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    print("Checking constructor of class SortingHelpFormatter")
    formatter = SortingHelpFormatter()
    if not formatter:
        fail("Unable to instantiate SortingHelpFormatter")


#
# Generic OptionParsers
#



# Generated at 2022-06-24 17:38:50.810925
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path() == inner



# Generated at 2022-06-24 17:38:59.873947
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # check for the value of the constant
    assert maybe_unfrack_path.__code__.co_consts[0] == '@'

    # check for return type of function
    assert isinstance(maybe_unfrack_path('@'), type(lambda:0))

    # check for return value with parameter '@'
    assert maybe_unfrack_path('@')('-') == '-'
    assert maybe_unfrack_path('@')('@') == '@'
    assert maybe_unfrack_path('@')('@a') == '@a'
    assert maybe_unfrack_path('@')('@@a') == '@a'
    assert maybe_unfrack_path('@')('@@/a') == '@/a'
    assert maybe_unfrack_path

# Generated at 2022-06-24 17:39:01.337342
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path("var_1")


# Generated at 2022-06-24 17:39:05.455316
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Create an object of class AnsibleVersion
    ansible_version = AnsibleVersion()

    # Call the method __call__
    ansible_version.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-24 17:39:07.526731
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()

#
# Function version
#

# Generated at 2022-06-24 17:39:10.026289
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    try:
        assert test_case_0()
    except AssertionError:
        raise


# Generated at 2022-06-24 17:39:15.771548
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    if HAS_LIBYAML:
        var_0 = maybe_unfrack_path('{{ ')
    else:
        var_0 = maybe_unfrack_path('{{')
    var_0 = maybe_unfrack_path('{{')


# Generated at 2022-06-24 17:39:24.712624
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test method __call__ of class PrependListAction, requires instantiating a PrependListAction object.
    # See https://docs.python.org/3/library/unittest.mock.html#unittest.mock.Mock.return_value
    # and https://docs.python.org/3/library/unittest.mock.html#unittest.mock.Mock.side_effect
    # for examples of how to apply tests to different behaviors
    assert 1 == 1

# Generated at 2022-06-24 17:39:40.808129
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # default
    var_0 = SortingHelpFormatter()
    assert var_0.__class__ is SortingHelpFormatter


# Generated at 2022-06-24 17:39:51.466500
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_1 = classmethod()
    var_2 = __main__()
    # Demo of argparse._AppendAction.__call__, with a 'const'
    parser = argparse.ArgumentParser()
    parser.add_argument('--str1', action='append', dest='str_list', const='str1')
    parser.add_argument('--str2', action='append', dest='str_list', const='str2')
    parser.add_argument('--list', action='append', dest='list_list', const=['list'])
    args = parser.parse_args(['--str1', '--str2', '--list'])
    print(args)
    # Demo of argparse._AppendAction.__call__, with a 'nargs'
    parser = argparse.ArgumentParser()

# Generated at 2022-06-24 17:39:53.675818
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    my_fmt = SortingHelpFormatter()
    assert my_fmt is not None  


# Generated at 2022-06-24 17:40:01.496897
# Unit test for function version

# Generated at 2022-06-24 17:40:16.799800
# Unit test for function version
def test_version():

    try:
        assert callable(version)

        # Unit test for function version
        # Test with parameter prog set to None
        assert version() == '2.9.6\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = Default w/o overrides\n  ansible python module location = /usr/local/lib/python3.6/dist-packages/ansible\n  ansible collection location = /usr/share/ansible/collections\n  executable location = /usr/bin/ansible-playbook\n  python version = 3.6.9 (default, Apr 18 2020, 01:56:04)\n[GCC 8.4.0]\n  jinja version = 2.10\n  libyaml = 1'

    except AssertionError:
        pass

# Generated at 2022-06-24 17:40:28.478646
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    arg0 = type('obj0', (object,), {})
    arg1 = type('obj1', (object,), {})
    arg2 = type('obj2', (object,), {})
    arg4 = type('obj4', (object,), {})
    arg5 = type('obj5', (object,), {})

    arg1.prog = arg4
    arg5.version = test_case_0

    arg2.AnsibleVersion = arg5

    arg1.AnsibleVersion = arg2

    arg0.parser = arg1

    val0 = arg0.__call__()



# Generated at 2022-06-24 17:40:31.516022
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = '/usr/local/bin/ansible-galaxy'
    var_1 = unfrack_path()(var_0)
    assert var_1 == '/usr/local/bin/ansible-galaxy'


# Generated at 2022-06-24 17:40:44.152877
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog = 'ansible-playbook', add_help=False)
    namespace = parser.parse_args()
    
    action = AnsibleVersion(
        option_strings=['--version'],
        dest=namespace,
        nargs=0,
        const=namespace,
        default=namespace,
        type=None,
        choices=None,
        required=False,
        help=None,
        metavar=None
    )
    # Coverage case 0
    test_case_0()
    
    
 
# Returns a human readable version string

# Generated at 2022-06-24 17:40:45.450511
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():

    assert test_case_0() == True


# Generated at 2022-06-24 17:40:47.687080
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()

#
# Shared Arguments
#

# Generated at 2022-06-24 17:41:19.690915
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()
    assert False



# Generated at 2022-06-24 17:41:24.765757
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path(False)
    assert var_0.__name__ == 'inner'

    var_1 = unfrack_path(True)
    assert var_1.__name__ == 'inner'

#
# Argument specs for individual apps
#

# Generated at 2022-06-24 17:41:29.464057
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    '''
    Unit test for method __call__ of class AnsibleVersion
    '''
    print('AnsibleVersion___call__')

    # duplicate the test case (to reduce the effort to maintain the test suite)
    test_case = test_case_0

    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-version'

#
# Main function
#

# Generated at 2022-06-24 17:41:32.820227
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()
    print(var_0)

# Main function for test

# Generated at 2022-06-24 17:41:38.389701
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():

    # Setup test environment
    class TestParser(object):
        def __init__(self, *args, **kwargs):
            self.prog = 'ansible'

        def exit(self, status=0, message=None):
            sys.exit(status)

    TestParser = TestParser
    # Test env is ready
    var_0 = AnsibleVersion()
    assert var_0 is not None
    assert hasattr(var_0, '__call__')
    var_1 = var_0.__call__(TestParser, None, None)
    assert var_1 is None


# Generated at 2022-06-24 17:41:40.426942
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)

# OptionParsers

# Generated at 2022-06-24 17:41:42.189741
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('hello')


# Generated at 2022-06-24 17:41:48.313790
# Unit test for function unfrack_path
def test_unfrack_path():
    function_name = sys._getframe().f_code.co_name
    var_0 = unfrack_path()
    var_1 = "test_case_0"
    var_2 = "unfrackpath(path)"
    if var_0.__name__ == var_1 and var_0.__doc__ == var_2:
        passed(function_name)
    else:
        failed(function_name)



# Generated at 2022-06-24 17:41:49.300982
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path(pathsep=True)


# Generated at 2022-06-24 17:41:55.461979
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = ansible_version(
        "../tests/test_ansible-playbook"
    )
    var_1 = to_native()
    print(var_0)
    print(var_1)
    # Expect that the following exit() call will be invoked
    parser.exit()



# Generated at 2022-06-24 17:43:03.532449
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()

# Generated at 2022-06-24 17:43:08.454782
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test for success case.
    pathsep = True
    assert(unfrack_path(pathsep) == False)
    # Test for failure case.
    pathsep = ''
    assert(unfrack_path(pathsep) == False)

#
# The command line parser wrapper
#

# Generated at 2022-06-24 17:43:16.050508
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unfrack_path()('/tmp/path/to/file') == '/tmp/path/to/file'
    assert unf

# Generated at 2022-06-24 17:43:19.303253
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    parser = argparse.ArgumentParser(description="description",formatter_class=SortingHelpFormatter)
    parser.add_argument("-b")
    parser.add_argument("-a")
    parser.print_help()


# Generated at 2022-06-24 17:43:22.582659
# Unit test for function unfrack_path
def test_unfrack_path():
    # FIXME: Create unit test for unfrack_path
    var_0 = unfrack_path()

#
# Command Line Parsers
#