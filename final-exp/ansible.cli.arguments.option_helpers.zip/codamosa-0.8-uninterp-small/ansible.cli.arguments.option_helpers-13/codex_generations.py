

# Generated at 2022-06-24 17:34:08.767555
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    add_check_options(parser)
    add_check_options(parser)
    add_check_options(parser)
    print(parser.parse_args([]))


# Generated at 2022-06-24 17:34:11.974086
# Unit test for function add_subset_options
def test_add_subset_options():
    argv = ['-t', 'tags', '--skip-tags', 'skip_tags']
    func = add_subset_options
    parser = argparse.ArgumentParser()
    func(parser)
    args = parser.parse_args(argv)
    assert args == argparse.Namespace(skip_tags=['skip_tags'], tags=['tags'])


# Generated at 2022-06-24 17:34:16.336623
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)


# Generated at 2022-06-24 17:34:19.161436
# Unit test for function add_runas_options
def test_add_runas_options():
    bc = BaseCLI()
    parser = bc.baseparser
    add_runas_options(parser)


# Generated at 2022-06-24 17:34:29.945203
# Unit test for function add_connect_options
def test_add_connect_options():
    argparser = argparse.ArgumentParser()
    argparser.add_argument('-u', '--user', action='store', dest='var_0', help='connect as this user (default=%s)' % C.DEFAULT_REMOTE_USER)
    argparser.add_argument('--private-key', '--key-file', action='store', dest='var_1', help='use this file to authenticate the connection')
    argparser.add_argument('-c', '--connection', action='store', dest='var_2', help="connection type to use (default=%s)" % C.DEFAULT_TRANSPORT)
    argparser.add_argument('--conn-pass-file', '--connection-password-file', action='store', dest='var_3', help="Connection password file")

# Generated at 2022-06-24 17:34:40.652480
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    parser.add_argument("-C", "--check", default=False, dest='check', action='store_true',
                        help="don't make any changes; instead, try to predict some of the changes that may occur")
    parser.add_argument('--syntax-check', dest='syntax', action='store_true',
                        help="perform a syntax check on the playbook, but do not execute it")
    parser.add_argument("-D", "--diff", default=C.DIFF_ALWAYS, dest='diff', action='store_true',
                        help="when changing (small) files and templates, show the differences in those"
                             " files; works great with --check")
    parser.parse_args(["--check"])



# Generated at 2022-06-24 17:34:49.811865
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser()
    parser.add_argument('-M', '--module-path', dest='module_path', default=None, type=unfrack_path(pathsep=True), action=PrependListAction)
    assert hasattr(parser, 'module_path'), "Failed to add module-path arg"
    assert hasattr(parser, 'module_path_brand_new'), "Failed to add module-path arg"
    test_case_0()

# unit test for function add_inventory_options

# Generated at 2022-06-24 17:34:52.049089
# Unit test for function ensure_value
def test_ensure_value():
    assert ensure_value(1, 'a', 'a') == 'a'


# Generated at 2022-06-24 17:34:58.825224
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

    with open('cs_doct.txt', 'w') as fp:
        fp.write(parser.format_help())

    parser.format_help()
    add_connect_options(parser)

# Generated at 2022-06-24 17:35:03.840565
# Unit test for function add_check_options
def test_add_check_options():

    test_case_0()

if __name__ == '__main__':
    #Use the following code if you have some test code
    #test_function()
    test_case_0()
    test_add_check_options()

# Generated at 2022-06-24 17:35:20.055167
# Unit test for function add_inventory_options
def test_add_inventory_options():
    argv = ['--list-hosts', '-l', '-i', '--inventory-file', '--inventory', '--inventory']
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_inventory_options(parser)
    options = parser.parse_args(argv)
    return options

# This test case should print out a list of matching hostes, and should not execute anything else

# Generated at 2022-06-24 17:35:22.875429
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/var') == '@/var'
    assert maybe_unfrack_path('@')('@/var/lib') == '@/var/lib'

# Generated at 2022-06-24 17:35:25.407435
# Unit test for function unfrack_path
def test_unfrack_path():
    assert 'ansible-playbook' in unfrack_path()('ansible-playbook')



# Generated at 2022-06-24 17:35:27.342325
# Unit test for function ensure_value
def test_ensure_value():
    var_0 = ensure_value(namespace=None, name=None, value=None)
    print(var_0)


# Generated at 2022-06-24 17:35:29.105038
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()


# Generated at 2022-06-24 17:35:35.713850
# Unit test for function add_runas_options
def test_add_runas_options():
    module = AnsibleModule(
        argument_spec=dict(
            become=dict(required=True, type='bool'),
            dest=dict(required=True, type='str'),
            become_user=dict(required=True, type='str'),
            become_method=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )

    var_0 = add_runas_options(module)


# Generated at 2022-06-24 17:35:41.020965
# Unit test for function add_subset_options
def test_add_subset_options():
    '''
    Unit test for function add_subset_options
    '''
    def do_test(capsys):
        '''
        Function to perform test
        '''
        parser = create_base_parser("test")
        add_subset_options(parser)
        case_0 = ['-h']
        with pytest.raises(SystemExit):
            parser.parse_args(case_0)
        out, err = capsys.readouterr()

# Generated at 2022-06-24 17:35:45.174156
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = AnsibleVersion()
    var_2 = argparse.ArgumentParser()
    var_3 = to_native(version('ansible'))
    try:
        var_1(var_2, None, None)
    except SystemExit:
        pass


# Generated at 2022-06-24 17:35:50.392729
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    parser.parse_args(['-i', 'inventory', '--list-hosts', '-l', 'localhost'])


# Generated at 2022-06-24 17:35:52.521145
# Unit test for function add_module_options
def test_add_module_options():
    var_0 = create_base_parser()
    add_module_options(var_0)
    parser = var_0

    # TODO: change command name to something that isn't "test"
    #parser = parser.parse_args(["test", "-M", "/test_path"])
    #var_1 = parser.module_path


# Generated at 2022-06-24 17:36:02.849824
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path() is maybe_unfrack_path



# Generated at 2022-06-24 17:36:12.283468
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()

    add_runas_prompt_options(parser)

    args = parser.parse_args(['-K'])
    assert args.become_ask_pass

    args = parser.parse_args(['--become-password-file', '~/.ssh/id_rsa'])
    assert args.become_password_file == '~/.ssh/id_rsa'


# Generated at 2022-06-24 17:36:23.994494
# Unit test for function add_runas_options
def test_add_runas_options():
    # Test case setup
    # Create a DataBase
    db = DataBase(test_case_0, test_case_0.__name__)
    for index in range(100):
        # Create a parser
        parser = create_base_parser('ansible', 'ansible')
        # Call function add_runas_options
        result = add_runas_options(parser)
        # Save the result to database
        db.append((parser, result))
    db.commit()
    return db

test_case_1_replace = [
    {'plain': "  -k, --ask-pass                       ask for connection password\n"},
    {'plain': "      --connection-password-file FILE   connection password file\n"},
]


# Generated at 2022-06-24 17:36:32.743583
# Unit test for function unfrack_path
def test_unfrack_path():
    get_path = unfrack_path()
    # Replace with appropriate test case
    result = get_path(0)
    print(result)
    assert(result == 0)

#
# Option Parser generation
#
deploy_parser = argparse.ArgumentParser(prog='ansible-config')
deploy_parser._ansible_version = True

deploy_parser.add_argument('--version', action=AnsibleVersion, nargs=0, help='show program\'s version number and exit')

# this is needed so that "-" is a valid inventory path (for stdin)

# Generated at 2022-06-24 17:36:36.144456
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    parser.parse_args()

# Test the function version

# Generated at 2022-06-24 17:36:38.794660
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser(description="")
    add_runtask_options(parser)


# Generated at 2022-06-24 17:36:41.516114
# Unit test for function add_runas_options
def test_add_runas_options():
    '''
    This unit test is for version()
    '''
    for _ in range(0, 100):
        test_case_0()


# Generated at 2022-06-24 17:36:44.033039
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser()
    add_output_options(parser)
    parser.parse_args('-t D -o D')


# Generated at 2022-06-24 17:36:46.091498
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_0 = SortingHelpFormatter()


# Generated at 2022-06-24 17:36:48.898419
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    try:
        test_case_0()
        test_results[0] = 0
    except:
        test_results[0] = 1


# Generated at 2022-06-24 17:37:06.124331
# Unit test for function add_async_options
def test_add_async_options():
    # Init parser
    parser = None
    # Init args
    args = None
    # Init result
    result = None

    # Check the case of positive test 0
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    args = parser.parse_args(['-P', '0', '-B', '1'])
    test_case_0()
    assert result == True


# Generated at 2022-06-24 17:37:09.313476
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()


# Generated at 2022-06-24 17:37:13.824543
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    a = SortingHelpFormatter()
    a.add_arguments()
    print('Execute the constructor of class SortingHelpFormatter')



# Generated at 2022-06-24 17:37:17.635176
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    formatter = SortingHelpFormatter()
    test_case_0()
    test_case_0()

#
# Parser for ansible-playbook and ansible-pull
#


# Generated at 2022-06-24 17:37:19.287944
# Unit test for function unfrack_path
def test_unfrack_path():
    # FIXME: This can be further improved as test cases.
    assert unfrack_path.__doc__ is not None


# Generated at 2022-06-24 17:37:26.967426
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_async_options(parser)
    print(parser.parse_args())

if __name__ == "__main__":
    test_case_0()
    test_add_async_options()
    # test_add_async_options()

# Generated at 2022-06-24 17:37:34.438066
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = argparse.ArgumentParser()
    var_2 = AnsibleVersion()
    var_3 = [ansible.__version__, 'unknown']
    var_4 = 'ansible'
    var_1.add_argument('--version', '-v', action=var_2, version=var_3)
    var_5 = var_1.parse_args([var_4, '--version'])
    var_6 = sys.exit()
    assert var_5 is not None
    return True


# Generated at 2022-06-24 17:37:43.612957
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-24 17:37:44.028644
# Unit test for function unfrack_path
def test_unfrack_path():
    pass


# Generated at 2022-06-24 17:37:47.347042
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value = "test"
    beacon = "test"
    expect = "test"
    result = maybe_unfrack_path(beacon)
    assert result == expect


# Generated at 2022-06-24 17:38:06.800596
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", action = AnsibleVersion)

    args = parser.parse_args("-v".split())

    # Line 0
    # Test 1
    print("Test 1: __call__()")
    var_0 = os.path.join()
    print("type(var_0): " + str(type(var_0)))
    print("var_0: " + str(var_0))
    var_1 = version()
    print("type(var_1): " + str(type(var_1)))
    print("var_1: " + str(var_1))
    if (var_0 == var_1):
        print("Test 1 passed")
        print("")
    else:
        print("Test 1 failed")
       

# Generated at 2022-06-24 17:38:09.971463
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    SortingHelpFormatter()
    #TODO: write test


# Generated at 2022-06-24 17:38:17.653769
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_4 = AnsibleVersion()
    var_3 = argparse.ArgumentParser()
    var_3.add_argument("-v", "--version", dest="version", action="store_true", default=False, help="show program's version number and exit")
    var_6 = argparse.Namespace()
    var_6.ansible_version = None
    var_6.version = True
    var_6.module_args = None
    var_6.extra_vars = None
    var_6.json = None
    var_6.module_paths = None
    var_6.module_name = None
    var_6.tqm_data = None
    var_6.tree = None
    var_6.forks = None
    var_6.ask_vault_pass = None
   

# Generated at 2022-06-24 17:38:23.985981
# Unit test for function ensure_value
def test_ensure_value():
    # Define 'parser' which is used in ensure_value function
    parser = argparse.ArgumentParser(description='Ansible')
    parser.add_argument('--dummy_arg', dest='dummy_arg', default='default_value', help='Dummy argument')

    # Create AnsibleOptions object
    ansible_options = AnsibleOptions()
    ansible_options.parse()
    assert ansible_options.ansible_path == 'ansible'

    # Test ensure_value function
    assert ensure_value(ansible_options, 'dummy_arg', 'default_value') == 'default_value'



# Generated at 2022-06-24 17:38:35.784467
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    #pass
    samples = [
        #(unfrack_path(), ["foo.cfg"], "bar.cfg"),
        #(unfrack_path(pathsep='/'), ["foo.cfg"], "bar.cfg"),
        (maybe_unfrack_path("/"), "/foo.cfg", "bar.cfg"),
    ]

    for sample in samples:
        var_0, var_1, var_2 = sample
        print("\t", var_0, var_1, var_2)
        #assert var_0(var_1) == var_2
        break


# Generated at 2022-06-24 17:38:42.353453
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    import ansible.cli
    var_0 = AnsibleVersion()
    var_1 = SortingHelpFormatter()
    var_1.add_arguments(var_0)


# Generated at 2022-06-24 17:38:48.877689
# Unit test for function unfrack_path
def test_unfrack_path():
    # Path to playbook.yml for running tests
    test_path = 'ansible-test/test/units/modules/test_playbook.yml'
    # Path as it would be from ansible-playbook
    path_from_playbook = 'ansible-test/test/units/modules/test_playbook.yml'

    # Test when input = None
    assert unfrack_path()(None) == None

    # Test when path is only the script name
    assert unfrack_path()(test_path) == path_from_playbook

    # Test when path is only the path
    assert unfrack_path()('ansible/test/units/modules') == 'ansible/test/units/modules'


# Generated at 2022-06-24 17:38:53.292851
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    from ansible.config.manager import ConfigManager
    my_config = ConfigManager()

    # This is how you create a config variable to be added to the command line
    my_config.set_config_value('some_var', 'hello')
    assert my_config['some_var'] == 'hello'


# Generated at 2022-06-24 17:38:55.566243
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = 'ansible/test/data/inventory'
    assert var_1 == unfrack_path()(var_1)


# Generated at 2022-06-24 17:38:56.822514
# Unit test for function unfrack_path
def test_unfrack_path():
    assert(unfrack_path()("test") == "test")


# Generated at 2022-06-24 17:39:16.826053
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    o = SortingHelpFormatter()


# Generated at 2022-06-24 17:39:19.130851
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test case for when the value starts with beacon
    var_0 = maybe_unfrack_path('/etc/ansible/')
    assert var_0('/etc/ansible/test') == '/etc/ansible/test'

# Generated at 2022-06-24 17:39:24.141801
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()

# Generated at 2022-06-24 17:39:28.648400
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Test good
    test_case_0()
    # BAD_CALL_MSG = "method __call__ of class AnsibleVersion called with wrong number of parameters"
    # try:
    #     parser.AnsibleVersion.__call__()
    # except Exception as e:
    #     assert(e.args[0] == BAD_CALL_MSG)



# Generated at 2022-06-24 17:39:38.797897
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = SortingHelpFormatter()
    var_1 = "ansible"
    var_2 = var_0.add_arguments(var_1)
    var_3 = "ansible"
    var_4 = var_0.add_arguments(var_3)
    var_5 = "ansible"
    var_6 = var_0.add_arguments(var_5)
    var_7 = "ansible"
    var_8 = var_0.add_arguments(var_7)
    var_9 = "ansible"
    var_10 = var_0.add_arguments(var_9)
    var_11 = "ansible"
    var_12 = var_0.add_arguments(var_11)
    var_13 = "ansible"
    var_

# Generated at 2022-06-24 17:39:39.597897
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    test_case_0()


# Generated at 2022-06-24 17:39:40.937875
# Unit test for function version
def test_version():
    # TODO: Implement test_version
    pass

# Generated at 2022-06-24 17:39:48.247396
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print("Test __call__ method of class AnsibleVersion")

    ansible_version = sys.version_info
    if ansible_version[0] >= 3:
        raw_input = input
    else:
        raw_input = raw_input

    ansible_version = __version__
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()
    


# Generated at 2022-06-24 17:39:52.669215
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('"')
    assert var_1("\"/usr/local/bin/ansible") == '"/usr/local/bin/ansible'


# Generated at 2022-06-24 17:39:53.619909
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_0 = SortingHelpFormatter()

# Generated at 2022-06-24 17:40:32.690371
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # inputs
    argparse.Action.__call__.__dict__.__setitem__('stypy_localization', localization)
    argparse.Action.__call__.__dict__.__setitem__('stypy_type_of_self', type_of_self)
    argparse.Action.__call__.__dict__.__setitem__('stypy_type_store', module_type_store)
    argparse.Action.__call__.__dict__.__setitem__('stypy_function_name', 'argparse.Action.__call__')
    argparse.Action.__call__.__dict__.__setitem__('stypy_param_names_list', ['parser', 'namespace', 'values', 'option_string'])
    argparse.Action.__call__.__dict

# Generated at 2022-06-24 17:40:37.463891
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = "@"
    value = "@/home/vagrant/ansible/examples/files"
    func = maybe_unfrack_path(beacon)
    assert func(value) is not None

# Helper function for unit test for function maybe_unfrack_path

# Generated at 2022-06-24 17:40:44.926562
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    here = os.path.abspath(os.path.dirname(__file__))
    here = here.replace(os.path.sep, '/')
    path = here + "/unfrack_path.py"
    var = maybe_unfrack_path(beacon='@')(path)
    assert var == '@' + path


# Generated at 2022-06-24 17:40:57.374001
# Unit test for function unfrack_path
def test_unfrack_path():
    os.environ['ANSIBLE_ROLES_PATH'] = '/tmp/roles:/tmp/has_no_roles'

    assert unfrack_path()('/tmp') == '/tmp'
    assert unfrack_path(pathsep=True)('/tmp:/tmp') == ['/tmp', '/tmp']
    assert unfrack_path()('~/foobar') == os.path.join(os.path.expanduser('~'), 'foobar')
    assert unfrack_path()('playbook.yml') == os.path.join(os.getcwd(), 'playbook.yml')
    assert unfrack_path()('relative/path/to/playbook.yml') == os.path.join(os.getcwd(), 'relative/path/to/playbook.yml')
    assert unfrack_path()

# Generated at 2022-06-24 17:41:02.217461
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_0 = SortingHelpFormatter(formatter_class=argparse.ArgumentDefaultsHelpFormatter, width=100)

# Generated at 2022-06-24 17:41:04.237212
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()()
    try:
        assert var_0 == var_1
    except AssertionError as e:
        print ("AssertionError: %s" % e)


# Generated at 2022-06-24 17:41:06.113299
# Unit test for function version
def test_version():
    import platform

    result = version("%s %s" % (platform.system(), platform.release()))
    assert result is not None


# Generated at 2022-06-24 17:41:18.754401
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():

    test_parser = argparse.ArgumentParser(formatter_class= SortingHelpFormatter)

    test_parser.add_argument('-v', '--verbose')
    test_parser.add_argument('-q', '--quiet')
    test_parser.add_argument('-d', '--def')
    test_parser.add_argument('-a', '--abc')
    test_parser.add_argument('-x', '--xyz')

    test_args = test_parser.parse_args()

    print("Argument values:")
    print("Verbose: ", test_args.verbose)
    print("Quiet: ", test_args.quiet)

# Generated at 2022-06-24 17:41:21.166242
# Unit test for function version
def test_version():
    # Check position args
    assert version() == version_check_0()
    # Check named args
    assert version(prog='sample_prog') == version_check_1()


# Generated at 2022-06-24 17:41:22.869214
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('str_1')


# Generated at 2022-06-24 17:42:30.741284
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = '-m ping -vvvv'
    var_1 = unfrack_path()(var_1)
    print(var_1)


# Generated at 2022-06-24 17:42:33.226173
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = unfrack_path()
    test_case_0()


# Generated at 2022-06-24 17:42:35.451215
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print("Test: AnsibleVersion.__call__()")
    print("Method __call__ not implemented yet.")
    return



# Generated at 2022-06-24 17:42:36.094075
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    args = parser.parse_args()

# Generated at 2022-06-24 17:42:46.996089
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = '-'
    var_2 = maybe_unfrack_path(var_1)
    var_3 = var_1
    var_6 = var_2(var_3)
    var_4 = '-'
    var_5 = var_4
    assert var_6 == var_5


# Generated at 2022-06-24 17:42:49.641658
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version = AnsibleVersion()
    version.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-24 17:42:58.671080
# Unit test for function unfrack_path
def test_unfrack_path():

    # Setup test values
    value = ''
    pathsep = False

    # Invoke method
    var_0 = unfrack_path(pathsep)
    var_0(value)


# Generated at 2022-06-24 17:43:04.887291
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = "test_strings"
    for i in range(0, 100):
        # If the beacon starts with prefix, call the function
        if var_0.startswith(''):
            maybe_unfrack_path('')(var_0)
    print('Done')

#
# Functions to build Options
#



# Generated at 2022-06-24 17:43:07.480048
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = AnsibleVersion()
    var_1 = var_0.__call__(parser, namespace, values, option_string=None)


# Generated at 2022-06-24 17:43:10.290518
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('/')
    assert isinstance(var_1, type(lambda x: x))
