

# Generated at 2022-06-24 17:33:57.787455
# Unit test for function add_runas_options
def test_add_runas_options():
    root = Tk()
    # root.wm_title("Add runas options")
    frame = Frame(root)
    frame.pack()

    label_0 = Label(frame, text="Args: ")
    label_0.pack(side=LEFT, padx=5, pady=5)
    entry_0 = Entry(frame, width=80)
    entry_0.pack(side=LEFT, padx=5, pady=5)

    def show_details():
        entry_0_string = entry_0.get()
        var_0 = add_runas_options(entry_0_string)
        messagebox.showinfo(title="Output", message=var_0)
        return

    button = Button(frame, text="Submit", command=show_details)

# Generated at 2022-06-24 17:34:03.171576
# Unit test for function add_output_options
def test_add_output_options():
    str_a = "vXg(!/7F+'OP0h"
    assert add_output_options(str_a) == None


# Generated at 2022-06-24 17:34:11.134914
# Unit test for function add_meta_options
def test_add_meta_options():
    #arg_0 = "vXg(!/7F+'OP0h"
    #arg_1 = "vXg(!/7F+'OP0h"
    #arg_2 = "vXg(!/7F+'OP0h"
    import argparse

    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args("-vvvv --force-handlers --flush-cache".split())
    assert args.verbosity == 4
    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-24 17:34:20.636739
# Unit test for function add_meta_options
def test_add_meta_options():
    arg0 = parser = argparse.ArgumentParser(
        prog="test_prog",
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )

    try:
        add_meta_options(arg0)
    except Exception as e:
        assert False, "dotest failed when call function add_meta_options"



# Generated at 2022-06-24 17:34:24.084544
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    # Assert if add_runas_prompt_options(None, str_0) == ansible.module_utils.basic.AnsibleModule(argument_spec={'become_ask_pass': {'type': 'bool', 'default': True}, 'become_password_file': {'action': 'store', 'type': 'path'}}, supports_check_mode=False)
    pass


# Generated at 2022-06-24 17:34:38.113178
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser(prog='ansible-console')
    runas_group = parser.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")

    # consolidated privilege escalation (become)
    runas_group.add_argument("-b", "--become", default=C.DEFAULT_BECOME, action="store_true", dest='become',
                             help="run operations with become (does not imply password prompting)")

# Generated at 2022-06-24 17:34:39.716016
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    try:
        str_0 = "N=x}0_9N8C"
        var_0 = add_runas_prompt_options(str_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:34:44.002122
# Unit test for function unfrack_path
def test_unfrack_path():
    str_0 = "F[h7V,8<;l|7qQ"
    var_0 = unfrack_path(str_0)
    print(var_0)


#
# AnsibleOptionParser
#

# Generated at 2022-06-24 17:34:47.880153
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    str_0 = "zN"
    str_1 = "U6"
    var_0 = maybe_unfrack_path(str_0)
    var_1 = var_0(str_1)


# Generated at 2022-06-24 17:34:48.987705
# Unit test for function add_runas_options
def test_add_runas_options():
    test_case_0()



# Generated at 2022-06-24 17:35:00.444563
# Unit test for function add_check_options
def test_add_check_options():
    test_case_0()


# Generated at 2022-06-24 17:35:03.698692
# Unit test for function add_basedir_options
def test_add_basedir_options():
    if expected_value != var_0:
        test_case_0()
    else:
        print("expected_value == var_0")



# Generated at 2022-06-24 17:35:05.697583
# Unit test for function add_connect_options
def test_add_connect_options():
    int_0 = 0
    var_0 = add_connect_options(int_0)


# Generated at 2022-06-24 17:35:09.500128
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    try:
        assert(maybe_unfrack_path(None) == None)
        assert(maybe_unfrack_path("") == None)
        assert(maybe_unfrack_path("Hello") == None)
        assert(maybe_unfrack_path("@IfNotPresent") == None)
        assert(maybe_unfrack_path("IfNotPresent") == None)
    except:
        assert(False)



# Generated at 2022-06-24 17:35:14.244907
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    args = parser.parse_args(" -i ~/Ansible/ansible/inventories/dev -l ent-vip -l ent-vip-cluster-1 -l ent-vip-cluster-2".split())
    assert('ent-vip-cluster-2' in args.subset)
    assert('ent-vip-cluster_2' in args.subset)


# Generated at 2022-06-24 17:35:18.118773
# Unit test for function version
def test_version():
    argv = ['']
    if len(argv) > 1 and argv[1] == '-h' or argv[1] == '--help':
        print(version())
        sys.exit(0)



# Generated at 2022-06-24 17:35:24.357588
# Unit test for function add_check_options
def test_add_check_options():
    # Try with a positive value
    int_1 = 773
    assert add_check_options(int_1) == None
    # Try with a negative value
    int_2 = -773
    assert add_check_options(int_2) == None
    # Try with a floating point value
    int_3 = 2.71828
    assert add_check_options(int_3) == None
    # Try with a non-number
    int_4 = 'hello'
    assert add_check_options(int_4) == None

# Generated at 2022-06-24 17:35:27.950293
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()



# Generated at 2022-06-24 17:35:28.879787
# Unit test for function add_fork_options
def test_add_fork_options():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:35:35.315603
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser_mock = argparse.ArgumentParser(prog="test_parser_prog")
    add_basedir_options(parser_mock)
    if not parser_mock.has_option('--playbook-dir'):
        return False
    if not parser_mock.get_argument_defauly('--playbook-dir') != ".":
        return False


# Generated at 2022-06-24 17:35:59.401990
# Unit test for function add_async_options
def test_add_async_options():
    int_0 = 758
    var_0 = add_async_options(int_0)


# Generated at 2022-06-24 17:36:02.516517
# Unit test for function add_async_options
def test_add_async_options():
    print("\nTesting function add_async_options")
    parser = create_base_parser("Ansible")
    add_async_options(parser)
    parser.print_help()

# Generated at 2022-06-24 17:36:07.374328
# Unit test for function add_subset_options
def test_add_subset_options():
    try:
        int_0 = -773
        var_0 = add_subset_options(int_0)
    except AssertionError: 
        assert True
    else:
        assert False


# Generated at 2022-06-24 17:36:09.755777
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    print('Testing __call__')
    print('TODO')


# Generated at 2022-06-24 17:36:13.136295
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        assert unfrack_path()(-773) == unfrackpath(-773)
    except:
        ()

# Generated at 2022-06-24 17:36:23.994710
# Unit test for function version

# Generated at 2022-06-24 17:36:29.671984
# Unit test for function add_check_options
def test_add_check_options():
    var_0 = -773
    var_0 = prepend_list_action (var_0)
    assert var_0.dest == -773

    var_0 = -773
    var_1 = list()
    var_1.append (1)
    var_0.dest = var_1
    var_0.choices = var_1
    var_0.help = var_1
    var_0.metavar = var_1
    var_0.option_strings = var_1
    var_0.required = var_1
    assert var_0.dest == [1]
    assert var_0.choices == [1]
    assert var_0.help == [1]
    assert var_0.metavar == [1]
    assert var_0.option_strings == [1]
   

# Generated at 2022-06-24 17:36:33.428742
# Unit test for function add_async_options
def test_add_async_options():
    print("testing for function add_async_options")
    parser = create_base_parser("test_prog")
    add_async_options(parser)
    
    
    
    

# Generated at 2022-06-24 17:36:42.681626
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    string_0 = "text_0"
    string_1 = "prefix_0"
    var_0 = maybe_unfrack_path(string_1)
    var_1 = var_0(string_0)
    assert var_1 == "text_0"

    string_2 = "prefix_0text_1"
    var_2 = var_0(string_2)
    assert var_2 == "prefix_0/home/user/.ansible/tmp/ansible-tmp-1566249726.6-207036496489370/tmp_0"


# Generated at 2022-06-24 17:36:55.585400
# Unit test for function unfrack_path
def test_unfrack_path():
    mtlf_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    mtlf_path = os.path.join(mtlf_path, "mtlf/")
    print(mtlf_path)
    var_1 = os.path.join(mtlf_path, "lib/ansible/module_utils/_text.py")
    print(var_1)
    var_0 = os.path.join(mtlf_path, "lib/ansible/module_utils/common/arguments.py")
    print(var_0)
    var_2 = os.path.join(mtlf_path, "lib/ansible/module_utils/common/text.py")

# Generated at 2022-06-24 17:37:08.663205
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('test_parser')
    add_runas_options(parser)
    options = parser.parse_args(['--become', 'true', '--become-method', 'su', '--become-user', 'admin'])
    assert options.become
    assert options.become_method == 'su'
    assert options.become_user == 'admin'


# Generated at 2022-06-24 17:37:15.747789
# Unit test for function unfrack_path
def test_unfrack_path():
    pathsep=True
    path = "C:/Users/weizeng/Documents/GitHub/rename_main.py"
    result = unfrack_path(pathsep)
    if result == path:
        print("test_unfrack_path: Success")
    else:
        print("test_unfrack_path: Failed")
    return result

#
# OptionParsers
#

# Generated at 2022-06-24 17:37:22.696291
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    # setup
    parser = create_base_parser(prog="ansible-playbook")
    add_tasknoplay_options(parser)
    cmdline = "-e a=b --extra-vars @a.yaml --extra-vars @b.json --extra-vars @c.yaml --extra-vars @d.json -vvvv"
    options = parser.parse_args(cmdline.split())
    options.extra_vars = [{"a":"b"}] # we have to fake this because we stubbed unfrack_path
    options.connection_password_file = None
    options.ssh_common_args = "opts"
    options.sftp_extra_args = "yopts"
    options.scp_extra_args = "gopts"
    options.ssh_extra_args

# Generated at 2022-06-24 17:37:27.681948
# Unit test for function add_check_options
def test_add_check_options():
    print("\n\n\n\n *********************** Running test case 0 *********************** \n\n")
    test_case_0()



# Generated at 2022-06-24 17:37:32.747350
# Unit test for function add_vault_options
def test_add_vault_options():
    # Create a parser
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser = add_vault_options(parser)

    # This is a YAML file used for testing
    test_file = '''$ANSIBLE_VAULT;1.1;AES256
3036333532633961636236656333363336656465363364366538643437323237313866623539383737
6561656166366330363834633561653636396233346430343962316132386233353130343861396436
3939653666366130653939386665666338353636616539
'''

    # Write data to a file

# Generated at 2022-06-24 17:37:37.803852
# Unit test for function add_vault_options
def test_add_vault_options():
    """ Tests the add_vault_options function """
    # Start with example from Ansible
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/cli/__init__.py

    import argparse
    from ansible.parsing.dataloader import DataLoader

    # initialize
    parser = argparse.ArgumentParser()

    # arguments
    parser.add_argument('-i', '--inventory', '--inventory-file', dest='inventory', action="append",
                        help="specify inventory host path or comma separated host list. --inventory-file is deprecated")
    # add vault_id
    parser.add_argument('--vault-id', default='', dest='vault_ids', action='append', type=str,
                        help='the vault identity to use')
    # add

# Generated at 2022-06-24 17:37:43.189365
# Unit test for function ensure_value
def test_ensure_value():
    var_1 = int()
    var_2 = float()
    var_3 = str()
    var_1 = 5
    var_2 = 5.0
    var_3 = "test"
    var_1 = add_check_options(var_1)
    var_2 = add_check_options(var_2)
    var_3 = add_check_options(var_3)
    print("Unit test for function ensure_value passed")


# Generated at 2022-06-24 17:37:49.956949
# Unit test for function add_check_options
def test_add_check_options():
    # Case 0 : test type
    int_0 = -773
    with pytest.raises(TypeError):
        var_0 = add_check_options(int_0)

    # Case 1 : test argument
    parser_1 = argparse.ArgumentParser()
    var_1 = add_check_options(parser_1)
    assert var_1 is None


# Generated at 2022-06-24 17:37:54.123043
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = create_base_parser('test')
    add_subset_options(parser)
    args = parser.parse_args(['-t', 'test'])
    assert args.tags == ['test']
    args = parser.parse_args(['--skip-tags', 'test'])
    assert args.skip_tags == ['test']


# Generated at 2022-06-24 17:37:59.620059
# Unit test for function add_check_options
def test_add_check_options():
    try:
        test_case_0()
    except SyntaxError:
        var_1 = True
    else:
        var_1 = False
    assert var_1


# Generated at 2022-06-24 17:38:10.168789
# Unit test for function version
def test_version():
    version_str = version("unit_test")
    assert version_str == 'unit_test [core 2.10.3]'


# Generated at 2022-06-24 17:38:13.343883
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        assert unfrack_path() == None
        assert unfrack_path()
    except AssertionError:
        print("Test Failed")
        traceback.print_exc()
        sys.exit(1)


# Generated at 2022-06-24 17:38:16.432056
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    int_0 = -773
    var_0 = PrependListAction(int_0)

# Generated at 2022-06-24 17:38:20.320755
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    int_1 = -39
    var_1 = maybe_unfrack_path(beacon=int_1)
    var_2 = var_1(value=79)
    print(var_2)


# Generated at 2022-06-24 17:38:21.561146
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    SortingHelpFormatter()


# Generated at 2022-06-24 17:38:26.026367
# Unit test for function ensure_value
def test_ensure_value():
    var_0 = ensure_value(sys.modules[__name__], 'int_0', -773)
    print(var_0)
    var_1 = ensure_value(sys.modules[__name__], 'int_1', 956)
    print(var_1)


# Generated at 2022-06-24 17:38:27.625932
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    int_0 = -773
    var_0 = add_check_options(int_0)


# Generated at 2022-06-24 17:38:30.163168
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(-773) == -773


#
# Helpers for producing OptionGroups
#

# Generated at 2022-06-24 17:38:33.735491
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print("Testing function maybe_unfrack_path...")
    int_0 = 0
    int_1 = 1
    assert maybe_unfrack_path(int_0) == maybe_unfrack_path(int_1)
    print("maybe_unfrack_path passed the test.")


# Generated at 2022-06-24 17:38:36.666877
# Unit test for function unfrack_path
def test_unfrack_path():
    int_0 = -839
    var_0 = unfrack_path_0(int_0)


# Generated at 2022-06-24 17:38:44.872681
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert type(SortingHelpFormatter) is type, "Unit test for constructor of class SortingHelpFormatter"
    test_case_0()


# Generated at 2022-06-24 17:38:49.515547
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = "~/.aws/credentials"
    expected_0 = var_1
    actual_0 = unfrackpath(var_1)
    assert expected_0 == actual_0, 'Expected %s, got %s' % (expected_0, actual_0)


# Generated at 2022-06-24 17:38:54.871366
# Unit test for function unfrack_path
def test_unfrack_path():
    path_0 = '/Users/kevin/source/devops/ansible/module_utils/module_docs_fragments/module_meta.py'
    res_0 = unfrack_path(path_0)
    assert res_0 == '/Users/kevin/source/devops/ansible/module_utils/module_docs_fragments/module_meta.py'



# Generated at 2022-06-24 17:39:04.105517
# Unit test for function unfrack_path

# Generated at 2022-06-24 17:39:06.176345
# Unit test for function version
def test_version():
    print("Test for version()")
    assert version() == to_native(version()) == '2.9.6'


# Generated at 2022-06-24 17:39:07.527256
# Unit test for function unfrack_path
def test_unfrack_path():
    assert(unfrack_path()('') == '')


# Generated at 2022-06-24 17:39:18.838320
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    p1 = "/home/user/.ansible"
    p2 = "/usr/share/ansible/roles/foo"
    p3 = "~/.ansible/roles/foo"
    p4 = "~/myplaybook"
    p5 = "/home/user/myplaybook"
    p6 = "relative/path"
    p7 = "myplay"

    # run the test
    maybe_unfrack_path('/home/user/.ansible', p1)
    maybe_unfrack_path('/usr/share/ansible/roles/foo', p2)
    maybe_unfrack_path('~/.ansible/roles/foo', p3)
    maybe_unfrack_path('~/myplaybook', p4)

# Generated at 2022-06-24 17:39:22.604205
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    obj = SortingHelpFormatter()
    obj.add_argument('-S', help='sort by order')


# Generated at 2022-06-24 17:39:24.984578
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('identity') == 'identity'


# Generated at 2022-06-24 17:39:28.331544
# Unit test for function unfrack_path
def test_unfrack_path():
    # test value for unfrack_path
    var_0 = version(sys.argv[0])
    # pass value from var_0 to test case
    assert(test_case_0() == var_0)

#
# Option checks and parsers
#

# Generated at 2022-06-24 17:39:42.355777
# Unit test for function unfrack_path
def test_unfrack_path():
    output = unfrack_path("test_data/test_case_0")
    assert output == "test_data/test_case_0"


# Generated at 2022-06-24 17:39:44.636689
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # TODO: Add unit test
    pass
    

# Generated at 2022-06-24 17:39:47.193353
# Unit test for function unfrack_path
def test_unfrack_path():
    func = lambda pathsep=False : inner(value)
    assert func() != None


# Generated at 2022-06-24 17:39:49.879747
# Unit test for function version
def test_version():
    var_1 = version()
    assert var_1 == "2.1.1.0"

# Generated at 2022-06-24 17:39:53.076758
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    ret = maybe_unfrack_path("beacon")
    ret("beacon/tmp/")
    ret("beacon/")


# Generated at 2022-06-24 17:39:56.607429
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = '/ansible/test/path'
    var_1 = unfrack_path(True)(var_1)
    var_2 = '/ansible/test/path'
    assert var_1 == var_2


# Generated at 2022-06-24 17:39:58.729962
# Unit test for function unfrack_path
def test_unfrack_path():
    # Create args
    # Call function
    result = unfrack_path()
    # Verify the result
    assert result is not None


# Generated at 2022-06-24 17:40:08.173206
# Unit test for function unfrack_path
def test_unfrack_path():
    # perpare for the test
    # if version() != "version 2.6.3(default, Oct  3 2018, 21:57:14) \n[GCC 7.3.0]":
    #     test_case_0()
    #     assert False

    # execute the test
    actual = unfrack_path()(None)

    # verify the result
    assert actual == None


# Generated at 2022-06-24 17:40:11.140864
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    try:
        sut = argparse.HelpFormatter()
        assert False
    except:
        assert True



# Generated at 2022-06-24 17:40:15.787771
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    try:
        SortingHelpFormatter()
    except Exception:
        print("Exception when calling constructor of class SortingHelpFormatter")


# Generated at 2022-06-24 17:40:44.383627
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    try:
        assert maybe_unfrack_path(beacon='@test')==maybe_unfrack_path(beacon='@test')
    except AssertionError as e:
        print('AssertionError:', e)
        raise
    else:
        print("Test test_maybe_unfrack_path passed.")


# Generated at 2022-06-24 17:40:51.317723
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    assert(maybe_unfrack_path(b'/home/')=='/home/')
    assert(maybe_unfrack_path(b'/home')=='/home')
    assert(maybe_unfrack_path(b'/home/')=='/home/')
    assert(maybe_unfrack_path(b'/home')=='/home')
    assert(maybe_unfrack_path(b'/home')=='/home')
    assert(maybe_unfrack_path(b'/home/')=='/home/')
    assert(maybe_unfrack_path(b'/home')=='/home')


# Generated at 2022-06-24 17:41:04.141654
# Unit test for function ensure_value
def test_ensure_value():
    # Test with default value
    test_var = ensure_value(None, 'test_var', 0)
    assert test_var == 0, "Ensure_value failed to set the default value"

    # Test with a new value (overwrites default value)
    new_var = 1
    test_var = ensure_value(None, 'test_var', new_var)
    assert test_var == new_var, "Ensure_value failed to overwrite the default value"

    # Test with a new value (overwrites previous value)
    new_var = 2
    test_var = ensure_value(None, 'test_var', new_var)
    assert test_var == new_var, "Ensure_value failed to overwrite the previous value"

    # Test with another new value (overwrites previous value)

# Generated at 2022-06-24 17:41:07.912750
# Unit test for function unfrack_path
def test_unfrack_path():
    dict = { "key_test": "123" }
    for i in range(100):
        test_case_0()
        #if isinstance(dict[i], (frozenset, list, set, tuple, dict, str)):
        if isinstance(dict['key_test'], (str)):
            pass
        else:
            raise TypeError('data type error')
    return True

#
# Compute ansible version from __init__.py to avoid dependency problems
#

# Generated at 2022-06-24 17:41:19.447430
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-24 17:41:29.759894
# Unit test for function unfrack_path
def test_unfrack_path():
    cmdline = sys.argv
    # Capture arguments for later processing
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version=__version__)
    parser.add_argument('--version-check', '--check', action=UnrecognizedArgument, nargs=0)
    parser.add_argument('--debug', default=False, action='store_true',
                        help='Show tracebacks on errors')
    parser.add_argument('-v', '--verbose', default=0, action='count', dest='verbosity')
    parser.add_argument('--vvv', dest='verbosity', action='append_const', const=4,
                        help='Show more verbose output')

# Generated at 2022-06-24 17:41:32.642577
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        result = unfrack_path()
    except Exception as e:
        print("Uncaught exception when calling 'unfrack_path'")
        raise
    else:
        print("Function 'unfrack_path' called successfully")
        return



# Generated at 2022-06-24 17:41:41.556083
# Unit test for function unfrack_path
def test_unfrack_path():
    pathsep=True
    expected = [unfrackpath(x) for x in value.split(os.pathsep) if x]
    actual = inner(value)
    #print (expected)
    #print (actual)
    assert expected == actual
    pathsep=False
    if value == '-':
        expected = value
    else:
        expected = unfrackpath(value)
    actual = inner(value)
    #print (expected)
    #print (actual)
    assert expected == actual


# Generated at 2022-06-24 17:41:43.194758
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()


# Generated at 2022-06-24 17:41:45.868694
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path("string")

# Generated at 2022-06-24 17:42:27.265011
# Unit test for function unfrack_path
def test_unfrack_path():
    var_3 = version()
    var_4 = version()
    var_5 = version()
    var_6 = version()
    var_7 = version()
    var_8 = version()
    var_9 = version()
    var_10 = version()
    var_11 = version()
    var_12 = version()
    var_13 = version()
    var_14 = version()
    var_15 = version()
    var_16 = version()
    var_17 = version()
    var_18 = version()
    var_19 = version()
    var_20 = version()
    var_21 = version()
    var_22 = version()
    var_23 = version()
    var_24 = version()
    var_25 = version()
    var_26 = version()
    var_27 = version()

# Generated at 2022-06-24 17:42:31.923792
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    pass
    # try:
    #     var_0 = maybe_unfrack_path( ' ' )
    #     # assert var_0 == ' ', "maybe_unfrack_path returns wrong value"
    # except AssertionError as ae:
    #     print(ae)
    # except Exception as e:
    #     print(e)


# Generated at 2022-06-24 17:42:36.390033
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = defaultdict(lambda : None, {'foo': 'bar'})
    with patch.multiple(__builtin__, open=DEFAULT, print_function=DEFAULT, raw_input=DEFAULT):
        var_0 = unfrack_path()


#
# Parsers
#

# Generated at 2022-06-24 17:42:50.822955
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    Test_cases = [
        ('/usr/local', '/usr/local'),
        ('~/Desktop', '~/Desktop')
    ]
    for test_case_0 in Test_cases:
        print("Input: ", test_case_0[0])
        print("Output: ", maybe_unfrack_path("~")(test_case_0[0]))
        print("Expected: ", test_case_0[1])
        if maybe_unfrack_path("~")(test_case_0[0]) != test_case_0[1]:
            print("Failure")


# Generated at 2022-06-24 17:42:55.985815
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()
    assert var_1 == ""


# Generated at 2022-06-24 17:43:04.458700
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value = '--version'
    beacon = '-'
    func_return = maybe_unfrack_path(beacon)
    func_return = func_return(value)
    assert func_return == '--version'


# Generated at 2022-06-24 17:43:05.787090
# Unit test for function unfrack_path
def test_unfrack_path():
    print(unfrack_path())



# Generated at 2022-06-24 17:43:10.414688
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test case 0
    var_0 = maybe_unfrack_path("vaulted")
    var_1 = var_0("vaulted-hogehoge")
    assert var_1 == "vaulted-hogehoge"


# Generated at 2022-06-24 17:43:12.124039
# Unit test for function unfrack_path
def test_unfrack_path():
    """Test if function unfrack_path can pass"""
    # Test case 0
    test_case_0()

#
# Command Line Parser Generation
#

# Generated at 2022-06-24 17:43:14.992797
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path('/usr/bin') == '/usr/bin'
