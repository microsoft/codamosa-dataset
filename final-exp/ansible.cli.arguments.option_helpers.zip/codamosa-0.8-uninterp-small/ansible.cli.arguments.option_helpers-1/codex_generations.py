

# Generated at 2022-06-24 17:33:55.298895
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    add_inventory_options(parser)
    arg_list = '-i --inventory --inventory-file -l --limit --list-hosts'.split()
    args = parser.parse_args(arg_list)

    # Check for required arguments
    for arg in [args.inventory, args.listhosts, args.subset]:
        assert arg != None


# Generated at 2022-06-24 17:34:00.560152
# Unit test for function add_vault_options
def test_add_vault_options():
    log.info("Unit Test for function add_vault_options")
    try:
        parser = argparse.ArgumentParser()
        add_vault_options(parser)
        test_case_1()
    except NameError:
        log.exception(NameError)
    except BaseException as e:
        log.exception(e)

# Generated at 2022-06-24 17:34:04.934766
# Unit test for function add_module_options
def test_add_module_options():
    parser = None
    
    # Testing function with parser as parameter.

    # Testing function with parser as parameter.

    # Testing function with parser as parameter.


    assert (add_module_options(parser) == None)



# Generated at 2022-06-24 17:34:14.454836
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser()

    int_0 = 896
    add_runas_prompt_options(parser, int_0)

    assert_equal(str(parser.parse_args('--ask-become-pass --become-password-file=become_password_file'.split())), "Namespace(ask_become_pass=True, become_password_file='become_password_file')")
    assert_equal(str(parser.parse_args('--ask-become-pass'.split())), "Namespace(ask_become_pass=True, become_password_file=None)")

# Generated at 2022-06-24 17:34:20.636525
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser(prog='ansible',usage='ansible <host-pattern> [options]',conflict_handler='resolve')
    add_meta_options(parser)
    namespace = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert namespace.flush_cache
    assert namespace.force_handlers


# Generated at 2022-06-24 17:34:22.827971
# Unit test for function add_module_options
def test_add_module_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )
    add_module_options(parser)
    args = parser.parse_args()



# Generated at 2022-06-24 17:34:23.533928
# Unit test for function version
def test_version():
    result = version()
    assert result




# Generated at 2022-06-24 17:34:30.700803
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test path starts with beacon
    path = unfrackpath('/usr/local/bin')
    real_path = maybe_unfrack_path('@')(path)
    assert real_path == '@' + path

    # Test path does not start with beacon
    path = unfrackpath('/usr/local/bin')
    real_path = maybe_unfrack_path('@')(path)
    assert real_path == path


# Generated at 2022-06-24 17:34:35.400068
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    float_1 = -1435.19
    var_1 = maybe_unfrack_path(float_1)
    assert var_1(float_1) == -1435.19


# Generated at 2022-06-24 17:34:44.357097
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = TestParser()
    parser.add_argument('--private-key', '--key-file', default=C.DEFAULT_PRIVATE_KEY_FILE, dest='private_key_file',
                       help='use this file to authenticate the connection', type=unfrack_path())
    parser.add_argument('-u', '--user', default=C.DEFAULT_REMOTE_USER, dest='remote_user',
                       help='connect as this user (default=%s)' % C.DEFAULT_REMOTE_USER)
    parser.add_argument('-c', '--connection', dest='connection', default=C.DEFAULT_TRANSPORT,
                       help="connection type to use (default=%s)" % C.DEFAULT_TRANSPORT)

# Generated at 2022-06-24 17:35:00.806420
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(0) == 0


# Generated at 2022-06-24 17:35:02.305984
# Unit test for function unfrack_path
def test_unfrack_path():
    assert True


# Generated at 2022-06-24 17:35:05.185882
# Unit test for function add_connect_options
def test_add_connect_options():
    result = add_connect_options(create_base_parser('/usr/bin/ansible'))
    assert result is None



# Generated at 2022-06-24 17:35:11.706994
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)

# Generated at 2022-06-24 17:35:12.253346
# Unit test for function add_runas_options
def test_add_runas_options():
    test_case_0()



# Generated at 2022-06-24 17:35:13.922454
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    #var_0 = parser.parse_args(['--extra-vars', '@test.yml'])

test_case_0()
test_add_runtask_options()

# Generated at 2022-06-24 17:35:23.984985
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = [1, 2, 3, 4]
    var_2 = [1, 2, 3, 4, 5]
    var_3 = [1, 2, 3, 4]
    var_4 = [1, 2, 3, 4, 5]
    var_5 = [1, 2, 3, 4]
    var_6 = [1, 2, 3]
    var_7 = [1, 2, 3, 4]
    var_8 = [1, 2, 3, 4, 5]
    var_9 = [1, 2, 3, 4]
    var_10 = [1, 2, 3, 4, 5]
    var_11 = [1, 2, 3, 4]
    var_12 = [1, 2, 3, 4, 5]

# Generated at 2022-06-24 17:35:32.154248
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = AnsibleVersion()
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible-playbook'
    namespace = argparse.Namespace()
    try :
        parser.add_argument('--version', '-v', action=AnsibleVersion, help='show program\'s version number and exit')
    except Exception as e:
        print("[FAILED] test_AnsibleVersion___call__ raises exception: " + repr(e))


# Generated at 2022-06-24 17:35:38.536504
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser("test")
    add_runas_options(parser)
    args = parser.parse_args(["test"])
    assert args.become == False
    assert args.become_method == "sudo"
    assert args.become_user == None
    assert args.ask_pass == False
    assert args.become_ask_pass == False


# Generated at 2022-06-24 17:35:42.091112
# Unit test for function unfrack_path
def test_unfrack_path():
    path = '/var/ansible/ansible/test/test'
    assert_equals(unfrackpath(path), '/var/ansible/ansible/test/test')


# Generated at 2022-06-24 17:35:52.640200
# Unit test for function version
def test_version():
    assert version() == "test_version [core 2.0.0.0]"

if __name__ == "__main__":
    import __main__
    import sys
    def main():
        print(version(__main__.__file__))
    if sys.argv[1] == 'test_version':
        test_version()
    main()

# Generated at 2022-06-24 17:35:55.302246
# Unit test for function ensure_value
def test_ensure_value():
    assert(ensure_value("test_string", "value", "name") == "test_string")
    assert(ensure_value("test_string", "value", "name") == "test_string")


# Generated at 2022-06-24 17:35:59.724268
# Unit test for function add_check_options
def test_add_check_options():
    var_0 = create_base_parser(prog = 'foo')
    add_check_options(var_0)
    var_0.print_help()


# Generated at 2022-06-24 17:36:06.694142
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser("ansible-playbook")
    add_check_options(parser)
    args = parser.parse_args(["--check"])
    assert args.check == True

    parser2 = create_base_parser("ansible-playbook")
    add_check_options(parser2)
    args2 = parser2.parse_args(["--syntax-check"])
    assert args2.syntax == True

    parser3 = create_base_parser("ansible-playbook")
    add_check_options(parser3)
    args3 = parser3.parse_args(["--diff"])
    assert args3.diff == True






# Generated at 2022-06-24 17:36:15.226807
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
  print(sys.argv)
  beacon = 'beacon'
  value = 'value'
  maybe_unfrack_path(beacon)
  #'If the first condition is true: assign to the var  var_0  the values of var  beacon + unfrackpath(var  value[1:]  )  .'
  #'Else: assign to the var  var_0  the values of var  value  .'
  var_0 = value
  print(var_0)
  return var_0


# Generated at 2022-06-24 17:36:20.105689
# Unit test for function unfrack_path
def test_unfrack_path():
    res_0 = unfrack_path(pathsep=False)
    res_1 = unfrack_path(pathsep=True)



# Generated at 2022-06-24 17:36:21.241543
# Unit test for function unfrack_path
def test_unfrack_path():
    assert os.path.isdir(unfrack_path())==0

#
# Option Groups
#

# Generated at 2022-06-24 17:36:31.774805
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()
    var_0('/home/vagrant/.ansible')
    var_0('/home/vagrant/.ansible/plugins')
    var_0('/home/vagrant/.ansible/plugins/callback')
    var_0('/home/vagrant/.ansible/plugins/callback/pytest.py')
    var_0('/home/vagrant/.ansible/plugins/callback/pytest.py:/home/vagrant/.ansible/plugins/callback/stdout.py')
    var_0('/home/vagrant/.ansible/plugins/callback/pytest.py:/home/vagrant/.ansible/plugins/callback/stdout.py:/home/vagrant/.ansible/plugins/callback/timer.py')

# Generated at 2022-06-24 17:36:34.280286
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=False)() == ''

#
# Option logics
#

# Generated at 2022-06-24 17:36:40.189961
# Unit test for function version
def test_version():
    assert True

if __name__ == '__main__':
    import cProfile
    cProfile.run('test_case_0()', 'restats')
    import pstats
    p = pstats.Stats('restats')
    p.strip_dirs().sort_stats('name').print_stats()
    p.strip_dirs().sort_stats('cumulative').print_stats()
    p.strip_dirs().sort_stats('time').print_stats()

    # Unit test
    test_version()

# Generated at 2022-06-24 17:36:50.759105
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()
    assert isinstance(var_0, type(maybe_unfrack_path()))


# Generated at 2022-06-24 17:36:51.953276
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_case_0()

# Generated at 2022-06-24 17:36:56.629697
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_1 = SortingHelpFormatter()


# Generated at 2022-06-24 17:37:00.348263
# Unit test for function version
def test_version():
    assert callable(version)
    # Call function
    print(version())


# Generated at 2022-06-24 17:37:07.109414
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        print("Test unfrack_path start")
        value=unfrack_path()
        print("Test unfrack_path end")
    except:
        print("Test unfrack_path failed")
        exit(1)
    print("Test unfrack_path passed")
    exit(0)

#
# Option Parser Annotations
#


# Generated at 2022-06-24 17:37:18.352664
# Unit test for function unfrack_path
def test_unfrack_path():
    assert __unfrack_path('tests/test_data/test1.yml')
    assert __unfrack_path('tests/test_data/test2.yml')
    assert __unfrack_path('tests/test_data/test3.yml')
    assert __unfrack_path('tests/test_data/test4.yml')
    assert __unfrack_path('tests/test_data/test5.yml')
    assert __unfrack_path('tests/test_data/test6.yml')
    assert __unfrack_path('tests/test_data/test7.yml')
    assert __unfrack_path('tests/test_data/test8.yml')
    assert __unfrack_path('tests/test_data/test9.yml')
   

# Generated at 2022-06-24 17:37:19.349023
# Unit test for function version
def test_version():
    assert len(version()) > 0


# Generated at 2022-06-24 17:37:22.444604
# Unit test for function ensure_value
def test_ensure_value():
    var_0 = ensure_value({}, None, {'': ' '})
    assert var_0 is None


# Generated at 2022-06-24 17:37:32.106098
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Print statements for debugging
    for beacon in ['/home/mytest']:
        # Define variables for the test
        values = ['--testcase', 'test_case_1', '--testcase', 'test_case_2', '--testcase', 'test_case_3']
        for value in values:
            print('value: ', value)
            # Call the tested function
            print('Answer should be: ', maybe_unfrack_path(beacon))
        print()


# Generated at 2022-06-24 17:37:34.331438
# Unit test for function unfrack_path
def test_unfrack_path():
    # Input parameters
    
    
    # Call function
    
    
    # Output checks
    assert True
    assert version()


# Generated at 2022-06-24 17:37:47.063891
# Unit test for function unfrack_path
def test_unfrack_path():
    assert(unfrack_path() == inner)


# Generated at 2022-06-24 17:37:56.914620
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Test 0:
    var_0 = argparse.ArgumentParser()
    var_1 = var_0.add_argument('-d', '--destination')
    var_2 = var_0.parse_args(['-d', 'dest'])
    var_3 = isinstance(var_2.destination, list)
    var_4 = var_2.destination[0]
    var_5 = var_4 == 'dest'
    var_6 = argparse.ArgumentParser()
    var_7 = var_6.add_argument('-d', '--destination', action=PrependListAction, nargs='*')
    var_8 = var_6.parse_args(['-d', 'dest1', 'dest2'])

# Generated at 2022-06-24 17:38:05.867073
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = "~/.ansible/roles"
    var_1 = to_native(var_1)
    try:
        var_2 = maybe_unfrack_path("~")
        var_1 = var_2(var_1)
    except Exception as var_3:
        print("test_maybe_unfrack_path: error occurred: " + str(var_3))
    assert '~/.ansible/roles' == var_1, "var_1 == '~/.ansible/roles'"


# Generated at 2022-06-24 17:38:12.176796
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('-')('-') == '-', 'Error: wrong result returned'
    assert maybe_unfrack_path('-')('path-') == '-path', 'Error: wrong result returned'



# Generated at 2022-06-24 17:38:17.830565
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test with positive values
    from pathlib import Path
    testfile = Path(__file__).parent/'data/test'
    var_1 = maybe_unfrack_path(beacon='test')
    print(var_1)


# Generated at 2022-06-24 17:38:20.026048
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path(0)
    print(var_0)


# Generated at 2022-06-24 17:38:22.278115
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_1 = "Self.DoAction(Params)"
    return var_1

# Generated at 2022-06-24 17:38:28.106281
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path(pathsep=False)
    if isinstance(var_0, FunctionType):
        var_0 = var_0()
    assert var_0 == None


# Generated at 2022-06-24 17:38:29.568566
# Unit test for function version
def test_version():
    test_case_0()

# Generated at 2022-06-24 17:38:31.055760
# Unit test for function version
def test_version():
    # Test function
    test_case_0()


#
# Main Options Parser classes
#

# Generated at 2022-06-24 17:39:10.337193
# Unit test for function unfrack_path
def test_unfrack_path():
    with pytest.raises(TypeError):
        unfrack_path(False)


# Generated at 2022-06-24 17:39:14.156714
# Unit test for function unfrack_path
def test_unfrack_path():
    # Output for function unit test should match below
    assert unfrack_path() == 'tbd'



# Generated at 2022-06-24 17:39:16.976705
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = "./new_abs/relative/path"
    test_case_0()
    test_case_1(var_1)
    print("Func unfrack_path() passed all the test cases")
    pass


# Generated at 2022-06-24 17:39:19.167994
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = {'default': None, 'help': 'path to an ansible configuration file\n', 'type': 'path', 'dest': 'ansible_config'}
    assert(unfrack_path(True)(var_1)) == True


# Generated at 2022-06-24 17:39:25.076951
# Unit test for function version
def test_version():
    var_0 = version()
    if var_0[1] != 'config file = /etc/ansible/ansible.cfg':
        print("Failed")
        return 1

if __name__ == '__main__':
    test_case_0()
    test_version()

# Generated at 2022-06-24 17:39:26.491072
# Unit test for function version
def test_version():
    global var_0
    assert var_0, "\nFailed to convert all json files"

# Generated at 2022-06-24 17:39:28.294832
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    obj = SortingHelpFormatter()
    assert obj is not None
    assert obj is not False
    assert obj is not True


# Generated at 2022-06-24 17:39:30.728619
# Unit test for function unfrack_path
def test_unfrack_path():
    assert(unfrack_path()('./test') == '/test')
    assert(unfrack_path(pathsep=True)('./test:./test') == ['/test', '/test'])


# Generated at 2022-06-24 17:39:31.863613
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    results = SortingHelpFormatter()


# Generated at 2022-06-24 17:39:35.185800
# Unit test for function unfrack_path
def test_unfrack_path():
    test_0 = "test_string"
    pathsep_0 = False
    assert_equal(unfrack_path(pathsep_0)(test_0), unfrackpath("test_string"))


# Generated at 2022-06-24 17:40:50.635215
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pr = PrependListAction('-t', '--targets', nargs='*', help='Specifies a space-separated list of hosts to update')
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--targets', nargs='*', action=PrependListAction, help='Specifies a space-separated list of hosts to update')
    parser.parse_args(['-t', '1', '2', '--targets', '3', '4'])


# Generated at 2022-06-24 17:40:53.837440
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path(beacon = "")
    var_1 = maybe_unfrack_path(beacon = "")


# Generated at 2022-06-24 17:40:57.590851
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_case_0()

if __name__ == '__main__':
    test_maybe_unfrack_path()

# Generated at 2022-06-24 17:41:05.832044
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    str_0 = version()
    int_0 = 1
    str_1 = version()
    str_2 = version()
    str_3 = version()
    str_4 = version()
    str_5 = version()
    str_6 = version()
    str_7 = version()
    str_8 = version()
    str_9 = version()
    str_10 = version()
    str_11 = version()
    str_12 = version()
    str_13 = version()
    str_14 = version()
    str_15 = version()
    str_16 = version()
    str_17 = version()
    str_18 = version()
    str_19 = version()
    str_20 = version()
    str_21 = version()
    str_22 = version()
    str_23 = version()


# Generated at 2022-06-24 17:41:08.783825
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        return_value_1 = unfrack_path()
        print(return_value_1)
    except Exception as exception:
        print(exception)


# Generated at 2022-06-24 17:41:20.794396
# Unit test for function unfrack_path
def test_unfrack_path():
    # Create argument parser
    parser = argparse.ArgumentParser()
    # Add argument
    parser.add_argument('--dir', dest='dir', type=unfrack_path(), default='/opt/ansible')
    # Parse argument
    args = parser.parse_args(['--dir', '/opt/ansible/playbooks'])
    # Verify
    assert args.dir == '/opt/ansible/playbooks'

if __name__ == '__main__':
    test_unfrack_path()
    test_case_0()

# Generated at 2022-06-24 17:41:23.551836
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # testing default constructor and properties
    x0 = SortingHelpFormatter()
    if x0:
        assert True
    else:
        assert False

# Generated at 2022-06-24 17:41:29.445970
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = '/etc/ssl/certs/ca-certificates.crt'
    var_1 = '/etc/ssl/certs/ca-certificates.crt'
    var_1 = maybe_unfrack_path(var_0)
    var_1 = maybe_unfrack_path(var_0)
    var_1 = maybe_unfrack_path(var_0)


# Generated at 2022-06-24 17:41:32.824231
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('some string') != 'some string'


# Generated at 2022-06-24 17:41:34.157951
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('../test/data/') == '../test/data/'
