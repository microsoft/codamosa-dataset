

# Generated at 2022-06-24 17:34:18.055071
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    assert add_runas_prompt_options(None, None) is None
    assert add_runas_prompt_options(None, '') is None
    assert add_runas_prompt_options(None, []) is None
    assert add_runas_prompt_options(None, {}) is None


# Generated at 2022-06-24 17:34:20.603397
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    assert add_runas_prompt_options(bytes) == b'\xcf'
    assert add_runas_prompt_options(bytes) == b'\xcf3'



# Generated at 2022-06-24 17:34:22.904048
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', '-e', action = AnsibleVersion,
                        help = 'show program\'s version number and exit')
    print(parser)
    parser.print_help()


# Generated at 2022-06-24 17:34:24.628517
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print(maybe_unfrack_path(bytes_0)(var_0))


# Generated at 2022-06-24 17:34:28.893552
# Unit test for function add_subset_options
def test_add_subset_options():
    # The following is b'\xcf3'
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--inventory', '--inventory-file', dest='inventory', action="append",
                        help="specify inventory host path or comma separated host list. --inventory-file is deprecated")
    parser.add_argument('--list-hosts', dest='listhosts', action='store_true',
                        help='outputs a list of matching hosts; does not execute anything else')
    parser.add_argument('-l', '--limit', default=C.DEFAULT_SUBSET, dest='subset',
                        help='further limit selected hosts to an additional pattern')

# Generated at 2022-06-24 17:34:33.130296
# Unit test for function add_output_options
def test_add_output_options():
    bytes_0 = b'$\xd9\x9a\x81\xd4\xbe\xa7"\x8f\xdb\x1d\x18\xed\xc4\x0e\x95\xb5\x03\x8a\xbb\xcbC\xd4\x07\xf4\x0c\xc4\x04j\xa5\x1fV\x1e\x7f\xe8\xb8\x96\xfb\x1a\xaf\xd8\x01\xab\x9c\xb8\xde\xa3#2\x1c\xb3>\x8f\xa2\x9a\x98\xd8'
    var_0 = add_output_options(bytes_0)



# Generated at 2022-06-24 17:34:42.686496
# Unit test for function add_runas_options
def test_add_runas_options():
    # Setup
    bytes_0 = b"\x1a\x9e\x1b\x1f\xba\x91G\xfb\x01\x1f\x11\x9e\x1a\x1b\x15\x04\x19\xb3\x08\xc3\x04\xe3\x08\xeb\x98\x1f\x1e\x8f\x10\xc3\x9c\x04\x14\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b"
    parser = argparse.ArgumentParser(prog=bytes_0)
    # Call function with args

# Generated at 2022-06-24 17:34:48.269780
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    import random

    for i in range(0, 10):
        var_0 = random.random()
        try:
            test_case_0()
        except:
            print("Exception caught: ", sys.exc_info()[0])


# Generated at 2022-06-24 17:34:56.101657
# Unit test for function add_check_options
def test_add_check_options():
    # Functions
    parser = argparse.ArgumentParser(conflict_handler='resolve')
    parser.add_argument("-C", "--check", default=False, dest='check', action='store_true',
                        help="don't make any changes; instead, try to predict some of the changes that may occur")
    parser.add_argument('--syntax-check', dest='syntax', action='store_true',
                        help="perform a syntax check on the playbook, but do not execute it")
    parser.add_argument("-D", "--diff", default=C.DIFF_ALWAYS, dest='diff', action='store_true',
                        help="when changing (small) files and templates, show the differences in those"
                             " files; works great with --check")

# Generated at 2022-06-24 17:34:59.156422
# Unit test for function add_inventory_options
def test_add_inventory_options():
    arg1 = "test1"

    test_func = add_inventory_options(arg1)



# Generated at 2022-06-24 17:35:22.068317
# Unit test for function add_check_options
def test_add_check_options():
    print("TESTING function add_check_options")
    
    parser = create_base_parser("testing_ansible-playbook")
    add_check_options(parser)
    # Check that options are added to argument list successfully
    arg_list = [
        '--syntax-check',
        '--check',
        '--diff',
    ]
    var_0 = parser.parse_args(arg_list)
    # var_0 should be a Namespace holding the expected attributes
    if var_0.syntax:
        print("Test 1 Passed")
        test_case_0()
    else:
        print("Test 1 Failed")
    if var_0.check:
        print("Test 2 Passed")
        test_case_0()
    else:
        print("Test 2 Failed")

# Generated at 2022-06-24 17:35:26.332236
# Unit test for function add_runas_options
def test_add_runas_options():
    bytes_0 = b'\xcf3'
    var_0 = add_runas_options(bytes_0)
    assert var_0.func_name == 'add_runas_options'


# Generated at 2022-06-24 17:35:34.160383
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='Test add_vault_options.')
    add_vault_options(parser)
    args = parser.parse_args([])
    assert args.vault_ids == []
    assert args.ask_vault_pass == C.DEFAULT_ASK_VAULT_PASS
    assert args.vault_password_files == []
    add_vault_options(parser)
    args = parser.parse_args(['--ask-vault-password',
                              '--vault-password-file', 'vault_password_file.txt'
                              ])
    assert args.vault_ids == []
    assert args.ask_vault_pass == True
    assert len(args.vault_password_files) == 1 and args.vault_password_files[0]

# Generated at 2022-06-24 17:35:38.172814
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test 0
    bytes_0 = b'\xcf3'
    var_0 = maybe_unfrack_path(bytes_0)
    if var_0 == b'\xcf3':
        print('Success 0')
    else:
        print('Fail 0')


# Generated at 2022-06-24 17:35:46.448727
# Unit test for function add_check_options
def test_add_check_options():
    argv = b"/usr/bin/ansible-playbook -C"
    parser = argparse.ArgumentParser(prog=argv, usage=None, description=None, formatter_class=None,
                                     conflict_handler=b'resolve', add_help=True)

    try:
        # Call add_check_options(parser)
        add_check_options(parser)

    except (TypeError, RuntimeError) as err:
        print(err)
    # Verify check option is available
    parser.parse_args()



# Generated at 2022-06-24 17:35:55.810155
# Unit test for function add_meta_options
def test_add_meta_options():
    # Setup test case
    parser = create_base_parser("test_add_meta_options")

    # Call function to be tested
    add_meta_options(parser)

    # Retrieve the --force-handlers option
    option_force_handlers = parser._actions[len(parser._actions) - 2]

    # Ensure that --force-handlers option exists
    assert option_force_handlers.dest == "force_handlers"

    # Retrieve the --flush-cache option
    option_flush_cache = parser._actions[len(parser._actions) - 1]

    # Ensure that --flush-cache option exists
    assert option_flush_cache.dest == "flush_cache"


# Generated at 2022-06-24 17:36:00.724999
# Unit test for function add_subset_options
def test_add_subset_options():
    parser_0 = argparse.ArgumentParser(prog='0', formatter_class=SortingHelpFormatter, conflict_handler='resolve',)
    add_subset_options(parser_0)
    try:
        assert parser_0.prog == '0'
    except AssertionError:
        raise AssertionError()
    try:
        assert isinstance(parser_0, argparse.ArgumentParser)
    except AssertionError:
        raise AssertionError()
    try:
        assert parser_0.formatter_class.__name__ == 'SortingHelpFormatter'
    except AssertionError:
        raise AssertionError()
    try:
        assert parser_0.conflict_handler == 'resolve'
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-24 17:36:03.094393
# Unit test for function add_async_options
def test_add_async_options():
    print ("Testing add_async_options():")
    bytes_0 = b'\xcf3'
    var_0 = add_output_options(bytes_0)


# Generated at 2022-06-24 17:36:16.673070
# Unit test for function ensure_value

# Generated at 2022-06-24 17:36:19.683372
# Unit test for function add_check_options
def test_add_check_options():
    test_case_0()


# Generated at 2022-06-24 17:36:27.196186
# Unit test for function add_runas_options
def test_add_runas_options():
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 17:36:32.083891
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser(prog='foo')
    add_inventory_options(parser)

    args = parser.parse_args(['--list-hosts', '-i', '/path/to/inventory.file'])
    assert args.listhosts == True, 'Invalid arguments'

    args = parser.parse_args(['-i', '1.1.1.1,1.1.1.2'])
    assert args.inventory[0] == '1.1.1.1,1.1.1.2', 'Invalid arguments'


# Generated at 2022-06-24 17:36:43.602570
# Unit test for function version
def test_version():
    #
    # Create a mock object for function to be tested
    #
    class MockArgs:
        def __init__(self, prog):
            self.prog = prog
    class MockParser:
        def __init__(self, prog):
            self.prog = prog
            self.args = MockArgs(prog)
        def exit(self): pass
    mock_parser = MockParser('test_cmd')

    expected_length = 13
    expected_version = version()
    expected_version_cmd = version('test_cmd')
    #
    # Execute unit test
    #
    ansible_version = AnsibleVersion()
    ansible_version(mock_parser, '', '', '')
    assert(len(expected_version) == expected_length)

# Generated at 2022-06-24 17:36:51.610937
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    options = parser.parse_args(['--become', '--become-method', 'su', '--become-user', 'root'])

    assert(options.become == True)
    assert(options.become_method == 'su')
    assert(options.become_user == 'root')
    assert(options.become_ask_pass == False)
    assert(options.ask_become_pass == False)


# Generated at 2022-06-24 17:37:03.880721
# Unit test for function add_connect_options
def test_add_connect_options():
    class DummyClass:
        def add_argument_group(self, *args, **kwargs):
            dummy_new_container = DummyClass()

            '@types: DummyClass'
            return dummy_new_container

        def add_argument(self, *args, **kwargs):
            pass

        def add_mutually_exclusive_group(self):
            return DummyClass()

    dummy_parser = DummyClass()
    # test with no exceptions
    add_connect_options(dummy_parser)


#
# Functions to setup inventory data
#

# Generated at 2022-06-24 17:37:11.401930
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)

    # Test that we get the correct help text
    help_text = parser.format_help()
    assert 'Privilege Escalation Options' in help_text
    assert 'control how and which user you become as on target hosts' in help_text
    assert 'run operations with become (does not imply password prompting)' in help_text
    assert 'privilege escalation method to use (default=sudo)' in help_text
    assert 'run operations as this user (default=root)' in help_text



# Generated at 2022-06-24 17:37:14.574196
# Unit test for function add_connect_options
def test_add_connect_options():
    bytes_0 = b'\xcf3'
    var_0 = add_connect_options(bytes_0)
    assert var_0 is not False
    

# Generated at 2022-06-24 17:37:22.038788
# Unit test for function add_connect_options
def test_add_connect_options():
    import random
    import string

    parser = argparse.ArgumentParser(prog='ansible',
                                     formatter_class=SortingHelpFormatter,
                                     conflict_handler='resolve',
                                     description='Dummy ArgParser')
    add_connect_options(parser)
    # Case 0: Test for string
    for i in range(100):
        bytes_0 = ''.join(random.choice(string.printable) for i in range(random.randint(1, 100))).encode('utf-8')
        try:
            parser.parse_args(bytes_0.split())
        except SystemExit:
            continue
        except:
            print("Test Case 0 Failed.")
            print("\tUnable to parse")
    print("Test Case 0 Passed")

    # Case 1: Test for list of bytes



# Generated at 2022-06-24 17:37:25.036768
# Unit test for function add_subset_options
def test_add_subset_options():
    bytes_0 = b'\xcf3'
    var_0 = add_subset_options(bytes_0)


# Generated at 2022-06-24 17:37:33.748785
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    option_string = None
    args = get_test_args()
    args.extend(['--version'])
    print("args:", args)
    options, args = parser.parse_known_args(args)
    options = get_test_options()
    namespace = get_test_namespace()
    namespace = AnsibleVersion.__call__(self, parser, namespace, values, option_string)
    print("Options:", options)
    print("Namespace:", namespace)
    print("Option String:", option_string)


# Generated at 2022-06-24 17:37:45.134617
# Unit test for function add_connect_options
def test_add_connect_options():

    # Assert if the function can handle the invalid type parameter
    test_pass = False
    try:
        add_connect_options(12)
    except TypeError:
        test_pass = True
    assert test_pass


# Generated at 2022-06-24 17:37:48.621806
# Unit test for function add_connect_options
def test_add_connect_options():
    bytes_0 = b'\xcf3'
    var_0 = add_connect_options(bytes_0)

#
# Functions for adding contents to the usage
#


# Generated at 2022-06-24 17:37:55.299141
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.release import __version__

    # call the function

# Generated at 2022-06-24 17:37:58.833317
# Unit test for function add_output_options
def test_add_output_options():
    assert test_case_0() == None


# Generated at 2022-06-24 17:38:07.768557
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = version(b'\xcf3')
    #assert ansible_version == "\nansible 2.6.9\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = [u'/home/zsx/.ansible/plugins/modules', u'/usr/share/ansible/plugins/modules']\n  ansible python module location = /home/zsx/.local/lib/python2.7/site-packages/ansible\n  executable location = /home/zsx/.local/bin/ansible\n  python version = 2.7.12 (default, Dec  4 2017, 14:50:18)\n\n", "%s" % ansible_version



# Generated at 2022-06-24 17:38:12.177407
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    bytes_0 = b'\xcf3'
    var_0 = maybe_unfrack_path(bytes_0)


# Generated at 2022-06-24 17:38:16.619374
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Test for b'string' string
    bytes_0 = b'string'
    result_0 = maybe_unfrack_path(bytes_0)
    assert result_0 == 'string'


# Generated at 2022-06-24 17:38:23.856570
# Unit test for function add_async_options
def test_add_async_options():
    prog = "ansible-test"
    usage = "Usage: ansible -m <MODULE_NAME> <HOSTS>"
    desc = "tests module functionality"
    epilog = "See the project home page on github at https://github.com/ansible/ansible."
    parser = create_base_parser(prog, usage, desc, epilog)
    add_async_options(parser)
    try:
        bytes_0 = b'\xcf3'
        var_0 = add_verbosity_options(bytes_0)
    except TypeError as e:
        print(e)


# Generated at 2022-06-24 17:38:26.293883
# Unit test for function unfrack_path
def test_unfrack_path():
    bytes_0 = b'\xcf3'
    var_0 = unfrack_path(bytes_0)
    print(len(var_0))


# Generated at 2022-06-24 17:38:38.124681
# Unit test for function add_connect_options
def test_add_connect_options():
    # Global variable (list of strings)
    parser = ['ssh-extra-args', 'key-file', 'connection-password-file', 'ssh-common-args', 'user', 'private-key', 'ask-pass', 'scp-extra-args', 'sftp-extra-args', 'connection', 'timeout']
    # Global variable (list of strings)
    parser[0] = ['sftp-extra-args', 'scp-extra-args']
    # Global variable (integer)
    parser[1] = [1366, 711, 1763, 397, 1136, 1534, 1876, 1032, 835, 1642, 825, 672, 819, 1064, 1032, 1065]
    # Global variable (integer)
    parser[2] = 1679
    # Global variable (list of strings

# Generated at 2022-06-24 17:38:56.842526
# Unit test for function add_connect_options
def test_add_connect_options():
    var_40 = '--private-key'
    var_41 = '--key-file'
    var_42 = C.DEFAULT_PRIVATE_KEY_FILE
    var_43 = 'use this file to authenticate the connection'
    var_44 = unfrack_path()
    var_45 = '-u'
    var_46 = '--user'
    var_47 = C.DEFAULT_REMOTE_USER
    var_48 = 'connect as this user (default=%s)' % C.DEFAULT_REMOTE_USER
    var_49 = '-c'
    var_50 = '--connection'
    var_51 = C.DEFAULT_TRANSPORT
    var_52 = "connection type to use (default=%s)" % C.DEFAULT_TRANSPORT

# Generated at 2022-06-24 17:39:00.504627
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version_instance = version()
    version_instance.apply(action='store_true')


# Generated at 2022-06-24 17:39:06.378746
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # 03/02/2017
    path = '/home/whuang/GitHub/Ansible/ansible/lib/ansible/module_utils/facts/virtual.py'
    res = maybe_unfrack_path(path)
    print(res)
    #assert(res == '/home/whuang/GitHub/Ansible/ansible/lib')



# Generated at 2022-06-24 17:39:18.481525
# Unit test for function add_connect_options
def test_add_connect_options():
    # Ansible version
    print(C.DEFAULT_PRIVATE_KEY_FILE, C.DEFAULT_REMOTE_USER, C.DEFAULT_TRANSPORT, C.DEFAULT_TIMEOUT, C.DEFAULT_ASK_PASS, C.CONNECTION_PASSWORD_FILE)
    print(C.config.get_config_value('PLAYBOOK_DIR'))

#    print(constants.DEFAULT_PRIVATE_KEY_FILE, constants.DEFAULT_REMOTE_USER, constants.DEFAULT_TRANSPORT, constants.DEFAULT_TIMEOUT, constants.DEFAULT_ASK_PASS, constants.CONNECTION_PASSWORD_FILE)
#    print(constants.config.get_config_value('PLAYBOOK_DIR'))

#    parser = argparse.ArgumentParser(prog

# Generated at 2022-06-24 17:39:20.438234
# Unit test for function add_output_options
def test_add_output_options():
    test_case_0()

#
# Callbacks for Options
#


# Generated at 2022-06-24 17:39:22.328416
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print(version())


# Generated at 2022-06-24 17:39:28.295355
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser()
    parser.prog = 'ansible'
    namespace = argparse.Namespace()
    values = None
    option_string = None
    # Call method __call__ of class AnsibleVersion
    obj = AnsibleVersion(option_strings=['-v'])
    obj.__call__(parser, namespace, values, option_string)


#
# Main script
#


# Generated at 2022-06-24 17:39:30.765797
# Unit test for function add_output_options
def test_add_output_options():
    parser = create_base_parser(None, None)
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert hasattr(args, 'one_line')


# Generated at 2022-06-24 17:39:32.827723
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)



# Generated at 2022-06-24 17:39:41.726298
# Unit test for function version
def test_version():
    # Set up mock values
    program_name = "foo"
    gitinfo = "bar"
    config_file = "/etc/ansible/ansible.cfg"
    module_path = "/etc/ansible/modules"
    module_location = "/usr/local/bin/ansible"
    executable_location = "/usr/bin/python"
    python_version = "2.7.6"
    jinja_version = "2.4"
    lib_yaml = False

    # Call function to be tested
    result = version(program_name)
    expected_result = "{0} [core {1}]".format(program_name, __version__)
    expected_result += "  config file = %s" % config_file
    expected_result += "  configured module search path = %s" % module_path

# Generated at 2022-06-24 17:39:52.582579
# Unit test for function unfrack_path
def test_unfrack_path():
    pathsep = True
    expected = "C:\Program Files\Git\bin"
    actual = unfrack_path(pathsep)
    assert actual == expected

#
# Functions to print out data during testing
#

# Generated at 2022-06-24 17:39:56.460812
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser = argparse.ArgumentParser(prog="ansible-playbook", description="Ansible Playbook")
    parser.add_argument("ansible-version", action=AnsibleVersion)
    parser.parse_args(["1.0.0"])


# Generated at 2022-06-24 17:39:59.286559
# Unit test for function unfrack_path
def test_unfrack_path():
    assert to_native(unfrackpath('/path/to/file')),'/path/to/file'
    assert to_native(unfrackpath('/path/to/file')) != '/path/to/file/',True


# Generated at 2022-06-24 17:40:05.872325
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = '@test'
    var_1 = maybe_unfrack_path(var_0)
    assert var_1 == '@test'


# Generated at 2022-06-24 17:40:08.117169
# Unit test for function ensure_value
def test_ensure_value():
    assert ensure_value('namespace', 'name', 'value') == 'value'


# Generated at 2022-06-24 17:40:11.088426
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    try:
        print(maybe_unfrack_path(0))
    except:
        print('Caught exception')
        raise


# Generated at 2022-06-24 17:40:15.788877
# Unit test for function version
def test_version():
    results = version()
    print(results)
    assert results == "ansible-base [core 2.10.0]"

# Generated at 2022-06-24 17:40:27.048013
# Unit test for function unfrack_path
def test_unfrack_path():
    func_0 = unfrack_path()
    func_1 = unfrack_path(True)
    # TODO: Fix this edge case unit test
    # testing if the input is '-' (string)
    #assert func_0('-') == '-'
    # testing if the input is [] (list)
    assert func_1([]) == []
    # testing if the input is a string
    assert func_0('a/b') == 'a/b'
    # testing if the input is a list
    assert func_1(['a/b', 'c']) == ['a/b', 'c']


# Generated at 2022-06-24 17:40:32.707880
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print("Running test for function maybe_unfrack_path...")
    var_4 = maybe_unfrack_path('@')
    print(var_4)
    print("Call function with param = '@' to get result")
    print(var_4('@'))
    print('\n')


# Generated at 2022-06-24 17:40:34.727292
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    var_0 = PrependListAction()


# Generated at 2022-06-24 17:40:46.604860
# Unit test for function unfrack_path
def test_unfrack_path():
    path = '/etc/passwd'
    assert unfrack_path(path) != path, 'Failed to assert that the file path /etc/passwd does not exist'

#
# Option Parser
#
# NOTE: Parser is defined here and not dynamically pulled from the module_utils/basic.py
#       to be fully backwards compatible with legacy usage of ansible-playbook.
#

# Generated at 2022-06-24 17:40:53.212901
# Unit test for function ensure_value
def test_ensure_value():
    '''
    verify that setattr() is called if value is None
    '''
    class MockArgs(object):
        pass
    args = MockArgs()
    args.vault_password_file = None
    args.ask_vault_pass = True
    args.vault_password_files = []
    ensure_value(args, 'vault_password_files', ['test-file'])
    ensure_value(args, 'vault_password_files', ['test-file-2'])
    ensure_value(args, 'vault_password_file', 'test-file-3')
    assert args.vault_password_files == ['test-file', 'test-file-2']
    assert args.vault_password_file == 'test-file-3'


# Generated at 2022-06-24 17:40:54.612784
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('@')('@/abc/abc') == '@/abc/abc'


# Generated at 2022-06-24 17:40:58.751378
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()


# Generated at 2022-06-24 17:41:08.348803
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-24 17:41:14.837391
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path("tests/fixtures/")("tests/fixtures/test1.yml") == "tests/fixtures/test1.yml"
    

# Generated at 2022-06-24 17:41:18.409441
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print("Test __call__")
    prog='test'
    version()
    version(prog)


# Generated at 2022-06-24 17:41:21.620911
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    args = ['arg1', 'arg2', 'arg3']
    namespace = '<namespace>'
    values = '<values>'
    option_string = '<option_string>'
    AnsibleVersion.__call__(args, namespace, values, option_string)


# Generated at 2022-06-24 17:41:25.124480
# Unit test for function version
def test_version():
    # no exception should be raised
    try:
        var_0 = version()
    except:
        var_0 = False

    return var_0


# Generated at 2022-06-24 17:41:34.012201
# Unit test for function unfrack_path
def test_unfrack_path():

    # Setup argparse OptionParser instance
    parser = argparse.OptionParser()

    # Setup argparse argument for OptionParser instance
    parser.add_argument(
        '--default-vault-password-file',
        callback=unfrack_path(),
        dest='default_vault_password_file',
        help=(' vault password file')
    )

    # Assert that parser.parse_args() does not raise an error
    try:
        # Setup argparse argument for OptionParser instance
        parser.add_argument(
            '--default-vault-password-file',
            callback=unfrack_path(),
            dest='default_vault_password_file',
            help=(' vault password file')
        )
    except SystemExit:
        print("Parser.parse_args() raises SystemExit, which is expected")

   

# Generated at 2022-06-24 17:41:50.100125
# Unit test for function ensure_value
def test_ensure_value():
    assert ensure_value(sys.modules[__name__], 'test_case_0', lambda: None) is test_case_0


# Generated at 2022-06-24 17:41:59.797402
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = argparse.Action()
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_0 = AnsibleVersion(var_1, var_2, var_3, var_4)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_0.__call__(var_1, var_2, var_3, var_4)


# Generated at 2022-06-24 17:42:05.077589
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Source: 
    assert maybe_unfrack_path(C.DEFAULT_LOCAL_TMP) == (C.DEFAULT_LOCAL_TMP + unfrackpath('/tmp/ansible-tmp-1550496755.99-928232250982586'))


# Generated at 2022-06-24 17:42:07.022756
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_2 = SortingHelpFormatter('')


# Generated at 2022-06-24 17:42:09.744378
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = AnsibleVersion()
    try:
        var_1.__call__(None, None, None, None)
    except Exception as exception:
        raise AssertionError(exception)



# Generated at 2022-06-24 17:42:12.219786
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version_1 = AnsibleVersion()
    print(version_1)
    print(type(version_1))



# Generated at 2022-06-24 17:42:16.445221
# Unit test for function version
def test_version():
    try:
        assert callable(version)
    except AssertionError as e:
        raise(AssertionError("%s not callable" % repr(version)))


# Generated at 2022-06-24 17:42:27.834434
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = copy.deepcopy(version())
    var_1 = argparse.Action()
    # 'parser' type is not tested
    # 'namespace' type is not tested
    # 'values' type is not tested
    # 'option_string' type is not tested
    try:
        var_1.__call__(parser, namespace, values, option_string)
    except Exception:
        var_2 = exception_type()
        var_3 = exception_value()
        var_4 = exception_traceback()
        raise_0 = raise_builtin(var_2, var_3, var_4)
        del raise_0
    finally:
        del var_0
        del var_1
    # TODO: Implement unit test for ansible.cli.CLI.__call__


# Generated at 2022-06-24 17:42:33.748850
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():

    # Setup the arguments for the script
    sys.argv = ['ansible-playbook --version']
    arg_parser = argparse.ArgumentParser()
    ansible_version = to_native(version('ansible-playbook'))
    print(ansible_version)

    # Creating mock objects
    args_dict = {}
    options = {'version' : ansible_version}
    ansible_version_obj = AnsibleVersion(**options)

    # Executing the method under test
    ansible_version_obj(arg_parser, args_dict, ansible_version)

    # Verifying the results
    assert(True)



# Generated at 2022-06-24 17:42:47.459069
# Unit test for function unfrack_path
def test_unfrack_path():

    # for test input values
    class Arguments:
        def __init__(self, val):
            self.__dict__['_an_actual_attribute'] = val

        def __getattr__(self, name):
            return self.__dict__['_an_actual_attribute']

        def __setattr__(self, name, value):
            self.__dict__['_an_actual_attribute'] = value

    y = Arguments(os.getcwd()+"/tests/test_utils_module_loader.py")

    res = unfrack_path()(y)
    assert isinstance(res, str), "unfrack_path function returns string type."


#
# '--version' Parser
#