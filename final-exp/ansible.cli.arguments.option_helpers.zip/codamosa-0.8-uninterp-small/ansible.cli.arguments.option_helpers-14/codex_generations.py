

# Generated at 2022-06-24 17:33:58.268092
# Unit test for function add_connect_options
def test_add_connect_options():
    args = [
        "--timeout", "1",
        "--scp-extra-args", "2",
        "-c", "connect type",
        "--ssh-common-args", "4",
        "-T", "timeout value",
        "-u", "user name",
        "-k", "ask pass",
        "-k", "default ask pass",
        "--ssh-extra-args", "8",
        "--private-key", "key place",
        "-c", "default connect type",
        "--ask-pass",
        "--sftp-extra-args", "16"
    ]

    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    res = parser.parse_args(args)
    #assert res.connection_password_file == "key place"


# Generated at 2022-06-24 17:34:00.593823
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(
        prog='ansible',
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve'
    )

    add_runas_options(parser)

    print(parser.parse_args())


# Generated at 2022-06-24 17:34:06.321357
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    bool_0 = False
    var_0 = AnsibleVersion(bool_0)
    bool_1 = False
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()
    str_8 = str()
    str_9 = str()
    str_10 = str()
    str_11 = str()
    str_12 = str()
    str_13 = str()
    parser = argparse.ArgumentParser(str_0)

# Generated at 2022-06-24 17:34:12.742527
# Unit test for function add_meta_options
def test_add_meta_options():
    bool_arg = False
    desc = "test"
    epilog = "test"
    formatter_class = "test"
    help = "test"
    metavar = "test"
    nargs = "test"
    parser = argparse.ArgumentParser(
        prog="test",
        description=desc,
        epilog=epilog,
        formatter_class=formatter_class,
        help=help,
        metavar=metavar,
        nargs=nargs,
    )
    add_meta_options(parser)
    assert(parser.__dict__['_optionals'])


# Generated at 2022-06-24 17:34:23.330983
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description='Generate Ansible inventory from Foreman.',
        epilog='Example usage: %s [options] --foreman-url http://foreman.example.com' % name)
    # Add the arguments
    parser.add_argument('--version', action='version', version='%(prog)s {version}'.format(version=__version__))
    parser.add_argument('--list', dest='list_instances', action='store_true',
                        help='List all Foreman instances (default: False)')
    parser.add_argument('--host', metavar='host', help='Get all information about specific instance (default: None)')

# Generated at 2022-06-24 17:34:26.156890
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = ArgumentParser()
    add_meta_options(parser)
    result = parser.parse_args(['--force-handlers', '--flush-cache'])
    assert result.force_handlers == True
    assert result.flush_cache == True


# Generated at 2022-06-24 17:34:36.189953
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--foo", action=PrependListAction)

    args = arg_parser.parse_args(["--foo=bar", "--foo=baz", "--foo=qux", "--foo=quux"])

    assert list(args.foo) == ["quux", "qux", "baz", "bar"]
    assert args.foo == ["quux", "qux", "baz", "bar"]


# Generated at 2022-06-24 17:34:40.590344
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    try:
        assert maybe_unfrack_path()('/tmp/ansible_unfrack_path_test.py') == '/tmp/ansible_unfrack_path_test.py'
    except AssertionError:
        raise AssertionError('maybe_unfrack_path() test failed!')
    else:
        print('maybe_unfrack_path() test passed.')



# Generated at 2022-06-24 17:34:45.776972
# Unit test for function add_module_options
def test_add_module_options():
    # Initializing variable 'parser'
    parser = None
    for i in range(100):
        # Call function 'add_module_options'
        # Call function 'add_module_options'
        test_case_0()



# Generated at 2022-06-24 17:34:47.455833
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrackpath("/home/foo/") == "/home/foo/", "Should be '%s'" % "/home/foo/"


# Generated at 2022-06-24 17:35:09.120451
# Unit test for function version
def test_version():
    arg_0 = None
    assert version(arg_0) == "ansible-test [core ansible-test]\n  config file = \n  configured module search path = \n  ansible python module location = \n  ansible collection location = \n  executable location = \n  python version = \n  jinja version = \n  libyaml = \n  python version = \n  jinja version = \n  libyaml = "


# Generated at 2022-06-24 17:35:11.270528
# Unit test for function add_vault_options
def test_add_vault_options():
    print("START test_add_vault_options")
    test_case_0()
    print("END test_add_vault_options")


# Generated at 2022-06-24 17:35:16.704993
# Unit test for function add_check_options
def test_add_check_options():
    ut.start_test_case("TEST-07", "Check-Options")
    parser = create_base_parser("TEST-07", "TESTING ADD-CHECK-OPTIONS")
    add_check_options(parser)
    var_1 = parser._actions
    ut.check_var_value("TEST-07", "check", True, var_1)
    ut.check_var_value("TEST-07", "syntax", True, var_1)
    ut.check_var_value("TEST-07", "Diff", C.DIFF_ALWAYS, var_1)
    ut.end_test_case("TEST-07", "Check-Options")


# Generated at 2022-06-24 17:35:20.260053
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(['-C',])
    assert args.check == True
    assert args.diff == True
    assert args.syntax == True


# Generated at 2022-06-24 17:35:25.763016
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = {}
    parser['help'] = "only run plays and tasks tagged with these values"
    parser['dest'] = 'tags'
    parser['action'] = 'append'
    parser['default'] = C.TAGS_RUN
    parser['args'] = '-t'
    parser['kwargs'] = '--tags'
    var_0 = add_subset_options(parser)
    test_case_0()


# Generated at 2022-06-24 17:35:32.569112
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    for args, expected in (
            (['-t', 'tag1', '-t', 'tag2', '--skip-tags', 'skip1', '--skip-tags', 'skip2'], {'tags': ['tag1', 'tag2'], 'skip_tags': ['skip1', 'skip2']}),
            ([], {'tags': ['all'], 'skip_tags': []})):
        with pytest.raises(SystemExit):
            options, _ = parser.parse_known_args(args)
        assert vars(options) == expected


# Generated at 2022-06-24 17:35:36.352695
# Unit test for function add_runtask_options
def test_add_runtask_options():
    parser = argparse.ArgumentParser()
    add_runtask_options(parser)
    args = parser.parse_args(['-e', '@' + os.path.join(os.getcwd(), 'conftest.yml')])
    assert args.extra_vars != None


# Generated at 2022-06-24 17:35:40.189923
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = create_base_parser('ansible-playbook')
    add_inventory_options(parser)
    parser.parse_args()



# Generated at 2022-06-24 17:35:43.205694
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook')
    add_output_options(parser)
    args = parser.parse_args(['--one-line', '--tree', "var_0"])
    assert args.one_line
    assert args.tree == "var_0"


# Generated at 2022-06-24 17:35:48.412344
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = ['--tags', 'bar,baz', '--skip-tags', 'foo', '-t', 'vmware_guest']
    options = parser.parse_args(args)
    assert options.tags == ['bar,baz', 'vmware_guest']
    assert options.skip_tags == ['foo']


# Generated at 2022-06-24 17:36:06.380559
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    value = None
    beacon = None
    assert maybe_unfrack_path(value,beacon)==None



# Generated at 2022-06-24 17:36:11.900623
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    parser.add_argument('--vault-password-file', '--vault-pass-file', default=[], dest='vault_password_files',
                            help="vault password file", type=unfrack_path(), action='append')
    parser.add_argument('--ask-vault-password', '--ask-vault-pass', default=C.DEFAULT_ASK_VAULT_PASS, dest='ask_vault_pass', action='store_true',
                            help='ask for vault password')
    parser.add_argument('--vault-id', default=[], dest='vault_ids', action='append', type=str,
                        help='the vault identity to use')
    var_1 = parser
    
    var

# Generated at 2022-06-24 17:36:14.990524
# Unit test for function unfrack_path
def test_unfrack_path():
    assert test_case_0()

# Generated at 2022-06-24 17:36:18.645091
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = None


# Generated at 2022-06-24 17:36:30.831761
# Unit test for function unfrack_path
def test_unfrack_path():
    test_case_0() # Yes, it's... simple...

#
# Start of Main Program
#

ANSIBLE_VERSION = __version__

# Note: If you add any options here which *store* values, make sure you modify
# the code which resets these to the defaults in ansible-playbook (look for
# settable_to_defaults).
common_parser = argparse.ArgumentParser(add_help=False)
common_parser.add_argument('--ansible-version', '--version', dest='version', action=AnsibleVersion, nargs=0, help="show program's version number and exit")
common_parser.add_argument('-k', '--ask-pass', dest='ask_pass', action='store_true', help='ask for connection password')

# Generated at 2022-06-24 17:36:36.144461
# Unit test for function unfrack_path
def test_unfrack_path():
    # Make sure that none of the files/folders in the test_case_0 folder are used
    var_0 = None
    var_0 = unfrack_path()(var_0)
    assert var_0 == None


# Generated at 2022-06-24 17:36:37.977566
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = None
    print("<-------->")
    print(unfrack_path(var_0))
    print("<>")


# Generated at 2022-06-24 17:36:49.489243
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Paths used for testing
    good_path = os.path.abspath(os.path.join(__file__, '..', '..', '..', 'test-data'))
    bad_path = os.path.abspath(os.path.join(__file__, '..', '..', '..', 'test-data-bad'))

    test_cases = [
        (None, '@test', '@test'),
        (good_path, '@test', '@' + good_path),
        (bad_path, '@test', '@' + bad_path),
        (good_path + os.sep, '@test', '@' + good_path),
        (bad_path + os.sep, '@test', '@' + bad_path),
    ]


# Generated at 2022-06-24 17:36:55.282547
# Unit test for function add_async_options
def test_add_async_options():
    global var_0
    print("Running unit test function test_add_async_options()")
    var_0 = argparse.ArgumentParser(conflict_handler='resolve')
    add_async_options(var_0)
    assert (hasattr(var_0, 'poll_interval'))
    assert (hasattr(var_0, 'seconds'))



# Generated at 2022-06-24 17:36:57.440010
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert callable(maybe_unfrack_path)
    assert isinstance(maybe_unfrack_path(var_0), Callable)
    assert maybe_unfrack_path(var_0)(var_0) == var_0


# Generated at 2022-06-24 17:37:05.228663
# Unit test for function unfrack_path
def test_unfrack_path():
    assert True == True


# Generated at 2022-06-24 17:37:06.993056
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)
    test_case_0()


# Generated at 2022-06-24 17:37:15.130347
# Unit test for function add_runas_options
def test_add_runas_options():
        test_0 = False
        test_1 = False
        test_2 = False
        test_3 = False
        test_4 = False
        test_5 = False
        test_6 = False
        test_7 = False
        test_8 = False
        test_9 = False

        test_0 = True
        
        test_1 = False
        
        test_2 = False
        
        test_3 = False
        
        test_4 = False
        
        test_5 = False
        
        test_6 = False
        
        test_7 = False
        
        test_8 = False
        
        test_9 = False
        

        # Call function
        var_0 = add_runas_options(parser=None)

        # Output
        test_0 = False
        
        test_1

# Generated at 2022-06-24 17:37:16.162385
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_case_0()


# Generated at 2022-06-24 17:37:18.025484
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    #
    # init a PrependListAction class
    #
    var_0 = _AppendAction([], [], [], [], [])


# Generated at 2022-06-24 17:37:26.575249
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(prog='ansible')
    add_runas_options(parser)
    args = ['--become', '--become-method', 'sudo', '--become-user', 'test']
    parsed_args = parser.parse_args(args)
    assert parsed_args.become == True
    assert parsed_args.become_method == 'sudo'
    assert parsed_args.become_user == 'test'


# Generated at 2022-06-24 17:37:35.025635
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    # Call method __call__
    var_0 = PrependListAction.__call__(var_0, var_1, var_2, var_3)



# Generated at 2022-06-24 17:37:37.398066
# Unit test for function add_runas_options
def test_add_runas_options():
    # Initialization
    parser = argparse.ArgumentParser()
    # Execution
    add_runas_options(parser)


# Generated at 2022-06-24 17:37:42.630351
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
    add_runas_options(parser)
    args = parser.parse_args(['-b', '--become-method', 'runas', '--become-user', 'root'])
    assert args.become == True
    assert args.become_method == 'runas'
    assert args.become_user == 'root'



# Generated at 2022-06-24 17:37:54.194840
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Arguments:
    # parser:
    class MockArgs:
        items=None
    var_parser = MockArgs()
    # namespace:
    class MockNamespace:
        items=None
    var_namespace = MockNamespace()
    # values:
    var_values = [1, 2, 3]
    # option_string:
    var_option_string = ''
    # # Define a mock for the class objects
    # MockArgs = mock.MagicMock()
    # var_parser = MockArgs()
    # # Set up mock attributes
    # MockArgs.items = []
    # # Mock the method call
    # var_parser.items = [1, 2, 3]
    # # Define a mock for the class objects
    # MockNamespace = mock.MagicMock()
    # var_namespace

# Generated at 2022-06-24 17:38:04.987569
# Unit test for function version
def test_version():
    args = []
    if len(args) == 0:
        assert False
    else:
        # This should pass.
        assert True

if __name__ == "__main__":
    test_case_0()
    test_version()

# Generated at 2022-06-24 17:38:07.845330
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()


# Generated at 2022-06-24 17:38:10.781009
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_case_0()


# Generated at 2022-06-24 17:38:13.848026
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('beacon')
    assert var_0('beacon') == 'beacon'


# Generated at 2022-06-24 17:38:17.648145
# Unit test for function unfrack_path
def test_unfrack_path():
    input = '/home/ansible/'
    expected = '/home/ansible/'
    output = unfrack_path(input)
    assert output == expected



# Generated at 2022-06-24 17:38:23.338843
# Unit test for function version
def test_version():
    var_0 = sys.version.splitlines()
    # Check if sys.argv[0] is file path or just script name
    if len(sys.argv[0].split(os.sep)) > 1:
        var_1 = os.sep
    else:
        var_1 = ' '
    var_2 = [var_0, var_1]
    var_3 = version()
    assert var_3 == '', 'Invalid return value {0}'.format(var_3)


# Generated at 2022-06-24 17:38:25.471263
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path("")
    var_1 = maybe_unfrack_path("")


# Generated at 2022-06-24 17:38:26.724763
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # default
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:38:28.926351
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    assert_raises(KeyError, test_case_0)



# Generated at 2022-06-24 17:38:39.535756
# Unit test for function ensure_value
def test_ensure_value():
    # Test if list is returned when input is of type list
    assert ensure_value("test", "test", [1, 2, 3]) == [1, 2, 3]

    # Test if tuple is returned when input is of type tuple
    assert ensure_value("test", "test", (1, 2, 3)) == (1, 2, 3)

    # Test if string is returned when input is of type string
    assert ensure_value("test", "test", "test") == "test"

    # Test if None is returned when input is of type None
    assert ensure_value("test", "test", None) == None

    # Test if int is returned when input is of type int
    assert ensure_value("test", "test", 10) == 10




# Generated at 2022-06-24 17:38:57.378351
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)
    pathsep = False
    assert unfrack_path(pathsep)("/usr/local/lib/python3.6/site-packages/ansible/module_utils/") == "/usr/local/lib/python3.6/site-packages/ansible/module_utils/"



# Generated at 2022-06-24 17:39:00.246943
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Setup
    pathsep = False
    beacon = '~'
    value = '~'
    var_2 = maybe_unfrack_path(beacon)
    # Invoke action
    temp_0 = var_2(value)
    print(temp_0)



# Generated at 2022-06-24 17:39:09.856717
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = ["--ansible-cfg"]
    dest = "ansible_cfg"
    nargs = None
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = None
    metavar = None
    parser = argparse.ArgumentParser()
    var_0 = PrependListAction(option_strings, dest, nargs, const, default, type, choices, required, help, metavar)
    namespace = ChoiceAction(dest, choices, required, help, metavar)
    option_string = "ansible_cfg"
    values = None
    var_0 = parser.parse_args()
    var_0.__call__(parser, namespace, values, option_string)
    assert var_0 == "ansible_cfg"



# Generated at 2022-06-24 17:39:19.741338
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # instance of class PrependListAction
    prepend_list_action_obj0 = PrependListAction(
        "option_strings_0",
        "dest_0",
        nargs_0=None,
        const_0=None,
        default_0=None,
        type_0=None,
        choices_0=None,
        required_0=False,
        help_0=None,
        metavar_0=None
    )

    # instance of class Namespace
    namespace_obj0 = Namespace()
    setattr(namespace_obj0,
            ensure_value(namespace_obj0, "dest_0", []))

# Generated at 2022-06-24 17:39:30.348583
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    args = [
        '--help'
    ]
    parser = argparse.ArgumentParser(description='', formatter_class=SortingHelpFormatter, add_help=True)
    parser.add_argument(
        "--args",
        action="store",
        type=str,
        dest="args",
        help='_args__help')
    parser.add_argument(
        "--t",
        action="store",
        default='a',
        type=str,
        dest="t",
        help='_t__help')
    parser.add_argument(
        "--s",
        action="store",
        type=str,
        dest="s",
        help='_s__help')
    args = parser.parse_args(args)



# Generated at 2022-06-24 17:39:34.157685
# Unit test for function version
def test_version():
    var_1 = version(1)
    assert var_1 == 1

    var_2 = version(0)
    assert var_2 == 0

    var_3 = version()
    assert var_3 != None


# Generated at 2022-06-24 17:39:38.283977
# Unit test for function version
def test_version():
    # TODO: create a test
    #assert version() == 'TODO'
    return

# Generated at 2022-06-24 17:39:39.532648
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert test_case_0() == 0



# Generated at 2022-06-24 17:39:40.874493
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # TODO: Create test.
    pass


# Generated at 2022-06-24 17:39:50.869287
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True) == [], 'unfrack_path() failed'

# Generated at 2022-06-24 17:40:21.509402
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    action = PrependListAction()
    parser = ArgParser()
    namespace = Namespace()
    values = []
    option_string = ''
    action.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-24 17:40:32.068958
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()
#     yaml_file = os.path.join(sys.argv[0], "test_cases", 'var_1.yaml')
    yaml_file = os.path.join(os.path.dirname(sys.argv[0]), 'test_cases', 'var_1.yaml')
    yaml_data = yaml_load(open(yaml_file).read())
    #print(yaml_data)
    assert yaml_data == var_1


# Generated at 2022-06-24 17:40:35.094230
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    beacon = '<AnsibleVar:abc>'
    var_1 = maybe_unfrack_path(beacon)
    assert var_1('<AnsibleVar:xyz>') == '<AnsibleVar:xyz>'
    assert var_1('<AnsibleVar:abc>') == '<AnsibleVar:abc>'





# Generated at 2022-06-24 17:40:36.970489
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('1')


# Generated at 2022-06-24 17:40:38.910818
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:40:41.874201
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path() in {'/usr/lib/python2.7'}


# Generated at 2022-06-24 17:40:44.927223
# Unit test for function unfrack_path
def test_unfrack_path():
    assert "ansible" in unfrack_path()("ansible")

#
# Utility functions to add Options to an OptionParser
#

# Generated at 2022-06-24 17:40:48.137785
# Unit test for function unfrack_path
def test_unfrack_path():
    # unfrack_path
    var_0 = unfrack_path()
    # --- end of code for unfrack_path ---
    assert var_0



# Generated at 2022-06-24 17:40:50.657113
# Unit test for function unfrack_path
def test_unfrack_path():
    out = unfrack_path()("./test/path")
    assert out == "./test/path"


# Generated at 2022-06-24 17:40:52.928302
# Unit test for function version
def test_version():
    # Test with no parameters
    result = version()
    assert result != None


# Generated at 2022-06-24 17:42:52.345372
# Unit test for function unfrack_path
def test_unfrack_path():
    #case_0
    #assert unfrack_path() == ''
    #print(unfrack_path())
    #print(unfrackpath('1111'))
    #print(os.pathsep)

    #case_1
    #assert unfrack_path(True) == ''

    #case_2
    #assert unfrack_path() == ''

    print('unfrack_path test success')

#
# The actual Options Parsers
#

# Base options
base_parser = argparse.ArgumentParser(formatter_class=SortingHelpFormatter)
base_parser.add_argument('-v', '--version', action=AnsibleVersion, nargs=0,
                         help='Show program\'s version number and exit')

# Generated at 2022-06-24 17:42:58.062999
# Unit test for function unfrack_path
def test_unfrack_path():
    test_case_0()

#
# Define and parse options
#

# Generated at 2022-06-24 17:43:00.634819
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print('Test function maybe_unfrack_path')
    # no input, should not crash.
    maybe_unfrack_path(None)


# Generated at 2022-06-24 17:43:04.031187
# Unit test for function version
def test_version():
    test = version()
    print("\n  Version: \n \n {} \n".format(test))
    return test


# Generated at 2022-06-24 17:43:12.483845
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    first_arg = argparse.Action()
    second_arg = argparse.Action()
    third_arg = argparse.Action()
    fourth_arg = argparse.Action()
    fifth_arg = argparse.Action()
    sixth_arg = argparse.Action()
    seventh_arg = argparse.Action()
    eight_arg = argparse.Action()
    nineth_arg = argparse.Action()
    tenth_arg = argparse.Action()

    PrependListAction(first_arg, second_arg, third_arg, fourth_arg, fifth_arg, sixth_arg, seventh_arg, eight_arg, nineth_arg, tenth_arg)


# Generated at 2022-06-24 17:43:15.738964
# Unit test for function unfrack_path
def test_unfrack_path():
    """Test for function unfrack_path"""
    assert callable(unfrack_path)
    # Test for return type
    assert isinstance(unfrack_path(), type(lambda :0))
    # Test for return value
    assert unfrack_path()(None) == None
    # Test for callback
    assert unfrack_path()(None) == None


# Generated at 2022-06-24 17:43:27.689533
# Unit test for function version
def test_version():
    # From Ansible docs:
    #  * ``--version``
    #  * ``-vvv``
    #  * ``--version``
    #  * ``-C``
    #  * ``--version``
    #  * ``-T``
    #  * ``--version``
    #  * ``-U``
    #  * ``--version``
    #  * ``-k``
    #  * ``--version``
    #  * ``-K``
    #  * ``--version``
    #  * ``-i <path>``

    # Test case 1
    print(version(), end='\n')