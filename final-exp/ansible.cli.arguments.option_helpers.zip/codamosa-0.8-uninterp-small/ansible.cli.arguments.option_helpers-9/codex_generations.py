

# Generated at 2022-06-24 17:33:59.976351
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser("test_add_runas_options")
    add_runas_options(parser)
    add_module_options(parser)
    ansible_args = parser.parse_args(["-M", "/tmp", "-b", "--become-method", "sudo", "--become-user", "root"])
    test_case_0()


# Generated at 2022-06-24 17:34:05.934305
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    args = parser.parse_args('--force-handlers'.split())
    assert args.force_handlers == True
    args = parser.parse_args('--flush-cache'.split())
    assert args.flush_cache == True



# Generated at 2022-06-24 17:34:09.821973
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser("test")
    add_meta_options(parser)
    var_0 = vars(parser.parse_args(args=[]))
    assert var_0["force_handlers"] == False


# Generated at 2022-06-24 17:34:11.019406
# Unit test for function add_connect_options
def test_add_connect_options():
    var_0 = add_connect_options()


# Generated at 2022-06-24 17:34:17.481842
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser(description='Usage: %(prog)s COMMAND')
    parser.add_argument('--vault-id', default=['abc'], dest='vault_ids', action='append', type=str)
    base_group = parser.add_mutually_exclusive_group()
    base_group.add_argument('--ask-vault-password', '--ask-vault-pass', default=['abc'], dest='ask_vault_pass', action='store_true')
    base_group.add_argument('--vault-password-file', '--vault-pass-file', default=['abc'], dest='vault_password_files', help="vault password file", type=unfrack_path(), action='append')
    add_vault_options(parser)

# Generated at 2022-06-24 17:34:26.823685
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    dict_0 = vars(parser.parse_args(args = []))
    assert dict_0['ask_vault_pass'] == False

    dict_1 = vars(parser.parse_args(args = ['--ask-vault-password']))
    assert dict_1['ask_vault_pass'] == True

    dict_2 = vars(parser.parse_args(args = ['--vault-password-file', 'vault-password-file']))
    assert dict_2['vault_password_files'] == ['vault-password-file']

    dict_3 = vars(parser.parse_args(args = ['--vault-id', 'vault-id']))

# Generated at 2022-06-24 17:34:28.803733
# Unit test for function unfrack_path
def test_unfrack_path():
    var_2 = unfrack_path()


# Generated at 2022-06-24 17:34:33.550675
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()

    # Case 0
    # Set parser to have no arguments and add_vault_options
    test_case_0()
    assert var_0 == "0.0.1"

# Generated at 2022-06-24 17:34:41.120385
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(['-k', '--ask-pass'])
    assert args.ask_pass is True
    assert args.private_key_file is C.DEFAULT_PRIVATE_KEY_FILE
    assert args.remote_user is C.DEFAULT_REMOTE_USER
    assert args.connection is C.DEFAULT_TRANSPORT
    assert args.timeout == C.DEFAULT_TIMEOUT


# Generated at 2022-06-24 17:34:47.158314
# Unit test for function add_vault_options
def test_add_vault_options():
    var_2 = mock.Mock()
    var_2.parser = mock.Mock()
    var_2.parser.add_mutually_exclusive_group = mock.Mock(return_value = var_2.parser)
    var_2.parser.add_argument = mock.Mock(return_value = var_2.parser)
    var_2.parser.add_argument_group = mock.Mock(return_value = var_2.parser)
    var_2.parser.dest = mock.Mock(return_value = var_2.parser)
    var_2.parser.set_defaults = mock.Mock(return_value = var_2.parser)
    var_2.parser.error = mock.Mock(return_value = var_2.parser)

# Generated at 2022-06-24 17:35:11.199161
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('-')
    var_0('--lookup')
    var_0('/path/to/lookup')

#
# Options for all Ansible utilities
#

# Generated at 2022-06-24 17:35:17.504470
# Unit test for function add_subset_options
def test_add_subset_options():
    argv = shlex.split("-t ttt --skip-tags ssss")
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    args = parser.parse_args(argv)
    assert args.tags == ["ttt"]
    assert args.skip_tags == ["ssss"]


# Generated at 2022-06-24 17:35:19.539947
# Unit test for function ensure_value
def test_ensure_value():
    var_1 = ensure_value(namespace = None, name = "test", value = [])
    assert var_1 == []


# Generated at 2022-06-24 17:35:25.373402
# Unit test for function add_subset_options
def test_add_subset_options():
    test_parser = create_base_parser('ansible-playbook', usage='', desc='')
    add_subset_options(test_parser)
    tmp = sys.argv
    sys.argv = ["bin/ansible-playbook", "-t", "tag_test_0"]
    namespace = test_parser.parse_args()
    if namespace.tags:
        assert namespace.tags == ["tag_test_0"]
    sys.argv = tmp

# Generated at 2022-06-24 17:35:29.370013
# Unit test for function ensure_value
def test_ensure_value():
    var_2 = ensure_value()
    var_3 = ensure_value(var_2)
    var_4 = ensure_value(var_3, var_2, var_3)


# Generated at 2022-06-24 17:35:30.411954
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)



# Generated at 2022-06-24 17:35:32.107206
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('foo') == 'foo'
    assert unfrack_path(pathsep=True)('/foo:/bar') == ['/foo', '/bar']


# Generated at 2022-06-24 17:35:37.769024
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser = argparse.ArgumentParser(
        prog="program_name",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="description",
        conflict_handler='resolve',
    )

    add_basedir_options(parser)

    test_str = "--playbook-dir, help message: Since this tool does not use playbooks, use this as a substitute playbook directory.This sets the relative path for many features including roles/ group_vars/ etc."

    assert test_str in parser.format_help()



# Generated at 2022-06-24 17:35:41.813305
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path() == 'test'
    assert maybe_unfrack_path() == 'test'
    assert maybe_unfrack_path() == 'test'


# Generated at 2022-06-24 17:35:44.816663
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()
    var_1 = unfrack_path(True) # add boolean param
    var_2 = unfrack_path(pathsep=True) # add named param


# Generated at 2022-06-24 17:35:53.319215
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = '-'
    var_1 = 'path/to/somewhere'
    my_func = maybe_unfrack_path(var_0)
    var_2 = my_func(var_1)
    assert var_2 == var_1


# Generated at 2022-06-24 17:35:57.693916
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # TODO: Set up a parser and namespace for testing
    ap = argparse.ArgumentParser()
    ns = argparse.Namespace()
    # TODO: Provide args for test
    args = []
    # TODO: Set up a object for testing
    a = PrependListAction(*args, **kwargs)
    # TODO: Inject test code here
    a.__call__(ap, ns)


# Generated at 2022-06-24 17:36:01.486445
# Unit test for function ensure_value
def test_ensure_value():
    var_1 = ensure_value(None, None, None)
    var_2 = ensure_value(None, None, None)
    var_3 = ensure_value(None, None, None)



# Generated at 2022-06-24 17:36:08.465206
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # set up test environment
    arg1 = argparse.Namespace(a=[], b=[], c=[])
    arg2 = argparse.Namespace(a=[], b=[], c=[])
    arg3 = argparse.Namespace(a=[], b=[], c=[])
    arg4 = argparse.Namespace(a=[], b=[], c=[])
    arg5 = argparse.Namespace(a=[], b=[], c=[])
    arg6 = argparse.Namespace(a=[], b=[], c=[])
    arg7 = argparse.Namespace(a=[], b=[], c=[])
    arg8 = argparse.Namespace(a=[], b=[], c=[])
    action = PrependListAction(option_strings = ['-a', '--bar'], dest = "b")
    action2 = Prep

# Generated at 2022-06-24 17:36:12.283464
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(False)('abc') is 'abc'
    assert unfrack_path(False)('a/b/c') is 'a/b/c'


# Generated at 2022-06-24 17:36:15.403600
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_maybe_unfrack_path_0()


# Generated at 2022-06-24 17:36:24.367566
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    # Create a new instance of class PrependListAction
    PrependListAction_0 = PrependListAction(option_strings=['PrependListAction_option_strings'], dest='PrependListAction_dest', nargs=2, const='PrependListAction_const', default='PrependListAction_default', type='PrependListAction_type', choices=['PrependListAction_choices'], required=False, help='PrependListAction_help', metavar='PrependListAction_metavar')

    # Call method __call__ of class PrependListAction
    PrependListAction___call___0 = PrependListAction_0.__call__(parser='parser', namespace='namespace', values='values', option_string='option_string')


# Generated at 2022-06-24 17:36:25.296385
# Unit test for function ensure_value
def test_ensure_value():
    var_1 = ensure_value({}, "a", 1)
    assert var_1 == 1



# Generated at 2022-06-24 17:36:29.232027
# Unit test for function ensure_value
def test_ensure_value():
    namespace = C
    value = 'test_value'
    assert ensure_value(namespace, 'DEFAULT_BECOME_METHOD', value) == 'test_value'
    namespace = C
    assert ensure_value(namespace, 'DEFAULT_BECOME_METHOD', value) == 'sudo'


# Generated at 2022-06-24 17:36:32.562972
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    setattr(namespace, "x", "foo")
    assert ensure_value(namespace, "x", "bar") == "foo"


# Generated at 2022-06-24 17:36:48.445529
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = version()
    os.environ["_ANSIBLE_MODULE_PATH"] = "/Users/sam/.local/lib/python3.7/site-packages/ansible/modules/windows"
    os.environ["_ANSIBLE_TEST_DATA_ROOT"] = "/Users/sam/.local/lib/python3.7/site-packages/ansible/modules/windows"
    os.environ["_ANSIBLE_MODULE_PATH"] = "/Users/sam/.local/lib/python3.7/site-packages/ansible/modules/net_tools"
    os.environ["_ANSIBLE_TEST_DATA_ROOT"] = "/Users/sam/.local/lib/python3.7/site-packages/ansible/modules/net_tools"

# Generated at 2022-06-24 17:36:52.465386
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()


# Generated at 2022-06-24 17:36:54.604955
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    result = maybe_unfrack_path()
    assert result == maybe_unfrack_path


# Generated at 2022-06-24 17:36:55.799117
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    var_0 = add_tasknoplay_options(argparse.ArgumentParser())
    assert var_0 == None


# Generated at 2022-06-24 17:36:57.068072
# Unit test for function add_tasknoplay_options
def test_add_tasknoplay_options():
    parser = create_base_parser()
    add_tasknoplay_options(parser)
    args = parser.parse_args()



# Generated at 2022-06-24 17:37:08.237412
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Making sure unfrackpath will be passed.
    beacon = '$ANSIBLE_LIBRARY/'
    value = '$ANSIBLE_LIBRARY/test.txt'
    expected = '$ANSIBLE_LIBRARY/test.txt'
    got = maybe_unfrack_path(beacon)(value)
    assert(got == expected)

    # Making sure unfrackpath will be replaced.
    beacon = '$ANSIBLE_LIBRARY/'
    value = '$ANSIBLE_LIBRARY/test/test.txt'
    expected = '$ANSIBLE_LIBRARY/test/test.txt'
    got = maybe_unfrack_path(beacon)(value)
    assert(got == expected)

    # Making sure unfrackpath will not be replaced.

# Generated at 2022-06-24 17:37:13.330500
# Unit test for function add_basedir_options
def test_add_basedir_options():
    parser=create_base_parser("","","","")
    add_basedir_options(parser)
    args=parser.parse_args(["--playbook-dir",".."])
    assert args.basedir == "../.."


# Generated at 2022-06-24 17:37:15.100027
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('beacon')('beacon'+'value') == 'beacon'+'value'


# Generated at 2022-06-24 17:37:22.411678
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = os.sep
    def var_6():
        return __file__
    assert not os.path.isabs(var_6())
    #### 
    #### if var_1 == '/':
    ####    var_2 = '/var/lib/awx/venv/awx/lib/python3.7/site-packages/awxkit/__init__.py'
    #### else:
    ####    var_2 = 'C:\\Program Files\\Tower\\venv\\Scripts\\awx-manage'
    #### 
    #### print(var_2)
    #### assert os.path.isabs(var_2)
    def var_7(arg):
        var_8 = os.path.sep
        #### return arg.split(var_8)

# Generated at 2022-06-24 17:37:30.161145
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert ('/private/test/testfile.txt' == maybe_unfrack_path('~')('~/test/testfile.txt'))
    assert ('~/test/testfile.txt' == maybe_unfrack_path('~')('~/test/testfile.txt'))


# Generated at 2022-06-24 17:37:43.154109
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/home/dv/env/ansible/') == '/home/dv/env/ansible/'
    assert unfrack_path(True)('/home/dv/env/ansible/:/home/dv/env/nvme-cli/') == ['/home/dv/env/ansible/', '/home/dv/env/nvme-cli/']
    assert unfrack_path()('-') == '-'
    assert unfrack_path(True)('-') == ['-']
    assert unfrack_path()('/home/dv/env/ansible/') == '/home/dv/env/ansible/'



# Generated at 2022-06-24 17:37:54.467361
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path("")
    assert var_1("") == "", "Test case #1 failed"
    assert var_1("") == "", "Test case #2 failed"
    assert var_1("") == "", "Test case #3 failed"
    assert var_1("") == "", "Test case #4 failed"
    assert var_1("") == "", "Test case #5 failed"
    assert var_1("") == "", "Test case #6 failed"
    assert var_1("") == "", "Test case #7 failed"
    assert var_1("") == "", "Test case #8 failed"
    assert var_1("") == "", "Test case #9 failed"
    assert var_1("") == "", "Test case #10 failed"
    assert var_

# Generated at 2022-06-24 17:38:07.278439
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = version()
    var_1 = {}
    var_2 = {}
    var_3 = []
    var_4 = []
    var_5 = {}
    var_6 = {}
    var_7 = []
    var_8 = []
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = []
    var_15 = []
    var_16 = {}
    var_17 = {}
    var_18 = {}
    var_19 = {}
    var_20 = []
    var_21 = []
    var_22 = []
    var_23 = []
    var_24 = []
    var_25 = []
    var_26 = []
    var_27 = {}
    var

# Generated at 2022-06-24 17:38:13.438082
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = version()
    var_1 = unfrack_path( False)()
    print(var_0, var_1)
    #assert var_0 == var_1

#
# Specialized OptionParsers
#

# Generated at 2022-06-24 17:38:15.487485
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)


# Generated at 2022-06-24 17:38:29.154584
# Unit test for function version
def test_version():
    var_0 = ("ansible 2.9.18\n"
             "  config file = /wrk/ansible.cfg\n"
             "  configured module search path = /wrk/lib/ansible/modules:/wrk/lib/ansible/modules\n"
             "  ansible python module location = None\n"
             "  ansible collection location = /wrk/lib/ansible/collections\n"
             "  executable location = /wrk/bin/ansible\n"
             "  python version = 3.7.3 (default, Dec 20 2019, 18:57:59)\n"
             "  jinja version = 2.10.1\n"
             "  libyaml = 3.13\n")
    assert var_0 == version(), 'return value is wrong'


# Generated at 2022-06-24 17:38:32.041701
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    # Set up test values
    beacon = 'beacon'

    # Invoke method
    result = maybe_unfrack_path(beacon)

    assert result != None


# Generated at 2022-06-24 17:38:34.144079
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Build default args (no arg)
    sys.argv = [os.path.basename(__file__)]
    parser = SortingHelpFormatter()
    test_case_0()



# Generated at 2022-06-24 17:38:37.733594
# Unit test for function unfrack_path
def test_unfrack_path():
    assert len(unfrack_path(False)) == 1
    assert callable(unfrack_path(False)) == True


# Generated at 2022-06-24 17:38:39.553658
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = PrependListAction()
    var_1 = var_0.__call__()


# Generated at 2022-06-24 17:38:46.574308
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()
    


# Generated at 2022-06-24 17:38:50.440394
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrackpath('ansible')
    var_2 = unfrackpath('ansible/')
    var_3 = unfrackpath('ansible/temp/')

    assert var_1 == var_2
    assert var_1 == var_3


# Generated at 2022-06-24 17:38:51.954452
# Unit test for function version
def test_version():
    assert(version() is not None)


#
# Abstract Options
#

# Generated at 2022-06-24 17:38:55.172490
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    var_1 = PrependListAction(option_strings='', dest='', nargs='', const='', default='', type='', choices='', required='', help='', metavar='')


# Generated at 2022-06-24 17:38:57.448391
# Unit test for function unfrack_path
def test_unfrack_path():
    # test_unfrack_path_0()
    assert True

if __name__ == '__main__':
    test_unfrack_path()
    test_case_0()

# Generated at 2022-06-24 17:38:59.338696
# Unit test for function version
def test_version():
    var_1 = version()



# Generated at 2022-06-24 17:39:03.006358
# Unit test for function unfrack_path
def test_unfrack_path():
    if __name__ == '__main__':

        # Initial setup for all cases
        pathsep=False

        # Case 0
        var_0 = unfrack_path(pathsep)
        print("\nCase 0 - output: " + str(var_0))



#
# Callbacks to read configs and other files
#

# Generated at 2022-06-24 17:39:05.778365
# Unit test for function unfrack_path
def test_unfrack_path():
    data_0 = 'examples'
    result_0 = unfrack_path()(data_0)
    assert result_0 == 'examples'


# Generated at 2022-06-24 17:39:12.841472
# Unit test for function version
def test_version():
    if not os.path.exists("/Users/megan/Desktop/python/udemy/projects/ansible"):
        os.makedirs("/Users/megan/Desktop/python/udemy/projects/ansible")
    if not os.path.exists("/Users/megan/Desktop/python/udemy/projects/ansible/test_results.txt"):
        with open("/Users/megan/Desktop/python/udemy/projects/ansible/test_results.txt", 'w') as file:
            file.write("Expected results on the left, your results on the right:\n\n")

# Generated at 2022-06-24 17:39:14.938278
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    class test_PrependListAction___call__():

        def __init__(self):
            self.var = False

        def run_test(self):
            return not self.var
    return test_PrependListAction___call__()


# Generated at 2022-06-24 17:39:25.809009
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = version()
    dirs = ['/etc/ansible', '~/ansible', '../ansible']

    # AssertionError: '/etc/ansible/../ansible' should be '/etc/ansible'


#
# Option Parsers
#

# Generated at 2022-06-24 17:39:30.876066
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
        assert PrependListAction.__init__('self', 'option_strings', 'dest', 'nargs=None', 'const=None', 'default=None', 'type=None', 'choices=None', 'required=False', 'help=None', 'metavar=None')

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_case_0()
    test_PrependListAction()

# Generated at 2022-06-24 17:39:32.473218
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_0 = SortingHelpFormatter()


# Generated at 2022-06-24 17:39:36.571883
# Unit test for function unfrack_path
def test_unfrack_path():
    if version == 1:
        assert unfrack_path() == "ansible-playbook 2.8.5\n  config file = \n"



# Generated at 2022-06-24 17:39:46.792650
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    v0 = version()
    v1 = ('0.0.0',)
    v2 = ('0.0.0', '0.0.0')
    v3 = (0,)
    v4 = (1,)
    v5 = (2,)
    v6 = (3,)
    v7 = (1, 2, 3)
    v8 = (0, 2, 3)
    v9 = (0, 1, 3)
    v10 = (0, 1, 2)
    v11 = (1, 2, 3)
    v12 = (0, 2, 3)
    v13 = (0, 1, 3)
    v14 = (0, 1, 2)
    v15 = [PrependListAction.__call__, v2, v3, v4, v5, v6]
    v

# Generated at 2022-06-24 17:39:51.130361
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Sends in option for system path
    my_option = '-/path/to/system/file'
    result = maybe_unfrack_path(my_option)
    assert result is not None


# Generated at 2022-06-24 17:39:53.529188
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    obj_0 = PrependListAction()
    obj_0.__call__()


# Generated at 2022-06-24 17:39:55.500059
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # case 1 for constructor
    test_SortingHelpFormatter = SortingHelpFormatter()


# Generated at 2022-06-24 17:39:56.582362
# Unit test for function version
def test_version():
    version()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:40:02.567292
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    if (os.getenv('TEST') is None):
        return
    var_0 = SortingHelpFormatter(prog='program', indent_increment=3, max_help_position=30, width=80)

if __name__ == '__main__':
    # Unit test for constructor of class SortingHelpFormatter
    test_SortingHelpFormatter()
    # Unit test for method SortingHelpFormatter.add_arguments
    test_SortingHelpFormatter.add_arguments()
    # Unit test for method SortingHelpFormatter.add_argument
    test_SortingHelpFormatter.add_argument()
    # Unit test for method SortingHelpFormatter.add_usage
    test_SortingHelpFormatter.add_usage()
    # Unit test for method SortingHelpFormatter.format_help
   

# Generated at 2022-06-24 17:40:14.406624
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_1 = SortingHelpFormatter()
    pass



# Generated at 2022-06-24 17:40:16.616903
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = os.getcwd()
    var_1 = maybe_unfrack_path(var_0)


# Generated at 2022-06-24 17:40:22.854246
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = './test_case_files/ansible_version'
    var_2 = maybe_unfrack_path('-c')
    var_3 = var_2(var_1)
    assert var_3 == '-c./test_case_files/ansible_version'


# Generated at 2022-06-24 17:40:25.681514
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 17:40:34.659037
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_pars = argparse.ArgumentParser()
    var_namespace = var_pars.parse_args()
    var_values = [2, 3]
    var_option_string = None
    var_method =  PrependListAction(option_strings = None, dest = 'dest', help = None, metavar = None)
    # Assign call to __call__ of class PrependListAction to var_result
    var_result = var_method(var_pars,var_namespace,var_values,var_option_string)
    if type(var_result) ==  PrependListAction:
        print(True)
    else:
        print(False)


# Generated at 2022-06-24 17:40:36.098446
# Unit test for function unfrack_path
def test_unfrack_path():
    assert(unfrack_path())


# Generated at 2022-06-24 17:40:47.503094
# Unit test for function version
def test_version():
    try:
        var_1 = os.path.basename(__file__)
    except Exception as e:
        print(e)
        var_1 = ''
        pass
    var_2 = version(var_1)
    print(var_2)
    #assert var_2 == '2.8.1 (devel b053f3a62) last updated 2020/11/29 23:24:15 (GMT +0100)  config file = /etc/ansible/ansible.cfg  configured module search path = [u'/root/.ansible/plugins/modules', u'/usr/share/ansible/plugins/modules']  ansible python module location = /usr/lib/python2.7/site-packages/ansible  ansible collection location = /usr/share/ansible/collections  executable location = /usr/bin/ans

# Generated at 2022-06-24 17:40:50.906399
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = argparse.ArgumentParser()
    var_1 = PrependListAction(option_strings=None, dest='cor', nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)
    var_1.__call__(parser=var_0, namespace=None, values=None, option_string=None)


# Generated at 2022-06-24 17:41:03.985215
# Unit test for function version
def test_version():
    var_1 = version(prog="None")
    var_2 = version(prog="Test")
    if var_1 == "None [core 2.9.9]\ntest" and var_2 == "Test [core 2.9.9]\ntest":
        print("Unit test for function version passed")
    else:
        var_0 = version()
        while var_0 == "None [core 2.9.9]\ntest" and var_2 == "Test [core 2.9.9]\ntest":
            var_0 = version()
            var_1 = version(prog="None")
            var_2 = version(prog="Test")

# Generated at 2022-06-24 17:41:07.807464
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    var_0 = PrependListAction((), 'var_0')
    var_1 = ParserEx()
    var_2 = var_0.__call__(var_1, 'var_2', {}, 'var_3')


# Generated at 2022-06-24 17:41:34.118732
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('-c')('-c') == '-c'


# Generated at 2022-06-24 17:41:43.370192
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    from ansible.utils.path import unfrackpath

    user_home_dir = os.path.expanduser('~')
    test_file_path = user_home_dir + os.sep + 'test_file'

    expected_out = '~' + os.sep + 'test_file'
    actual_out = maybe_unfrack_path(expected_out[0:1])(test_file_path)

    assert expected_out == actual_out, "Expected {0}, but got {1}".format(expected_out, actual_out)


# Generated at 2022-06-24 17:41:46.802803
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('/Users/jk/')
    res_0 = var_0('/Users/jk/')
    return res_0


# Generated at 2022-06-24 17:41:51.336117
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    print("Testing function maybe_unfrack_path...")
    test_case_0()
    print("Success!")



# Generated at 2022-06-24 17:41:56.816992
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    arg0 = argparse.ArgumentParser()
    arg0.add_argument("-a", dest="vars", default=[], action=PrependListAction)
    argv = ["-a", "a", "-a", "b", "foo", "-a", "c", "bar"]
    ns = arg0.parse_args(argv)
    assert ns.vars == ["c", "b", "a"]


# Generated at 2022-06-24 17:42:06.244561
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    print("test_PrependListAction___call__")

    # Test the case where self.nargs is None
    option_strings = ["option_strings-value"]
    dest = "dest-value"
    nargs = None
    const = "const-value"
    default = "default-value"
    type = "type-value"
    choices = "choices-value"
    required = False
    help = "help-value"
    metavar = "metavar-value"
    a = PrependListAction(option_strings, dest, nargs, const, default, type, choices, required, help, metavar)

    # Test the case where self.nargs is OPTIONAL
    option_strings = ["option_strings-value"]
    dest = "dest-value"
    nargs = "OPTIONAL"

# Generated at 2022-06-24 17:42:13.074136
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = "./test_ansible_module_utils_common_common.py"
    var_1 = "/Users/ansible/ansible/test/units/module_utils/common/test_ansible_module_utils_common_common.pyc"
    var_2 = "./test/units/module_utils/common/test_ansible_module_utils_common_common.py"
    var_3 = "./test_ansible_module_utils_common_common.py"
    var_4 = "/Users/ansible/ansible/test/units/module_utils/common/test_ansible_module_utils_common_common.py"
    var_5 = "/Users/ansible/ansible/test_ansible_module_utils_common_common.pyc"

# Generated at 2022-06-24 17:42:21.876116
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/my/dir') == '/my/dir'
    assert unfrack_path()('~/my/dir') == os.path.expanduser('~/my/dir')
    assert unfrack_path()('/my/dir/') == '/my/dir'
    assert unfrack_path()('~/') == '/home/net4tec'
    assert unfrack_path(True)('/my/dir:/my/other/dir:/my/other/other/dir') == ['/my/dir', '/my/other/dir', '/my/other/other/dir']

#
# Common OptionGroups
#

# Generated at 2022-06-24 17:42:23.620192
# Unit test for function unfrack_path
def test_unfrack_path():
    data = [("pathsep=False", False), ("pathsep=True", True)]
    for d in data:
        test_case_0(d[0], d[1])


# Generated at 2022-06-24 17:42:31.834457
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    param_0 = None
    param_1 = None
    param_2 = None
    param_3 = None
    obj_0 = argparse.Action()
    obj_1 = PrependListAction()
    obj_1.__call__(arg1=obj_0, arg2=param_1, arg3=param_2, arg4=param_3)
