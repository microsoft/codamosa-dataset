

# Generated at 2022-06-24 17:34:07.041462
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", action=PrependListAction)
    parser.add_argument("-b", action=PrependListAction)
    parser.add_argument("-c", action=PrependListAction, nargs="?")
    parser.add_argument("-d", action=PrependListAction, nargs="*")
    parser.add_argument("-e", action=PrependListAction, nargs=2)
    parser.add_argument("-f", action=PrependListAction, nargs=argparse.REMAINDER)
    parser.add_argument("-g", action=PrependListAction, nargs=argparse.OPTIONAL)

# Generated at 2022-06-24 17:34:15.251917
# Unit test for function add_inventory_options
def test_add_inventory_options():
    global __author__
    global __license__
    global __version__

    ansible_options = 'ansible options'

    # Test case 0, 1
    parser = create_base_parser(ansible_options)
    add_inventory_options(parser)

    # Test case 0
    test_case_0()

    # Test case 1

# Generated at 2022-06-24 17:34:18.414921
# Unit test for function version
def test_version():
    print("test_version")
    tuple_0 = ()
    var_0 = version(tuple_0)
    print(var_0)

# Main function, where all the magic happens

# Generated at 2022-06-24 17:34:20.739951
# Unit test for function add_runtask_options
def test_add_runtask_options():
    from argparse import ArgumentParser
    parser = ArgumentParser(prog="ansible-playbook", formatter_class=SortingHelpFormatter)
    add_runtask_options(parser)
    return parser

# Generated at 2022-06-24 17:34:27.582704
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    try:
        tuple_0 = ()
        instance_0 = PrependListAction(tuple_0, tuple_0, argparse.OPTIONAL, None, None)
        namespace_0 = None
        values_0 = None
        option_string_0 = None
        instance_0.__call__(namespace_0, values_0, option_string_0)
    except argparse.ArgumentError as e:
        msg = "unrecognized arguments: %s" % option_string_0
        var_0 = to_native(e) == msg


# Generated at 2022-06-24 17:34:31.598552
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    tuple_0 = ()
    var_0 = version(tuple_0)
    print(var_0)
    print(version(tuple_0))


# Generated at 2022-06-24 17:34:34.613664
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    tuple_0 = ()
    var_0 = version(tuple_0)



# Generated at 2022-06-24 17:34:36.296641
# Unit test for function add_inventory_options
def test_add_inventory_options():
    parser = argparse.ArgumentParser()
    # TODO: add test cases
    # expected_results = []
    add_inventory_options(parser)
    test_list_hosts_1()
    test_subset_1()
    test_inventory_1()


# Generated at 2022-06-24 17:34:41.094485
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = ['--without-tags']
    dest = 'without_tags'
    nargs = None
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = 'only run plays and tasks whose tags do not match these values'
    metavar = None
    tuple_0 = (dest, nargs, const, default, type, choices, required, help, metavar)
    str_0 = "--without-tags"
    var_0 = argparse.Action(option_strings, dest, nargs, const, default, type, choices, required, help, metavar)
    list_0 = []
    var_0.__call__(var_0, list_0, str_0)


# Generated at 2022-06-24 17:34:52.087180
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    tuple_0 = ()
    var_0 = version(tuple_0)
    tuple_1 = ()
    var_1 = version(tuple_1)
    tuple_2 = ()
    var_2 = version(tuple_2)
    tuple_3 = ()
    var_3 = version(tuple_3)
    tuple_4 = ()
    var_4 = version(tuple_4)
    tuple_5 = ()
    var_5 = version(tuple_5)
    tuple_6 = ()
    var_6 = version(tuple_6)
    tuple_7 = ()
    var_7 = version(tuple_7)
    tuple_8 = ()
    var_8 = version(tuple_8)
    tuple_9 = ()
    var_9 = version(tuple_9)

# Generated at 2022-06-24 17:35:10.451055
# Unit test for function add_vault_options
def test_add_vault_options():
    """Unit test for function add_vault_options"""
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    args = parser.parse_args([])
    assert args.vault_ids == [] and args.vault_password_files == [] and args.ask_vault_pass is False
    #
    args = parser.parse_args(['--vault-id', 'foo', '--vault-password-file', '/tmp/bar', '--vault-password-file', '/tmp/baz'])
    assert args.vault_ids == ['foo'] and args.vault_password_files == ['/tmp/bar', '/tmp/baz'] and args.ask_vault_pass is False
    #

# Generated at 2022-06-24 17:35:14.928994
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser(prog=str_0, description=str_0 + ' playbook.yml')
    add_check_options(parser)
    parser.parse_args()


# Generated at 2022-06-24 17:35:17.632029
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    try:
        parser.parse_args('--become --become-method su --become-user test_user'.split())
    except SystemExit:
        assert False, 'add_runas_options FAILED'



# Generated at 2022-06-24 17:35:20.688606
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = add_runas_options(create_base_parser('ansible-playbook'))

    # test for default value of default_become_user
    default_become_user = parser.get_default('become_user')
    assert C.DEFAULT_BECOME_USER == default_become_user


# Generated at 2022-06-24 17:35:22.875238
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = argparse.ArgumentParser()
    add_meta_options(parser)
    test_case_0()


# Generated at 2022-06-24 17:35:27.116231
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    parser_0 = AnsibleVersion()
    parser_1 = 'ansible-playbook'
    str_0 = parser_0.__call__(parser_1)
    print(str_0)


# Generated at 2022-06-24 17:35:29.162450
# Unit test for function add_module_options
def test_add_module_options():
    parser_5 = argparse.ArgumentParser()
    add_module_options(parser_5)


# Generated at 2022-06-24 17:35:32.256430
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    args = {}
    try:
        ansible.module_utils.basic._ANSIBLE_ARGS = None
        ansible.module_utils.basic._ANSIBLE_ARGS = []
        add_runas_prompt_options(args, None)
        assert args.become_ask_pass == False
        assert args.become_password_file == None
    except:
        pass
    finally:
        ansible.module_utils.basic._ANSIBLE_ARGS = None
        ansible.module_utils.basic._ANSIBLE_ARGS = []


# Generated at 2022-06-24 17:35:36.326745
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(prog='ansible-playbook', description='test')
    add_runas_prompt_options(parser)
    test_args = "--ask-become-pass".split()
    namespace = parser.parse_args(test_args)

# Generated at 2022-06-24 17:35:48.554999
# Unit test for function add_subset_options
def test_add_subset_options():
    parser_0 = argparse.ArgumentParser()
    func(parser_0)
    for arg in sys.argv[1:]:
        if arg.startswith("-"):
            break
        sys.argv.remove(arg)
    setattr(_options, 'prog', "ansible-playbook")
    setattr(_options, 'tags', ["1"])
    _options.tags.append("1")
    argparse.Namespace.tags.fget(_options)
    test_case_0()

    parser_0 = argparse.ArgumentParser()
    func(parser_0)
    for arg in sys.argv[1:]:
        if arg.startswith("-"):
            break
        sys.argv.remove(arg)

# Generated at 2022-06-24 17:36:08.883328
# Unit test for function add_check_options
def test_add_check_options():
    parser = create_base_parser(test_case_0(), usage=test_case_0.__doc__)
    add_check_options(parser)
    arg_0 = parser._get_optional_actions()[0]
    assert arg_0.dest == 'check'
    assert arg_0.default == False
    assert arg_0.type == None
    assert arg_0.help == "don't make any changes; instead, try to predict some of the changes that may occur"
    arg_1 = parser._get_optional_actions()[1]
    assert arg_1.dest == 'syntax'
    assert arg_1.default == None
    assert arg_1.type == None
    assert arg_1.help == "perform a syntax check on the playbook, but do not execute it"
    arg_2 = parser._get

# Generated at 2022-06-24 17:36:13.836955
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    namespace = 'ansible-playbook'
    values = {'version': 'false'}
    option_string = 'ansible-playbook'
    obj = PrependListAction()
    obj.__call__(namespace, values, option_string)



# Generated at 2022-06-24 17:36:24.043805
# Unit test for function ensure_value
def test_ensure_value():
    str_0 = 'ansible-playbook'
    str_1 = '--syntax-check'
    str_2 = '--diff'
    str_3 = '--connection='
    str_4 = '--sudo'
    str_5 = '--su'
    str_6 = '--ask-password'
    str_7 = '--ask-su-pass'
    str_8 = '--ask-sudo-pass'
    str_9 = '--ask-vault-pass'
    str_10 = '--vault-password-file='
    str_11 = '--vault-ed25519-key='
    str_12 = '--vault-id='
    str_13 = '--vault-id-file='
    str_14 = '--vault-id-format='
    str_

# Generated at 2022-06-24 17:36:29.696806
# Unit test for function unfrack_path
def test_unfrack_path():
    print(unfrack_path())
    print(unfrack_path.__dict__)

if __name__ == '__main__':
    #test_case_0()
    #test_unfrack_path()
    #AnsibleVersion()
    #SortingHelpFormatter()

    #unrecognized_argument = UnrecognizedArgument()
    #print(unrecognized_argument.__dict__)
    #UnrecognizedArgument()

    parser = argparse.ArgumentParser(description="test")
    parser.add_argument('-d', action='store_true', help="debug")
    parser.add_argument('--bar', help=argparse.SUPPRESS)
    parser.add_argument('--baz', help=argparse.SUPPRESS)


# Generated at 2022-06-24 17:36:42.573074
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('ansible-playbook') == expected_result_0
    assert maybe_unfrack_path('ansible-playbook') == expected_result_1
    assert maybe_unfrack_path('ansible-playbook') == expected_result_2
    assert maybe_unfrack_path('ansible-playbook') == expected_result_3
    assert maybe_unfrack_path('ansible-playbook') == expected_result_4
    assert maybe_unfrack_path('ansible-playbook') == expected_result_5
    assert maybe_unfrack_path('ansible-playbook') == expected_result_6
    assert maybe_unfrack_path('ansible-playbook') == expected_result_7

# Generated at 2022-06-24 17:36:52.968775
# Unit test for function ensure_value
def test_ensure_value():
    # No-param case
    try:
        assert ensure_value() == None
    except TypeError:
        print("Expected TypeError on line 50")
    # One-param case
    try:
        assert ensure_value(1) == None
    except TypeError:
        print("Expected TypeError on line 55")
    # Two-param case
    try:
        assert ensure_value(1, 1) == None
    except TypeError:
        print("Expected TypeError on line 60")
    # Three-param case
    try:
        assert ensure_value(1, 1, 1) == 1
    except TypeError:
        print("Expected TypeError on line 65")
    # Four-param case

# Generated at 2022-06-24 17:37:02.227589
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    obj = ansible.cli.command.version.AnsibleVersion()
    
    # perform the method call
    obj.__call__()
    
    # verify the values present in the namespace
    args = parser.parse_args(args.split())



# Generated at 2022-06-24 17:37:12.036160
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():

    # Test case for call __call__(self, parser, namespace, values, option_string=None) with parameters (None, None, None, '-i')

    my_object = PrependListAction(option_strings=['-i'], dest='dest', nargs=None, const=None, default=None, type=None,
                 choices=None, required=False, help=None, metavar=None)
    argparse.ArgumentParser(description='description', prefix_chars='-', usage=None, add_help=True, allow_abbrev=True)
    argparse.Namespace()
    my_object.__call__(parser=None, namespace=None, values=None, option_string='-i')


# Generated at 2022-06-24 17:37:19.035318
# Unit test for function unfrack_path
def test_unfrack_path():
    ansible_version()
    ansible_version = to_native(version(getattr(parser, 'prog')))
    print(ansible_version)
    parser.exit()
    results_for_ansible_version_0 = ansible_version(a=1, b=2)
    with open('tmp_file_for_test_ansible_version_0', 'w') as file_0:
        file_0.write(results_for_ansible_version_0)
    expected_ansible_version_0 = 'ansible-playbook'
    assert results_for_ansible_version_0 == expected_ansible_version_0


# Generated at 2022-06-24 17:37:28.495273
# Unit test for function version
def test_version():
    print('')
    print('Executing test_version...')

    prog = 'ansible-playbook'
    # Test with program name

# Generated at 2022-06-24 17:37:54.998450
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    str_0 = 'ansible-playbook'
    str_1 = 'ansible-playbook'
    str_2 = 'ansible-playbook'
    str_3 = 'ansible-playbook'
    str_4 = 'ansible-playbook'
    str_5 = 'ansible-playbook'
    str_6 = 'h'
    str_7 = 'help'
    str_8 = 'ansible-playbook'
    str_9 = 'ansible-playbook'
    str_10 = 'ansible-playbook'
    str_11 = 'ansible-playbook'
    str_12 = 'ansible-playbook'
    str_13 = 'ansible-playbook'
    str_14 = 'ansible-playbook'
    str_15 = 'ansible-playbook'

# Generated at 2022-06-24 17:37:58.482408
# Unit test for function unfrack_path
def test_unfrack_path():
    assert True == unfrack_path()



# Generated at 2022-06-24 17:38:05.103394
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    ansible_version = ansible.__version__
    ansible_major_version = ansible_version.split('.')[0]
    if str(ansible_major_version) in ['2']:
        parser_case_0 = SortingHelpFormatter()
        parser_case_0.add_arguments(str_0)
        return parser_case_0

#
# Regular OptionParsers
#

# Generated at 2022-06-24 17:38:14.822196
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    str_0 = 'ansible-playbook'
    prepend_list_action_0 = PrependListAction(option_strings=None, dest=None, nargs=None, const=None, default=None, type=None, choices=None, required=False, help=None, metavar=None)
    try:
        prepend_list_action_0.__call__(parser=None, namespace=None, values=None, option_string=str_0)
    except Exception as exception_0:
        print('Exception message: ', str(exception_0))
        assert True

# Generated at 2022-06-24 17:38:17.525867
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(True)(str_0) == 'ansible-playbook'


# Generated at 2022-06-24 17:38:19.723583
# Unit test for function unfrack_path
def test_unfrack_path():
    pathsep = False
    assert_equal(unfrack_path(pathsep=False), inner)


# Generated at 2022-06-24 17:38:25.057689
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path)
    assert isinstance(unfrack_path(), type(unfrack_path))
    assert unfrack_path('-') == '-'
    assert unfrack_path('/dev/null') == '/dev/null'
    print('Test passed.')


# Generated at 2022-06-24 17:38:33.648246
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    version_response = version("ansible-playbook")
    version_expected = "ansible-playbook 2.5.5\n  config file = /etc/ansible/ansible.cfg\n  configured module search path = [u'/root/.ansible/plugins/modules', u'/usr/share/ansible/plugins/modules']\n  ansible python module location = /root/anaconda2/lib/python2.7/site-packages/ansible\n  executable location = /root/anaconda2/bin/ansible-playbook\n  python version = 2.7.15 (default, May  1 2018, 16:44:22) [GCC 7.3.0]\n\n"
    assert version_response == version_expected
    assert version_response == version_expected


# Generated at 2022-06-24 17:38:43.505732
# Unit test for function ensure_value
def test_ensure_value():
    str_list_0 = ["ansible-playbook"]
    ensure_value(str_list_0, "", "")
    str_list_1 = ["ansible-playbook"]
    ensure_value(str_list_1, "", "")
    str_list_1 = ["--force-color"]
    ensure_value(str_list_1, "", "")
    str_0 = '--force-color'
    str_1 = '--module-path'
    str_2 = '--module-path'
    str_3 = 'test_sample.yml'
    str_4 = 'test_sample.yml'
    str_5 = 'ansible-playbook'
    str_6 = '--force-color'
    str_7 = '--module-path'

# Generated at 2022-06-24 17:38:45.415774
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    formatter = SortingHelpFormatter()
    assert isinstance(formatter, argparse.HelpFormatter)


# Generated at 2022-06-24 17:39:19.969004
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    ansible_version = '2.9.1'
    assert ansible_version == to_native(version('ansible'))
    assert ansible_version == to_native(version('ansible-playbook'))
    assert ansible_version == to_native(version('ansible-doc'))
    assert ansible_version == to_native(version('ansible-console'))
    assert ansible_version == to_native(version('ansible-galaxy'))
    assert ansible_version == to_native(version('ansible-pull'))
    assert ansible_version == to_native(version('ansible-vault'))
    assert ansible_version == to_native(version('ansible-inventory'))
    assert ansible_version == to_native(version('ansible-config'))
    assert ansible

# Generated at 2022-06-24 17:39:24.757321
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    str_0 = 'ansible-playbook'
    str_t0 = maybe_unfrack_path(str_0)('foo')
    print(str_t0)


# Generated at 2022-06-24 17:39:33.431547
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser_1 = argparse.ArgumentParser(description='test_prepend')
    parser_1.add_argument('--test', dest='test_opt', action=PrependListAction)
    parser_1.add_argument('--test2', dest='test_opt')
    parser_1.add_argument('foo', nargs='*')
    argv = ['--test', 'first', '--test2', 'second', 'foo']
    args = parser_1.parse_args(argv)
    assert args.test_opt == ['first']
    assert args.test_opt == ['first']
    assert args.test_opt == 'first'
    assert args.test_opt == 'first'
    assert args.test_opt == ['first']


# Generated at 2022-06-24 17:39:45.511885
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    action = AnsibleVersion(option_strings=None, dest=None, nargs=None, const=None, default=None, type=None, choices=None, required=None, help=None, metavar=None)
    arg_1 = None
    arg_2 = None
    arg_3 = None
    arg_4 = None
    try:
        action.__call__(arg_1, arg_2, arg_3, arg_4)
    except RuntimeError as e:
        print("RuntimeError: %s" %(e))
    except:
        print("Exception detected")
    else:
        print("Success")
        

# Generated at 2022-06-24 17:39:53.405495
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    str_0 = b'G'
    py_0 = maybe_unfrack_path(str_0)
    str_1 = b'~/.ansible/tmp'
    str_2 = b'G/root/.ansible/tmp'
    assert str_2 == py_0(str_1)
    str_1 = b'~/.ansible/tmp'
    str_2 = b'~/.ansible/tmp'
    assert str_2 == py_0(str_1)
    str_1 = b'~/.ansible/tmp'
    str_2 = b'~/.ansible/tmp'
    assert str_2 == py_0(str_1)
    str_1 = b'G~/.ansible/tmp'
    str_2 = b'G~/.ansible/tmp'

# Generated at 2022-06-24 17:40:01.355982
# Unit test for function ensure_value
def test_ensure_value():
    from ansible import context
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.errors import AnsibleOptionsError
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-24 17:40:07.382330
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    args_0 = './ansible-playbook'
    arg_1 = maybe_unfrack_path(args_0)
    assert arg_1 == './ansible-playbook'
if __name__ == "__main__":
    test_maybe_unfrack_path()

# Generated at 2022-06-24 17:40:21.939527
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    str_0 = 'C:\\Users\\Administrator\\AppData\\Roaming\\.ansible\\tmp\\ansible-tmp-1540604021.12-246769451317428\\__pycache__\\packaging\\__init__.cpython-36.pyc'
    str_1 = 'C:\\Users\\Administrator\\AppData\\Roaming\\.ansible\\tmp\\ansible-tmp-1540604021.12-246769451317428\\__pycache__\\packaging\\__about__.cpython-36.pyc'
    str_2 = 'C:\\Users\\Administrator\\AppData\\Roaming\\.ansible\\tmp\\ansible-tmp-1540604021.12-246769451317428\\__pycache__\\packaging\\markers.cpython-36.pyc'
    str

# Generated at 2022-06-24 17:40:24.805300
# Unit test for function version
def test_version():
    assert _git_repo_info(os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_version_test')) == 'detached HEAD c847a1076b last updated 2020/05/20 14:42:41 (GMT -0700)'



# Generated at 2022-06-24 17:40:30.132876
# Unit test for function unfrack_path
def test_unfrack_path():
    pathsep = False

    # Call function with args
    try:
        unfrack_path(pathsep=pathsep)()
    except SystemExit as exception:
        if exception.code == 0:
            pass
        else:
            raise


# Generated at 2022-06-24 17:40:47.795736
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    argparse_Action = AnsibleVersion()
    parser = argparse.ArgumentParser()
    namespace = argparse.Namespace()
    values = None
    option_string = None
    argparse_Action.__call__(parser, namespace, values, option_string)
    assert var_0 == "Ansible"

# Generated at 2022-06-24 17:40:48.693664
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('beacon')


# Generated at 2022-06-24 17:41:03.085817
# Unit test for method __call__ of class PrependListAction

# Generated at 2022-06-24 17:41:04.332606
# Unit test for function version
def test_version():
    assert version() == "TODO"

# Generated at 2022-06-24 17:41:11.640615
# Unit test for function ensure_value
def test_ensure_value():
  args = argparse.Namespace()

  # Test no value set
  setattr(args, 'roles_path', None)
  ensure_value(args, 'roles_path', [])
  assert getattr(args, 'roles_path') == []

  # Test value already set
  setattr(args, 'roles_path', ['/opt/ansible/roles'])
  ensure_value(args, 'roles_path', [])
  assert getattr(args, 'roles_path') == ['/opt/ansible/roles']

# Generated at 2022-06-24 17:41:14.239020
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_2 = PrependListAction()
    var_2.__call__()

# Generated at 2022-06-24 17:41:17.983289
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = AnsibleVersion()
    # fake __call__ implementation
    var_0.__call__()


# Generated at 2022-06-24 17:41:19.361560
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_0 = AnsibleVersion()
    var_0.__call__()



# Generated at 2022-06-24 17:41:23.117461
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    var_1 = argparse.Action()
    var_2 = var_1.__call__()
    var_3 = to_native(version(getattr(parser, 'prog')))
    var_4 = print(ansible_version)
    var_5 = parser.exit()

# Generated at 2022-06-24 17:41:27.250486
# Unit test for function unfrack_path
def test_unfrack_path():
    # Input arguments
    pathsep = False

    # Output arguments

    # Call the function
    var_0 = unfrack_path(pathsep=False)

    # Result
    assert var_0 is not None



# Generated at 2022-06-24 17:41:49.556786
# Unit test for function version
def test_version():
    expected = """config file = /private/etc/ansible/ansible.cfg
  configured module search path = Default w/o overrides
  ansible python module location = .
  ansible collection location = .
  executable location = ./a.out
  python version = Python 2.7.10
  jinja version = 2.10
  libyaml = False
"""
    assert version() == expected

# Generated at 2022-06-24 17:41:53.628031
# Unit test for function unfrack_path
def test_unfrack_path():
    assert callable(unfrack_path()) == True

#
# Options Parser Classes
#

# Generated at 2022-06-24 17:41:59.640168
# Unit test for function unfrack_path
def test_unfrack_path():
    path = os.path.dirname(__file__)
    ansible_path = path + os.path.sep + "ansible"
    print(unfrackpath(path))
    assert unfrack_path(path) == ansible_path, "unfrack_path doesn't work"

#
# Functions to create Options
#

# Generated at 2022-06-24 17:42:02.888953
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:42:04.169391
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:42:07.649389
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    input_value = "test_case_0"
    beacon = "test_case_0"
    test_case_0_value = test_case_0()
    output_value = maybe_unfrack_path(input_value, beacon)

    assert output_value == test_case_0_value

#
# Test Helpers
#

# Generated at 2022-06-24 17:42:11.766539
# Unit test for function version
def test_version():
    assert version() == """2.9.13 [core 2.9.13]
  config file =
  configured module search path =
  ansible python module location =
  ansible collection location =
  executable location =
  python version = 3.7.5 (default, Nov  6 2019, 14:00:32)
[Clang 10.0.0 ]
  jinja version = 2.11.2
  libyaml = 3.13"""


# Generated at 2022-06-24 17:42:19.206161
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_1 = UnrecognizedArgument()
    var_2 = PrependListAction()
    var_3 = var_2._call__(var_1,argparse.Action(),argparse.Action(),PrependListAction())


# Generated at 2022-06-24 17:42:20.581050
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path() == inner()

# Generated at 2022-06-24 17:42:24.683886
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = os.path.join(os.getcwd(), "tmp")
    var_0 = unfrack_path(var_1)


# Generated at 2022-06-24 17:43:05.181168
# Unit test for function version
def test_version():
    ansible_version = version('ansible-runner')
    assert ansible_version.startswith('ansible-runner [core 2.9.2]')
    assert 'python version = ' in ansible_version
    assert 'jinja version = ' in ansible_version
    assert 'libyaml = ' in ansible_version

# Generated at 2022-06-24 17:43:14.602825
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Define arguments and parse
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action='store_true', help="Get current version")
    args = parser.parse_args()

    # This is the call of the method to be tested
    parser.version = args.version
    ansibleVersion = AnsibleVersion()
    ansibleVersion.__call__(parser, 'namespace','values','option_string')

    # Define arguments and parse
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action='store_true', help="Get current version")
    args = parser.parse_args(['--version'])

    # This is the call of the method to be tested
    parser.version = args.version
    ansibleVersion = AnsibleVersion()
    ansibleVersion

# Generated at 2022-06-24 17:43:19.280440
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    vars = dict(
        value = '~/ansible/roles'
        )
    path = maybe_unfrack_path(vars['value'])
    print(path)
    assert path(vars['value']) == '~/ansible/roles'

#
# Utility functions for parsing Options
#

# Generated at 2022-06-24 17:43:27.818768
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Setup
    from ansible import constants as C
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    display = Display()
    parser = C.config['parser']
    ansible_version = ansible.version
    ansible_version = to_native(ansible_version)
    # Testing
    print(ansible_version)
    # Teardown
