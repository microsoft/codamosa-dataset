

# Generated at 2022-06-24 17:33:59.320944
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = create_base_parser()
    add_connect_options(parser)
    #args = parser.parse_args()
    #assert args.private_key_file == None
    #assert args.remote_user == C.DEFAULT_REMOTE_USER
    #assert args.connection == None
    #assert args.timeout == C.DEFAULT_TIMEOUT
    #assert args.ask_pass == False


# Generated at 2022-06-24 17:34:00.605694
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:34:06.365527
# Unit test for function add_runas_options
def test_add_runas_options():

    # Create the module
    module = AnsibleModule(
        argument_spec = dict(
            state   = dict(default='present', choices=['present', 'absent']),
            name    = dict(required=True),
            enabled = dict(default=True, type='bool'),
            groups  = dict(default=["wheel", "dev"], type='list')
        ),
        supports_check_mode=True
    )
    match_0 = argparse.ArgumentParser(
        prog='ansible-config',
        formatter_class=SortingHelpFormatter,
        epilog='The config script is used to change variables and settings in the ansible configuration files.',
        description='The config script is used to change variables and settings in the ansible configuration files.')
    match_1 = add_runas_options(match_0)

# Generated at 2022-06-24 17:34:12.501694
# Unit test for function unfrack_path
def test_unfrack_path():
    func_name = 'unfrack_path'

    # Initialize host facts
    facts = dict()

    # Set expected results
    expected_results = [0]

    # Set test inputs
    test_inputs = [0]

    # Perform the test
    iterate_test(test_case_0, func_name, test_inputs, expected_results, facts)


#
# Helper functions for parsing options
#
# Do not call these from within the CLI.  These are only used by other modules.

# Generated at 2022-06-24 17:34:20.636714
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    module = ansible.module_utils.basic
    v = '~'
    case_0 = maybe_unfrack_path(v)
    s = set(case_0.func_dict.keys())

    fun_0 = module.unfrackpath
    fun_0_set = set(fun_0.func_dict.keys())
    assert fun_0_set == s


# Generated at 2022-06-24 17:34:25.063500
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_connect_options(parser)
    parser.parse_args()




# Generated at 2022-06-24 17:34:30.122673
# Unit test for function add_connect_options
def test_add_connect_options():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    parser = create_base_parser('ansible-connection-options')
    add_connect_options(parser)
    parser.add_argument('--test-option', action='store_true', help='test option')

# Generated at 2022-06-24 17:34:41.773981
# Unit test for function add_connect_options
def test_add_connect_options():
    # Test the default case
    parser = argparse.ArgumentParser()
    add_connect_options(parser)
    args = parser.parse_args(["-u", "root", "-c", "local", "--private-key", "?", "--ssh-common-args", "??"])
    for tmp in vars(args).items():
        print("{0}={1}".format(tmp[0], tmp[1]))
    assert vars(args)["remote_user"] == "root"
    assert vars(args)["connection"] == "local"
    assert vars(args)["private_key_file"] == "?"
    assert vars(args)["ssh_common_args"] == "??"

    # Test -k
    parser = argparse.ArgumentParser()

# Generated at 2022-06-24 17:34:49.731871
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = argparse.ArgumentParser(
        formatter_class=SortingHelpFormatter,
        conflict_handler='resolve',
    )

    # default check for new test case.
    print("========Unit Test for add.connect_options=======")
    print("Testing parser...")
    print(parser)
    print("Testing add_connect_options")
    add_connect_options(parser)
    print(parser)



# Generated at 2022-06-24 17:34:53.021709
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser("test", "test option parser")
    add_meta_options(parser)

    arg_list = ["--force-handlers", "--flush-cache"]
    args = parser.parse_args(arg_list)

    assert args.force_handlers == True
    assert args.flush_cache == True


# Generated at 2022-06-24 17:35:14.033695
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path("ansible")
    expected = "ansible/home/user/.ssh"
    actual = var_0("ansible/home/user/.ssh")
    assert expected == actual


# Generated at 2022-06-24 17:35:20.542561
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    ret = parser.parse_args('--become'.split())
    assert ret.become is True
    assert ret.become_method == 'sudo'
    assert ret.become_user is None

    ret = parser.parse_args('--become --become-user root'.split())
    assert ret.become is True
    assert ret.become_user == 'root'

    ret = parser.parse_args('--become --become-user root --ask-become-pass'.split())
    assert ret.become is True
    assert ret.become_user == 'root'

    ret = parser.parse_args('--become --become-user root --ask-su-pass'.split())
    assert ret.bec

# Generated at 2022-06-24 17:35:30.053141
# Unit test for function add_async_options
def test_add_async_options():
    # options.py
    std_in = sys.stdin.fileno()
    std_out = sys.stdout.fileno()
    mydir = os.path.dirname(os.path.abspath(__file__))
    parser = create_base_parser('ansible-playbook', usage='%(prog)s playbook.yml [options]',
                                desc='Executes an ansible playbook in the Ansible API')
    # Setup options
    parser.add_argument('playbook', nargs='*', help='playbook file (default: %s)' % C.DEFAULT_PLAYBOOK_FILE)

# Generated at 2022-06-24 17:35:35.681592
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    # Setup testcase
    parser = Mock()
    namespace = Mock()
    values = Mock()
    option_string = Mock()
    
    # Exercise SUT
    test_case_0 = AnsibleVersion()
    test_case_0.__call__(parser, namespace, values, option_string)
    
    # Verify outcome
    assert True # did not raise exception


# Generated at 2022-06-24 17:35:42.936007
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(prog='my-prog', formatter_class=SortingHelpFormatter, conflict_handler='resolve',)
    runas_group = parser.add_argument_group("Privilege Escalation Options", "control how and which user you become as on target hosts")
    add_runas_prompt_options(parser, runas_group)


# Generated at 2022-06-24 17:35:54.683452
# Unit test for function add_output_options
def test_add_output_options():
    import os
    os.remove('my_out.txt')
    parser = argparse.ArgumentParser(description='testing')
    add_output_options(parser)
    parser.add_argument('-f', '--file', dest='file', help='log output to file')
    args = parser.parse_args(['-o','-t', '.', '-f', 'my_out.txt'])
    if args.one_line != True:
        print('Test Failed!')
    elif args.tree != '.':
        print('Test Failed!')
    elif args.file != 'my_out.txt':
        print('Test Failed!')
    else:
        print('Test Passed!')


# Generated at 2022-06-24 17:35:59.834087
# Unit test for function add_runas_options
def test_add_runas_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible import context
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import json

    # since the API is constructed for CLI it expects certain options to always be set, named tuple 'fakes' the args parsing options object

# Generated at 2022-06-24 17:36:01.138360
# Unit test for method __call__ of class AnsibleVersion
def test_AnsibleVersion___call__():
    print('Test __AnsibleVersion___call__')
    var_0 = unfrack_path()


# Generated at 2022-06-24 17:36:07.226741
# Unit test for function add_runas_options
def test_add_runas_options():
    argparse.ArgumentParser.add_argument = fake_add_argument
    argparse.ArgumentParser.add_argument_group = fake_add_argument_group
    parser = argparse.ArgumentParser()
    add_runas_options(parser)
    assert parser.action_group[0].dest == 'become'
    assert parser.action_group[1].dest == 'become_method'
    assert parser.action_group[2].dest == 'become_user'
    assert parser.action_group[3].dest == 'ask_become_pass'
    assert parser.action_group[4].dest == 'ask_pass'


# Generated at 2022-06-24 17:36:20.654273
# Unit test for function add_output_options
def test_add_output_options():
    parser = argparse.ArgumentParser(
        prog=__program__,
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description=None,
        conflict_handler='resolve',
    )
    add_output_options(parser)
    if os.path.isdir("/root/tmp/one_line"):
        for root, dirs, files in os.walk("/root/tmp/one_line"):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        os.rmdir("/root/tmp/one_line")

# Generated at 2022-06-24 17:36:33.688812
# Unit test for function ensure_value
def test_ensure_value():
    # Assert that ensure_value does not change existing values
    existing_value = 10
    namespace = type("Foo", (object,), {'existing_value': existing_value})
    ensure_value(namespace, 'existing_value', 20)
    assert namespace.existing_value == existing_value

    # Assert that ensure_value adds the value to the namespace
    assert namespace.existing_value2 is None
    ensure_value(namespace, 'existing_value2', 20)
    assert namespace.existing_value2 == 20

    # Assert that ensure_value returns the value if added
    returned = ensure_value(namespace, 'existing_value3', 30)
    assert namespace.existing_value3 == 30
    assert returned == 30

    # Assert that ensure_value returns the existing value
    namespace.existing_value4 = 40


# Generated at 2022-06-24 17:36:40.948399
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    """Test function maybe_unfrack_path"""
    var_0 = maybe_unfrack_path("beacon")("./test")
    assert var_0 == "./test"
    var_1 = maybe_unfrack_path(".")("./test")
    assert var_1 == "./test"

#
# Options (parsers and groups)
#

# Generated at 2022-06-24 17:36:43.519366
# Unit test for function add_check_options
def test_add_check_options():
    print("test add_check_options", end="")
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(["-C"])
    assert args.check == True
    print("success")


# Generated at 2022-06-24 17:36:55.744399
# Unit test for function version
def test_version():

    # Primitive 1
    assert version() == "2.5.5 {}  config file = /home/devops/.ansible.cfg  configured module search path = Default w/o overrides  ansible python module location = ./lib/ansible  ansible collection location = /home/devops/.ansible/collections  executable location = ./bin/ansible  python version = 3.6.7 (default, Oct 22 2018, 11:32:17)  [GCC 8.2.0]  jinja version = 2.10  libyaml = False"

    # Primitive 2

# Generated at 2022-06-24 17:36:58.440054
# Unit test for function version
def test_version():
    assert len(version()) > 1
    return

if __name__ == "__main__":
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--version', action=AnsibleVersion)
        args = parser.parse_args()
    except SystemExit as e:
        print('ERROR: %s' % e)
        sys.exit(1)

# Generated at 2022-06-24 17:37:04.668675
# Unit test for function unfrack_path
def test_unfrack_path():
    if not hasattr(unfrack_path, 'counter'):
        unfrack_path.counter = 0
    try:
        assert 4 == test_case_0()
        print('unit test of "unfrack_path" passed')
        unfrack_path.counter += 1
    except AssertionError:
        print('unit test of "unfrack_path" failed')

# Run unit test for function unfrack_path
test_unfrack_path()


# Generated at 2022-06-24 17:37:05.854469
# Unit test for function version
def test_version():
    var_0 = version()

# Generated at 2022-06-24 17:37:12.885137
# Unit test for function add_check_options
def test_add_check_options():
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args("-C --syntax-check --diff".split())
    assert args.check
    assert args.syntax
    assert args.diff



# Generated at 2022-06-24 17:37:18.131417
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Setup the test
    var_0 = "~"
    var_1 = maybe_unfrack_path(var_0)
    try:
        result = var_1("/tmp")
    except Exception as e:
        raise e
    assert result == "/tmp"


#
# Options
#

# Generated at 2022-06-24 17:37:19.584035
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:37:42.814577
# Unit test for function maybe_unfrack_path

# Generated at 2022-06-24 17:37:45.784544
# Unit test for function add_subset_options
def test_add_subset_options():
    var_0 = argparse.ArgumentParser()
    add_subset_options(var_0)


# Generated at 2022-06-24 17:37:52.945384
# Unit test for function version
def test_version():
    assert version() == '2.9.4rc4 [core 2.9.4rc4]  config file = /root/ansible/ansible.cfg  configured module search path = /root/ansible/library:/usr/share/ansible/plugins/modules:/usr/share/ansible/plugins/module_utils:/usr/share/ansible/plugins/inventory  ansible python module location = /root/ansible/lib/ansible  ansible collection location = /root/ansible/collections  executable location = /usr/bin/python  python version = 2.7.13 (default, Jan 19 2017, 14:48:08)[GCC 6.3.0 20170118]  jinja version = 2.9.5  libyaml = 0'



# Generated at 2022-06-24 17:38:02.040115
# Unit test for function version
def test_version():
    # Create the arguments as if they would be passed on the command line.
    sys_argv_orig = sys.argv
    sys.argv = [ 'myprog' ]

    # Call the AnsibleVersion callback.
    result = version(prog='myprog')

    # Restore the original arguments.
    sys.argv = sys_argv_orig

    return result



# Generated at 2022-06-24 17:38:04.144622
# Unit test for function add_subset_options
def test_add_subset_options():
    parser = argparse.ArgumentParser()
    add_subset_options(parser)
    # Test without option -t
    args = parser.parse_args()
    try:
        res = args.tags
    except AttributeError:
        res = None
    assert not res


# Generated at 2022-06-24 17:38:07.624709
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()



# Generated at 2022-06-24 17:38:12.055880
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path(beacon="") == "", "Unable to handle given beacon value"


# Generated at 2022-06-24 17:38:13.641594
# Unit test for function version
def test_version():
    assert True == isinstance(version(), str)

# Generated at 2022-06-24 17:38:20.862402
# Unit test for function add_async_options
def test_add_async_options():
    print(int(C.DEFAULT_POLL_INTERVAL))
    parser = argparse.ArgumentParser(prog='test', add_help=False)
    add_async_options(parser)
    args = parser.parse_args(['-B', '100', '--poll', '200'])
    assert args.seconds == 100
    assert args.poll_interval == 200




# Generated at 2022-06-24 17:38:30.715361
# Unit test for function version
def test_version():
    # Unit test for function version
    
    # Local variables:
    # var_0:
    var_0 = None
    # var_1:
    var_1 = None
    # var_2:
    var_2 = None
    # var_3:
    var_3 = None
    # var_4:
    var_4 = None

    # Test TemplateChars, from Jinja2/testsuite/
    # TemplateChars[0]: '\\'
    # TemplateChars[1]: '\''
    # TemplateChars[2]: '"'
    # TemplateChars[3]: '\a'
    # TemplateChars[4]: '\b'
    # TemplateChars[5]: '\f'
    # TemplateChars[6]: '\n'
    # TemplateChars[7]: '

# Generated at 2022-06-24 17:38:42.190557
# Unit test for function version
def test_version():
    assert version('prog')

if __name__ == "__main__":
    test_case_0()
    test_version()
    print("Unit test complete")

# Generated at 2022-06-24 17:38:46.832758
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    import check_utils as utils
    utils.show_output(maybe_unfrack_path('/src/ansible'))

#
# Utility Methods
#

# Generated at 2022-06-24 17:38:52.485481
# Unit test for function version
def test_version():
    var_0 = "Executable location = %s"
    var_1 = sys.argv[0]
    var_2 = "Python Version = %s"
    var_3 = sys.version
    var_4 = "Jinja2 Version = %s"
    var_5 = j2_version
    var_6 = "libYAML support = %s"
    var_7 = HAS_LIBYAML
    var_8 = "Ansible Core Version = %s"
    var_9 = __version__
    var_10 = "Ansible Modules Search Path = %s"
    var_11 = C.DEFAULT_MODULE_PATH
    var_12 = "Ansible Python Module Location = %s"
    var_13 = ':'.join(ansible.__path__)
    var_

# Generated at 2022-06-24 17:38:53.936805
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # TODO: Implement test
    raise NotImplementedError


# Generated at 2022-06-24 17:38:57.045597
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        assert [unfrack_path()("/etc/passwd")] == [("/etc/passwd")]
    except:
        pass


# Generated at 2022-06-24 17:39:01.158555
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = "~/testdir"
    var_2 = maybe_unfrack_path(var_1)


#
# Helper functions
#

# Generated at 2022-06-24 17:39:04.414059
# Unit test for function unfrack_path
def test_unfrack_path():
    with pytest.raises(AssertionError):
        assert(unfrack_path(C.DEFAULT_MODULE_PATH))

#
# Base Parser classes
#

# Generated at 2022-06-24 17:39:05.905593
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    x = maybe_unfrack_path("@")
    assert x("@/usr/local/bin") == "@/usr/local/bin"



# Generated at 2022-06-24 17:39:08.264947
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('var_0')
    print(var_0)


#
# Parser main functions
#
# TODO: merge these together and make the parser available elsewhere
#

# Generated at 2022-06-24 17:39:11.842471
# Unit test for function version
def test_version():
    assert len(version().split('\n'))==7

if __name__ == "__main__":
    test_version()

# Generated at 2022-06-24 17:39:25.591591
# Unit test for function unfrack_path
def test_unfrack_path():
    # Call function with 0 parameters
    print('Testing function "unfrack_path".')
    test_case_0()

#
# Ansible Options
#

# Generated at 2022-06-24 17:39:26.873314
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('-c')


# Generated at 2022-06-24 17:39:30.062797
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path(pathsep=False)
    print(var_1)
    assert var_1() == '-', "Error in function unfrack_path"


# Generated at 2022-06-24 17:39:33.442652
# Unit test for function unfrack_path
def test_unfrack_path():
    for arg_0 in [u'', u'', u'']:
        try:
            test_case_0()
        except:
            pass


#
# Option Parser
#

# Generated at 2022-06-24 17:39:37.868295
# Unit test for function unfrack_path
def test_unfrack_path():
    test_case_0()


#
# Options classes
#

# Generated at 2022-06-24 17:39:39.866600
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    var_1 = SortingHelpFormatter()
    return var_1


# Generated at 2022-06-24 17:39:48.247270
# Unit test for function ensure_value
def test_ensure_value():
    # Test when setattr()
    p = argparse.Namespace()
    ensure_value(p,'test','abc')
    setattr(p,'test','abc')
    assert getattr(p,'test') == 'abc'
    assert p.test == 'abc'

    # Test when value already set
    var_0 = ensure_value(p,'test','xyz')
    assert var_0 == 'abc'
    assert p.test == 'abc'

# test_case_0()
test_ensure_value()


# Generated at 2022-06-24 17:39:54.331295
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    # From class AnsibleOptions._initialize_deprecated_options():
    # Example 1
    value = "SSH_ASKPASS"
    beacon = "SSH_ASKPASS"

    # Call function maybe_unfrack_path with arguments value and beacon
    unfrack_path_obj = maybe_unfrack_path(beacon)


# Generated at 2022-06-24 17:40:01.683858
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():

    # Setup
    #########
    # stderr_file = open("/dev/null", "w")
    # sys.stderr = stderr_file

    # sys.stderr.flush()
    # sys.stderr.truncate(0)
    # sys.stderr.seek(0, 0)

    # sys.stderr.write("hello world")
    # assert sys.stderr.tell() == 0

    # sys.stderr.flush()
    # sys.stderr.truncate(0)
    # sys.stderr.seek(0, 0)

    # sys.stderr.write("hello world")

    # stderr_file.close()

    var_2 = maybe_unfrack_path()
    var_2 = maybe_unfr

# Generated at 2022-06-24 17:40:07.209693
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path(beacon='/')
    var_0 = maybe_unfrack_path(beacon='/')
    var_0 = maybe_unfrack_path(beacon='/')


# Generated at 2022-06-24 17:40:21.832112
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('abc')
    var_1 = var_0('abcdef')
    assert var_1 == 'abcdef'


#
# Main Application Option Parsers
#

# Generated at 2022-06-24 17:40:24.998745
# Unit test for function unfrack_path
def test_unfrack_path():
    path = sys.argv[0]
    actual = unfrack_path(path)
    expected = unfrackpath(path)
    print(actual)
    print(expected)
    if actual == expected:
        print('Test Passed')
    else:
        print('Test Failed')


# Generated at 2022-06-24 17:40:26.134311
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
  tch = SortingHelpFormatter()
  return tch


# Generated at 2022-06-24 17:40:30.281038
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path(pathsep=True)("a:b:c") == ['a', 'b', 'c']


# Generated at 2022-06-24 17:40:31.982804
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    constr = SortingHelpFormatter()
    assert isinstance(constr,SortingHelpFormatter)


# Generated at 2022-06-24 17:40:35.720616
# Unit test for function version
def test_version():
    var_0 = version()

if __name__ == '__main__':
    test_case_0()
    test_version()

# Generated at 2022-06-24 17:40:37.100091
# Unit test for function version
def test_version():
    pass


# Generated at 2022-06-24 17:40:39.557345
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('some_beacon')


# Generated at 2022-06-24 17:40:50.087164
# Unit test for function version
def test_version():
    if os.path.basename(sys.argv[0]) == 'ansible':
        myprog = 'ansible'
    elif os.path.basename(sys.argv[0]) == 'ansible-playbook':
        myprog = 'ansible-playbook'
    else:
        myprog = ''
    result = version(myprog)
    # Use the following lines to manually validate test_case_0
    #print(result)


# Generated at 2022-06-24 17:40:52.806522
# Unit test for function version
def test_version():
    prog = 'ansible-playbook'
    ob_0 = version(prog)
    print(ob_0)


# Generated at 2022-06-24 17:41:18.288368
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('~')('~root') == '~/root'


# Generated at 2022-06-24 17:41:21.475018
# Unit test for function version
def test_version():
    main_class = AnsibleVersion
    options = {'dest': 'dummy'}
    obj = main_class(**options)
    ret = obj.__call__()
    # Check if we got a dictionary back
    assert type(ret) is dict

# Generated at 2022-06-24 17:41:23.825237
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    test_case_0()


#
# Options that can be set for the Ansible cmdline tools
#

# Generated at 2022-06-24 17:41:28.302777
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('./')


# Generated at 2022-06-24 17:41:34.951121
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # Possible inputs:
    # 1. needs_unfrack = False ; beacon = '-'
    # 2. needs_unfrack = True  ; beacon = '-'
    # 3. needs_unfrack = False ; beacon = '/my/path'
    # 4. needs_unfrack = True  ; beacon = '/my/path'

    for needs_unfrack in (False, True):
        for beacon in ('-', '/my/path'):
            case_str = 'needs_unfrack = %s; beacon = %s' % (needs_unfrack, beacon)
            print(case_str)

            if needs_unfrack:
                value = '/tmp/unfracked_dir'
                expected_result = beacon + '/tmp/unfracked_dir'

# Generated at 2022-06-24 17:41:45.475634
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    args = {
        'option_strings': ['--foo'],
        'dest': 'foo',
        'nargs': '+',
        'const': 'bar',
        'default': 'BAR',
        'type': 'int',
        'choices': [1, 2, 3],
        'required': False,
        'help': 'help string',
        'metavar': 'string'
    }
    obj = PrependListAction(**args)
    # print(obj)
    assert obj.option_strings == ['--foo']
    assert obj.dest == 'foo'
    assert obj.nargs == '+'
    assert obj.const == 'bar'
    assert obj.default == 'BAR'
    assert obj.type == 'int'
    assert obj.choices == [1, 2, 3]

# Generated at 2022-06-24 17:41:50.095225
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    result = maybe_unfrack_path("C:\\temp\\ansible")
    assert result == 1


# Generated at 2022-06-24 17:41:56.120524
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    try:
        assert SortingHelpFormatter(prog="unit_testing")
        test_case_0()
    except Exception:
        print("Error raised in test_SortingHelpFormatter")
        return False
    return True



# Generated at 2022-06-24 17:41:57.664984
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('foo') == ("foo",)


# Generated at 2022-06-24 17:42:08.170414
# Unit test for function unfrack_path
def test_unfrack_path():
    # Run this test only once
    test_unfrack_path.count += 1
    if test_unfrack_path.count != 1:
        return
    test_unfrack_path.count = 0

    # Setup
    var_0 = unfrack_path()
    var_1 = unfrack_path(False)
    var_2 = unfrack_path(True)

    # Testing
    try:
        assert var_0 == None
        assert var_1 == None
        assert var_2 == None
        test_case_0()
    except Exception as e:
        print("Error in test_unfrack_path: " + str(e))

