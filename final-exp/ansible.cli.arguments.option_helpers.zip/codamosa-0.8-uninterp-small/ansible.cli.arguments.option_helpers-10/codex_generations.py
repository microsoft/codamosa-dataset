

# Generated at 2022-06-24 17:33:58.626565
# Unit test for function add_connect_options
def test_add_connect_options():
    parser = add_connect_options(sys.argv)


# Generated at 2022-06-24 17:34:09.608695
# Unit test for function add_connect_options
def test_add_connect_options():
    # Create a dummy parser
    parser = argparse.ArgumentParser(
        prog="ansible",
        formatter_class=SortingHelpFormatter,
        epilog=None,
        description="",
        conflict_handler='resolve',
    )
    
    # Add connection options to the dummy parser
    add_connect_options(parser)

    # Check that we added the expected options to the parser
    expected_option_names = ['private_key_file', 'remote_user', 'connection', 'timeout', 'ssh_common_args',
    'sftp_extra_args', 'scp_extra_args', 'ssh_extra_args', 'ask_pass', 'connection_password_file']
    
    assert len(parser._actions) == 10
    for action in parser._actions:
        assert action.dest in expected_

# Generated at 2022-06-24 17:34:15.776261
# Unit test for function ensure_value
def test_ensure_value():
    namespace = argparse.Namespace()
    ensure_value(namespace, 'foo', [])
    assert namespace.foo == []
    ensure_value(namespace, 'foo', 'bar')
    assert namespace.foo == []
    setattr(namespace, 'foo', 'fooz')
    ensure_value(namespace, 'foo', 'bar')
    assert namespace.foo == 'fooz'
    ensure_value(namespace, 'bar', 'baz')
    assert namespace.bar == 'baz'


# Generated at 2022-06-24 17:34:18.055096
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = os.path.abspath('.')
    assert True == os.path.isabs(var_0)


# Generated at 2022-06-24 17:34:20.947274
# Unit test for function add_vault_options
def test_add_vault_options():
    parser = argparse.ArgumentParser()
    add_vault_options(parser)
    options = parser.parse_args(['--vault-password-file', '@/tmp/file_path'])
    assert options.vault_password_files == ['/tmp/file_path']


# Generated at 2022-06-24 17:34:23.336418
# Unit test for function add_check_options
def test_add_check_options():
    test_args = []
    parser = argparse.ArgumentParser()
    add_check_options(parser)
    args = parser.parse_args(test_args)
    assert args


# Generated at 2022-06-24 17:34:28.784064
# Unit test for function add_vault_options
def test_add_vault_options():
    """Add options for loading vault files"""

    # Test positional arguments
    parser = None
    try:
        parser = add_vault_options(parser)
    except TypeError as e:
        assert(str(e) == 'argument "parser" (position 1) must be argparse.ArgumentParser')
        parser = argparse.ArgumentParser()

    assert( parser.prog == "ansible-playbook" )
    assert( parser._positionals._group_actions[0].dest == 'action')
    assert( parser._positionals._group_actions[0].metavar == "<action>")
    assert( parser._positionals._group_actions[0].required == True)
    assert( parser._positionals._group_actions[0].type == 'str')


# Generated at 2022-06-24 17:34:40.317365
# Unit test for function add_runas_prompt_options
def test_add_runas_prompt_options():
    parser = argparse.ArgumentParser(prog='ansible')

    add_runas_prompt_options(parser)

    args = parser.parse_args(['-K'])
    assert args.become_ask_pass is True
    assert args.become_password_file is None

    args = parser.parse_args(['--become-password-file', '/path/to/.become_pass'])
    assert args.become_ask_pass is False
    assert args.become_password_file == '/path/to/.become_pass'

    # TODO: Check that parser raises an error for both args being passed
    # args = parser.parse_args(['-K', '--become-password-file', '/path/to/.become_pass'])


# Generated at 2022-06-24 17:34:42.066889
# Unit test for function ensure_value
def test_ensure_value():
    assert ensure_value(1, "name", value) == 1
    return


# Generated at 2022-06-24 17:34:49.499721
# Unit test for function unfrack_path
def test_unfrack_path():
    # Setup test inputs
    pathsep = False

    # invoke function under test
    function_under_test = unfrack_path(pathsep=False)
    # get expected result
    expected_result = '~///.ansible/plugins/modules'
    # compare expected result with actual result
    actual_result = function_under_test(expected_result)
    assert actual_result == expected_result


# Generated at 2022-06-24 17:35:06.755327
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test passes with no exceptions
    # TODO: implement some tests since there is not a lot of coverage
    try:
        test_case_0()
    except Exception as e:
        print ("Unfranchised exception!")


# Generated at 2022-06-24 17:35:14.100656
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path() == '/ansible_module_utils'
    assert unfrack_path() == ''
#
# Args to parse
#

COMMON_ARGS = [
    '--version',
    {'dest': 'version', 'action': 'version', 'version': version(version=True), 'default': None, 'help': 'show program\'s version number and exit'},
]

COMMON_SHORT_ARGS = [
    '-h',
    {'dest': 'help', 'action': 'store_true', 'default': None, 'help': 'show this help message and exit'},
]


# Generated at 2022-06-24 17:35:17.256619
# Unit test for function unfrack_path
def test_unfrack_path():
    # Setup
    arg1 = False

    # Exercise
    ret = unfrack_path(arg1)

    # Verify
    assert ret

    # Cleanup
# already cleaned up


# Generated at 2022-06-24 17:35:26.521228
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('-')

# Generated at 2022-06-24 17:35:29.369729
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # TODO: Write unit test for function maybe_unfrack_path
    raise NotImplementedError()


# Generated at 2022-06-24 17:35:32.154695
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path()("something/something") == "something/something"

#
# Functions to generate OptionParsers
#

# Generated at 2022-06-24 17:35:41.350523
# Unit test for function add_output_options
def test_add_output_options():
    parser = create_base_parser('test')
    add_output_options(parser)
    args = parser.parse_args(['-o'])
    assert args.one_line == True
    args = parser.parse_args(['-t', 'tree_value'])
    assert args.tree == 'tree_value'

#
# Functions to generate options in a consistent and DRY way
#


# Generated at 2022-06-24 17:35:48.883327
# Unit test for function add_output_options
def test_add_output_options():
    test_parser = create_base_parser(prog='ansible-playbook', usage="%(prog)s [options] playbook.yml",
                                     desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")
    var_1 = test_case_0()
    var_2 = add_output_options(test_parser)
    return var_2


# Generated at 2022-06-24 17:35:49.592320
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert SortingHelpFormatter() is not None


# Generated at 2022-06-24 17:35:54.806885
# Unit test for function add_runas_options
def test_add_runas_options():
    parser = create_base_parser('test')
    add_runas_options(parser)
    args = parser.parse_args(['-b'])

    assert args.become == True
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user == C.DEFAULT_BECOME_USER

    args = parser.parse_args(['--become'])
    assert args.become == True
    assert args.become_method == C.DEFAULT_BECOME_METHOD
    assert args.become_user == C.DEFAULT_BECOME_USER

    args = parser.parse_args(['--become-method=sudo'])
    assert args.become == False
    assert args.become_method == 'sudo'
    assert args.bec

# Generated at 2022-06-24 17:36:05.891365
# Unit test for function add_meta_options
def test_add_meta_options():
    parser = create_base_parser()

    # Test functionality
    add_meta_options(parser)

    # Test options
    #assert '--force-handlers' in parser.option_list  # Input: argparse.Action
    #assert '--flush-cache' in parser.option_list  # Input: argparse.Action
    #assert '--flush-cache' in parser.option_list  # Input: argparse.Action
    assert parser



# Generated at 2022-06-24 17:36:10.311276
# Unit test for function version
def test_version():
    # Setup
    prog = None
    # Expectation
    expected = ("1.0 [core 2.7.0]")
    # Assertion
    assert version(prog) == expected


# Generated at 2022-06-24 17:36:17.085811
# Unit test for function unfrack_path
def test_unfrack_path():
    input1 = 'C:\\Users\\kapil_g\\AppData\\Local\\Temp\\ansible_dnf_payload_0xuUeL6'
    ans1 = unfrack_path()(input1)

    assert(ans1 == 'C:\\Users\\kapil_g\\AppData\\Local\\Temp\\ansible_dnf_payload_0xuUeL6')

#
# Callbacks to validate and normalize Options
#

# Generated at 2022-06-24 17:36:21.037301
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path("./")


# Generated at 2022-06-24 17:36:26.190321
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser(
        prog='',
        formatter_class=SortingHelpFormatter,
    )
    add_async_options(parser)
    parser.parse_args([])


# Generated at 2022-06-24 17:36:28.947861
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse
    namespace = object
    values = list
    option_string = object
    # self.__call__(parser, namespace, values, option_string=None)
    assert 0


# Generated at 2022-06-24 17:36:30.091748
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = unfrack_path()


# Generated at 2022-06-24 17:36:35.076905
# Unit test for function unfrack_path
def test_unfrack_path():
    # Test default case
    assert unfrack_path()('/path/to/file') == '/path/to/file'
    var_1 = unfrack_path()('/path/to/file')

#
# Main OptionParser
#

# Generated at 2022-06-24 17:36:37.389723
# Unit test for function add_meta_options
def test_add_meta_options():
    var_1 = argparse.ArgumentParser()
    add_meta_options(var_1)


# Generated at 2022-06-24 17:36:39.552122
# Unit test for function unfrack_path
def test_unfrack_path():
    print("Entering test_unfrack_path")
    test_case_0()



# Generated at 2022-06-24 17:36:56.218095
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    print("Testing constructor of class PrependListAction")
    var_1 = argparse.Action()
    var_2 = option_strings
    var_3 = 'dest'
    var_4 = nargs
    var_5 = const
    var_6 = default
    var_7 = type
    var_8 = choices
    var_9 = required
    var_10 = help
    var_11 = metavar
    var_12 = PrependListAction(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11)
    var_13 = to_native("Test passed")
    print(var_13)


# Generated at 2022-06-24 17:36:57.092481
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:37:00.289736
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # SortingHelpFormatter()
    test_case_0()


# Generated at 2022-06-24 17:37:12.007303
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    # set up environment
    beacon = '@'
    value = '@some_value'
    # execute function
    retval = maybe_unfrack_path(beacon)
    # validate results
    assert retval(value) == '@some_value'

#
# Constants
#
DESC = "Ansible %s on %s - %s" % (__version__, os.name, sys.version.split()[0])
DEFAULT_MODULE_PATH = unfrackpath('~/.ansible/plugins/modules:%s/library' % os.path.dirname(ansible.__file__))
DEFAULT_MODULE_NAME = 'command'
DEFAULT_UNKNOWN_PLUGIN_FILTER = 'ignore'
DEFAULT_EXIT_JSON = False
DEFAULT_DIRECT_BASEN

# Generated at 2022-06-24 17:37:15.042254
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # return SortingHelpFormatter(argparse.HelpFormatter.add_arguments(actions))
    pass



# Generated at 2022-06-24 17:37:17.381692
# Unit test for constructor of class PrependListAction
def test_PrependListAction():
    var_0 = PrependListAction(nargs=2)
    print("PrependListAction object after call:", var_0)


# Generated at 2022-06-24 17:37:21.028888
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:37:26.393601
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = ['','','','','','','']
    res_0 = unfrack_path()
    poc_0 = 0
    for var_1 in var_0:
        res_1 = res_0(var_1)
        if res_1 != poc_0:
            raise Exception("unfrack_path")


# Generated at 2022-06-24 17:37:36.269926
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_0 = argparse.ArgumentParser()
    var_1 = var_0.add_argument('-x')
    var_2 = var_0.add_argument('-y')
    var_3 = var_0.add_argument('-z')
    var_4 = var_0.add_argument('-a')
    var_4 = var_0.add_argument('-b')
    var_4 = var_0.add_argument('-c')
    var_4 = var_0.add_argument('-d')
    var_4 = var_0.add_argument('-e')
    var_4 = var_0.add_argument('-f')
    var_5 = ['b','a','c','d','e','f','x','y','z']
    var_6 = var_0

# Generated at 2022-06-24 17:37:42.630337
# Unit test for function add_async_options
def test_add_async_options():
    parser = argparse.ArgumentParser()
    add_async_options(parser)
    # Do not provide argument to -P / --poll
    #parser.parse_args(['-P']) # raises error:
    # error: argument -P/--poll: expected one argument
    # Test with valid int
    args = parser.parse_args(['-B', '77'])
    assert args.seconds == 77
    print("test_add_async_options: test_0 passed")



# Generated at 2022-06-24 17:37:57.609027
# Unit test for function unfrack_path
def test_unfrack_path():

    # Create a test case
    test_case = [(('/tmp/roles'), False),
                 (('/tmp/roles'), True),
                 (('/tmp/roles:/tmp/devel_roles'), True),
                 (('/tmp/roles:/tmp/devel_roles:/tmp/adhoc_roles'), True),
                 (('/tmp/roles:/tmp/devel_roles/foo/bar:/tmp/adhoc_roles'), True),
                 (('-', False)),
                 ]

    # Execute each test case
    for test_params, pathsep in test_case:
        if pathsep:
            res = unfrack_path(pathsep)(test_params[0]).split(os.pathsep)

# Generated at 2022-06-24 17:37:58.417841
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()


# Generated at 2022-06-24 17:37:59.240575
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    assert True

# Generated at 2022-06-24 17:38:00.963845
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()
    print(var_1)


# Generated at 2022-06-24 17:38:03.448826
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    from ansible.utils.path import unfrackpath
    assert (callable(unfrackpath))



# Generated at 2022-06-24 17:38:09.838825
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path('a')('a') == 'a'
    assert maybe_unfrack_path('a')('a/b') == 'a/b'
    assert maybe_unfrack_path('b')('b/a') == 'b/a'

#
# Base Options defined by Ansible
#
DEFAULT_MODULE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'library')
DEFAULT_EXECUTABLE = '/usr/bin/ansible-playbook'
DEFAULT_MODULE_NAME = 'command'
ANSIBLES_MODULE_PATH = '/usr/share/ansible'

# Generated at 2022-06-24 17:38:15.935946
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default=None, action=PrependListAction)
    ns = parser.parse_args('--foo 1 --foo 2 --foo 3'.split())
    assert ns.foo == [3, 2, 1]



# Generated at 2022-06-24 17:38:20.424660
# Unit test for function unfrack_path
def test_unfrack_path():
    assert (unfrack_path()(10) == 10)


# Generated at 2022-06-24 17:38:24.458551
# Unit test for function unfrack_path
def test_unfrack_path():
    assert unfrack_path()('/etc/ansible/') == '/etc/ansible/'
    assert unfrack_path()('/home/user1') == '/home/user1'


# Generated at 2022-06-24 17:38:25.471340
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    pass


# Generated at 2022-06-24 17:38:38.129704
# Unit test for function version
def test_version():
    assert version() is None


# Generated at 2022-06-24 17:38:40.283212
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    result = 1
    raise NotImplementedError()


# Generated at 2022-06-24 17:38:49.090691
# Unit test for function unfrack_path
def test_unfrack_path():
    print("in test_unfrack_path")

    # mock input data
    for test_input, expected_input in [
        ("/etc/ansible", "/etc/ansible"),
        ("/etc/ansible/", "/etc/ansible"),
    ]:
        # prepare environment
        # execute function
        actual_input = unfrack_path()(test_input)

        # verify output
        assert actual_input == expected_input

    # mock input data
    for test_input, expected_input in [
        ("/etc/ansible", "/etc/ansible"),
        ("/etc/ansible/", "/etc/ansible"),
    ]:
        # prepare environment
        # execute function
        actual_input = unfrack_path(False)(test_input)

        # verify output
        assert actual_input == expected

# Generated at 2022-06-24 17:38:50.855843
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()
    var_0('')
    var_0('-')


# Generated at 2022-06-24 17:38:57.377377
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('/etc/ansible')
    try:
        assert var_1('/etc/ansible/ansible.cfg') == '/etc/ansible/ansible.cfg'
        var_2 = var_1('/etc/ansible/../ansible.cfg')
        assert var_2 == '/etc/ansible/../ansible.cfg'
    except NameError:
        print("Unable to find 'assertEqual'")


# Generated at 2022-06-24 17:38:58.671852
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path()
    return var_0


# Generated at 2022-06-24 17:39:05.143034
# Unit test for function unfrack_path
def test_unfrack_path():
    if not HAS_LIBYAML:
        return
    yaml_data = '''\
- ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible
    - ansible'''

# Generated at 2022-06-24 17:39:12.393402
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    # Set python executable to python3.5
    if sys.version_info[0] < 3:
        os.environ['python3.5'] = "python3.5"
        os.environ['python3.6'] = "python3.6"
        os.environ['python3.7'] = "python3.7"
        os.environ['python3.8'] = "python3.8"

    # Set python version to 3.5
    sys.version_info = (3, 5, 0, 'final', 0)

    # Compare the output of sys.executable with the value of the environment variable (python3.5)
    # If both are True, then create an object of class SortingHelpFormatter.
    if sys.executable == os.environ['python3.5']:
        s = Sorting

# Generated at 2022-06-24 17:39:17.710377
# Unit test for function version
def test_version():
    # Call version with a variety of inputs

    version(prog=None)


# Generated at 2022-06-24 17:39:19.690805
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_0 = maybe_unfrack_path('beacon')
    

# Generated at 2022-06-24 17:39:45.873093
# Unit test for function version
def test_version():
    import ansible.utils.display
    ansible.utils.display.ANSIBLE_VERSION = '2.9.1'
    assert version('ansible') == 'ansible [core 2.9.1]'


# Generated at 2022-06-24 17:39:55.205443
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = 'F:\\ansible_prj_2.4\\ansible-2.4.3.0\\lib\\ansible\\modules\\cloud\\azure\\azure_rm_storageaccount.py'
    b = unfrack_path()
    #print(b)
    var_2 = b(var_1)
    print(var_2)
    print(type(var_2))

if __name__ == "__main__":
  test_case_0()
  test_unfrack_path()

# Generated at 2022-06-24 17:39:57.278745
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        unfrack_path()
    except:
        assert False


#
# OptionGroups
#

# Generated at 2022-06-24 17:40:06.474323
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    import argparse
    kwargs = {'nargs': 1, 'const': None, 'default': None, 'type': None, 'choices': None, 'required': False, 'help': None, 'metavar': None, 'dest': 'arg1'}
    prepend_listaction = PrependListAction(['--arg1', '-a'], **kwargs)
    argparse_namespace_1 = argparse.Namespace()
    argparse_namespace_1.arg1 = None
    prepend_listaction.__call__(None, argparse_namespace_1, ['c', 'd'])
    assert argparse_namespace_1.arg1 == ['c', 'd']


# Generated at 2022-06-24 17:40:09.055226
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    assert maybe_unfrack_path (None) == None
    assert maybe_unfrack_path (True) == None
#
# Helper functions to create Options
#

# Generated at 2022-06-24 17:40:13.877236
# Unit test for function unfrack_path
def test_unfrack_path():
    try:
        assert os.path.exists(unfrack_path())
    except:
        print("Testcase Failed: " +
              "test_unfrack_path")

# Check if a given path(file) exists

# Generated at 2022-06-24 17:40:16.633737
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    p = prepare_test()
    var_0 = p.__call__('p', 'namespace', 'values', 'option_string')
    assert(var_0 == expected_0)


# Generated at 2022-06-24 17:40:20.837467
# Unit test for function version
def test_version():
    # Test: Calling function with no parameters
    func_name = "version"
    result = version()
    assert type(result) == str
    assert result != ""


# Generated at 2022-06-24 17:40:24.119134
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    var_3 = to_native(version('ansible-playbook'))
    print(var_3)
    exit()
    return


# Generated at 2022-06-24 17:40:32.708456
# Unit test for method __call__ of class PrependListAction
def test_PrependListAction___call__():
    option_strings = None
    dest = None
    nargs = None
    const = None
    default = None
    type = None
    choices = None
    required = False
    help = None
    metavar = None
    prepend_list_action = PrependListAction(option_strings, dest, nargs, const, default, type, choices, required,
                                            help, metavar)
    parser = None
    namespace = None
    values = None
    option_string = None
    prepend_list_action.__call__(parser, namespace, values, option_string)


# Generated at 2022-06-24 17:42:17.218416
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path('~/.ssh/id_rsa')

#
# Global Constants
#
# NOTE: The commented out variables are not strictly necessary and should likely
# be removed once Ansible is ported to Python 3 and the sys.maxsize constants are
# removed.
ZERO_OR_MORE = argparse.OPTIONAL
ONE_OR_MORE = argparse.ONE_OR_MORE
ZERO_OR_ONE = 0
ONE_OR_MORE_NOT_REQUIRED = 1
# PY_MAXSIZE = sys.maxsize
# PY_MAXSIZE_STRING = str(sys.maxsize)


#
# Methods for processing jinja2 expressions in ANSIBLE_INVENTORY and in the user playbook.
#

# Generated at 2022-06-24 17:42:18.369569
# Unit test for function unfrack_path
def test_unfrack_path():
    var_0 = unfrack_path()
    assert(isinstance(var_0, function))


# Generated at 2022-06-24 17:42:19.317216
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    test = SortingHelpFormatter()
    assert test is not None



# Generated at 2022-06-24 17:42:21.559219
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    path = "~/"
    beacon = "~"
    var_0 = maybe_unfrack_path(beacon)
    assert var_0(path) == "~/user/root/ansible"


# Generated at 2022-06-24 17:42:27.169992
# Unit test for constructor of class SortingHelpFormatter
def test_SortingHelpFormatter():
    class TestSortingHelpFormatter(SortingHelpFormatter):
        def add_usage(self, usage, actions, groups, prefix=None):
            usage = super(SortingHelpFormatter, self).add_usage(usage, actions, groups, prefix)
            return usage

    class TestSortingHelpFormatter2(SortingHelpFormatter):
        def start_section(self, heading):
            heading = super(SortingHelpFormatter, self).start_section(heading)
            return heading

    class TestSortingHelpFormatter3(SortingHelpFormatter):
        def _format_action_invocation(self, action):
            action = super(SortingHelpFormatter, self)._format_action_invocation(action)
            return action


# Generated at 2022-06-24 17:42:29.476818
# Unit test for function unfrack_path
def test_unfrack_path():
    var_1 = unfrack_path()
    print(var_1)


# Generated at 2022-06-24 17:42:35.251685
# Unit test for function unfrack_path
def test_unfrack_path():

    # Setup test data
    pathsep = False

    # Invoke method
    var_0 = unfrack_path(pathsep)
    
    # Check for expected results
    assert var_0 != None, 'Expected unfrack_path() to return a value'
    assert var_0 == inner, 'Expected unfrack_path() to return a function'

# Generated at 2022-06-24 17:42:36.346640
# Unit test for function maybe_unfrack_path
def test_maybe_unfrack_path():
    var_1 = maybe_unfrack_path()
    var_2 = maybe_unfrack_path()



# Generated at 2022-06-24 17:42:52.344985
# Unit test for function unfrack_path
def test_unfrack_path():
    ansible_git_version = b'v2.4.3.0-0-g4767c1fda7'
    ansible_version = b'2.4.3.0'
    ansible_local_tmpdir = u'/home/vsts/work/1/s/ansible_hosts_groups'
    ansible_managed = u'Ansible managed: Do not edit this file manually!'
    ansible_become_user = u'root'
    ansible_user = u'root'
    ansible_verbosity = u'0'
    ansible_connection = u'local'
    ansible__inventory_file = u'/home/vsts/work/1/s/ansible_hosts_groups/fake_inventories/inventory'

# Generated at 2022-06-24 17:43:03.968232
# Unit test for constructor of class PrependListAction