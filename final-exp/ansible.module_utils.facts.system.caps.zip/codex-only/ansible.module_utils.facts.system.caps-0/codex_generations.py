

# Generated at 2022-06-23 00:37:31.068768
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact = SystemCapabilitiesFactCollector()
    assert fact.collect() == {}, "Test failed"

# Generated at 2022-06-23 00:37:42.313224
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Run a test to make sure the collect method returns the expected dictionary.
    """
    # Create a fake module object
    class FakeModule(object):
        def __init__(self, run_command_return_value=(0, 'Current: =ep', '')):
            self.fake_module_result = run_command_return_value
        def get_bin_path(self, module):
            return module
        def run_command(self, command, errors='surrogate_then_replace'):
            return self.fake_module_result
    fake_module = FakeModule()
    # Create a fact collector object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect(fake_module)
    # Make sure we get the expected dictionary back


# Generated at 2022-06-23 00:37:47.745297
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = 0, 'Current:	=ep', None
    module_mock.get_bin_path.return_value = '/bin/true'
    c = SystemCapabilitiesFactCollector()
    assert c.collect(module_mock) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-23 00:37:55.588578
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import platform
    import unittest
    import textwrap
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector

    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, binPath):
            return("/bin/capsh")


# Generated at 2022-06-23 00:37:58.573730
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_fact_c = SystemCapabilitiesFactCollector()
    caps_fact_c.collect(module=None, collected_facts=None)

# Generated at 2022-06-23 00:38:02.997904
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert set(c._fact_ids) == set(['system_capabilities',
                                    'system_capabilities_enforced'])


# Generated at 2022-06-23 00:38:08.780773
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Check the name of the class being tested
    assert 'SystemCapabilitiesFactCollector' == SystemCapabilitiesFactCollector.__name__

    # Check the name of this collector
    assert 'caps' == SystemCapabilitiesFactCollector.name

    # Check the list of internal fact IDs managed by this subclass.
    assert set(['system_capabilities', 'system_capabilities_enforced']) == SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-23 00:38:13.673231
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Unit test for constructor of class SystemCapabilitiesFactCollector"""
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert 'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-23 00:38:25.523000
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Stub AnsibleModule
    module = AnsibleModuleStub()

    # Stub AnsibleModule.get_bin_path
    setattr(module, 'get_bin_path', lambda path: 'capsh_bin')

    # Stub AnsibleModule.run_command
    caps_out = """Capabilities for `capsh --print': = cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_sys_ptrace,cap_mknod,cap_audit_write,cap_setfcap+eip
"""

# Generated at 2022-06-23 00:38:36.433617
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = None
    test_collected_facts = None
    test_correct_system_capabilities = ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap', 'audit_control']
    test_correct_system_capabilities_enforced = 'True'
    test_correct_results = {'system_capabilities_enforced': test_correct_system_capabilities_enforced,
                            'system_capabilities': test_correct_system_capabilities}
    test_fact_collector = SystemCapabilitiesFactCollector()
    test_result = test_fact_collector.collect

# Generated at 2022-06-23 00:38:40.228352
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:38:42.632789
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleStub()
    SystemCapabilitiesFactCollector.collect(module)
    assert module.fail_json.called

# Generated at 2022-06-23 00:38:45.368473
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:57.487992
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import platform
    from ansible.module_utils.facts import ansible_facts

    msg = 'This test should only be run on linux platform'
    if platform.system() != 'Linux':
        raise Exception(msg)

    mgr = ansible_facts.AnsibleFacts(module=None, collected_facts={})
    facts = ansible_facts.Facts(None, None)
    mgr.set_facts(facts)
    collect_obj = SystemCapabilitiesFactCollector(mgr)

    capsh_path = '/usr/bin/capsh'
    if os.path.isfile(capsh_path):
        result = collect_obj.collect(module=None, collected_facts={})
        assert 'system_capabilities' in result
        assert 'system_capabilities_enforced' in result


# Generated at 2022-06-23 00:39:01.403840
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                        'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:12.384873
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import platform
    import stat
    import tempfile
    import unittest

    from ansible.module_utils._text import to_bytes

    class TestModule:

        def __init__(self):
            self.run_command_result = 1
            self.run_command_calls = []
            self.run_command_rc = []
            self.run_command_out = []
            self.run_command_err = []
            self.get_bin_path_result = 1
            self.get_bin_path_calls = []

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-23 00:39:18.884405
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # get_bin_path() -> /usr/bin/capsh
    # run_command() -> (0, 'Capabilities for `/bin/ls`: = cap_setpcap+ep\nCurrent: =ep\nBounding set =cap_setpcap+ep\nSecurebits: 00/0x0/1\n secure-noroot: no (unlocked) secure-no-suid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root)', '')
    # get_bin_path() -> None
    return None, {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-23 00:39:22.051411
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class args:
        gather_subset = ["all"]
    class module:
        def __init__(self):
            self.params = args()
    SystemCapabilitiesFactCollector(module)

# Generated at 2022-06-23 00:39:31.954489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_module = {}

# Generated at 2022-06-23 00:39:37.404911
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Arguments of class SystemCapabilitiesFactCollector constructor
    name = 'caps'
    _fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])
    class_inst = SystemCapabilitiesFactCollector(name, _fact_ids)
    assert class_inst.name == 'caps'
    assert class_inst._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:44.713448
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == "caps"
    assert fc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

if __name__ == '__main__':
    # Unit test
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == "caps"
    assert fc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:57.041108
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from collections import namedtuple

    mod_output_good = '''Current: =ep
Bounding set =ep
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root)
'''

    mod_output_bad = '''Current: =ep Bounding set =ep Securebits: 00/0x0/1'b0 secure-noroot: no (unlocked) secure-no-suid-fixup: no (unlocked) secure-keep-caps: no (unlocked) uid=0(root) gid=0(root) groups=0(root)'''


# Generated at 2022-06-23 00:40:00.348387
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sysCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert sysCapabilitiesFactCollector.name == 'caps'
    assert sysCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:10.393834
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import ansible_facts_to_data
    from ansible.module_utils.facts import ansible_collector

    class MockAnsibleModule(object):
        def __init__(self, exit_status=None, rc=None, out=None, err=None, debug=None, command_warnings=None):
            self.exit_status = exit_status
            self.rc = rc
            self.out = out
            self.err = err

# Generated at 2022-06-23 00:40:11.632491
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:15.194347
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:15.948105
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:40:26.450702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Ensure that capsh bin is installed
    module = MockModule()
    if os.path.exists("/bin/capsh"):
        assert SystemCapabilitiesFactCollector().collect(module=module) == {'system_capabilities_enforced': 'True', 'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']}
    else:
        assert SystemCapabilitiesFactCollector().collect(module=module) == {}

# Generated at 2022-06-23 00:40:27.608993
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:40:38.084348
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule(object):
        def __init__(self, expected_return_code, expected_stdout):
            self.expected_return_code = expected_return_code
            self.expected_stdout = expected_stdout

        def get_bin_path(self, capsh_path, *args, **kwargs):
            return '/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace', *args, **kwargs):
            return (self.expected_return_code, self.expected_stdout, '')

    # need to mock module_utils.basic.AnsibleModule

# Generated at 2022-06-23 00:40:46.881526
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    syscap_obj = SystemCapabilitiesFactCollector()
    assert syscap_obj.name == 'caps'
    assert syscap_obj._fact_ids == set(['system_capabilities',
                                        'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:48.971170
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:40:52.863125
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    collected_facts = dict()
    assert sut.collect(None, collected_facts) == dict()

# Generated at 2022-06-23 00:41:03.857080
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test should use a mock module
    module = 'mock_module'

    capsh_path = 'mock_capsh_path'

# Generated at 2022-06-23 00:41:08.446602
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x=SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:11.346443
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    print(collector.name)
    print(collector._fact_ids)


if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:41:12.980327
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:41:20.733822
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import base_module

    module = base_module.BaseModule()
    module.exit_json = lambda: None

    # create collector object
    provider = SystemCapabilitiesFactCollector()
    provider.collect(module)
    # add to ansible_facts_cache dictionary
    ansible_collector.add_collector(provider)

    facts = ansible_collector.get_ansible_facts(module)
    assert 'system_capabilities' in facts['ansible_facts']
    assert 'system_capabilities_enforced' in facts['ansible_facts']

# Generated at 2022-06-23 00:41:26.555986
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = AnsibleModuleMock()
    m.run_command.return_value = 0, 'Current: = cap_net_admin+ep', 'error'
    f = SystemCapabilitiesFactCollector()
    assert f.collect(m)['system_capabilities_enforced'] == 'False'
    assert f.collect(m)['system_capabilities'] == ['cap_net_admin']


# Generated at 2022-06-23 00:41:28.554057
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test dictionary with defaults
    assert SystemCapabilitiesFactCollector().name == 'caps'



# Generated at 2022-06-23 00:41:37.237014
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import FallbackModuleUtils
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import _get_caps_data
    from ansible.module_utils.facts.system.capabilities import _parse_caps_data
    caps = SystemCapabilitiesFactCollector()
    module_utils = FallbackModuleUtils()
    # test if capsh is not installed
    module_utils.get_bin_path = lambda x: None
    assert caps.collect(module=module_utils) == {}
    # test if capsh is

# Generated at 2022-06-23 00:41:48.396062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, 'Current: =ep', '')
    mock_caps = SystemCapabilitiesFactCollector()
    mock_caps.collect(module=mock_module)
    assert mock_caps.collect(module=mock_module) == {'system_capabilities_enforced': False, 'system_capabilities': []}
    mock_module.run_command.return_value = (0, 'Current: =ep cap_sys_chroot+ep cap_sys_admin+ep ', '')
    assert mock_caps.collect(module=mock_module) == {'system_capabilities_enforced': True, 'system_capabilities': ['cap_sys_chroot+ep', 'cap_sys_admin+ep']}
    mock_module

# Generated at 2022-06-23 00:41:58.891089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import tempfile
    import os
    import os.path
    from ansible.module_utils.facts import collector


# Generated at 2022-06-23 00:42:00.368531
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:04.958294
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:07.823223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert instance.name == 'caps'
    assert instance._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:42:09.517232
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:42:10.263339
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:42:11.464492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector.collect()

# Generated at 2022-06-23 00:42:13.012918
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    obj = SystemCapabilitiesFactCollector()
    assert obj.name == "caps"

# Generated at 2022-06-23 00:42:19.995913
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sCFC = SystemCapabilitiesFactCollector()
    sCFC_name = sCFC.name
    sCFC_ids = sCFC._fact_ids
    sCFC_caps = sCFC.collect()

    assert(sCFC_name == 'caps')
    assert(sCFC_ids == {'system_capabilities', 'system_capabilities_enforced'})
    assert(sCFC_caps == {'system_capabilities': ['cap_sys_chroot'], 'system_capabilities_enforced': 'False'})

# Generated at 2022-06-23 00:42:23.353841
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'


# TODO: add unit tests for 'collect()' method of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:42:28.847202
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CollecteFailError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_caps
    from ansible.module_utils.facts.utils import get_file_content
    if not ansible_collector.has_collector('caps'):
        ansible_collector.add_collector(SystemCapabilitiesFactCollector)


# Generated at 2022-06-23 00:42:38.600210
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:42:46.089523
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_from_collectors
    from ansible.module_utils.facts.collector import Module
    module = Module()
    module.get_bin_path = lambda opt: '/path/to/capsh'
    module.run_command = lambda opt: ['', 'Current: =eip', '']
    ansible_facts = collect_from_collectors(module)
    assert ansible_facts['system_capabilities_enforced'] == 'True'
    assert ansible_facts['system_capabilities'] == ['e', 'i', 'p']



# Generated at 2022-06-23 00:42:48.412936
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_obj = SystemCapabilitiesFactCollector()
    assert test_obj.collect() == {}

# Generated at 2022-06-23 00:42:57.697617
# Unit test for constructor of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:43:00.830460
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert facts._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:06.521688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    test_module = platform.system()
    from ansible.module_utils import facts

    test_facts = {'caps': {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}}
    test_facts = facts.get_facts(test_module, test_facts)
    assert test_facts['caps'] is not None

# Generated at 2022-06-23 00:43:10.678508
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:16.952492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = [{'run_command': {'rc': 1, 'out': 'Current: =ep', 'err': ''}}]
    facts = {'system_capabilities': [], 'system_capabilities_enforced': 'False'}
    assert SystemCapabilitiesFactCollector().collect(
        module=module, collected_facts={}) == facts

# Generated at 2022-06-23 00:43:19.325253
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in collector._fact_ids
    assert 'system_capabilities_enforced' in collector._fact_ids

# Generated at 2022-06-23 00:43:21.546064
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    # Test for the name of the class.
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:43:23.440517
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Ensures that the SystemCapabilitiesFactCollector initializes without arguments.
    assert SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:43:26.883051
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector.priority == 0
    assert set(collector._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:33.170523
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a poorly designed unit test since it relies on the
    # implementation details of module_utils.command_defaults.Module
    # Used to stub module
    def run_command(self, args, check_rc=False, close_fds=True,
                    executable=None, data=None, binary_data=False):
        return 0, 'Current: = ep\nBounding set =chown,dac_override,setgid,setuid,setpcap,net_raw,net_bind_service,net_admin,sys_chroot,mknod,audit_write,setfcap', None
    module = lambda: None
    module.run_command = run_command
    collector = SystemCapabilitiesFactCollector(module=module)
    collected_facts = collector.collect()

# Generated at 2022-06-23 00:43:41.725383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    capsh_path = '/sbin/capsh'
    command = ['capsh', "--print"]

# Generated at 2022-06-23 00:43:52.522118
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # generate instance of class SystemCapabilitiesFactCollector
    sys_caps = SystemCapabilitiesFactCollector()
    facts_dict = {}
    collected_facts = {}
    module_return_value = (0, "Current: =ep", "")
    def get_bin_path(binary):
        # NOTE: 'binary' is the name of the binary to search for in $PATH
        return '/usr/bin/capsh'
    def run_command(args, errors='surrogate_then_replace'):
        return module_return_value
    module_obj = create_module_object(get_bin_path, run_command)
    # NOTE: sys_caps.collect(module=module_obj, collected_facts=collected_facts)
    #       is the code to test
    #       it returns a dictionary of the modifications to be made

# Generated at 2022-06-23 00:43:57.533589
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities','system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:00.070978
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == "caps"
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:06.935122
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_bytes
    import re

    # Output from `capsh --print` when caps are enforced

# Generated at 2022-06-23 00:44:13.409592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import os
    import tempfile

    temp_file_handle, temp_file = tempfile.mkstemp()
    temporary_file_handle = os.fdopen(temp_file_handle, 'w')
    temporary_file_handle.write(
        'Current: =ep\nBounding set =cap_chown,cap_dac_override'
    )
    temporary_file_handle.close()

    mock_module = mock.MagicMock()
    mock_module.get_bin_path.return_value = temp_file
    mock_module.run_command.return_value = (0, '', '')

    SystemCapabilitiesFactCollector().collect(module=mock_module)

# Generated at 2022-06-23 00:44:16.255115
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # unit tests disabled/omitted/redundant, see lib/ansible/module_utils/facts/collector/__init__.py
    pass

# Generated at 2022-06-23 00:44:20.442230
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Create an instance of SystemCapabilitiesFactCollector
    system_capabilities_fc = SystemCapabilitiesFactCollector()
    assert system_capabilities_fc.name == 'caps'
    assert system_capabilities_fc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:23.857632
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # check class derived from class BaseFactCollector
    assert issubclass(SystemCapabilitiesFactCollector, BaseFactCollector)
    # check name
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:44:28.560344
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector

    capsh_fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(capsh_fact_collector, BaseFactCollector)
    assert capsh_fact_collector.name == 'caps'
    assert capsh_fact_collector._fact_ids == set(['system_capabilities',
                                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:31.590983
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert instance.name == 'caps'



# Generated at 2022-06-23 00:44:35.146547
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Unit test for constructor of class SystemCapabilitiesFactCollector
    '''
    _collector = SystemCapabilitiesFactCollector()
    if _collector.name != 'caps':
        return False
    if _collector._fact_ids is None:
        return False
    return True

# Generated at 2022-06-23 00:44:46.243273
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    # ansible.module_utils.facts.collectors.system.SystemCapabilitiesFactCollector.collect()
    #
    # These tests are based on the x86_64 RHEL 7.3 system_capabilities
    #   -> ['cap_chown', 'cap_dac_override', 'cap_fowner', 'cap_fsetid',
    #       'cap_kill', 'cap_setgid', 'cap_setuid', 'cap_setpcap',
    #       'cap_net_bind_service', 'cap_sys_chroot',
    #       'cap_mknod', 'cap_audit_write', 'cap_

# Generated at 2022-06-23 00:44:49.112608
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:54.403527
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert my_SystemCapabilitiesFactCollector.name == 'caps'
    assert 'system_capabilities' in my_SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in my_SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-23 00:45:03.129383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import textwrap

    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, binary, required=False):
            if binary == 'capsh':
                return '/bin/capsh'

            return None


# Generated at 2022-06-23 00:45:06.309744
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector constructor"""
    module = AnsibleModule()
    capf = SystemCapabilitiesFactCollector(module)
    assert capf.name == 'caps'
    assert capf._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:09.921406
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fixture = SystemCapabilitiesFactCollector()
    assert fixture
    assert fixture.name == 'caps'
    assert fixture._fact_ids == set(['system_capabilities',
                                     'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:22.256223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class args(object):
        def __init__(self, module):
            self.module = module
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector.load_collector_from_file('ansible.module_utils.facts.system.capabilities', 'SystemCapabilitiesFactCollector')
    system_capabilities_fact_collector.__init__(args(module=None))

    assert system_capabilities_fact_collector.__class__.__name__ == 'SystemCapabilitiesFactCollector'
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:32.299681
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule

    class MockModule:
        def __init__(self, cmd, rc, out, err):
            self.cmd = cmd
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, cmd):
            return '/bin/capsh'

        def run_command(self, cmd, errors):
            if cmd[0] == '/bin/capsh':
                return self.rc, self.out, self.err
            else:
                raise Exception('Unexpected command: {}'.format(cmd))

    def mock_get_file_content(path):
        return '/bin/capsh\n'


# Generated at 2022-06-23 00:45:46.588320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    module = MockModule(command_names=dict(get_bin_path=['capsh']))
    #mock_run = MagicMock(return_value = [0, 'Current: =ep', ''])
    mock_run = MagicMock(return_value = [0, 'Current: =epB', ''])
    module.run_command = mock_run
    sc = SystemCapabilitiesFactCollector(module=module, collected_facts=None)
    module.run_command = mock_run
    sc = SystemCapabilitiesFactCollector(module=module, collected_facts=None)
    module.run_command = mock_run
    sc = System

# Generated at 2022-06-23 00:45:49.089900
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facility = SystemCapabilitiesFactCollector()
    assert facility.name == 'caps'

# Generated at 2022-06-23 00:45:53.748132
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ Tests for SystemCapabilitiesFactCollector constructor, which returns a SystemCapabilitiesFactCollector object """

    fac = SystemCapabilitiesFactCollector()
    assert fac.name == 'caps'
    assert fac._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:04.267252
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import unittest

    class Mock_system_capabilities(object):
        def __init__(self):
            self.capsh_path = os.path.join(tempfile.gettempdir(), 'capsh')
            with open(self.capsh_path, 'w') as capsh_handle:
                capsh_handle.write(capsh_output)

        def get_bin_path(self, command):
            return self.capsh_path

        def run_command(self, command, errors):
            return 0, capsh_output, ''

    class Mock_system_capabilities2(object):
        def get_bin_path(self, command):
            return None


# Generated at 2022-06-23 00:46:07.411553
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == \
           set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:46:16.715492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Set up test parameters
    module = ansible.module_utils.facts.ansible_collector

# Generated at 2022-06-23 00:46:24.891211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    Collector.init(None, None)
    collector = get_collector_instance(SystemFactCollector)
    # Mock collect module and create snapshot

# Generated at 2022-06-23 00:46:35.961077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class Module(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return capsh_path

    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    import json


# Generated at 2022-06-23 00:46:46.454025
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:46:47.222551
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-23 00:46:53.223384
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize a SystemCapabilitiesFactCollector instance.
    my_obj = SystemCapabilitiesFactCollector()

    # Initialize a ansible.module_utils.facts.module.AnsibleModule instance.
    module = AnsibleModule(argument_spec={})

    # Invoke the collect method of SystemCapabilitiesFactCollector class
    # with module and collected_facts parameters.
    # This will return the ansible_facts.
    ansible_facts = my_obj.collect(module=module, collected_facts=None)
    print(ansible_facts)


# Generated at 2022-06-23 00:46:54.195716
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    _ = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:46:55.288825
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:47:05.234062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    method collect() of class SystemCapabilitiesFactCollector
    """
    # init
    class MockModule(object):
        def __init__(self):
            self.run_command_kwargs = {}

        def get_bin_path(self, executable, required=True):
            return "capsh_path"

        def run_command(self, args, **kwargs):
            self.run_command_kwargs.update(kwargs)
            return (0, "Current: =ep", "")

    class MockFacts(object):
        def __init__(self, sys_caps, sys_caps_enforced):
            self.system_capabilities = sys_caps
            self.system_capabilities_enforced = sys_caps_enforced

    caps_collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:47:14.823571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.run_command = MockModule.run_command

# Generated at 2022-06-23 00:47:26.192454
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    Collect = SystemCapabilitiesFactCollector()

    # test when capsh_path is not present
    Collect.module.get_bin_path = lambda x: None
    assert Collect.collect() == {}

    # test when capsh_path is present
    Collect.module.get_bin_path = lambda x: 'capsh_path'

# Generated at 2022-06-23 00:47:28.776218
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import ansible.module_utils.facts.collectors.system.caps as caps
    x = caps.SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert 'caps' in x._fact_ids