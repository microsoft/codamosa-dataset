

# Generated at 2022-06-23 00:37:42.472565
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Get the module object used to run commands and return facts
    module = MockAnsibleModule()

    # Create an instance of SystemCapabilitiesFactCollector to mock
    fact_collector = SystemCapabilitiesFactCollector(module=module)

    # Run collect and retrieve the fact returned
    fact_collector.collect()

    # Assert that the 'capsh' command was executed and the returned fact equals the expected fact
    assert module.run_command.call_count == 1
    assert 'system_capabilities' in fact_collector.facts
    assert 'current_capabilities' in fact_collector.facts['system_capabilities']
    assert 'effective_capabilities' in fact_collector.facts['system_capabilities']
    assert 'inheritable_capabilities' in fact_collector.facts['system_capabilities']

# Generated at 2022-06-23 00:37:52.397848
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:38:04.247739
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:38:05.173905
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj1 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:38:13.753929
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    class MockModule:
        def __init__(self, params):
            self.params = params
            return

        def get_bin_path(self, executable, opts=None, required=False):
            if self.params['executable'] == executable:
                return executable
            return None

        def run_command(self, cmd, check_rc=False, errors='surrogate_then_replace'):
            if self.params['cmd'] == cmd:
                return self.params['rc'], self.params['out'], self.params['err']
            return 1, '', ''

    # The following tests rely on

# Generated at 2022-06-23 00:38:25.603265
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector

    # Create a dummy module class
    class DummyModule:
        def run_command(self, cmd, errors='surrogate_then_replace'):
            # Simply return dummy data for each command
            if cmd[0] == '/usr/bin/test':
                return (0, '', '')
            elif cmd[0] == '/usr/bin/which':
                return (0, '', '')

# Generated at 2022-06-23 00:38:36.525909
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector import get_collector_instance

    # Instantiate a SystemCapabilitiesFactCollector instance
    caps_collector = get_collector_instance('SystemCapabilitiesFactCollector')

    # Test if instantiated instance is of type SystemCapabilitiesFactCollector
    assert isinstance(caps_collector, SystemCapabilitiesFactCollector)

    # Test method collect of class SystemCapabilitiesFactCollector
    class FakeModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, *args, **kwargs):
            return '/bin/capsh'


# Generated at 2022-06-23 00:38:39.972753
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:42.755181
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

    assert systemCapabilitiesFactCollector is not None
    assert systemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:38:44.452584
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:47.508383
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:59.533329
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:00.609294
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c



# Generated at 2022-06-23 00:39:04.926575
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:10.251723
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:39:14.375274
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector.fact_ids == {'system_capabilities',
                                                        'system_capabilities_enforced'}

# Generated at 2022-06-23 00:39:26.852644
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import LocalAnsibleModule
    module = LocalAnsibleModule()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        # NOTE: this is bad for multiple reasons:
        # * assuming order of entries in the output (line 0 and 1)
        # * assuming values of capability names (CAP_NET_ADMIN)
        # * assuming that enforced capabilities are present in the output
        # * assuming that the values of enforced capabilitiess are CAP_NET_ADMIN,CAP_SETPCAP
        # * assuming that enforced capabilitiess are enforced
        # * etc.
        #


# Generated at 2022-06-23 00:39:36.287574
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)


    # NOTE: when testing fail condition, module must be initialized
    # to None, or 'setdefaults' will fail
    module = None


    # capsh path is not set
    capsh_path = None
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-23 00:39:38.958564
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:39:50.229274
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Mock_module:
        def __init__(self, failure=False,
                     capsh_path='',
                     capsh_out='',
                     capsh_rc=0,
                     capsh_err=''
        ):
            self.failure = failure
            self.capsh_out = capsh_out
            self.capsh_rc = capsh_rc
            self.capsh_err = capsh_err
            self.capsh_path = capsh_path

        def get_bin_path(self, *args, **kwargs):
            return self.capsh_path

        def run_command(self, *args, **kwargs):
            if self.failure:
                return 1, '', 'Command failed'
            return self.capsh_rc, self.capsh_out, self.capsh_

# Generated at 2022-06-23 00:40:01.643720
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors import generic_collector

    # Create a instance of SystemCapabilitiesFactCollector class.
    obj = SystemCapabilitiesFactCollector()

    # check if the instance created is of the same class
    assert isinstance(obj, SystemCapabilitiesFactCollector), "instance created is not of SystemCapabilitiesFactCollector class"

    # check if the name of the instance is correct
    assert obj.name == "caps", "name of the instance is not correct"

    """
    Check the output of collect method with no arguments passed
    """
    assert not obj.collect(), "empty dictionary is not returned by collect method without arguments"

    """
    Check the output of collect method with arguments passed
    """
    # Create a mock object of BaseFactCollector class.

# Generated at 2022-06-23 00:40:06.297651
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj._fact_ids == {'system_capabilities',
                             'system_capabilities_enforced'}
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:40:18.010135
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import shutil
    import os
    import textwrap
    module = _get_AnsibleModule()
    (tmp_path, capsh_path) = _create_capsh_mock(module)
    # TODO: mock module.run_command(...) with capsh_path as first argument
    #       and with the following output:
    #
    #       0 Current: =eip
    #       0 Capability Bounds: =eip
    #       Attribute          Current     Effective     Inherited  Permitted
    #       chown              =eip        =eip          =eip       =eip
    #       dac_override       =eip        =eip          =eip       =eip
    #       dac_read_search    =eip        =eip          =eip       =

# Generated at 2022-06-23 00:40:30.039552
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts import DefaultCollectors
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_bytes

    module_mock = type('', (object,), {})
    module_mock.run_command = lambda self, cmd, check_rc=True: (0, to_bytes(cmd), '')
    module_mock.get_bin_path = lambda self, arg: arg

    Collector.module_implementation = module_mock
    DefaultCollectors.module = module_mock
    DefaultCollectors.module_implementation = module_mock

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    facts = dict()
   

# Generated at 2022-06-23 00:40:36.388910
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps', \
        "SystemCapabilitiesFactCollector.name should be 'caps'"
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced']), \
        "SystemCapabilitiesFactCollector._fact_ids should be set(['system_capabilities', 'system_capabilities_enforced'])"

# Generated at 2022-06-23 00:40:50.652976
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import pytest
    import sys

    try:
        import ptyprocess
    except Exception as e:
        pytest.skip("can't import ptyprocess: %s", e)

    class MockModule(object):

        def __init__(self):
            self.run_command_calls = []
            self.run_command_results = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)


# Generated at 2022-06-23 00:41:01.565797
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        def __init__(self, bin_path,results):
            self.bin_path = bin_path
            self.results = results

        def get_bin_path(self,binary):
            return self.bin_path

        def run_command(self, cmd, errors):
            return self.results

    class MockAnsibleModule:

        def __init__(self):
            self.CAPSH_PATH = '/bin/capsh'
            self.CAPSH_ERR = 'get_bin_path'
            self.CAPSH_NA = 'run_command'
            self.CAPSH_TRUE = 'run_command'
            self.CAPSH_FALSE

# Generated at 2022-06-23 00:41:04.819066
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:09.379613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    print(json.dumps(facts_dict, indent=2))

if __name__== '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-23 00:41:16.595186
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    sys_caps_fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}

# Generated at 2022-06-23 00:41:24.072790
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import platform
    import shutil
    module = sys.modules['ansible.module_utils.facts.system.capabilities']
    module.get_bin_path.return_value = True

# Generated at 2022-06-23 00:41:31.043370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #mock_module = MagicMock()
    #mock_module.get_bin_path.return_value = '/bin/capsh'
    #mock_module.run_command.return_value = (0, 'Current: =ep\nBounding set =', '')
    #caps_facts = SystemCapabilitiesFactCollector().collect(mock_module, None)
    #assert caps_facts['system_capabilities_enforced'] == 'False'
    #assert caps_facts['system_capabilities'] == []
    pass

# Generated at 2022-06-23 00:41:34.048254
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])
    assert collector.collect(module) == {}

# Generated at 2022-06-23 00:41:36.450689
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:41:43.312648
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    module.get_bin_path.return_value = None
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect(module=module)
    assert facts_dict.get('system_capabilities') == []
    assert facts_dict.get('system_capabilities_enforced') == 'False'

# Generated at 2022-06-23 00:41:54.070815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    class MockAnsibleModule:
        """ Mock AnsibleModule class. """
        def __init__(self):
            """ Constructor. """
            self.params = {}
            self.args = sys.argv

        def run_command(self, cmd, errors='surrogate_then_replace'):
            """ Mock run_command method. """
            import sys
            import os


# Generated at 2022-06-23 00:41:56.255906
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert len(obj._fact_ids) == 2

# Generated at 2022-06-23 00:41:59.438777
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # init Collector
    fc = SystemCapabilitiesFactCollector()
    # init output
    fc.collect(module='test_module', collected_facts='test_dict')
    # test output
    print(fc.collect.__module__)

# Generated at 2022-06-23 00:42:04.918025
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:09.163136
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:42:18.206781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()

    class MyModule(object):
        def get_bin_path(self, arg):
            return '/path/to/capsh'

        def run_command(self, args, **keyword_args):
            if args[0] == '/path/to/capsh' and args[1] == '--print':
                return 0, 'Current: =ep', ''
            raise AssertionError()

    module = MyModule()

    result = collector.collect(module)

    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Generated at 2022-06-23 00:42:26.905467
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize the class instance
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Prepare the set of facts
    collected_facts = {"system_capabilities_enforced": {}, "system_capabilities": []}

    # Mocking the run_command method
    def run_command(self, cmd, errors='surrogate_then_replace'):
        if cmd[0] == '/bin/capsh':
            out = "Current: =ep\n"
            err = ''
            rc = 0
        else:
            out = "Current: =ep cap_net_raw,cap_sys_admin\n"
            err = ''
            rc = 0
        return rc, out, err

    # Mock the module and class instance

# Generated at 2022-06-23 00:42:37.292848
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/bin/capsh'
    mock_module = MockModule()

# Generated at 2022-06-23 00:42:39.629841
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:40.617705
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:42.106325
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test that an instance of the collector is created
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:43.170401
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector, object)

# Generated at 2022-06-23 00:42:52.501060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.test.unit.module_utils.facts.test_system_capabilities_facts import TestModule
    from ansible.module_utils.facts.system_capabilities_facts import SystemCapabilitiesFactCollector

    class TestSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def get_caps_data(self, module=None):
            if not module:
                return {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
            return mock.Mock()

        def parse_caps_data(self, data):
            return {}

    test_module = TestModule()
    module_mock = mock.Mock()

    test_system_capabilities_fact_collector = TestSystem

# Generated at 2022-06-23 00:43:03.460287
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Stub for method 'run_command' of class 'AnsibleModule'
    class StubAnsibleModule:
        @staticmethod
        def get_bin_path(binary):
            return binary

        def run_command(self, command):
            if isinstance(command, list):
                if command[1] == '--print':
                    return (0, 'Current: =ep cap_net_raw+ep\n', '')
                return (0, '', '')
            else:
                return (0, '', '')

    # Stub the 'AnsibleModule'
    mod = StubAnsibleModule()
    # Stub the 'dict'
    collected_facts = {}
    # Create the SystemCapabilitiesFactCollector object
    ssc = SystemCapabilitiesFactCollector(mod, collected_facts)
    # Execute collect

# Generated at 2022-06-23 00:43:13.740334
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: fake module params, e.g. module.run_command() return values -akl
    # for test module_utils.facts.collector.SystemCapabilitiesFactCollector.collect()
    # and expected return dict from test module_utils.facts.collector.SystemCapabilitiesFactCollector.collect()
    module = {}

# Generated at 2022-06-23 00:43:25.184639
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Build instance to test and dictate expected results
    expected_dict = {'system_capabilities_enforced': 'True',
                     'system_capabilities': ['=ep']}
    # NOTE: let mock return actual output from system (using capsh --print) -akl
    capsh_path = '/usr/bin/capsh'
    mock_run_command = lambda self, args, **kwargs: (0, 'Current: =ep', '')
    mock_get_bin_path = lambda self, args, **kwargs: capsh_path
    test_instance = SystemCapabilitiesFactCollector()
    test_instance.run_command = mock_run_command
    test_instance.get_bin_path = mock_get_bin_path
    actual_dict = test_instance.collect()

    # Assert results match expectations
   

# Generated at 2022-06-23 00:43:32.196555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Unit test for method SystemCapabilitiesFactCollector.collect """
    # NOTE: get_caps_data()/parse_caps_data() for easier mocking -akl
    #
    # arrange
    #
    import ansible.module_utils.facts.system.caps

    # system_capabilities_enforced expected to be 'NA' when capsh binary not available on PATH
    expected_system_capabilities_enforced = 'NA'
    # system_capabilities expected to be empty list when capsh binary not available on PATH
    expected_system_capabilities = []

    # act
    actual_system_capabilities_enforced, actual_system_capabilities = ansible.module_utils.facts.system.caps.get_caps_data()

    # assert
    assert expected_system_capabilities_enforced == actual_system_capabilities_

# Generated at 2022-06-23 00:43:35.627456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = None
    test_collector = SystemCapabilitiesFactCollector()
    assert {} == test_collector.collect( module=module_mock)

# Generated at 2022-06-23 00:43:40.335830
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                              'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:43.945375
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:54.825442
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_class = SystemCapabilitiesFactCollector()

    # NOTE: set up environment/context to test collect() -akl
    return_code = 0

# Generated at 2022-06-23 00:44:03.704095
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    import pytest
    from ansible.module_utils.facts import collector

    class TestModule(object):
        def __init__(self, params=None):
            self.params = params
            self.run_command_results = []

        def get_bin_path(self, binary):
            return '/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_results.append(cmd)

# Generated at 2022-06-23 00:44:06.523215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector().collect()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 00:44:09.865998
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # test_SystemCapabilitiesFactCollector_collect:
    #  -check that no exception is raised when capsh_path is None.
    assert(SystemCapabilitiesFactCollector().collect() == {})

# Generated at 2022-06-23 00:44:12.927480
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(fact_collector, BaseFactCollector)
    assert fact_collector.name == 'caps'

# Generated at 2022-06-23 00:44:16.629446
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set([
        'system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:19.858036
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:44:29.875539
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile

    # NOTE: not mocked 'capsh' and no parsing of it's output.
    # These should be mocked and parsed for real testing.
    #fixture_path = os.path.join(os.path.dirname(__file__), 'unit', 'fixtures', 'capsh')

    os_facts = {
        'distribution': 'Debian',
        'distribution_file_parsed': True,
        'distribution_file_variety': 'Debian',
        'distribution_major_version': '8',
        'distribution_release': 'jessie',
        'distribution_version': '8.9',
        'os_family': 'Debian'
    }

    class MockModule(object):
        def __init__(self, params):
            self.params = params

       

# Generated at 2022-06-23 00:44:39.321989
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:44:44.449302
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert len(SystemCapabilitiesFactCollector()._fact_ids) == 2
    assert 'system_capabilities' in SystemCapabilitiesFactCollector()._fact_ids
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector()._fact_ids


# Generated at 2022-06-23 00:44:55.976010
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    module = MockedModule()
    capsh_path = module.get_bin_path('capsh')
    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'
                enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector.collect(module)

# Generated at 2022-06-23 00:45:02.281252
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Unit test for method collect of class SystemCapabilitiesFactCollector
    # Parameters/returns
    #   Parameters
    #   ----------
    #   collected_facts : dict
    #       Collected facts
    #   Returns
    #   -------
    #   collected_facts : dict
    #       Collected facts
    pass

# Generated at 2022-06-23 00:45:03.334569
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-23 00:45:13.399230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib_parse import quote

    if PY2:
        builtin_module_name = '__builtin__'
    else:
        builtin_module_name = 'builtins'


# Generated at 2022-06-23 00:45:16.344478
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap_fact_col = SystemCapabilitiesFactCollector()
    assert cap_fact_col.name == 'caps'

    assert len(cap_fact_col._fact_ids) == 2

# Generated at 2022-06-23 00:45:25.349736
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'Current: =eip\nBounding set =eip\nSecurebits: 00/0x0/1\'b0\n secure-noroot: no (unlocked)\n secure-no-suid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)\n', '')
    mock_module.get_bin_path.return_value = True
    mock_collector = SystemCapabilitiesFactCollector()
    assert mock_collector.collect(module=mock_module) == {'system_capabilities_enforced': 'False', 'system_capabilities': ['eip']}

# Generated at 2022-06-23 00:45:29.324515
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    # Unit test for constructor of SystemCapabilitiesFactCollector
    # Collects the caps data and then sets it up in the fact dict

    test_module = MockModule({'capsh': ''})
    test_object = SystemCapabilitiesFactCollector()

    assert test_object.collect(test_module) == {}

# Generated at 2022-06-23 00:45:32.965740
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector.__name__ == 'SystemCapabilitiesFactCollector'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:45:38.356005
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    module.params['binary_paths'] = None
    module.params['binary_paths'] = ['/bin', '/usr/bin']
    module.run_command = MagicMock(return_value=(0, 'Current: = cap_net_bind_service,cap_setgid+i, cap_setuid+i', ''))
    module.get_bin_path = MagicMock(return_value=True)
    SystemCapabilitiesFactCollector().collect(module=module)

# Generated at 2022-06-23 00:45:39.273823
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:49.984630
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class SystemCapabilitiesFactCollector_collect:
        #
        # NOTE:  This test assumes that the 'capsh' command is available on the system that is
        #        running the tests!  The tests will not work on systems that do not have 'capsh'
        #        installed.
        #
        def __init__(self, module, collected_facts):
            self.module = module
            self.collected_facts = collected_facts

        def run_command(self, args, errors=None):
            # NOTE: capsh was chosen because it has different output on different systems
            #   This method will be mocked to return different output for different tests
            if errors == 'surrogate_then_replace':
                out = "Current: =ep\n"

# Generated at 2022-06-23 00:46:01.124362
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Args():
        def __init__(self, bin_ansible_callbacks):
            self.bin_ansible_callbacks=bin_ansible_callbacks
    class Func():
        def __init__(self, capsh_path):
            self.caps_path=capsh_path
        def get_bin_path(self, bin_name):
            return self.caps_path

# Generated at 2022-06-23 00:46:03.734390
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Check if a SystemCapabilitiesFactCollector can be instantiated
    """
    # Constructing a SystemCapabilitiesFactCollector must succeed
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:46:14.081702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    module = MagicMock()

    # NOTE: move to fact_suite.py
    class MockModuleUtilsFactCollector(BaseFactCollector):
        _fact_ids = ['mock_fact']

        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            if not module:
                return facts_dict

            module.get_bin_path.return_value = '/bin'

            return {'mock_fact': 1}

    # (class_name, method_name, return_value, side_effect)

# Generated at 2022-06-23 00:46:23.175403
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def run_command_mock(args, **kwargs):
        return 0, 'Current: = cap_setpcap,cap_net_bind_service,cap_net_raw=ep', ''

    def get_bin_path_mock(args, **kwargs):
        return '/usr/bin/' + args

    module = None
    myfact = SystemCapabilitiesFactCollector()
    monkeypatch.setattr(myfact.module, 'run_command', run_command_mock)
    monkeypatch.setattr(myfact.module, 'get_bin_path', get_bin_path_mock)
    myfact.collect(None, None)
    assert myfact.get_facts()['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:46:30.691674
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = AnsibleModule({'binary_module': True})
    test_module.run_command = MagicMock(return_value=('#', 'Current: =ep', ''))
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    test_result = test_SystemCapabilitiesFactCollector.collect(test_module, None)
    assert test_result == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-23 00:46:32.466538
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'

# Generated at 2022-06-23 00:46:37.090921
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import mock
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector

    CapshCollector = SystemCapabilitiesFactCollector()

    assert CapshCollector.name == 'caps'
    for fact in CapshCollector._fact_ids:
        assert fact in collector.FACT_SUBSETS['all']

# Generated at 2022-06-23 00:46:38.674846
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:46:47.647748
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps

    import ansible.module_utils.basic
    import ansible.module_utils.six

    import ansible.module_utils.ansible_release
    ansible.module_utils.ansible_release.__version__ = '2.1.0'

    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.shutil

    import ansible.module_utils.system
    ansible.module_utils.system.DO_VERSION_CHECK = False
    ansible.module_utils.system.IS_SELINUX_CAPABLE = True
    ansible.module_utils.system.SELINUX_DEFAULT_ENFORCED = True

# Generated at 2022-06-23 00:46:50.686595
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector.collect() == {}

# Generated at 2022-06-23 00:47:01.690722
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create mock
    module = MagicMock()
    module.command_help.return_value = ['/usr/bin/capsh', '--print']
    module.get_bin_path.return_value = '/usr/bin/capsh'

# Generated at 2022-06-23 00:47:07.616941
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import pytest
    module = pytest.Mock()
    module.get_bin_path.return_value = 'capsh'
    module.run_command.return_value = '', '', ''
    system_capability_fact_collector = SystemCapabilitiesFactCollector(module)

    assert system_capability_fact_collector.name == 'caps'



# Generated at 2022-06-23 00:47:16.611818
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockAnsibleModule:
        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/capsh'

        def run_command(self, cmd, **kwargs):
            if cmd == ['/usr/bin/capsh', "--print"]:
                return 0, 'Current: =ep', ''
            return None

    mock_AnsibleModule = MockAnsibleModule()
    expected_facts = {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }
    assert SystemCapabilitiesFactCollector().collect(mock_AnsibleModule) == expected_facts

    expected_facts['system_capabilities_enforced'] = 'True'

# Generated at 2022-06-23 00:47:26.684466
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collectors.system.caps
    import ansible.module_utils.facts.collectors.system.platform
    import ansible.module_utils._text
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.connection
    import sys
    import os
    import mock

    # mock objects
    class MockPlatform(object):
        def __init__(self):
            self.distribution = "MockDistro"
            self.distribution_version = "MockDistroVersion"


# Generated at 2022-06-23 00:47:28.907674
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert 'system_capabilities' in x._fact_ids
    assert 'system_capabilities_enforced' in x._fact_ids

# Generated at 2022-06-23 00:47:33.108000
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])