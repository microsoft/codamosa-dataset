

# Generated at 2022-06-23 00:37:34.575914
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:39.750424
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps.name == 'caps'
    assert sys_caps._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:40.706115
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:37:42.578388
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc._capsh_path == 'capsh'

# Generated at 2022-06-23 00:37:46.550404
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # init
    module = None
    collected_facts = {}
    collector = SystemCapabilitiesFactCollector()

    # run the test
    result = collector.collect(module, collected_facts)

    # check the results
    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result

# Generated at 2022-06-23 00:37:54.757930
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.mock_run_command_results = []

        def run_command(self, args, errors=None):
            rc, out, err = self.mock_run_command_results.pop(0)
            return rc, out, err

    class MockFactsCollector(object):
        def __init__(self):
            self.facts = {}

    class TestSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def __init__(self, module=None, collected_facts=None):
            super(TestSystemCapabilitiesFactCollector, self).__init__(module, collected_facts)
            self._module = module
            self._collect_caps_data()  # method under test


# Generated at 2022-06-23 00:38:05.413496
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys

    collected_facts = {}
    class MockModule(object):
        def __init__(self, bin_path_result):
            self.bin_path_result = bin_path_result
            self.run_command_result = None
        def get_bin_path(self, arg):
            return self.bin_path_result
        def run_command(self, args, errors=None):
            assert errors is 'surrogate_then_replace'
            if self.run_command_result is None:
                return 0, 'Current: =ep', ''
            else:
                return self.run_command_result

    # capsh_path is present
    capsh_path = '/bin/capsh'
    mock_module = MockModule(capsh_path)
    scc = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:38:13.850570
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create object instance for AnsibleModule
    from ansible.module_utils.facts.collector.system import AnsibleModule
    from ansible.module_utils.facts.collector.system import BaseFile
    import ansible.module_utils.facts.collector.system.os
    os = ansible.module_utils.facts.collector.system.os
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # capture original os.access function
    original_os_access = os.access

    # create mock os.access
    def my_os_access(path, mode):
        if path == "/proc/1/exe":
            return False
        else:
            return original_os_access(path, mode)

    # patch os.access with the mock
    os

# Generated at 2022-06-23 00:38:25.687057
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class DummyModule:
        def __init__(self, run_result):
            self.run_result = run_result

        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'capsh':
                return '/usr/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return self.run_result

    module = DummyModule((0, 'Current: =ep\nBounding set =ep', ''))
    collector = SystemCapabilitiesFactCollector(module=module)
    results = collector

# Generated at 2022-06-23 00:38:36.610904
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import Collector

    # Setup a mock ansible.module_utils.facts.collector.Collector class with mock ansible.module_utils.facts.collector.BaseFactCollector.collector_name set to "capsh"
    Collector.collectors = {'capsh': SystemCapabilitiesFactCollector}
    Collect = get_collector_instance('capsh')

    assert Collect.collector_name == 'capsh'

    capsh_path = '/sbin/capsh'
    rc = 0
    err = ''

# Generated at 2022-06-23 00:38:42.971204
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import Collector
    c = Collector()
    capsh = SystemCapabilitiesFactCollector(c)
    assert isinstance(capsh, SystemCapabilitiesFactCollector)
    assert isinstance(capsh, BaseFactCollector)
    assert capsh.name == 'caps'
    assert capsh._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:47.185638
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])
    assert fact_collector.collect() == {}

# Generated at 2022-06-23 00:38:50.627180
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:02.584668
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for collect method of class SystemCapabilitiesFactCollector
    """
    import os
    import sys
    import tempfile
    import mock

    # Prepare
    class Dummy():
        """ Dummy class for mocking modules """
        def __init__(self):
            self.params = {}

    class DummyModule(Dummy):
        """ Dummy class for mocking module """
        def __init__(self):
            super(DummyModule, self).__init__()
            self.params = {}

    class DummyModuleUtil(Dummy):
        """ Dummy class for mocking module utils """
        def __init__(self):
            super(DummyModuleUtil, self).__init__()
            self.params = {}

        # pylint: disable=unused-argument

# Generated at 2022-06-23 00:39:09.246539
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector

    MockModule = basic.AnsibleModule
    mock_module = MockModule()

    collector = collector.SystemCapabilitiesFactCollector(mock_module)
    result = collector.collect({}, {})

    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result


# Generated at 2022-06-23 00:39:20.656391
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:26.270516
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector is not None
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:35.690577
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Creating a mock object of class BaseFile
    base_file_obj = Mock()

    # Setting the path_file to None
    base_file_obj.path_file = None

    # Mocking the 'exist' method of BaseFile class
    base_file_obj.exists = MagicMock(return_value=True)

    # Mocking the get_capsh_path of BaseFile class
    base_file_obj.get_capsh_path = MagicMock(return_value=True)

    # Mocking the run_command of BaseFile class
    base_file_obj.run_command = MagicMock(return_value=True)

    # Mocking the parse_capsh_data of BaseFile class
    base_file_obj.parse_capsh_data = MagicMock(return_value=True)

    # Creating

# Generated at 2022-06-23 00:39:46.930789
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class ModuleMock:
        def __init__(self):
            self.run_command_called = 0
            self.run_command_args_list = []

        def get_bin_path(self, executable, required=False):
            return '/usr/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_called += 1
            self.run_command_args_list.append(cmd)
            if self.run_command_called != 1:
                return (0, '', '')

# Generated at 2022-06-23 00:39:49.970943
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert _fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:39:54.390169
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:57.743122
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert instance is not None
    assert instance.name == 'caps'
    assert instance._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:08.809939
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest
    collected_facts = {'platform_subsystem': 'Linux',
                       'system_capabilities': [],
                       'platform_capabilities_enforced': 'True',
                       'os_family': 'RedHat',
                       'system': 'Linux'}

    # Create target class
    target = SystemCapabilitiesFactCollector(None, {}, [], [])

    # Create 'module' mock
    class module_mock:
        def get_bin_path(self, arg):
            return "/bin"

        def run_command(self, cmd, errors):
            return 0, 'Current: =ep', 'err'

    # Create 'ansible.module_utils.facts.collector.BaseFactCollector' mock

# Generated at 2022-06-23 00:40:14.318682
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:15.288312
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:27.906440
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    module.get_bin_path.return_value = True

# Generated at 2022-06-23 00:40:29.207322
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert not SystemCapabilitiesFactCollector().collected_facts



# Generated at 2022-06-23 00:40:32.888861
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert ('system_capabilities' in SystemCapabilitiesFactCollector._fact_ids and
            'system_capabilities_enforced' in SystemCapabilitiesFactCollector._fact_ids)

# Generated at 2022-06-23 00:40:41.955719
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    data = dict()
    data['system_capabilities_enforced'] = 'True'
    data['system_capabilities'] = ['chown', 'dac_override']
    data['system_capabilities_enforced'] = 'True'
    data['system_capabilities'] = ['chown', 'dac_override']

    def mock_bin_path(key):
        return capsh_path

    def mock_run_command(arg_list, **kwargs):
        rc = 0
        out = 'Current: =ep\nBounding set =cap_chown,cap_dac_override\nSecurebits: 00/0x0/1'
        err = ''
        return rc, out, err

    capsh_path = '/usr/bin/capsh'
    module = MagicMock()

# Generated at 2022-06-23 00:40:49.553023
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Unit test for constructor of class SystemCapabilitiesFactCollector"""
    a = SystemCapabilitiesFactCollector()
    assert a.name == 'caps'
    assert a._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:51.767502
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = dict()
    instance = SystemCapabilitiesFactCollector(None, None, facts)
    assert instance.name == "caps"

# Generated at 2022-06-23 00:40:57.244494
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()

# Generated at 2022-06-23 00:41:08.012064
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes

    collector_class = SystemCapabilitiesFactCollector
    test_module = DummyModule(name='test_module')

# Generated at 2022-06-23 00:41:09.134075
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert 0, 'Expected fail because of not implemented yet'

# Generated at 2022-06-23 00:41:16.490685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import default_collectors as default_collector_list
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector as SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector import SystemCapabilitiesFactCollector as SystemCapabilitiesFactCollector_class
    module = MockModule()
    class_obj = SystemCapabilitiesFactCollector_class()
    class_obj.collect(module)
    module.run_command.assert_called_with(['/usr/bin/capsh', '--print'])
    assert class_obj.name == "caps"
    assert class_obj

# Generated at 2022-06-23 00:41:27.587987
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create test object
    # NOTE: this should be instantiated with a module with a valid
    #       capsh_path.  This must be mocked or a real path used
    #       for this test to work
    caps_collector = SystemCapabilitiesFactCollector()

    # Create a test module object with a valid path for capsh
    # NOTE: this is normally imported by the Ansible module, but needs
    #       to be mocked here.
    class Module(object):
        def __init__(self):
            self.bin_path = 'some/path'

        def get_bin_path(self, name, opt_dirs=None):
            if name == 'capsh':
                return self.bin_path
            else:
                return None


# Generated at 2022-06-23 00:41:36.052125
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import mock
    from ansible.module_utils.facts import collector
    mock_module = mock.Mock()
    mock_module.get_bin_path.return_value = '/usr/bin/capsh'

# Generated at 2022-06-23 00:41:47.605917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest


# Generated at 2022-06-23 00:41:56.916320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Called once, no params
    from ansible.module_utils.facts import ModuleShim
    from ansible.module_utils import basic
    import os

    # Setup test case
    sys_caps = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:02.849031
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector().collect()
    # 'system_capabilities_enforced' and 'system_capabilities' keys are there in the result
    result_keys = result.keys()
    assert set(result_keys) == set(['system_capabilities_enforced', 'system_capabilities'])

# Generated at 2022-06-23 00:42:14.078560
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # init module and class instances
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import collector

    m = basic.AnsibleModule(
        argument_spec=dict()
    )
    c = collector.get_collector(m)
    m.get_bin_path = lambda path: path
    f = SystemCapabilitiesFactCollector(m)

    # set expected return values

# Generated at 2022-06-23 00:42:23.613340
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test method collect of class SystemCapabilitiesFactCollector
    """

    def run_command(self, args, check_rc=True, close_fds=True, executable=None,
            data=None, binary_data=False, path_prefix=None, cwd=None,
            use_unsafe_shell=False, prompt_regex=None, environ_update=None,
            umask=None, errors=None):
        return 0, "", ""

    module = type("AnsibleModule", (object,), {
        'run_command': run_command
    })

    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = fact_collector.collect(module)

    assert collected_facts['system_capabilities_enforced'] == "True"

# Generated at 2022-06-23 00:42:26.379624
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_cap_facts_collector = SystemCapabilitiesFactCollector()
    assert sys_cap_facts_collector.name == 'caps'
    assert sys_cap_facts_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:33.353033
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # create object of SystemCapabilitiesFactCollector class
    caps_obj = SystemCapabilitiesFactCollector()

    # get the name of the class
    class_name = caps_obj.name

    # get the facts ids
    fact_id_list = caps_obj._fact_ids

    # check if the variables have correct values
    assert class_name == "caps"
    assert fact_id_list == {'system_capabilities_enforced', 'system_capabilities'}

# Generated at 2022-06-23 00:42:44.726135
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.system
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.platform
    from ansible.module_utils.facts.system.capabilities import \
        SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector

    ansible.module_utils.facts.collector.COLLECTORS = \
        [SystemCapabilitiesFactCollector, SystemFactCollector]
    ansible.module_utils.facts.utils.get_file_content = lambda x: ''

# Generated at 2022-06-23 00:42:46.926489
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert(SystemCapabilitiesFactCollector().name == 'caps')
    assert(SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced']))

# Generated at 2022-06-23 00:42:56.838923
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock module for this test
    # NOTE: mock_module.params['gather_subset']=['!all'] does nothing
    mock_module = MagicMock()
    # mock_module.params = {'gather_subset': ['!all']}
    mock_module.get_bin_path.return_value = capsh_path
    # get the output of system-capabilities module with:
    # ansible -m system_capabilities -a '{}' all
    # which gets the output of:
    # capsh --print
    rc, out, err = mock_module.run_command.return_value = (0, capsh_out, '')
    SystemCapabilitiesFactCollector.collect(mock_module, collected_facts={})
    assert rc == 0
    mock_module.get_bin

# Generated at 2022-06-23 00:43:00.043396
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:10.972320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import collections
    from ansible.module_utils.facts.utils import get_file_lines
    # setup test data
    results = {
        'system_capabilities': ['cap_sys_ptrace=eip'],
        'system_capabilities_enforced': True,
    }
    # prepare test environment
    with open('/tmp/capsh', 'w') as capsh_file:
        capsh_file.write('#!/bin/sh\ncat /tmp/capsh.out')
    capsh_out = get_file_lines('/tmp/capsh.out')
    # perform test
    new_results = SystemCapabilitiesFactCollector._collect_capsh_facts({'capsh_path': '/tmp/capsh'}, capsh_out)

    # validate results

# Generated at 2022-06-23 00:43:16.306103
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class_name = 'ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector'
    import sys
    if sys.version_info >= (3, 0):
        x = '__class__'
    else:
        x = '__name__'
    assert eval(class_name + '.' + x) == 'ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector'
    assert eval(class_name + '.name') == 'caps'



# Generated at 2022-06-23 00:43:18.524360
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert len(obj._fact_ids) == 2

# Generated at 2022-06-23 00:43:19.744329
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    # Create an instance of a class
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:43:27.771702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value="/usr/bin/capsh")
    stderr = StringIO()
    with redirect_stderr(stderr):
        scfc = SystemCapabilitiesFactCollector(module=module)
        collected_facts = scfc.collect()

    assert collected_facts['system_capabilities_enforced'] == 'NA'
    assert collected_facts['system_capabilities'] == []



# Generated at 2022-06-23 00:43:38.361793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector

    # Setup a test AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a instance of SystemCapabilitiesFactCollector class using AnsibleModule as __init__ parameter
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector(module=module)
    # Execute method collect of class SystemCapabilitiesFactCollector
    collected_facts = system_capabilities_fact_collector.collect()
    assert collected_facts == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-23 00:43:40.126988
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-23 00:43:43.254603
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:45.037254
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x

# Generated at 2022-06-23 00:43:49.208349
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:52.912677
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == "caps"
    assert system_capabilities_fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:44:03.196519
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:44:08.515730
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    This Unit test tests the constructor of the class SystemCapabilitiesFactCollector.
    """
    instance = SystemCapabilitiesFactCollector()
    assert instance.name == 'caps'
    assert instance._fact_ids == set(['system_capabilities', \
                                      'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:09.859590
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:44:21.418107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import copy

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b'Version:	1.0\n')
    test_file.write(b'CapBnd:	0000003fffffffff\n')
    test_file.write(b'CapEff:	0000003fffffffff\n')
    test_file.write(b'CapInh:	0000000000000000\n')
    test_file.write(b'CapPrm:	0000003fffffffff\n')
    test_file.write(b'CapAmb:	0000003fffffffff\n')
    test_file.write(b'NoNewPrivs:	0\n')
    test_file.write(b'SecComp:	0\n')


# Generated at 2022-06-23 00:44:30.764571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: [1] covers the case where capsh is availabe and returns enforced=True,
    # whereas in [2] capsh is available but return enforced=False.
    # In [3] capsh is not available and thus system_capabilities_enforced is 'NA'
    # and system_capabilities is empty

    mock_module = Mock(get_bin_path=Mock(return_value=True))
    mock_module.run_command = Mock(return_value=(0, 'Current: =ep\nboun dings', ''))
    # NOTE: -> get_bin_path, run_command for easier mocking -akl
    facts_dict = SystemCapabilitiesFactCollector.collect(mock_module)
    assert facts_dict['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:44:32.748280
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-23 00:44:42.451532
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import base
    from ansible.module_utils.facts.collectors.generic.system_capabilities import SystemCapabilitiesFactCollector
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    src_path = os.path.join(dir_path, '../')
    if os.path.exists(os.path.join(src_path, 'ansible')):
        sys.path.insert(0, src_path)
    base_fact = base.BaseFactCollector()
    SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(base_fact)

# Generated at 2022-06-23 00:44:46.389535
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:44:47.321530
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:44:51.125272
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    p = SystemCapabilitiesFactCollector()
    assert p.name == 'caps'
    assert p._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:44:53.625885
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'


# Generated at 2022-06-23 00:45:02.332156
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock the module and its return value, module.run_command(['capsh', '--print'])
    # Create empty facts_dict to populate
    import mock
    import module_utils.facts.system.capabilities as cap_mod

    m_mod = mock.MagicMock()
    # This is not so much a 'return_value', as a mocked side_effect
    # m_mod.run_command() will return the tuple indicated below, for each call.
    # This allows us to simulate the behavior of run_command() on separate hosts

# Generated at 2022-06-23 00:45:12.669016
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:45:16.350011
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_scfc = SystemCapabilitiesFactCollector()
    assert my_scfc.name == 'caps'
    assert my_scfc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert my_scfc.collect() == {}
    my_scfc.collect(module=True)

# Generated at 2022-06-23 00:45:18.268397
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector class"""
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:26.199455
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    caps_collector = SystemCapabilitiesFactCollector()

    collected_facts = {'system_capabilities': ['chown', 'dac_override', 'fowner',
                                               'fsetid', 'kill', 'setgid',
                                               'setuid', 'setpcap', 'net_bind_service',
                                               'net_raw', 'sys_chroot', 'mknod',
                                               'audit_write', 'setfcap'],
                       'system_capabilities_enforced': 'True'}

    module = FakeAnsibleModule()
    assert collected_facts == caps_collector.collect(module)


# Generated at 2022-06-23 00:45:28.337944
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
   res = SystemCapabilitiesFactCollector()
   assert len(res.name) > 0
   assert len(res._fact_ids) > 0

# Generated at 2022-06-23 00:45:36.061636
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.openbsd
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.systemd
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system

# Generated at 2022-06-23 00:45:48.202775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # See also test/unit/module_utils/facts/test_system_platform.py

    class TestModule:
        def __init__(self, platform, is_Linux):
            self.platform = platform
            self.is_Linux = is_Linux

        def get_bin_path(self, program):
            if program == "capsh" and self.is_Linux:
                return '/usr/bin/capsh'
            return None

        def run_command(self, program, errors='surrogate_then_replace'):
            if program == ['/usr/bin/capsh', "--print"]:
                if self.is_Linux:
                    if self.platform in ['RedHat', 'CentOS']:
                        return 0, "Current: =ep\n", ''

# Generated at 2022-06-23 00:45:50.297515
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'

# Generated at 2022-06-23 00:45:52.756954
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:03.471100
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need a real module for this test to work -akl
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # Create an instance of a 'system.caps' collector
    #
    # NOTE: this is what a user would do:
    #   from ansible.module_utils.facts.collector import get_collector_instance
    #   get_collector_instance('system.caps')
    caps_collector = get_collector_instance('system.caps')

    # Create a 'module'
    #
    # NOTE: this is what a user would do:
    #   import AnsibleModule
    #   module = AnsibleModule(


# Generated at 2022-06-23 00:46:06.255941
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set([
        'system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:15.268565
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Info and caps.
    module = MagicMock()
    collected_facts = dict(ansible_facts=dict())
    module.get_bin_path.return_value = "a"
    module.run_command.return_value = (0, "Current:  =cap_chown,cap_dac_override,cap_fowner=ep", "")
    fact = SystemCapabilitiesFactCollector()
    fact.collect(module, collected_facts)
    assert 'system_capabilities' in collected_facts['ansible_facts']
    assert 'system_capabilities_enforced' in collected_facts['ansible_facts']

# Unit test when module.get_bin_path returns None

# Generated at 2022-06-23 00:46:24.099464
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts = {}
    collected_facts = {}
    capsh_path = "/path/to/capsh"
    rc = 0

# Generated at 2022-06-23 00:46:26.789875
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == "caps"
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:30.414707
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])


# Generated at 2022-06-23 00:46:31.054985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:46:34.087093
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:37.437105
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities','system_capabilities_enforced'])
    assert x._platform == 'All'
    assert x._file == None

# Generated at 2022-06-23 00:46:40.247389
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
  import ansible.module_utils.facts.collector
  assert isinstance(ansible.module_utils.facts.collector.SystemCapabilitiesFactCollector, object)

# Generated at 2022-06-23 00:46:41.992626
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Feel free to implement this unit test; and if you do, please remove this placeholder & marker.
    pass

# Generated at 2022-06-23 00:46:45.243400
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    facts_dict = SystemCapabilitiesFactCollector().collect(module, collected_facts)
    assert facts_dict['system_capabilities_enforced'] == 'NA'
    assert facts_dict['system_capabilities'] == []

# Generated at 2022-06-23 00:46:51.312907
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.collector import Collector
    class TestCollector(Collector):
        name = 'test'
        _fact_ids = set()
        def collect(self, module=None, collected_facts=None):
            return {}

    # NOTE: Monkey-patch the current working directory for testing
    def mock_pwd_getpwuid(uid):
        class struct_passwd(object):
            pw_name = 'testuser'
        return struct_passwd()
    # NOTE: Monkey-patch the current users login name
    def mock_getlogin():
        return 'testuser'
    # NOTE: Monkey-patch the getpwnam() function

# Generated at 2022-06-23 00:47:02.224230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import Capabilities

    class TestModule(object):
        def __init__(self):
            self.run_command_result = (0, Capabilities.fake_data, None)

        def run_command(self, args, **kwargs):
            return self.run_command_result

    test_module = TestModule()
    test_collector = SystemCapabilitiesFactCollector(test_module)

    capabilities_facts = test_collector.collect()

# Generated at 2022-06-23 00:47:05.739710
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])
    assert SystemCapabilitiesFactCollector.collect() == {}


# Generated at 2022-06-23 00:47:09.693045
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create system capabilities fact collector
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

    # get facts
    facts = obj.collect()
    assert 'system_capabilities' in facts
    assert 'system_capabilities_enforced' in facts

# Generated at 2022-06-23 00:47:21.108098
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: is it possible to mock-up module.run_command()? -akl

    module = None
    import mock
    with mock.patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
        # Mock data to be returned by get_bin_path
        mock_get_bin_path.return_value = '/sbin/capsh'

        # Get an instance of SystemCapabilitiesFactCollector
        test_obj = SystemCapabilitiesFactCollector()

        # Mock data returned by the 'capsh' command
        capsh_output = " \n \n Current:\n=ep \n \n \n \n"


# Generated at 2022-06-23 00:47:23.874055
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:32.450854
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Mock module inputs
    collected_facts = None

    # Mock class inputs
    capsh_path = '/path/to/capsh'
    capsh_cmd = [capsh_path, "--print"]
    capsh_out = '''
Current: = cap_setpcap,cap_net_admin+eip
Inheritable: = cap_setpcap,cap_net_admin+eip
Permitted:   = cap_setpcap,cap_net_admin+eip
Effective:   = cap_setpcap,cap_net_admin+eip
Bounding set =cap_setpcap,cap_net_admin+eip
Securebits:  00/0x0/1'b0
Capabilities: = cap_setpcap,cap_net_admin+eip
'''

    # Mock module class and