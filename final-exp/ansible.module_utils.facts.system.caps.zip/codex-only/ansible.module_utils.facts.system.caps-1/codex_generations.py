

# Generated at 2022-06-23 00:37:34.314866
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-23 00:37:35.991203
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert not SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-23 00:37:40.555804
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_test = SystemCapabilitiesFactCollector()
    assert my_test.name == 'caps'
    assert my_test._fact_ids == set(['system_capabilities',
                                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:42.078622
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'

# Generated at 2022-06-23 00:37:43.424790
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:37:52.235144
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.utils import ScriptRunner

    mock_module = ScriptRunner(args=dict(foo='bar'))
    # NOTE: untestable without a mock_module.run_command() replacement
    assert SystemCapabilitiesFactCollector.collect(mock_module) == dict()
    assert BaseFactCollector.collect(mock_module) == dict()

# Generated at 2022-06-23 00:37:59.170132
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    node = {
        'ansible_facts': {
            'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'sys_chroot', 'mknod', 'audit_write'],
            'system_capabilities_enforced': 'False'
        }
    }

    node_data = SystemCapabilitiesFactCollector.collect(None, node['ansible_facts'])
    assert node_data['system_capabilities'] == node['ansible_facts']['system_capabilities']
    assert node_data['system_capabilities_enforced'] == node['ansible_facts']['system_capabilities_enforced']

# Generated at 2022-06-23 00:38:01.532506
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    kollector = SystemCapabilitiesFactCollector()

    assert kollector.name == 'caps'
    assert kollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:38:02.530343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:38:06.182572
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector_obj = SystemCapabilitiesFactCollector()
    assert collector_obj.name == 'caps'
    assert collector_obj._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:08.313203
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None

# Generated at 2022-06-23 00:38:18.913976
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleDataCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import get_module_facts

    class AnsibleModuleStub:
        FAKE_RETURN_VALUES = {
            'run_command': (0, u'Current: =ep\n', u''),
            'get_bin_path': True,
        }

        def run_command(self, cmd, **kwargs):
            if cmd == ['/bin/capsh', '--print']:
                return self.FAKE_RETURN_VALUES['run_command']


# Generated at 2022-06-23 00:38:23.369063
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_gather_class = SystemCapabilitiesFactCollector
    assert fact_gather_class.name == 'caps'
    assert fact_gather_class._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}



# Generated at 2022-06-23 00:38:26.086088
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector()._fact_ids, set)


# Generated at 2022-06-23 00:38:37.388472
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(fact_collector, BaseFactCollector)
    assert isinstance(fact_collector, SystemCapabilitiesFactCollector)
    assert fact_collector.name == 'caps'

    def stub_ansible_module():
        class AnsibleModule(object):
            def get_bin_path(self, executable, required=False, opt_dirs=[]):
                fake_path = '/usr/bin/capsh'
                if os.path.exists(fake_path):
                    return fake_path
                return False


# Generated at 2022-06-23 00:38:40.701490
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.six import PY2, PY3
    import textwrap


# Generated at 2022-06-23 00:38:44.627875
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert isinstance(sut, SystemCapabilitiesFactCollector)
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:47.966722
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert facts._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:38:59.987101
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    # Create instance of SystemCapabilitiesFactCollector
    scfc_obj = get_collector_instance(SystemCapabilitiesFactCollector)

    # Create instance of Facts with dict() as membership
    facts_obj = Facts(dict())

    # Get collect method of SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:03.982887
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert 'system_capabilities' in collector._fact_ids
    assert 'system_capabilities_enforced' in collector._fact_ids



# Generated at 2022-06-23 00:39:16.974277
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mod = AnsibleModule()
    mod.get_bin_path = lambda _: '/path/to/capsh'

# Generated at 2022-06-23 00:39:19.353319
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'

# Generated at 2022-06-23 00:39:22.425405
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    try:
        facts_dict = SystemCapabilitiesFactCollector.collect(module)
    except SystemExit as e:
        assert False
    except Exception as e:
        assert False


# Generated at 2022-06-23 00:39:23.531167
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:39:25.305456
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.collect() == {}

# Generated at 2022-06-23 00:39:31.159706
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    capsh_path = ''
    capsh_path = '/usr/bin/capsh'
    capsh_path = '../ansible/module_utils/facts/capsh'
    assert(capsh_path)

    scfc = SystemCapabilitiesFactCollector()

    assert(scfc)
    assert(scfc.name == 'caps')
    assert(scfc._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced']))

# Generated at 2022-06-23 00:39:43.053938
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import capsh_output

    # Set up a module
    module = MockModule()
    # Set up a module
    module.run_command.return_value = (0, capsh_output, '')
    # Collect facts
    facts_dict = SystemCapabilitiesFactCollector().collect(module)
    # Validate facts

# Generated at 2022-06-23 00:39:46.929954
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert(collector.name == 'caps')
    assert(collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']))

# Generated at 2022-06-23 00:39:53.832098
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Constructor for SystemCapabilitiesFactCollector
    '''

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # Test whether the constructor creates a valid object
    assert system_capabilities_fact_collector
    # Test the value of 'name' attribute of object created
    assert system_capabilities_fact_collector.name == 'caps'


# Generated at 2022-06-23 00:40:05.162843
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fake_module = FakeModule()
    caps_collector = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:40:11.951703
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    module.run_command = Mock()


# Generated at 2022-06-23 00:40:15.631945
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == "caps"
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:19.018091
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    mock_module = sys.modules[__name__]
    caps_fact = SystemCapabilitiesFactCollector()
    caps_fact.collect(mock_module)['system_capabilities'] == '[]'

# Generated at 2022-06-23 00:40:30.974261
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # collect method args
    mod = None
    collected_facts = None

    # mock collect method return value
    expected_return_value = {'system_capabilities': [],
                             'system_capabilities_enforced': False}

    # mock run_command return value
    run_command_return_value = (0,
                                'Current: =ep',
                                '')

    # mock run_command object
    run_command_object = MagicMock()
    run_command_object.side_effect = run_command_return_value

    # mock get_bin_path method return value
    get_bin_path_return_value = 'capsh'

    # mock get_bin_path method
    get_bin_path_object = MagicMock()
    get_bin_path_object.side_effect = get_

# Generated at 2022-06-23 00:40:40.808828
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    import ansible_collections.ansible.community.tests.unit.module_utils.facts.collector.test_fixtures as test_fixture

    # Testing with non root user
    module_mock = test_fixture.ModuleMock()
    module_mock.params = {'gather_subset': ['all']}
    module_mock.run_command.return_value = (
        0,
        test_fixture.CAPSH_OUTPUT_NON_ROOT,
        ''
    )
    sys_caps_collector = SystemCapabilitiesFactCollector()

    result = sys_caps_collector.collect(module_mock)



# Generated at 2022-06-23 00:40:47.572256
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
	f = SystemCapabilitiesFactCollector()
	assert f.name == 'caps'
	assert f._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:49.828362
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x.alloc_method == 'set'

# Generated at 2022-06-23 00:40:50.489229
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:41:01.349525
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.system.capsh import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils.capsh import parse_caps_data
    from ansible.module_utils.facts.utils.capsh import get_caps_data
    from ansible.module_utils.facts.utils import ansible_get_os_name
    import ansible.module_utils.facts.collectors.system.capsh
    import tempfile
    import os

    # NOTE: Global override of class attribute system_capabilities_enforced -akl
    # NOTE: This is really just to avoid a deprecation warning
   

# Generated at 2022-06-23 00:41:04.607018
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    # Instance creation
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Testing name
    assert system_capabilities_fact_collector.name == 'caps'

# Generated at 2022-06-23 00:41:07.488911
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'

# Generated at 2022-06-23 00:41:15.744682
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import os
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty_capsh(self):
            test_module = FakeModule(self.tempdir)

# Generated at 2022-06-23 00:41:18.651752
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:20.468774
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capscollector = SystemCapabilitiesFactCollector()
    assert capscollector.name == 'caps'

# Generated at 2022-06-23 00:41:22.273289
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TEST: fact collection
    # TODO: make unit test
    pass

# Generated at 2022-06-23 00:41:24.176453
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.collect() == {}
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:33.975702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Check that SystemCapabilitiesFactCollector.collect() gives expected results
    """
    if not getattr(test_SystemCapabilitiesFactCollector_collect, 'uc', False):
        # Call once only to setup the test "universe"
        test_SystemCapabilitiesFactCollector_collect.uc = True
        import sys
        import tests.unit.module_utils.facts.collectors.system.system_capabilities
        globals().update(tests.unit.module_utils.facts.collectors.system.system_capabilities.__dict__)
        fake_module = FakeAnsibleModule(collector=SystemCapabilitiesFactCollector,
                                        collected_facts=None,
                                        get_bin_path_side_effect=lambda x: None)
        globals().update(fake_module.__dict__)

# Generated at 2022-06-23 00:41:45.380713
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.add_collector(SystemCapabilitiesFactCollector)
    import ansible.module_utils.facts.collector
    c = ansible.module_utils.facts.collector.FactsCollector()
    assert 'caps' in c.collectors
    assert 'caps' in c.collectors_by_type['local']
    import os
    if os.path.isfile('/sbin/capsh'):
        assert 'system_capabilities' in c.collect()
        assert 'system_capabilities_enforced' in c.collect()
    else:
        assert 'system_capabilities' not in c.collect()
        assert 'system_capabilities_enforced' not in c.collect()

# Generated at 2022-06-23 00:41:55.967703
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = get_module_mock()
    collector = SystemCapabilitiesFactCollector(module)

    facts = collector.collect()
    assert 'system_capabilities' in facts
    assert 'system_capabilities_enforced' in facts

    # Function get_bin_path(...) returns None because our mock does not
    # contain a list of paths.
    module = get_module_mock()
    module.get_bin_path = lambda *args, **kwargs: None
    collector = SystemCapabilitiesFactCollector(module)

    facts = collector.collect()
    assert 'system_capabilities' not in facts
    assert 'system_capabilities_enforced' not in facts

    # Function run_command(...) returns an error code of 1 because our mock
    # does not return proper values on calls to run_command.
    module = get

# Generated at 2022-06-23 00:41:58.767953
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps', \
        "Builder.name returns invalid value %s" % obj.name


# Generated at 2022-06-23 00:42:05.075733
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    r"""Unit test for SystemCapabilitiesFactCollector.

    >>> test1 = SystemCapabilitiesFactCollector()
    >>> test1.name
    'caps'
    >>> test1._fact_ids
    set(['system_capabilities_enforced', 'system_capabilities'])
    """


# Generated at 2022-06-23 00:42:15.838583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    import os
    import json
    import tempfile
    import sys
    import shutil
    import pytest
    import textwrap

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import FactCollector

    # Mock 'call'
    class MockSubprocess:
        def __init__(self):
            self.returncode = 0

        def check_output(self, cmd, errors='strict'):
            """Returns a pre-baked response for the requested command"""


# Generated at 2022-06-23 00:42:23.514815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import unittest.mock as mock
    mock_ansible_module = mock.MagicMock()
    mock_ansible_module.run_command.return_value = (0, """Current: = cap_setuid+ep
Bounding set =cap_setgid,cap_setuid
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)

  secure-no-suid-fixup: no (unlocked)

  secure-keep-caps: no (unlocked)
If the application has not dropped permissions after the execve, then you may
see the effective capabilities here.
""", '')
    test_collector = SystemCapabilitiesFactCollector()
    test_collector.collect(module=mock_ansible_module)

    # NOTE: Should have tried to use module.get

# Generated at 2022-06-23 00:42:25.868866
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()

    # assert
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:34.324483
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.common._collections_compat import Mapping
    collector.collectors['SystemCapabilitiesFactCollector'] = SystemCapabilitiesFactCollector
    BaseFactCollector._collectors['SystemCapabilitiesFactCollector'] = SystemCapabilitiesFactCollector
    o = SystemCapabilitiesFactCollector()
    facts = o.collect()
    assert isinstance(facts, Mapping)

# Generated at 2022-06-23 00:42:38.530325
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_coll = SystemCapabilitiesFactCollector()
    assert fact_coll.name == 'caps'
    assert fact_coll._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:45.053559
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock(
        get_bin_path=Mock(return_value=True)
    )
    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    expected_result = {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA'
    }
    ac = SystemCapabilitiesFactCollector()
    assert ac.collect(module) == expected_result

# Generated at 2022-06-23 00:42:49.893062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_capabilities
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from pytest_ansible.module_utils import stubs

    def get_bin_path(name, opt_dirs=[]):
        return ["/bin/capsh"]


# Generated at 2022-06-23 00:42:52.346438
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj.collect() == {}

# Generated at 2022-06-23 00:42:57.773562
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector to make sure it's an instance of
    BaseFactCollector class and have the correct facts.
    """
    system_capabilities_fact_collection = SystemCapabilitiesFactCollector()

    assert isinstance(system_capabilities_fact_collection, BaseFactCollector)
    assert system_capabilities_fact_collection.name == 'caps'
    assert system_capabilities_fact_collection._fact_ids == set(['system_capabilities',
                                                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:01.427896
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:05.799674
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    module = mock.Mock()
    collector = SystemCapabilitiesFactCollector(module=module)
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:13.981645
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Test if the facts as returned by SystemCapabilitiesFactCollector.collect method.
    Test fixture of ansible/ansible-modules-core/system/setup/collector/system_capabilities.py
    """
    # prepare the test:
    import os
    import subprocess
    import tempfile
    import unittest
    from mock import patch

    temp_dir = tempfile.mkdtemp()
    fake_capsh_path = os.path.join(temp_dir, 'capsh')

    def run_command_mock(args, **kwargs):
        """Mock of BaseModule.run_command()
        """
        return (0, 'Current: =ep\nBounding set =cap_sys_admin,cap_sys_chroot+eip', '')


# Generated at 2022-06-23 00:43:17.874110
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:22.832448
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    factCollector = SystemCapabilitiesFactCollector()
    assert factCollector.name == 'caps'
    assert factCollector._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])
    assert factCollector._platform == None
    assert factCollector._subplatform == None
    assert factCollector._distribution == None

# Generated at 2022-06-23 00:43:34.267033
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:43:38.024965
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ test_SystemCapabilitiesFactCollector: instantiate and check instance attributes """

    c = SystemCapabilitiesFactCollector()
    assert(c.name == 'caps')
    assert(set(c._fact_ids) == set(['system_capabilities',
                                    'system_capabilities_enforced']))

# Generated at 2022-06-23 00:43:42.443489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test the method collect of class SystemCapabilitiesFactCollector.
    """
    caps_fact_collector = SystemCapabilitiesFactCollector
    caps_fact_collector.collect(caps_fact_collector)


# Generated at 2022-06-23 00:43:44.455407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: FIXME: create unit test(s) for this fact
    pass

# Generated at 2022-06-23 00:43:47.790867
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:43:57.307247
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is really testing a private method get_caps_data()
    #       as it's the only 'mockable' unit. The other parts are OS specific.
    import os
    import mock
    import platform
    import re

    # NOTE: those two are created by collect()
    #       and are used by the test to check if the mock was called correctly
    capsh_path = None
    rc = 0
    out = None
    err = None

    def run_command(args, **kwargs):
        global capsh_path
        global rc
        global out
        global err
        capsh_path = args[0]
        rc = 0
        out = None
        err = None
        if capsh_path != '/usr/bin/capsh':
            rc = 1

# Generated at 2022-06-23 00:44:04.233727
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import yaml
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    # initialize the fact collector instance
    fact_collector = SystemCapabilitiesFactCollector()

    # initialize the AnsibleModule mock
    module = AnsibleModule()

    # execute the collect method
    collected_facts = fact_collector.collect(module, None)

    # try to convert the collected facts to a dictionary
    collected_facts_dict = dict((k, v) for k, v in collected_facts.items())
    yaml.dump(collected_facts_dict, sys.stdout)


# Generated at 2022-06-23 00:44:13.727849
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Check for 'capsh' installed
    capsh_path = '/usr/bin/capsh'
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import Fetch
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    default_collectors['unknown'].append(SystemCapabilitiesFactCollector)
    scfc = SystemCapabilitiesFactCollector(Fetch())
    module = scfc.module
    module.run_command = MagicMock(return_value=(0, capsh_output, ''))
    module.get_bin_path = MagicMock(return_value=capsh_path)

# Generated at 2022-06-23 00:44:15.285980
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: replace with unit test
    pass

# Generated at 2022-06-23 00:44:25.454719
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from collections import namedtuple
    import json

    # Create a mock ansible module object
    class MockAnsibleModule:

        def __init__(self, *args, **kwargs):
            self.params = {}
            self.facts = {}

        def get_bin_path(self, *args, **kwargs):
            return "/bin/capsh"

        def run_command(self, *args, **kwargs):
            return (0, "Current: =ep\nSecurebits: 00/0x0/1'b0 secure-noroot, secure-no-suid\n secure-keep-caps", "")
    module = MockAnsibleModule()

    collected_facts = {}
    fact_collector = SystemCap

# Generated at 2022-06-23 00:44:28.063383
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:32.218478
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    caps = SystemCapabilitiesFactCollector()
    assert caps.name == 'caps'
    assert caps._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:44:42.005623
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: THIS WILL NOT WORK. IT IS FOR TESTING THE TEST FRAMEWORK.
    # Mock module to return test values
    class TestModule():
        def __init__(self):
            self.run_command_results = []
            self.run_command_results.append(return_value(0,'Current: =ep',''))
            self.run_command_results.append(return_value(0,'Current: =ep',''))
            self.run_command_results.append(return_value(0,'Current: =ep',''))
            self.run_command_results.append(return_value(0,'Current: =ep',''))
            self.run_command_results.append(return_value(0,'Current: =ep',''))

# Generated at 2022-06-23 00:44:50.580609
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import unittest
    import sys
    from ansible.module_utils.facts import collector

    facts_module_mock = unittest.mock.MagicMock()
    fact_collector = collector.BaseFactCollector(
        'caps',
        set(['system_capabilities', 'system_capabilities_enforced']),
        facts_module_mock
    )
    assert isinstance(fact_collector, collector.BaseFactCollector)
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert fact_collector._module == facts_module_mock


# Generated at 2022-06-23 00:44:55.882929
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_name = 'caps'
    fact_ids = set(['system_capabilities',
                    'system_capabilities_enforced'])
    result = SystemCapabilitiesFactCollector.collect(None)
    assert result == {}
    assert fact_name == SystemCapabilitiesFactCollector.name
    assert fact_ids == SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-23 00:44:58.242513
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict

# Generated at 2022-06-23 00:45:08.580758
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    fake_module = FakeModule()
    # Test default collect
    result = fact_collector.collect(module = fake_module)
    fake_module.fail_json.assert_called()
    assert 'system_capabilities' not in result
    assert 'system_capabilities_enforced' not in result

    # Test Successful capsh --print

# Generated at 2022-06-23 00:45:17.056243
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Import of module needed for mocking
    import ansible.modules.system.capabilities as capabilities
    # Import of base module needed for mocking
    import ansible.module_utils.facts.collector as collector

    # Instantiation of class SystemCapabilitiesFactCollector
    collecter = collector.SystemCapabilitiesFactCollector()

    # Mocking of method get_bin_path of class capabilities.AnsibleModule
    capabilities.AnsibleModule.get_bin_path = lambda x, y: 'capsh_path'

    # Mocking of method run_command of class capabilities.AnsibleModule
    capabilities.AnsibleModule.run_command = lambda x, y, z: (1, 'Current: =ep\nBounding set =CAP_AUDIT_CONTROL,CAP_KILL,\n', 'Error')


# Generated at 2022-06-23 00:45:21.287094
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: no __init__ for collector, use base class constructor
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:25.406907
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:33.572673
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = MagicMock()
    caps_path = '/usr/bin/capsh'
    module.get_bin_path.return_value = caps_path

# Generated at 2022-06-23 00:45:47.077262
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def run_command(args, **kwargs):
        module = kwargs.get('module', None)
        capsh_path = module.get_bin_path('capsh')

# Generated at 2022-06-23 00:45:57.654079
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorStorage

    # NOTE: Mock module/run_command() return values/check if called/check __salt__ usage...
    module = mock.MagicMock()
    module.get_bin_path.return_value = True
    module.run_command.return_value = 0, '', ''
    collected_facts = CollectorStorage()
    # NOTE: Create instance of the object SystemCapabilitiesFactCollector
    caps_fact_collector = SystemCapabilitiesFactCollector()

    # Check if method collect returns a dict
    assert isinstance(caps_fact_collector.collect(module=module, collected_facts=collected_facts), dict)

# Generated at 2022-06-23 00:46:02.391197
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh = SystemCapabilitiesFactCollector()
    name = capsh.name
    fact_ids = capsh._fact_ids
    assert name == 'caps'
    assert 'system_capabilities' in fact_ids
    assert 'system_capabilities_enforced' in fact_ids



# Generated at 2022-06-23 00:46:12.962614
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mocked module
    mock_module = MockAnsibleModule()

    # Create a mocked AnsibleModule object
    mock_ansible_module = MockAnsibleModule()

    # Create a SystemCapabilitiesFactCollector object
    sut = SystemCapabilitiesFactCollector()

    # Create a mock returned value for module.run_command
    # See 'system_capabilities_enforced = True' below
    mock_rc = 0

# Generated at 2022-06-23 00:46:15.737925
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:46:16.989755
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-23 00:46:19.141505
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scf = SystemCapabilitiesFactCollector()
    assert scf.name == 'caps'

# Generated at 2022-06-23 00:46:21.862264
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:46:32.524236
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ast
    import json
    import os
    import sys
    import tempfile
    module = mock.Mock()
    capsh_path = os.path.join('test', 'output', 'capsh_out.txt')
    module.run_command.return_value = (0, open(capsh_path).read(), '')
    module.get_bin_path.return_value = '/bin/capsh'
    module.params = {'async_dir': '/tmp', 'async_timeout': 60}
    fact_collector = SystemCapabilitiesFactCollector(module=module)
    collected_facts = fact_collector.collect(module=module)

# Generated at 2022-06-23 00:46:35.588917
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert(set(collector._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced']))
    assert(collector.name == 'caps')

# Generated at 2022-06-23 00:46:40.873646
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: I am not sure if this is the right way to do this test, but
    # I tried for a little while and gave up.  -akl
    module = None
    collected_facts = None
    s = SystemCapabilitiesFactCollector()
    assert s.collect(module, collected_facts) == {}

# Generated at 2022-06-23 00:46:41.523450
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:46:44.264559
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:54.049637
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    # NOTE: 'capsh --print' mocks
    rc_true = 0

# Generated at 2022-06-23 00:46:59.231080
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps', \
        "SystemCapabilitiesFactCollector() instantiation test failed"
    assert fact_collector.fact_ids == frozenset(['system_capabilities', 'system_capabilities_enforced']), \
        "SystemCapabilitiesFactCollector() instantiation test failed - fact_ids"

# Generated at 2022-06-23 00:47:08.420039
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create instance of class SystemCapabilitiesFactCollector
    sut = SystemCapabilitiesFactCollector()

    # create a dummy module
    module = MockModule()

    # populate module instance with capsh output
    sut.get_caps_data(module)

    # call method collect
    results = sut.collect(module)

    # assert that the method collect returns a dictionary
    assert isinstance(results, dict)
    assert 'system_capabilities_enforced' in results
    assert isinstance(results['system_capabilities_enforced'], str)
    assert results['system_capabilities_enforced'] == 'True'
    assert 'system_capabilities' in results
    assert isinstance(results['system_capabilities'], list)

# Generated at 2022-06-23 00:47:09.797897
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:47:11.627975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    No test implementation yet.
    '''

# Generated at 2022-06-23 00:47:22.479083
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes

    class MyPlatform(object):
        DISTRIBUTION = "CentOS"
        DISTRIBUTION_MAJOR_VERSION = "7"
        DISTRIBUTION_VERSION = "7.0.1406"
        DISTRIBUTION_RELEASE = "el7.0.1406"
        KERNEL = "Linux"
        KERNEL_VERSION = "3.13.6-200.fc20.x86_64"
        SYSTEM = "Linux"
        MACHINE = "x86_64"
        FILE_SYSTEM_ENCODING = 'UTF-8'
        UNAME_SYSNAME = 'Linux'
        UNAME_RELEASE

# Generated at 2022-06-23 00:47:26.923390
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    def no_get_bin_path(path):
        return None
    test_module = FakeModule()
    test_module.get_bin_path = no_get_bin_path
    actual = SystemCapabilitiesFactCollector(test_module).collect()
    assert actual == {}


# Generated at 2022-06-23 00:47:28.040919
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:47:33.204782
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    utf = SystemCapabilitiesFactCollector()
    assert utf.name == 'caps'
    assert utf._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])
    # TODO: assert utf._platform == 'all'