

# Generated at 2022-06-23 00:37:37.125039
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh = SystemCapabilitiesFactCollector()
    assert capsh.name == 'caps'
    assert capsh._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])


# Generated at 2022-06-23 00:37:44.019963
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_instance = SystemCapabilitiesFactCollector()
    assert len(test_instance.__dict__) == 3
    assert test_instance.__dict__["name"] == "caps"
    assert len(test_instance.__dict__["_fact_ids"]) == 2
    assert 'system_capabilities' in test_instance.__dict__["_fact_ids"]
    assert 'system_capabilities_enforced' in test_instance.__dict__["_fact_ids"]


# Generated at 2022-06-23 00:37:52.767942
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.system
    import ansible.module_utils.facts.system.distribution

    def get_bin_path(name):
        return None

    def run_command(name, errors='surrogate_then_replace'):
        return [0, 'Current: =ep bset', '']

    module_mock = ansible.module_utils.facts.system.capabilities.AnsibleModule
    module_mock.get_bin_path = get_bin_path
    module_mock.run_command = run_command

    _capability = ansible.module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:37:57.854753
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:38:06.499232
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # setup
    def run_command(cmd, errors='surrogate_then_replace'):
        return (0, 'Some: line\nCurrent: =ep  CapInh:  CapEff:  CapPrm:  CapBnd:   chown,dac_override,fowner,fsetid,kill,setgid,setuid,net_bind_service,net_raw,sys_chroot,mknod,audit_write,setfcap\nCapEff:   \n', '')

    def get_bin_path(cmd):
        return '/usr/bin/capsh'

    module = Mock()
    module.run_command = Mock(side_effect=run_command)
    module.get_bin_path = Mock(side_effect=get_bin_path)
    collected_facts = dict

# Generated at 2022-06-23 00:38:10.041494
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scf = SystemCapabilitiesFactCollector()
    assert scf.name == 'caps'
    assert scf._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:38:12.573393
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert fact_ids == {'system_capabilities','system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:13.302009
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("Nothing to unit test for now")

# Generated at 2022-06-23 00:38:24.420447
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = {}
    module = None
    capsh_path = "capsh_path"
    module.get_bin_path('capsh')

    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')

    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            line = 'Current:=ep'
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'
                enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

# Generated at 2022-06-23 00:38:25.924655
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'



# Generated at 2022-06-23 00:38:36.881272
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector

    # Setup test data.
    module = AnsibleModule()
    Collector._instance = None
    loaded_fact_collectors = Collector.get_fact_collectors()

    # Test method collect with capsh data.

# Generated at 2022-06-23 00:38:47.545778
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None

# Generated at 2022-06-23 00:38:58.675489
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import mock
    import json
    def get_bin_path(path, required=False):
        return True

    def run_command(cmd, errors='surrogate_then_replace'):
        return 0, 'Current: =ep', ''

    with mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.collect'):
        with mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.__init__') as mock_BaseFactCollector_init:
            mock_BaseFactCollector_init.return_value = None

# Generated at 2022-06-23 00:39:02.138761
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:04.180896
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert (collector.collect() == {})


# Generated at 2022-06-23 00:39:17.107877
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:29.502621
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import tempfile
    import os

    capsh_path = tempfile.mkdtemp(prefix='ansible_system_capabilities_facts_capsh_test')
    capsh_filepath = os.path.join(capsh_path, 'capsh')


# Generated at 2022-06-23 00:39:30.508786
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:39:38.317335
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])

# For mocking of run_command during unit tests and mocking an instance of class SystemCapabilitiesFactCollector.
# This function connects the return values of the mocked run_command to "collect()" method of class
# SystemCapabilitiesFactCollector.

# Generated at 2022-06-23 00:39:49.624778
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (0,
                            'Current: =eip\nBounding set =eip\nSecurebits: 00/0x0/1\nsecure-noroot: no (unlocked)\nsecure-no-suid-fixup: no (unlocked)\nsecure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)',
                            '')

    facts = SystemCapabilitiesFactCollector()

    # NOTE: we use 'set' method to add new data instead of direct
    # assignment to '_collected_facts' because assignment triggers
    # call to '_flush' method that tries to remove duplicate facts

# Generated at 2022-06-23 00:39:54.390485
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    collected_facts = {}
    SystemCapabilitiesFactCollector(module, collected_facts).collect()
    assert 'system_capabilities_enforced' in collected_facts
    assert 'system_capabilities' in collected_facts

# Generated at 2022-06-23 00:39:58.084722
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    obj = SystemCapabilitiesFactCollector(module)
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:09.052494
# Unit test for constructor of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:40:16.160737
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    a1 = dict(enforced_caps=set(['cap_net_raw', 'cap_kill', 'cap_setuid']))
    t = SystemCapabilitiesFactCollector()
    retval = t.collect(module=ModuleStub(a1))
    assert retval['system_capabilities_enforced'] == 'True'
    assert retval['system_capabilities'] == ['cap_net_raw', 'cap_kill', 'cap_setuid']



# Generated at 2022-06-23 00:40:19.541193
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:25.135967
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:40:26.596243
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:40:37.301286
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class DummyModule():
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            return self.path

    module = DummyModule('/usr/bin/capsh')

    collector = SystemCapabilitiesFactCollector()

    # Test the constructor
    try:
        assert collector is not None
    except Exception:
        pytest.fail("Failed to create SystemCapabilitiesFactCollector")

    # Test the collect() method
    module = DummyModule('/usr/bin/capsh')
    facts_dict = collector.collect(module)
    try:
        assert 'system_capabilities' in facts_dict
        assert 'system_capabilities_enforced' in facts_dict
    except:
        pytest.fail("Failed to collect caps facts")

# Generated at 2022-06-23 00:40:52.460123
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import os
    from ansible.module_utils.facts.collector import FactsCollector

    c = FactsCollector()
    c.collector['system_capabilities'] = SystemCapabilitiesFactCollector()

    os.environ['PATH'] += ':/usr/sbin'
    facts = c.get_facts(module=None, collected_facts=None)
    assert 'system_capabilities' in facts
    assert 'system_capabilities_enforced' in facts

    from ansible.module_utils._text import to_text
    facts['system_capabilities'] = to_text(facts['system_capabilities'])
    facts['system_capabilities_enforced'] = to_text(facts['system_capabilities_enforced'])
    assert '=' not in facts['system_capabilities']

# Generated at 2022-06-23 00:40:54.172021
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = {}
    s = SystemCapabilitiesFactCollector()
    return s


# Generated at 2022-06-23 00:41:05.117024
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()

# Generated at 2022-06-23 00:41:14.915202
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import get_all_facts

    class TestModuleStub(AnsibleModuleStub):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, program):
            return './capsh'

        def run_command(self, args, errors='stop'):
            self.run_command_calls.append(args)
            return 0, "Current: =ep", ""

    module = TestModuleStub()

    # Run fact gathering and validate results.
    fact_collector = SystemCapabilitiesFactCollector(module=module)

# Generated at 2022-06-23 00:41:26.255006
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock up an AnsibleModule
    import ansible.module_utils.facts.collectors.system.caps as caps

    class Mock_AnsibleModule(object):
        def get_bin_path(self, command):
            return command

    class Mock_AnsibleModule_run_command_split(object):
        def __init__(self, out):
            self.out = out

        def splitlines(self):
            return self.out


# Generated at 2022-06-23 00:41:27.247973
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: implement this
    pass

# Generated at 2022-06-23 00:41:36.222815
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_data = '''
        Current: = cap_setfcap+ep
        Bounding set =cap_setfcap
        Securebits: 00/0x0/1'b0
        secure-noroot: no (unlocked)
        secure-no-suid-fixup: no (unlocked)
        secure-keep-caps: no (unlocked)
        uid=0(root)
        gid=0(root)
        groups=0(root),1(bin),2(daemon),3(sys),4(adm),6(disk),10(wheel)
        capabilities=cap_setfcap+ep
        audit_enabled=1
        old_enforce=0
    '''
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert 'system_capabilities'

# Generated at 2022-06-23 00:41:39.927625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # check for availability of capsh
    # return an empty list if not available
    # TODO: TRY IF CAPSH IS AVAILABLE
    pass

# TODO: Test with capsh

# Generated at 2022-06-23 00:41:50.480672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.linux.capabilities import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts
    import ansible.module_utils.six
    import ansible.module_utils

    # Define the necessary mocks
    class ModuleUtilsFactsMock(ansible.module_utils.facts.collectors.base.BaseFactCollector):
        @staticmethod
        def get_bin_path(name, opt_dirs=None):
            return '/bin/capsh'


# Generated at 2022-06-23 00:41:59.088864
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collectors import get_collector_instance
    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command
        def run_command(args, errors='surrogate_then_replace'):
            return 1, 'Current: = cap_chown,cap_dac_override+eip cap_fowner+ep cap_fsetid+ep', ''       
        def get_bin_path(self, arg):
            return 'capsh'
    mock_module = MockModule()
    mock_module_instance = MockModule()
    collector = get_collector_

# Generated at 2022-06-23 00:42:00.665705
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:08.918588
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize a SystemCapabilitiesFactCollector object
    #
    # Note: Define a mock output for the command "capsh --print" as
    #       this command can not be run as part of unit test.
    #
    fact_collector = SystemCapabilitiesFactCollector()
    fact_collector.ansible_module = mock.Mock()
    fact_collector.ansible_module.run_command.return_value = (0, "Current: =ep", "")

    # Invoke the collect method of the object to collect facts
    fact_collector.collect()

    # Assert the collected facts with expected values for
    # 'system_capabilities_enforced' and 'system_capabilities'
    assert fact_collector.facts['system_capabilities_enforced'] == 'False'
    assert fact_collector

# Generated at 2022-06-23 00:42:10.596371
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'


# Generated at 2022-06-23 00:42:12.351172
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name  == 'caps'

# Generated at 2022-06-23 00:42:20.690177
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fake_module = ['capsh', '--print']

# Generated at 2022-06-23 00:42:26.553937
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_object = SystemCapabilitiesFactCollector()
    assert isinstance(test_object, SystemCapabilitiesFactCollector)
    assert isinstance(test_object.name, str)
    assert isinstance(test_object._fact_ids, set)
    assert 'system_capabilities' in test_object._fact_ids
    assert 'system_capabilities_enforced' in test_object._fact_ids
    assert isinstance(test_object.collect(), dict)

# Generated at 2022-06-23 00:42:29.124383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = SystemCapabilitiesFactCollector()
    d = m.collect()
    assert 'system_capabilities' in d
    assert 'system_capabilities_enforced' in d

# Generated at 2022-06-23 00:42:31.920117
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert set(c._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:43.785370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts import assertion
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_mock
    import ansible.module_utils.facts.system.caps

    def mock_run_command(self, *args, **kwargs):
        return test_SystemCapabilitiesFactCollector_collect_mock

    SystemCapabilitiesFactCollector.get_caps_data = mock_run_command
    SystemCapabilitiesFactCollector.parse_caps_data = mock_run_command

    caps = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:42:48.058736
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:53.183953
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.capabilities.system_capabilities import SystemCapabilitiesFactCollector

    SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in SystemCapabilitiesFactCollector.collect()
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector.collect()

# Generated at 2022-06-23 00:42:56.206890
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:57.236451
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert 'caps' == SystemCapabilitiesFactCollector().name

# Generated at 2022-06-23 00:43:08.440630
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = 'path_to_capsh'

    # pylint: disable=protected-access,unused-variable
    test_mock = SystemCapabilitiesFactCollector._test_mock

    # NOTE: input data -akl

# Generated at 2022-06-23 00:43:16.981640
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible
    import ansible.module_utils.facts.collector

    ansible_version = ansible.__version__
    ansible_version_parts = tuple([int(i) for i in ansible_version.split('.')])
    if ansible_version_parts >= (2, 6):
        ansible_module_utils_facts_base_dir = ansible.module_utils.facts.collector.__path__[0]
    else:
        ansible_module_utils_facts_base_dir = ansible.module_utils.facts.__path__[0]


    # NOTE: Use mock module if available, otherwise, write pytest monkeypatches -akl

# Generated at 2022-06-23 00:43:20.294647
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector_obj = SystemCapabilitiesFactCollector()
    assert fact_collector_obj.name == 'caps'
    assert fact_collector_obj._fact_ids == set(['system_capabilities',
                                                'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:21.290351
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:43:22.269047
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:43:25.759701
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert set(s.FACT_NAMES) == set(['system_capabilities',
                                     'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:37.280738
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # TODO: Fix
    import unittest
    import logging
    import mock

    # sample_module has a requirement for capsh
    sample_module = mock.Mock()
    sample_module.get_bin_path.return_value = '/usr/bin/capsh'
    sample_module.run_command.return_value = (0,
                                           "Current: =ep\n" +
                                           "Bounding set =ep\n" +
                                           "ep\n" +
                                           "cap_net_bind_service,cap_net_raw+eip",
                                           '')

    # create an instance of class to be tested
    fact_collector = SystemCapabilitiesFactCollector()
    # test the constructor
    assert fact_collector.name == 'caps'

# Generated at 2022-06-23 00:43:38.958163
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Verify that class is not empty
    obj = SystemCapabilitiesFactCollector()
    assert obj

# Generated at 2022-06-23 00:43:46.096392
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = MockModule()
    test_module.get_bin_path.return_value = '/path/to/capsh'
    test_module.run_command.return_value = (0, 'Current: =ep', None)
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(test_module)
    assert facts == {'system_capabilities': [],
                     'system_capabilities_enforced': 'False'}

# Generated at 2022-06-23 00:43:49.544480
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector(None)._fact_ids == {'system_capabilities','system_capabilities_enforced'}
    assert SystemCapabilitiesFactCollector(None).name == 'caps'


# Generated at 2022-06-23 00:43:50.956522
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-23 00:44:01.838476
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = '/usr/bin/capsh'
    capsh_rc = 0
    capsh_out = '''
    Current: =ep
    Bounding set =ep
    Securebits: 00/0x0/1'b0
    secure-noroot: no (unlocked)
    secure-no-suid-fixup: no (unlocked)
    secure-keep-caps: no (unlocked)
    uid=0(root)
    gid=0(root)
    groups=0(root)
    '''
    capsh_err = ''
    module_mock = Mock()
    module_mock.get_bin_path.return_value = capsh_path

# Generated at 2022-06-23 00:44:12.220810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class DummyModule:
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self, args, **kwargs):
            return (self.rc, self.stdout, self.stderr)

        def get_bin_path(self, arg):
            return '/bin/capsh'



# Generated at 2022-06-23 00:44:12.876151
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:44:16.575574
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector()
    assert a


test_cases = [
    {'input': {},
     'output': ('NA', 'NA')
     }
]



# Generated at 2022-06-23 00:44:19.417063
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    f = SystemCapabilitiesFactCollector()
    assert f.name == 'caps'
    assert f._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:44:28.487154
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts import DefaultTimeout
    from ansible.module_utils.facts import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_text
    import os
    import json
    import ansible.module_utils.facts.system.caps as caps_module

    mock_module = caps_module.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # load data from fixture
    mock_caps_output = get_file_content(os.path.join('fixtures', 'fact', 'system_capabilities.out'))

# Generated at 2022-06-23 00:44:30.908905
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-23 00:44:33.226788
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # arrange
    factCollector = SystemCapabilitiesFactCollector()

    # act
    pass

    # assert

# Generated at 2022-06-23 00:44:42.524255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub, get_all_collector_classes
    
    module = AnsibleModuleStub()

# Generated at 2022-06-23 00:44:44.806924
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert set(SystemCapabilitiesFactCollector.collect()) == set({'system_capabilities_enforced': 'NA', 'system_capabilities': []})

# Generated at 2022-06-23 00:44:53.701288
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    
    # Get the content of test file
    with open('ansible/modules/system/facts/collector/test_data/test_capsh_output.txt', 'r') as f:
        content = f.read()

    # Create a mock module
    module = Mock()
    # Create a mock run_command
    module.run_command = Mock(return_value=(0, content, ''))
    module.get_bin_path = Mock(return_value='/bin/capsh')

    # Test method collect()
    system_capabilities_fact_collector.collect(module)
    system_capabilities_fact_collector.collect(module)
    system_capabilities_fact_

# Generated at 2022-06-23 00:44:56.884883
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    fc = SystemCapabilitiesFactCollector()
    fc.collect(module, None)


# Generated at 2022-06-23 00:45:02.129157
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: replace with 'assert' statemenets -akl
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:45:12.526588
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Define a test_module
    test_module = AnsibleModule(argument_spec={})

    # Get a SystemCapabilitiesFactCollector
    s = SystemCapabilitiesFactCollector()

    # Do not test if not capsh_path
    if s.capsh_path:
        # Init test_module.run_command
        test_module.run_command = mock.Mock(return_value=(0,'Current: =ep','hello'))
        # Do not test if no system_capabilities
        if 'system_capabilities' in test_module.__dict__:
            # Collect facts
            facts_dict = s.collect(module=test_module)

            # Assert list system_capabilities is empty
            assert isinstance(facts_dict['system_capabilities'], list)

# Generated at 2022-06-23 00:45:15.660160
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_obj = SystemCapabilitiesFactCollector()
    assert(my_obj.name == "caps")
    assert(my_obj is not None)

# Generated at 2022-06-23 00:45:19.144361
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()

    assert(instance.name == 'caps')
    assert(instance._fact_ids == {'system_capabilities', 'system_capabilities_enforced'})


# Generated at 2022-06-23 00:45:20.122404
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capabilities = SystemCapabilitiesFactCollector()
    assert capabilities.name == 'caps'

# Generated at 2022-06-23 00:45:28.395617
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    mock_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    mock_module.run_command = lambda command, errors='surrogate_then_replace': (0, '', '')
    collector.FACT_CACHE = {}
    SystemCapabilitiesFactCollector.collect(mock_module)
    import ansible.module_utils.facts.collector.system.system_capabilities

# Generated at 2022-06-23 00:45:36.096120
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MagicMock()
    mock_module.run_command.return_value = 0, ('''Current: = cap_setuid,cap_setgid,cap_net_bind_service,cap_audit_write,cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setfcap+eip
Bounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setfcap
Securebits: 00/0x0/1'''), ''

    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=mock_module, collected_facts=None)

    assert 'system_capabilities' in facts

# Generated at 2022-06-23 00:45:48.233860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector.system

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class Mock_run_command(object):
        def __init__(self, module, cmd, errors='surrogate_then_replace'):
            self.module = module
            self.cmd = cmd
            self.errors = errors
            self.rc = 0
            self.stdout = StringIO('Current: =ep')
            self.stderr = StringIO()

        def __call__(self):
            return (self.rc, self.stdout.getvalue(), self.stderr.getvalue())


# Generated at 2022-06-23 00:45:59.717145
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def mock_run_command(self, cmd, **kwargs):
        class mock_cmd():
            def __init__(self, args, kwargs):
                self.args = args

# Generated at 2022-06-23 00:46:04.536499
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test creation of SystemCapabilitiesFactCollector."""
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:13.493675
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    import unittest
    from ansible.module_utils.facts import collector
    fake_module = FakeModule()
    sut = collector.get_collector(SystemCapabilitiesFactCollector.name, fake_module)
    actual_result = sut.collect(fake_module)
    test_string = 'system_capabilities = %s' % FakeModule.system_capability
    assert test_string in fake_module.output
    test_string = 'system_capabilities_enforced = %s' % FakeModule.system_capability_enforced
    assert test_string in fake_module.output



# Generated at 2022-06-23 00:46:16.989814
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:23.413881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # module is not available in this context
    # instead, build a small object and pass it
    class MockModule(object):
        def __init__():
            self.run_command = lambda cmd, errors: (0, 'Current: =ep', '')

    collected_facts = {}
    collector = SystemCapabilitiesFactCollector()
    collector.collect(MockModule(), collected_facts)
    # check enforced
    assert collected_facts['system_capabilities_enforced'] == 'False'
    # check supported
    assert collected_facts['system_capabilities'] == []

# Generated at 2022-06-23 00:46:24.934064
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:46:32.381010
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Run unit test for method collect of class SystemCapabilitiesFactCollector
    Paramaters:
    module: ansible.module_utils.basic.AnsibleModule
    '''
    module = 'ansible.module_utils.basic.AnsibleModule'
    capsh_path = 'capsh_path'
    collected_facts ={}
    collector = SystemCapabilitiesFactCollector
    results = {'system_capabilities_enforced': 'True', 'system_capabilities': ['foo']}


# Generated at 2022-06-23 00:46:34.316660
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    # TODO - more tests here...


# Generated at 2022-06-23 00:46:34.910393
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-23 00:46:38.963735
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:42.186135
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cls = SystemCapabilitiesFactCollector()
    assert cls.name == 'caps'
    assert cls._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert isinstance(cls, BaseFactCollector)

# Generated at 2022-06-23 00:46:46.794289
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:48.982090
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:54.718769
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    fact_collector_obj = SystemCapabilitiesFactCollector()
    result = fact_collector_obj.collect(module)
    assert result == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    # TODO: Write more tests for other scenarios
    # TODO: Write integration tests

# Generated at 2022-06-23 00:46:58.188772
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(('system_capabilities', 'system_capabilities_enforced'))

# Generated at 2022-06-23 00:46:59.968481
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    temp_collector = SystemCapabilitiesFactCollector()
    assert type(temp_collector) == SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:47:08.969044
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class Module(object):
        def __init__(self):
            self.params = {'capabilities': []}
            self.facts = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

        def get_bin_path(self, path, opt_dirs=[]):
            self.facts['system_bin_path'] = '/bin/capsh'
            return self.facts['system_bin_path']

        def run_command(self, args, errors='surrogate_then_replace'):
            self.facts['system_capabilities'].append('cap_chown')
            self.facts['system_capabilities_enforced'] = 'True'
            return 0, 'Current: =ep Bounding set =cap_chown', ''

    module = Module()
    SystemCapabilitiesFact

# Generated at 2022-06-23 00:47:12.910600
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_system_caps = SystemCapabilitiesFactCollector()
    assert set(test_system_caps.fact_ids) == set(['system_capabilities',
                                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:24.006174
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: direct param 'module' access here which is 2nd param of collect() is not a 'clean'
    #       approach, but allows us to directly inject mocked 'module' instead of using a base class
    #       for this class and add a lot of extra stuff just for a unit test -akl
    module = None
    collected_facts = None
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.collect(module, collected_facts) == {}

    scfc = SystemCapabilitiesFactCollector()
    scfc.module = MagicMock()
    scfc.module.run_command = MagicMock()
    scfc.module.run_command.return_value = (0, 'Current: =ep\n', '')
    scfc.module.get_bin_path = MagicMock()

# Generated at 2022-06-23 00:47:28.530884
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this unit test is incomplete and needs to be updated -akl
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect()

    # NOTE: as coded, this can not be an assertTrue/False, use assertEquals instead -akl
    assert facts_dict['system_capabilities'][0] == 'cap_sys_ptrace'

# Generated at 2022-06-23 00:47:39.337865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collect_exit_codes
    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, {}, [], True, '/')

    # NOTE: always use a separate instance to avoid cross talk -akl
    instance = SystemCapabilitiesFactCollector()

    # NOTE: use a specific bin path to avoid messing with system setup -akl
    module.BIN_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../files'))

    # NOTE: need to set the '_module' to make the ->has_capability() fake work -akl
    instance._module = module

    # NOTE: there is a list of capsh outputs in ../files/capsh.list
    #       that