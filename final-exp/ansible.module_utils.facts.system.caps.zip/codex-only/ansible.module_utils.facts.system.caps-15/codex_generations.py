

# Generated at 2022-06-23 00:37:34.198299
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-23 00:37:37.330520
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:40.602209
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    obj = SystemCapabilitiesFactCollector()
    obj._module = None
    obj._collect_subset = None
    obj._gather_subset = None

    assert obj.name == 'caps'

# Generated at 2022-06-23 00:37:46.971886
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = lambda: None
    module.run_command = lambda *args, **kwargs: (0, "Current: =ep", "")
    assert SystemCapabilitiesFactCollector(module).collect()['system_capabilities'] == []
    module.run_command = lambda *args, **kwargs: (0, "Current: =ep cap_net_bind_service", "")
    assert SystemCapabilitiesFactCollector(module).collect()['system_capabilities'] == ['cap_net_bind_service']

# Generated at 2022-06-23 00:37:55.648974
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_bins = ['capsh', 'capsh_nonpath']
    for capsh_bin in caps_bins:
        module = MockAnsibleModule(capsh_bin)
        fact_collector = SystemCapabilitiesFactCollector()
        facts_dict = fact_collector.collect(module)
        assert facts_dict['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-23 00:38:03.537066
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fake_an_module = MockModule()
    fake_an_module.run_command.return_value = (0, 'Current: =ep', None)

    fact_collector = SystemCapabilitiesFactCollector(FakeTerminalModule(), None)
    facts_dict = fact_collector.collect(fake_an_module)
    assert facts_dict['system_capabilities'] == []
    assert facts_dict['system_capabilities_enforced'] == 'False'


###
#  Mocks
###

import ansible.module_utils.facts.capsh_support



# Generated at 2022-06-23 00:38:15.067584
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps_fact_col = SystemCapabilitiesFactCollector()
    assert sys_caps_fact_col.name == 'caps'
    assert sys_caps_fact_col._fact_ids == set(['system_capabilities',
                                               'system_capabilities_enforced'])
    sys_caps_fact_col1 = SystemCapabilitiesFactCollector()
    assert sys_caps_fact_col is not sys_caps_fact_col1
    # Check if the object is an instance of the class it is derived from
    assert isinstance(sys_caps_fact_col, SystemCapabilitiesFactCollector)
    assert isinstance(sys_caps_fact_col, BaseFactCollector)
    # Test if an exception is raised for unsupported args

# Generated at 2022-06-23 00:38:18.587331
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:22.691888
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    tsfc_id = scfc.name
    assert scfc.name == 'caps'
    assert scfc._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:32.115893
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = MockModule()
    d = {'system_capabilities': [],
         'system_capabilities_enforced': 'NA'}
    assert d == SystemCapabilitiesFactCollector().collect(m)

    m = MockModule('/bin/capsh')
    d = {'system_capabilities': ['cap_setuid'],
         'system_capabilities_enforced': 'False'}
    assert d == SystemCapabilitiesFactCollector().collect(m)

    m = MockModule('/bin/capsh', 'Current: =ep')
    d = {'system_capabilities': [],
         'system_capabilities_enforced': 'False'}
    assert d == SystemCapabilitiesFactCollector().collect(m)



# Generated at 2022-06-23 00:38:33.016104
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:38.641599
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Degenerate, should be useful when we have more methods
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert len(obj.collect()) == 0
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:41.334106
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class_name = SystemCapabilitiesFactCollector()
    assert isinstance(class_name, SystemCapabilitiesFactCollector)
    assert class_name.name == 'caps'

# Generated at 2022-06-23 00:38:52.090506
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os

    test_content = "Current: =ep\n"

# Generated at 2022-06-23 00:38:52.900314
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:53.606211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:56.720467
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test = SystemCapabilitiesFactCollector()
    assert test.name == 'caps'
    assert test._fact_ids == {'system_capabilities','system_capabilities_enforced'}

# Generated at 2022-06-23 00:39:01.953558
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_caps = SystemCapabilitiesFactCollector()
    test_module = {'capsh': 'capsh', 'run_command': lambda *args, **kwargs: ['NA', '', '']}
    test_module['run_command'].__doc__ = '''Mock of run_command method in AnsibleModule'''

    result = test_caps.collect(module=test_module)
    assert result == {'system_capabilities': ['NA'], 'system_capabilities_enforced': 'NA'}, 'Test failed'

# Generated at 2022-06-23 00:39:12.849906
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import ansible.module_utils.facts.system.caps
    module = ansible.module_utils.facts.system.caps
    module.run_command = mock_run_command
    module.get_bin_path = mock_get_bin_path
    from ansible.module_utils.facts.collector import BaseFactCollector
    base = BaseFactCollector()
    capsh = ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector(base)
    capsh.collect()
    # Correct output from the mock
    assert capsh.collect_facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-23 00:39:16.002278
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test with capsh not present on system
    """
    module = FakeModule({})
    collector = SystemCapabilitiesFactCollector(module=module, shared_module_params=None)
    facts = collector.collect()
    assert facts == {}


# Generated at 2022-06-23 00:39:28.516018
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: the mock module is provided by the mock-helper.py script
    # NOTE: calling module.run_command() in the collect() method leads to a
    #       SystemExit exception (even if we return the default empty dict
    #       immediately after the call). So for unit testing the method
    #       we have to mock-out the call.
    # NOTE: the mock_module fixture is provided by the mock-helper.py script
    import ansible.module_utils.facts.system.caps
    mock_module = ansible.module_utils.facts.system.caps.AnsibleModule

    # NOTE: we have to mock-out everything down to module.run_command() here:

# Generated at 2022-06-23 00:39:35.370167
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock = {
        'run_command.return_value': (0, 'Current: =ep', ''),
    }
    m = mock_module(mock)
    s = SystemCapabilitiesFactCollector(m)
    assert 'system_capabilities_enforced' in s.collect()
    assert 'system_capabilities' in s.collect()

# Generated at 2022-06-23 00:39:38.508354
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector._fact_ids, set)
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:43.216374
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test instantiation of class
    x = SystemCapabilitiesFactCollector()
    assert isinstance(x, SystemCapabilitiesFactCollector)
    assert repr(x) == "<SystemCapabilitiesFactCollector(name=caps, fact_ids={'system_capabilities', 'system_capabilities_enforced'})>"



# Generated at 2022-06-23 00:39:48.855666
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector._fact_ids, set)
    assert 'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector._fact_ids


# Generated at 2022-06-23 00:39:50.143604
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: Test coverage needed when mocking present
    assert(True)

# Generated at 2022-06-23 00:39:57.345235
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # create instance of SystemCapabilitiesFactCollector without any optional arguments
    obj = SystemCapabilitiesFactCollector()

    # check if instance attributes are initialized correctly
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

    # check if the output of the collect method is a dictionary
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 00:40:08.500387
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import pytest
    import os
    import mock

    @mock.patch('ansible.module_utils.facts.collector.FactsCollector.collect')
    @mock.patch('ansible.module_utils.facts.collector.get_collector_instance')
    def test_collect_mock_facts(mock_collect, mock_get_collector_instance):
        mock_

# Generated at 2022-06-23 00:40:18.692032
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

    class FakeModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, prog):
            return self.tmpdir + '/' + prog

        def run_command(self, args, **kwargs):
            if args[0] == self.tmpdir + '/capsh':
                return (0, 'Current: =ep', '')
            return (1, '', 'not found')

    capsh_path = tmpdir + '/capsh'
    with open(capsh_path, 'w') as fh:
        fh.write('#!/bin/sh\n')
        fh.write('/bin/echo "$@"')


# Generated at 2022-06-23 00:40:30.465157
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = AnsibleModule({}, {}, {}, True, None, False, False, None, None)
    base = BaseFactCollector({})
    module.run_command = lambda args, **kwargs: ('fake.out', 'fake.err', 0)
    base.get_bin_path = lambda bin, **kwargs: bin
    fake = SystemCapabilitiesFactCollector(base)
    facts = fake.collect(module)
    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts
    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts

# Generated at 2022-06-23 00:40:40.577174
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_capsh_rc = 0
    test_capsh_out = 'Current:\t= cap_setuid+ep\nBounding set =cap_setuid\n securebits: \t1\n'
    test_capsh_err = ''

    class MockModule(object):
        def __init__(self):
            self.bin_path = '/bin'
            self.rc = test_capsh_rc
            self.out = test_capsh_out
            self.err = test_capsh_err

        def get_bin_path(self, path):
            return self.bin_path + '/' + path

        def run_command(self, command, errors='surrogate_then_replace', **kwargs):
            return self.rc, self.out, self.err

    test_module = MockModule()


# Generated at 2022-06-23 00:40:49.469046
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:53.387108
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps
    assert sys_caps.name == 'caps'
    assert sys_caps._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:55.484160
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test SystemCapabilitiesFactCollector.collect()"""
    # TODO: implement
    assert False, "test not implemented"


# Generated at 2022-06-23 00:41:04.176870
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:41:14.333919
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """

    # Test 1 - expected output from command:
    # Current: = cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_

# Generated at 2022-06-23 00:41:18.049786
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:19.646770
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector class constructor"""
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sorted(sut._fact_ids) == sorted(set(['system_capabilities',
                                                'system_capabilities_enforced']))

# Generated at 2022-06-23 00:41:22.273665
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        sut = SystemCapabilitiesFactCollector()
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-23 00:41:25.946697
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert collector.collect() == {}

# Generated at 2022-06-23 00:41:26.489736
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:41:29.435854
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    p = SystemCapabilitiesFactCollector()
    assert p.name == 'caps'
    assert p._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:36.952059
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os.path
    module = MockModule()
    # Mock run_command() return value
    module.run_command = Mock(return_value=(0, """Current: = cap_net_bind_service,cap_dac_override+ep
Inheritable: = cap_net_bind_service,cap_dac_override
Permitted:   = cap_net_bind_service,cap_dac_override
Effective:   = cap_net_bind_service,cap_dac_override
Bounding set =cap_net_bind_service,cap_dac_override""", ""))
    # Make a fake capsh
    (fd, capsh_path) = tempfile.mkstemp(prefix="capsh", suffix=".py")

# Generated at 2022-06-23 00:41:45.857514
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (0, 'Current: =ep', '')
    collected_facts = dict()

    sut = SystemCapabilitiesFactCollector()
    result = sut.collect(module=module, collected_facts=collected_facts)

    assert 'system_capabilities_enforced' in result
    assert 'system_capabilities' in result
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []


# Generated at 2022-06-23 00:41:48.561425
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mock_module = MagicMock()
    sut = SystemCapabilitiesFactCollector(mock_module)
    assert_equal(sut.name, 'caps')

# Generated at 2022-06-23 00:41:51.209442
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    with mock.patch('ansible.module_utils.facts.collector.module_utils.module_loader') as ml:
        fac = SystemCapabilitiesFactCollector()
        fac.collect()

# Generated at 2022-06-23 00:42:01.232475
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes

    args = []
    curr_list = []
    res_dict = {
        'system_capabilities_enforced': 'True',
        'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']
    }


# Generated at 2022-06-23 00:42:03.453287
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:42:07.426012
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_cap = SystemCapabilitiesFactCollector()
    assert sys_cap is not None
    assert sys_cap.name == 'caps'
    assert sys_cap._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:10.587562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: requires mocking module.run_command()/parse_caps_data() -akl
    pass

# Generated at 2022-06-23 00:42:19.623877
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    SystemCapabilitiesFactCollector.collect() Test
    """
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts import ansible_collector

    ac = AnsibleCollector
    ac.get_module_resource = lambda self, module, resource: None
    ac.exists_executable = lambda self, executable: executable == 'capsh'
    ac.file_exists = lambda self, path: True

    class mock_cmd_output:
        def __init__(self):
            self.rc = 0

# Generated at 2022-06-23 00:42:23.675665
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:35.270281
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.caps
    # This is what capsh --print looks like on a RHEL host with 'enforced' capabilities.
    #
    # Current: = cap_chown,cap_dac_override,cap_dac_read_search,cap_net_bind_service,cap_net_raw,cap_setgid,cap_setuid,cap_setpcap,cap_sys_chroot,cap_audit_write,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_mknod,cap_sys_tty_config,cap_lease,cap_audit_control,cap_fowner,cap_fsetid
    # Bounding set =cap_chown,cap_dac_override,

# Generated at 2022-06-23 00:42:36.841508
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-23 00:42:43.867714
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = ModuleMock()
    module_mock.run_command = lambda args, **kwargs: (0, 'out', 'err')

    capsh_mock = CapsHMock()

# Generated at 2022-06-23 00:42:51.166360
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule:
        class MockRunCommand:
            def __init__(self, arg, rc=0, err='', out=''):
                self.rc = rc
                self.err = err
                self.out = out

            def run_command(self, cmd, errors='surrogate_or_strict', check_rc=False, cwd=None):
                return (self.rc, self.out, self.err)

        def __init__(self):
            self.run_command = self.MockRunCommand()

        def get_bin_path(self, arg):
            return '/bin/capsh'


# Generated at 2022-06-23 00:42:58.344232
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test function
    '''

    # Mock instance of BaseFactCollector
    # NOTE: calling super(BaseFactCollector, self) in class
    # SystemCapabilitiesFactCollector constructor -akl
    ins = BaseFactCollector()

    # Mock instance of SystemCapabilitiesFactCollector
    ins1 = SystemCapabilitiesFactCollector()

    # NOTE: module object is not used for now -akl
    # Mock module object
    # module = AnsibleModule()
    module = None

    # Execute method collect of class SystemCapabilitiesFactCollector
    ret1 = ins1.collect(module)

    assert ret1=={}, "Invalid return value - expected {}"

# Generated at 2022-06-23 00:43:02.801684
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj
    assert obj.name == 'caps'
    # NOTE: -> obj._fact_ids for easier testing -akl
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:06.209980
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: the following test is a bit of a lie, there are not actually
    #       any fact_ids currently exposed from the collector -akl
    f = SystemCapabilitiesFactCollector()
    assert f.name == 'caps'
    assert 'caps' in f.fact_ids

# Generated at 2022-06-23 00:43:09.102856
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test = SystemCapabilitiesFactCollector()
    assert test.name == 'caps'
    assert test.collect() == {}
    assert test._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:13.219783
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == "caps"
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:14.673059
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)


# Generated at 2022-06-23 00:43:19.744491
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert set(system_capabilities_fact_collector._fact_ids) == set(
        ['system_capabilities_enforced', 'system_capabilities'])


# Generated at 2022-06-23 00:43:24.068793
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    
    # Create the class object
    obj = SystemCapabilitiesFactCollector()

    # check name and capabilities of class object
    assert obj.name == 'caps'
    assert str(obj._fact_ids) == "{'system_capabilities_enforced', 'system_capabilities'}"

# Generated at 2022-06-23 00:43:27.614276
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scf = SystemCapabilitiesFactCollector()
    assert scf.name == 'caps'
    assert scf._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:38.916416
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys

    class MockModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            return '/bin/capsh'


# Generated at 2022-06-23 00:43:39.782746
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:43:51.163173
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import json
    import os
    
    # Give return code, stdout and stderr of caps command

# Generated at 2022-06-23 00:43:59.594323
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Mock ansible.module_utils.facts.collector.BaseFactCollector.
    class BaseFactCollector:
        def __init__(self, h):
            self._fact_ids = set(h)

    set_fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])
    base_fact_collector_class = BaseFactCollector(set_fact_ids)
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector(base_fact_collector_class)

    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set_fact_ids

# Generated at 2022-06-23 00:44:03.467223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:13.284427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_path = '/bin/capsh'
    mock_out = """Capabilities for `/bin/capsh':
= cap_setpcap-ep cap_dac_override-p cap_sys_ptrace-eip cap_kill-ep cap_sys_nice-eip cap_sys_resource-ep
cap_sys_time-ep cap_net_bind_service-ep cap_setfcap-ep
=ep
"""
    mock_module = mock.MagicMock()
    mock_module.get_bin_path.return_value = mock_path
    mock_module.run_command.return_value = (0, mock_out, '')
    fact_collector = SystemCapabilitiesFactCollector(mock_module)
    collected_facts = {}

# Generated at 2022-06-23 00:44:14.369240
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    assert SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:44:19.314344
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:28.411249
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    fact_module(ansible.module_utils.facts.system.system)
    -> CollectFactsBase
    -> BaseFactCollector
    -> SystemCapabilitiesFactCollector
    """
    # mock ansible.module_utils.basic.AnsibleModule
    mock_ansible_module = 'ansible.module_utils.basic.AnsibleModule'
    # NOTE: set needed class attributes for testing
    capsh_path = 'capsh_path'

    # NOTE: using class method 'mock_module' and mocking module for test
    # todo: refactor (or move this method) to test support class/module (ansible.test.libs)
    mock_module = BaseFactCollector.mock_module(mock_ansible_module)

    #
    # Mock needed module methods
    #
   

# Generated at 2022-06-23 00:44:32.934523
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:44:38.842555
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Unit test for constructor of class SystemCapabilitiesFactCollector
    """
    # Test with valid parameters
    o = SystemCapabilitiesFactCollector()
    name = o.name
    fact_ids = o._fact_ids

    assert name == 'caps'
    assert 'system_capabilities' in fact_ids
    assert 'system_capabilities_enforced' in fact_ids
    assert len(fact_ids) == 2

# Generated at 2022-06-23 00:44:39.547363
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:44:49.979028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: import locally as unit test is under tests/unit/module_utils/facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import BaseFileModule
    from ansible.module_utils.facts.utils import AnsibleModule

    class FakeModule(BaseFileModule):
        def get_bin_path(self, arg):
            return '/bin/capsh'

        def run_command(self, args, errors=None):
            return (0, get_file_content('tests/unit/module_utils/facts/system/caps', 'capsh'), '')

    module = Ansible

# Generated at 2022-06-23 00:44:54.206752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    sut = SystemCapabilitiesFactCollector()

    # when
    actual = sut.collect()

    # then
    assert actual['system_capabilities_enforced'] in ('True', 'False')
    assert isinstance(actual['system_capabilities'], list)

# Generated at 2022-06-23 00:45:02.863456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock_module = unittest.mock.Mock()
    import pytest
    class mock_module:
        def __init__(self):
            self.run_command = lambda x, y: (0, "Current: =ep", "")

        def get_bin_path(path):
            return "/usr/bin/capsh"

    mock_module_instance = mock_module()

    # mock_module.run_command.return_value = (0, "Current: =ep", "")
    # mock_module.run_command.return_value = (0, "Current: =eip", "")
    # mock_module.run_command.return_value = (0, "Current: cap_net_raw+p", "")
    # mock_module.run_command.return_value = (0, "Current

# Generated at 2022-06-23 00:45:04.523515
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c is not None


# Generated at 2022-06-23 00:45:09.780114
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    sys_cap = SystemCapabilitiesFactCollector()
    collected = sys_cap.collect()
    assert collected['system_capabilities_enforced'] == "NA"
    assert collected['system_capabilities'] == []
    assert sys_cap._fact_ids == set(['system_capabilities',
                                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:14.950948
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    x = SystemCapabilitiesFactCollector()
    y = x.collect()
    assert y == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-23 00:45:18.544656
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:28.338298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # unit test for method collect of class SystemCapabilitiesFactCollector
    # load up our test SystemCapabilitiesFactCollector -akl
    #
    # AnsibleModule objects allow us to create, mock and run modules as if they were being
    # invoked by Ansible, as well as pass parameters to them as if they were modules being
    # executed from the command-line. All this to allow for unit testing -akl
    #
    #
    returned_facts = {}
    am = AnsibleModule({})
    capsh_path = '/bin/capsh'
    am.get_bin_path = MagicMock(return_value=capsh_path)
    am.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    SysCaps = SystemCapabilitiesFactCollector(module=am)


# Generated at 2022-06-23 00:45:30.870909
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:40.408629
# Unit test for constructor of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:45:44.630426
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Unit test for constructor of class SystemCapabilitiesFactCollector."""
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}




# Generated at 2022-06-23 00:45:50.726205
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Arrange
    mock_module = type('', (), {'run_command': run_command})
    mock_module.get_bin_path = lambda self, arg: None
    collector = SystemCapabilitiesFactCollector()

    # Act
    result = collector.collect(module=mock_module)

    # Assert
    assert result == {}


# Generated at 2022-06-23 00:46:01.802870
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # simplify mocking
    class TestModule(object):
        def get_bin_path(self, command):
            return '/usr/bin/capsh'
    module = TestModule()


# Generated at 2022-06-23 00:46:12.530945
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:46:16.084117
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector

    collector = Collector(None)
    result = collector.collect()
    assert result.get('system_capabilities', None) is not None
    assert result.get('system_capabilities_enforced', None) is not None



# Generated at 2022-06-23 00:46:17.804097
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test: Instantiate SystemCapabilitiesFactCollector
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None

# Generated at 2022-06-23 00:46:22.116683
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    assert not c._platforms
    assert c._condition == 'ansible_facts.system_capabilities_enforced != NA'

# Generated at 2022-06-23 00:46:33.084525
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    testModule = MockModule('/bin/capsh', return_value='print line')
    testCollector = SystemCapabilitiesFactCollector(testModule)
    
    # Test non-enforced
    testModule.run_command.return_value = (0, 'Current: =ep', None)
    result = testCollector.collect()
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

    # Test enforced
    testModule.run_command.return_value = (0, 'Current: =eip cap_sys_admin,cap_net_raw+ep', None)
    result = testCollector.collect()
    assert result == {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_sys_admin', 'cap_net_raw']}


# Generated at 2022-06-23 00:46:41.663750
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import get_facts


# Generated at 2022-06-23 00:46:43.793276
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_Cap = SystemCapabilitiesFactCollector()
    assert isinstance(test_Cap, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:46:53.474496
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    # NOTE: get rid of all the mock related stuff, should be unit testing
    # caps_path, caps data, and facts_dict should be set in the unittest setup,
    # not in the test itself.

    # Test not on a system with capsh binary
    module = MockModule()
    module.get_bin_path.side_effect = [None]
    co = SystemCapabilitiesFactCollector()
    assert co.collect(module) == {}

    # Test on a system with capsh binary but with no data
    module = MockModule()
    module.get_bin_path.side_effect = ['capsh']
    module.run_command.side_effect = raiser(1, "", "")
    co = SystemCapabilities

# Generated at 2022-06-23 00:46:54.663831
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:46:57.708799
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}

# Generated at 2022-06-23 00:47:07.278863
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector

    # Test that if 'capsh' command doesn't exist we return an empty list
    def test_collect1(self, module=None, collected_facts=None):
        return {}

    caps_collector = SystemCapabilitiesFactCollector()
    caps_collector.get_bin_path = test_collect1
    facts_dict = caps_collector.collect()
    assert facts_dict == {}

    # Test that if 'capsh' command does exist we are able to parse its output
    # Test that capabilities are enforced
    def test_collect2(self, module=None, collected_facts=None):
        return '/usr/bin/capsh'


# Generated at 2022-06-23 00:47:09.811522
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.__dict__ == {'_fact_ids': {'system_capabilities_enforced', 'system_capabilities'}, 'name': 'caps'}


# Generated at 2022-06-23 00:47:21.097498
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector
    import sys
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule



    #we capture sys.argv to prevent find_needle from failing
    saved_sysargv = sys.argv
    sys.argv = ['bogus','bogus']
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )


    class ModuleMock(object):
        def run_command(foo):
            return 0, "Current: =ep", ""

# Generated at 2022-06-23 00:47:26.106304
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector is not None
    assert 'caps' == system_capabilities_fact_collector.name
    assert set(['system_capabilities', 'system_capabilities_enforced']) == system_capabilities_fact_collector._fact_ids


# Generated at 2022-06-23 00:47:34.097860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import ModuleExecutor
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    executor = ModuleExecutor()

    # Correct facts should be obtained
    content = get_file_content('ansible/module_utils/facts/system/caps/capsh_output.txt')
    capsh_output = StringIO()
    capsh_output.write(to_bytes(content))
    capsh_output.seek(0)
    executor.run_command = lambda x, **kwargs: (0, capsh_output.read(), '')
