

# Generated at 2022-06-23 00:37:35.473714
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                              'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:38.101334
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:47.974166
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import ansible.module_utils.facts.collector as collector

    collector.FACT_CACHE.pop('caps', None)
    caps_collector = SystemCapabilitiesFactCollector()
    assert caps_collector.collect() == {}


# Generated at 2022-06-23 00:37:56.437211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector
    import os
    import sys

    # Create instance of class SystemCapabilitiesFactCollector
    # which inherits from BaseFactCollector
    x = SystemCapabilitiesFactCollector()

    # Create instance of module class
    mock_module = BaseFactCollector()
    mock_module.run_command = MagicMock()

    # Create instance of class FakeModule
    class FakeModule:
      def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
    module = FakeModule()

    # Define some variables
    mock_module.get_bin_path = lambda x: "/bin/capsh"


# Generated at 2022-06-23 00:38:05.868242
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  c = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:38:08.645999
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'


# Generated at 2022-06-23 00:38:11.331774
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector()
    assert a._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:14.792511
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    module = None
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

    fact_collector.collect(module=module)

# Generated at 2022-06-23 00:38:20.697924
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj, SystemCapabilitiesFactCollector)
    assert obj.name == 'caps'
    assert isinstance(obj, BaseFactCollector)
    assert isinstance(obj, collector.BaseFactCollector)

# Generated at 2022-06-23 00:38:24.742437
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:35.582968
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.facts import gather_subset

    # local module import to avoid mutual dependency
    from ansible.module_utils._text import to_bytes

    # create temp dir
    tmpdir = tempfile.mkdtemp()
    tmpcapsh = os.path.join(tmpdir, 'capsh')
    tmpout = os.path.join(tmpdir, 'cap_out')

    # create file with proper content

# Generated at 2022-06-23 00:38:37.949889
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj is not None, ("create SystemCapabilitiesFactCollector failed")

# Generated at 2022-06-23 00:38:48.114249
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    get_caps_data method testing
    """
    SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:38:50.919221
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert type(fact_collector) == SystemCapabilitiesFactCollector

collector = SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:38:53.063637
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-23 00:39:04.909778
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class SystemCapabilitiesFactCollector:
        def __init__(self, name, fact_ids):
            self.name = name
            self._fact_ids = fact_ids

        def get_bin_path(self, capsh_path):
            return capsh_path

        def run_command(self, cmd, errors):
            rc = 0

# Generated at 2022-06-23 00:39:11.482368
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector()
    assert result.name == 'caps'
    for fact in result._fact_ids:
        assert fact in ['system_capabilities', 'system_capabilities_enforced']

# Generated at 2022-06-23 00:39:12.273552
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:39:24.046537
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ test: SystemCapabilitiesFactCollector._collect()
    """
    module = dict()
    module['run_command'] = ['capsh', '--print']
    capsh_output = """
    Current: =ep
    Bounding set =ep
    Secure bits: 00/0x0/1'b0
    secure-noroot: no (unlocked)
    secure-no-suid-fixup: no (unlocked)
    secure-keep-caps: no (unlocked)
    uid=0(root) gid=0(root)
    Capabilities: =ep
    """
    class ModuleResult:
        def __init__(self):
            self.rc = 0
            self.out = capsh_output
            self.err = None

    module['run_command_environ_update'] = None
   

# Generated at 2022-06-23 00:39:25.105105
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:39:35.050531
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:46.074709
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:55.493933
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = MockModule()
    c = SystemCapabilitiesFactCollector(module=m)
    expected = { 'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap'], 'system_capabilities_enforced': 'True' }
    results = c.collect(module=m, collected_facts=None)
    assert expected == results


# Generated at 2022-06-23 00:40:07.152315
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactsCollector, _find_fact_collector_class
    from ansible.module_utils.facts import ProcessorFactCollector
    from ansible.module_utils.facts import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    
    # create fake module
    module = object()

    # create list and add ProcessorFactCollector
    fact_classes = []
    fact_classes.append(ProcessorFactCollector)
    fact_classes.append(SystemCapabilitiesFactCollector)

    # create ModuleFactsCollector object
    module_facts_collector = ModuleFactsCollector(module)

    # call method register_fact_collectors of class ModuleFactsCollector
    module_facts_collector.register_fact_collect

# Generated at 2022-06-23 00:40:18.370341
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: I'm no python unit test expert - JPC
    import ansible.module_utils.facts.collector
    module_mock = ansible.module_utils.facts.collector.AnsibleModule()
    collected_facts = {}

    # 'if not capsh_path' early exit
    capsh_path = None
    capsh_path_mock = ansible.module_utils.facts.collector.AnsibleModule.get_bin_path
    capsh_path_mock.return_value = capsh_path

    c = SystemCapabilitiesFactCollector()
    ret = c.collect(module_mock, collected_facts)

    # Capabilities facts undef by default
    assert ('system_capabilities' not in ret)
    assert ('system_capabilities_enforced' not in ret)

   

# Generated at 2022-06-23 00:40:28.655974
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestModule:
        def get_bin_path(self, executable, required=False):
            return ('/usr/local/bin', [])
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (0, '', '')

    test_module = TestModule()
    test_collector = SystemCapabilitiesFactCollector()
    test_fact_data = test_collector.collect(test_module)
    assert 'system_capabilities' in test_fact_data
    assert 'system_capabilities_enforced' in test_fact_data

# Unit tests for method get_caps_data() of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:40:33.528578
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class_name = 'ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector'
    this_class = get_collector_class(class_name)
    assert this_class != None
    # Verify that instance is of correct type
    assert isinstance(this_class(None), SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:40:37.442859
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = {}
    sys_caps['system_capabilities_enforced'] = 'True'
    sys_caps['system_capabilities'] = ['CAP_NET_BIND_SERVICE']
    assert SystemCapabilitiesFactCollector().collect() == sys_caps

# Generated at 2022-06-23 00:40:41.398693
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleFake()
    module.run_command = lambda x, y: (0, 'Current: =ep', '')
    facts_dict = SystemCapabilitiesFactCollector().collect(module=module)

    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []



# Generated at 2022-06-23 00:40:54.314601
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: py23 compat
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock

    mock_module = MagicMock()

# Generated at 2022-06-23 00:41:05.215179
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys

    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts import collector

    # NOTE: importing module code under test
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    from system_capabilities_collector import SystemCapabilitiesFactCollector

    ##########################################################################
    # Patching required for unit testing

    # Patching AnsibleModule
    class AnsibleModuleMock(object):

        FAKE_BIN_PATH = '/usr/bin/capsh'

        @staticmethod
        def get_bin_path(path):
            return AnsibleModuleMock.FAKE_BIN_PATH if (path == 'capsh') else None


# Generated at 2022-06-23 00:41:14.920684
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleDict
    from ansible.module_utils.facts.sys_module_store import SysModuleStore
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector

    mock_module = Mock()
    mock_module.run_command.return_value = 0, 'Current: =ep'.encode(), ''
    mock_module.get_bin_path.return_value = '/usr/bin/capsh'

    sys_module_store = SysModuleStore()
    sys_module_store.sys_module_import(mock_module)
    collector = SystemCapabilitiesFactCollector(sys_module_store)
    assert collector.collect() == dict(system_capabilities_enforced='False', system_capabilities=[])



# Generated at 2022-06-23 00:41:18.789032
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:41:21.692923
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    return

if __name__ == "__main__":
    test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:41:30.174684
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    my_collected_facts = dict()
    capsh_path = '/usr/bin/capsh'

    my_collector = SystemCapabilitiesFactCollector()

    # caps not present on system
    my_collector.collect(None, my_collected_facts)
    assert my_collected_facts == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

    # caps present on system
    my_collector.collect(capsh_path, my_collected_facts)
    assert my_collected_facts == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-23 00:41:32.546453
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    result = c.collect()
    assert 'system_capabilities_enforced' in result
    assert 'system_capabilities' in result

# Generated at 2022-06-23 00:41:33.678060
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'

# Generated at 2022-06-23 00:41:34.781991
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:41:40.204916
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])


# Generated at 2022-06-23 00:41:50.877817
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary, required=False, opt_dirs=None):
            return '/bin/capsh'


# Generated at 2022-06-23 00:41:55.533752
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capability_collector = SystemCapabilitiesFactCollector()
    assert system_capability_collector.name == 'caps'
    assert system_capability_collector._fact_ids == {'system_capabilities',
                                                     'system_capabilities_enforced'}


# Generated at 2022-06-23 00:41:56.876029
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-23 00:42:00.667223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:05.185424
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:42:15.950615
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Creating mock args
    # TODO: can we use unittest.mock.Mock() instead?
    class ArgumentsMock(object):
        def __init__(self):
            self.module = None

    arguments_mock = ArgumentsMock()

    # Creating mock module
    class ModuleMock:
        def run_command(self, command, errors='surrogate_then_replace'):
            rc = 0

# Generated at 2022-06-23 00:42:16.476541
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:42:24.031963
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CachingFileParser
    from ansible.ModuleUtils.facts.utils.features.test.fake_subprocess_module import FakeSubprocessModule

    fake_subprocess = FakeSubprocessModule()

# Generated at 2022-06-23 00:42:35.675848
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.capabilities import (
        SystemCapabilitiesFactCollector
    )
    from ansible.module_utils import basic
    import pytest
    caps_gc = SystemCapabilitiesFactCollector(basic.AnsibleModule(argument_spec={}))
    caps_gc._module.run_command = lambda x, errors='surrogate_then_replace': (
        0, 'Current: =ep', '')
    caps_gc._module.get_bin_path = lambda x: '/bin/capsh'
    caps_facts = caps_gc.collect()
    assert caps_facts['system_capabilities_enforced'] == 'False'
    assert caps_facts['system_capabilities'] == []

# Generated at 2022-06-23 00:42:43.468046
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system as scfc
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.system.caps as caps
    import ansible.module_utils.basic as basic
    import ansible.module_utils.common.process as process
    import mock

    with mock.patch.object(basic.AnsibleModule, 'get_bin_path') as mock_get_bin_path,\
         mock.patch.object(basic.AnsibleModule, 'run_command') as mock_run_command,\
         mock.patch.object(facts, 'get_cachefile_path') as mock_get_cachefile_path,\
         mock.patch.object(process, '_parse_shebang') as mock_parse_shebang:

        mock_

# Generated at 2022-06-23 00:42:50.932352
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    import sys
    module = AnsibleModuleStub()

    caps = SystemCapabilitiesFactCollector(module=module)
    capsh_path = caps._module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        rc, out, err = caps._module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-23 00:42:56.413419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect(module)
    assert result == {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_chown,cap_dac_override,cap_net_raw,cap_sys_chroot+i']}

# Mock Module class used for unit testing

# Generated at 2022-06-23 00:43:07.709343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system.caps as real_caps_module
    import ansible.module_utils.facts.system.platform as real_platform_module
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    import ansible.module_utils.facts.system.caps as caps_module
    import ansible.module_utils.facts.system.platform as platform_module
    import ansible.module_utils.facts.collector as collector_module
    import tempfile

# Generated at 2022-06-23 00:43:09.489888
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert set(SystemCapabilitiesFactCollector._fact_ids) == set(['system_capabilities',
                                                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:14.595533
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mod = "module"
    facts = "facts"

    fact_collector = SystemCapabilitiesFactCollector(mod, facts)
    assert fact_collector is not None
    assert fact_collector.module == mod
    assert fact_collector.collect() == {}
    assert fact_collector.name == 'caps'
    assert fact_collector.facts == facts
    assert fact_collector._fact_ids == 'system_capabilities'.split()

# Generated at 2022-06-23 00:43:18.014515
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector_obj = SystemCapabilitiesFactCollector()
    assert fact_collector_obj is not None

# Unit test to collect() in class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:43:28.948076
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('ansible.module_utils.facts.capabilities.SystemCapabilitiesFactCollector.collect()')
    from ansible.module_utils.facts.capabilities.SystemCapabilitiesFactCollector import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.capabilities.SystemCapabilitiesFactCollector
    import mock

    x = SystemCapabilitiesFactCollector()
    if hasattr(ansible.module_utils.facts.capabilities.SystemCapabilitiesFactCollector, '_validate_caps'):
        ansible.module_utils.facts.capabilities.SystemCapabilitiesFactCollector._validate_caps = mock.Mock()
    if hasattr(ansible.module_utils.facts.capabilities.SystemCapabilitiesFactCollector, 'get_caps_data'):
        ansible.module_utils.facts.capabilities

# Generated at 2022-06-23 00:43:39.489172
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_parse_caps_data
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_get_caps_data
    from ansible.module_utils._text import to_bytes, to_text
    import os

    # NOTE: run_command() return values in the form (rc, out, err)
    def run_command(command, **kwargs):
        rc = 0
        out = ''
        err = None

# Generated at 2022-06-23 00:43:43.085810
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == \
        set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:45.369070
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:43:46.755327
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'

# Generated at 2022-06-23 00:43:56.798866
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock_module() with or without side_effect
    # depending on whether the return value is to be tested.
    m_module = Mock()
    m_module.run_command.return_value = 0, 'capsh --print' \
                  'Current: =ep', ''
    m_module.get_bin_path.return_value = '/bin/capsh'
    # Instantiate the SystemCapabilitiesFactCollector with the mocked_module()
    # as parameter
    system_caps_collector = SystemCapabilitiesFactCollector()
    system_caps_collector.collect(m_module)
    # Assert that the method run_command() is called with the expected parameters
    m_module.run_command.assert_called_with(['/bin/capsh', '--print'], errors='surrogate_then_replace')

# Generated at 2022-06-23 00:44:05.337966
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.other
    import ansible.module_utils.facts.system
    import ansible.module_utils.module_common
    import ansible.module_utils.basic
    import ansible.module_utils.six

    capsh_path = "/usr/bin/capsh"
    fake_module = ansible.module_utils.module_common.AnsibleModule(
            argument_spec=ansible.module_utils.basic.AnsibleModule.argument_spec,
            supports_check_mode=False,
            bypass_checks=False)


# Generated at 2022-06-23 00:44:09.752418
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test for constructor of class SystemCapabilitiesFactCollector
    result = SystemCapabilitiesFactCollector()
    assert result
    assert result.name == 'caps'
    assert result._fact_ids == set(['system_capabilities',
                                    'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:21.327816
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap_facts = {}
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        os.environ["PATH"] = os.pathsep.join([os.environ["PATH"], tempdir])
        bin_name = os.path.join(tempdir, 'capsh')

# Generated at 2022-06-23 00:44:30.776505
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Set up the following test fixture:
    from ansible.module_utils.facts import collector

    # NOTE: This is basically a 'run_command()' mock
    def _run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', text=None):
        out = ''
        err = ''
        rc = 0
        return rc, out, err

    class _AnsibleModule(object):
        @property
        def run_command(self):
            return _run_command


# Generated at 2022-06-23 00:44:36.424004
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_local

    os_mock = ansible_local.AnsibleModule(argument_spec={}, supports_check_mode=True)
    os_mock.run_command = MagicMock()
    os_mock.run_command.return_value = (0, "Current: =ep bounding", "")

    f = SystemCapabilitiesFactCollector()
    f.collect(os_mock)
    assert f.facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:44:42.433803
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps', 'Name should be caps but is %s' % c.name
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']),\
        'Fact ids should be "system_capabilities" and "system_capabilities_enforced" but are %s' % c._fact_ids

# Generated at 2022-06-23 00:44:44.704892
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
  # Testing of object instance creation
  system_c_facts = SystemCapabilitiesFactCollector()

  assert system_c_facts is not None

# Generated at 2022-06-23 00:44:47.572305
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    inst = SystemCapabilitiesFactCollector()
    # NOTE: make this assert None instead of []
    assert inst._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:50.098345
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-23 00:44:54.703306
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_capability_collector = SystemCapabilitiesFactCollector()
    assert capsh_capability_collector.name == 'caps'
    assert capsh_capability_collector._fact_ids == {'system_capabilities',
                                                    'system_capabilities_enforced'}

# Generated at 2022-06-23 00:45:04.420981
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as capsh_path:
        capsh_path_file =  os.path.join(capsh_path, 'capsh')

# Generated at 2022-06-23 00:45:06.210935
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-23 00:45:09.062285
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:45:11.159480
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector is not None

# Generated at 2022-06-23 00:45:23.233730
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    # Create a collector object
    test_collector = collector.get_collector("SystemCapabilitiesFactCollector")

    # Create a test module to provide mocked system capabilities

# Generated at 2022-06-23 00:45:24.422043
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:33.653023
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.common import get_exception
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.compat.tests import mock
    m = mock.mock_open()
    from ansible.compat import mock
    #mock_get_bin_path = MagicMock(return_value="/usr/bin/capsh")
    #monkeypatch.setattr(ansible, 'module_utils.basic.get_bin_path', mock_get_bin_path)

# Generated at 2022-06-23 00:45:36.230580
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-23 00:45:38.255267
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector_instance = SystemCapabilitiesFactCollector()
    if not collector_instance:
        return 1
    return 0

# Generated at 2022-06-23 00:45:41.937284
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: Instantiate only to test constructor -akl
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:50.496707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors import which
    from ansible.module_utils.facts import Collector

    class TestModule:
        def run_command(self, argv, errors=None):
            if argv[0] == capsh_path:
                return 0, '', ''
            elif argv[0] == 'which':
                return 0, capsh_path, ''

        def get_bin_path(self, exe):
            return exe

    capsh_path = '/bin/capsh'
    test_module = TestModule()
    collector = Collector.load_collector('system_capabilities')
    result = collector.collect(test_module)
    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result

# Generated at 2022-06-23 00:45:54.303565
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    assert c.collect() == {}

# Generated at 2022-06-23 00:46:04.181550
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:46:14.468944
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:46:23.414805
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:46:31.009061
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    module = ansible.module_utils.facts.collector.get_module_mock()
    capabilities = SystemCapabilitiesFactCollector(module)
    current_caps = capabilities.collect(module)
    assert isinstance(current_caps, dict)
    assert isinstance(current_caps['system_capabilities'], list)
    assert isinstance(current_caps['system_capabilities_enforced'], str)

# Generated at 2022-06-23 00:46:35.502995
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = "/usr/bin/capsh"
    module = "mock module"
    capsh_collector = SystemCapabilitiesFactCollector(module)
    assert isinstance(capsh_collector, BaseFactCollector)
    assert isinstance(capsh_collector.capsh_path, str)

# Generated at 2022-06-23 00:46:38.722223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector._fact_ids, set)

# Generated at 2022-06-23 00:46:47.715765
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    try:
        from importlib import util
    except ImportError:
        from imp import find_module as util
    found = util.find_module('capstone')


    # NOTE: construct object with empty module to capture side effects -akl
    obj = SystemCapabilitiesFactCollector()

    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

    # NOTE: capsh not found in path - return empty dict
    assert obj.collect(module=None) == {}

    # NOTE: capsh found, but prints nothing - return empty dict
    assert obj.collect(module=None) == {}

    # NOTE: capsh found, prints output, but not enforced - return empty dict
    assert obj.collect(module=None) == {}

   

# Generated at 2022-06-23 00:46:49.133506
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:46:50.883595
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    results = SystemCapabilitiesFactCollector.collect()
    assert results == {}

# Generated at 2022-06-23 00:46:54.664736
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set([
        'system_capabilities',
        'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:00.716591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = MagicMock()
    test_module.get_bin_path.side_effect = lambda path: path
    test_module.run_command.side_effect = lambda args, errors: (0, 'Current: =ep', '')

    fact = SystemCapabilitiesFactCollector(test_module)

    result = fact.collect(test_module)

    assert result == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'False',
    }

# Generated at 2022-06-23 00:47:03.959237
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector()
    assert result['name'] == 'caps'
    assert result['_fact_ids'] == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:47:12.070860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect(): # pylint: disable=invalid-name
    """
    Unit test for method 'collect' of class SystemCapabilitiesFactCollector
    """
    fact_collector = SystemCapabilitiesFactCollector(None)
    fact_collector._module = MockModule(
        get_bin_path=lambda x: '/invalid/path/for/%s' % x)
    collected_facts = {'/invalid/path/for/capsh': None,
                       'system_capabilities_enforced': None,
                       'system_capabilities': []}
    assert fact_collector.collect() == collected_facts



# Generated at 2022-06-23 00:47:22.968214
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'Current: =ep', '')
    expected = {'system_capabilities_enforced': 'False',
                'system_capabilities': []}
    result = SystemCapabilitiesFactCollector.collect(mock_module)
    assert not mock_module.run_command.called
    assert result == {}

    mock_module.run_command.return_value = (0, 'Current: =ep test, test_2', '')
    expected = {'system_capabilities_enforced': 'False',
                'system_capabilities': ['test',
                                        'test_2']}
    result = SystemCapabilitiesFactCollector.collect(mock_module)
    assert not mock_module.run_command.called

# Generated at 2022-06-23 00:47:27.785998
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mod = FakeModule(capsh_out=CAPSH_OUTPUT)
    facts = SystemCapabilitiesFactCollector().collect(mod)
    assert facts['system_capabilities'] == ['cap_chown', 'cap_fowner', 'cap_mknod', 'cap_net_bind_service', 'cap_setgid', 'cap_setuid']
    assert facts['system_capabilities_enforced'] == 'True'

    mod = FakeModule(capsh_out=CAPSH_OUTPUT_NOT_ENFORCED)
    facts = SystemCapabilitiesFactCollector().collect(mod)
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-23 00:47:32.290197
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])