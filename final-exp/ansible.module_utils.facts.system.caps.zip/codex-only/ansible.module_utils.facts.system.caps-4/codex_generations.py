

# Generated at 2022-06-23 00:37:36.959189
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector constructor"""
    fact_class = SystemCapabilitiesFactCollector
    fact_instance = fact_class()
    assert fact_instance.name == 'caps'
    assert fact_instance._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:40.366577
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:42.267855
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_collector = SystemCapabilitiesFactCollector()
    assert not facts_collector.get_facts()

# Generated at 2022-06-23 00:37:51.325368
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # The SystemCapabilitiesFactCollector class object.
    name = "ansible.module_utils.facts.system.caps"
    collector = __import__(name, globals(), locals(), [], 0)

    # The AnsibleModule class object.
    module = __import__("ansible.module_utils.basic",
                        globals(), locals(), [], 0)()

    # The SystemCapabilitiesFactCollector class object.
    obj = collector.SystemCapabilitiesFactCollector(module)
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

    # Test 1, system_capabilities_enforced is NA, system_capabilities is None
    # due to a return early for capsh_path not being found.
    facts_

# Generated at 2022-06-23 00:37:53.679516
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:00.954820
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class TestModule:
        def get_bin_path(self, program):
            return 'capsh'

    TestModule = TestModule()

    fc = SystemCapabilitiesFactCollector()

    assert fc.name == 'caps'
    keys = fc.collect(TestModule).keys()
    assert 'system_capabilities_enforced' in keys
    assert 'system_capabilities' in keys

# Generated at 2022-06-23 00:38:04.237385
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == ('system_capabilities', 'system_capabilities_enforced')

# Generated at 2022-06-23 00:38:04.805257
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:13.584917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # test empty return
    f = SystemCapabilitiesFactCollector()
    assert len(f.collect()) == 0

    # test with fake module
    m = module()
    assert len(f.collect(module=m)) == 0

    # test with fake module and return
    m.run_command_return = ('', '', '')
    m.run_command_rc = 0
    assert len(f.collect(module=m)) == 2
    assert f.collect(module=m)['system_capabilities'] == []
    assert f.collect(module=m)['system_capabilities_enforced'] == 'NA'

    # test with fake module and return
    m.run_command_return = ('Current: =ep', '', '')
    m.run_command_rc = 0

# Generated at 2022-06-23 00:38:14.270562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:19.557552
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
        Test the constructor of class SystemCapabilitiesFactCollector.
        """
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])


# Generated at 2022-06-23 00:38:26.131819
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    class AC(object):

        def getuid(self):
            return 0

    a = AC()
    facts = SystemCapabilitiesFactCollector()

    assert facts._fact_ids is not None
    assert 'system_capabilities' in facts._fact_ids
    assert 'system_capabilities_enforced' in facts._fact_ids
    assert isinstance(facts.name, str)
    assert isinstance(facts.collect(a), dict)

# Generated at 2022-06-23 00:38:36.385768
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    test_class = "SystemCapabilitiesFactCollector"
    test_method = "collect"
    mock_module = Mock()
    mock_module.run_command.return_value = (0,
                                            'Current: = cap_setpcap,cap_net_admin,cap_net_raw+eip',
                                            '')
    # Exercise:
    result = SystemCapabilitiesFactCollector(mock_module).collect()
    # Verify:
    assert result == { 'system_capabilities_enforced': 'False',
                       'system_capabilities': ['cap_setpcap', 'cap_net_admin', 'cap_net_raw']}
    # Cleanup:
    mock_module.reset_mock()

# Generated at 2022-06-23 00:38:38.044863
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:38:42.585796
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # initialize the class to test
    test_class = SystemCapabilitiesFactCollector()
    
    # test the name property
    assert test_class.name == 'caps'
    
    # test the _fact_ids property
    assert test_class._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:45.324518
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for collect method of SystemCapabilitiesFactCollector.
    '''
    obj = SystemCapabilitiesFactCollector()
    assert obj.collect() == {'system_capabilities': []}

# Generated at 2022-06-23 00:38:49.766763
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: constructor doesn't take any arguments
    sc = SystemCapabilitiesFactCollector()
    assert sc.name == 'caps'
    assert 'system_capabilities' in sc._fact_ids
    assert 'system_capabilities_enforced' in sc._fact_ids

# Generated at 2022-06-23 00:38:53.303875
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:38:56.899768
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mycollector = SystemCapabilitiesFactCollector()
    assert mycollector.name == 'caps'
    assert mycollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:04.386933
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ##
    ## patch module.get_bin_path
    ##
    def get_bin_path(bin_name):
        return '/usr/bin/capsh'

    ##
    ## patch module.run_command
    ##

# Generated at 2022-06-23 00:39:07.537821
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    result = c.__dict__
    assert result['_fact_ids'] == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:19.404944
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    from ansible.module_utils.facts import collector
    collector._collectors['caps'] = SystemCapabilitiesFactCollector()

    (rc, out, err) = collector.collect(module=module, collected_facts={})
    assert rc == 0

# Generated at 2022-06-23 00:39:22.471667
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:30.577792
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={}
    )

    capsh_path = module.get_bin_path('capsh')
    if not capsh_path:
        # this is a skip - no capsh on system -akl
        return

    facts_dict = {}
    for c in [SystemCapabilitiesFactCollector]:
        c = c(module)
        facts_dict.update(c.collect(module, facts_dict))

    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict


# Generated at 2022-06-23 00:39:42.899522
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = '/usr/bin/capsh'
    # capsh_path = None

# Generated at 2022-06-23 00:39:46.082809
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    TODO: Unit test for constructor of class SystemCapabilitiesFactCollector
    '''
    # Test instantiation of class SystemCapabilitiesFactCollector
    pass

# Generated at 2022-06-23 00:39:51.599109
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock type and value of module
    module = FakeAnsibleModule()

# Generated at 2022-06-23 00:39:52.301071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """system/capabilities.py:SystemCapabilitiesFactCollector.collect() - unit test"""
    pass

# Generated at 2022-06-23 00:39:54.654403
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector()
    assert isinstance(a, SystemCapabilitiesFactCollector)


# Generated at 2022-06-23 00:40:06.298606
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.pycompat24 import get_exception

    module = basic.AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    module.get_bin_path = get_bin_path_mock_return_value
    module.run_command = run_command_mock_return_value
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert len(SystemCapabilitiesFactCollector._fact_ids) == 2
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilities

# Generated at 2022-06-23 00:40:10.340461
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut.collect(module=module) == {}



# Generated at 2022-06-23 00:40:16.160625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    expected_facts = {'system_capabilities_enforced': 'NA',
                      'system_capabilities': []}

    scfc = SystemCapabilitiesFactCollector()
    out_facts_dict = scfc.collect(module=module, collected_facts=collected_facts)

    assert out_facts_dict == expected_facts

# Generated at 2022-06-23 00:40:16.766426
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:40:29.023447
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(module, {})

# Generated at 2022-06-23 00:40:39.421257
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector

    class MockModule:
        def __init__(self, path, rc, out, err):
            self.run_command = Mock(return_value=(rc, out, err))
            self.get_bin_path = Mock(return_value=path)
            self.run_command = Mock(return_value=(rc, out, err))

    def get_collector(path, rc, out, err):
        module = MockModule(path, rc, out, err)
        return FactsCollector(module=module)

    from unittest.mock import Mock

    def get_collector(path, rc, out, err):
        module = MockModule(path, rc, out, err)
        return FactsCollector(module=module)
    #
    #

# Generated at 2022-06-23 00:40:40.026406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:40:43.851556
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:55.011171
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'false'
                else:
                    enforced = 'true'
                    enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

        facts_dict['system_capabilities_enforced'] = enforced
        facts

# Generated at 2022-06-23 00:40:57.930255
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:41:08.630799
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test collect capabilities method of SystemCapabilitiesFactCollector

    """

# Generated at 2022-06-23 00:41:16.237072
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.modules.system import get_capabilities

    class MockModule:
        def __init__(self):
            self.fail_json = self.fail_json_mock

        def get_bin_path(self, prog):
            return '/usr/bin/capsh'

        def fail_json_mock(self, msg):
            print(msg)

        def run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd == ['/usr/bin/capsh', '--print']:
                return 0, '''Current: =ep
CapInh: =
CapPrm: =
CapEff: =
CapBnd: =
CapAmb: =
''', ''

# Generated at 2022-06-23 00:41:21.899638
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Make sure the collect method is returning sensible data
    """
    import ansible.module_utils.facts.system.capabilities as capabilities
    print("Running test_SystemCapabilitiesFactCollector_collect")
    print("")
    print("TODO")
    raise NotImplementedError("TODO")
    # facts_collector = capabilities.SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:41:32.164874
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector
    module = ['capsh', '--print']
    module.append('')
    output = 'Current: = cap_net_raw+p\n'
    error = ''
    rc = 0
    def run_command(self, args, errors='stderr'):
        return rc, output, error

    test_status = True
    # Check if facts are getting collected
    test_dict = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    module.run_command = run_command
    collected_facts = collector.collect(module)
    for each_fact in test_dict:
        if each_fact in collected_facts.keys():
            if collected_facts[each_fact] != test_dict[each_fact]:
                test_status

# Generated at 2022-06-23 00:41:38.142407
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import ansible_collector
    # Create a fake module to get a module util object
    class TestAnsibleModule():
        def __init__(self):
            self.params = None
        def get_bin_path(self, path):
            return "capsh"
        def run_command(self, path):
            return 0, "Current: =ep", None
    testAnsibleModule = TestAnsibleModule()
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    systemCapabilitiesFactCollector.collect(module=testAnsibleModule)
    assert systemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:41:45.070432
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Arrange
    module = AnsibleModuleMock()
    test_collector = SystemCapabilitiesFactCollector()

    # Act
    result = test_collector.collect(module)

    # Assert
    assert 'system_capabilities' in result.keys()
    assert 'system_capabilities_enforced' in result.keys()
    assert result['system_capabilities'] == ['chown']
    assert result['system_capabilities_enforced'] == 'True'



# Generated at 2022-06-23 00:41:48.486432
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_obj = SystemCapabilitiesFactCollector()
    assert my_obj.name == 'caps'

    # Test _fact_ids is readonly
    with pytest.raises(AttributeError):
        my_obj._fact_ids = []

# Generated at 2022-06-23 00:41:57.673721
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #Test expected success path
    module = mock.Mock()
    module.run_command.return_value = (0, 'Current: = cap_net_raw,cap_sys_raw=pe', '')
    module.command_warnings = ()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    mock_facts = {}
    expected_facts_dict = {'system_capabilities_enforced': 'False',
                           'system_capabilities': ['cap_net_raw', 'cap_sys_raw']}
    actual_facts_dict = SystemCapabilitiesFactCollector.collect(module, mock_facts)
    assert expected_facts_dict == actual_facts_dict

    # Test expected failure path (1)
    module.reset_mock()

# Generated at 2022-06-23 00:42:04.305191
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # setup mocks
    capsh_path = '/bin/capsh'
    module = MagicMock()
    module.get_bin_path.return_value = capsh_path
    module.run_command.return_value = (0, 'foo', '')
    # create instance
    sut = SystemCapabilitiesFactCollector()
    # run
    result = sut.collect(module)
    # assert method run_command was called with expected args
    module.run_command.assert_called_once_with([capsh_path, '--print'], errors='surrogate_then_replace')
    # and that we have the expected result
    assert result == {}

# Generated at 2022-06-23 00:42:10.100416
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ Test SystemCapabilitiesFactCollector construction
        It should return an SystemCapabilitiesFactCollector with correct
        attributes
    """
    new_collector = SystemCapabilitiesFactCollector()

    assert new_collector.name == 'caps'
    assert new_collector._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:20.771592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = DummyAnsibleModule()
    test_module.run_command = MagicMock(
        # NOTE: Must return a tuple. Validated.
        return_value=(1, 'Current: =ep', ''))
    test_module.get_bin_path = MagicMock(return_value='/usr/bin/capsh')
    test_collector = SystemCapabilitiesFactCollector()
    test_collector.collect(test_module)
    # NOTE: Assertions
    assert test_module.get_bin_path.call_args_list ==\
           [call('capsh')],\
        "Failed to call get_bin_path with required argument(s)"

# Generated at 2022-06-23 00:42:24.947099
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert (instance.name == 'caps')
    assert (instance._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']))

# Generated at 2022-06-23 00:42:36.603135
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    def run_command_mock(command, errors='surrogate_then_replace',
                                          check_rc=True, close_fds=True, executable=None,
                                          data=None, binary_data=False, path_prefix=None,
                                          cwd=None, use_unsafe_shell=False, prompt_regex=None,
                                          environ_update=None, umask=None, encoding=None,
                                          data_struct=None, replace_whitespace=True,
                                          regex_search=None):
        return 0, 'Current: =epB', ''

    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.collector.base


# Generated at 2022-06-23 00:42:39.334261
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])



# Generated at 2022-06-23 00:42:43.010626
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps.name == "caps"
    assert sys_caps._fact_ids == {"system_capabilities",
                                  "system_capabilities_enforced"}


# Generated at 2022-06-23 00:42:44.436479
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert set(SystemCapabilitiesFactCollector.collect()) == set([])

# Generated at 2022-06-23 00:42:51.527680
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, path):
            return '/bin/capsh'
        def run_command(self, command, errors='strict'):
            assert errors == 'surrogate_then_replace'
            assert command == ['capsh', '--print']
            return (0, """Current: =ep
CapInh: =
CapPrm: =
CapEff: =
CapBnd: =
CapAmb: =
""", '')

    mock_module = MockModule()
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(mock_module)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

#

# Generated at 2022-06-23 00:42:52.231008
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("test TODO")

# Generated at 2022-06-23 00:42:54.924446
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:58.649781
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj.collect() == {}
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:43:05.528031
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock(
        run_command=Mock(
            return_value=(0, 'Current: =ep', '')
        ),
        get_bin_path=Mock(return_value=True)
    )

    # Test
    assert SystemCapabilitiesFactCollector().collect(None, {}) == {}
    assert SystemCapabilitiesFactCollector().collect(mock_module, {}) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-23 00:43:09.423295
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert isinstance(instance.name, str)
    assert isinstance(instance._fact_ids, set)
    assert instance._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:17.645122
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class FakeModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, capsh_path, required=False, opt_dirs=[]):
            return '/usr/bin'

# Generated at 2022-06-23 00:43:20.794897
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:25.453455
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Note: instantiated in BaseFact, provided for consistency
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                            'system_capabilities_enforced'])
    assert SystemCapabilitiesFactCollector.collect() == {}


# Generated at 2022-06-23 00:43:27.910294
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = None
    c = SystemCapabilitiesFactCollector()
    facts = c.collect(m)
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'NA'

# Generated at 2022-06-23 00:43:32.114391
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:39.963693
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    import sys
    m = type(sys)("ansible_module_mock")
    m.run_command = lambda x, **kwargs: (0, json.dumps({}), '')
    m.get_bin_path = lambda x: "/capsh_path"
    m.params = {}
    c = SystemCapabilitiesFactCollector()
    f = c.collect(m, {})

    assert 'system_capabilities' in f
    assert 'system_capabilities_enforced' in f
    assert f['system_capabilities'] == []
    assert f['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:43:41.288869
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:43:44.596693
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name =='caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:47.260761
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert set(SystemCapabilitiesFactCollector._fact_ids) == set(['system_capabilities',
                                                                  'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:50.368804
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    fake_module = None
    fake_collector = SystemCapabilitiesFactCollector()
    fake_collector.collect(fake_module)

# Generated at 2022-06-23 00:44:01.689131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible_collections.ansible.posix.plugins.module_utils.facts import collector
    import os
    # Replace function get_bin_path of class BaseFactCollector by a mock
    BaseFactCollector.get_bin_path = lambda self: os.path.join('path', 'to', 'capsh')
    # Replace function run_command of class AnsibleModule by a mock

# Generated at 2022-06-23 00:44:08.122443
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    test for when a system has capabilities enforced
    '''
    print('start test')
    def mock_run_command(cmd, errors):
        class MockResult():
            def __init__(self, status, stdout, stderr):
                self.status = status
                self.stdout = stdout
                self.stderr = stderr
        if cmd[0] == 'capsh':
            return MockResult(0, "Current: = cap_chown,cap_dac_override+p", "")
        elif cmd[0] == '/foo/bin/capsh':
            return MockResult(0, "", "")

    class MockModule():
        def __init__(self):
            self.run_command = mock_run_command

# Generated at 2022-06-23 00:44:10.265309
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect()

# Generated at 2022-06-23 00:44:13.729085
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector.fact_ids() == ['system_capabilities', 'system_capabilities_enforced']


# Generated at 2022-06-23 00:44:18.391362
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ This method will create object for class SystemCapabilitiesFactCollector """
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:44:27.722369
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic
    import ansible.module_utils.facts.system.caps

    class MockModule(object):
        def __init__(self):
            # NOTE: 'run_command()' validates params -akl
            self.params = {}

        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'capsh':
                return '/bin/capsh'
            return None

        def run_command(self, args, **kwargs):
            if args[0] == 'capsh':
                return 0, '', ''
            return -1, '', ''


# Generated at 2022-06-23 00:44:34.562652
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    result = "{'name': 'caps', '_fact_ids': frozenset({'system_capabilities_enforced', 'system_capabilities'})}"
    result2 = str(my_SystemCapabilitiesFactCollector)
    assert (result == result2), \
        "Results do not match, %s != %s" % (result2, result)

# Generated at 2022-06-23 00:44:45.628106
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is for code already present; add more tests -akl
    # NOTE: method tested in isolation from superclass BaseFactCollector
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils import basic
    import sys


# Generated at 2022-06-23 00:44:54.288912
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a new instance of the module
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: None

    # Create a new instance of the SystemCapabilitiesFactCollector class
    capsh_path = '/bin/capsh'
    module.run_command = lambda x, errors='surrogate_then_replace', check_rc=None: (0, capsh_path, '')
    module.get_bin_path = lambda x: capsh_path
    collect_mock = SystemCapabilitiesFactCollector()
    collect_mock.collect(module=module, collected_facts={})
    assert collect_mock.name == 'caps'
    assert collect_mock._fact_ids == set(['system_capabilities',
                                          'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:54.901341
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:45:04.705343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    class ModuleStub():
        def get_bin_path(self, cmd, required=False):
            print("returning %s" % os.path.abspath("caps.sh"))
            return os.path.abspath("caps.sh")
        def run_command(self, cmd, errors="surrogate_then_replace"):
            return 0, "something", "something else"
    class FakeLoader():
        def __init__(self):
            self.module_utils_path = "something"
    class FakeVarsModule():
        def get_vars(self):
            return {}
    m = ModuleStub()
    l = FakeLoader()
    v = FakeVarsModule()

# Generated at 2022-06-23 00:45:08.418760
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == "caps"
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:45:12.561716
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector.collect_fn == 'collect'
    assert SystemCapabilitiesFactCollector.fact_ids == set(['system_capabilities',
                                                            'system_capabilities_enforced'])

# Unit test of method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:45:14.561236
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_collector = SystemCapabilitiesFactCollector()
    assert facts_collector.name == 'caps'
    assert len(facts_collector._fact_ids) == 2

# Generated at 2022-06-23 00:45:20.121649
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """This is a constructor test for SystemCapabilitiesFactCollector
    """
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:23.302843
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:25.717822
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps', 'name of collector should be caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])



# Generated at 2022-06-23 00:45:33.866996
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = {}
    capsh_path = '/usr/bin/capsh'
    new_inst = SystemCapabilitiesFactCollector()
    # NOTE: test_module = None to use 'hardcoded' test-data -akl
    test_module = None
    # NOTE: this output is hardcoded inside the method -akl

# Generated at 2022-06-23 00:45:47.249482
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initializes a mock module
    module = AnsibleModule(argument_spec={'capsh_path': dict(default='/bin/capsh')})

    # Initializes a mock module with empty output in case of non-root
    capsh_path_empty = "tests/unittests/test_capsh_empty.txt"
    with open(capsh_path_empty, 'rb') as capsh_path_empty_output:
        module.run_command = MagicMock(return_value=[0, capsh_path_empty_output.read(), ''])
    collector = SystemCapabilitiesFactCollector(module=module)
    # Calling the collect method - output is empty if the user is not running with root permissions
    collected_facts = collector.collect(module=module)

# Generated at 2022-06-23 00:45:51.381865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: create mock module for testing method -akl
    # noting:   ansible_facts['system_capabilities']
    #           ansible_facts['system_capabilities_enforced']
    pass

# Generated at 2022-06-23 00:45:52.532518
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:55.652584
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:04.530420
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = type('test_module', (object,), { 
        'run_command': lambda s, x: (0, '', '')
        })

    # Construct object for testing
    test_object = SystemCapabilitiesFactCollector()
    # Call the collect method with test_module (defined above) object
    test_object.collect(test_module)
    # test_object.system_capabilities_enforced has value 'True' if capsh is not installed
    if test_object.system_capabilities_enforced == 'NA':
       assert test_object.system_capabilities_enforced == 'NA'
    else:
       assert test_object.system_capabilities_enforced == 'True'

# Generated at 2022-06-23 00:46:14.735178
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:46:17.682729
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    results = collector.collect()
    assert sorted(results.keys()) == ['system_capabilities', 'system_capabilities_enforced']
    assert isinstance(results['system_capabilities'], list)
    assert isinstance(results['system_capabilities_enforced'], str)

# Generated at 2022-06-23 00:46:21.243448
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector({})
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:22.842248
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector.collect(module=None, collected_facts=None) == {}

# Generated at 2022-06-23 00:46:25.929678
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-23 00:46:36.224773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pprint
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collectors.system.capabilities.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collectors.system.capabilities.caps import run_command
    module = AnsibleModule(
        argument_spec = dict()
    )
    ansible_collector.register(SystemCapabilitiesFactCollector(module, 'setup'))
    ansible_collector.collect()
    facts = ansible_collector.populate()
    rules = facts.get('system_capabilities')
    enforced = facts.get('system_capabilities_enforced')
    pprint.pprint(rules)
    pprint.pp

# Generated at 2022-06-23 00:46:37.420048
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:46:46.875458
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    patcher = patch("ansible.module_utils.facts.collector.BaseFactCollector._get_file_content")
    mock_BaseFactCollector_get_file_content = patcher.start()
    patcher = patch("ansible.module_utils.facts.collector.BaseFactCollector._get_file_lines")
    mock_BaseFactCollector_get_file_lines = patcher.start()
    patcher = patch("ansible.module_utils.facts.collector.BaseFactCollector._get_file_size")
    mock_BaseFactCollector_get_file_size = patcher.start()
    expected_results = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    mock_module = MagicMock()

# Generated at 2022-06-23 00:46:49.190188
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}



# Generated at 2022-06-23 00:46:53.502823
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Unit test for class SystemCapabilitiesFactCollector
    '''
    capsh_collector = SystemCapabilitiesFactCollector()
    assert capsh_collector.name == 'caps'
    assert capsh_collector.collect() == {}

# Generated at 2022-06-23 00:46:56.794654
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                          'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:59.769251
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:08.831221
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Mock a FakeModule, used to collect facts
    class MockModule(object):

        def __init__(self):
            self.run_command = ['/bin/capsh', '--print']

        def get_bin_path(self, name):
            return name

        @staticmethod
        def run_command(args, errors='surrogate_then_replace'):
            return 0, 'Current: =ep\nBounds:', ''

    # Mock a collected_facts
    class MockCollectedFacts(dict):
        def __init__(self):
            dict.__init__(self)
            self.system_capabilities_enforced = 'NA'
            self.system_capabilities = []

    mock_module = MockModule()

    # Call the method collect of class SystemCapabilitiesFactCollector
    # Returned value

# Generated at 2022-06-23 00:47:13.911605
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeModule(subprocess.Popen([], stdout=subprocess.PIPE))
    SystemCapabilitiesFactCollector.collect(module)

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.facts.collector import BaseFactCollector
import subprocess


# Generated at 2022-06-23 00:47:18.822324
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector(None).name == 'caps'
    assert set(SystemCapabilitiesFactCollector(None)._fact_ids) == set(['system_capabilities',
                                                                        'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:28.313406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    class ECModule:
        def __init__(self):
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None

        def ec_run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd == ['/usr/bin/capsh', '--print']:
                out = "Current: =ep\n"

# Generated at 2022-06-23 00:47:37.900882
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.module_utils import system_capabilities_data
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    # TODO: replace with proper mock -akl
    mod = AnsibleModuleStub(None)
    collector = SystemCapabilitiesFactCollector(mod)
    mod.run_command = system_capabilities_data.get_caps_command
    facts = collector.collect(mod)
    assert facts['system_capabilities_enforced'] == 'True'
    assert facts['system_capabilities'] == ['cap_kill', 'cap_net_bind_service']