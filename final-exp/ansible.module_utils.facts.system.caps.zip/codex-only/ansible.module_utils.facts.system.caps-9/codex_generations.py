

# Generated at 2022-06-23 00:37:41.024617
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    import json

    # Create mock ansible module
    class Module(object):
        def __init__(self):
            self.params={}
            self.run_command_expect_rc=[0]
            self.run_command_expect_out=[0]
            self.run_command_expect_err=[0]

        def run_command(self, cmd, errors='surrogate_then_replace'):
            rc = self.run_command_expect_rc.pop(0)
            out = self.run_command_expect_out.pop(0)
            err = self.run_command_expect_err.pop(0)
            return rc, out, err


# Generated at 2022-06-23 00:37:49.125839
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    MainModuleMock = type('MainModuleMock', (object,), {'run_command': mock_run_command,
                                                         'get_bin_path': mock_get_bin_path})
    module = MainModuleMock()

    collector = SystemCapabilitiesFactCollector()
    collected_facts = collector.collect(module=module)
    assert 'system_capabilities' in collected_facts
    assert collected_facts['system_capabilities'] == ['cap_chown', 'cap_kill', 'cap_setgid']
    assert 'system_capabilities_enforced' in collected_facts
    assert collected_facts['system_capabilities_enforced'] == 'True'


# Generated at 2022-06-23 00:37:56.484588
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock capabilities are hard coded in the method...so really just test
    #       it doesn't crash and that it parses the data to produce a list of
    #       capabilities (not each one itself)
    from ansible.module_utils.facts.collector import BaseFactCollector
    _collector = SystemCapabilitiesFactCollector(BaseFactCollector())
    capabilities = _collector.collect()
    if not isinstance(capabilities, dict):
        raise Exception("capabilities is not a dictionary")
    if not isinstance(capabilities['system_capabilities'], list):
        raise Exception("system_capabilities should be list")
    if not isinstance(capabilities['system_capabilities_enforced'], str):
        raise Exception("system_capabilities_enforced should be a string")



# Generated at 2022-06-23 00:38:05.900435
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils._text import to_bytes
    import os
    import json

    # NOTE: change to 'new_local_tmp_dir()' once it's available in module_utils -akl
    (rc, out, err) = module.run_command(['mktemp', '-d'], check_rc=True)
    test_dir = to_bytes(out).strip()
    test_exec = os.path.join(test_dir, 'foo')

# Generated at 2022-06-23 00:38:17.520562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test for method collect of class SystemCapabilitiesFactCollector '''
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    # NOTE: -> CollectedFacts() for easier mocking -akl
    collected_facts = {}
    module = {
        'get_bin_path': lambda *args: 'capsh',
        'run_command': lambda *args, **kwargs: (
            None,
            'Current: = cap_chown,cap_dac_override,cap_dac_read_search+ep\nBounding set =cap_chown,cap_dac_override,cap_dac_read_search',
            None),
    }

# Generated at 2022-06-23 00:38:19.968141
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    a = SystemCapabilitiesFactCollector()
    assert a

# Generated at 2022-06-23 00:38:28.106518
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector.name, str)
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector().name, str)
    assert SystemCapabilitiesFactCollector()._fact_ids == {'system_capabilities', 'system_capabilities_enforced'} # pylint: disable=protected-access
    assert isinstance(SystemCapabilitiesFactCollector()._fact_ids, set) # pylint: disable=protected-access


# Generated at 2022-06-23 00:38:31.664865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create object of SystemCapabilitiesFactCollector class
    system_caps_fact_collector = SystemCapabilitiesFactCollector()
    # Call method collect of SystemCapabilitiesFactCollector class
    system_caps_fact_collector.collect()

# Generated at 2022-06-23 00:38:33.662879
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Mock the module, collect and assert facts
    pass


# Generated at 2022-06-23 00:38:44.452880
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockOSCommandResult():
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err

    class MockOSModule():
        def __init__(self):
            self.cmds = {}
            self.cmds['capsh'] = '/bin/capsh'
        def get_bin_path(self, path):
            return self.cmds.get(path, None)
        def run_command(self, cmd_args, errors='surrogate_then_replace'):
            # Return output of a cat command for testing purposes
            if cmd_args[0] == '/bin/capsh':
                with open('/proc/version') as f:
                    return MockOSCommandResult(0, f.read(), "")
            return Mock

# Generated at 2022-06-23 00:38:52.205003
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import ansible.module_utils.facts.collectors.system.capabilities
    test_param = ansible.module_utils.facts.collectors.system.capabilities.SystemCapabilitiesFactCollector()
    assert test_param.name == 'caps', "The name should be caps"
    assert sorted(list(test_param._fact_ids)) == sorted(
        ['system_capabilities', 'system_capabilities_enforced']), "The list should be ['system_capabilities', 'system_capabilities_enforced']"


# Generated at 2022-06-23 00:39:04.122516
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:39:08.454653
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c1 = SystemCapabilitiesFactCollector()
    assert c1.name == 'caps'
    assert c1._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert c1.collect() == {}
    assert type(c1.collect()) is dict

# Generated at 2022-06-23 00:39:14.675979
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert 'system_capabilities' in facts._fact_ids
    assert 'system_capabilities_enforced' in facts._fact_ids


# Generated at 2022-06-23 00:39:18.234590
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:22.608837
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:25.775260
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    o = SystemCapabilitiesFactCollector()
    assert o.name == 'caps'

# Generated at 2022-06-23 00:39:30.503217
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test case 1: Default
    test_1 = SystemCapabilitiesFactCollector()
    name = 'caps'
    fact_ids = {'system_capabilities', 'system_capabilities_enforced'}
    assert test_1.name == name
    assert test_1._fact_ids == fact_ids


# Generated at 2022-06-23 00:39:35.866284
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities',
                                        'system_capabilities_enforced'}

# Generated at 2022-06-23 00:39:40.030780
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_caps = SystemCapabilitiesFactCollector()
    assert system_caps.name == 'caps', 'constructor test 1 failed'
    assert system_caps._fact_ids == set(['system_capabilities',
                                         'system_capabilities_enforced']), 'constructor test 2 failed'

# Generated at 2022-06-23 00:39:44.203094
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj, SystemCapabilitiesFactCollector)
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:39:46.074307
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    with pytest.raises(SystemExit):
        SystemCapabilitiesFactCollector.test_collect()



# Generated at 2022-06-23 00:39:58.170798
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: you may need to run 'sudo yum install libcap-devel libcap' to install capsh
    # NOTE: you may want to install 'pip install mock' (for python2) or 'pip3 install mock' (for python 3) to run this unit test.
    # NOTE: you may want to install 'pip install pexpect' (for python2) or 'pip3 install pexpect' (for python 3) to run this unit test.
    import subprocess
    # NOTE: if you are using python3, you can use the function below (instead of the code below the function)
    def run_command(args, errors='replace'):
        process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        result = process.communicate()


# Generated at 2022-06-23 00:40:09.106096
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:40:12.308091
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:16.995411
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mod = None
    collector = SystemCapabilitiesFactCollector()
    assert isinstance(collector, SystemCapabilitiesFactCollector)
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities',
                                   'system_capabilities_enforced'}



# Generated at 2022-06-23 00:40:23.518954
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_module = type('module', (), dict(params=dict(gather_subset=['!all', 'caps'])))
    sp = SystemCapabilitiesFactCollector(fact_module, 'custom_env')
    assert sp.name == 'caps'
    assert sp.valid == True
    assert sp._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:40:27.492639
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Instantiate class SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()

    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:37.997621
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    with open('test.capsh', 'r') as f:
        test_out = f.read()
    # test_out = 'Current: =ep\nBounding set =ep cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap

# Generated at 2022-06-23 00:40:43.280773
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == {'system_capabilities',
                                                           'system_capabilities_enforced'}



# Generated at 2022-06-23 00:40:54.795996
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = create_mock_object('module')
    # mock capsh_path
    mock_module.get_bin_path.return_value = 'path/to/capsh'

    # mock run_command
    rc, out, err = 0, 'Current: = cap_chown,cap_dac_override,cap_sys_admin+p\nBounding set =cap_chown,cap_dac_override,cap_sys_admin\n', ''
    mock_module.run_command.return_value = (rc, out, err)

    facts_dict = SystemCapabilitiesFactCollector().collect(mock_module)
    assert facts_dict['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-23 00:40:58.398850
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:41:02.874937
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Unit test method to test constructor of SystemCapabilitiesFactCollector class
    """
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:41:07.784517
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {
            'system_capabilities',
            'system_capabilities_enforced'
    }



# Generated at 2022-06-23 00:41:15.527415
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create mock SystemCapabilitiesFactCollector
    class MockSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def __init__(self, *args, **kwargs):
            super(self.__class__, self).__init__(*args, **kwargs)
            self.called_run_command = False

        def run_command(self, *args, **kwargs):
            self.called_run_command = True
            return 74, '', ''

    mock_fact_collector = MockSystemCapabilitiesFactCollector()

    # Run collect
    returned_facts = mock_fact_collector.collect()

    # Check collect
    assert mock_fact_collector.called_run_command

    # TODO: assert on returned_facts

# Generated at 2022-06-23 00:41:17.276009
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_caps = SystemCapabilitiesFactCollector()
    assert system_caps

# Generated at 2022-06-23 00:41:24.027463
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = type('TestModule', (object,), {'get_bin_path': lambda self,b: b, 'run_command': lambda self,c: (0, 'stdout', 'stderr')})
    test_module = test_module()
    test_obj = SystemCapabilitiesFactCollector()
    result = test_obj.collect(test_module)
    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result

# Generated at 2022-06-23 00:41:28.129121
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert type(obj) == SystemCapabilitiesFactCollector
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:41:36.233852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    def my_run_command(self, *args, **kwargs):
        class MyRunCommandResult:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

        if args == (['capsh', '--print'],):
            return MyRunCommandResult(0, "Current: =ep cap_net_bind_service,cap_net_raw+eip cap_setfcap=ep", "")
        elif args == (['capsh', '--print'],):
            return MyRunCommandResult(0, "Current: = cap_net_raw+eip cap_setfcap", "")

# Generated at 2022-06-23 00:41:41.293747
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:44.219198
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert fact._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:55.023264
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = 'bin/capsh'
    capsh_cmd = [capsh_path, "--print"]
    rc = 0

# Generated at 2022-06-23 00:41:56.788771
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == "caps"

# Generated at 2022-06-23 00:42:07.576589
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    with patch('os.path.isfile', return_value=True):
        with patch('ansible.module_utils.facts.collector.get_file_content', return_value='Current: =ep') as mock_gfc:
            with patch('ansible.module_utils.facts.collector.run_command', return_value=(0, 'Current: =ep\nBounding set =chown,dac_override,fowner,fsetid,net_bind_service,sys_chroot,setgid,setuid,net_raw,ipc_lock,ipc_owner,sys_ptrace,sys_admin,sys_rawio,sys_pacct,sys_admin\nSecurebits: 00/0x0/1' , '')) as mock_run_cmd:
                mock_module = Mock()
                mock_module

# Generated at 2022-06-23 00:42:13.685114
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Create an instance of SystemCapabilitiesFactCollector
    collector = SystemCapabilitiesFactCollector()

    # Check the name
    assert collector.name == 'caps'

    # Check the fact_ids
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:42:19.847731
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: mock module, collected_facts & run_command args -akl
    # PC:hpe # module = ansible.module_utils.facts.collector.ModuleStub()
    # PC:hpe # module = ansible.module_utils.facts.collector.ModuleStub()
    # PC:hpe # collected_facts = ansible.module_utils.facts.collector.CollectedFa()
    facts_dict = {}
    return facts_dict


# Generated at 2022-06-23 00:42:23.452306
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert(SystemCapabilitiesFactCollector.name == 'caps')
    assert(SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'})
    assert(isinstance(SystemCapabilitiesFactCollector._fact_ids, set))

# Generated at 2022-06-23 00:42:24.817295
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == "caps"

# Generated at 2022-06-23 00:42:33.783161
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False,
    )

    fake_collector = collector.BaseFactCollector()
    fake_collector.frameworks.append('system_capabilities')
    facts_dict = fake_collector.collect(
        module=module,
        collected_facts=None)

    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict

# Generated at 2022-06-23 00:42:45.052556
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    test_module = FakeModule()

# Generated at 2022-06-23 00:42:49.893077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.cache import FactsCache

    def parse_capsh_data(classname):
        if classname == 'SystemCapabilitiesFactCollector':
            return dict(system_capabilities_enforced='False', system_capabilities=['cap_chown'])
        return {}

    class test_module(object):
        def __init__(self, bin_path, cmd=None, errors='surrogate_then_replace'):
            self.cmd = cmd
            self.bin_path = bin_path

# Generated at 2022-06-23 00:42:50.992100
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:54.389948
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:42:57.627405
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:58.699793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-23 00:43:01.896450
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()

    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:09.102925
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''unit tests for SystemCapabilitiesFactCollector.collect'''
    module_mock = MockModule()
    # Test if capsh is not present
    facts_dict = SystemCapabilitiesFactCollector.collect(module_mock)
    assert not facts_dict

    # Test if capsh is present
    module_mock = MockModule(capsh_path='/bin/capsh')
    facts_dict = SystemCapabilitiesFactCollector.collect(module_mock)
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict



# Generated at 2022-06-23 00:43:21.463322
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector

    module = mock.Mock()
    module.get_bin_path.return_value = '/bin/capsh'

# Generated at 2022-06-23 00:43:24.097929
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector._fact_ids == {'system_capabilities',
                                   'system_capabilities_enforced'}

# Generated at 2022-06-23 00:43:27.784988
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        s = SystemCapabilitiesFactCollector()
        assert s.name == 'caps'
        assert set(s._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])
    except:
        assert False


# Generated at 2022-06-23 00:43:39.085658
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test if method collect of class SystemCapabilitiesFactCollector
    return expected dict when capsh_path is a valid path
    """
    # Mock class ModuleReplacer and its method run_command
    class ModuleReplacer():
        def get_bin_path(self, *args, **kwargs):
            return capsh_mock_path

        def run_command(self, *args, **kwargs):
            return 0, capsh_mock_out, None

    # Mock capsh_mock_path and capsh_mock_out
    capsh_mock_path = '/path/to/capsh'

# Generated at 2022-06-23 00:43:42.708580
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert facts._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:43:45.918117
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:49.829532
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:59.446986
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        pass

    module = MockModule()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module)

# Generated at 2022-06-23 00:44:03.426123
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ Test constructor of class SystemCapabilitiesFactCollector """
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'

# Generated at 2022-06-23 00:44:07.653934
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector(None)
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:09.599803
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test that constructor of SystemCapabilitiesFactCollector returns an object
    test = SystemCapabilitiesFactCollector()
    assert test

# Generated at 2022-06-23 00:44:21.232549
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as run
    from ansible.module_utils.facts.utils.caps import MockAnsibleModule
    from ansible.module_utils.facts.utils.caps import Mock_capsh_path

    results = {}
    module = MockAnsibleModule(run, results, run_command=run_command)
    fc = SystemCapabilitiesFactCollector(module)
    collected_facts = fc.collect()
    assert collected_facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-23 00:44:25.055089
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    # Check if facts related to system capabilities is created
    assert 'system_capabilities_enforced' in facts_dict
    assert 'system_capabilities' in facts_dict

# Generated at 2022-06-23 00:44:28.065079
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemcapabilitiesfactcollector = SystemCapabilitiesFactCollector()
    assert systemcapabilitiesfactcollector._fact_ids == {'system_capabilities_enforced', 'system_capabilities'}
    assert systemcapabilitiesfactcollector.name == 'caps'

# Generated at 2022-06-23 00:44:37.222133
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_file_content
    from io import StringIO
    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts.system.caps as caps
    import sys
    import os

    class MockModule(object):
        def __init__(self):
            self.params = FactsParams()
            self.params.content = None
            self.params.gather_subset = ['all']
            self.params.timeout = timeout.Timeout(timeout=5)
            self.params.filter = None

        def get_bin_path(self, name):
            module_path = os.path.dirname(caps.__file__)

# Generated at 2022-06-23 00:44:39.929186
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """SystemCapabilitiesFactCollector.collect returns a dictionary"""
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-23 00:44:43.403285
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps.name == 'caps'
    assert sys_caps.fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:46.490258
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:50.243375
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test if a provided set of facts are initialized properly
    class_facts = ['system_capabilities',
                  'system_capabilities_enforced']
    facts_instance = SystemCapabilitiesFactCollector()
    assert facts_instance._fact_ids == set(class_facts)
    assert facts_instance.name == 'caps'

# Generated at 2022-06-23 00:44:52.234423
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Execute constructor of SystemCapabilitiesFactCollector
    obj = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:44:57.241574
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    t = SystemCapabilitiesFactCollector()
    assert t._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    assert t.name == 'caps'


# Generated at 2022-06-23 00:45:03.705450
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test SystemCapabilitiesFactCollector::collect
    """
    # TODO: make this a real unit test, use mocks
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts

# Generated at 2022-06-23 00:45:13.701867
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import mock
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector

    def get_bin_path_mock(bin):
        return "/bin/{0}".format(bin)

    def run_command_mock(cmd, errors='surrogate_then_replace'):
        return (0, "Current: =ep", "")

    mod_mock = mock.MagicMock()
    mod_mock.get_bin_path.side_effect = get_bin_path_mock
    mod_mock.run_command.side_effect = run_command_mock

    assert "system_capabilities" not in sys.modules

    sys.modules["ansible.module_utils.facts.collector.system_capabilities"] = mock.Mock

# Generated at 2022-06-23 00:45:15.304051
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s is not None

# Generated at 2022-06-23 00:45:23.499705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # monkey patching
    from ansible.module_utils.facts import collector
    collector.BaseFactCollector.run_command = lambda s,x,y: ('', 'Current: =ep\nBounding set =cap_chown,cap_dac_override,cap_dac_read_search\n', '')
    # Test
    inst = SystemCapabilitiesFactCollector()
    fact = inst.collect()
    assert fact['system_capabilities'] == ['cap_chown', 'cap_dac_override', 'cap_dac_read_search']
    assert fact['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:45:28.743124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    data = 'Current: = cap_audit_read+pcap cap_audit_write+p cap_dac_read_search+p cap_dac_override+eip cap_sys_admin+ei ' \
           'cap_sys_chroot+ep cap_sys_ptrace+ep cap_sys_pacct+ep cap_sys_admin+ep cap_sys_boot+ep cap_sys_tty_config+ep ' \
           'cap_mknod+ep cap_lease+ep cap_audit_control+ep '

# Generated at 2022-06-23 00:45:30.695538
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test for method collect of class SystemCapabilitiesFactCollector '''
    # NOTE: write test to validate capability collection -akl
    pass

# Generated at 2022-06-23 00:45:33.292197
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # File is missing, so no results
    test = SystemCapabilitiesFactCollector()
    assert test.collect() == {}
    assert test.name == 'caps'

# test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:37.184149
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Unit test for constructor of class SystemCapabilitiesFactCollector"""
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Unit tests for collect() method of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:45:40.574922
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    capabilities_facts = SystemCapabilitiesFactCollector()

    assert capabilities_facts.name == 'caps'
    assert capabilities_facts._fact_ids == set(['system_capabilities',
                                                'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:41.803877
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:45.338572
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids is not None

# Generated at 2022-06-23 00:45:51.221728
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc is not None
    assert scfc.name == 'caps'
    assert len(scfc._fact_ids) == 2
    assert 'system_capabilities' in scfc._fact_ids
    assert 'system_capabilities_enforced' in scfc._fact_ids

# Generated at 2022-06-23 00:45:59.570277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.caps.SystemCapabilitiesFactCollector import test_SystemCapabilitiesFactCollector_collect_mock_module
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.caps.SystemCapabilitiesFactCollector import test_SystemCapabilitiesFactCollector_collect_mock_output
    validate_collector(test_SystemCapabilitiesFactCollector_collect_mock_module,
              test_SystemCapabilitiesFactCollector_collect_mock_output)


# Generated at 2022-06-23 00:46:10.254606
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: This method will be executed on the Ansible controller, not the managed
    #   machine. Create a fake module.
    from ansible.module_utils.facts import ModuleFactCollector

    # NOTE: This class is difficult to test outside of an Ansible runtime,
    #   especially since it uses module.run_commands() and relies on the
    #   availability of 'capsh' in the runtime environment. Rewrite this
    #   test to use mock subprocess.Popen()/communicate()?
    ac = SystemCapabilitiesFactCollector()
    m = ModuleFactCollector()

    fake_module = mock.MagicMock()
    fake_module.run_command.return_value = (0, "Current: =ep", "")
    a = ac.collect(fake_module)

# Generated at 2022-06-23 00:46:20.066698
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()

# Generated at 2022-06-23 00:46:29.042002
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import pwd
    import stat
    import platform
    import tempfile
    import textwrap
    import subprocess
    import pytest


    #
    # Create a temporary directory
    #
    tmpdir = tempfile.mkdtemp()

    #
    # Make a tempory executable
    #
    capsh_exe = os.path.join(tmpdir, 'capsh')

# Generated at 2022-06-23 00:46:33.962789
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set([
        'system_capabilities',
        'system_capabilities_enforced'])


# Generated at 2022-06-23 00:46:42.231167
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for method collect of class SystemCapabilitiesFactCollector'''

    # Import Python module
    import sys
    import os

    # Ansible facts module is in a subdirectory
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    # Ansible module_utils path is relative
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils'))

    # Module to test
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    # Module mock

# Generated at 2022-06-23 00:46:43.728882
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-23 00:46:48.679596
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Unit test for constructor of class SystemCapabilitiesFactCollector
    """
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert set(SystemCapabilitiesFactCollector._fact_ids) == set(['system_capabilities',
                                                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:51.340741
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(fact_collector, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:46:53.762332
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert isinstance(x, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:46:54.505032
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-23 00:46:57.987156
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:47:02.126742
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities = SystemCapabilitiesFactCollector()
    assert system_capabilities.name == 'caps'
    assert set(system_capabilities._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])
    assert system_capabilities.collect() == {}


# Generated at 2022-06-23 00:47:12.905871
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    # Instantiate a module
    m = BaseFactCollector()
    # Instantiate a collector
    c = get_collector_instance(SystemCapabilitiesFactCollector)
    assert c is not None, \
        'get_collector_instance(SystemCapabilitiesFactCollector) returned None'
    # Make sure the two facts are supported
    assert c is not None, \
        'get_collector_instance(SystemCapabilitiesFactCollector) returned None'
    assert 'system_capabilities' in c.get_fact_ids(), \
        "Failed to find expected fact 'system_capabilities' in %s" % repr(c.get_fact_ids())
   

# Generated at 2022-06-23 00:47:17.177011
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                     'system_capabilities_enforced'}

# Generated at 2022-06-23 00:47:27.082354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.run_command = ['', '']
            self.output = ''


# Generated at 2022-06-23 00:47:29.582661
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert id(s._fact_ids) == id(set(['system_capabilities', 'system_capabilities_enforced']))

# Generated at 2022-06-23 00:47:30.664033
# Unit test for method collect of class SystemCapabilitiesFactCollector