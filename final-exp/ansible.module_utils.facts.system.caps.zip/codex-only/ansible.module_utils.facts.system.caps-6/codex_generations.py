

# Generated at 2022-06-23 00:37:42.471343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system.sysctl import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24
    import ansible.module_utils.six

    module = object()

    class MockAnsibleModule(object):
        def __init__(self, args, kwargs):
            self.__dict__.update(args)
            self.__dict__.update(kwargs)

        def get_bin_path(self, name, opts=None):
            return '/bin/capsh'

        def run_command(self, cmd, **kwargs):
            return (0, 'Current: =ep\n', "")


    collected_facts = {}


# Generated at 2022-06-23 00:37:51.472323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test_module() in module_utils/basic.py will create _ = AnsibleModule(ARGS) -akl
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'Current: =ep\nSecurebits: 00/0x0/1\'b0 secure-noroot, no-setuid-fixup, no-setuid-fixup-shared', '')
    mock_module.get_bin_path.return_value = 'capsh'
    
    # NOTE: expected_facts_dict is from above tmp_out -akl
    expected_facts_dict = {'system_capabilities': [],
                           'system_capabilities_enforced': 'False'}

    # NOTE: setting/restoring '_ansible_module_generated' is a hack to deal with


# Generated at 2022-06-23 00:37:54.687634
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps_fact_collector = SystemCapabilitiesFactCollector()
    assert sys_caps_fact_collector.name == 'caps'
    assert sys_caps_fact_collector._fact_ids == set(['system_capabilities',
                                                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:05.413368
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """collect() -> (system_capabilities_enforced, system_capabilities)"""
    import types
    import mock
    import sys
    # Create a mock version of the ActionBase class
    # with the name run_command that returns a tuple of the rc, stdout, and stderr
    mock_module = mock.Mock(spec=types.ModuleType)
    mock_run_command = mock.Mock(spec=types.MethodType)
    mock_run_command.return_value = (0, 'Current: =ep', '')
    mock_module.run_command = mock_run_command
    mock_module.get_bin_path.return_value = 'capsh_path'

# Generated at 2022-06-23 00:38:13.849346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect(module) == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

    # return capsh_path
    collector.module = MagicMock()
    collector.module.get_bin_path.return_value = 'path'
    # return run_command
    collector.module.run_command.return_value = (0, 'Current: =ep\nBounding set =ep', '')
    # run the test
    assert collector.collect(module) == {"system_capabilities": [], "system_capabilities_enforced": "False"}

    # return capsh_path
    collector.module = MagicMock()
    collector.module.get_bin_path.return_value = 'path'


# Generated at 2022-06-23 00:38:18.493388
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
	fc = SystemCapabilitiesFactCollector()
	assert fc is not None
	assert fc.name == 'caps'
	assert fc._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])
	

# Generated at 2022-06-23 00:38:29.647157
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test if output of capsh --print is changed to a list of capabilities
    and if the flag for enforcing capabilities is set properly.
    """
    def get_bin_path(self, executable):
        """
        Mock and return capsh as if it was present in the PATH.
        """
        return '/bin/capsh'

    def run_command(self, command, **kwargs):
        """
        Mock the output of capsh --print and return it.
        """

# Generated at 2022-06-23 00:38:31.351433
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Proper instantiation of SystemCapabilitiesFactCollector
    assert SystemCapabilitiesFactCollector() != None

# Generated at 2022-06-23 00:38:35.534480
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    assert x.collect() == {}

# Generated at 2022-06-23 00:38:45.849715
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import _get_module_mock

    module = _get_module_mock()

# Generated at 2022-06-23 00:38:51.147083
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class object_to_test():
        module = object()
    system_capabilities = SystemCapabilitiesFactCollector(object_to_test)
    assert system_capabilities.name == 'caps'
    assert system_capabilities._fact_ids == set(['system_capabilities',
                                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:00.898473
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    system_capabilities_enforced and system_capabilities
    """
    # Setup
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.basic import DictMerge
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_bytes
    import mock

    # Exercise
    capsh_path = '/usr/bin/capsh'
    capsh_out = get_file_lines(__file__, 'output_getcap_ep.txt')
    capsh_out = to_bytes(capsh_out)

    test_module = mock.Mock()

# Generated at 2022-06-23 00:39:06.513274
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert c.collect()
    assert c.collect(collected_facts=None)
    assert c.collect(collected_facts=dict())

# Generated at 2022-06-23 00:39:13.346912
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert facts._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:16.777199
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:19.132772
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Test SystemCapabilitiesFactCollector constructor
    """
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:39:22.239449
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    module = object()
    collected_facts = object()
    actual = collector.collect(module, collected_facts)
    assert actual is not None
    assert len(actual) == 0

# Generated at 2022-06-23 00:39:25.879757
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    x = SystemCapabilitiesFactCollector()
    assert 'caps' == x.name
    assert set(['system_capabilities', 'system_capabilities_enforced'] ) == x._fact_ids
    assert None == x.collect()

# Generated at 2022-06-23 00:39:35.325125
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    module = AnsibleModule()
    facts_dict = SystemCapabilitiesFactCollector().collect(module)
    assert facts_dict['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-23 00:39:36.752111
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert(SystemCapabilitiesFactCollector.name == 'caps')

# Generated at 2022-06-23 00:39:39.083372
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'


# Generated at 2022-06-23 00:39:41.356911
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    results = SystemCapabilitiesFactCollector().collect(module=None, collected_facts=None)
    assert results == {}

# Generated at 2022-06-23 00:39:52.989583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need better mocking support so we don't have to do this.
    import tempfile
    # TODO: need to re-enable once the below is done -akl
    return
    capsh_path = tempfile.mkstemp()
    module = Mock(get_bin_path=Mock(return_value=capsh_path),
                  run_command=Mock(return_value=(0, 'Current: =ep', '')))
    facts_dict = SystemCapabilitiesFactCollector().collect(module=module)
    # TODO: current the mock framework doesn't appear to support mocking __getattr__
    # assert facts_dict['system_capabilities_enforced'] is False
    # TODO: need to re-enable once the above is done -akl
    assert facts_dict['system_capabilities'] == []

# Generated at 2022-06-23 00:40:04.851566
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    # test with --print
    capsh_path = '/tmp/capsh'
    module = ansible_facts.AnsibleFactsModule()
    module.run_command = lambda x, **kwargs: (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector()
    new_facts = collector.collect(module=module)
    assert('system_capabilities_enforced' in new_facts)
    assert(new_facts['system_capabilities_enforced'] == 'False')
    assert('system_capabilities' in new_facts)
    assert(new_facts['system_capabilities'] == [])
    module.run_command

# Generated at 2022-06-23 00:40:08.424549
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:18.692643
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:40:24.770957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0,'Current: =ep', b""))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module)
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == "False"



# Generated at 2022-06-23 00:40:25.812988
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'

# Generated at 2022-06-23 00:40:36.581758
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, 'Current: =ep\nBounding set =chown,dac_override,fowner,fsetid,kill,setgid,setuid,setpcap,net_bind_service,net_raw,sys_chroot,mknod,audit_write,setfcap', ''))
    collected_facts = collector.collect(module=module, collected_facts=None)
    assert collected_facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:40:38.071477
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh = SystemCapabilitiesFactCollector()
    assert capsh.name == 'caps'
    assert capsh._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:53.387672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    # NOTE: mock out os module needed in get_caps_data()
    # NOTE: mock out module module needed in get_caps_data()
    # NOTE: test stdout output generated by capsh --print -akl

# Generated at 2022-06-23 00:41:03.383011
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a test mock module and a mock module utility
    # which returns a list of binaries that can be used
    # to check the output of the SystemCapabilitiesFactCollector.collect() method
    m = MockModule()
    m.bin_path = lambda x: '/bin/capsh' if x == 'capsh' else None


# Generated at 2022-06-23 00:41:13.171289
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_module_mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.caps import SystemCapabilitiesFactCollector

    mod = ansible_module_mock.AnsibleModuleMock()
    capsh = '/usr/bin/capsh'
    mod.get_bin_path.return_value = capsh
    mod.run_command.return_value = (0, 'Current: =ep', '')

    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module=mod)

    assert(isinstance(fact_collector, BaseFactCollector))

# Generated at 2022-06-23 00:41:16.220514
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector(None)
    assert a.name == 'caps'
    assert a._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:41:27.344503
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    def get_bin_path(arg):
        bin_paths = {
                      'capsh': '/bin/capsh'
                    }
        return bin_paths.get(arg)


# Generated at 2022-06-23 00:41:35.940693
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts
    import ansible.module_utils
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_text

    class MockAnsibleModule:
        def __init__(self):
            pass

        def fail_json(self, **kwargs):
            print('fail_json called')

        def get_bin_path(self, path, required=False, opt_dirs=None):
            print('get_bin_path called')
            return '/bin/capsh' # NOTE: we assume here that /bin/capsh

# Generated at 2022-06-23 00:41:44.632462
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class MockModule():
        def get_bin_path(self, arg):
            return 'capsh_path'
        def run_command(self, arg, errors):
            return 0, 'Current: =ep', ''

    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

    caps = c.collect(MockModule())
    assert caps['system_capabilities_enforced'] == 'False'
    assert caps['system_capabilities'] == []

# Generated at 2022-06-23 00:41:46.481305
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # collect() returns a dict
    assert isinstance(SystemCapabilitiesFactCollector().collect(), dict)

# Generated at 2022-06-23 00:41:55.858805
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # used for stubbing module.get_bin_path()
    fixture_path = '/path/to/capsh'
    # used for stubbing module.run_command()

# Generated at 2022-06-23 00:41:59.427474
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    fact_collector = SystemCapabilitiesFactCollector(module)
    assert fact_collector.name == "caps"
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:04.596160
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:42:05.176469
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:42:07.332698
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    test_class = SystemCapabilitiesFactCollector()
    assert test_class.collect() == {}

# Generated at 2022-06-23 00:42:12.612665
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sysCap = SystemCapabilitiesFactCollector()
    assert sysCap.name == 'caps'
    assert 'system_capabilities' in sysCap._fact_ids
    assert 'system_capabilities_enforced' in sysCap._fact_ids


# Generated at 2022-06-23 00:42:22.442895
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""


# Generated at 2022-06-23 00:42:29.983244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Init
    module = lambda x: "FAKE_BIN_PATH"
    module.run_command = lambda x, errors='surrogate_then_replace': ("FAKE_RC", "Current: =ep FAKE_OUT", "FAKE_ERR")

    # Test
    f = SystemCapabilitiesFactCollector()
    facts = f.collect(module=module)
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'

    module.run_command = lambda x, errors='surrogate_then_replace':("FAKE_RC", "Current: =ep+i FAKE_OUT", "FAKE_ERR")
    facts = f.collect(module=module)
    assert facts['system_capabilities'] == ['i']

# Generated at 2022-06-23 00:42:32.676372
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap_collector = SystemCapabilitiesFactCollector()
    assert cap_collector is not None

# Generated at 2022-06-23 00:42:44.149291
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Run the collect method with a mocked module and compare the result to expected one.
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import get_ansible_module_wrap
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a system capabilities collector
    capsh_collector = SystemCapabilitiesFactCollector()
    assert isinstance(capsh_collector, BaseFactCollector)

    # Create a fake module
    module = get_ansible_module_wrap()

    # Create a capabilities collector and set its module with the fake module
    collector.collector.add_callback(capsh_collector.collect)
   

# Generated at 2022-06-23 00:42:51.349979
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector.

    Unit test reads lines from capsh.command output data; checks capsh_path and
    functionality of method collect().
    '''

    import os
    import sys
    import tempfile
    import unittest
    import uuid
    import inspect
    #from mock import MagicMock
    #from mock import patch
    #from mock import call
    #from ansible.module_utils import basic

    #sys.modules['ansible'] = MagicMock()
    #sys.modules['ansible.module_utils'] = MagicMock()
    #mock_basic = MagicMock(spec=basic)
    #sys.modules['ansible.module_utils.basic'] = mock_basic
    #mock_module = MagicMock()
    #m

# Generated at 2022-06-23 00:42:56.459724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    module.run_command.return_value = (0, 'Current: =ep', None)
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module, collected_facts=None)
    expected_facts = {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }
    assert facts == expected_facts

# Generated at 2022-06-23 00:43:05.696581
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    import os
    import tempfile
    import shutil
    import json

    class TestModule():
        def __init__(self):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, command, *args, **kwargs):
            return '/bin/capsh'

        def run_command(self, *args, **kwargs):
            return 0, 'Current: =ep', ''

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 00:43:15.076137
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock
    class MockModule(object):
        def __init__(self, capsh_path=None, run_command_return=None):
            self.run_command_return = run_command_return
            self.run_command_called = False
            self.capsh_path = capsh_path

        def get_bin_path(self, arg, *args, **kwargs):
            return self.capsh_path

        def run_command(self, command, errors=None):
            self.run_command_called = True
            return self.run_command_return

    # Return value of run_command
    test_rc = 0
    test_out = 'Current: =ep'
    test_err = ''
    test_run_command_return = (test_rc, test_out, test_err)

   

# Generated at 2022-06-23 00:43:19.984239
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import facts
    fact_collector = SystemCapabilitiesFactCollector(facts)
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:23.791874
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Test the constructor 'SystemCapabilitiesFactCollector'
    """
    assert(SystemCapabilitiesFactCollector.name == 'caps')
    assert(SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']))


# Generated at 2022-06-23 00:43:26.052020
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    myS = SystemCapabilitiesFactCollector()
    assert myS.name == "caps"
    assert len(myS._fact_ids) == 2

# Generated at 2022-06-23 00:43:28.486869
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:36.008210
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    test_SystemCapabilitiesFactCollector_collect: Unit test for method collect of class SystemCapabilitiesFactCollector

    :arg vars:
    :return:
    """
    # Initialize an AnsibleModule object
    module = AnsibleModuleMock()

    # Initialize an instance of SystemCapabilitiesFactCollector
    my_obj = SystemCapabilitiesFactCollector(module)

    # Test method collect of class SystemCapabilitiesFactCollector
    my_obj.collect()



# Generated at 2022-06-23 00:43:44.159464
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Create an instance of SystemCapabilitiesFactCollector
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

    # Assert object attribute `name`
    assert test_SystemCapabilitiesFactCollector.name == 'caps'

    # Assert object attribute `_fact_ids`
    assert test_SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:43:49.886497
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    expected_facts_list = [
        'system_capabilities',
        'system_capabilities_enforced'
    ]
    obj = SystemCapabilitiesFactCollector()
    facts_list = dir(obj)
    found = True
    for fact_id in expected_facts_list:
        if fact_id not in facts_list:
            found = False
    assert found

# Generated at 2022-06-23 00:43:50.906068
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:43:57.974360
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system.system_capabilities as system_capabilities

    caps = system_capabilities.SystemCapabilitiesFactCollector()

    col_fa = {}
    facts_dict = caps.collect(collected_facts=col_fa)

    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict


# Generated at 2022-06-23 00:44:00.145142
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector

    c = collector.get_collector('SystemCapabilitiesFactCollector')
    assert isinstance(c, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:44:03.838212
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_facts = {'system_capabilities': ['cap_chown', 'cap_dac_override'], 'system_capabilities_enforced': 'True'}
    with patch('ansible.module_utils.facts.collector.SystemCapabilitiesFactCollector.collect', return_value=test_facts):
        assert SystemCapabilitiesFactCollector.collect() == test_facts

# Generated at 2022-06-23 00:44:08.519402
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])



# Generated at 2022-06-23 00:44:10.723114
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        x = SystemCapabilitiesFactCollector()
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-23 00:44:22.324255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    # mock 'module.run_command' to return "capsh --print"-like output
    # NOTE: capsh --print | grep CapEff
    # CapEff:  00000000a80425fb
    # CapInh:  0000000000000000
    # CapPrm:  0000000000000000
    # CapBnd:  0000003fffffffff
    # CapAmb:  0000000000000000
    # CapEff: =ep
    # CapInh: =
    # CapPrm: =
    # CapBnd: =ep
    # CapAmb: =
    # CapEff: =
    # CapInh: =
    # CapPrm: =
    # CapBnd: =
    # CapAmb: =
    #

# Generated at 2022-06-23 00:44:24.620237
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert isinstance(collector._fact_ids, set)

# Generated at 2022-06-23 00:44:33.470801
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: format is (module_name, os_name, os_release, data_from_module, data_to_compare, module_args):
    input_data_list = []

    input_data = {'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid',
                                          'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write',
                                          'setfcap'],
                  'system_capabilities_enforced': 'True'}
    module_args = {}
    os_name = 'Linux'
    input_data_list.append(('mocked_module', os_name, None, True, input_data, module_args))

    input

# Generated at 2022-06-23 00:44:40.681115
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    system_capabilities = SystemCapabilitiesFactCollector()
    assert system_capabilities.name == 'caps'
    assert system_capabilities._fact_ids == set(['system_capabilities',
                                                 'system_capabilities_enforced'])
    # NOTE: add test for name of new method, as well as its existence -akl
    assert hasattr(system_capabilities, 'collect')
    assert system_capabilities.collect.__name__ == 'collect'



# Generated at 2022-06-23 00:44:44.960065
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Test for SystemCapabilitiesFactCollector.
    :return:
    """
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:48.619714
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    assert facts_dict.get('system_capabilities') is not None
    assert facts_dict.get('system_capabilities_enforced') is not None


# Generated at 2022-06-23 00:44:52.977378
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    collected_facts = None
    test_instance = SystemCapabilitiesFactCollector()
    assert test_instance.name == 'caps'
    test_instance.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-23 00:45:02.187313
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this unit test has been derived from test_LinuxSystemInfoFactCollector_collect.
    # It is assured that the original test_LinuxSystemInfoFactCollector_collect test still passes
    # (see commit history) -akl
    import sys
    import subprocess

    class MockModule():
        def __init__(self):
            self._bin_paths = {'capsh': '/bin/capsh'}

        def get_bin_path(self, executable):
            return self._bin_paths[executable]

        def run_command(self, args, errors='’surrogate_then_replace’'):
            return (0, 'Current: =ep', '')

    module = MockModule()
    collected_facts = {}

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:45:08.229560
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {'ansible_system_capabilities': ['net_admin', 'dac_read_search'],
                       'ansible_system_capabilities_enforced': 'True'}

    # test that method collect returns correct values
    assert system_capabilities_fact_collector.collect() == collected_facts

# Generated at 2022-06-23 00:45:11.499479
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities = SystemCapabilitiesFactCollector()
    assert system_capabilities.name == 'caps'
    assert system_capabilities._fact_ids == set(['system_capabilities',
                                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:15.257880
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # test for imported base class
    assert type(SystemCapabilitiesFactCollector) == type(BaseFactCollector)


# Generated at 2022-06-23 00:45:16.845695
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sc = SystemCapabilitiesFactCollector()
    assert sc.name == 'caps'

# Generated at 2022-06-23 00:45:20.076305
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:28.361360
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''SystemCapabilitiesFactCollector.collect returns a dictionary
    '''
    module = AnsibleMock()
    module.run_command = run_Command_return
    module.get_bin_path = get_Bin_Path_Return
    collected_facts = { 'system_capabilities': [],
                        'system_capabilities_enforced': []  }
    ansible_facts = {'ansible_system_capabilities': [],
                     'ansible_system_capabilities_enforced': "False" }

    system_facts = SystemCapabilitiesFactCollector(module)
    assert system_facts.collect(module, collected_facts) == ansible_facts
    assert system_facts.name == 'caps'

# Generated at 2022-06-23 00:45:36.107513
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # TEST 1: capsh --print returns non-zero RC
    class MockModule1:
        def get_bin_path(self, path):
            return '/usr/bin/capsh'

        def run_command(self, cmd, errors):
            return 1, "", "None"

        @staticmethod
        def fail_json(msg):
            return msg

    mock_module1 = MockModule1()

    result = SystemCapabilitiesFactCollector().collect(mock_module1)
    assert result == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

    # TEST 2: capsh --print returns unexpected output
    class MockModule2:
        def get_bin_path(self, path):
            return '/usr/bin/capsh'


# Generated at 2022-06-23 00:45:46.903222
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import mock
    import tempfile
    test_module = mock.Mock()
    test_module.run_command.return_value = 0, 'Current: =ep', ''
    test_collector = SystemCapabilitiesFactCollector(test_module)
    test_collector._fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])
    test_collector.collect()
    assert test_collector._fact_ids == set([])

# Generated at 2022-06-23 00:45:52.809518
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_collector = SystemCapabilitiesFactCollector()

    assert test_collector.name == 'caps'
    assert 'system_capabilities' in test_collector._fact_ids
    assert 'system_capabilities_enforced' in test_collector._fact_ids
    assert len(test_collector._fact_ids) == 2

# Generated at 2022-06-23 00:45:56.366605
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:06.108434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import tempfile

    with mock.patch.object(tempfile, 'mkstemp') as mkstemp_mock:
        open_mock = mock.mock_open()
        with mock.patch('ansible.module_utils.facts.collector.open', open_mock, create=True):
            capsh_path = '/bin/capsh'

# Generated at 2022-06-23 00:46:12.584490
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test that SystemCapabilitiesFactCollector is a subclass of BaseFactCollector"""
    sys_caps_facts_obj = SystemCapabilitiesFactCollector()
    # Tests that the object is an instance of a class
    assert isinstance(sys_caps_facts_obj, BaseFactCollector)
    # Tests that object is an instance of SystemCapabilitiesFactCollector
    assert isinstance(sys_caps_facts_obj, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:46:19.694508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import unittest

    class TestModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.run_command_calls = []
            self.run_command_responses = dict()
            self.get_bin_path_returns = dict()

        def get_bin_path(self, name):
            return self.get_bin_path_returns.get(name, None)

        def run_command(self, command, errors='surrogate_then_replace', check_rc=True):
            self.run_command_calls.append(command)
            return self.run_command_responses.get(' '.join(command), (0, '', ''))


# Generated at 2022-06-23 00:46:24.012229
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Input params for the test
    module = None
    collected_facts = None

    # expected result
    expected = {}

    # create instance of the class being tested
    caps_collector = SystemCapabilitiesFactCollector()

    # invoke the method being tested
    result = caps_collector.collect(module, collected_facts)

    # assert the expected results
    assert result == expected

# Generated at 2022-06-23 00:46:35.235403
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestModule(object):
        def __init__(self, check_result):
            self._check_result = check_result
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/capsh'
        def run_command(self, cmd):
            if cmd == ['/usr/bin/capsh','--print']:
                return self._check_result
            raise Exception('Unexpected command: %s' % (cmd))
    # NOTE: more tests needed! -akl
    # NOTE: move to test_facts.py -akl
    # NOTE: test_facts.py: find existing test that checks for 'ansible_system_capabilities'
    # to see if we need to add a new test for it.
    # NOTE: remove fact_ids when this is in place

# Generated at 2022-06-23 00:46:40.864101
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Instantiate the SystemCapabilitiesFactCollector object
    my_obj = SystemCapabilitiesFactCollector()

    # Check the name
    assert my_obj.name == 'caps'

    # Check the fact_ids
    assert my_obj._fact_ids == set(['system_capabilities',
                                    'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:49.190945
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import pytest

    # Mock module object
    class ModuleMock:
        def get_bin_path(self, path, opt_dirs=[]):
            return '/bin/capsh'


# Generated at 2022-06-23 00:46:53.029148
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:03.413967
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock of AnsibleModule
    mock_ansible_module = MockAnsibleModule()
    # Mock of SystemCapabilitiesFactCollector
    mock_system_capabilities_collector = SystemCapabilitiesFactCollector()
    # Creating the mock return values for dict merge
    capabilities_property_dict = {'system_capabilities_enforced': 'True',
                                  'system_capabilities': ['cap_net_bind_service=ep']}
    # Merge mocks

# Generated at 2022-06-23 00:47:06.480538
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_collector = SystemCapabilitiesFactCollector()
    assert my_collector.name == 'caps'
    assert my_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:07.083523
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:47:09.219050
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    c = SystemCapabilitiesFactCollector()
    # TODO: Add test
    #assert c.collect() == 'foobar'

# Generated at 2022-06-23 00:47:18.122584
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # create a subclass of SystemCapabilitiesFactCollector
    class TestSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def __init__(self, *args, **kwargs):

            # store arguments for later usage
            if not hasattr(self, 'collect_args'):
                self.collect_args = []
                self.collect_kwargs = []
            self.collect_args.append(args)
            self.collect_kwargs.append(kwargs)
    return TestSystemCapabilitiesFactCollector


TestSystemCapabilitiesFactCollector = test_SystemCapabilitiesFactCollector_collect()


# Generated at 2022-06-23 00:47:21.287231
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert set(obj._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:47:31.049365
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import unittest
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts import collector

    # NOTE: This is a quick check as the SystemDistributionFactCollector
    #       is not well suited for unit level testing.
    #       Full testing is done in the integration tests
    #       e.g. test/units/module_utils/facts/test_collector.py

    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data', SystemCapabilitiesFactCollector.name)

    # Prepare test data for each os for different scenarios
    # 1. command exists
    # 2. command does not exist
    # 3. command exists but doesn't return expected data
    # 4. command exists but returns error

    # Non-existing

# Generated at 2022-06-23 00:47:40.281187
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda args, errors: (0, capsh_output, '')

        def get_bin_path(self, exe):
            if exe == 'capsh':
                return '/usr/bin/capsh'
            return None

    # NOTE:  want to mock the entire run_command call to not actually call it
    # NOTE:  but use a