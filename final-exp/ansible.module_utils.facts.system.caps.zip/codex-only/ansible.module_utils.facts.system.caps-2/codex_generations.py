

# Generated at 2022-06-23 00:37:33.071478
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'


# Generated at 2022-06-23 00:37:36.572763
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:38.265997
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:37:41.267572
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:37:44.536740
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_class = SystemCapabilitiesFactCollector()
    assert fact_class.name == 'caps'
    assert fact_class._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:37:47.631807
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:37:48.169670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:37:50.713814
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_caps = SystemCapabilitiesFactCollector()
    # check if the name of fact collector is same as class name
    assert system_caps.name == 'caps'

# Generated at 2022-06-23 00:37:52.944379
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:04.694035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import sys

    # Unit test for init
    module = platform
    # No need to patch 'sys' module if it's python2.6 (possible issue with 'unittest' library)
    if int(sys.version[:1]) < 3:
        module = sys

    collector = SystemCapabilitiesFactCollector(module=module)
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

    # No need to patch 'sys' module if it's python2.6 (possible issue with 'unittest' library)
    if int(sys.version[:1]) < 3:
        return

    # Using python3 (dict order is saved)
    from unittest.mock import patch


# Generated at 2022-06-23 00:38:13.517639
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestModule:
        def get_bin_path(self, bin_name):
            return '/bin/capsh'


# Generated at 2022-06-23 00:38:17.382614
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:20.697384
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps' and \
            SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                          'system_capabilities_enforced'}


# Generated at 2022-06-23 00:38:25.071226
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()

    assert collector.name == 'caps'
    assert collector._fact_ids == set([
        'system_capabilities',
        'system_capabilities_enforced'
    ])



# Generated at 2022-06-23 00:38:30.082639
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: method will be called with None for module, we can't do much testing
    collector = SystemCapabilitiesFactCollector()
    collector.collect()
    assert(collector.name == 'caps')
    assert(collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']))
    assert(collector.collect() == {})


# Generated at 2022-06-23 00:38:30.704095
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-23 00:38:31.662594
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:38:34.037185
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    assert(type(facts_dict) is dict)

# Generated at 2022-06-23 00:38:43.675822
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
        import os

        module_mock = type('module', (object,), {
            'run_command': lambda *a, **k: (0, "Current:\t= cap_net_raw+p", ''),
            'get_bin_path': lambda *a, **k: os.path.join('/', 'usr', 'bin', 'capsh')
        })();

        capsh_output = SystemCapabilitiesFactCollector().collect(module=module_mock)
        # mokito-style mocking of the capsh subprocess call
        assert capsh_output['system_capabilities'] == ['cap_net_raw+p']
        assert capsh_output['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:38:48.383470
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    passed_facts = dict()
    collector = SystemCapabilitiesFactCollector()
    fake_module = FakeModule(path=['/usr/sbin'])

    passed_facts = collector.collect(module=fake_module, collected_facts=passed_facts)

    assert passed_facts['system_capabilities_enforced'] == 'True'



# Generated at 2022-06-23 00:38:52.824466
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert hasattr(x, 'collect')


# Generated at 2022-06-23 00:38:57.369355
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    _SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert _SystemCapabilitiesFactCollector.name == 'caps'
    assert _SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:04.005003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("*** Entering test_SystemCapabilitiesFactCollector_collect ***");
    # Test with mocked module
    #mock_module = MagicMock()
    #mock_module.run_command.side_effect = [("", "", "")]
    #mock_module.get_bin_path.side_effect = [""]
    #sut = SystemCapabilitiesFactCollector()
    #sut.collect(mock_module)

# Generated at 2022-06-23 00:39:05.262543
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-23 00:39:12.272062
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:15.688477
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_class = SystemCapabilitiesFactCollector()
    facts_dict = test_class.collect()
    assert facts_dict['system_capabilities'] != 'NA'
    assert facts_dict['system_capabilities_enforced'] != 'NA'


# Generated at 2022-06-23 00:39:16.304115
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:39:27.133755
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    # NOTE: foo=bar fact to force execution
    module = MockModule(run_command_ansible_facts=dict(foo='bar'))

    # stubbed-out instance of SystemCapabilitiesFactCollector
    fact_collector = MockSystemCapabilitiesFactCollector(module=module)
    facts_dict = fact_collector.collect()
    assert 'system_capabilities_enforced' in facts_dict
    assert 'system_capabilities' in facts_dict

# TODO: add test for get_caps_data()/parse_caps_data() -akl

import pytest

# Generated at 2022-06-23 00:39:30.146898
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()

    assert 'caps' == collector.name
    assert set(['system_capabilities', 'system_capabilities_enforced']) == collector._fact_ids


# Generated at 2022-06-23 00:39:35.475069
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:42.521539
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import StringIO
    mock_module = sys.modules[__name__]
    mock_module.run_command.return_value = (0, 'Current: =ep  Bounding set =ep ', '')
    mock_module.get_bin_path.return_value = '/usr/bin/capsh'
    TestSystemCapabilitiesFactCollector = type('TestSystemCapabilitiesFactCollector',
                                                (SystemCapabilitiesFactCollector,),
                                                {'collect': SystemCapabilitiesFactCollector.collect})
    test_fact_collector = TestSystemCapabilitiesFactCollector(mock_module)
    result = test_fact_collector.collect(mock_module)
    out = StringIO.StringIO()
    sys.stdout = out
    print(result)
    sys.stdout = sys

# Generated at 2022-06-23 00:39:50.600662
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    source_name = 'test'
    capsh_path = '/test/capsh'
    module_mock = mock.Mock()
    module_mock.get_bin_path.return_value = capsh_path
    module_mock.run_command.return_value = (0, 'Current: =', '')
    capabilities = SystemCapabilitiesFactCollector(module_mock, source_name)
    assert capabilities.name == 'caps'
    assert capabilities._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:56.427687
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    x = SystemCapabilitiesFactCollector()
    ansible_facts={}
    y = x.collect(collected_facts=ansible_facts)
    
    assert y['system_capabilities_enforced'] != 'NA'
    assert len(y['system_capabilities']) >= 0

# Generated at 2022-06-23 00:40:00.265356
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert set(system_capabilities_fact_collector._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:01.902394
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:40:04.422154
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:08.034588
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:18.665529
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollectionError
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Set up a module object
    #
    # NOTE: this looks bizarre, and almost like something which should be
    #       mocked.  However, this is the right way to go about things; if we
    #       are to have any hope of writing proper unit tests, we have to just
    #       accept that some things are a fact of life, and write the tests
    #       around them.
    #
    #       I see no better way of doing this; we could mock, but that actually
    #       makes things

# Generated at 2022-06-23 00:40:30.512712
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # dummy module, not actually used
    class DummyModule(object):
        def __init__(self):
            self.params = None
            self.exit_args = None
            self.exit_json = None
            self.fail_json = None

        # for mockability to modify args for testing
        def run_command(self, args, **kwargs):
            return self.exit_args, self.exit_json, self.fail_json

        def get_bin_path(self, arg):
            return self.exit_args

    # py26 compatible type-checking
    assert issubclass(SystemCapabilitiesFactCollector, BaseFactCollector)

    # Test SystemCapabilitiesFactCollector.collect()
    #   collect facts and test that they match expected

# Generated at 2022-06-23 00:40:31.599010
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:41.248010
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import os
    import tempfile
    import shutil
    import sys

    if sys.version_info[:2] >= (2, 7):
        import unittest
    else:
        import unittest2 as unittest

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class TestModule(object):

        def __init__(self, params=None, type='command'):
            self.params = params
            self.type = type

        def get_bin_path(self, executable, required=False):
            if required:
                return "/usr/bin/" + executable
            else:
                return None

    class TestFactsCollector(basic.AnsibleModule, collector.BaseFactCollector):
        pass


# Generated at 2022-06-23 00:40:43.852896
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    _store = SystemCapabilitiesFactCollector()
    assert isinstance(_store, BaseFactCollector)



# Generated at 2022-06-23 00:40:48.066933
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:57.931985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def collect(self, module=None, collected_facts=None):
            super(SystemCapabilitiesFactCollector, self).collect(module=None, collected_facts=['system_capabilities_enforced'])

    mockSystemCapabilitiesFactCollector = MockSystemCapabilitiesFactCollector()

    assert mockSystemCapabilitiesFactCollector.collect() == {'system_capabilities': ['=ep', 'chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'net_bind_service', 'sys_chroot', 'mknod', 'audit_write', 'setfcap'], 'system_capabilities_enforced': 'True'}

# Generated at 2022-06-23 00:41:02.221010
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])


# Generated at 2022-06-23 00:41:13.409975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = Mock()
    module_mock.run_command.return_value = (0, "Current: =ep", "")

    module_mock.get_bin_path.return_value = "/usr/bin/capsh"
    collector = SystemCapabilitiesFactCollector(module=module_mock, collected_facts={})
    results = collector.collect()
    assert results['system_capabilities_enforced'] == 'False'
    assert results['system_capabilities'] == []

    module_mock.run_command.return_value = (0, "Current: =ep cap_net_bind_service,cap_net_raw+ep", "")
    collector = SystemCapabilitiesFactCollector(module=module_mock, collected_facts={})
    results = collector.collect()

# Generated at 2022-06-23 00:41:16.433299
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None  # SystemCapabilitiesFactCollector doesn't use this param
    capsh = SystemCapabilitiesFactCollector()
    assert capsh.name == 'caps'
    assert capsh.collect(module) == {}

# Generated at 2022-06-23 00:41:18.135202
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    SystemCapabilitiesFactCollector.collect() Test
    """
    pass

# Generated at 2022-06-23 00:41:28.567870
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    MockedModule = type('MockedModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'Current: = cap_net_bind_service,cap_net_raw+ep', ''),
        'get_bin_path': lambda *args, **kwargs: 'capsh_path'
    })
    module = MockedModule()
    collector = SystemCapabilitiesFactCollector(module=module)
    definitions = collector.collect(module=module)
    assert 'system_capabilities' in definitions
    assert definitions['system_capabilities'] == ['cap_net_bind_service', 'cap_net_raw']
    assert 'system_capabilities_enforced' in definitions
    assert definitions['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:41:32.022043
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:41:38.071624
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # testing this on a non RPM-based system, where the
    # presence of the 'capsh' binary tells us that
    # capabilities are enabled/supported
    capsh_path = '/bin/true'

    CapshRunner = collections.namedtuple('CapshRunner', ['rc', 'out', 'err'])

# Generated at 2022-06-23 00:41:44.309166
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import json
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 00:41:48.233826
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector
    obj = get_collector_instance(SystemCapabilitiesFactCollector)
    assert obj is not None

# Generated at 2022-06-23 00:41:50.817471
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: replace with something better when we implement 'unittest' improvements -akl
    # see https://github.com/ansible/ansible/issues/9069
    pass

# Generated at 2022-06-23 00:42:00.646188
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Instantiate SystemCapabilitiesFactCollector object
    collector = SystemCapabilitiesFactCollector()
    # verify the properties of SystemCapabilitiesFactCollector
    assert collector.name == 'caps', "The name property of SystemCapabilitiesFactCollector should be 'caps', but it is %s" % collector.name
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}, "The _fact_ids property of SystemCapabilitiesFactCollector should be {'system_capabilities', 'system_capabilities_enforced'}, but it is %s" % collector._fact_ids
    assert type(collector.collect()) == dict, "The collect method of SystemCapabilitiesFactCollector should return a dictionary, but it is %s" % type(collector.collect())

# Generated at 2022-06-23 00:42:08.919069
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.capabilities as capabilities
    collector = capabilities.SystemCapabilitiesFactCollector()

    caps = collector._collect_caps()
    assert (isinstance(caps, dict))
    assert(len(caps.keys()) == 2)

    system_caps_enforced = caps['system_capabilities_enforced']
    assert(system_caps_enforced == 'True')

    system_caps = caps['system_capabilities']
    assert(isinstance(system_caps, list))

# Generated at 2022-06-23 00:42:18.199246
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import DummyModule
    module = DummyModule()

    import os
    import json
    # NOTE: taken from the output of 'capsh --print'
    str_capsh = "Current: =ep"
    str_json = json.dumps(dict(rc=0, out=str_capsh, err=""))
    str_path = "/tmp/capsh.json"
    with open(str_path, "w") as f:
        f.write(str_json)
    module.run_command = os.system

    SystemCapabilitiesFactCollector().collect(module, {})
    try:
        os.remove(str_path)
    except:
        pass


if __name__ == "__main__":
    test_SystemCapabilitiesFactCollector_collect

# Generated at 2022-06-23 00:42:22.760826
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:24.543846
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'


# Generated at 2022-06-23 00:42:26.468072
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:37.250234
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils._text import to_bytes, to_native

    # If capsh is found, test the parsing of the output

# Generated at 2022-06-23 00:42:40.681411
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == {'system_capabilities',
                                                     'system_capabilities_enforced'}


# Generated at 2022-06-23 00:42:44.279485
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mod = None
    facts_collector = SystemCapabilitiesFactCollector()
    facts = facts_collector.collect(mod)

    assert isinstance(facts, dict)
    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts

# Generated at 2022-06-23 00:42:46.705422
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_obj = SystemCapabilitiesFactCollector()
    assert test_obj.name == 'caps'
    assert test_obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:49.170664
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:58.163030
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import MockModuleUtilsParameters

    module_params = MockModuleUtilsParameters()
    module_params.bin_path = lambda *args: '/usr/bin/capsh'
    mod = ansible_collector.get_ansible_module(module_params=module_params,
        module_name='test_collector',
        module_args='')


    capscollect = SystemCapabilitiesFactCollector()
    res = capscollect.collect(module=mod)

    assert res['system_capabilities'][0] == 'chown'
    assert res['system_capabilities'][-1] == 'setgid'
    assert res['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-23 00:43:09.174107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path
    def get_bin_path_mock(name):
        name_map = {
            'capsh': 'data/unit/ansible_collections/ansible/builtin/plugins/module_utils/facts/test_capsh'
        }
        return name_map.get(name, None)

    class AnsibleModuleMock:
        def __init__(self, *args, **kwargs):
            self.run_command_rc = 0

        def get_bin_path(self, name):
            return get_bin_path_mock(name)


# Generated at 2022-06-23 00:43:14.761000
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    x = SystemCapabilitiesFactCollector(module)
    assert x.collect()['system_capabilities'][0] == 'chown'
    assert x.collect()['system_capabilities_enforced'] == 'True'

# Mock class for module in SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:43:16.989864
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == "caps"

# Generated at 2022-06-23 00:43:18.316511
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut is not None

# Generated at 2022-06-23 00:43:24.511365
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # create an instance of the SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # compare its name with the expected one
    assert system_capabilities_fact_collector.name == 'caps'
    # compare its fact ids with the expected ones
    assert system_capabilities_fact_collector._fact_ids == {'system_capabilities',
                                                            'system_capabilities_enforced'}

# Generated at 2022-06-23 00:43:28.383696
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    caps_fact_collector = SystemCapabilitiesFactCollector()
    assert caps_fact_collector.name == 'caps'
    assert type(caps_fact_collector._fact_ids) is set
    assert caps_fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:43:39.291076
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector


# Generated at 2022-06-23 00:43:43.826866
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = MagicMock()
    class_under_test = SystemCapabilitiesFactCollector(module)
    assert class_under_test.module == module
    assert isinstance(class_under_test.name, str)
    assert isinstance(class_under_test._fact_ids, set)

# Generated at 2022-06-23 00:43:54.825543
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import mock # python 2.7+
    try: # python 2.6
        import unittest2 as unittest
    except ImportError:
        import unittest

    # fake methods used in testing
    def fake_get_bin_path(self, exe):
        return '/bin/capsh'


# Generated at 2022-06-23 00:44:03.775387
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test collect method of class SystemCapabilitiesFactCollector
    """
    # Define SystemCapabilitiesFactCollector object
    class MockModule:
        def __init__(self):
            self.params = None
        def get_bin_path(self, executable, required=False):
            return "capsh"

# Generated at 2022-06-23 00:44:08.779750
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = MagicMock()
    caps_collector = SystemCapabilitiesFactCollector(module)
    assert caps_collector.name == 'caps'
    assert caps_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:44:20.574038
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this method is not a unit test, it is an integration test
    #       in the style of Ansible's 'module_utils/facts/system/...' -akl
    import os
    import random
    import shutil
    import sys

    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.six.moves import StringIO

    # create a temp dir to hold test modules
    tmpdir = os.path.join(os.path.dirname(__file__),
                          os.path.basename(__file__) + '.d.{0:x}'.format(random.getrandbits(32)))
    os.mkdir(tmpdir)

    # create a minimal module that mocks the args needed by collect()
    mod_args

# Generated at 2022-06-23 00:44:30.233500
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for method collect of class SystemCapabilitiesFactCollector'''
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import sys
    import os

    class MockModule():
        def get_bin_path(self, arg):
            return '/bin/capsh'


# Generated at 2022-06-23 00:44:33.958155
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert c.collect() == {}

# Generated at 2022-06-23 00:44:37.840654
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert result == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'False'
    }

# Generated at 2022-06-23 00:44:43.763474
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.processor.caps import CapabilityProcessor

    my_test_collector = SystemCapabilitiesFactCollector()
    my_test_collector.collect()
    # assert my_test_collector.name == 'caps'


# Generated at 2022-06-23 00:44:46.039754
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test if the constructor works without any arguments
    x = SystemCapabilitiesFactCollector()
    assert isinstance(x, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:44:53.135756
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
        # Get a set of empty module params
        test_module_params = dict()
        # Call the method
        test_caps_collector_fact = SystemCapabilitiesFactCollector()
        result = test_caps_collector_fact.collect(test_module_params)
        # Test if the setup is sane
        assert result == '', "test_SystemCapabilitiesFactCollector_collect() result: '%s' is not empty" % result

# Generated at 2022-06-23 00:45:00.989477
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    import ansible.module_utils.facts.system.caps as caps_mod

    capsh_path = '/bin/capsh'
    enforced_caps = ['cap_fowner=ei']
    enforced = 'True'
    caps_mod.capsh_path = capsh_path
    caps_mod.rc = 0
    caps_mod.out = "Current:\n  =ep cap_fowner=ei"
    caps_mod.err = ""

    # Test
    assert SystemCapabilitiesFactCollector().collect() == {
        'system_capabilities': enforced_caps,
        'system_capabilities_enforced': enforced
    }

# Generated at 2022-06-23 00:45:04.043318
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:07.767901
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = '/usr/bin/capsh'
    module = SystemCapabilitiesFactCollector()
    s = SystemCapabilitiesFactCollector()
    facts_dict = s.collect()
    return facts_dict

# Generated at 2022-06-23 00:45:14.038427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector.fail_on_missing_deps = False
    SystemCapabilitiesFactCollector._fact_ids = set()
    mock_module = Mock()
    mock_module.run_command = Mock(return_value=('', 'Current: =ep', ''))
    mock_module.get_bin_path = Mock(return_value='/bin/capsh')
    assert SystemCapabilitiesFactCollector(mock_module).collect() == \
           {'system_capabilities': [],
            'system_capabilities_enforced': 'False'}
    mock_module.run_command.assert_called_once_with(
        ['/bin/capsh', '--print'], errors='surrogate_then_replace')

# Generated at 2022-06-23 00:45:16.462104
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:24.483510
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import sys

    # Initialization of the class
    object_of_class = SystemCapabilitiesFactCollector()

    # Check the properties of class
    assert object_of_class.name == 'caps'
    # TODO: Enforce the fact_ids to be set
    assert all(item in object_of_class.fact_ids for item in ['system_capabilities', 'system_capabilities_enforced'])

    # Check the type of class
    assert isinstance(object_of_class, SystemCapabilitiesFactCollector)

    # Check the type of objects
    assert isinstance(object_of_class.name, str)
    assert isinstance(object_of_class.fact_ids, set)

    # Check the properties of objects

# Generated at 2022-06-23 00:45:32.703953
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule

    capsh_path = "/bin/capsh"
    capsh_output = b"""Current: =eip
Bounding set =eip
Securebits: 00/0x0/1'b0
secure-noroot: no (unlocked)
secure-no-suid-fixup: no (unlocked)
secure-keep-caps: no (unlocked)
uid=1000(ansible)
gid=1000(ansible)
groups=1000(ansible),4(adm),27(sudo)"""


# Generated at 2022-06-23 00:45:40.720807
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import MythicFactCollector
    # Test 1:
    # Test return value of collect when capsh is not present.
    # Should return an empty dictionary.
    # Setup
    fc = SystemCapabilitiesFactCollector()
    result = fc.collect()
    #Assert
    assert result == {}

    # Test 2:
    # Test return value of collect when capsh is present.
    # Setup
    fc = SystemCapabilitiesFactCollector()
    mc = MythicFactCollector(
        module=None,
        collectors=[fc.name], # NOTE: '['f']' -> '[fc.name]'
        fact_cache={},
        gathered_facts={}
    )
    # Assert
    assert mc.get_facts()

test_SystemCapabilitiesFactCollector_collect

# Generated at 2022-06-23 00:45:50.710492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    import ansible.module_utils.basic
    SystemCapabilitiesFactCollector = get_collector_instance(
        'ansible.module_utils.facts.system.caps')

    def run_command_dummy(args, errors='surrogate_then_replace'):
        return(0, "Current: =ep", "")

    run_command_original = ansible.module_utils.basic.AnsibleModule.run_command
    ansible.module_utils.basic.AnsibleModule.run_command = run_command_dummy
    result = SystemCapabilitiesFactCollector._collect()
    ansible.module_utils.basic.AnsibleModule.run_command = run_command_original


# Generated at 2022-06-23 00:45:54.079993
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:57.597705
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert facts._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:59.098024
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    f = SystemCapabilitiesFactCollector()
    assert isinstance(f.collect(), dict)

# Generated at 2022-06-23 00:46:00.329980
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert instance.name == 'caps'

# Generated at 2022-06-23 00:46:00.954435
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:46:11.519355
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest

    @pytest.fixture
    def FakeModule(object):
        class FakeModule(object):
            def __init__(self):
                self.run_command_results = []
                self.run_command_exceptions = []

            def run_command(self, args, data=None, binary_data=False, errors='surrogate_then_replace'):
                [rc, out, err] = self.run_command_results.pop(0)
                return rc, out, err

            def get_bin_path(self, name, opt_dirs=[]):
                return '/bin/capsh'

        return FakeModule()


# Generated at 2022-06-23 00:46:21.026146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.system_capabilities import system_capabilities_dict
    from ansible.module_utils._text import to_bytes, to_text
    # NOTE: module_utils.common._module_state is not used in the public API
    import ansible.module_utils.common._module_state as module_state
    import os

    # Setup a mock module and module state object
    lsmod_path = os.path.join(os.getcwd(), 'tests', 'unit', 'module_utils', 'facts', 'modules', 'system', 'system_capabilities')

    m = ansible_collector.get

# Generated at 2022-06-23 00:46:28.218333
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of SystemCapabilitiesFactCollector
    sc = SystemCapabilitiesFactCollector()

    # Create a module mock
    mod = AnsibleModuleMock()

    # Set its get_bin_path to return capsh path
    mod.get_bin_path.return_value = "/path/to/capsh"

    # Set its run_command to return the expected data
    mod.run_command.return_value = (0, "Current: =ep", None)

    # Set collected_facts to an empty dictionary
    collected_facts = {}

    # Call the collect method with the module mock and the collected facts
    sc.collect(module=mod, collected_facts=collected_facts)

    # Now assert the value of collected facts
    facts_dict = {}

# Generated at 2022-06-23 00:46:34.898361
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = SystemCapabilitiesFactCollector().collect()

    # We may or may not have capsh on the system
    # But if we do, we should get valid data
    # Test may fail if capsh is installed but broken
    if facts_dict:
        assert 'system_capabilities_enforced' in facts_dict
        assert 'system_capabilities' in facts_dict

# Generated at 2022-06-23 00:46:45.720391
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = mock_run_command
    module.get_bin_path = mock_get_bin_path
    capsh_path = module.get_bin_path('capsh')
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'


# Generated at 2022-06-23 00:46:48.674483
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                        'system_capabilities_enforced'}


# Generated at 2022-06-23 00:46:49.733909
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:47:01.058762
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # NOTE: Use custom class for easier testing
    class MockModule(object):
        def __init__(self):
            self._bin_path = '/usr/bin'
            self.run_command_result = (0, "Current:\t= eip\nCapabilities for test_user:\n = cap_net_bind_service,cap_net_raw+eip", "")

        def get_bin_path(self, path):
            return '/usr/bin/%s' % path

        def run_command(self, cmd, errors):
            return self.run_command_result

    MModule = MockModule()

    # NOTE: Use custom class for easier testing

# Generated at 2022-06-23 00:47:09.504437
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    capsh_path = module.get_bin_path('capsh')
    capsh_rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    assert capsh_rc == 0
    assert 'NA' not in out.split(':')[1]
    enforced = 'True'
    enforced_caps = [i.strip() for i in out.split('=')[1].split(',')]

    collector = SystemCapabilitiesFactCollector()
    data = collector.collect(AnsibleModuleMock(), {})
    assert data['system_capabilities_enforced'] == enforced
    assert data['system_capabilities'] == enforced_caps


# Generated at 2022-06-23 00:47:21.054370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #preset some fakes
    fake_path = "/usr/bin/capsh"

# Generated at 2022-06-23 00:47:30.403635
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import AnsibleFactCollector

    # Instantiate SystemCapabilitiesFactCollector()
    module = AnsibleFactCollector() #mock
    SUT = SystemCapabilitiesFactCollector(module)

    # mock.run_command()
    module.run_command = lambda a,b,c: 'caps', 'no enforced', 'no errors'

    # mock.get_bin_path(''capsh'')
    module.get_bin_path = lambda capsh: capsh

    # SUT.collect()
    collected_facts = SUT.collect()

    # assert
    assert collected_facts['system_capabilities_enforced'] == 'NA'
    assert collected_facts['system_capabilities'] == []