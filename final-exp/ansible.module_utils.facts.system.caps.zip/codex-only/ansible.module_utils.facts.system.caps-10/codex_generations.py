

# Generated at 2022-06-23 00:37:36.629681
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap = SystemCapabilitiesFactCollector()
    assert cap.name == 'caps'
    assert set(['system_capabilities', 'system_capabilities_enforced']) == cap._fact_ids

# Generated at 2022-06-23 00:37:42.718546
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test instantiation of SystemCapabilitiesFactCollector"""
    fc = SystemCapabilitiesFactCollector()
    result = fc.name
    expected_result = 'caps'
    assert result == expected_result
    result = fc._fact_ids
    expected_result = set(['system_capabilities', 'system_capabilities_enforced'])
    assert result == expected_result



# Generated at 2022-06-23 00:37:49.499088
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    module = MockModule()

    caps_fact_collector = SystemCapabilitiesFactCollector()
    # NOTE: return_value as it's a method
    # NOTE: method name is the mocked function name
    module.run_command.return_value = (0, 'Current: =ep', '')

    caps_facts = caps_fact_collector.collect(module=module)

    assert caps_facts['system_capabilities_enforced'] == 'False'
    assert caps_facts['system_capabilities'] == []



# Generated at 2022-06-23 00:37:51.499096
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    for name in obj._fact_ids:
        assert name in obj.collect()

# Generated at 2022-06-23 00:37:53.922218
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:05.110957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  import os
  import pytest
  from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
  from ansible.module_utils.facts.collector import BaseFactCollector
  from ansible.module_utils._text import to_bytes

  if not os.path.exists('/proc/self/status'):
    pytest.skip("process is not running in a Linux environment")

  # test contents of system_capabilities_enforced and system_capabilities
  # system_capabilities_enforced' == 'True'
  # system_capabilities' == '['cap_sys_ptrace']'

# Generated at 2022-06-23 00:38:07.920999
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    print('Testing constructor of class SystemCapabilitiesFactCollector')
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name is not None

# Generated at 2022-06-23 00:38:10.374234
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:10.951422
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:21.551074
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def test_get_caps_data(module=None, errors='surrogate_then_replace'):
        capsh_path = module.get_bin_path('capsh')
        if capsh_path:
            # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
            rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
            return out
        else:
            return ''

    def test_parse_caps_data(caps_data=None):
        enforced_caps = []
        for line in caps_data.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-23 00:38:28.756455
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class TestModule(object):
        pass
    module = TestModule()
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])
    assert not module == collector.module
    assert not collector.collect(module) == collector.collect()
    assert not collector.collect(module) == {}

# Unit tests for SystemCapabilitiesFactCollector.collect()

# Generated at 2022-06-23 00:38:30.797758
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_collector is not None

# Generated at 2022-06-23 00:38:34.607763
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import collector
    # Check that the FactCollector factory creates an instance of NetworkFactCollector
    assert isinstance(collector.FactCollector.factory('cap',''), SystemCapabilitiesFactCollector)


# Generated at 2022-06-23 00:38:43.493324
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Return a fact dict containing facts about system capabilities.
    """
    module = FakeAnsibleModule("FakeAnsibleModule")
    module.get_bin_path = Mock(return_value="capsh_path")
    module.run_command = Mock(return_value=[0, "Current: =ep\nCapInh: =\nCapPrm: =\nCapEff: =\n", ""])
    capsh_facts = SystemCapabilitiesFactCollector.collect(module)
    assert capsh_facts['system_capabilities_enforced'] == "False"
    assert capsh_facts['system_capabilities'] == []


# Generated at 2022-06-23 00:38:47.309454
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module_list = [{'path': 'capsh'}]
    obj = SystemCapabilitiesFactCollector(module_list)
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:52.140542
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create empty module
    module = AnsibleModuleMock()

    # Create object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Collect
    actual_result = system_capabilities_fact_collector.collect(module)

    # Check
    assert actual_result != None

# Generated at 2022-06-23 00:38:58.603273
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_c = SystemCapabilitiesFactCollector()
    assert isinstance(system_c, BaseFactCollector)
    assert hasattr(system_c, 'name') and system_c.name == 'caps'
    assert hasattr(system_c, '_fact_ids') and system_c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:05.441244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    collect = SystemCapabilitiesFactCollector().collect(module)

# Generated at 2022-06-23 00:39:13.823481
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    collected_facts = {}
    result = collect_fact(SystemCapabilitiesFactCollector.collect, module, collected_facts)
    assert result['system_capabilities_enforced'] == 'True'
    assert len(result['system_capabilities']) == 4



# Generated at 2022-06-23 00:39:17.050742
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:20.286190
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector constructor"""
    sut = SystemCapabilitiesFactCollector()
    # TODO: assert class properties
    assert sut is not None

# Generated at 2022-06-23 00:39:25.051227
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_collector = SystemCapabilitiesFactCollector()
    assert facts_collector.name == 'caps'
    assert facts_collector._fact_ids == set(['system_capabilities',
                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:29.466992
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert isinstance(collector, SystemCapabilitiesFactCollector)
    assert isinstance(collector, BaseFactCollector)
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:37.472340
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import textwrap

    # Test capsh path
    with mock.patch('ansible.module_utils.facts.collector.os.path.exists', return_value=True):
        # Test capsh no output
        with mock.patch('ansible.module_utils.facts.collector.subprocess.check_output', return_value='Current: =eip'):
            facts = SystemCapabilitiesFactCollector().collect()
            assert facts['system_capabilities_enforced'] == 'False'
            assert facts['system_capabilities'] == []

        # Test capsh enforced caps output

# Generated at 2022-06-23 00:39:41.690396
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = {}
    test_collector = SystemCapabilitiesFactCollector()
    assert(test_collector.name == 'caps')
    assert(test_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced']))

# Generated at 2022-06-23 00:39:43.657352
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:45.071188
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:39:48.525353
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:52.676482
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mod = SystemCapabilitiesFactCollector()
    assert mod.name == "caps"
    assert mod._fact_ids == set(['system_capabilities','system_capabilities_enforced'])
    assert mod.collect() == {}

# Generated at 2022-06-23 00:40:04.612625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector

    def mock_get_bin_path(app, opt_dirs=[]):
        return '/bin/capsh'

    def mock_run_command(cmd, cwd=None, stdin=None, stdout=None, stderr=None,
                         shell=None, environ_update=None, umask=None,
                         encoding=None, errors=None):
        return (0, 'Current: =ep,cap_net_bind_service,cap_net_raw+ep', '')

    system_caps = SystemCapabilitiesFactCollector()
    system_caps_enforced

# Generated at 2022-06-23 00:40:11.380913
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    capsh_path = '/usr/bin/capsh'
    fact_module_mock = mock.Mock(run_command=mock.Mock(return_value=(0, 'Current: =ep cap_setpcap,cap_setfcap+i', 'some error')))
    fact_collector = SystemCapabilitiesFactCollector()

    result = fact_collector.collect(fact_module_mock)

    fact_module_mock.run_command.assert_called_once_with([capsh_path, '--print'], errors='surrogate_then_replace')
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': ['cap_setpcap', 'cap_setfcap']}

# Generated at 2022-06-23 00:40:11.950744
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:40:16.032249
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    t = SystemCapabilitiesFactCollector()
    assert t.name == 'caps'
    assert 'system_capabilities' in t._fact_ids
    assert 'system_capabilities_enforced' in t._fact_ids


# Generated at 2022-06-23 00:40:19.360447
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:26.302778
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector_obj = SystemCapabilitiesFactCollector()
    fact_ids = fact_collector_obj._fact_ids
    fact_names = fact_collector_obj.name
    assert fact_names == 'caps'
    assert 'system_capabilities_enforced' in fact_ids
    assert 'system_capabilities' in fact_ids
    assert len(fact_ids) == 2

# Generated at 2022-06-23 00:40:29.023613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tmp = SystemCapabilitiesFactCollector()

    assert tmp.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-23 00:40:39.420434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import SYSTEM_COLLECTORS
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collection_order
    from ansible.module_utils.facts.utils import get_file_lines

    # Add to the system collectors so that get_collection_order() picks it up
    _name = 'SystemCapabilitiesFactCollector'
    SYSTEM_COLLECTORS[_name] = 'ansible.module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector'

    # Create its instance
    class_instance = get_collector_instance(_name)

    # Ensure the instance is derived from BaseFactCollector
   

# Generated at 2022-06-23 00:40:43.618940
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect()
    assert facts_dict['system_capabilities_enforced'] == 'NA'
    assert facts_dict['system_capabilities'] == []

# Generated at 2022-06-23 00:40:53.472093
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.params = {}
    capsh_path = module.get_bin_path('capsh')
    if (capsh_path):
        fact_collector = SystemCapabilitiesFactCollector()
        facts = fact_collector.collect(module, MockSystemCapabilitiesFactCollectorFacts())
        assert 'system_capabilities' in facts
        assert 'system_capabilities_enforced' in facts
        assert facts['system_capabilities'] == []
        assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:40:56.095312
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:41:04.427449
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    m = mock.MagicMock()
    m.get_bin_path.return_value = capsh_path
    m.run_command.return_value = (0, 'Current: =ep', '')
    f = SystemCapabilitiesFactCollector()
    assert f.collect(m)[0] == 'system_capabilities_enforced'
    m.get_bin_path.return_value = None
    assert not f.collect()

    m.run_command.return_value = (0, 'Current: cap_chown,cap_dac_override,cap_fowner=ep', '')
    cap_dict = f.collect(m)
    assert cap_dict['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:41:05.115081
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-23 00:41:08.867323
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector()
    assert isinstance(a, BaseFactCollector)
    assert a.name == 'caps'
    assert a._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:41:12.048270
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class_object = SystemCapabilitiesFactCollector()
    assert class_object.name == 'caps'
    assert class_object._fact_ids == set(['system_capabilities',
                                          'system_capabilities_enforced'])


# Generated at 2022-06-23 00:41:21.329184
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Arrange
    module = mock.Mock()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    collector = SystemCapabilitiesFactCollector(module)

    # Act
    result = collector.collect()

    # Assert
    assert result['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:41:25.497265
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps_obj = SystemCapabilitiesFactCollector()
    assert sys_caps_obj.name == 'caps'
    assert sys_caps_obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:41:35.162721
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector

    # NOTE: 'mock' module not included in base python -akl
    # - so mocking via 'unittest.mock' instead, using 'patch()' context manager -akl
    from unittest.mock import patch

    with patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
        with patch.object(AnsibleModule, 'run_command') as mock_run_command:
            mock_get_bin_path.return_value = '/usr/bin/capsh'

            mock_run_command.return_

# Generated at 2022-06-23 00:41:38.911470
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    # Arrange
    test_class = SystemCapabilitiesFactCollector()

    # Assert
    assert test_class



# Generated at 2022-06-23 00:41:49.574672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 00:41:59.928029
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule

    f = SystemCapabilitiesFactCollector()

    base_mock = BaseFactCollector()
    base_mock.get_file_lines = lambda x: ['Current: =ep']
    setattr(builtins, 'super', lambda x, y: base_mock)

    module_mock = AnsibleModule()
    module_mock.get_bin_path = lambda x: '/usr/bin/capsh'

    # No capsh path
    f = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:42:04.680178
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    testobj = SystemCapabilitiesFactCollector()
    assert testobj.name == 'caps'
    assert testobj._fact_ids == {'system_capabilities',
                                 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:42:09.661139
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of SystemCapabilitiesFactCollector
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    # Call collect() method of the instance
    assert systemCapabilitiesFactCollector.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-23 00:42:14.524562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for method collect of class SystemCapabilitiesFactCollector'''
    from ansible.module_utils.facts import collector
    collector.collect2 = collector.collect
    collector.collect = SystemCapabilitiesFactCollector.collect
    try:
        SystemCapabilitiesFactCollector().collect()
    finally:
        collector.collect = collector.collect2

# Generated at 2022-06-23 00:42:17.701621
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Construct class SystemCapabilitiesFactCollector
    test_instance = SystemCapabilitiesFactCollector()
    assert test_instance.name == 'caps'
    assert test_instance._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:42:24.913188
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import unittest
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    class TestModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, name, required=False):
            path = '/bin/' + name
            if name == 'capsh' and os.path.exists(path):
                return path


# Generated at 2022-06-23 00:42:29.038195
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Check if the method collect matches the return data
    cpfc = SystemCapabilitiesFactCollector()
    assert cpfc.collect() == dict(system_capabilities_enforced='NA')

# Generated at 2022-06-23 00:42:30.073602
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-23 00:42:42.263393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess as sp
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import mock
    import os.path

    # ==============================================
    # test for method collect of class SystemCapabilitiesFactCollector
    #
    # case 1 of 2
    # initialize a test SystemCapabilitiesFactCollector
    # then set up mocks for capsh_path and
    # capsh_path + ' --print' and return_value
    #
    # mock capsh_path to return None
    # mock run_command to return return_value
    #
    # call collect()
    # assert facts_dict == expected_facts_dict
    #

# Generated at 2022-06-23 00:42:45.403091
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])



# Generated at 2022-06-23 00:42:47.958437
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test function 'collect' in class SystemCapabilitiesFactCollector"""
    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect()
    assert isinstance(result, dict)
    assert 'system_capabilities_enforced' in result
    assert 'system_capabilities' in result

# Generated at 2022-06-23 00:42:51.354081
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test = SystemCapabilitiesFactCollector()
    assert test.name == 'caps'
    assert test._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])



# Generated at 2022-06-23 00:42:56.450227
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = MockModule()
    test_module.run_command = Mock(return_value=(0, "Current: =ep", ""))
    expected_result = {
        'system_capabilities_enforced': 'False',
        'system_capabilities': [],
    }
    assert(SystemCapabilitiesFactCollector().collect(test_module) == expected_result)


# Generated at 2022-06-23 00:42:59.698673
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:10.614116
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Test that module is not 'None'
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {}

    # Test that system_capabilities_enforced and system_capabilities is
    # present in output from 'caps'
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content
    from ansible.module_utils.facts.utils.capsh import get_caps_data
    from ansible.module_utils.facts.utils.capsh import parse_caps_data
    from ansible.module_utils.facts.utils.capsh import process_caps_data
    capsh_out = get_file_content('../data/capsh_out.txt')

# Generated at 2022-06-23 00:43:22.391584
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule(object):
        def __init__(self, capsh_path, output):
            self._capsh_path = capsh_path
            self._output = output
            self._called_command = None

        def get_bin_path(self, capsh):
            return self._capsh_path

        def run_command(self, command, errors):
            self._called_command = command
            return (0, self._output, "")

    class Args(object):
        def __init__(self):
            self.gather_subset = []

    def test_args():
        return Args()

    def test_ansible_module():
        return None

    # with capsh_path and 'Current: =ep' in output

# Generated at 2022-06-23 00:43:30.955216
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # GIVEN: a SystemCapabilitiesFactCollector object, an AnsibleModule mock, and a list of returned
    #        values for various 'run_command' calls,
    #        and a dict of expected 'facts' to be returned by the collect() method
    #        and a list of expected calls made to AnsibleModule.fail_json(msg)
    collected_facts = {}
    returned_values = [0, 'Current: =ep\n', '']
    expected_facts_dict = {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    expected_fail_json_call_args = []
    return_value_generator = (v for v in returned_values)
    capsh_path = 'dummy-path-to-capsh-binary'

# Generated at 2022-06-23 00:43:38.372666
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mocked_module = MockedModule()
    capsh_path = mocked_module.get_bin_path('capsh')
    if not capsh_path:
        return # skip this test

    caps = SystemCapabilitiesFactCollector()
    assert caps.name is not None
    assert caps.name == 'caps'
    assert 'system_capabilities_enforced' in caps._fact_ids
    assert 'system_capabilities' in caps._fact_ids



# Generated at 2022-06-23 00:43:40.597624
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'


# Generated at 2022-06-23 00:43:43.277833
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Testing the case when module argument is unavailable
    capsh = SystemCapabilitiesFactCollector()
    assert len(capsh.collect()) == 0



# Generated at 2022-06-23 00:43:48.502959
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert set(fact._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])
    assert fact.collect() == {}


# Generated at 2022-06-23 00:43:58.214623
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic

    module = basic.AnsibleModule()

    with patch('ansible_collections.ansible.community.plugins.module_utils.facts.system.system_capabilities.os.path.exists') as exists:
        with patch('ansible_collections.ansible.community.plugins.module_utils.facts.system.system_capabilities.SystemCapabilitiesFactCollector._run_capsh') as _run_capsh:
            exists.return_value = True
            _run_capsh.return_value = (0, "Current:  =ep cap_net_raw+p", "")
            result = SystemCapabilitiesFactCollector.collect

# Generated at 2022-06-23 00:44:02.553839
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    p = SystemCapabilitiesFactCollector()
    assert p.name == 'caps'
    assert sorted(p._fact_ids) == ['system_capabilities', 'system_capabilities_enforced']

# Generated at 2022-06-23 00:44:06.795079
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh = SystemCapabilitiesFactCollector()
    assert capsh.name == 'caps'
    assert capsh._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:14.501207
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.os.linux.tests.unit.compat import unittest
    from ansible_collections.os.linux.tests.unit.compat.mock import patch
    import ansible.module_utils.facts.collectors.system.system_capabilities as which_module

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self._SystemCapabilitiesFactCollector__capsh_path = '/usr/bin/capsh'
            self._SystemCapabilitiesFactCollector__parsed_output = ""


# Generated at 2022-06-23 00:44:14.934076
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass #TODO

# Generated at 2022-06-23 00:44:15.622714
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-23 00:44:16.682101
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:44:27.476910
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.system.system as facts_module
    import ansible.module_utils.facts.cache as cache
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp(prefix='ansible_test_data')

    open(os.path.join(temp_dir, 'capsh'), 'w').close()

    test_collector = SystemCapabilitiesFactCollector()
    test_cache = cache.FactsCache(None, temp_dir, cachedir=temp_dir)
    test_base_collector = BaseFactCollector(module=None, collected_facts=None, facts_cache=test_cache)



# Generated at 2022-06-23 00:44:33.392654
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj.logger, object)
    assert isinstance(obj.name, str)
    assert isinstance(obj.mandatory_facts, set)
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-23 00:44:36.029350
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_obj = SystemCapabilitiesFactCollector()
    assert test_obj.name == 'caps'

# Generated at 2022-06-23 00:44:39.520783
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    e_scfc = SystemCapabilitiesFactCollector()
    assert e_scfc.name == 'caps'
    assert e_scfc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:40.581371
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO
    pass

# Generated at 2022-06-23 00:44:41.188042
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:44:44.657124
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector.collect() == {}

# Generated at 2022-06-23 00:44:47.708678
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test pre-conditions for testing
    assert False, "Test not implemented"

    # Test code path (method code path: code path + test method code path)
    assert False, "Test not implemented"


# Generated at 2022-06-23 00:44:58.931508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Test setup:
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes

    def mock_get_bin_path(name, opts=None, required=False):
        return capsh_path


# Generated at 2022-06-23 00:45:10.517818
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = mock.Mock()
    module.get_bin_path.return_value = '/bin/capsh'

# Generated at 2022-06-23 00:45:13.031156
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:45:23.615862
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.compat.tests import unittest

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = module_run_command
            self.get_bin_path = module_get_bin_path

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.run_command = module_run_command_no_path
            self.get_bin_path = module_get_bin_path

    class AnsibleModuleNoneMock(object):
        def __init__(self):
            return None


# Generated at 2022-06-23 00:45:26.092994
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Check 'system_capabilities' and 'system_capabilities_enforced'"""
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:28.808887
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:31.076640
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Test constructor of class SystemCapabilitiesFactCollector
    '''
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector != None

# Generated at 2022-06-23 00:45:36.619844
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])


# Generated at 2022-06-23 00:45:48.530328
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils import basic

    def run_command(module, cmd, check_rc=True, close_fds=False):
        assert module
        assert cmd
        assert cmd[0] == '/usr/bin/capsh'
        return 0, "Current: =ep\nBounding set =cap_setpcap,cap_net_raw+ep\nSecurebits: 00/0x0/1'b0 secure-noroot\n", ''

    module = AnsibleModuleStub(basic.AnsibleModule, dict(run_command=run_command))

    fact_collector = SystemCapabilitiesFactCollector(module)
    collected_facts = fact_collector.collect()


# Generated at 2022-06-23 00:45:59.909740
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create an instance of the SystemCapabilitiesFactCollector class
    system_capabilities_fact_collector_inst =  SystemCapabilitiesFactCollector()

    # create instances of ModuleStub class
    module_inst =  ModuleStub()

    # create instances of Subprocess class
    subprocess_inst_1 = SubprocessStub(return_value=(0,
        'Current: =ep cap_sys_chroot+eip cap_net_admin+eip cap_net_raw+eip cap_sys_ptrace+eip cap_sys_admin+eip cap_sys_boot+ep cap_sys_nice+ep cap_sys_resource+ep',
        'stderr_string1'
    ))

# Generated at 2022-06-23 00:46:10.533022
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collectors.system.system_capabilities
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector

    # NOTE: avoid actually loading and running the module -akl

# Generated at 2022-06-23 00:46:13.989061
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_collector = SystemCapabilitiesFactCollector()
    assert my_collector.name == 'caps'
    assert my_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:46:14.591390
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:46:22.754355
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # initialize a 'system_capabilities' facts collector instance
    objFactsCollector = SystemCapabilitiesFactCollector()
    
    # make sure the 'name' property is set as expected
    assert objFactsCollector.name == 'caps'
    # make sure the fact_ids property is set as expected
    assert objFactsCollector._fact_ids == set(['system_capabilities',
                                               'system_capabilities_enforced'])
    
    # Note: cannot test the 'collect' method directly as it depends on a module object
    #       to be passed for the 'module' parameter.
    #       The 'collect' method is tested indirectly thru the unit test for the 'populate' method


# Generated at 2022-06-23 00:46:26.872546
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collect = SystemCapabilitiesFactCollector()
    assert collect.name == 'caps'
    assert collect._fact_ids == {'system_capabilities',
                                 'system_capabilities_enforced'}
    assert collect.type == 'capabilities'
    assert isinstance(collect._fact_ids, set)


# Generated at 2022-06-23 00:46:36.917275
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # NOTE: no 'params' expected here -akl
    base_module = MockModule()
    base_module.run_command.return_value = (0, 'Current: =ep', '')
    base_module.get_bin_path.return_value = "capsh_path"
    base_module.ansible_version.get.return_value = "2.1"

    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(base_module)

    base_module.run_command.assert_called_once_with(["capsh_path", "--print"])
    base_module.get_bin_path.assert_called_once_with('capsh')
    assert result == {'system_capabilities': [], 'system_capabilities_enforced': "False"}



# Generated at 2022-06-23 00:46:38.914904
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    t = SystemCapabilitiesFactCollector()
    assert t.name == 'caps'
    assert t.collect() == {}

# Generated at 2022-06-23 00:46:47.817229
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.system.sys_capabilities import SystemCapabilitiesFactCollector
    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            BaseFactCollector.clear_cache()


# Generated at 2022-06-23 00:46:48.677273
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:46:52.000408
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:46:58.289804
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Simulate object creation
    facts_collector = SystemCapabilitiesFactCollector()

    # Test for instance attributes
    assert len(facts_collector._fact_ids) == 2
    assert facts_collector._fact_ids == set(['system_capabilities',
                                             'system_capabilities_enforced'])
    assert facts_collector.name == 'caps'
    assert facts_collector.depends == set()

# Generated at 2022-06-23 00:47:00.465100
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    def test():
        my_collector = SystemCapabilitiesFactCollector()
        assert my_collector.name == 'caps'

# Generated at 2022-06-23 00:47:02.647486
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:12.959030
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            # NOTE: get_bin_path() should never be used in non-delegated tasks -akl
            # NOTE: use a simple if/else for easier mocking -akl
            self.rc = 0
            self.out = 'Current: =ep\nBounding set =caps_bounding\nSecurebits: 00/0x0/1\n secure-noroot, \n secure-no-suid-fixup, \n secure-keep-caps\n test'
            self.err = ''

        def get_bin_path(self, app):
            return '/usr/bin/capsh'

        def run_command(self, cmd, errors):
            self.cmd = cmd
            if self.rc != 0:
                raise Exception()

# Generated at 2022-06-23 00:47:18.915615
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'caps'
    # NOTE: -> set() call? -akl
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:47:22.767273
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """test_SystemCapabilitiesFactCollector - test constructor of class SystemCapabilitiesFactCollector"""

    sys_caps_fact_collector = SystemCapabilitiesFactCollector()
    assert sys_caps_fact_collector is not None, 'test_SystemCapabilitiesFactCollector: constructor of class SystemCapabilitiesFactCollector failed'

# Generated at 2022-06-23 00:47:24.260468
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'

# Generated at 2022-06-23 00:47:24.891912
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:47:32.197728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # we want to return non-empty data (like a real system would) when invoked
    # via unit tests, but we don't want to print the output to stdout
    # how?
    # (1) create a fake module with stdout=None and then run the
    #     SystemCapabilitiesFactCollector.collect method
    # (2) return the facts from the collector's collect method
    # (3) compare facts to expected facts
    #
    # Note:  This test is adhoc and does not run as part of the unit test suite.
    # In the future, we will want to create a mock of the capsh command
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_lines

    module = MockModule()
    sc = SystemCapabilitiesFact

# Generated at 2022-06-23 00:47:33.441290
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector().collect() == {}