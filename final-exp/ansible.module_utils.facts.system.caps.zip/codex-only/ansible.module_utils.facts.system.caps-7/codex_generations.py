

# Generated at 2022-06-23 00:37:36.380537
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-23 00:37:39.433030
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    print(fact.capsh_path)
    assert fact.name == 'caps'


# Generated at 2022-06-23 00:37:46.223629
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class ModuleStub(object):
        def get_bin_path(self, arg):
            return arg
        def run_command(self, arg1, arg2):
            return None
    class CollectedFactsStub(object):
        pass
    tester = SystemCapabilitiesFactCollector()
    assert tester.collect(ModuleStub(), CollectedFactsStub()) == {}
    assert tester.name == 'caps'
    assert tester._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:37:48.999001
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}

# Generated at 2022-06-23 00:37:50.184173
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    SystemCapabilitiesFactCollector()

test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:37:57.886203
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    collected_facts = dict()

    class MockModule():
        def __init__(self, bin_path_return_value):
            self.bin_path_return_value = bin_path_return_value

        def get_bin_path(self, command):
            return self.bin_path_return_value

        def run_command(self,command):
            return (0, 'Current: = ', None)

    # 1. Test, if capsh is not present
    mock_module = MockModule(bin_path_return_value=None)
    facts_dict = collector.collect(mock_module)
    assert facts_dict == {}

    # 2. Test, if capsh is present, but there is no output

# Generated at 2022-06-23 00:38:02.211744
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert len(c._fact_ids) == 2
    assert 'system_capabilities' in c._fact_ids
    assert 'system_capabilities_enforced' in c._fact_ids


# Generated at 2022-06-23 00:38:12.083223
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 00:38:13.174063
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is incomplete and needs to be implemented -akl
    pass

# Generated at 2022-06-23 00:38:13.640466
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:15.711111
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert isinstance(collector, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:38:23.078956
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    module.get_bin_path.return_value = 'capsh'
    module.run_command.side_effect = [(0, 'Current: = cap_chown,cap_dac_override,cap_dac_read_search+ep', '')]

    # NOTE: Don't want to show magic number, but it is fine for this test to verify method behaves correctly
    assert 5 == len(SystemCapabilitiesFactCollector().collect(module, {}))

# Generated at 2022-06-23 00:38:25.521738
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert (fact_collector.name == 'caps')


# Generated at 2022-06-23 00:38:36.492449
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of the class SystemCapabilitiesFactCollector
    '''

    module = Mock()

# Generated at 2022-06-23 00:38:47.185281
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    obj = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:38:58.306039
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()

    class MockPexpect(object):
        def __init__(self, *args, **kwargs):
            pass

        def expect(self, *args, **kwargs):
            return 3


# Generated at 2022-06-23 00:39:07.031928
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json

    class MockModule(object):
        def __init__(self, *args):
            self.called = ''
            self.return_value = ''

        def get_bin_path(self, cmd):
            self.called = 'get_bin_path ' + cmd
            return self.return_value

        def run_command(self, cmd, errors, *args):
            self.called = 'run_command ' + cmd
            return self.return_value

    class MockResult(object):
        def __init__(self, out, err, rc):
            self.called = 'run_command'
            self.stdout = out
            self.stderr = err
            self.rc = rc


# Generated at 2022-06-23 00:39:18.798326
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # set up a mocked ansible module
    class MyModule():
        def get_bin_path(self, name):
            return '/usr/bin/capsh'
        def run_command(self, cmd, **kwargs):
            return 0, 'Current: =ep cap_net_raw+p cap_net_admin+ep cap_net_bind_service+ep', ''
    module = MyModule()
    collected_facts = {}
    scc = SystemCapabilitiesFactCollector(module)
    facts = scc.collect(module, collected_facts)
    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:39:20.760559
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert not SystemCapabilitiesFactCollector().name is None
    assert not SystemCapabilitiesFactCollector()._fact_ids is None

# Generated at 2022-06-23 00:39:31.440347
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class ECModule:
        def get_bin_path(self, arg):
            return '/usr/bin/capsh'
        def run_command(self, arg, errors=None):
            print(arg)

# Generated at 2022-06-23 00:39:43.300574
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.system_capabilities
    from ansible.module_utils.facts import ModuleStub

    m = ModuleStub()
    c = ansible.module_utils.facts.system.system_capabilities.SystemCapabilitiesFactCollector()

    # example output from capsh

# Generated at 2022-06-23 00:39:48.005563
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])



# Generated at 2022-06-23 00:39:52.726012
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:39:54.295508
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:39:57.606330
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:08.708292
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Assert test module
    module_mock = Mock()
    module_mock.run_command.return_value = (1, 'Current: =ep', '')
    module_mock.get_bin_path.return_value = "/path/to/capsh"

    # Create SystemCapabilitiesFactCollector instance to test
    system_caps_fact_collector = SystemCapabilitiesFactCollector()

    # Call the collect method
    all_facts = system_caps_fact_collector.collect(module=module_mock)

    # Assert that the expected keys are present in the facts
    assert set(all_facts.keys()).intersection(system_caps_fact_collector._fact_ids) is not None

    # Assert the values of the facts

# Generated at 2022-06-23 00:40:12.080009
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:40:15.809514
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-23 00:40:17.160750
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == "caps"

# Generated at 2022-06-23 00:40:22.894957
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
  collector = SystemCapabilitiesFactCollector()

  # Check if class variables are initialized properly
  assert collector.name == 'caps'
  assert collector._fact_ids == set(['system_capabilities',
                                     'system_capabilities_enforced'])

  # Check if collect() returns a dict
  collector.collect()

# Generated at 2022-06-23 00:40:24.257942
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:40:35.034031
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest

    from test.support import EnvironmentVarGuard
    from ansible.module_utils import facts

    from ansible.module_utils.facts.collector import BaseFactCollector

    module = 'ansible.module_utils.facts.collector.SystemCapabilitiesFactCollector'

    # get os.environ
    old_environment = os.environ.copy()

    # set os.environ to the test environment
    if sys.version_info < (3,):
        # py2.7
        environment = EnvironmentVarGuard()
    else:
        # py3+
        environment = EnvironmentVarGuard()
        environment.unset("LANG")
        environment.unset("LC_ALL")
        environment.unset("LC_CTYPE")


# Generated at 2022-06-23 00:40:36.419633
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x

# Generated at 2022-06-23 00:40:42.706825
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: n.b. 'None' is used for module since unittest does not provide the
    # object like Ansible does, however, it is not used for this method.
    collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    result = collector.collect(collected_facts=collected_facts)
    assert 'system_capabilities_enforced' in result
    assert 'system_capabilities' in result

# Generated at 2022-06-23 00:40:48.425308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need to mock module.run_command()/'is_exe()' -akl
    assert False # NOTE: implement me


# Generated at 2022-06-23 00:40:59.152004
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: 'module' and 'collected_facts' not used, remove
    capsh_path = '/bin/capsh'
    module = None
    collected_facts = None

    # Mock run_command and call method
    cmd  = [capsh_path, "--print"]
    rc   = 0

# Generated at 2022-06-23 00:41:00.611985
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert set(s.collect()) == set()

# Generated at 2022-06-23 00:41:03.436476
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:41:09.269979
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorModule
    module = CollectorModule()
    module.run_command = lambda args, **kargs: (0, 'Current: =eip', '')
    SystemCapabilitiesFactCollector(module).collect(module)

    module.run_command = lambda args, **kargs: (0, 'Current: =ep', '')
    SystemCapabilitiesFactCollector(module).collect(module)

# Generated at 2022-06-23 00:41:10.826016
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None

# Generated at 2022-06-23 00:41:14.626798
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collect = SystemCapabilitiesFactCollector()
    assert collect.name == 'caps'
    assert len(collect._fact_ids) == 2


# Generated at 2022-06-23 00:41:25.946900
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = Mock()
    module_mock.get_bin_path.return_value = '/sbin/capsh'
    module_mock.run_command.return_value = 0, 'Current: =ep', ''
    # collect facts
    test_collector = SystemCapabilitiesFactCollector(module_mock)
    facts = test_collector.collect()
    # assert facts
    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


if __name__ == "__main__":
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock

# Generated at 2022-06-23 00:41:27.343128
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    unit = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:41:30.661096
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x
    assert x.name == 'caps'
    assert x._fact_ids == {'system_capabilities_enforced', 'system_capabilities'}



# Generated at 2022-06-23 00:41:31.987868
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:41:35.126694
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    # Check name
    assert collector.name == "caps"
    # Check fact ids
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-23 00:41:46.416500
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert isinstance(sut, SystemCapabilitiesFactCollector)
    assert sut.name == 'caps'

# Unit tests for SystemCapabilitiesFactCollector.collect()
# TODO: Mock module, test for valid return codes and
# TODO: test for "Current: =eip" and "Current: =ep" output strings.
# TODO: test for no capsh_path, test for rc != 0 and
# TODO: test for err output
# TODO: Assert cap_data list is same as original capsh stdout output list
# TODO: Assert capability enforcement mode is correct for both cases.
# TODO: Assert capabilities are correct for both cases.

# Generated at 2022-06-23 00:41:56.208874
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = type('module', (object,), {'run_command': mock_run_command})
    collected_facts = {}
    result=SystemCapabilitiesFactCollector().collect(module, collected_facts)
    #print("system_capabilities: %s" % result['system_capabilities'])
    #print("system_capabilities_enforced: %s" % result['system_capabilities_enforced'])
    assert result['system_capabilities'] == ['cap_chown', 'cap_dac_override', 'cap_fowner', 'cap_kill', 'cap_setgid', 'cap_setuid']
    assert result['system_capabilities_enforced'] == 'True'

# Unit test helper function

# Generated at 2022-06-23 00:42:07.152174
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, 'Current: =ep\nBounding set =cap_net_admin,cap_net_raw\nSecurebits: 00/0x0/1''b000\nsecure-noroot: no (unlocked)\nsecure-no-suid-fixup: no (unlocked)\nsecure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)', '')
    collect = mock_module.get_bin_path.return_value = '/usr/bin/capsh'
    collector = SystemCapabilitiesFactCollector(mock_module)
    facts = collector.collect()
    mock_module.get_bin_path.assert_called_with('capsh')
   

# Generated at 2022-06-23 00:42:19.155873
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: add 'module' param to collect() for easier mocking -akl
    # NOTE: add 'collected_facts' param to collect() for easier mocking -akl
    # Note: create object SystemCapabilitiesFactCollector of class SystemCapabilitiesFactCollector
    obj_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    # Note: create object module of class AnsibleModule
    class AnsibleModule(object):
        def __init__(self, argument_spec=None, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False,
                     required_if=None):
            pass

# Generated at 2022-06-23 00:42:27.886133
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.pycompat24 import get_exception

    class TestFactsModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            if cmd == 'capsh':
                return '/usr/bin/capsh'
            else:
                return

        def run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd[0] == '/usr/bin/capsh' and cmd[1] == '--print':
                return (0, 'Current: =ep', '')
            else:
                return

      # Setup the collector
        collector = Collector()
        collector.collect_facter = False
        collector.collect_ohai = False


# Generated at 2022-06-23 00:42:30.661396
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collect_method = SystemCapabilitiesFactCollector().collect
    assert collect_method({}) == {'system_capabilities':[], 'system_capabilities_enforced':'NA'}

# Generated at 2022-06-23 00:42:34.247412
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # No assert for constructor, because it does not return anything

    # Initialize and call constructor of class SystemCapabilitiesFactCollector
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:42:45.481584
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:42:56.347016
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapsFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    import pytest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch


# Generated at 2022-06-23 00:43:07.576343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    name = 'caps'
    with open(os.path.join(mydir, 'capsh.txt'), 'rb') as f:
        capsh_path = os.path.join(mydir, './capsh')
        capsh_data = f.read()
        run_command_mock = MagicMock(return_value=(0, capsh_data, ''))
        module_mock = MagicMock()

        # NOTE: verify_capsh_path=True -akl
        capsh_collector = SystemCapabilitiesFactCollector(module_mock, {'verify_capsh_path':True}, name, 'system_capabilities')
        capsh_collector.run_command = run_command_mock
        collected_facts = capsh_collector.collect()
      

# Generated at 2022-06-23 00:43:15.368515
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class mock_module(object):
        def __init__(self, path, run_cmd):
            self.bin_path = path
            self.run_command = run_cmd

        def get_bin_path(self, _):
            return self.bin_path

    class mock_facts(object):
        def __init__(self):
            self.system_capabilities_enforced = None
            self.system_capabilities = None

    # Case 1: Capabilities not supported on system
    mod = mock_module(None, None)
    facts = mock_facts()
    mySystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(module=mod, collected_facts=facts)
    fact = mySystemCapabilitiesFactCollector.collect()
    assert fact['system_capabilities_enforced'] == 'NA'
    assert fact

# Generated at 2022-06-23 00:43:22.144827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = AnsibleMockModule({'get_bin_path': {'capsh': 'true'},
                                     'run_command': {'rc': 0, 'out': 'Current: =ep', 'err': ''}})

    fc = SystemCapabilitiesFactCollector(mock_module)
    result = fc.collect()

    assert result == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-23 00:43:26.231706
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_fact = SystemCapabilitiesFactCollector()
    assert my_fact.name == 'caps'
    assert set(my_fact._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])
    assert my_fact.collect() == {}

# Generated at 2022-06-23 00:43:28.692912
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = {}
    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(module, collected_facts)
    assert result == {}

# Generated at 2022-06-23 00:43:39.331806
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector as caps_collector
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    ansible_collector.collectors['caps'] = caps_collector

    # NOTE: No capsh path
    module = type('',(object,),dict(run_command=lambda *args: [127,"",""]))
    collected_facts = dict()
    caps_collector_obj = ansible_collector.get_collector('caps')
    facts_dict = caps_collector_obj.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-23 00:43:50.837673
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import TestModule
    import ansible.module_utils.facts.system.caps as sys_cap
    import tempfile
    import os

    # NOTE: Setup a test module with a capsh mock and test data
    capsh_rc = 0
    capsh_stdout = b'''Current: =ep
Bounding set =ep
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root)'''

    capsh_stderr = b''

# Generated at 2022-06-23 00:43:53.740213
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector.priority == 70
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:43:59.082970
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    c = SystemCapabilitiesFactCollector('ansible')
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:06.230285
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Test SystemCapabilitiesFactCollector.collect() """
    from ansible.module_utils.facts.collector import FactsCollector

    # Test initial configuration
    assert FactsCollector._FactCollector['system_capabilities']['class'] == 'SystemCapabilitiesFactCollector'

    # Test that all the required fact names are present in the global dict
    assert len(FactsCollector._FactCollector) == 2
    assert 'system_capabilities' in FactsCollector._FactCollector
    assert 'system_capabilities_enforced' in FactsCollector._FactCollector

    # Test that the global dict has identical keys as SystemCapabilitiesFactCollector._fact_ids
    assert len(FactsCollector._FactCollector) == 2
    for fact_id in SystemCapabilitiesFactCollector._fact_ids:
        assert fact_id in Facts

# Generated at 2022-06-23 00:44:09.423251
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_collector = SystemCapabilitiesFactCollector()
    assert test_collector.name == 'caps'
    assert 'system_capabilities' in test_collector._fact_ids

# Generated at 2022-06-23 00:44:11.023987
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Create test_SystemCapabilitiesFactCollector_collect()
    assert False

# Generated at 2022-06-23 00:44:13.192851
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    m = SystemCapabilitiesFactCollector()
    assert isinstance(m, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:44:18.287805
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_collector.name == 'caps'
    assert set(system_capabilities_collector._fact_ids) == set(['system_capabilities',
                                                                'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:21.279299
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:23.331816
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj, SystemCapabilitiesFactCollector)


# Generated at 2022-06-23 00:44:31.463537
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # arranging
    from ansible.module_utils.facts import ModuleDataCollector

    def get_bin_path(self, executable):
        return None

    def run_command(self, args, errors):
        import subprocess
        out = subprocess.check_output(['capsh', '--print'])
        return 0, out, ''

    m = ModuleDataCollector()
    m.get_bin_path = get_bin_path
    m.run_command = run_command

    # act & assert
    f =  SystemCapabilitiesFactCollector()
    facts = f.collect(module=m)
    expected = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    assert facts == expected, facts

# Generated at 2022-06-23 00:44:35.163963
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Unit test for SystemCapabilitiesFactCollector() class constructor.
    Test for the parameters it takes.
    """

    facts_obj = SystemCapabilitiesFactCollector()
    assert facts_obj.name == 'caps'
    assert facts_obj._fact_ids == set([u'system_capabilities', u'system_capabilities_enforced'])


# Generated at 2022-06-23 00:44:46.293731
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_values = '/usr/bin/caps', ['/usr/bin/caps', '--print'], 'surrogate_then_replace'

        def get_bin_path(self, name, required=False):
            return '/usr/bin/capsh' if name == 'capsh' else None


# Generated at 2022-06-23 00:44:57.682877
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import platform
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    class FakeAnsibleModule:
        def __init__(self):
            self._module = None
            self._result = {}
        @property
        def params(self):
            return {}

# Generated at 2022-06-23 00:45:04.104331
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    This function instantiates class SystemCapabilitiesFactCollector
    and checks if instance created is of instance SystemCapabilitiesFactCollector
    """
    module = {
        'run_command': None,
        'get_bin_path': None
    }

    system_cap_fd = SystemCapabilitiesFactCollector(module)
    assert isinstance(system_cap_fd, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:45:14.040624
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import re
    import tempfile
    import os
    import copy

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.exit_json_called = None
            self.fail_json_called = None
            self.fail_json_called_with = None

        def exit_json(self, changed=False, ansible_facts=dict()):
            self.exit_json_called = True
            self.ansible_facts = ansible_facts

        def fail_json(self, failed_msg=None, **kwargs):
            self.fail_json_called = True
            self.fail_json_called_with = kwargs


# Generated at 2022-06-23 00:45:24.157073
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test SystemCapabilitiesFactCollector.collect().
    This doesn't need to test whether capsh is actually installed
    or the system is actually capable of enforcing capabilities,
    just that the facts are properly collected from capsh output."""
    import sys
    import StringIO
    from ansible.module_utils.basic import ModuleUtilsBasic


# Generated at 2022-06-23 00:45:26.544256
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj.collector == 'SystemCapabilitiesFactCollector'
    assert obj.collectors == ['SystemCapabilitiesFactCollector']
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-23 00:45:34.470289
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Test with module mocked to return capsh data
    # None is returned when 'capsh' binary is not found
    # @classmethod
    def get_bin_path(module_self, binary):
        return 'capsh'

    # @classmethod
    def run_command(module_self, command):
        rc = 0

# Generated at 2022-06-23 00:45:38.221682
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:49.334375
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.caps as caps_mod
    import tempfile
    import os

    tmp_capsh = tempfile.NamedTemporaryFile(delete=True)

# Generated at 2022-06-23 00:45:54.465622
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert (isinstance(SystemCapabilitiesFactCollector(None), SystemCapabilitiesFactCollector))
    assert (SystemCapabilitiesFactCollector(None).name == 'caps')
    assert (SystemCapabilitiesFactCollector(None)._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']))


# Generated at 2022-06-23 00:45:55.985824
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    return obj.name == 'caps'

# Generated at 2022-06-23 00:45:57.205757
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None


# Generated at 2022-06-23 00:46:06.759406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def get_caps_data_mock(module, capsh_path):
        class CapsDataMock:
            def __init__(self):
                self.out = """Current: =ep
Bounding set =cap_audit_write,cap_net_raw+eip
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root),1(bin),2(daemon),3(sys),4(adm),6(disk),10(wheel)
Pending set =<none>
Inheritable set =<none>
Ambient set =<none>"""

        return CapsDataM

# Generated at 2022-06-23 00:46:16.319563
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import DummyModule
    import sys
    import tempfile
    try:
        # Python 2
        from cStringIO import StringIO
    except ImportError:
        # Python 3
        from io import StringIO

    # Define test cases, which each have a tuple of (fact_ids, capsh_output, expected facts)

# Generated at 2022-06-23 00:46:18.440705
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector(None)
    assert isinstance(fact_collector, SystemCapabilitiesFactCollector)

# Generated at 2022-06-23 00:46:27.699515
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    caps_collector = SystemCapabilitiesFactCollector()
    assert(caps_collector.name == 'caps')

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise kwargs['msg']

        def get_bin_path(self, binary):
            if binary == 'capsh':
                return '/bin/capsh'
            else:
                return None


# Generated at 2022-06-23 00:46:37.476735
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.collector import FactsCollector

    def fake_run_command(cmd, errors=None):
        return (0, "Current: =ep", "")

    setattr(ansible_collector, 'run_command', fake_run_command)

    # fake custom module so FactsCollector.collect_from_module() doesn't
    # crash on module 'init' method
    class FakeCustomModule:
        def __init__(self):
            pass

        def get_bin_path(self, module_name):
            return "/bin/capsh"

    facts_collector = FactsCollector(module=FakeCustomModule())
    # avoid warning on class instantiation


# Generated at 2022-06-23 00:46:45.281152
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector

    fake_module = type('FakeModule', (object,), {'get_bin_path': lambda s,p: '/bin/capsh', 'run_command': lambda s,c,e: (0, 'Current: =ep', '')})()
    data = SystemCapabilitiesFactCollector().collect(fake_module)
    assert data.get('system_capabilities_enforced', None) == 'False'
    assert data.get('system_capabilities', None) == []



# Generated at 2022-06-23 00:46:47.984158
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test constructor of SystemCapabilitiesFactCollector class."""
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:46:52.829178
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector._fact_ids, set)
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}

# Generated at 2022-06-23 00:47:03.223379
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mc = SystemCapabilitiesFactCollector()
    mc.module = 'dummy'
    mc.run_command = lambda x: ('', '', True, 0)
    assert mc.collect() == \
            {
                'system_capabilities_enforced': 'False',
                'system_capabilities': []
            }

    mc.run_command = lambda x: ('Current: =ep', '', True, 0)
    assert mc.collect() == \
            {
                'system_capabilities_enforced': 'False',
                'system_capabilities': []
            }

    mc.run_command = lambda x: ('Current: =ep cap_net_bind_service', '', True, 0)

# Generated at 2022-06-23 00:47:04.222936
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass


# Generated at 2022-06-23 00:47:10.501917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command.return_value = 0, 'Current: =ep', None
    mock_module.get_bin_path.return_value = 'fake/capsh'

    get_facts = SystemCapabilitiesFactCollector()

    result = get_facts.collect(mock_module)
    assert result == {'system_capabilities_enforced': 'False',
                      'system_capabilities': []}

if __name__ == '__main__':
    from ansible.module_utils.facts import ansible_collector
    ansible_collector(SystemCapabilitiesFactCollector())

# Generated at 2022-06-23 00:47:21.532301
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collectors.capabilities import FACT_CACHE_FILE
    from ansible.module_utils.facts.collectors.capabilities import FACT_CACHE_MAX_AGE
    from ansible.module_utils.facts import cache
    from tempfile import mkdtemp
    import os
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = mkdtemp()

    # Create a module util mock object
    module = AnsibleModuleUtilMock()
    sys.modules['ansible.module_utils.facts'] = module
    module.FACT_CACHE = {}
    module.FACT_C

# Generated at 2022-06-23 00:47:24.398712
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:31.897732
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import fact_collector

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    fact_collector.add_collector(SystemCapabilitiesFactCollector())

    # NOTE: create a mock class for collected_facts
    # . . . . . . . . . . . . . . . . . . . . . . .
    class MockCollectedFacts:
        def __init__(self):
            self.contents = dict()

        def populate(self):
            return self.contents

    class MockModule:
        def __init__(self):
            self.run_command = MockModuleRunCommand()


# Generated at 2022-06-23 00:47:32.710677
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:47:33.298089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass