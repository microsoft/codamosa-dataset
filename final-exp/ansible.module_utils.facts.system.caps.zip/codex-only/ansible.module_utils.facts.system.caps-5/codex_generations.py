

# Generated at 2022-06-23 00:37:37.373775
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import ansible.module_utils.facts.collector
    import sys
    cap = SystemCapabilitiesFactCollector()

    assert(str(type(cap)) == "<class 'ansible.module_utils.facts.collector.SystemCapabilitiesFactCollector'>")
    assert(cap.name == 'caps')
    assert(type(cap._fact_ids) == type(set()))
    assert(type(cap.collect()) == type(dict()))

# Generated at 2022-06-23 00:37:47.617077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_txt = """
Capabilities for `/usr/bin/ping': = cap_net_admin,cap_net_raw+ep
Capabilities for `/usr/bin/ping': = cap_net_admin,cap_net_raw+pe
"""
    # NOTE: add mock for module.get_bin_path and for module.run_command
    # -akl
    module=None
    collected_facts={}
    scfc = SystemCapabilitiesFactCollector(module=module, collected_facts=collected_facts)
    # NOTE: mock module.run_command
    # -akl

    parsed_caps_data = scfc.parse_caps_data(caps_txt)
    assert parsed_caps_data['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-23 00:37:52.594181
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {'system_capabilities': ['CAP_NET_BIND_SERVICE', 'CAP_NET_BROADCAST'],
                  'system_capabilities_enforced': 'False'}
    module = type('module', (object,), {'run_command': run_command})
    CapshFac = SystemCapabilitiesFactCollector()
    assert CapshFac.collect(module) == facts_dict


# Generated at 2022-06-23 00:37:54.579788
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:37:56.752817
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:38:06.047572
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' SystemCapabilitiesFactCollector.collect() '''

    # Expected results

# Generated at 2022-06-23 00:38:07.869748
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'

# Generated at 2022-06-23 00:38:18.447295
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m_run_command = mock.MagicMock(return_value=(0, 'Current: =ep', None))
    m_get_bin_path = mock.MagicMock(return_value='/bin/capsh')
    m_module = mock.MagicMock()
    m_module.get_bin_path.side_effect = m_get_bin_path
    m_module.run_command.side_effect = m_run_command
    with mock.patch('ansible.module_utils.facts.collector.get_module'):
        s = SystemCapabilitiesFactCollector()
        facts_dict = s.collect(m_module)
        assert facts_dict.has_key('system_capabilities')
        assert facts_dict.has_key('system_capabilities_enforced')

# Generated at 2022-06-23 00:38:23.700144
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_obj = SystemCapabilitiesFactCollector()
    assert fact_obj
    assert fact_obj.name == 'caps'
    assert fact_obj.collect() == {}
    assert not fact_obj.collect()
    assert fact_obj._fact_ids == {'system_capabilities',
                                  'system_capabilities_enforced'}

# Generated at 2022-06-23 00:38:26.708097
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                    'system_capabilities_enforced'])

# Generated at 2022-06-23 00:38:37.349274
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: tmp class to avoid running collect() during module init -akl
    class FakeModule():
        def get_bin_path(self, *args):
            return '/usr/bin/capsh'
        def run_command(self, *args, **kwargs):
            return 0, 'Current: =ep\nSecurebits: 00/0x0/1\'b0 secure-noroot, secure-no-suid-fixup, secure-keep-caps (system_capabilities_enforced=False)', ''

    sut = SystemCapabilitiesFactCollector()
    module = FakeModule()
    result = sut.collect(module)
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-23 00:38:47.583278
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Unit test for method collect of class SystemCapabilitiesFactCollector

    module = get_module_mock()

    def get_bin_path(binary):
        if binary == 'capsh':
            return '/bin/capsh'
        return None

    module.get_bin_path = get_bin_path

    def run_command(command, errors='strict'):
        rc = 0

# Generated at 2022-06-23 00:38:51.031400
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock_module with an example of 'capsh --print' output to parse
    #       to the SystemCapabilitiesFactCollector.collect() method
    #       for testing. -akl
    pass

# Generated at 2022-06-23 00:38:52.702445
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector.collect(None) == {}

# Generated at 2022-06-23 00:38:55.898598
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    t_instance = SystemCapabilitiesFactCollector()
    assert t_instance.name == 'caps'
    assert t_instance._fact_ids == set(['system_capabilities',
                                        'system_capabilities_enforced'])

# Generated at 2022-06-23 00:39:04.014955
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup and run test
    module = AnsibleModuleMock()
    module.run_command.side_effect = [
        (0, 'Current: =ep', ''),
        (0, 'Current: =ep', ''),
        (0, 'Current: =ep', ''),
        (0, 'Current: =ep cap_net_admin,cap_net_raw+eip', ''),
        (127, '', ''),
    ]
    c = SystemCapabilitiesFactCollector()

    # First call, capsh not on system
    result = c.collect(module)
    assert result == {'system_capabilities': None}

    # Second call, capsh returns config
    result = c.collect(module)

# Generated at 2022-06-23 00:39:07.237634
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:39:18.941667
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Set up a mock module
    class MockModule:
        def get_bin_path(self, arg):
            return capsh_path

        def run_command(self, arg):
            return rc, out, err

    module = MockModule()

    capsh_path = 'mock_capsh_path'

    # Test when capsh exists
    rc = 0

# Generated at 2022-06-23 00:39:30.724555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = SystemCapabilitiesFactCollector()
    module = {'SELinux': {'Enabled': 'NA'}, 'Command': ['capsh'], 'get_bin_path': BaseFactCollector.get_bin_path,
              'run_command': test_run_command}

# Generated at 2022-06-23 00:39:42.897786
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = {}

# Generated at 2022-06-23 00:39:44.400319
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-23 00:39:56.636143
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils.capability import get_caps_data, parse_caps_data
    from ansible.module_utils.facts.utils import get_file_content
    import os

    def get_file_content_mock(file_name):
        return "Current: = cap_setpcap+ep"

    def get_caps_data_mock(module, rc, out, err):
        return "= cap_setpcap+ep"

    def parse_caps_data_mock(data):
        parts = data.split('=')
        data = parts[1].strip()
        caps = data.split('+')
        return caps

    # Arrange

# Generated at 2022-06-23 00:40:07.901941
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    # NOTE: 'mock' is required to run these tests elsewhere than in a Vagrant
    #       environment (ie. in Travis, appveyor, etc.) so please keep that
    #       dependency.
    import mock
    import platform
    import syslog
    from ansible.module_utils.facts.collector import BaseFactCollector


# Generated at 2022-06-23 00:40:12.349317
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj1 = SystemCapabilitiesFactCollector()
    assert obj1.name == 'caps'
    assert obj1._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:40:20.112030
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:40:25.710144
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_fact_collector = SystemCapabilitiesFactCollector()
    assert test_fact_collector.name == 'caps'
    assert test_fact_collector._fact_ids == set(['system_capabilities',
                                                 'system_capabilities_enforced'])
    assert test_fact_collector.collect == SystemCapabilitiesFactCollector.collect

# Generated at 2022-06-23 00:40:31.262562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    class TestSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def __init__(self):
            self.collected_facts = {}

    testmodule = TestSystemCapabilitiesFactCollector()
    assert testmodule.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-23 00:40:41.001514
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleFake
    from ansible.module_utils import basic

    class FakeCommand(object):
        def __init__(self):
            self.rc = 0
            self.err = ''

# Generated at 2022-06-23 00:40:49.111159
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert isinstance(instance, SystemCapabilitiesFactCollector)
    assert instance.name == 'caps'
    assert instance._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert instance.collect() == {}

# Generated at 2022-06-23 00:40:57.354282
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    collector.module = type('module', (object,), {
        # run_command will be mocked
        'run_command': lambda self, command, errors: (0, 'Current: =ep\nBounding set =b', ''),
        'get_bin_path': lambda self, command: '/bin/capsh'})
    facts = collector.collect()

    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-23 00:41:01.826778
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Unit test to verify that SystemCapabilitiesFactCollector() returns a
    valid object reference.
    '''
    sys_caps_obj = SystemCapabilitiesFactCollector()

    # test name is the only required attribute
    assert sys_caps_obj.name == 'caps'



# Generated at 2022-06-23 00:41:12.045518
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_name = 'ansible.module_utils.facts.system.linux.caps'
    # Mock run_command()/get_bin_path()
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, 'Current: =ep', None)
    module_mock.get_bin_path.return_value = 'capsh_path'

    # Instantiate SystemCapabilitiesFactCollector
    fact_collector = SystemCapabilitiesFactCollector()
    fact_collector.collect(module=module_mock)

    # Assertions
    module_mock.get_bin_path.assert_called_once_with('capsh')

# Generated at 2022-06-23 00:41:21.329471
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    SystemCapabilitiesFactCollector_module = SystemCapabilitiesFactCollector()
    SystemCapabilitiesFactCollector_module.get_bin_path = lambda x: '/bin/capsh'
    SystemCapabilitiesFactCollector_module.run_command = \
        lambda x, **y: (0, to_bytes('Current: =ep'), '')
    SystemCapabilitiesFactCollector_result = SystemCapabilitiesFactCollector_module.collect(None)
    SystemCapabilitiesFactCollector_expect = {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    assert SystemCapabilitiesFactCollector_result == SystemCapabilitiesFactCollector_expect

# Generated at 2022-06-23 00:41:31.722189
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system
    from ansible.module_utils.facts.system import SystemCapabilitiesFactCollector
    import ansible_collections.ansible.distribution.tests.unit.modules.utils.facts.collector.system
    from ansible_collections.ansible.distribution.tests.unit.modules.utils.facts.collector.system import SystemCapabilitiesFactCollector
    module = ansible_collections.ansible.distribution.tests.unit.modules.utils.facts.collector.system.mock_module
    test_collector_instance = SystemCapabilitiesFactCollector()


# Generated at 2022-06-23 00:41:37.462372
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    BaseFactCollector.get_bin_path = mock_get_bin_path
    BaseFactCollector.run_command = mock_run_command
    result = SystemCapabilitiesFactCollector().collect()
    assert result['system_capabilities_enforced'] == 'True'
    assert result['system_capabilities'] == ['CAP_CHOWN']
    result = SystemCapabilitiesFactCollector().collect()
    assert result['system_capabilities_enforced'] == 'True'
    assert result['system_capabilities'] == []
    result = SystemCapabilitiesFactCollector().collect()
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []


# Generated at 2022-06-23 00:41:39.768157
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-23 00:41:50.339893
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    # capsh_path = None
    module = MockModule(capsh_path=capsh_path, run_command_rc=0, run_command_stdout='Current: =ep')
    fact_collector = SystemCapabilitiesFactCollector()
    res = fact_collector.collect(module=module)
    assert res == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

    module = MockModule(capsh_path=capsh_path, run_command_rc=0, run_command_stdout='')
    fact_collector = SystemCapabilitiesFactCollector()
    res = fact_collect

# Generated at 2022-06-23 00:41:58.846733
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize the system capabilities fact collector
    # Instantiate the SystemCapabilitiesFactCollector class
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Create a mock module
    mock_module = AnsibleModule(argument_spec={})

    # Set the bin path of capsh as 'capsh_path'
    mock_module.bin_path = 'capsh'

    # Run the collect method with the above created mock data and assert the output
    assert system_capabilities_fact_collector.collect(mock_module) == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-23 00:42:08.432555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.capabilities

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ansible.module_utils.facts.system.capabilities.FACTS

        def get_bin_path(self, cmd, opts=None):
            return '/usr/bin/capsh'

        def run_command(self, args, errors='surrogate_then_replace'):
            if args == ['/usr/bin/capsh', '--print']:
                return (0, 'Current: = cap_setgid,cap_setuid\n', '')

# Generated at 2022-06-23 00:42:12.240100
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-23 00:42:13.684465
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-23 00:42:21.725808
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # arrange
    class MockModule:
        """Mock class for ansible.module_utils.facts.module.Module.
        """

        def __init__(self):
            """Initialize MockModule.
            """
            self.params = {}
            self.run_command_results = []
            self.bin_path_results = []

        def get_bin_path(self, param):
            """Mock method to mock module.get_bin_path.
            """
            return self.bin_path_results.pop(0)

        def run_command(self, cmd):
            """Mock method to mock module.run_command.
            """
            return self.run_command_results.pop(0)


# Generated at 2022-06-23 00:42:26.943169
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = '/usr/bin/capsh'
    capsh_output = ""
    capsh_enforced_status = "True"

# Generated at 2022-06-23 00:42:30.222086
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:42.480397
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    cm = basic.AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 00:42:45.335887
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    expected = set(['system_capabilities', 'system_capabilities_enforced'])
    assert sut._fact_ids == expected

# Generated at 2022-06-23 00:42:47.713374
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == "caps"
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:42:48.881141
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: add unit tests
    pass

# Generated at 2022-06-23 00:42:55.807449
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Collect facts related to systems 'capabilities' via capsh.
    """
    # NOTE: python3.5+ mock.mock_open() has been added, which is both
    #  quicker to write and less error prone than the below -akl

    # initialise class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # test method collect of class SystemCapabilitiesFactCollector with n/a
    result = system_capabilities_fact_collector.collect()
    assert {} == result

# Generated at 2022-06-23 00:43:05.250961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Init instance
    instance = SystemCapabilitiesFactCollector()

    # Test out simple case:
    name = 'system_capabilities'
    m = MagicMock(side_effect=lambda x: ('/usr/bin/capsh', 'capsh'))
    instance.get_bin_path = m
    rc = MagicMock(return_value=(0, 'Current: = cap_setuid+eip', ''))
    instance.run_command = rc

    actual = instance.collect(MagicMock())
    expected = {'system_capabilities_enforced': 'True',
                'system_capabilities': ['cap_setuid']}
    assert actual == expected

# Generated at 2022-06-23 00:43:08.500249
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        instance = SystemCapabilitiesFactCollector()
        assert instance.name == 'caps'
        assert instance._fact_ids == set(['system_capabilities',
                                          'system_capabilities_enforced'])
    except:
        pass

# Generated at 2022-06-23 00:43:13.822805
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    fact_collector = SystemCapabilitiesFactCollector(module=module)
    result = fact_collector.collect(module)
    assert 'system_capabilities' in result.keys()
    assert 'system_capabilities_enforced' in result.keys()
    assert result['system_capabilities_enforced'] == 'True'
    assert result['system_capabilities'] == ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'setfcap']

# Generated at 2022-06-23 00:43:18.443876
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert len(c._fact_ids) == 2
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:29.500235
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:43:32.975681
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    print("Testing SystemCapabilitiesFactCollector")
    result = SystemCapabilitiesFactCollector()
    assert result._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-23 00:43:36.841559
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Basic test to confirm the collector is created and initialized as expected
    fc = SystemCapabilitiesFactCollector()

    assert fc is not None
    assert fc.name == 'caps'
    assert fc._fact_ids == { 'system_capabilities', 'system_capabilities_enforced' }



# Generated at 2022-06-23 00:43:42.339331
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-23 00:43:45.244539
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Init a SystemCapabilitiesFactCollector
    obj = SystemCapabilitiesFactCollector()
    # Test the name attribute value
    assert obj.name == 'caps'
    # Test the _fact_ids attribute
    assert sorted(obj._fact_ids) == sorted(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:43:45.848524
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-23 00:43:48.264294
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    TODO: Implement collect() unit test
    """
    # Test code here


# Generated at 2022-06-23 00:43:58.041152
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    #NOTE: 'capsh' is not installed on host, just to test method collect
    #NOTE: I am testing code coverage, so I can't mock capsh.
    class MockModule(object):
        def get_bin_path(self, command, required=False, opt_dirs=[]):
            if command == 'capsh':
                return '/usr/bin/' + command
            return None
        def run_command(self, command):
            if command == ['/usr/bin/capsh', '--print']:
                return 0, CAPSH_OUTPUT, ''
            return 0, '', ''

    class CollectedFacts:
        def __init__(self):
            self.data = {}
        def get(self, key):
            return self.data[key]

# Generated at 2022-06-23 00:43:59.710695
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert isinstance(s, BaseFactCollector)


# Generated at 2022-06-23 00:44:11.344222
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    expected_attr_name = 'name'
    expected_attr_name_value = 'caps'
    expected_attr__fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])

    # Instantiate the 'SystemCapabilitiesFactCollector' class
    obj = SystemCapabilitiesFactCollector()
    
    # Get the name of the class
    cls_name = obj.__class__.__name__

    # Check if the instantiated class is the 'SystemCapabilitiesFactCollector' class
    assert cls_name == 'SystemCapabilitiesFactCollector'

    # Check if the name of the class attribute is the 'name'
    assert hasattr(obj, expected_attr_name)

    # Check if the value of the name of the class attribute is 'caps'
    assert obj.name == expected_attr_

# Generated at 2022-06-23 00:44:22.840598
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("Executing directly...")
    import ansible.module_utils.facts.system.caps as caps
    # TODO: Add test_run_command() or something to module_utils/facts/__init__.py
    caps.run_command = lambda *args, **kwargs: (0, '', '')
    caps.get_bin_path = lambda *args, **kwargs: 'capsh_path'
    caps.run_command = lambda *args, **kwargs: (0,
                                                'Current: =ep',
                                                '')

    fact_collector = SystemCapabilitiesFactCollector()
    assert  fact_collector.collect() == {'system_capabilities': [],
                                         'system_capabilities_enforced': 'False'}


# Generated at 2022-06-23 00:44:25.863905
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    tst_inst = SystemCapabilitiesFactCollector()
    assert tst_inst
    assert tst_inst.name == 'caps'
    assert isinstance(tst_inst._fact_ids, set)

# Generated at 2022-06-23 00:44:32.704306
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:35.658045
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:44:37.595786
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert(SystemCapabilitiesFactCollector)
    cap_col = SystemCapabilitiesFactCollector()

# Generated at 2022-06-23 00:44:48.360443
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class _Module(object):
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, 'Current: =ep\nBounding set =chown,dac_override,fowner,fsetid,kill,setgid,setuid,setpcap,net_bind_service,net_raw,sys_chroot,mknod,audit_write,setfcap\nSecurebits: 00/0x0/1\nsecure-noroot: no (unlocked)\nsecure-no-suid-fixup: no (unlocked)\nsecure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)', ''

        def get_bin_path(self, cmd):
            return True
    
    c = System

# Generated at 2022-06-23 00:44:54.304522
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector_obj = SystemCapabilitiesFactCollector()
    assert fact_collector_obj.name == 'caps'
    assert fact_collector_obj.collector == 'SystemCapabilitiesFactCollector'
    assert fact_collector_obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:03.127368
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class FakeModule:
        def __init__(self, capsh_path='/bin/capsh'):
            self.capsh_path = capsh_path
        def get_bin_path(self, arg):
            return self.capsh_path
        def run_command(self, arg, errors='surrogate_then_replace'):
            return None, None,None

    fm = FakeModule()
    fm.capsh_path = None
    sc_collector = SystemCapabilitiesFactCollector()
    result = sc_collector.collect(fm, {})
    assert result == {}
    assert 'system_capabilities' not in result
    assert 'system_capabilities_enforced' not in result


    fm.capsh_path = '/bin/capsh'

# Generated at 2022-06-23 00:45:11.112749
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import AnsibleModuleFactCollector

    def get_caps_data():
        if sys_type == 'darwin':
            return '', '', 0
        else:
            return 'Current: =ep', '', 0

    def parse_caps_data(out):
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'
                else:
                    enforced = 'True'
                    enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]


# Generated at 2022-06-23 00:45:16.441703
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])

# Generated at 2022-06-23 00:45:25.717691
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test for the method collect of class SystemCapabilitiesFactCollector
        """
    params = dict()
    params['caps.system_capabilities_enforced'] = ['False']

# Generated at 2022-06-23 00:45:28.604756
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    # assign return value to instance of SystemCapabilitiesFactCollector
    test_collector = SystemCapabilitiesFactCollector(module=module)
    print(test_collector.collect())



# Generated at 2022-06-23 00:45:36.383829
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import OMIT_KEYS
    from ansible.module_utils.facts.collector import collector_registry
    import os
    import stat
    import tempfile
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    capsh_path = '/bin/capsh'
    capsh_perms = stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH

# Generated at 2022-06-23 00:45:39.101756
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts import collector
    # NOTE: nothing to mock
    # NOTE: test input params to collect()
    # NOTE: grab output of collect()
    pass

# Generated at 2022-06-23 00:45:49.877781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.distribution \
        import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr \
        import PkgMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr \
        import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.user \
        import UserFactCollector
    from ansible.module_utils.facts.virtual.openstack \
        import OpenStackFactCollector
    from ansible.module_utils._text import to_bytes

    module = Mock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path

# Generated at 2022-06-23 00:46:01.078028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import amazon
    from ansible.module_utils.facts import comparison
    from ansible.module_utils.facts import debian
    from ansible.module_utils.facts import redhat
    from ansible.module_utils.facts import solaris

    ansible_module_mock = comparison.AnsibleModuleMock()


# Generated at 2022-06-23 00:46:09.041112
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-23 00:46:14.314212
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector

    import ansible.module_utils.facts.collector

    config = {"module_setup": True, "gather_subset": ["all", "capabilities"]}

    module = ansible.module_utils.facts.collector.get_module(config)

    bc = SystemCapabilitiesFactCollector()
    bc.collect(module)

# Generated at 2022-06-23 00:46:21.856527
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system.caps as caps_utils

    # Stub of Capsh binary data

# Generated at 2022-06-23 00:46:32.679441
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class module:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return 'some/path'

        def run_command(self, cmd, environ_update=None, check_rc=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_batch=None, errors='surrogate_then_replace'):
            return (0, '', '')

    collected_facts = {}
    scc = SystemCapabilitiesFactCollector()
    results = scc.collect(module(), collected_facts)

    assert 'system_capabilities' in results.keys()
    assert 'system_capabilities_enforced' in results.keys()

# Generated at 2022-06-23 00:46:41.420338
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test for method SystemCapabilitiesFactCollector.collect
    
    _collect_capsh_data() is called before any tests using the patch decorator
    this means that we need to use the monkeypatch fixture to regroup the
    original function and all the patches to restore the original function
    """
    
    # Mock the methods and values used by the method being tested
    def get_bin_path(path):
        return "/bin/capsh"
        
    def run_command(command, errors="surrogate_then_replace"):
        """
        Mock the run_command method
        """

# Generated at 2022-06-23 00:46:52.338489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Unit test for method SystemCapabilitiesFactCollector.collect """
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.virtual.systemd import SystemdVirtual
    module_mock = cache.get_module_mock()

# Generated at 2022-06-23 00:46:55.705596
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    return


# Generated at 2022-06-23 00:46:57.939187
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector is not None

# Generated at 2022-06-23 00:47:00.117621
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facter = SystemCapabilitiesFactCollector()
    print(facter._fact_ids)
    print(facter.name)

# Generated at 2022-06-23 00:47:02.991438
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    obj = SystemCapabilitiesFactCollector()

    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-23 00:47:06.937683
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    expected_fact_ids = {'system_capabilities', 'system_capabilities_enforced'}
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == expected_fact_ids

# Generated at 2022-06-23 00:47:16.050808
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
        import os
        import platform
        import sys
        import tempfile
        tmp = tempfile.mkdtemp()
        sys.modules['ansible.module_utils.facts.collector.platform'] = platform
        sys.modules['ansible.module_utils.facts.collector.os'] = os
        sys.modules['ansible.module_utils.facts.collector.sys'] = sys
        sys.modules['ansible.module_utils.facts.collector.tempfile'] = tempfile

        class ModuleMock():
            __file__ = tmp
            def get_bin_path(self, name):
                return '/bin/capsh'

            @staticmethod
            def run_command(args, errors='surrogate_then_replace'):
                class Object(object):
                    pass
                o = Object()

# Generated at 2022-06-23 00:47:27.523232
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test with module and collected_facts equal to None
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert obj.collect() == {}

    # Test with module equal to None and collected_facts not equal to None
    collected_facts = {'gather_subset': ['network']}
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert obj.collect(collected_facts=collected_facts) == {}

    # Test with module not equal to None and collected_facts equal to None
    import ansible.module_utils.facts.system

# Generated at 2022-06-23 00:47:38.457049
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test if the SystemCapabilitiesFactCollector works with valid data.
    '''

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self, return_value=None):
            self.return_value = return_value

        @staticmethod
        def get_bin_path(name, opts=None, required=False):
            return '/usr/bin/test'

        def run_command(self, args, **kwargs):
            return (0, to_bytes('\n'.join(self.return_value)), '')
