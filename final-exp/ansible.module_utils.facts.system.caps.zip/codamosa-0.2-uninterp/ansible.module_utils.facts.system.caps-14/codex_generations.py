

# Generated at 2022-06-17 01:34:57.443527
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() -akl
    module = None
    # NOTE: mock run_command() -akl
    capsh_path = '/bin/capsh'
    rc = 0

# Generated at 2022-06-17 01:35:04.614517
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:05.609382
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub -akl
    pass

# Generated at 2022-06-17 01:35:09.765358
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: add unit test for method collect of class SystemCapabilitiesFactCollector
    pass

# Generated at 2022-06-17 01:35:21.131043
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not run by 'make unit-test'
    #       run it manually with 'python -m test.units.module_utils.facts.system.caps'
    #       or 'python -m test.units.module_utils.facts.system.caps -v'
    import sys
    import unittest
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_caps_enforced as test_collect_caps_enforced
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_caps_not

# Generated at 2022-06-17 01:35:22.080003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with real test -akl
    assert True

# Generated at 2022-06-17 01:35:31.297160
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:41.962623
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test with capsh_path
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/capsh')
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module=module)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []

    # Test without capsh_path
    module = MockModule()
    module.get_bin_path = Mock(return_value=None)
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module=module)

# Generated at 2022-06-17 01:35:53.379068
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector

    module = AnsibleModuleStub()

# Generated at 2022-06-17 01:36:04.334554
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:36:14.484307
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:20.050845
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:36:28.323149
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:36:37.036067
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_no_log'] = False
            self.params['_ansible_debug'] = False
            self.params['_ansible_diff'] = False
            self.params['_ansible_check_mode'] = False
            self.params['_ansible_remote_tmp'] = '/tmp'
            self.params['_ansible_keep_remote_files'] = False
            self.params['_ansible_tmpdir'] = '/tmp'
            self.params['_ansible_socket'] = None
           

# Generated at 2022-06-17 01:36:40.400927
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: no test for this fact yet -akl
    pass

# Generated at 2022-06-17 01:36:48.513815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data
    from ansible.module_utils.facts.collector.system import get_caps_data_from_file
    from ansible.module_utils.facts.collector.system import parse_caps_data_from_file
    from ansible.module_utils.facts.collector.system import get_caps_data_from_file_with_enforced
    from ansible.module_utils.facts.collector.system import parse_caps_data_from_file_with_enforced

# Generated at 2022-06-17 01:36:51.502827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:36:59.570856
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_id
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 01:37:12.123443
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:37:19.380513
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test_module_utils.get_module_path() for easier mocking -akl
    module = get_module_path('ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector')
    # NOTE: test_module_utils.get_module_path() for easier mocking -akl
    capsh_path = get_module_path('ansible.module_utils.facts.system.caps.capsh')
    # NOTE: test_module_utils.get_module_path() for easier mocking -akl
    capsh_out = get_module_path('ansible.module_utils.facts.system.caps.capsh_out')
    # NOTE: test_module_utils.get_module_path() for easier mocking -akl

# Generated at 2022-06-17 01:37:29.679224
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary capsh
    capsh_path = os.path.join(tmpdir, 'capsh')

# Generated at 2022-06-17 01:37:40.271598
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:37:48.289123
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.dist

# Generated at 2022-06-17 01:37:58.872508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collector_status_text
    from ansible.module_utils.facts.collector import get_collector_status_text_list

# Generated at 2022-06-17 01:38:01.656614
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:38:11.040057
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_by_name
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_list
    from ansible.module_utils.facts.collector import list_collectors

# Generated at 2022-06-17 01:38:21.337277
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:31.463883
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_

# Generated at 2022-06-17 01:38:32.445334
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, to be implemented
    assert False

# Generated at 2022-06-17 01:38:34.501048
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not really testing anything, just to make sure
    # the method is not crashing -akl
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-17 01:38:54.674492
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:58.204775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:39:05.684785
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:16.333361
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import mock

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary executable
    fd, capsh_path = tempfile.mkstemp()
    os.close(fd)
    os.chmod(capsh_path, 0o755)

    # Create a temporary module
    fd, tmpmodule = tempfile.mkstemp()
    os.close(fd)

    # Write a temporary module

# Generated at 2022-06-17 01:39:24.800359
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:39:35.853979
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFacts
    from ansible.module_utils.facts.system.capabilities import Capabilities
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforced
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforcedFacts
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforcedFact
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforcedValue

# Generated at 2022-06-17 01:39:43.049419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_sub

# Generated at 2022-06-17 01:39:51.839084
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:01.592832
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLinuxFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesNetBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesOpenBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSolarisFactCollect

# Generated at 2022-06-17 01:40:08.139845
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import stat
    import subprocess
    import json
    import pytest

    # NOTE: this is a bit of a hack, but it's the only way to get a
    #       'module' object to pass to the collect() method.
    #       We need to do this because the 'module' object is used
    #       to call run_command(), which is what we're trying to test.
    #       We can't mock run_command() because it's a method of the
    #       'module' object, which is not passed in as a parameter.
    #       We can't mock the 'module' object itself because it's
    #       created in the method we're trying to test.
    #       We can't mock the method that creates the 'module' object
    #       because

# Generated at 2022-06-17 01:40:53.300679
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import System

# Generated at 2022-06-17 01:41:01.671578
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names
   

# Generated at 2022-06-17 01:41:03.957691
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with actual unit test -akl
    assert True

# Generated at 2022-06-17 01:41:12.303035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 01:41:21.412792
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:30.031364
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:41:41.205801
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:48.232561
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (0, 'Current: =ep', '')

    mock_module = MockModule()

    # Create a mock Collector
    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock_fact'])


# Generated at 2022-06-17 01:41:59.654699
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts -akl
    module = None
    collected_facts = None
    # NOTE: mock capsh_path -akl
    capsh_path = 'capsh_path'
    # NOTE: mock rc, out, err -akl
    rc = 0

# Generated at 2022-06-17 01:42:12.597835
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:28.739303
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object
    module = Mock()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (0, 'Current: =ep', '')

    # NOTE: mock collected_facts
    collected_facts = {}

    # NOTE: create instance of SystemCapabilitiesFactCollector
    fact_collector = SystemCapabilitiesFactCollector()

    # NOTE: call method collect of class SystemCapabilitiesFactCollector
    fact_collector.collect(module=module, collected_facts=collected_facts)

    # NOTE: assert that method collect of class SystemCapabilitiesFactCollector
    #       returned expected result
    assert collected_facts == {'system_capabilities_enforced': 'False',
                               'system_capabilities': []}

# Generated at 2022-06-17 01:43:35.955294
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule

# Generated at 2022-06-17 01:43:43.292367
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.date_time
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.fips
    import ansible.module_

# Generated at 2022-06-17 01:43:52.258302
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:43:57.719332
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.run_command()
    # NOTE: mock module.get_bin_path()
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:44:00.570999
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with actual unit test -akl
    assert True

# Generated at 2022-06-17 01:44:13.122544
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkFileCacheCollector
    from ansible.module_utils.facts.collector import NetworkCachingFileCollector

# Generated at 2022-06-17 01:44:19.770781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 01:44:26.470737
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.system import SystemDmidecodeCollector
    from ansible.module_utils.facts.collector.system import SystemHardwareCollector
    from ansible.module_utils.facts.collector.system import SystemNetworkCollector
    from ansible.module_utils.facts.collector.system import SystemPlatformCollector
    from ansible.module_utils.facts.collector.system import SystemUptimeCollector
    from ansible.module_utils.facts.collector.system import SystemVirtualCollector

# Generated at 2022-06-17 01:44:29.773642
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with real unit test -akl
    assert True