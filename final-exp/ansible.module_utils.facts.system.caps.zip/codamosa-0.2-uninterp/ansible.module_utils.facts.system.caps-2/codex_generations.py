

# Generated at 2022-06-17 01:35:01.038490
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:03.100233
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, it needs to be implemented
    pass

# Generated at 2022-06-17 01:35:12.494636
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import DictFileCacheCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkFileCacheCollector
    from ansible.module_utils.facts.collector import NetworkHardwareCollector

# Generated at 2022-06-17 01:35:22.161071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import filter_collectors
    from ansible.module_utils.facts.collector import get_fact_names
   

# Generated at 2022-06-17 01:35:25.836346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:35:32.854968
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:35:42.608532
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: mock get_caps_data()/parse_caps_data() -akl
    def mock_get_caps_data(module):
        return 'Current: =ep'

    def mock_parse_caps_data(data):
        return {'system_capabilities_enforced': 'False',
                'system_capabilities': []}

    # NOTE: mock FactsCollector.get_module() -akl
    def mock_get_module():
        return None

    # NOTE:

# Generated at 2022-06-17 01:35:44.368306
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:35:54.332151
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseCommandCollector
    from ansible.module_utils.facts.collector import BasePreserveCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BaseHardwareCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseDistributionCollector

# Generated at 2022-06-17 01:36:04.814584
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:16.295613
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:17.632798
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:36:27.283837
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_enforced as test_collect_enforced
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_not_enforced as test_collect_not_enforced
    from ansible.module_utils.facts.system.caps import test_SystemCap

# Generated at 2022-06-17 01:36:36.442383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:36:46.544521
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:56.316217
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary capsh script
    capsh_script = os.path.join(tmpdir, "capsh")
    with open(capsh_script, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo 'Current: =ep'\n")
        f.write("echo 'Bounding set =ep'\n")

# Generated at 2022-06-17 01:37:07.520069
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_name
    from ansible.module_utils.facts.collector import get_collector_class_for_platform
    from ansible.module_utils.facts.collector import get_collector_class_for_platform_by_distribution

# Generated at 2022-06-17 01:37:17.100216
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # NOTE: get_collector_instance()/get_collector_names()/list_collectors()
    #       for easier mocking -akl
    assert isinstance(get_collector_instance('system_capabilities'),
                      SystemCapabilitiesFactCollector)
    assert 'system_capabilities' in get_collector_names()
    assert 'system_capabilities' in list_collectors()

    # NOTE: BaseFactCollector

# Generated at 2022-06-17 01:37:23.877017
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: mock module, get_caps_data(), parse_caps_data() -akl
    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/capsh'

        def run_command(self, cmd, errors):
            return 0, 'Current: =ep', ''

    module = MockModule()
    capsh_path = module.get_bin_path('capsh')

# Generated at 2022-06-17 01:37:32.543498
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 01:37:48.267615
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import BaseModule

    class TestModule(BaseModule):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, executable):
            return '/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    test_module = TestModule()

# Generated at 2022-06-17 01:37:58.872897
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParseError
    from ansible.module_utils.facts.collector import FactsCacheError
    from ansible.module_utils.facts.collector import FactsCacheExpiredError
    from ansible.module_utils.facts.collector import FactsCacheExpiryError
    from ansible.module_utils.facts.collector import FactsCacheReadError
    from ansible.module_utils.facts.collector import FactsCacheWriteError
    from ansible.module_utils.facts.collector import FactsSearchError

# Generated at 2022-06-17 01:38:02.935432
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, run_command, get_bin_path, and run_command
    #       to test collect()
    pass

# Generated at 2022-06-17 01:38:12.116399
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() return values -akl
    module = Mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    module.get_bin_path.return_value = '/usr/bin/capsh'
    # NOTE: create instance of SystemCapabilitiesFactCollector -akl
    sut = SystemCapabilitiesFactCollector()
    # NOTE: call method collect of class SystemCapabilitiesFactCollector -akl
    result = sut.collect(module)
    # NOTE: assert result -akl
    assert result == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-17 01:38:22.187372
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:38:31.532830
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_for_platform
    from ansible.module_utils.facts.collector import get_collector_class_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_class_for_platform_by_os
    from ansible.module_utils.facts.collector import get_collector_class

# Generated at 2022-06-17 01:38:40.040026
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: mock get_caps_data()/parse_caps_data() for easier mocking -akl
    SystemCapabilitiesFactCollector.get_caps_data = get_caps_data
    SystemCapabilitiesFactCollector.parse_caps_data = parse_caps_data

    # NOTE: mock AnsibleModuleStub.run_command() for easier mocking -akl

# Generated at 2022-06-17 01:38:50.034013
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'
                else:
                    enforced = 'True'
                    enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

        assert enforced == 'True'

# Generated at 2022-06-17 01:38:53.802105
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:38:55.187205
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:39:19.246290
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data
    from ansible.module_utils.facts.collector.system import get_caps_data_mock
    from ansible.module_utils.facts.collector.system import parse_caps_data_mock
    from ansible.module_utils.facts.collector.system import get_caps_data_mock_no_capsh
    from ansible.module_utils.facts.collector.system import parse_caps_data_mock_no_capsh

# Generated at 2022-06-17 01:39:24.963414
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl

# Generated at 2022-06-17 01:39:35.939677
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:39:45.446947
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector.system import BaseFileVirtualDedupedFactCollector
    from ansible.module_utils.facts.collector.system import BaseFileVirtualFactCollector
    from ansible.module_utils.facts.collector.system import BaseVirtualDedupedFactCollector
    from ansible.module_utils.facts.collector.system import BaseVirtualFactCollector
    from ansible.module_utils.facts.collector.system import BaseHardwareFactCollector

# Generated at 2022-06-17 01:39:52.680066
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils.facts.system.caps import get_caps_data_mock
    from ansible.module_utils.facts.system.caps import parse_caps_data_mock
    from ansible.module_utils.facts.system.caps import get_caps_data_mock_no_capsh
    from ansible.module_utils.facts.system.caps import parse_caps_data_mock_no_capsh

# Generated at 2022-06-17 01:39:53.764034
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:39:58.632106
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:40:12.145210
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:16.876051
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts -akl
    # NOTE: mock run_command() -akl
    # NOTE: mock get_bin_path() -akl
    # NOTE: mock get_caps_data() -akl
    # NOTE: mock parse_caps_data() -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:40:20.834559
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test method collect of class SystemCapabilitiesFactCollector
    """
    # NOTE: this is a stub, to be implemented
    pass

# Generated at 2022-06-17 01:41:01.745591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: this is a bit of a hack, but it's the best way to test this
    #       without having to mock out the whole module
    FactsCollector.collectors['system.caps'] = SystemCapabilitiesFactCollector()

    # NOTE: this is a bit of a hack, but it's the best way to test this
    #       without having to mock out the whole module
    SystemCapabilitiesFactCollector._get_caps_data = get_caps_data
    SystemCapabilitiesFactCollector._

# Generated at 2022-06-17 01:41:11.777476
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_

# Generated at 2022-06-17 01:41:20.792570
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:41:29.097596
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module/run_command() for easier testing -akl
    import mock
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # NOTE: mock module/run_command() for easier testing -akl
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_path = ''
            self.run_command_args = []
            self.run_command_kwargs = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/bin/' + name


# Generated at 2022-06-17 01:41:34.268509
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module/run_command() for easier testing -akl
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/capsh')
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect(module=module)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []


# Generated at 2022-06-17 01:41:35.186431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:41:39.921706
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, module.run_command()
    # NOTE: mock module.run_command() -> get_caps_data()
    # NOTE: mock get_caps_data() -> parse_caps_data()
    # NOTE: mock parse_caps_data() -> return test data
    # NOTE: assert facts_dict == test data
    pass

# Generated at 2022-06-17 01:41:44.144716
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:51.526680
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileGlob
    from ansible.module_utils.facts.collector import FileGlob
    from ansible.module_utils.facts.collector import get_file_glob_instance
    from ansible.module_utils.facts.collector import get_file_glob_names
   

# Generated at 2022-06-17 01:42:01.363852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_with_cache
    from ansible.module_utils.facts.collector import get_collector_for_platform_with_cache_by_path
    from ansible.module_utils.facts.collector import get_collector_for_platform_with_cache_by_path_with_fallback

# Generated at 2022-06-17 01:43:14.240114
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkFileCacheCollector
    from ansible.module_utils.facts.collector import NetworkCachingFileCollector

# Generated at 2022-06-17 01:43:16.254791
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:43:23.148686
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collectors_for_platform
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact

# Generated at 2022-06-17 01:43:24.982354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    return True

# Generated at 2022-06-17 01:43:34.311341
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:39.562189
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone

# Generated at 2022-06-17 01:43:40.587519
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test -akl
    assert True

# Generated at 2022-06-17 01:43:48.373275
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.system
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.system.zone

# Generated at 2022-06-17 01:43:55.652273
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import remove_collector
    from ansible.module_utils.facts.collector import remove_collector_instance
    from ansible.module_utils.facts.collector import remove_collectors
    from ansible.module_utils.facts.collector import set_collectors

# Generated at 2022-06-17 01:43:56.369796
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, it needs to be implemented
    pass