

# Generated at 2022-06-17 01:35:01.477381
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:35:07.586261
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and facts_dict
    # NOTE: mock module.run_command() to return a tuple of (rc, out, err)
    # NOTE: mock module.get_bin_path() to return capsh_path
    # NOTE: assert facts_dict['system_capabilities_enforced'] == enforced
    # NOTE: assert facts_dict['system_capabilities'] == enforced_caps
    pass

# Generated at 2022-06-17 01:35:16.839613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not complete, but it is a start -akl
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import textwrap

    # NOTE: this is a hack to get the test to work on Travis CI -akl
    if 'TRAVIS' in os.environ:
        return

    # NOTE: this is a hack to get the test to work on Travis CI -akl
    if 'TRAVIS' in os.environ:
        return

    # NOTE: this is a hack to get the test to work on Travis CI -akl
    if 'TRAVIS' in os.environ:
        return

    # NOTE: this is a hack to get the test to work on Travis CI -akl
    if 'TRAVIS' in os.environ:
        return



# Generated at 2022-06-17 01:35:18.202555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:35:19.277071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with real unit test -akl
    assert True

# Generated at 2022-06-17 01:35:29.704528
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_for_platform

# Generated at 2022-06-17 01:35:39.690049
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_collector_

# Generated at 2022-06-17 01:35:50.239119
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    # NOTE: this is a bit of a hack to get the test to work on both python2 and python3
    #       the test is written for python3, but we need to run it on python2 as well
    #       so we need to make sure that the python2 version of the module_utils is
    #       used instead of the python3 version.
    #       This is done by removing the python3 version from sys.path and adding
    #       the python2 version to sys.path
    #       This is only done for this test, and not for the rest of the module.
    #       This is done to make sure that the python2 version of the module_utils
    #       is used, and not the

# Generated at 2022-06-17 01:36:01.311493
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:07.027838
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:36:18.983957
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:27.919715
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:36.824935
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-17 01:36:44.628242
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_instance

# Generated at 2022-06-17 01:36:47.205303
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.run_command()
    # NOTE: mock module.get_bin_path()
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:36:53.244384
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and module.run_command()
    # NOTE: mock module.run_command() -> get_caps_data()
    # NOTE: mock get_caps_data() -> parse_caps_data()
    # NOTE: mock parse_caps_data() -> return test data
    # NOTE: assert facts_dict == test_data
    pass

# Generated at 2022-06-17 01:37:01.216140
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:37:02.145230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-17 01:37:05.437086
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but will be fleshed out as we add more
    #       capabilities to the module.
    pass

# Generated at 2022-06-17 01:37:15.830585
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances

# Generated at 2022-06-17 01:37:24.740484
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:37:26.439307
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:37:35.236873
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subsets
    from ansible.module_utils.facts.collector import list_deprecated_facts
    from ansible.module_utils.facts.collector import list_deprecated_names


# Generated at 2022-06-17 01:37:43.920396
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:37:53.779505
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object -akl
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    module.get_bin_path.return_value = '/usr/bin/capsh'
    # NOTE: mock collected_facts -akl
    collected_facts = {}
    # NOTE: instantiate class -akl
    fact_collector = SystemCapabilitiesFactCollector()
    # NOTE: call method -akl
    result = fact_collector.collect(module, collected_facts)
    # NOTE: assert result -akl
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-17 01:37:54.919627
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:38:03.947750
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:38:12.297535
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exceptions

# Generated at 2022-06-17 01:38:17.911229
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:26.129831
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collector_status_set

# Generated at 2022-06-17 01:38:40.853686
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collect

# Generated at 2022-06-17 01:38:50.758342
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:01.350583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: 'caps' facts are not collected on Windows -akl
    if not SystemCapabilitiesFactCollector.is_available():
        return

    # NOTE: 'caps' facts are not collected on Windows -akl

# Generated at 2022-06-17 01:39:13.231438
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:21.751947
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_instance_names
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get

# Generated at 2022-06-17 01:39:28.326860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command.return_value = (0, 'Current: =ep', '')
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:39:38.155967
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCollector
    from ansible.module_utils.facts.collector import CachingFileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCacheCollector

# Generated at 2022-06-17 01:39:39.960765
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.run_command()
    # NOTE: mock module.get_bin_path()
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:39:47.230000
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    # NOTE: mock module object -akl
    module = None
    # NOTE: mock collected_facts -akl
    collected_facts = None
    # NOTE: instantiate SystemCapabilitiesFactCollector -akl
    sut = SystemCapabilitiesFactCollector()
    # NOTE: call method collect -akl
    result = sut.collect(module, collected_facts)
    # NOTE: assert result -akl
    assert result == {}

# Generated at 2022-06-17 01:39:48.689793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:40:12.819425
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import parse_caps_data
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import get_distribution
    from ansible.module_utils.facts.collector.system import get_distribution_release
    from ansible.module_utils.facts.collector.system import get_distribution_version
    from ansible.module_utils.facts.collector.system import get_distribution_major_version

# Generated at 2022-06-17 01:40:22.433003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collectors_

# Generated at 2022-06-17 01:40:32.707067
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkFileCacheCollector
    from ansible.module_utils.facts.collector import DMIHardwareCollector
    from ansible.module_utils.facts.collector import DMISoftwareCollector

# Generated at 2022-06-17 01:40:43.878765
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, params):
            self.params = params
            self.exit_args = None
            self.exit_kwargs = None

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            return self.params['capsh_path']


# Generated at 2022-06-17 01:40:47.861858
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.run_command()
    # NOTE: mock module.get_bin_path()
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:40:48.926127
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with a real test
    assert True

# Generated at 2022-06-17 01:40:56.720388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # NOTE: this test is not complete, but it is a start -akl
    # NOTE: this test is not complete, but it is a start -akl
    # NOTE: this test is not complete, but it is a start -akl

    # NOTE: this test is not complete, but it is a start -akl
    # NOTE: this test is not complete, but it is a start -akl
    # NOTE: this test is not complete, but it is a start -akl

    # NOTE: this

# Generated at 2022-06-17 01:40:58.512397
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub test
    assert True

# Generated at 2022-06-17 01:41:08.649607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module for testing
    class MockModule():
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/capsh'
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', expand_user_and_vars=True):
            self.run_command_calls.append(args)
            return self.run_

# Generated at 2022-06-17 01:41:09.914081
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:41:45.154737
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:51.864611
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data_from_string
    from ansible.module_utils.facts.collector.system import parse_caps_data_from_string_with_enforced
    from ansible.module_utils.facts.collector.system import parse_caps_data_from_string_without_enforced
    from ansible.module_utils.facts.collector.system import parse_caps_data_from_string

# Generated at 2022-06-17 01:42:01.932329
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

    module.run_command = Mock(return_value=(0, 'Current: =ep cap_net_raw+p', ''))
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'True'
    assert facts['system_capabilities'] == ['cap_net_raw+p']


# Generated at 2022-06-17 01:42:11.618753
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFile
    from ansible.module_utils.facts.collector import File
    from ansible.module_utils.facts.collector import get_file_instance

# Generated at 2022-06-17 01:42:15.314088
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock run_command() -akl
    pass

# Generated at 2022-06-17 01:42:23.577245
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:42:30.897007
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseCommandCollector

    # Test that the class is a subclass of BaseFactCollector
    assert issubclass(SystemCapabilitiesFactCollector, BaseFactCollector)

    # Test that the class is a subclass of BaseFileCacheCollector
    assert issubclass(SystemCapabilitiesFactCollector, BaseFileCacheCollector)

    # Test that the class is a subclass of BaseCommandCollector
    assert issubclass(SystemCapabilitiesFactCollector, BaseCommandCollector)

    # Test that the class can be instantiated
    SystemCapabilitiesFact

# Generated at 2022-06-17 01:42:40.457761
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a bit of a hack to get around the fact that the
    #       module_utils.facts.collector.BaseFactCollector class is an ABC
    #       and therefore cannot be instantiated directly.
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x, **kwargs: (0, 'Current: =ep', '')

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/capsh'

    module = MockModule()
    facts = SystemCapabilitiesFactCollector().collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-17 01:42:47.916492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances

# Generated at 2022-06-17 01:42:57.922033
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import set_collector_status

# Generated at 2022-06-17 01:44:13.617260
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:44:24.435783
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import get_file_lines
    from ansible.module_utils.facts.collector.system import get_file_size
    from ansible.module_utils.facts.collector.system import get_file_type
    from ansible.module_utils.facts.collector.system import get_mount_size
    from ansible.module_utils.facts.collector.system import get_mount_options

# Generated at 2022-06-17 01:44:31.358823
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test the collect method of SystemCapabilitiesFactCollector
    """
    # Create a mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    module.get_bin_path = Mock(return_value='/bin/capsh')

    # Create a SystemCapabilitiesFactCollector object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Call the collect method
    facts_dict = system_capabilities_fact_collector.collect(module=module)

    # Check the facts
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []


# Generated at 2022-06-17 01:44:37.260566
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:42.902322
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone.zone
    import ansible.module_utils.facts.system.zone.zone_info

# Generated at 2022-06-17 01:44:52.913532
# Unit test for method collect of class SystemCapabilitiesFactCollector