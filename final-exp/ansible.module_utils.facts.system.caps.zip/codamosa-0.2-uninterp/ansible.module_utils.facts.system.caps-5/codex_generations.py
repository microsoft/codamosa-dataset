

# Generated at 2022-06-17 01:35:00.493963
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:35:01.958897
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with real test
    assert True

# Generated at 2022-06-17 01:35:12.162776
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list

# Generated at 2022-06-17 01:35:14.014033
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use mock module to test this method -akl
    pass

# Generated at 2022-06-17 01:35:22.702066
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseFileWriteFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFactCollector
    from ansible.module_utils.facts.collector import BaseHardwareFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualFactCollector
    from ansible.module_utils.facts.collector import BaseSystemFactCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector

# Generated at 2022-06-17 01:35:30.767028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and get_bin_path() for testing -akl
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollect

# Generated at 2022-06-17 01:35:39.705887
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector

    # TODO: mock capsh_path and capsh_output
    # TODO: mock module.run_command()
    # TODO: mock module.get_bin_path()
    # TODO: mock module.get_bin_path()
    # TODO: mock module.get_bin_path()
    # TODO: mock module.get_bin_path()
    # TODO: mock module.get_bin_path()
    # TODO: mock module.get_bin_path()
    # TODO: mock module.get_bin_path()
    # TODO:

# Generated at 2022-06-17 01:35:50.238465
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'capsh')
            with open(self.test_file, 'w') as f:
                f.write('''#!/bin/sh
echo "Current: =ep"
''')
            os.chmod(self.test_file, 0o755)
            self.module = ansible.module_utils.facts.collector.BaseFactCollector()


# Generated at 2022-06-17 01:36:01.312945
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import BaseFileSearch
    from ansible.module_utils.facts.collector import FileSearch
    from ansible.module_utils.facts.collector import get_file_lines
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.collector import get_file_content_of_block

# Generated at 2022-06-17 01:36:05.619448
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command()
    # NOTE: mock capsh_path and run_command()
    # NOTE: mock rc, out, err
    # NOTE: assert facts_dict == expected
    pass

# Generated at 2022-06-17 01:36:16.671609
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test_module_utils.get_module_mock() -> get_module_mock()
    module = get_module_mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(module=module)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []
    module.run_command.return_value = (0, 'Current: =ep cap_net_admin,cap_net_raw+eip', '')
    result = collector.collect(module=module)
    assert result['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-17 01:36:26.724943
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 01:36:28.053671
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:36:38.105623
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_all_collect

# Generated at 2022-06-17 01:36:46.681602
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_exclusions
    from ansible.module_utils.facts.collector import get_collector_cache_dir

# Generated at 2022-06-17 01:36:49.054297
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub test -akl
    assert True

# Generated at 2022-06-17 01:36:50.327530
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test -akl
    assert True

# Generated at 2022-06-17 01:36:59.286744
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_subset
    from ansible.module_utils.facts.collector import get_fact_version

# Generated at 2022-06-17 01:37:12.044923
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test_module_utils.get_module_mock() is a helper function to
    #       create a mock module object
    module = test_module_utils.get_module_mock()
    # NOTE: test_module_utils.get_bin_path_mock() is a helper function to
    #       create a mock bin_path() method for the module object
    module.bin_path = test_module_utils.get_bin_path_mock()
    # NOTE: test_module_utils.get_run_command_mock() is a helper function to
    #       create a mock run_command() method for the module object
    module.run_command = test_module_utils.get_run_command_mock()
    # NOTE: test_module_utils.get_ansible_module_results_mock()

# Generated at 2022-06-17 01:37:19.332566
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:37:29.988647
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils.facts.system.caps import capsh_path
    from ansible.module_utils.facts.system.caps import capsh_path_exists
    from ansible.module_utils.facts.system.caps import capsh_path_exists_mock
    from ansible.module_utils.facts.system.caps import get_caps_data_mock
    from ansible.module_utils.facts.system.caps import parse_caps_data_mock


# Generated at 2022-06-17 01:37:40.748093
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:37:41.899842
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:37:50.406410
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a mock module object, not a real AnsibleModule
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/capsh')
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect(module=module)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []


# Generated at 2022-06-17 01:37:52.786044
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with real test -akl
    assert True

# Generated at 2022-06-17 01:38:02.214363
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system.capabilities import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.collector.system.capabilities import test_SystemCapabilitiesFactCollector_collect as test_collect_caps
    from ansible.module_utils.facts.collector.system.capabilities import test_SystemCapabilitiesFactCollector_collect as test_collect_caps_enforced


# Generated at 2022-06-17 01:38:12.395993
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:20.603499
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:31.120402
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:38:39.705077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:38:58.606147
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock facts, mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:39:12.450037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule

# Generated at 2022-06-17 01:39:14.410518
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command()
    # NOTE: mock capsh_path
    # NOTE: mock rc, out, err
    # NOTE: assert facts_dict
    pass

# Generated at 2022-06-17 01:39:20.716307
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:32.468697
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and facts_dict -akl
    module = None
    facts_dict = {}
    # NOTE: mock capsh_path -akl
    capsh_path = None
    # NOTE: mock rc, out, err -akl
    rc = 0

# Generated at 2022-06-17 01:39:40.953056
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_names
   

# Generated at 2022-06-17 01:39:50.326543
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:00.395216
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_all_collect

# Generated at 2022-06-17 01:40:12.717554
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-17 01:40:22.814134
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:07.945975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names

# Generated at 2022-06-17 01:41:16.345516
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_with_cache
    from ansible.module_utils.facts.collector import get_collector_for_platform_with_cache_no_fallback
    from ansible.module_utils.facts.collector import get_collector_for_platform_with_cache_fallback

# Generated at 2022-06-17 01:41:18.735728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test
    assert True

# Generated at 2022-06-17 01:41:28.087198
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.version
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone

# Generated at 2022-06-17 01:41:34.918705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import CacheableCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceDictCollector

# Generated at 2022-06-17 01:41:43.592618
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLinuxFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesNetBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesOpenBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSunOSFactCollector

# Generated at 2022-06-17 01:41:51.210526
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 01:42:01.191680
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:42:03.386098
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, it needs to be implemented
    pass

# Generated at 2022-06-17 01:42:13.767855
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:28.715983
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:29.554676
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:43:36.635478
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is a bit brittle, but it's better than nothing -akl
    import os
    import tempfile
    import shutil
    import subprocess

    # NOTE: this is a bit of a hack, but it's better than nothing -akl
    capsh_path = '/usr/bin/capsh'
    if not os.path.exists(capsh_path):
        return

    # NOTE: this is a bit of a hack, but it's better than nothing -akl
    capsh_out = subprocess.check_output([capsh_path, "--print"])

    # NOTE: this is a bit of a hack, but it's better than nothing -akl
    capsh_out_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-17 01:43:43.858616
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 01:43:54.339613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance

# Generated at 2022-06-17 01:44:01.493677
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:05.010989
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:44:07.045952
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    assert True

# Generated at 2022-06-17 01:44:12.025074
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:44:18.651850
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names