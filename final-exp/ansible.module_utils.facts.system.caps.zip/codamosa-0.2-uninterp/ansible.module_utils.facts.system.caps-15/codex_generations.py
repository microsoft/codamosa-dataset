

# Generated at 2022-06-17 01:35:00.494351
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 01:35:03.963061
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and module.run_command()
    #       -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:35:12.867287
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import get_file_lines
    from ansible.module_utils.facts.collector.system import get_file_size
    from ansible.module_utils.facts.collector.system import get_file_type
    from ansible.module_utils.facts.collector.system import get_mount_size
    from ansible.module_utils.facts.collector.system import get_mount_options

# Generated at 2022-06-17 01:35:22.328707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.gentoo
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.distribution.alpine


# Generated at 2022-06-17 01:35:31.343893
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a unit test for the method collect of class SystemCapabilitiesFactCollector
    #       it is not a unit test for the module_utils.facts.system.caps module
    #       which is used by the method collect
    #       the module_utils.facts.system.caps module is tested in test_caps.py
    #       -akl
    import os
    import sys
    import tempfile
    import textwrap
    import unittest

    # NOTE: this is a unit test for the method collect of class SystemCapabilitiesFactCollector
    #       it is not a unit test for the module_utils.facts.system.caps module
    #       which is used by the method collect
    #       the module_utils.facts.system.caps module is tested in test_caps.py
    #       -akl

# Generated at 2022-06-17 01:35:40.355063
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:35:50.276734
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance

# Generated at 2022-06-17 01:36:01.321194
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFileSearch
    from ansible.module_utils.facts.collector import FileSearch
    from ansible.module_utils.facts.collector import get_file_search_instance

# Generated at 2022-06-17 01:36:04.263599
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but it's better than nothing -akl
    assert True

# Generated at 2022-06-17 01:36:12.900740
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module for testing
    module = MockModule()
    # NOTE: mock module.run_command() for testing
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    # NOTE: mock module.get_bin_path() for testing
    module.get_bin_path = Mock(return_value='/usr/bin/capsh')
    # NOTE: create instance of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # NOTE: call method collect of class SystemCapabilitiesFactCollector
    result = system_capabilities_fact_collector.collect(module=module)
    # NOTE: assert result
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Unit

# Generated at 2022-06-17 01:36:17.103244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:36:18.805060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, we need to mock the module object
    #       and the run_command() method
    pass

# Generated at 2022-06-17 01:36:20.511771
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but will be fleshed out as needed -akl
    assert True

# Generated at 2022-06-17 01:36:29.413395
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command()
    # NOTE: mock module.run_command() -> return (0, 'Current: =ep', '')
    # NOTE: assert 'system_capabilities_enforced' == 'False'
    # NOTE: assert 'system_capabilities' == []
    # NOTE: mock module.run_command() -> return (0, 'Current: =ep cap_net_bind_service', '')
    # NOTE: assert 'system_capabilities_enforced' == 'True'
    # NOTE: assert 'system_capabilities' == ['cap_net_bind_service']
    pass

# Generated at 2022-06-17 01:36:39.322012
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import remove_collector
    from ansible.module_utils.facts.collector import set_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector

# Generated at 2022-06-17 01:36:46.709504
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_by_name

# Generated at 2022-06-17 01:36:53.793810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a mock of the module class, not the module itself -akl
    module = MockModule()
    module.run_command.return_value = (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:37:00.548494
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileSearch
    from ansible.module_utils.facts.collector import FileSearch
    from ansible.module_utils.facts.collector import get_file_lines

# Generated at 2022-06-17 01:37:12.211558
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary capsh script
    capsh_path = os.path.join(tmpdir, "capsh")

# Generated at 2022-06-17 01:37:19.480991
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

    module.run_command = Mock(return_value=(0, 'Current: =ep cap_sys_admin,cap_sys_ptrace', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'True'
    assert facts['system_capabilities'] == ['cap_sys_admin', 'cap_sys_ptrace']



# Generated at 2022-06-17 01:37:35.178573
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_

# Generated at 2022-06-17 01:37:38.827713
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but will be fleshed out with a test
    #       harness that can mock the module and the run_command() method
    #       to return canned output from capsh --print
    #       -akl
    pass

# Generated at 2022-06-17 01:37:48.219939
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:37:58.833211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_all_collect

# Generated at 2022-06-17 01:38:11.692366
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for_fact
    from ansible.module_utils.facts.collector import get_collector_classes_for_fact_ids
    from ansible.module_utils.facts.collector import get_collector_classes_for_platform
    from ansible.module_utils.facts.collector import get_collector_class_names_for_platform

# Generated at 2022-06-17 01:38:20.568215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import FileDigestCollector

# Generated at 2022-06-17 01:38:22.662985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub -akl
    pass

# Generated at 2022-06-17 01:38:31.794700
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:38:40.449567
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collector_status_set

# Generated at 2022-06-17 01:38:50.356238
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileGlob
    from ansible.module_utils.facts.collector import FileGlob
    from ansible.module_utils.facts.collector import get_file_glob_instance
    from ansible.module_utils.facts.collector import get_file_glob_names
   

# Generated at 2022-06-17 01:39:17.979903
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import remove_collector
    from ansible.module_utils.facts.collector import set_collectors
    from ansible.module_utils.facts.collector import unregister_collector

# Generated at 2022-06-17 01:39:19.306004
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need to mock module.run_command() and module.get_bin_path() -akl
    pass

# Generated at 2022-06-17 01:39:24.973591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.kernel
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.system.mounts

# Generated at 2022-06-17 01:39:26.373976
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:39:36.849118
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names

# Generated at 2022-06-17 01:39:40.082741
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts -akl
    # NOTE: mock run_command() -akl
    # NOTE: mock get_bin_path() -akl
    # NOTE: mock get_caps_data()/parse_caps_data() -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:39:49.549962
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLinuxFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesNetBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesOpenBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSolarisFactCollect

# Generated at 2022-06-17 01:39:51.349371
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:40:01.045422
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:40:01.891896
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:40:38.628911
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but it's better than nothing -akl
    pass

# Generated at 2022-06-17 01:40:48.129654
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:40:59.034249
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a bit of a hack to get the test to work with the
    #       current structure of the module_utils.  This should be
    #       refactored to make it easier to test. -akl
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-17 01:41:08.814968
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:16.965287
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:27.506852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect

    # NOTE: mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = test_collect.run_command

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/capsh'

    # NOTE: mock module.run_command()

# Generated at 2022-06-17 01:41:27.979104
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-17 01:41:34.849530
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:43.559267
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:51.212202
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collectors
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_ids

# Generated at 2022-06-17 01:43:04.281098
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import get_file_content
    import os
    import tempfile
    import shutil
    import sys
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()

    # Write to the temporary file
    os.write(fd, b'Current: =ep')

    # Close the file
    os

# Generated at 2022-06-17 01:43:14.468368
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_get_caps_data as test_get_caps_data
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_parse_caps_data as test_parse_caps_data

# Generated at 2022-06-17 01:43:21.762545
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test_module_utils.get_module_mock() -> get_module_mock() -akl
    module = get_module_mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    # NOTE: test_module_utils.get_module_mock() -> get_module_mock() -akl
    module.get_bin_path.return_value = '/bin/capsh'
    # NOTE: test_module_utils.get_module_mock() -> get_module_mock() -akl
    module.get_bin_path.return_value = '/bin/capsh'
    # NOTE: test_module_utils.get_module_mock() -> get_module_mock() -akl

# Generated at 2022-06-17 01:43:28.827698
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import FactsCache
    from ansible.module_utils.facts.collector import get_file_lines
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.collector import get_file_content_of_device
    from ansible.module_utils.facts.collector import get_mount_size

# Generated at 2022-06-17 01:43:38.033536
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import platform
    import json

    # NOTE: this is a hack to get the module to run from the test directory
    #       without installing the module.
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:43:44.944035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import mock
    from ansible.module_utils.facts import collector

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

        def test_collect_returns_dict(self):
            self.assertIsInstance(self.system_capabilities_fact_collector.collect(), dict)

        def test_collect_returns_dict_with_system_capabilities_enforced_key(self):
            self.assertIn('system_capabilities_enforced', self.system_capabilities_fact_collector.collect())

        def test_collect_returns_dict_with_system_capabilities_key(self):
            self.assertIn

# Generated at 2022-06-17 01:43:54.472690
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names

# Generated at 2022-06-17 01:44:01.493774
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:13.584072
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.kernel
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.system.date_time
    import ansible.module_

# Generated at 2022-06-17 01:44:24.436256
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.selinux