

# Generated at 2022-06-17 01:35:00.237769
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts for testing -akl
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x, **kwargs: (0, 'Current: =ep', '')
            self.get_bin_path = lambda x: '/bin/capsh'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockCollectedFacts(object):
        def __init__(self):
            self.facts = {}

    module

# Generated at 2022-06-17 01:35:10.239137
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import parse_file_content
    from ansible.module_utils.facts.collector.system import get_file_lines
    from ansible.module_utils.facts.collector.system import parse_file_lines
    from ansible.module_utils.facts.collector.system import get_file_content_if_exists
    from ansible.module_utils.facts.collector.system import get_file_lines_if_

# Generated at 2022-06-17 01:35:21.393474
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names_from_package
    from ansible.module_utils.facts.collector import get_collector_classes_from_package
    from ansible.module_utils.facts.collector import get_collector_instance_from_package
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:35:28.807511
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCollector
    from ansible.module_utils.facts.collector import CachingFileDictCollector
    from ansible.module_utils.facts.collector import CachingFileListCollector
    from ansible.module_utils.facts.collector import CachingFileLinesCollector
    from ansible.module_utils.facts.collector import CachingFileStringCollector

# Generated at 2022-06-17 01:35:41.231468
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:35:51.941650
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test the collect method of SystemCapabilitiesFactCollector
    """
    # NOTE: this is a bit of a hack to get the module_utils path
    #       into the path so we can import the module_utils.basic
    #       module.  This should be fixed in Ansible core.
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../../module_utils'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # NOTE: this is a bit of a hack to get the module_utils path
    #       into the path so we

# Generated at 2022-06-17 01:36:02.103267
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:04.059207
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:36:05.701878
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:36:14.427752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, 'Current: =ep', ''

    class TestAnsibleModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable


# Generated at 2022-06-17 01:36:21.765754
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, need to add unit tests -akl
    pass

# Generated at 2022-06-17 01:36:28.935670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time

# Generated at 2022-06-17 01:36:38.970351
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_names
   

# Generated at 2022-06-17 01:36:46.556406
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:56.306634
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module = os.path.join(tmpdir, 'ansible_test_facts.py')
    with open(module, 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("import os\n")
        f.write("import json\n")
        f.write("print(json.dumps(dict(ANSIBLE_MODULE_ARGS=dict(capsh_path='/usr/bin/capsh'))))\n")

    # Create a temporary python module
    capsh_path = os.path.join(tmpdir, 'capsh')

# Generated at 2022-06-17 01:36:59.363910
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but it should be possible to
    #       test this method with a mocked module object.
    pass

# Generated at 2022-06-17 01:37:12.044976
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:37:13.343734
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:37:19.815460
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:37:21.034459
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but it's better than nothing -akl
    assert True

# Generated at 2022-06-17 01:37:25.192852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:37:35.148167
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import Capabilities
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFacts
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsParser
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsParserFactory
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsParserFactoryImpl

# Generated at 2022-06-17 01:37:43.864637
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceDictCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceListCollector

# Generated at 2022-06-17 01:37:55.450718
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_id
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_instance_names
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_

# Generated at 2022-06-17 01:38:03.376768
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_

# Generated at 2022-06-17 01:38:11.829210
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance

# Generated at 2022-06-17 01:38:20.569057
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'

# Generated at 2022-06-17 01:38:31.121388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not really testing the collect method, but rather the
    #       get_caps_data and parse_caps_data methods.
    #       The collect method is tested in test_ansible_module_system_capabilities.py
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: this is a bit of a hack, but it works
    BaseFactCollector.collectors.append(SystemCapabilitiesFactCollector())

    # NOTE: this is a bit of a hack, but it works

# Generated at 2022-06-17 01:38:39.705103
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:45.179058
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, required=False):
            return self.bin_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return subprocess.call(cmd, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
           

# Generated at 2022-06-17 01:39:01.851177
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # NOTE: this is a bit of a hack, but it's the only way to get a
    #       ModuleFacts instance without a module

# Generated at 2022-06-17 01:39:08.944437
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command.return_value = (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:39:18.234381
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors

    # Test the collector class
    assert issubclass(SystemCapabilitiesFactCollector, BaseFactCollector)

    # Test the collector instance
    collector = SystemCapabilitiesFactCollector()
    assert isinstance(collector, BaseFactCollector)
    assert isinstance(collector, Collector)

    # Test the get_collector_instance function
    collector = get_collector_instance('SystemCapabilitiesFactCollector')
    assert isinstance

# Generated at 2022-06-17 01:39:23.620821
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFacts
    from ansible.module_utils.facts.system.capabilities import Capabilities
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforced
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforcedFacts
    from ansible.module_utils.facts.system.capabilities import CapabilitiesEnforcedFact

# Generated at 2022-06-17 01:39:30.300733
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.kernel
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.timezone
    import ansible.module_utils.facts.system.selinux
    import ansible.module_

# Generated at 2022-06-17 01:39:39.597205
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:49.274704
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:00.078119
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:40:12.607562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_

# Generated at 2022-06-17 01:40:18.921369
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    # NOTE: this is a hack to get the module_utils path for the mock module
    #       when running from a virtualenv.
    #       See https://github.com/ansible/ansible/issues/25662
    #       and https://github.com/ansible/ansible/issues/25665
    #       for more details.
    #       This is a workaround until we can get the module_utils path
    #       from the ansible-test command.
    if 'ANSIBLE_MODULE_UTILS' not in os.environ:
        if 'VIRTUAL_ENV' in os.environ:
            venv_path = os.environ['VIRTUAL_ENV']
           

# Generated at 2022-06-17 01:40:39.087154
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not really testing anything, just checking that the
    #       method does not crash -akl
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-17 01:40:48.186845
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:59.103127
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:41:08.834162
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFile
    from ansible.module_utils.facts.collector import File
    from ansible.module_utils.facts.collector import get_file_instance

# Generated at 2022-06-17 01:41:18.903902
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:24.387841
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:34.059717
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:41:34.886074
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:41:42.365047
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a very basic test, just to make sure the method is not broken
    #       and returns a dict with expected keys
    #       the actual data returned is tested in integration tests
    #       (see test/integration/targets/facts/test_system_capabilities.py)
    #       -akl
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert 'system_capabilities' in facts
    assert 'system_capabilities_enforced' in facts


# Generated at 2022-06-17 01:41:50.539380
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorNotFound
    from ansible.module_utils.facts.collector import CollectorNotLoaded
    from ansible.module_utils.facts.collector import CollectorNotImplemented

# Generated at 2022-06-17 01:42:27.044335
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # NOTE: this is a bit of a hack to get the module mock to work
    #       since the module is not a real module, but a class
    #       that is instantiated by the module_utils/facts/__init__.py
    #       file.  We need to mock the module class, not the module
    #       instance.
    from ansible.module_utils.facts import module_utils_facts_module
    from ansible.module_utils.facts import module_utils_facts_module_instance

# Generated at 2022-06-17 01:42:29.422449
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now.
    #       This should be replaced with a proper unit test.
    #       See https://github.com/ansible/ansible/issues/33892
    pass

# Generated at 2022-06-17 01:42:33.096655
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but will be fleshed out as needed -akl
    pass

# Generated at 2022-06-17 01:42:38.373027
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object
    module = Mock()
    module.get_bin_path.return_value = '/bin/capsh'
    module.run_command.return_value = (0, 'Current: =ep', '')
    # NOTE: mock collected_facts
    collected_facts = {}
    # NOTE: instantiate SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # NOTE: call method collect of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector.collect(module=module, collected_facts=collected_facts)
    # NOTE: assert that module.get_bin_path was called with 'capsh'
    module.get_bin_path.assert_called_with('capsh')
    # NOTE: assert that module.run_command was

# Generated at 2022-06-17 01:42:47.092387
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:42:56.822775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test the collect method of SystemCapabilitiesFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_id
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:43:04.599444
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:43:06.589763
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:43:16.101336
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test that SystemCapabilitiesFactCollector.collect() returns the expected
    data.
    """
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import mock

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, executable, required=False):
            return '/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 01:43:23.085846
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return self.params['capsh_path']

        def run_command(self, args, errors='surrogate_then_replace'):
            return self.params['run_command'](args)

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 01:44:42.970608
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not very useful, since it doesn't test the
    #       actual functionality of the method.
    #       It would be better to mock the module and the run_command
    #       method, so that we can test the actual parsing of the output
    #       of the capsh command.
    #       However, this is a good start.
    #       -akl
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # NOTE: this test is not very useful, since it doesn't test the
    #       actual functionality of the method.
    #       It would be better to mock the module and the run_command
    #       method, so that we can

# Generated at 2022-06-17 01:44:45.233917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.run_command()
    # NOTE: mock module.get_bin_path()
    # NOTE: assert facts_dict == expected_facts_dict
    pass