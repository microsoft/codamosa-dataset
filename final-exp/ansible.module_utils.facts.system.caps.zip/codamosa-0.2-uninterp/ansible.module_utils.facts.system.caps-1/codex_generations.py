

# Generated at 2022-06-17 01:35:01.278327
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:11.780496
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import tempfile
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'capsh_output'), 'w')
    f.write('Current: =ep\n')

# Generated at 2022-06-17 01:35:21.868553
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorNotFound
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector

# Generated at 2022-06-17 01:35:29.145715
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:41.265906
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorNotFound
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector

# Generated at 2022-06-17 01:35:44.690068
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:35:51.800473
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 01:35:55.584852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub test, to be replaced with a real test
    assert True

# Generated at 2022-06-17 01:36:05.471865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:36:14.534385
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_ids
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subset_names
   

# Generated at 2022-06-17 01:36:21.766024
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:36:32.533953
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:36:37.136736
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-17 01:36:44.760753
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileCollector
    from ansible.module_utils.facts.collector import CachingFileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileParallelCollector
    from ansible.module_utils.facts.collector import CachingFileParallelCacheCollector


# Generated at 2022-06-17 01:36:52.300442
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-17 01:37:00.853603
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is a bit of a mess, but it's the best we can do with
    # the current design.  It's not clear how to mock the module object
    # and the run_command() method.  The test is also not very robust,
    # since it relies on the output of capsh --print.  If that changes,
    # the test will fail.  -akl
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 01:37:10.726781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use mock module to mock 'run_command' and 'get_bin_path'
    #       methods of module
    #       -> mock 'run_command' to return a tuple of (0, '', '')
    #       -> mock 'get_bin_path' to return '/usr/bin/capsh'
    #       -> call collect() of SystemCapabilitiesFactCollector
    #       -> assert that the return value is a dict
    #       -> assert that the dict contains the expected keys
    #          and values
    pass

# Generated at 2022-06-17 01:37:19.499755
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFileCacheModuleCollector
    from ansible.module_utils.facts.collector import BaseFileCacheModuleCollector
    from ansible.module_utils.facts.collector import BaseFileCacheModuleCollector
    from ansible.module_utils.facts.collector import BaseFileCacheModuleCollector
    from ansible.module_utils.facts.collector import BaseFileCacheModuleCollect

# Generated at 2022-06-17 01:37:24.955313
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_no_caps as test_collect_no_caps
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_no_capsh as test_collect_no_capsh
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollect

# Generated at 2022-06-17 01:37:32.999539
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not really testing anything, as it's not mocking the
    #       module.run_command() call.
    #       It's just a placeholder for now.
    #       We should mock the module.run_command() call, and then test the
    #       parsing of the output.
    #       This will require some refactoring of the method collect()
    #       -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # NOTE: this is not a real module, just a placeholder for now
    class FakeModule:
        def get_bin_path(self, name):
            return '/bin/capsh'


# Generated at 2022-06-17 01:37:44.565247
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.version
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.virtual.zone
    import ansible.module_utils.facts.virtual.zone


# Generated at 2022-06-17 01:37:55.797187
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_class

    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl

# Generated at 2022-06-17 01:38:03.472518
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, 'Current: =ep', ''



# Generated at 2022-06-17 01:38:11.911896
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is a bit of a hack, but it's better than nothing -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_caps_data as test_collect_caps_data
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_parse_caps_data as test_parse_caps_data
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_get_caps_data

# Generated at 2022-06-17 01:38:14.856360
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command()
    # NOTE: mock capsh_path
    # NOTE: mock rc, out, err
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:38:19.105060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and mock run_command()
    # NOTE: mock get_bin_path()
    # NOTE: mock run_command()
    # NOTE: mock parse_caps_data()
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:38:26.920244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import _get_collectors_from_entry_points
    from ansible.module_utils.facts.collector import _get_collectors_

# Generated at 2022-06-17 01:38:32.629322
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    # NOTE: need to mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:38:35.618138
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module/run_command()/get_bin_path()
    #       -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:38:40.160565
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test_module_utils.get_module_mock() for easier mocking -akl
    module = get_module_mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-17 01:38:57.682531
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance

# Generated at 2022-06-17 01:39:00.419725
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock run_command(), mock get_bin_path()
    #       -> mock get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:39:12.961255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFileModule
    from ansible.module_utils.facts.collector import BaseFileModuleDeprecated

# Generated at 2022-06-17 01:39:21.702326
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names
    from ansible.module_utils.facts.collector import list_file_

# Generated at 2022-06-17 01:39:23.221702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:39:27.632300
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command()
    # NOTE: mock capsh_path and run_command()
    # NOTE: mock rc, out, err
    # NOTE: assert facts_dict
    pass

# Generated at 2022-06-17 01:39:37.643172
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:39:42.993426
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:48.393814
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector(module=module)
    facts = collector.collect()
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:39:59.509866
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() for easier testing -akl
    module = MockModule()

# Generated at 2022-06-17 01:40:19.795517
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command.return_value = (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:40:28.567619
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFile
    from ansible.module_utils.facts.collector import File
    from ansible.module_utils.facts.collector import get_file_instance

# Generated at 2022-06-17 01:40:29.360821
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:40:38.219929
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'
                else:
                    enforced = 'True'
                    enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

        assert enforced == 'True'

# Generated at 2022-06-17 01:40:46.895996
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFile
    from ansible.module_utils.facts.collector import File
    from ansible.module_utils.facts.collector import get_file_instance

# Generated at 2022-06-17 01:40:54.695612
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorNotFound
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_fact_id

# Generated at 2022-06-17 01:41:02.308916
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import list_collectors

# Generated at 2022-06-17 01:41:13.633255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_id
    from ansible.module_utils.facts.collector import get_collector_instance_by_name
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors

# Generated at 2022-06-17 01:41:16.495837
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, capsh_path, and run_command()
    # NOTE: mock out.splitlines()
    # NOTE: mock enforced_caps, enforced, and facts_dict
    # NOTE: assert facts_dict
    pass

# Generated at 2022-06-17 01:41:27.029784
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_id
    from ansible.module_utils.facts.collector import get_collector_fact_ids_by_class_name
    from ansible.module_utils.facts.collector import get_collector_fact_ids_by_collector_class
    from ansible.module_utils.facts.collector import get_collector_fact_ids_by_collector_instance

# Generated at 2022-06-17 01:42:01.340023
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:42:08.648030
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:42:09.537765
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-17 01:42:11.364389
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:42:20.451124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, capsh_path, and run_command() -akl
    # NOTE: mock out.splitlines() -akl
    # NOTE: mock line.split() -akl
    # NOTE: mock line.split(':')[1].strip() -akl
    # NOTE: mock line.split('=')[1].split(',') -akl
    # NOTE: mock [i.strip() for i in ...] -akl
    # NOTE: mock return values -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:42:24.085884
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub -akl
    pass

# Generated at 2022-06-17 01:42:27.919298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:42:30.971592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts -akl
    # NOTE: mock run_command() -akl
    # NOTE: mock get_bin_path() -akl
    # NOTE: mock get_caps_data() -akl
    # NOTE: mock parse_caps_data() -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:42:32.639120
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:42:41.152031
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import shutil
    import sys
    import stat
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python script
    script = os.path.join(tmpdir, "capsh")
    with open(script, 'w') as f:
        f.write("""#!/usr/bin/python
import sys
import json

if len(sys.argv) == 2 and sys.argv[1] == "--print":
    print(json.dumps({'Current': '=ep'}))
    sys.exit(0)

sys.exit(1)
""")
    # make the script executable
    st = os.stat(script)

# Generated at 2022-06-17 01:43:54.661205
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:04.007059
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:13.950523
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:24.629969
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, 'Current: =ep', ''

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.collector = SystemCapabilitiesFactCollector()


# Generated at 2022-06-17 01:44:31.760206
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:37.338968
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:44:39.774763
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, module.run_command(), module.get_bin_path() -akl
    pass

# Generated at 2022-06-17 01:44:49.142301
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all