

# Generated at 2022-06-17 01:34:53.062777
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub test -akl
    pass

# Generated at 2022-06-17 01:35:02.128600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not complete, but it does test the basic functionality
    #       of the method.  It should be expanded to cover all possible cases.
    #       -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_deprecated_names

    # NOTE: this test is not complete, but it does test

# Generated at 2022-06-17 01:35:12.522028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFileGlob
    from ansible.module_utils.facts.collector import FileGlob
    from ansible.module_utils.facts.collector import get_file_glob

# Generated at 2022-06-17 01:35:22.161222
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, module.run_command(), and parse_caps_data() -akl
    module = None
    collected_facts = None

# Generated at 2022-06-17 01:35:26.370617
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but it's better than nothing -akl
    assert True

# Generated at 2022-06-17 01:35:32.965007
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:42.661660
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:53.550832
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not complete, but it is a start -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 01:36:04.440372
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances

# Generated at 2022-06-17 01:36:13.009351
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:36:26.297893
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:35.770028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not complete, but it's a start -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import list_extras_collectors
    from ansible.module_utils.facts.collector import list

# Generated at 2022-06-17 01:36:44.021723
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:55.591353
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a unit test for the method collect of class SystemCapabilitiesFactCollector
    #       it is not a unit test for the module_utils.facts.system.caps module
    #       which is tested via the integration test test_system_caps.py
    #       -akl
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import mock

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.exit_json = mock.MagicMock()
            self.fail_json = mock.MagicMock()

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/capsh'


# Generated at 2022-06-17 01:36:56.833692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, will be implemented later -akl
    pass

# Generated at 2022-06-17 01:36:58.729150
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented -akl
    pass

# Generated at 2022-06-17 01:37:08.925663
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    from ansible.module_utils.facts import collector

    # NOTE: mock module_utils.facts.collector.BaseFactCollector.get_bin_path()
    def mock_get_bin_path(self, binary):
        if binary == 'capsh':
            return '/usr/bin/capsh'
        else:
            return None
    collector.BaseFactCollector.get_bin_path = mock_get_bin_path

    # NOTE: mock module_utils.facts.collector.BaseFactCollector.run_command()

# Generated at 2022-06-17 01:37:17.945136
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:37:20.300299
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:37:24.192693
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names

# Generated at 2022-06-17 01:37:33.537645
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test -akl
    assert True

# Generated at 2022-06-17 01:37:43.157899
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import parse_file_content
    from ansible.module_utils.facts.collector.system import get_file_lines
    from ansible.module_utils.facts.collector.system import parse_file_lines
    from ansible.module_utils.facts.collector.system import get_file_content_if_exists
    from ansible.module_utils.facts.collector.system import get_mount_size

# Generated at 2022-06-17 01:37:45.353999
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:37:56.298330
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import unittest
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            return '/bin/capsh'


# Generated at 2022-06-17 01:37:58.955601
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() -akl
    pass

# Generated at 2022-06-17 01:38:06.882462
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.get_bin_path() -> '/bin/capsh'
    # NOTE: mock module.run_command() -> (0, 'Current: =ep', '')
    # NOTE: assert facts_dict == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    pass

# Generated at 2022-06-17 01:38:10.806298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and module.run_command() -akl
    pass

# Generated at 2022-06-17 01:38:21.266686
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names

# Generated at 2022-06-17 01:38:31.465376
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_mocked as test_collect_mocked
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_mocked_enforced as test_collect_mocked_enforced
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_mocked_not_enforced as test_collect

# Generated at 2022-06-17 01:38:40.417746
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a mock of the module object, not the actual module -akl
    module = Mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    module.get_bin_path.return_value = '/usr/bin/capsh'

    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

    module.run_command.return_value = (0, 'Current: =ep cap_sys_admin,cap_sys_chroot+eip', '')
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-17 01:39:03.363855
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:15.566375
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_id
    from ansible.module_utils.facts.collector import get_collector_instance_by_name
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors

# Generated at 2022-06-17 01:39:22.542783
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import _get_caps_data
    from ansible.module_utils.facts.collector.system import _parse_caps_data

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary 'capsh' executable
    capsh_path = os.path.join(tmpdir, 'capsh')
    with open(capsh_path, 'w') as capsh_file:
        capsh_file.write("#!/bin/sh\n")
        cap

# Generated at 2022-06-17 01:39:34.373517
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:39:42.222886
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:51.297239
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileGlob
    from ansible.module_utils.facts.collector import FileGlob
    from ansible.module_utils.facts.collector import get_file_glob_instance
    from ansible.module_utils.facts.collector import get_file_glob_names
   

# Generated at 2022-06-17 01:40:01.005995
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    import os
    import tempfile

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    # Create the test AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Create the test SystemCapabilitiesFactCollector
    test_collector = SystemCapabilitiesFactCollector(module=module)
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary executable file
    temp_executable = os.path.join(temp_dir, 'capsh')
    # Create the temporary executable file

# Generated at 2022-06-17 01:40:12.871986
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:40:22.471279
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object
    module = MockModule()
    # NOTE: mock capsh_path
    module.get_bin_path.return_value = '/usr/bin/capsh'
    # NOTE: mock run_command
    module.run_command.return_value = (0, 'Current: =ep', '')
    # NOTE: mock collected_facts
    collected_facts = {}

    # NOTE: create instance of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # NOTE: test collect method of SystemCapabilitiesFactCollector
    facts_dict = system_capabilities_fact_collector.collect(module, collected_facts)

    # NOTE: assert facts_dict

# Generated at 2022-06-17 01:40:24.783070
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, module.run_command(), module.get_bin_path()
    #       and module.get_caps_data()
    #       for easier testing -akl
    pass

# Generated at 2022-06-17 01:40:58.471111
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:41:04.791721
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts,
    #       mock module.run_command() -> (0, 'Current: =ep', '')
    #       mock module.get_bin_path() -> '/bin/capsh'
    #       mock module.run_command() -> (0, 'Current: =ep', '')
    #       assert facts_dict == {'system_capabilities_enforced': 'False',
    #                             'system_capabilities': []}
    pass

# Generated at 2022-06-17 01:41:12.493749
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    # NOTE: this is a 'mock' module, not the real module
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_results.append((0, 'Current: =ep', ''))
            self.run_command_results.append((0, 'Current: =ep cap_net_raw+eip', ''))
            self.run_command_results.append((0, 'Current: =ep cap_net_raw+eip cap_net_admin+eip', ''))
            self

# Generated at 2022-06-17 01:41:21.450797
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is a bit of a mess, but it's better than nothing -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collect

# Generated at 2022-06-17 01:41:30.061618
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances

# Generated at 2022-06-17 01:41:41.205407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:41:42.328235
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real unit test
    pass

# Generated at 2022-06-17 01:41:50.538033
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:52.522353
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, replace with actual test
    assert True

# Generated at 2022-06-17 01:41:54.287020
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() -akl
    pass

# Generated at 2022-06-17 01:43:03.055268
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorNotFound
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_fact_names

# Generated at 2022-06-17 01:43:05.056268
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, to be implemented
    pass

# Generated at 2022-06-17 01:43:07.893381
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but will be filled in as needed -akl
    pass

# Generated at 2022-06-17 01:43:10.916018
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test -akl
    pass

# Generated at 2022-06-17 01:43:20.769831
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import load_collectors_from_module
    from ansible.module_utils.facts.collector import load_collectors_from_module_names
    from ansible.module_utils.facts.collector import load_collect

# Generated at 2022-06-17 01:43:28.762010
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFile
    from ansible.module_utils.facts.collector import File

# Generated at 2022-06-17 01:43:35.990240
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:43.323681
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:53.930108
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []
    module.run_command.return_value = (0, 'Current: =ep cap_sys_admin,cap_sys_chroot+eip', '')
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'True'
    assert facts['system_capabilities'] == ['cap_sys_admin', 'cap_sys_chroot']

# Generated at 2022-06-17 01:43:56.552393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need to mock module.run_command()
    pass