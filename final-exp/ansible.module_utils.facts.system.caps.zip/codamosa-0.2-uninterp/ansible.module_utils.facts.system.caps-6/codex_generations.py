

# Generated at 2022-06-17 01:34:56.232787
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector

    # NOTE: using a class variable for the fact_ids set
    #       to avoid the need to update the test when the
    #       set is updated
    fact_ids = SystemCapabilitiesFactCollector._fact_ids

    # NOTE: using a class variable for the name string
    #       to avoid the need to update the test when the
    #       string is updated
    name = SystemCapabilitiesFactCollector.name

    # NOTE: using a class variable for the required_module
    #       to avoid the

# Generated at 2022-06-17 01:35:08.118442
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data

# Generated at 2022-06-17 01:35:09.634975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:35:21.071475
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:35:22.268764
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: mock module.run_command() and module.get_bin_path()
    pass

# Generated at 2022-06-17 01:35:29.473924
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and module.run_command()
    # NOTE: mock module.run_command() -> get_caps_data()/parse_caps_data()
    # NOTE: mock get_caps_data()/parse_caps_data() -> capsh_data
    # NOTE: mock capsh_data -> capsh_data_enforced, capsh_data_enforced_caps
    # NOTE: mock capsh_data_enforced, capsh_data_enforced_caps
    # NOTE: assert expected results
    pass

# Generated at 2022-06-17 01:35:39.646664
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:50.238333
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:01.310645
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import System

# Generated at 2022-06-17 01:36:11.430489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import load_collectors_from_module


# Generated at 2022-06-17 01:36:16.922385
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:36:26.911831
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesNetworkFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSeLinuxFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSelinuxLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSelin

# Generated at 2022-06-17 01:36:28.621054
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:36:38.715925
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_paths

# Generated at 2022-06-17 01:36:46.702989
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest

    class TestModule(object):
        def __init__(self, run_command_args, run_command_rc):
            self.run_command_args = run_command_args
            self.run_command_rc = run_command_rc

        def get_bin_path(self, binary):
            return '/bin/capsh'

        def run_command(self, args, errors='surrogate_then_replace'):
            if args != self.run_command_args:
                raise Exception("Unexpected args: %s" % args)
            return self.run_command_rc, '', ''


# Generated at 2022-06-17 01:36:56.345508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:37:07.519006
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactModule
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactParser

    # Create a mock module
    mock_module = CapabilitiesFactModule()
    mock_module.run_command = lambda x, errors='surrogate_then_replace': (0, 'Current: =ep', '')

    # Create a mock parser
    mock_parser = CapabilitiesFactParser()

# Generated at 2022-06-17 01:37:17.101280
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:37:20.944992
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() -akl
    module = None
    collected_facts = None
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module, collected_facts)
    assert facts['system_capabilities_enforced'] == 'NA'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-17 01:37:27.738370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a bit of a hack, but it's the best way to test this
    #       without having to actually run capsh on the system
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:37:40.787316
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_classes_names
   

# Generated at 2022-06-17 01:37:46.275635
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import _get_collectors_from_directory
    from ansible.module_utils.facts.collector import _get_collectors_from_class
    from ansible.module_utils.facts.collector import _get_collectors_from_module
    from ansible.module_utils.facts.collector import _get_collectors_from_file
    from ansible.module_utils.facts.collector import _get_collectors_from_package
    from ansible.module_utils.facts.collector import _get_collectors_from

# Generated at 2022-06-17 01:37:57.117009
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:38:05.269687
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.capsh_path = os.path.join(self.tempdir, 'capsh')
            with open(self.capsh_path, 'w') as f:
                f.write('''#!/bin/sh
echo "Current: =ep"
''')
            os.chmod(self.capsh_path, 0o755)
            self.old_path = os.environ['PATH']
            os

# Generated at 2022-06-17 01:38:13.654358
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:15.284340
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented -akl
    pass

# Generated at 2022-06-17 01:38:24.633045
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a very basic test, more tests are needed -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collectors_

# Generated at 2022-06-17 01:38:25.927451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented -akl
    pass

# Generated at 2022-06-17 01:38:34.467436
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subsets
    from ansible.module_utils.facts.collector import list_deprecated_facts
    from ansible.module_utils.facts.collector import list_deprecated_names
    from ansible.module_utils.facts.collector import list_

# Generated at 2022-06-17 01:38:41.634015
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import _get_collector_class
    from ansible.module_utils.facts.collector import _get_collector_class_by_name
    from ansible.module_utils.facts.collector import _get_

# Generated at 2022-06-17 01:38:50.289591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub test, replace with real test -akl
    assert True

# Generated at 2022-06-17 01:39:01.290321
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:13.205069
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import unittest
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.distribution.gentoo

# Generated at 2022-06-17 01:39:21.757683
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:39:22.874918
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:39:34.709787
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsCache
    from ansible.module_utils.facts.collector import get_collector_cache
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:39:35.816794
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:39:43.021417
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:51.849489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector

# Generated at 2022-06-17 01:40:01.592473
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:27.922527
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_uuid

# Generated at 2022-06-17 01:40:35.941535
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network

# Generated at 2022-06-17 01:40:45.177069
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    # NOTE: this is a hack to get the module_utils path on the python path
    #       so we can import the module_utils.basic module.
    #       This is needed because we are running the unit tests from the
    #       test directory, and the module_utils directory is not in the
    #       python path.
    #       This is not needed if the unit tests are run from the root
    #       directory.
    #       This is a temporary solution until we have a better way to
    #       handle this.
    #

# Generated at 2022-06-17 01:40:53.522439
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:01.721094
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_

# Generated at 2022-06-17 01:41:11.776596
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:41:20.792030
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:41:26.049834
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:32.456173
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not really testing anything, just checking for syntax errors -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapabilitiesEnforcedFactCollector
    from ansible.module_utils.facts.system.caps import CapabilitiesFactModule
    from ansible.module_utils.facts.system.caps import CapabilitiesEnforcedFactModule
    from ansible.module_utils.facts.system.caps import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapabilitiesEnforcedFactCollector

# Generated at 2022-06-17 01:41:41.848326
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collectors_instances
    from ansible.module_utils.facts.collector import get_collectors_names
    from ansible.module_utils.facts.collector import get_collectors_for_fact
    from ansible.module_utils.facts.collector import get_fact_collectors_names
    from ansible.module_utils.facts.collector import get_fact_collectors_instances
    from ansible.module_utils.facts.collector import get_fact_collectors

# Generated at 2022-06-17 01:42:08.363284
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:42:15.724084
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:42:23.844911
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:42:31.068726
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import sys
    import os
    import tempfile

    # NOTE: this is a bit of a hack to get around the fact that we can't
    #       mock the module_utils.facts.collector.BaseFactCollector class
    #       directly.
    #
    #       We create a temporary module that imports the class we want to
    #       mock and then mock that module.  We then import the temporary
    #       module and use it to instantiate the class we want to mock.
    #
    #       This is a bit convoluted, but it works.
    #
    #       See: https://stackoverflow.com/a/42651480/938297
    #
    #       This is a bit of a hack to get around the fact that we can't
    #       mock the module_utils.facts.collector.

# Generated at 2022-06-17 01:42:40.683289
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            return '/bin/capsh'


# Generated at 2022-06-17 01:42:43.792613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:42:50.314936
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import platform
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import filter_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names_from_ids


# Generated at 2022-06-17 01:42:59.423094
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:12.729375
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_cache
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:43:19.305995
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_names
    from ansible.module_utils.facts.collector import get_collector_status_values
    from ansible.module_utils.facts.collector import get_collector_subset_names

# Generated at 2022-06-17 01:44:31.358084
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:44:35.892093
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:42.179138
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:44:46.507969
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_fact
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_fact

# Generated at 2022-06-17 01:44:50.918820
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, run_command, get_bin_path
    # NOTE: mock run_command output
    # NOTE: call collect
    # NOTE: assert facts_dict
    pass