

# Generated at 2022-06-17 01:34:57.714720
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a bit of a hack, but it's the best way to test this
    #       without having to mock out the module class
    class MockModule:
        def get_bin_path(self, arg):
            return '/bin/capsh'

        def run_command(self, arg, errors):
            return 0, 'Current: =ep', ''

    module = MockModule()
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-17 01:35:08.599508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule

# Generated at 2022-06-17 01:35:20.583037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-17 01:35:27.260191
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:33.369996
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:42.840130
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:53.687826
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # NOTE: this is a hack to get the module_utils.facts.collector.BaseFactCollector class
    #       into the namespace of this test function
    #       so that we can instantiate a BaseFactCollector object
    #       and call the collect method of the SystemCapabilitiesFactCollector class
    #       which is a subclass of BaseFactCollector
    #       and which is the class we are testing
    #       and which is not in the namespace of this test function
    #       so we have to import

# Generated at 2022-06-17 01:36:04.535498
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts for testing -akl
    module = None
    collected_facts = None
    # NOTE: mock run_command() for testing -akl

# Generated at 2022-06-17 01:36:13.081855
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-17 01:36:24.614640
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import get_file_lines
    from ansible.module_utils.facts.collector.system import get_file_size
    from ansible.module_utils.facts.collector.system import get_file_type
    from ansible.module_utils.facts.collector.system import get_mount_size
    from ansible.module_utils.facts.collector.system import get_mount_options

# Generated at 2022-06-17 01:36:36.692571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileGlob
    from ansible.module_utils.facts.collector import FileGlob
    from ansible.module_utils.facts.collector import get_file_glob_instance
    from ansible.module_utils.facts.collector import get_file_glob_names
   

# Generated at 2022-06-17 01:36:41.809911
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() -akl
    module = None
    collected_facts = None
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(module, collected_facts)
    assert result == {}

# Generated at 2022-06-17 01:36:44.699606
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:36:48.132842
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() -akl
    # NOTE: mock capsh_path, out, err -akl
    # NOTE: mock facts_dict -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:36:48.843771
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:36:58.640524
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:37:08.842074
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import list_fact_ids
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import get_fact_names_from_id

# Generated at 2022-06-17 01:37:17.895885
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:37:21.233456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test collect method of class SystemCapabilitiesFactCollector
    """
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:37:32.102041
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class

    # test for class SystemCapabilitiesFactCollector
    # instantiate SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_instance = SystemCapabilitiesFactCollector()
    # test for class SystemCapabilitiesFactCollector
   

# Generated at 2022-06-17 01:37:48.193035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance

# Generated at 2022-06-17 01:37:49.178327
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:37:50.650015
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented -akl
    pass

# Generated at 2022-06-17 01:38:01.590909
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import textwrap
    import pytest

    # NOTE: this is a bit of a hack, but it's the best way to get a
    #       module object without actually running the module code
    #       (which would be a lot of work to set up)
    # NOTE: we use the 'ping' module here because it's a no-op module
    #       that doesn't require any special privileges
    from ansible.modules.system import ping

    # NOTE: we need to make sure that the module path is in sys.path
    #       so that AnsibleModule can be imported
    module_path = os.path.dirname(ping.__file__)
    if module_path not in sys.path:
        sys.path.append(module_path)

# Generated at 2022-06-17 01:38:10.726776
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and module.run_command() -akl
    module = Mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    capsh_path = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-17 01:38:11.510480
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now
    pass

# Generated at 2022-06-17 01:38:20.526089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists
    from ansible.module_utils.facts.utils import get_file_lines_if_exists
    from ansible.module_utils.facts.utils import get_mount_size
   

# Generated at 2022-06-17 01:38:31.119699
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_module_instance
    from ansible.module_utils.facts.collector import get_module_instance
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.collector import get_file

# Generated at 2022-06-17 01:38:40.384271
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:50.289054
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_fact_ids

# Generated at 2022-06-17 01:39:16.287431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            return self.path

        def run_command(self, cmd, errors):
            return (0, 'Current: =ep', '')

    class MockFactsCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self, name):
            self.name = name

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()


# Generated at 2022-06-17 01:39:22.832546
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:34.661317
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:39:44.743316
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_names
   

# Generated at 2022-06-17 01:39:52.330686
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_for_platform
    from ansible.module_utils.facts.collector import get_collector_class_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_class_

# Generated at 2022-06-17 01:39:57.010122
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: This is a stub test.
    #       Please add unit tests for your collector.
    #       See https://github.com/ansible/ansible/blob/devel/test/units/modules/utils/test_module_utils_facts_collectors.py
    #       for examples.
    assert True

# Generated at 2022-06-17 01:40:04.560883
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_status

# Generated at 2022-06-17 01:40:05.991118
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:40:08.532890
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test
    assert True

# Generated at 2022-06-17 01:40:19.992129
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors_for_fact
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors

# Generated at 2022-06-17 01:41:01.563169
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_collector_

# Generated at 2022-06-17 01:41:11.754051
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:13.615290
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but this is a good place to put unit tests
    # for the collect method of SystemCapabilitiesFactCollector
    pass

# Generated at 2022-06-17 01:41:20.863024
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import DictFileCacheCollector
    from ansible.module_utils.facts.collector import DictFileCacheMappingCollector
    from ansible.module_utils.facts.collector import DictFileCacheMappingCollector
    from ansible.module_utils.facts.collector import DictFileCacheM

# Generated at 2022-06-17 01:41:22.165207
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, module.run_command() -akl
    pass

# Generated at 2022-06-17 01:41:30.526709
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:41.232083
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: mock get_caps_data()/parse_caps_data()
    def mock_get_caps_data(module):
        return 'Current: =ep'


# Generated at 2022-06-17 01:41:48.252034
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector

# Generated at 2022-06-17 01:41:55.258951
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:42:04.402785
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:14.925694
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.system.date_time
    import ansible.module_utils.facts.system.dns
    import ansible.module

# Generated at 2022-06-17 01:43:21.779995
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:28.826315
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 01:43:38.033922
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import list_collectors_by_category
    from ansible.module_utils.facts.collector import list_enabled

# Generated at 2022-06-17 01:43:39.498264
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but will be fleshed out in the future -akl
    pass

# Generated at 2022-06-17 01:43:46.411021
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:43:48.336308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    assert False

# Generated at 2022-06-17 01:43:55.601545
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:01.529628
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFacts
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsParser
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsParserFactory
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactsParserFactoryImpl

# Generated at 2022-06-17 01:44:05.011144
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need to mock module.run_command() -akl
    pass