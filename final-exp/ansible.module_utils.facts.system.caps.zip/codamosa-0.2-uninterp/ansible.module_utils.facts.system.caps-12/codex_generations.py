

# Generated at 2022-06-17 01:34:51.836913
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: add unit test for method collect of class SystemCapabilitiesFactCollector -akl
    pass

# Generated at 2022-06-17 01:35:01.531219
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:04.218676
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now, but we should add a unit test for this
    #       fact module.
    pass

# Generated at 2022-06-17 01:35:13.003384
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:35:14.629948
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:35:15.941928
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub test, replace with real test -akl
    assert True

# Generated at 2022-06-17 01:35:24.061123
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary executable file
    fd, tmpexec = tempfile.mkstemp()
    os.close(fd)
    os.chmod(tmpexec, 0o755)

    # Create a temporary module
    fd, tmpmodule = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-17 01:35:30.844582
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not really a unit test, but a functional test,
    #       since it depends on the system having capsh installed.
    #       It is here for now, because it is better than no test at all.
    #       If you are reading this, please consider writing a proper unit test.
    #       -akl
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_no_capsh
    from ansible.module_utils.facts.system.caps import test_SystemCapabilities

# Generated at 2022-06-17 01:35:41.523495
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object and method run_command() -akl
    module = Mock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    module.get_bin_path.return_value = '/usr/bin/capsh'
    # NOTE: mock collected_facts dict -akl
    collected_facts = {}
    # NOTE: create instance of SystemCapabilitiesFactCollector -akl
    sut = SystemCapabilitiesFactCollector()
    # NOTE: call method collect() -akl
    result = sut.collect(module, collected_facts)
    # NOTE: assert result -akl
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': []}


# Generated at 2022-06-17 01:35:52.112341
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:35:55.940208
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real unit test -akl
    assert True

# Generated at 2022-06-17 01:36:05.612488
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:14.540395
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:20.097208
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names

# Generated at 2022-06-17 01:36:21.632694
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:36:32.426275
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileGlob
    from ansible.module_utils.facts.collector import FileGlob
    from ansible.module_utils.facts.collector import get_file_glob_instance
    from ansible.module_utils.facts.collector import get_file_glob_names
   

# Generated at 2022-06-17 01:36:42.007145
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-17 01:36:51.670894
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:59.672223
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:37:05.581323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock run_command()
    #       -> get_caps_data()/parse_caps_data() for easier mocking -akl
    #       -> get_bin_path() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:37:14.490072
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, module.run_command(), and parse_caps_data() -akl
    pass

# Generated at 2022-06-17 01:37:20.914311
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    module.get_bin_path = Mock(return_value='/bin/capsh')
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-17 01:37:27.712875
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_fact_on_

# Generated at 2022-06-17 01:37:39.343102
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is not very good, but it's better than nothing -akl
    import os
    import sys
    import tempfile
    import textwrap
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFile

# Generated at 2022-06-17 01:37:43.286170
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub for now -akl
    pass

# Generated at 2022-06-17 01:37:55.256840
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # NOTE: get_collector_instance()/get_collector_names()/list_collectors()
    #       for easier mocking -akl
    # NOTE: get_collector_instance()/get_collector_names()/list_collectors()
    #       for easier mocking -akl
    # NOTE: get_collector_instance()/get_collector_names()/list_collectors()
    #       for easier mocking -akl
    # NOTE: get_collector_instance()

# Generated at 2022-06-17 01:38:03.293833
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesModule
    from ansible.module_utils.facts.system.capabilities import CapabilitiesParser
    from ansible.module_utils.facts.system.capabilities import CapabilitiesData
    from ansible.module_utils.facts.system.capabilities import CapabilitiesDataParser
    from ansible.module_utils.facts.system.capabilities import CapabilitiesDataParserError
    from ansible.module_utils.facts.system.capabilities import CapabilitiesDataParserErrorNoData

# Generated at 2022-06-17 01:38:11.829342
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:20.569103
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a unit test for a method in a class, so we need to
    #       instantiate the class first.
    #       We also need to mock the module.run_command() method, so we
    #       need to import the module, and instantiate it.
    #       We also need to mock the module.get_bin_path() method, so we
    #       need to import the module, and instantiate it.
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

# Generated at 2022-06-17 01:38:31.119533
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:46.764946
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented
    pass

# Generated at 2022-06-17 01:38:55.389153
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:39:01.933917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module_utils.basic.AnsibleModule
    # NOTE: mock module_utils.facts.collector.BaseFactCollector.get_bin_path()
    # NOTE: mock module_utils.facts.collector.BaseFactCollector.run_command()
    # NOTE: mock module_utils.facts.collector.BaseFactCollector.parse_caps_data()
    # NOTE: mock module_utils.facts.collector.BaseFactCollector.get_caps_data()
    pass

# Generated at 2022-06-17 01:39:08.944160
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts -akl
    # NOTE: mock run_command() -akl
    # NOTE: mock get_bin_path() -akl
    # NOTE: mock get_caps_data() -akl
    # NOTE: mock parse_caps_data() -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:39:10.665458
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use mock module to test this method -akl
    pass

# Generated at 2022-06-17 01:39:12.459235
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub
    pass

# Generated at 2022-06-17 01:39:21.597223
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:39:33.534781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.vmware
    import ansible.module_utils.facts.system.distribution.windows
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module

# Generated at 2022-06-17 01:39:41.623788
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_collector_

# Generated at 2022-06-17 01:39:50.825810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: 'mock' is a built-in module in Python 3.x, but needs to be installed for Python 2.x
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    # NOTE: 'mock' is a built-in module in Python 3.x, but needs to be installed for Python 2.x
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    # NOTE: 'mock' is a built-in module in Python 3.x, but needs to be installed for Python 2.x
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    # NOTE: 'mock' is a built-in

# Generated at 2022-06-17 01:40:20.921689
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a unit test
    pass

# Generated at 2022-06-17 01:40:31.192246
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:40:37.285106
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts -akl
    # NOTE: mock run_command() -akl
    # NOTE: mock get_bin_path() -akl
    # NOTE: mock get_caps_data()/parse_caps_data() -akl
    # NOTE: assert facts_dict -akl
    pass

# Generated at 2022-06-17 01:40:44.880318
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is a bit of a hack, as it relies on the fact that
    #       the module_utils.facts.collector.BaseFactCollector.collect()
    #       method will return an empty dict if the module argument is None.
    #       This is not a documented feature, and may change in the future.
    #       If this test starts failing, it may be because the
    #       BaseFactCollector.collect() method has been changed to raise an
    #       exception when module is None.
    #       If this happens, the test will need to be updated to mock the
    #       module argument.
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect()
    assert facts == {}

# Generated at 2022-06-17 01:40:46.718844
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, and needs to be implemented
    pass

# Generated at 2022-06-17 01:40:54.533409
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:02.223089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:11.900530
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    capsh_path = '/usr/bin/capsh'
    rc = 0

# Generated at 2022-06-17 01:41:20.956856
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import shutil
    import stat
    import ansible.module_utils.facts.collector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, capsh_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Make the file executable
    os.chmod(capsh_path, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)

    # Create a temporary module
    fd, module_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write the module

# Generated at 2022-06-17 01:41:29.685277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a 'mock' of the ansible module class
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_results.append((0, 'Current: =ep', ''))
            self.run_command_results.append((0, 'Current: =ep cap_net_bind_service,cap_net_raw+eip', ''))
            self.run_command_results.append((1, '', 'capsh: invalid option -- \'e\''))
            self.run_command_results.append((0, '', ''))
            self.run_command_results.append((0, '', 'capsh: invalid option -- \'e\''))

# Generated at 2022-06-17 01:42:26.381684
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLinuxFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesNetBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesOpenBSDFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSolarisFactCollect

# Generated at 2022-06-17 01:42:32.565832
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:42:41.107966
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            return '/bin/capsh'


# Generated at 2022-06-17 01:42:48.086688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and run_command() for easier testing -akl
    module = None
    collected_facts = None
    capsh_path = '/usr/bin/capsh'

# Generated at 2022-06-17 01:42:50.034923
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need to mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:42:59.184209
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test method collect of class SystemCapabilitiesFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileSearch
    from ansible.module_utils.facts.collector import FileSearch
    from ansible.module_utils.facts.collector import get_file_search_instance
    from ansible.module_utils.facts.collector import get_file_search_paths

# Generated at 2022-06-17 01:43:12.620038
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collect

# Generated at 2022-06-17 01:43:21.655943
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesLegacyFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesNetworkFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesPosixFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesSelinuxFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesWindowsFactCollector

# Generated at 2022-06-17 01:43:28.806637
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.system.date_time
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.domain
    import ansible.module_

# Generated at 2022-06-17 01:43:36.025008
# Unit test for method collect of class SystemCapabilitiesFactCollector