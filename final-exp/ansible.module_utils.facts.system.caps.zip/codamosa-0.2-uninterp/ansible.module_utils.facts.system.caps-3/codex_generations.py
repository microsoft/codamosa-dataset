

# Generated at 2022-06-17 01:35:00.424806
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import remove_collector
    from ansible.module_utils.facts.collector import set_collectors
    from ansible.module_utils.facts.collector import unregister_collector

# Generated at 2022-06-17 01:35:03.848529
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, mock run_command()
    #       -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:35:12.812720
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module/run_command() for easier testing -akl
    class MockModule:
        def get_bin_path(self, path):
            return '/usr/bin/capsh'


# Generated at 2022-06-17 01:35:22.281773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-17 01:35:31.321649
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_by_name
    from ansible.module_utils.facts.collector import get_collectors

# Generated at 2022-06-17 01:35:32.225346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, add real unit test -akl
    assert True

# Generated at 2022-06-17 01:35:42.446887
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_subset

# Generated at 2022-06-17 01:35:53.520343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import CollectorNotFound
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_fact_id

# Generated at 2022-06-17 01:35:54.835104
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real test
    assert True

# Generated at 2022-06-17 01:36:05.100782
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:36:16.393796
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a very basic test, it just checks that the method
    #       does not crash and returns a dict
    #       more tests are needed to check that the output is correct
    #       and that the method behaves as expected
    #       (e.g. when capsh is not installed)
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, executable):
            return '/bin/capsh'


# Generated at 2022-06-17 01:36:26.497270
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:36:35.902475
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors_for_sources
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes

# Generated at 2022-06-17 01:36:46.119905
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:36:48.816450
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and collected_facts
    # NOTE: mock module.run_command()
    # NOTE: mock module.get_bin_path()
    # NOTE: assert facts_dict == expected_facts_dict
    pass

# Generated at 2022-06-17 01:36:58.641881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is a bit of a mess, but it's better than nothing -akl
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: this is a bit of a mess, but it's better than nothing -akl
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.params['capsh_path'] = '/usr/bin/capsh'

# Generated at 2022-06-17 01:37:08.842767
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and facts_dict -akl
    module = None
    facts_dict = {}
    # NOTE: mock capsh_path -akl
    capsh_path = None
    # NOTE: mock rc, out, err -akl
    rc = 0

# Generated at 2022-06-17 01:37:17.895448
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances

# Generated at 2022-06-17 01:37:27.119408
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution

    # NOTE: This is a hack to get around the fact that the
    #       'ansible.module_utils.facts.collector' module is not a real
    #       python module.  It is dynamically created as a part of the
    #       ansible.module_utils.facts package.  This means that it cannot be
    #       imported directly.  The following code creates a fake module
    #       object that can be used to import the SystemCapabilitiesFactCollector
    #       class.
    #
    #       The code below is based on the code in the 'importlib' module.
    #      

# Generated at 2022-06-17 01:37:35.291582
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 01:37:52.985823
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is incomplete -akl
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type

# Generated at 2022-06-17 01:38:02.310854
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:12.414559
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.version
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone

# Generated at 2022-06-17 01:38:20.604292
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:38:23.066894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub to be replaced with a proper test -akl
    pass

# Generated at 2022-06-17 01:38:29.560046
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_fact_ids_from_collectors
    from ansible.module_utils.facts.collector import get_fact_ids_from_collection_type
    from ansible.module_utils.facts.collector import get_fact_names_from_collectors
    from ansible.module_utils.facts.collector import get_fact_names_from_collection

# Generated at 2022-06-17 01:38:36.515034
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, executable, required=False):
            return executable

        def run_command(self, args, errors='surrogate_then_replace'):
            return 0, 'Current: =ep', ''

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.collector = SystemCapabilitiesFactCollect

# Generated at 2022-06-17 01:38:44.858097
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import BaseFileModuleFactsCollector
    from ansible.module_utils.facts.collector import FileModuleFactsCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector


# Generated at 2022-06-17 01:38:54.304367
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module_utils.facts.collector.BaseFactCollector
    #       and module_utils.facts.collector.SystemCapabilitiesFactCollector
    #       for easier mocking -akl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts

# Generated at 2022-06-17 01:39:02.438161
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data
    from ansible.module_utils.facts.collector.system import get_caps_data
    from ansible.module_utils.facts.collector.system import parse_caps_data

# Generated at 2022-06-17 01:39:21.537014
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collector_

# Generated at 2022-06-17 01:39:23.132863
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, needs to be implemented -akl
    pass

# Generated at 2022-06-17 01:39:25.299962
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use mock module to mock module.run_command() -akl
    pass

# Generated at 2022-06-17 01:39:36.235362
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exclusions
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_

# Generated at 2022-06-17 01:39:45.643920
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactsCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Write data to the temporary file
    tmpfile.write(b"Current: =ep\n")

# Generated at 2022-06-17 01:39:47.349110
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module, get_bin_path(), run_command() -akl
    pass

# Generated at 2022-06-17 01:39:58.856865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module and module.run_command() -akl
    module = None
    collected_facts = None

# Generated at 2022-06-17 01:40:12.218324
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as test_collect
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_caps_enforced as test_collect_caps_enforced
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_caps_not_enforced as test_collect_caps_not_enforced
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect_caps_not_enforced_no_capsh as test_collect_caps_

# Generated at 2022-06-17 01:40:22.278576
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector

    # NOTE: mock module_utils.facts.collector.BaseFactCollector
    BaseFactCollector_mock = ansible.module_utils.facts.collector.BaseFactCollector
    BaseFactCollector_mock.collect = lambda self, module=None, collected_facts=None: {}

    # NOTE: mock module_utils.facts.collector.SystemCapabilitiesFactCollector.get_caps_data()
    def get_caps_data_mock():
        return 0, 'Current: =ep', ''

    # NOTE: mock module_utils.facts.collector.SystemCapabilitiesFactCollector.parse_caps_data()
    def parse_caps_data_mock(data):
        return 'NA', []

    # NOTE: mock module_utils.basic.Ans

# Generated at 2022-06-17 01:40:32.571697
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileModuleFactsCollector
    from ansible.module_utils.facts.collector import FileModuleFactsCollector
    from ansible.module_utils.facts.collector import get_file_module_collector_instance

# Generated at 2022-06-17 01:40:56.642411
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a unit test for the method collect of class SystemCapabilitiesFactCollector
    #       it is not a unit test for the module_utils.facts.system.caps module
    #       which is tested in test_module_utils_facts_system_caps.py
    #       -akl
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # NOTE: create a temporary directory to use as a fake bin directory
    #       to test the SystemCapabilitiesFactCollector class
    #       -akl
    temp_dir = tempfile

# Generated at 2022-06-17 01:41:08.078981
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collect

# Generated at 2022-06-17 01:41:16.383630
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:41:19.180182
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# Generated at 2022-06-17 01:41:22.320455
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a stub, not a real unit test -akl
    module = None
    collected_facts = None
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(module, collected_facts)
    assert result == {}

# Generated at 2022-06-17 01:41:30.641512
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: mock module and get_caps_data()/parse_caps_data() -akl
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

       

# Generated at 2022-06-17 01:41:41.235014
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:41:48.252134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors


# Generated at 2022-06-17 01:41:59.654703
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, path):
            return '/bin/capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (self.rc, self.out, self.err)

    # Test with capsh returning 'Current: =ep'

# Generated at 2022-06-17 01:42:07.596662
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object -akl
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/bin/capsh'

# Generated at 2022-06-17 01:42:49.509477
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_paths

# Generated at 2022-06-17 01:42:59.006624
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:43:12.591488
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import CachingFileMixin
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkFileCacheMixin
    from ansible.module_utils.facts.collector import NetworkCollector

# Generated at 2022-06-17 01:43:21.655800
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

    # NOTE: mock module_util.facts.collector.BaseFactCollector.collect()
    #       to avoid calling BaseFactCollector.collect()
    #       which would call module.run_command()
    #       which would fail in a unit test environment
    #       because module is not defined
    ansible.module_utils.facts.collector.BaseFactCollector.collect = lambda self: {}

    # NOTE: mock module.run_command() to return a known value
    #       to avoid calling module.run_command()
    #       which would fail in a unit test environment
    #       because module is not defined
    ansible.module_utils.facts

# Generated at 2022-06-17 01:43:28.806521
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileWriteCollector
    from ansible.module_utils.facts.collector import BaseFileReadCollector
    from ansible.module_utils.facts.collector import BaseCommandCollector
    from ansible.module_utils.facts.collector import BasePreserveCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseDictMergeCollector
    from ansible.module_utils.facts.collector import BaseSetMergeCollector

# Generated at 2022-06-17 01:43:36.024415
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.caps

# Generated at 2022-06-17 01:43:43.352654
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceDictCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceListCollector

# Generated at 2022-06-17 01:43:54.012335
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_network_collect

# Generated at 2022-06-17 01:44:01.452072
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-17 01:44:13.554797
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import get_file_collector_instance
    from ansible.module_utils.facts.collector import get_file_collector_names