

# Generated at 2022-06-24 23:31:55.892690
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    actual_return_value_0 = system_capabilities_fact_collector_0.collect()
    assert actual_return_value_0 == {}


# Generated at 2022-06-24 23:32:06.334175
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # assert not system_capabilities_fact_collector_0.collect(module=None) == expected_result
    # assert system_capabilities_fact_collector_0.collect(module=None) == expected_result
    # assert system_capabilities_fact_collector_0.collect(module=None) == expected_result
    # assert system_capabilities_fact_collector_0.collect(module=None) == expected_result
    # assert not system_capabilities_fact_collector_0.collect(module=None) == expected_result
    # assert not system_capabilities_fact_collector_0.collect(module=None) == expected_result
    # assert not system_capabilities_fact_collector_0.collect(module

# Generated at 2022-06-24 23:32:07.150770
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO (must be implemented)
    pass


# Generated at 2022-06-24 23:32:07.944434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: not testing for now, will be developed with fully implemented fact
    pass

# Generated at 2022-06-24 23:32:10.237128
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:32:12.184717
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()



# Generated at 2022-06-24 23:32:15.013162
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Check method collect return
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:17.047117
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}


# Generated at 2022-06-24 23:32:19.360286
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:32:21.530081
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:32:29.841354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA'}, 'incorrect value for var_0'


# Generated at 2022-06-24 23:32:36.199438
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Testing: SystemCapabilitiesFactCollector.collect')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:32:37.002660
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:32:41.651179
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}

test_dict = {"SystemCapabilitiesFactCollector": {"test_case_0": test_case_0, "test_SystemCapabilitiesFactCollector_collect": test_SystemCapabilitiesFactCollector_collect, }}



# Generated at 2022-06-24 23:32:44.291774
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:50.314827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # No module
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}
    # No capsh
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(module=None, collected_facts=None)
    assert var_1 == {}
    # Capabilities not enforced
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    class MockModuleReturn(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err

# Generated at 2022-06-24 23:32:58.413742
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    module = AnsibleModuleStub()

# Generated at 2022-06-24 23:33:08.839536
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorNotFoundException
    try:
        from unittest.mock import Mock, patch, MagicMock
    except ImportError:
        from mock import Mock, patch, MagicMock
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # AssertionError: expected 'system_capabilities_enforced' of <ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector object at 0x101eec8d0> to be None but was 'NA'
    # assert system_capabilities_fact_collector_0.collect()['system_capabilities_enforced'] is None
    # AssertionError: expected 'system_capabilities' of <ansible.module_utils.facts.system.caps.SystemCapabilitiesFact

# Generated at 2022-06-24 23:33:15.834727
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = system_capabilities_fact_collector.collect()

    assert(facts_dict['system_capabilities_enforced'] == 'True')

# Generated at 2022-06-24 23:33:23.454398
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = ModuleStub()
    var_2 = var_1.run_command([var_1.get_bin_path('capsh'), '--print'], 'surrogate_then_replace')
    var_1.set_command_return(var_2)
    var_3 = var_2[1].splitlines()
    var_4 = []
    var_5 = var_0.collect(var_1, 'foo')
    assert var_5 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:33:34.207681
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:33:37.363223
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    my_module = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(module=my_module)
    for key_1, value_1 in var_1.items():
        assert False


# Generated at 2022-06-24 23:33:47.972415
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # set up mock
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    module_mock = MockAnsibleModule()
    module_mock.get_bin_path.return_value = '/some/bin/path'
    module_mock.run_command.return_value = (0, 'Current: =ep', '')

    # instantiate object
    system_capabilities_fact_collector_obj = SystemCapabilitiesFactCollector()

    # execute method and point out mocked module
    system_capabilities_fact_collector_out = system_capabilities_fact_collector_obj.collect(module=module_mock)
    assert system_capabilities_fact_collector_out['system_capabilities_enforced'] == 'False'
    assert system_capabilities_fact_

# Generated at 2022-06-24 23:33:56.960760
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:34:01.858227
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: disable deprecation warning in test -akl
    #import warnings
    #warnings.filterwarnings("ignore", category=DeprecationWarning)
    result = SystemCapabilitiesFactCollector.collect()
    assert result is None


# Generated at 2022-06-24 23:34:08.820917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Implementing mock for ansible module class
    class MockAnsibleModule:
        def __init__(self, bin_path=None):
            self.bin_path = bin_path
        # Implementing method get_bin_path of class ansible module
        def get_bin_path(self, bin_path):
            return self.bin_path
        # Implementing method run_command of class ansible module
        def run_command(self, command, errors='surrogate_then_replace'):
            rc = 0
            out = 'Current: =ep'
            err = ''
            if len(command) > 1:
                if command[1] == '-V':
                    out = 'capsh v1.0'
                if command[1] == '-h':
                    out = 'help'

# Generated at 2022-06-24 23:34:09.323584
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:34:13.366575
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # TODO: How can we mock out 'module' parameter using python standard lib?


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:34:14.109759
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:34:19.442087
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Providing the parameters of the value to be tested
    var_0 = {}
    var_0['bin_path'] = 'D:/ansible/ansible-1.9.4/hoge'
    var_0['warn'] = False
    var_0['run_command'] = 'capsh --print'
    # Calling the method
    var_1 = system_capabilities_fact_collector_0.collect(var_0)
    # Asserting the value of var_1
    assert var_1 == {}

# Generated at 2022-06-24 23:34:33.463301
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:37.655896
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Create a new instance of SystemCapabilitiesFactCollector class
    system_capabilities_fact_collector_var_0 = SystemCapabilitiesFactCollector()

    # Call method collect of SystemCapabilitiesFactCollector class 
    res = system_capabilities_fact_collector_var_0.collect()

    # Assert the equality of expression "res" and "expected"
    # Test will fail if expression "res" and "expected" are not equal
    assertEquals(res, expected)


# Generated at 2022-06-24 23:34:44.657532
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    #capsh_path = module.get_bin_path('capsh')
    #print(capsh_path)
    #rc, out, err = module.run_command([capsh_path, "--print"])
    #print(out)
    #print(rc)
    #print(err)
    #print(system_capabilities_fact_collector._fact_ids)
    var = system_capabilities_fact_collector.collect()
    #print(var)
    #print(var.keys())



# Generated at 2022-06-24 23:34:49.620033
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 23:34:56.845816
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = ansible_fake_module

# Generated at 2022-06-24 23:34:58.918399
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-24 23:35:01.345497
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}, var_0

# Generated at 2022-06-24 23:35:01.759024
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:35:07.294157
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:09.422624
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:40.368843
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert test_case_0() == {'system_capabilities': [],
                             'system_capabilities_enforced': 'NA'}, \
        "Failed to run test_case_0."

# Generated at 2022-06-24 23:35:42.464107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:35:47.516925
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-24 23:35:51.502326
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    system_capabilities_fact_collector.collect(collected_facts)
    assert collected_facts == {}
#    assert False, 'An assertion error was found'


if __name__ == "__main__":
    test_case_0()
    # test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:35:53.010961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    up_test_mc = SystemCapabilitiesFactCollector()
    up_test_mc.collect()

# Generated at 2022-06-24 23:36:01.895472
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    expected = {}

    class mock_module:
        class run_command():
            pass
    
    module = mock_module
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    capsh_path = module.get_bin_path
    system_capabilities_fact_collector_0.capsh_path = capsh_path
    module = mock_module
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    rc, out, err = module.run_command
    system_capabilities_fact_collector_0.rc, out, err = rc, out, err
    
   

# Generated at 2022-06-24 23:36:07.760702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        var_0 = system_capabilities_fact_collector_0.collect()
        assert True
    except Exception as e:
        print('Caught exception in test: {}'.format(e))
        assert False


# Generated at 2022-06-24 23:36:14.125567
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    var_2 =ModuleStub()
    var_3 = var_1.collect(module=var_2)

# Generated at 2022-06-24 23:36:20.896255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0.__class__ == dict
    assert len(var_0.keys()) == 2
    assert 'system_capabilities' in var_0.keys()
    assert var_0['system_capabilities'].__class__ == list
    assert len(var_0['system_capabilities']) == 0
    assert 'system_capabilities_enforced' in var_0.keys()
    assert var_0['system_capabilities_enforced'] == 'NA'

# Generated at 2022-06-24 23:36:21.621715
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # No code to test
    pass


# Generated at 2022-06-24 23:37:25.774068
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:37:27.409192
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    if not system_capabilities_fact_collector.collect():
        assert True


# Generated at 2022-06-24 23:37:35.259244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()
    mock_run_command = Mock()
    mock_command = ["capsh", '--print']

# Generated at 2022-06-24 23:37:37.031945
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:37:43.912137
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    if (var_1 == {}):
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:37:47.402408
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert not var_0
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:37:48.698388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:37:51.789912
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


# Generated at 2022-06-24 23:37:56.934422
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Controller
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Test case 0
    test_case_0()

# Entry point
if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:37:59.750516
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() != []

# Generated at 2022-06-24 23:40:25.710052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    expected_0 = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    var_0 = system_capabilities_fact_collector_0.collect()

    def mock_run_command(self, cmd, *args, **kwargs):
        out_0 = 'Current: =ep'
        err_0 = ''
        rc_0 = 0
        return rc_0, out_0, err_0

    expected_1 = {'system_capabilities': [], 'system_capabilities_enforced': 'False'}
    with patch('ansible.module_utils.facts.collector.BaseFactCollector.run_command', mock_run_command):
        var_1 = system_capabilities_

# Generated at 2022-06-24 23:40:26.477678
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:40:34.623638
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert (var_0 == {})
    # assert(system_capabilities_fact_collector_0.system_capabilities == [])
    # assert(system_capabilities_fact_collector_0.system_capabilities_enforced == 'NA')

# Generated at 2022-06-24 23:40:37.017822
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use capsh on localhost and mock command output -akl
    test_case_0()

# Generated at 2022-06-24 23:40:42.976346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # get all system capabilities with enforcement
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    all_system_capabilities = system_capabilities_fact_collector.collect()
    print(all_system_capabilities)

    # get all system capabilities with enforcement == False
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    all_system_capabilities = system_capabilities_fact_collector.collect()
    print(all_system_capabilities)

# Generated at 2022-06-24 23:40:47.064972
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:40:53.001046
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Module import
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector

    # Test object creation
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Test object attributes
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-24 23:40:56.118427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:41:00.085587
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:41:05.643839
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0, var_1 = 0, 1
    for var_2 in range(0, var_1):
        try:
            test_case_0()
            var_0 += 1
        except:
            pass
    assert var_0 == var_1