

# Generated at 2022-06-24 23:31:54.945331
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    print(system_capabilities_fact_collector_1.collect())

# Generated at 2022-06-24 23:31:57.437307
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}



# Generated at 2022-06-24 23:32:04.006436
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:10.754170
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    module = None
    collected_facts = None

    facts_dict = system_capabilities_fact_collector_0.collect(module, collected_facts)

    # Assertion
    assert(facts_dict['system_capabilities_enforced'] == 'NA')
    assert(facts_dict['system_capabilities'] == [])

# Generated at 2022-06-24 23:32:20.407520
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    import json
    test_AnsibleModule_0 = AnsibleModule()
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:21.837037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:32:32.232241
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    mock_module_1 = type('module_1', (object,),
                         {
                            'get_bin_path': (lambda self_1, path_1: '/bin/capsh'),
                            'run_command': (lambda self_1, args_1, **kwargs_1: (0, 'Current: =ep', ''))
                          })

    assert system_capabilities_fact_collector_1.collect(module=mock_module_1(), collected_facts=None) == \
           {'system_capabilities_enforced': 'False',
            'system_capabilities': []}


# Generated at 2022-06-24 23:32:41.534770
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    class MockModule(object):
        params = {}

        def get_bin_path(self, path):
            return '/bin/capsh'

        def run_command(self, args, *args1, **kwargs):
            return (0, 'Current: = cap_net_admin,cap_net_raw+eip\n', '')

    module_0 = MockModule()

    expected = {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_net_admin', 'cap_net_raw']}
    facts_dict = system_capabilities_fact_collector.collect(module=module_0)
    assert facts_dict['system_capabilities_enforced'] == expected['system_capabilities_enforced']


# Generated at 2022-06-24 23:32:48.321900
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:53.280295
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    test_dict0 = {}
    assert system_capabilities_fact_collector_0.collect(module=None, collected_facts=test_dict0, options=None) == {}



# Generated at 2022-06-24 23:32:58.341361
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ret_value_0 = SystemCapabilitiesFactCollector.collect()
    assert ret_value_0 == 'NA'

# Generated at 2022-06-24 23:33:02.307747
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:33:02.857088
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:33:03.969811
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: pass for now -akl
    pass

# Generated at 2022-06-24 23:33:06.481037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:09.257332
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:33:14.822930
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)

# Generated at 2022-06-24 23:33:16.520950
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = None
    var_1 = SystemCapabilitiesFactCollector()
    var_1.collect(var_0)


# Generated at 2022-06-24 23:33:21.945714
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    method_0 = system_capabilities_fact_collector_0.collect
    var_0 = method_0(system_capabilities_fact_collector_0)
    assert (var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []})


# Generated at 2022-06-24 23:33:25.037466
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    system_capabilities_fact_collector.collect(system_capabilities_fact_collector)



# Generated at 2022-06-24 23:33:34.464333
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    var_2 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    pass


# Generated at 2022-06-24 23:33:36.147593
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:33:42.267354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
  from ansible.module_utils.facts.collector.system import parse_caps_data
  data_0 = SystemCapabilitiesFactCollector.collect(0)

  assert data_0['system_capabilities_enforced'] == "NA"


# Generated at 2022-06-24 23:33:45.062359
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:33:51.044332
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_path = '/bin/capsh'

# Generated at 2022-06-24 23:33:55.075368
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert 'system_capabilities_enforced' in system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:34:02.223433
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Imports
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Setup
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect = MagicMock()

    # Tested function call
    system_capabilities_fact_collector_0.collect(BaseFactCollector())

    # assert return value and call count
    system_capabilities_fact_collector_0.collect.assert_called_with(BaseFactCollector())
    assert system_capabilities_fact_collector_0.collect.call_count == 1

# Generated at 2022-06-24 23:34:02.783314
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:34:05.062501
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:34:07.955933
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('In method collect')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert False



# Generated at 2022-06-24 23:34:18.848407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # IOError raised
    try:
        system_capabilities_fact_collector_0.collect()
    # IOError caught and exception handled
    except IOError as e:
        # var_0 contains the string representation of IOError object
        var_0 = str(e)

    assert len(var_0) > 0


# Generated at 2022-06-24 23:34:22.600214
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

# Generated at 2022-06-24 23:34:24.947905
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

# Generated at 2022-06-24 23:34:30.142732
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:34.478654
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)



# Generated at 2022-06-24 23:34:42.211117
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: capsh will not run in the test environment
    # NOTE: the test collector returns pre-setup data
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

    assert 'system_capabilities_enforced' in var_1
    assert 'system_capabilities' in var_1

# Generated at 2022-06-24 23:34:46.855282
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    user_input = 0

    if (user_input == 0):
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:34:49.438528
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:34:52.606771
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    assert isinstance(var_1, dict)



# Generated at 2022-06-24 23:34:57.416901
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:35:07.733079
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert var_1 == {}


# Generated at 2022-06-24 23:35:11.299516
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    with patch.object(SystemCapabilitiesFactCollector, '_get_caps_data', return_value=('stdout', 'stderr')):
        with patch.object(SystemCapabilitiesFactCollector, '_parse_caps_data', return_value=('system_capabilities_enforced', 'system_capabilities')):
            system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:35:12.931454
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:35:16.371534
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert type(var_1) is dict
    assert var_1 == {}


# Generated at 2022-06-24 23:35:23.752322
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible_for_network_engineers.plugins.module_utils.network.facts.facts import Facts


# Generated at 2022-06-24 23:35:26.563831
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    assert var_1 is None

# Generated at 2022-06-24 23:35:30.101107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0) == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}


# Generated at 2022-06-24 23:35:31.940065
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:35:41.897446
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup test case
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.module = None
    system_capabilities_fact_collector_0.collected_facts = None
    
    # Invoke method
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

    # Getting the type of 'var_0' (line 170)
    var_0_type = type(var_0)

    # Asserting the type of 'var_0' (line 170)
    assert var_0_type == dict, "The type of 'var_0' is not 'dict'"
    
    # Call to collect(...): (line 169)
    # Processing the call arguments (

# Generated at 2022-06-24 23:35:48.873268
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    assert(isinstance(var_1, dict))


if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:36:03.619681
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:36:04.213760
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:36:11.512660
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_path = 'ansible_collections.ansible.community.plugins.module_utils.facts.caps.SystemCapabilitiesFactCollector'
    module_0 = imp.load_source('ansible_collections.ansible.community.plugins.module_utils.facts.caps.SystemCapabilitiesFactCollector', module_path)
    system_capabilities_fact_collector_1 = module_0.SystemCapabilitiesFactCollector()
    try:
        var_0 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    except SystemExit as exception:
        assert False


# Generated at 2022-06-24 23:36:16.891917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # -> assert that capsh_path is set, in all methods that use it -akl
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:36:18.856370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('test_SystemCapabilitiesFactCollector_collect')
    collector = SystemCapabilitiesFactCollector()
    data_dict = collector.collect(collector)
    assert set(data_dict.keys()) == collector._fact_ids

# Generated at 2022-06-24 23:36:23.906376
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Unit test for method collect of class SystemCapabilitiesFactCollector

    # NOTE: remember to unindent the rest of the method as well -akl
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0['system_capabilities_enforced'] is None
    assert var_0['system_capabilities'] is None

# Generated at 2022-06-24 23:36:26.306777
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    syste_0 = SystemCapabilitiesFactCollector()
    syste_1 = SystemCapabilitiesFactCollector()
    # Call method collect of SystemCapabilitiesFactCollector with arguments



# Generated at 2022-06-24 23:36:30.999951
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    return


# Generated at 2022-06-24 23:36:31.507183
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('')

# Generated at 2022-06-24 23:36:33.278832
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}

# Generated at 2022-06-24 23:37:09.979760
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of the class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Get the result of method collect of class SystemCapabilitiesFactCollector
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    # Assert the result
    if var_0 != {}:
        raise AssertionError
    # Assert the result
    assert var_0 == {}
    # Create an instance of the class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Get the result of method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:37:12.683892
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # TODO: mock obj or command output for test
    var = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:37:16.883782
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0['system_capabilities_enforced'] == 'NA'
    assert var_0['system_capabilities'] == []

# Generated at 2022-06-24 23:37:23.432530
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:37:25.976335
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1) is None


# Generated at 2022-06-24 23:37:30.867722
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == {"system_capabilities": [], "system_capabilities_enforced": "NA"}


# Generated at 2022-06-24 23:37:31.535206
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:37:37.236469
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFileEntry
    from ansible.module_utils.facts.collector import FileEntry
    from ansible.module_utils.facts.collector import DictFileEntry
    import ansible.module_utils.facts.collector
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    print(var_1)

# Generated at 2022-06-24 23:37:43.632049
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:37:45.701125
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    pass


# Generated at 2022-06-24 23:38:56.454023
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(var_0=None)
    print(var_0['system_capabilities_enforced'])
    print(var_0['system_capabilities'])

# Generated at 2022-06-24 23:39:00.774143
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector_1.collect().get('system_capabilities')
    assert not system_capabilities_fact_collector_1.collect().get('system_capabilities_enforced')
    assert system_capabilities_fact_collector_1.name == 'caps'
    assert system_capabilities_fact_collector_1._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


if __name__ == "__main__":
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:39:03.193425
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    expected = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    assert var_1 == expected


# Generated at 2022-06-24 23:39:04.486059
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Method needs implementation
    pass


# Generated at 2022-06-24 23:39:08.679119
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # No param
    var_1 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:39:16.201145
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    # dummy test
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    var_0 = var_0
    expect_0 = None

    assert(var_0 == expect_0)


# Generated at 2022-06-24 23:39:20.217692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    if var_0 != var_1:
        raise Exception('Failed')

# Generated at 2022-06-24 23:39:29.353187
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_arg_spec = {
        'collector': {
            'required': False,
            'type': 'str'
        }
    }

    system_capabilities_fact_collector_arg_spec.update(BaseFactCollector.collect_set)
    system_capabilities_fact_collector_arg_spec.update(BaseFactCollector.collect_facts)
    system_capabilities_fact_collector_arg_spec.update(collector_collect=system_capabilities_fact_collector_arg_spec)
    system_capabilities_fact_collector_arg_spec.pop("collector")
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector(**system_capabilities_fact_collector_arg_spec )
    var_0 = system

# Generated at 2022-06-24 23:39:38.080430
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: 1st test case {enforced == 'True' && system_capabilities == ['cap_chown']}
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

    # NOTE: 2nd test case {enforced == 'False' && system_capabilities == ['cap_chown']}
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect(system_capabilities_fact_collector_2)

    # NOTE: 3rd test case {enforced == 'NA' && system_capabilities == ['cap_chown']}
    system_capabilities_

# Generated at 2022-06-24 23:39:40.111923
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)