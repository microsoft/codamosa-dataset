

# Generated at 2022-06-24 23:31:54.092688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:31:55.713115
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:01.280817
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    result_0 = system_capabilities_fact_collector_1.collect(module=module)
    assert isinstance(result_0, dict)
    assert result_0 == {}


# Generated at 2022-06-24 23:32:08.246470
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import textwrap
    import io


    # NOTE: get_bin_path() stubs/mocks -akl
    class MockModule(object):
        # NOTE: -> get_bin_path() -akl
        def get_bin_path(self, arg, **kwargs):
            return tempfile.mkstemp()[1]

        # NOTE: pool.apply_async()/get() for easier mocking -akl

# Generated at 2022-06-24 23:32:10.879103
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # TODO: add a test here
    # assert False


# Generated at 2022-06-24 23:32:13.503811
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_1.collect(), dict)

# Generated at 2022-06-24 23:32:17.607142
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # NOTE: maybe mock module.run_command() ? -akl
    # TODO: test without capsh installed and with fake return values for capsh ? -akl
    assert system_capabilities_fact_collector_1.collect().get('system_capabilities') is not None

# Generated at 2022-06-24 23:32:20.273879
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # TODO: Add test cases


# Generated at 2022-06-24 23:32:25.418563
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    empty_module_0 = ''
    empty_module_1 = ''
    SystemCapabilitiesFactCollector_collect_func_0 = SystemCapabilitiesFactCollector()
    result_0 = SystemCapabilitiesFactCollector_collect_func_0.collect(empty_module_0, collected_facts={})
    assert result_0 == {}
    result_1 = SystemCapabilitiesFactCollector_collect_func_0.collect(empty_module_1, collected_facts={})
    assert result_1 == {}


# Generated at 2022-06-24 23:32:36.001255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    caps_facts = system_capabilities_fact_collector.collect()
    assert caps_facts['system_capabilities'] == ['BOUNDING', 'CHOWN', 'DAC_OVERRIDE', 'FOWNER', 'FSETID', 'KILL', 'MKNOD', 'NET_BIND_SERVICE', 'NET_RAW', 'SETFCAP', 'SETGID', 'SETPCAP', 'SETUID', 'SYS_CHROOT', 'AUDIT_WRITE', 'AUDIT_CONTROL', 'MAC_OVERRIDE', 'MAC_ADMIN', 'NET_ADMIN', 'SYSLOG', 'WAKE_ALARM', 'BLOCK_SUSPEND']

# Generated at 2022-06-24 23:32:46.419150
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = 'bin/capsh'
    rc = '0'

# Generated at 2022-06-24 23:32:51.423354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("Method collect not implemented yet.")
    # system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # result = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:52.389228
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:32:59.482864
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # get instance of class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # call collect of class SystemCapabilitiesFactCollector with parameter 
    # get return value of collect of class SystemCapabilitiesFactCollector
    var_0 = system_capabilities_fact_collector_0.collect()
    # call collect of class SystemCapabilitiesFactCollector with parameter 
    # get return value of collect of class SystemCapabilitiesFactCollector
    var_1 = system_capabilities_fact_collector_0.collect(var_0)
    # call collect of class SystemCapabilitiesFactCollector with parameter 
    # get return value of collect of class SystemCapabilitiesFactCollector
    var_2 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:07.438614
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = bool()
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # NOTE: calling collect(bool)
    #       with param: bool_0
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    # NOTE: accessing private attribute _fact_ids of class SystemCapabilitiesFactCollector
    #       using var: system_capabilities_fact_collector_0
    assert not any((system_capabilities_fact_collector_0._fact_ids))



# Generated at 2022-06-24 23:33:10.356934
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)



# Generated at 2022-06-24 23:33:14.900815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:17.638390
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # New instances of this class
    test_case_0()

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:33:21.618350
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    bool_1 = bool_0
    var_0 = system_capabilities_fact_collector_0.collect(bool_1)
    assert var_0 == {}


# Generated at 2022-06-24 23:33:30.331476
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    bool_0 = False
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect(bool_0)
    expected_0 = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

    bool_0 = True
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect(bool_0)
    expected_0 = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}


# Generated at 2022-06-24 23:33:42.987998
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = False
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:33:45.407058
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect(bool_0)



# Generated at 2022-06-24 23:33:50.711226
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:33:54.184670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)


# Generated at 2022-06-24 23:33:56.858463
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:34:03.189519
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  try:
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
  except Exception:
    import traceback
    exception = traceback.format_exc()
    print(exception)
    raise


# Generated at 2022-06-24 23:34:04.249738
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:34:06.757951
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:34:13.565407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(bool_0)
    print(var_1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:34:20.784754
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    assert var_0 == {u'system_capabilities_enforced': u'NA', u'system_capabilities': []}, "Return value of method collect of class SystemCapabilitiesFactCollector is incorrect"


# Generated at 2022-06-24 23:34:33.705536
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:34:36.382131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: assert variables for method calls -akl
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    bool_0 = True
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:34:41.364701
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    str_0 = system_capabilities_fact_collector_0.get_name(bool_0)
    str_1 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:34:44.442608
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)


# Generated at 2022-06-24 23:34:51.004653
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

    # Type match test
    if isinstance(var_0, dict):
        # Simplified tests
        assert var_0 == {}
    else:
        raise AssertionError("Test object type difference, should be {}, is actually {}"
                             .format(dict, type(var_0)))


# Generated at 2022-06-24 23:34:56.389091
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # We will be using a 'module_utils' fixture.  Note
    # that we do not need a 'ansible_module' fixture
    # since we are not actually running an ansible module.

    # Prep
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = None
    collected_facts_0 = None

    # Operation
    result = system_capabilities_fact_collector_0.collect(module_0, collected_facts_0)

    # Verification
    assert result is None

    # Cleanup
    # no need for cleanup since nothing was created

# Generated at 2022-06-24 23:34:58.191906
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:34:58.859066
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  assert True == True


# Generated at 2022-06-24 23:35:00.832318
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)



# Generated at 2022-06-24 23:35:02.680319
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)


# Generated at 2022-06-24 23:35:30.231954
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_1 = True
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(bool_1)


# Generated at 2022-06-24 23:35:30.706586
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass



# Generated at 2022-06-24 23:35:39.262157
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test with good module
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    assert 'system_capabilities' in var_0
    assert 'system_capabilities_enforced' in var_0

    # Test with bad module
    class dict_0_0:
        pass

    dict_0 = dict_0_0()

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect(dict_0)

# Generated at 2022-06-24 23:35:41.036751
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:35:43.272723
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = True
    var_1 = system_capabilities_fact_collector_0.collect(var_0)

# Generated at 2022-06-24 23:35:48.233759
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Unit test that can run in stand alone mode

# Generated at 2022-06-24 23:35:51.684842
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: validate the params
    # TODO: fix the code
    #assert_raises(TypeError, SystemCapabilitiesFactCollector.collect)

    # Testing only with the default param
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:54.727705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)



# Generated at 2022-06-24 23:35:58.562013
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:02.429131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)


# Generated at 2022-06-24 23:37:00.505195
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    bool_0 = True
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)


# Generated at 2022-06-24 23:37:06.615975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    if module.params['capsh_path']:
        sys.path.append(module.params['capsh_path'])

    assert module.params['capsh_path'] == True

# Generated at 2022-06-24 23:37:08.918683
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    assert 'system_capabilities' in var_0
    assert 'system_capabilities_enforced' in var_0


# Generated at 2022-06-24 23:37:15.006703
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = None
    collected_facts_0 = None
    var_0 = system_capabilities_fact_collector_0.collect(module_0, collected_facts_0)
    assert var_0 == {}


# Generated at 2022-06-24 23:37:16.082163
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert test_case_0() == 0


# Generated at 2022-06-24 23:37:26.409533
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    str_0 = "NA"
    str_1 = "Current:"
    list_0 = []
    str_2 = "Current:"
    str_3 = "="
    str_4 = "Current:"
    str_5 = "="
    str_6 = "Current:"
    str_7 = "="
    str_8 = "Current:"
    str_9 = "="
    str_10 = "Current:"
    str_11 = "="
    str_12 = "Current:"
    str_13 = "="
    str_14 = "Current:"
    str_15 = "="
    str_16 = "Current:"
    str_17 = "="
    str_18 = "Current:"
   

# Generated at 2022-06-24 23:37:30.151921
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    return var_0


# Generated at 2022-06-24 23:37:34.645036
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:37:36.121161
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:37:38.945832
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """

    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    print (system_capabilities_fact_collector_0.collect(bool_0))

print (test_SystemCapabilitiesFactCollector_collect())
print (test_case_0())

# Generated at 2022-06-24 23:39:50.663416
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print(SystemCapabilitiesFactCollector.collect)



# Generated at 2022-06-24 23:39:55.466390
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():


    # Default values for method
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    print(var_0)

    # Default values for method
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    print(var_0)


# Generated at 2022-06-24 23:39:57.190799
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:39:59.074663
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:40:00.876399
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    t_Function_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(t_Function_0)


# Generated at 2022-06-24 23:40:02.291881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test failing -akl
    return
    # assert not CapshFactCollector.collect()
    # assert CapshFactCollector.collect(None, None)

# Generated at 2022-06-24 23:40:03.911098
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect(bool_0)


# Generated at 2022-06-24 23:40:13.395325
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = SystemCapabilitiesFactCollector()
    bool_0 = True
    str_0 = "Current: =ep"
    str_1 = "Bounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip"
    str_2 = "Securebits: 00/0x0/1'b0"
    str_3 = "secure-noroot: no (unlocked)"
    str_4 = "secure-no-suid-fixup: no (unlocked)"
   

# Generated at 2022-06-24 23:40:15.902686
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)

# Generated at 2022-06-24 23:40:21.400151
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bool_0 = True
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(bool_0)