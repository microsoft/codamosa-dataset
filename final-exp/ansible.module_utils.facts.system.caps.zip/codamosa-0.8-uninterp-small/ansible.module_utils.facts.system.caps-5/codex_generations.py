

# Generated at 2022-06-24 23:31:53.840486
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:31:57.049390
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_collect_1 = SystemCapabilitiesFactCollector()
    module = 'module_0'
    collected_facts = 'collected_facts_0'
    system_capabilities_fact_collector_collect_1.collect(module=module, collected_facts=collected_facts)


# Generated at 2022-06-24 23:31:58.783699
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector.collect(None, None)

# Generated at 2022-06-24 23:32:03.828937
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    collected_facts_1 = {}
    system_capabilities_fact_collector_1.collect(collected_facts=collected_facts_1)
    print(collected_facts_1)

# Generated at 2022-06-24 23:32:08.262154
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_0.collect(module=None, collected_facts=None)
    assert result == {}


# Generated at 2022-06-24 23:32:10.916299
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_instance = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_instance.collect()

# Generated at 2022-06-24 23:32:13.546240
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}



# Generated at 2022-06-24 23:32:15.608753
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities_enforced': 'False', 'system_capabilities': ['=ep']}

# Generated at 2022-06-24 23:32:17.874132
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = {}
    facts_dict = fact_collector.collect()
    assert facts_dict is None

# Generated at 2022-06-24 23:32:20.639596
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:35.377616
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    except ImportError:
        raise
    else:
        system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
        assert isinstance(system_capabilities_fact_collector_1, SystemCapabilitiesFactCollector)
        assert isinstance(system_capabilities_fact_collector_1, BaseFactCollector)
        assert hasattr(system_capabilities_fact_collector_1, "collect")
        assert callable(system_capabilities_fact_collector_1.collect)



# Generated at 2022-06-24 23:32:37.309146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0.system_capabilities_fact_collector_0.collect()

test_case_0.test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:32:39.151793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    SystemCapabilitiesFactCollector.collect(system_capabilities_fact_collector)

# Generated at 2022-06-24 23:32:41.000824
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:32:46.910084
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    collected_facts_0 = {'ansible_distribution': 'Ubuntu',
                         'ansible_distribution_version': '18.04',
                         'ansible_distribution_major_version': '18',
                         'ansible_distribution_release': 'bionic',
                         'ansible_lsb': {'codename': 'bionic',
                                         'major_release': '18',
                                         'minor_release': '04',
                                         'description': 'Ubuntu 18.04.1 LTS',
                                         'id': 'Ubuntu',
                                         'release': '18.04'},
                         'ansible_os_family': 'Debian',
                         'ansible_architecture': 'x86_64'}



# Generated at 2022-06-24 23:32:53.351880
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a SystemCapabilitiesFactCollector object to test
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Test the 'collect' method
    try:
        assert not (system_capabilities_fact_collector_0.collect(collected_facts={}))
    except NotImplementedError:
        pass



# Generated at 2022-06-24 23:32:56.843783
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    print(system_capabilities_fact_collector_1.name)
    print(system_capabilities_fact_collector_1._fact_ids)
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:06.043852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    capsh_path = system_capabilities_fact_collector_1.get_bin_path(capsh)
    rc = 0
    out = b''
    err = b''
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    facts = system_capabilities_fact_collector_1.collect(module=(capsh_path, "--print"), errors='surrogate_then_replace')
    assert facts['system_capabilities_enforced'] == enforced
    assert facts['system_capabilities'] == enforced_caps
    # assert facts == facts

# Generated at 2022-06-24 23:33:08.502655
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:10.668795
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:19.760705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:22.658885
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {
        'system_capabilities_enforced': 'NA',
        'system_capabilities': []
    }


# Generated at 2022-06-24 23:33:26.514661
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Prepare the parameters
    # Do the test
    result = SystemCapabilitiesFactCollector().collect()

    # Check the results
    assert result is not None
    assert '' in result
    assert 'system_capabilities_enforced' in result
    assert 'system_capabilities' in result

# Generated at 2022-06-24 23:33:35.942715
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test method collect of class SystemCapabilitiesFactCollector
    """
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # set up the mock module
    import ansible.module_utils.facts.collector as ac
    #ac.CAPS_PATH = 'capsh'
    ac.HAVE_CAPS = True
    import ansible.module_utils.facts.system.capabilities as cs
    cs.HAVE_CAPS = True
    import ansible.module_utils.facts.system.capabilities as acs
    acs.CAPS_PATH = '/bin/capsh'
    import ansible.module_utils.facts as af
    class ModuleMock:
        def __init__(self):
            self.params = {}

# Generated at 2022-06-24 23:33:45.590909
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector is not None

    # Unit test for property name of class SystemCapabilitiesFactCollector
    assert system_capabilities_fact_collector.name == 'caps'

    # Unit test for property _fact_ids of class SystemCapabilitiesFactCollector
    assert system_capabilities_fact_collector._fact_ids.__contains__('system_capabilities')
    assert system_capabilities_fact_collector._fact_ids.__contains__('system_capabilities_enforced')

    assert system_capabilities_fact_collector.collect() == {}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 23:33:57.059612
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: the following line is in fact a setup for a builtin 'module_utils' mock
    #       called 'ansible_module_utils.facts.collector.BaseFactCollector'
    # 'ansible_module_utils.facts.collector.BaseFactCollector' has no member 'get_bin_path'
    # 'ansible_module_utils.facts.collector.BaseFactCollector' has no member 'run_command'
    ansible_module_utils = mock.Mock()
    ansible_module_utils.facts.collector.BaseFactCollector = mock.Mock() 
    type(ansible_module_utils.facts.collector.BaseFactCollector).get_bin_path = mock.PropertyMock(return_value='capsh')

# Generated at 2022-06-24 23:33:58.750986
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    returned_dict = system_capabilities_fact_collector_0.collect()
    return

# Generated at 2022-06-24 23:34:01.274356
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert {} == system_capabilities_fact_collector.collect(None, None)

# Generated at 2022-06-24 23:34:03.512961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("")
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:11.634080
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: this method only works if module is set to a non-None value
    # TEST: system_capabilities_fact_collector_0 is a instance of SystemCapabilitiesFactCollector
    # TEST: system_capabilities_fact_collector_0.collect() returns a dictionary
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:20.574529
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # NOTE: mocks for module and /proc/sys/kernel/cap_last_cap
    # needed for testing -akl
    system_capabilities_fact_collector_0.collect()

test_case_0()

# Generated at 2022-06-24 23:34:25.132880
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:34:29.694146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:31.802330
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:34:38.123906
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # (1) For test 0:
    #  - mock run_command (with return_value=None)
    #  - call collect
    #  - check that collected_facts is empty
    #  - check that stderr contains a warning about the invocation of capsh
    #  - check that the warning is present in collected_facts['warnings']
    # (2) For test 1:
    #  - mock run_command (with return_value=something meaningful)
    #  - call collect
    #  - check that collected_facts is not empty
    #  - check that stderr contains a warning about the invocation of capsh
    #  - check that the warning is present in collected_facts['warnings']
    return


# Generated at 2022-06-24 23:34:41.238997
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    expected = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    actual = system_capabilities_fact_collector_0.collect()
    assert actual == expected

# Generated at 2022-06-24 23:34:47.190684
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Module:
        def get_bin_path(self, path):
            return '/usr/bin/capsh'

        def run_command(self, command, errors='surrogate_then_replace'):
            if command == ['/usr/bin/capsh', '--print']:
                return 0, 'Current: =ep', ''
    module = Module()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect(module=module, collected_facts=None) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-24 23:34:55.487293
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    string_0 = 'True'
    string_1 = 'False'

# Generated at 2022-06-24 23:35:01.398587
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = None

    def run_command_mock(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, prompt=None, environ_update=None, umask=None, errors='surrogate_then_replace', encoding=None, errors_callback=None, expand_user_files=False, data_encoding=None, stdin=None):
        return ((0, '', ''), None)

# Generated at 2022-06-24 23:35:07.248018
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() != 0

# Generated at 2022-06-24 23:35:13.744227
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:35:18.029571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    result_collection_0 = system_capabilities_fact_collector_1.collect()
    assert (result_collection_0['system_capabilities_enforced'] == 'NA')
    assert (result_collection_0['system_capabilities'] == [])


# Generated at 2022-06-24 23:35:21.983025
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert var_1 == {'system_capabilities': [],
                     'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:35:24.948963
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = 'system_capabilities_enforced'
    var_2 = 'system_capabilities'
    var_3 = var_0.collect()
    assert var_3 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}, '\nExpected:\n  {\'system_capabilities_enforced\': \'NA\', \'system_capabilities\': []}\nGot:\n  {0}'.format(var_3)

# Generated at 2022-06-24 23:35:27.177796
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:29.723944
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:35:31.533308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:33.412725
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:34.986601
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:44.906089
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:36:07.143889
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = module.get_bin_path('capsh')
    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'
                enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

    facts_dict['system_capabilities_enforced'] = enforced
    facts_dict['system_capabilities'] = enforced_caps

# Generated at 2022-06-24 23:36:09.456448
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    (result_0, result_1) = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:36:17.261856
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = SystemCapabilitiesFactCollector()
    var_3 = SystemCapabilitiesFactCollector()
    var_4 = SystemCapabilitiesFactCollector()
    out = var_1.collect()
    out = var_2.collect()
    out = var_3.collect(module=None)
    out = var_4.collect()

# Generated at 2022-06-24 23:36:21.086388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    assert(var == [])


# Generated at 2022-06-24 23:36:24.076259
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA'
    }

# Generated at 2022-06-24 23:36:33.068665
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    # AssertionError: The key(s) ['system_capabilities'] are not present in "system_capabilities_enforced"
    # assert var_1['system_capabilities'] == ['chown', 'dac_override', 'fsetid', 'fowner', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap'], "Incorrect value of system_capabilities provided"


# Generated at 2022-06-24 23:36:35.565924
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test method collect of class SystemCapabilitiesFactCollector"""

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:37.306996
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:39.424602
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    print(var)

test_case_0()
test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:36:41.231374
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:13.087619
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:19.678836
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import FileFactCollector
    from ansible.module_utils.facts.collector import DictFileFactCollector
    from ansible.module_utils.facts.collector import FallbackDictFileFactCollector
    from ansible.module_utils.facts.collector import ShellCommandFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = BaseFactCollector()
    var_2 = Collector()
    var_3 = BaseFileFact

# Generated at 2022-06-24 23:37:29.467836
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    _system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    (_var_0, ) = list(map(lambda _k, _v: _v if isinstance(_k, str) else _k,
                          _system_capabilities_fact_collector_0.__dict__['collect'](),
                          test_case_0()))
    assert _var_0 == list()
    _system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    (_var_0, ) = list(map(lambda _k, _v: _v if isinstance(_k, str) else _k,
                          _system_capabilities_fact_collector_1.__dict__['collect'](),
                          test_case_0()))

# Generated at 2022-06-24 23:37:34.395601
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:37:38.390360
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize the object
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Invoke method collect
    test_case_0()

USAGE = """
Usage:

> ansible localhost -m setup -a 'filter=ansible_capabilities'

OR

> ansible localhost -m setup -a 'filter=ansible_capabilities_enforced'
"""
# Execute the code
if __name__ == '__main__':
    print(USAGE)
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:37:44.016631
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert not var_0

# NOTE: Create a test case for an individual method of SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:37:48.246897
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0._fact_ids
    assert var_0 == {}
    assert var_1 == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-24 23:37:52.428148
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    # mock module
    var_2 = ModuleStub()
    # mock string
    var_3 = StringStub()
    var_2.get_bin_path.return_value = var_3
    var_3.split.retun_value = ['Current:', '=ep']
    var_4 = system_capabilities_fact_collector_0.collect(var_2)

# Generated at 2022-06-24 23:37:58.121367
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Test cases for method collect of class SystemCapabilitiesFactCollector
    # Testing for no parameters
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {}
    # Testing for parameters module=None, collected_facts=None
    var_2 = system_capabilities_fact_collector_1.collect(None, None)
    assert var_2 == {}

# Generated at 2022-06-24 23:38:00.231060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # Teardown



# Generated at 2022-06-24 23:39:12.286881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert set(system_capabilities_fact_collector_0.collect()) == set({'system_capabilities': [], 'system_capabilities_enforced': 'NA'})

# Generated at 2022-06-24 23:39:14.734116
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:39:18.581349
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module_1 = object()
    collected_facts_1 = object()
    var_1 = system_capabilities_fact_collector_1.collect(module=module_1, collected_facts=collected_facts_1)


# Generated at 2022-06-24 23:39:21.770290
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: define test data
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # NOTE: define test conditions
    var_0 = system_capabilities_fact_collector_0.collect()
    # NOTE: assert test conditions


# Generated at 2022-06-24 23:39:27.244703
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0_caps = set(['system_capabilities', 'system_capabilities_enforced'])
    assert (system_capabilities_fact_collector_0_caps == SystemCapabilitiesFactCollector.collect(SystemCapabilitiesFactCollector()))

# Generated at 2022-06-24 23:39:29.257864
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == None

# Generated at 2022-06-24 23:39:30.701712
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:39:33.603746
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:39:35.381013
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:38.398291
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)