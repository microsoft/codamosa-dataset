

# Generated at 2022-06-24 23:31:55.213537
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_collect_0 = SystemCapabilitiesFactCollector()
    assert True == system_capabilities_collect_0.collect()

# Generated at 2022-06-24 23:31:56.894997
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:31:57.409423
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:32:03.980183
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    with patch('ansible.module_utils.facts.collector.BaseFactCollector.collect') as mocked_BaseFactCollector_collect:
        mocked_BaseFactCollector_collect.return_value = {"ansible_facts": {}, "changed": False, "ansible_facts_modified": False}
        with patch('ansible.module_utils.facts.collector.module_facts') as mocked_module_facts:
            mocked_module_facts.return_value = True
            with patch('ansible.module_utils.facts.collector.get_bin_path') as mocked_get_bin_path:
                mocked_get_bin_path.return_value = True

# Generated at 2022-06-24 23:32:10.070742
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module = None
    collected_facts = None
    assert system_capabilities_fact_collector_0.collect(module=module, collected_facts=collected_facts) == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:32:12.330803
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # TODO: implement test
    assert True

# Generated at 2022-06-24 23:32:16.165358
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    # Initializing the mock_module_execute_command parameters
    capsh_path = 'capsh'
    capsh_args = ['--print']
    capsh_rc = 0
    stdout_1 = "Current:\t=ep\nsecurebits:000000/000000\nsecure-noroot: no (unlocked)\nsecure-no-suid-fixup: no (unlocked)\nsecure-keep-caps: no (unlocked)\nuid=0(root)\ngid=0(root)\neuid=0(root)\n egid=0(root)\nCapInh:\t=\nCapPrm:\t=ep\nCapEff:\t=ep\nCapBnd:\t=ep\nCapAmb:\t=\n"



# Generated at 2022-06-24 23:32:16.712408
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:32:25.660281
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from unittest.mock import patch, Mock

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, a, b):
            return (0, 'a', 'b')

    try:
        from ansible.module_utils.facts.collector import CapshCollector
    except ImportError:
        m = Mock()
        m.return_value = {}
        CapshCollector = m

    class ArgvFilled(unittest.TestCase):
        def setUp(self):
            self.old_argv = sys.argv
            sys.argv = ['']

        def tearDown(self):
            sys.argv = self.old_argv


# Generated at 2022-06-24 23:32:28.036589
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:32:36.886062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: create/mock subclass of module_utils.basic.AnsibleModule and pass as module -akl
    tuple_0 = None
    tuple_1 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0, tuple_1)

# Generated at 2022-06-24 23:32:39.320220
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)


# Generated at 2022-06-24 23:32:42.563856
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

# Generated at 2022-06-24 23:32:44.788439
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)


# Generated at 2022-06-24 23:32:51.060666
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

if __name__ == "__main__":
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()
    print('Test done!')

# Generated at 2022-06-24 23:32:54.435672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)
    del(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:32:59.520855
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)


# Generated at 2022-06-24 23:33:09.755705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import StringIO
    import tempfile
    import unittest
    import ansible.module_utils.facts.collector.system

    class ModuleMock:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, app, opt_dirs=[]):
            return '/usr/bin/python'


# Generated at 2022-06-24 23:33:15.465005
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:33:19.935464
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(tuple_0)
#
# Unit test with mock module
#


# Generated at 2022-06-24 23:33:30.525094
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)



# Generated at 2022-06-24 23:33:31.787773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert 'system_capabilities_enforced' in var_0


# Generated at 2022-06-24 23:33:33.993862
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

# Generated at 2022-06-24 23:33:36.190576
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)


# Generated at 2022-06-24 23:33:39.912984
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

# Generated at 2022-06-24 23:33:41.456957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

# Generated at 2022-06-24 23:33:43.970408
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

# Generated at 2022-06-24 23:33:47.892383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
# 'from ansible.module_utils.facts.collector import BaseFactCollector'
# 'from ansible.module_utils.facts.collector import BaseFactCollector'
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

# Generated at 2022-06-24 23:33:51.399753
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)


# Generated at 2022-06-24 23:33:57.213560
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test case: Test when capsh is available, enforced caps
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

    # Test case: Test when capsh is available, capsh not enforcing
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(tuple_0)

    # Test case: Test when capsh is not available
    tuple_0 = None
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:34:12.480975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:34:15.529657
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # now test collect()
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:34:16.844583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-24 23:34:22.028881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    var = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)
    var_0 = system_capabilities_fact_collector.collect()
    var_1 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)

# Generated at 2022-06-24 23:34:26.309822
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-24 23:34:32.150639
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:34:34.484056
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    class_0 = system_capabilities_fact_collector_0.collect()
    assert class_0 == {}

# Generated at 2022-06-24 23:34:39.991838
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    except Exception as e:
        #print(e)
        assert False


# Generated at 2022-06-24 23:34:46.878804
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:34:52.109441
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = system_capabilities_fact_collector_0.module
    # NOTE: Unit test not yet implemented
    # var_0 = system_capabilities_fact_collector_0.collect(module_0, system_capabilities_fact_collector_0.collected_facts)


# Generated at 2022-06-24 23:35:15.759121
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:16.991110
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: add test for method collect of class SystemCapabilitiesFactCollector
    assert false


# Generated at 2022-06-24 23:35:20.159289
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:25.640304
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)
    var_0 = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:35:29.613330
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    # self.assertIn(var_0,)

# Generated at 2022-06-24 23:35:32.446045
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert not (system_capabilities_fact_collector_0.collect())


# Generated at 2022-06-24 23:35:34.867279
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:35:38.652652
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:35:41.415113
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    if isinstance(system_capabilities_fact_collector_0, SystemCapabilitiesFactCollector):
        system_capabilities_fact_collector_0.collect()
    else:
        raise RuntimeError("Method collect not implemented in the class SystemCapabilitiesFactCollector")

# Generated at 2022-06-24 23:35:48.720451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:36:37.075531
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:36:39.997187
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

test_case_0()

# Generated at 2022-06-24 23:36:42.255994
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module = DummyModule()
    var_1 = system_capabilities_fact_collector_0.collect(module)
    assert True


# Generated at 2022-06-24 23:36:45.581206
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:36:48.344709
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  system_capabilities_fact_collector_3 = SystemCapabilitiesFactCollector()
  var_3 = system_capabilities_fact_collector_3.collect()
  var_4 = system_capabilities_fact_collector_3.collect(system_capabilities_fact_collector_3)


# Generated at 2022-06-24 23:36:50.409999
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:36:58.491490
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = {}
    var_2['system_capabilities'] = []
    var_2['system_capabilities_enforced'] = 'NA'
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, var_2)
    assert var_3 == var_2


# Generated at 2022-06-24 23:37:00.326758
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:37:05.457457
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock module object
    class module_1283376706_23(object):
        def get_bin_path(self, arg0_1283376706_24):
            return "/usr/bin/capsh"

# Generated at 2022-06-24 23:37:08.086924
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:39:05.386849
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:39:09.370401
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_2 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_2 == {}

# Generated at 2022-06-24 23:39:15.393696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_obj0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_obj0.collect()
    if var_0 == None:
        print("None")
    else:
        print("Collect")


# Generated at 2022-06-24 23:39:20.273023
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: module_utils/facts/util.py: run_command() -akl
    # NOTE: caps are applied at process startup, so you need to sudo -akl
    # NOTE: 'capsh --print' will show your capabilities -akl
    # NOTE: head capsh to get subprocess.Popen() -akl
    # NOTE: head module to get AnsibleModule() -akl
    # NOTE: no need for a test case, we just want to enumerate the
    #       module import dependencies for now -akl
    pass

# Generated at 2022-06-24 23:39:29.445841
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("[TEST] Testing collect method of SystemCapabilitiesFactCollector class")

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()

    # Test for not None
    print("[TEST] Testing collect method for not None")
    assert var is not None

    # Test for keys in dict
    print("[TEST] Testing collect method to have certain keys in dict")
    assert 'system_capabilities_enforced' in var and 'system_capabilities' in var

    # Test for proper type of the value of key 'system_capabilities_enforced'
    print("[TEST] Testing collect method to have proper type of value of key 'system_capabilities_enforced'")

# Generated at 2022-06-24 23:39:35.605865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    var_2 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    try:
        var_3 = system_capabilities_fact_collector_0.collect(var_2)
    except Exception:
        var_3 = None
    var_0 = False
    if var_3 == None:
        var_0 = True
    assert var_0


# Generated at 2022-06-24 23:39:38.928722
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    arg0 = None
    var_0 = system_capabilities_fact_collector_0.collect(arg0)
    assert var_0 is None


# Generated at 2022-06-24 23:39:41.727146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)




# Generated at 2022-06-24 23:39:44.833083
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()  # do not raise exception
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)  # do not raise exception


# Generated at 2022-06-24 23:39:46.406470
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert (isinstance(system_capabilities_fact_collector_0.collect(), dict))