

# Generated at 2022-06-24 23:31:56.780596
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module1 = DummyModule()
    collected_facts1 = []
    result1 = system_capabilities_fact_collector_1.collect(module1, collected_facts1)
    assert result1 == {}

# Stub class for module class

# Generated at 2022-06-24 23:31:59.835130
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:32:01.553524
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:32:07.284517
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    module_0 = MagicMock()
    collected_facts_0 = MagicMock()

# Generated at 2022-06-24 23:32:17.338093
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = "/usr/bin/capsh"

# Generated at 2022-06-24 23:32:18.988080
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    c = SystemCapabilitiesFactCollector()
    c.collect()

# Generated at 2022-06-24 23:32:21.619373
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:25.773246
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_test_0_result_0 = {}
    caps_test_0_result_0['system_capabilities'] = []
    caps_test_0_result_0['system_capabilities_enforced'] = 'NA'
    caps_test_0 = SystemCapabilitiesFactCollector()
    # NOTE: need 'mock' here -akl
    assert caps_test_0.collect() == caps_test_0_result_0


# Generated at 2022-06-24 23:32:28.373159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:35.882826
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    ansible_module_0 = import_module('ansible.modules.system.setup')
    ansible_module_set_module_args('')
    ansible_module_0.main()
    ansible_module_set_module_args('gather_subset=caps')
    ansible_module_0.main()
    output = ansible_module_0.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    assert(output[0] == 0)

# Generated at 2022-06-24 23:32:42.646806
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Arrange
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Act
    result = system_capabilities_fact_collector.collect()

    # Assert
    assert isinstance(result, dict)
    assert result is not None
    assert result == {}


# Generated at 2022-06-24 23:32:45.599138
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts = system_capabilities_fact_collector_0.collect()
    assert collected_facts == {}


if __name__ == '__main__':
    test_case_0()
    # test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:32:52.007591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector._module.run_command = lambda args, **kwargs: [0, '', '']
    system_capabilities_fact_collector._module.get_bin_path = lambda args: 'capsh'
    assert system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:32:53.350926
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0_SystemCapabilitiesFactCollector_collect = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:33:02.121522
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:33:04.267117
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:33:12.884534
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = type('', (), {})
    module.get_bin_path = lambda self, arg: '/usr/bin/capsh'

# Generated at 2022-06-24 23:33:14.267985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:15.314779
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:33:20.744326
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = MockModule()
    collected_facts_0 = {}
    assert system_capabilities_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0) == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-24 23:33:30.680154
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    arg_0 = system_capabilities_fact_collector_0
    var_0 = system_capabilities_fact_collector_0.collect(arg_0)


if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:33:33.434033
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:33:38.213485
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Case 0:
    if True:
        var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
        print(var_0)
        print(type(var_0))
        assert var_0 is not None
        system_capabilities = []
        assert (var_0 == {'system_capabilities': system_capabilities, 'system_capabilities_enforced': 'NA'})
test_case_0()

# Generated at 2022-06-24 23:33:39.205407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:33:41.496494
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:33:43.051220
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:33:45.373288
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Setup test environment
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Run method
    result = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)

    # Check result
    assert result is not None

    # Cleanup test environment
    # N/A



# Generated at 2022-06-24 23:33:55.722197
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_path = 'ansible.module_utils.facts.collector'
    module_0 = getattr(__import__(module_path, fromlist=('ansible', 'module_utils', 'facts', 'collector'), level=0), 'ansible.module_utils.facts.collector', None)
    rc = None
    out = None
    err = None
    rc, out, err = module_0.run_command([None, "--print"], errors='surrogate_then_replace')
    assert rc == 0
    assert out != ''


# Generated at 2022-06-24 23:33:57.388616
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:34:01.542245
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:34:12.402441
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FakeModule
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = FakeModule()
    var_2 = system_capabilities_fact_collector_0.collect(var_1)



# Generated at 2022-06-24 23:34:23.292273
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:34:30.085476
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:34:35.277394
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1._fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])
    var_0 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:34:39.750856
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()

test_case_0()

# Generated at 2022-06-24 23:34:45.662619
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MockModule()
    mock_caps = MockCaps()

    mock_module.run_command = mock_caps.run_command
    mock_module.get_bin_path = mock_caps.get_bin_path

    caps = SystemCapabilitiesFactCollector()
    result = caps.collect()

    assert result["system_capabilities_enforced"] == "True"
    assert result["system_capabilities"] == ["net_bind_service", "sys_chroot"]


# Generated at 2022-06-24 23:34:50.045350
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)



# Generated at 2022-06-24 23:34:53.320998
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Assert that function collect returns a dict for all mock inputs
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:34:58.033281
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector(name='caps')
    var_1 = var_0.collect()
    assert var_0.name == 'caps'

# Generated at 2022-06-24 23:35:04.744940
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:35:20.338360
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:35:25.679240
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

test_case_0()

# Generated at 2022-06-24 23:35:30.434672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock('SystemCapabilitiesFactCollector')
    collected_facts = dict()
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(module=module, collected_facts=collected_facts)
    assert 'system_capabilities_enforced' in var_1
    assert 'system_capabilities' in var_1


# Generated at 2022-06-24 23:35:31.460834
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # We just collect facts. Nothing to do/test.
    pass

# Generated at 2022-06-24 23:35:35.514159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == system_capabilities_fact_collector_1()
    assert isinstance(var_1,dict)
    assert 'system_capabilities' in var_1
    assert 'system_capabilities_enforced' in var_1


# Generated at 2022-06-24 23:35:40.688201
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:35:47.211508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module_0 = MagicMock()
    mock_module_0.run_command.return_value = (0, 'Current: = cap_sys_admin,cap_sys_chroot,cap_dac_override,cap_dac_read_search+eip', '')

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(mock_module_0)
    assert var_0 == {
        'system_capabilities_enforced': 'True',
        'system_capabilities': ['cap_sys_admin', 'cap_sys_chroot', 'cap_dac_override', 'cap_dac_read_search']
    }


# Generated at 2022-06-24 23:35:49.533696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0) == {}


# Generated at 2022-06-24 23:35:52.539587
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)
    assert var == {}


# Generated at 2022-06-24 23:35:57.983209
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:36:31.860939
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = None
    capsh_path = BaseFactCollector.get_bin_path(BaseFactCollector, 'capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = BaseFactCollector.run_command(BaseFactCollector, [capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-24 23:36:34.705583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:36:41.395193
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Mock module
    class MockModule(object):

        def __init__(self, module_name):
            self.module_name = module_name

        def to_json(self):
            return self.module_name

        def get_bin_path(self, arg_0):
            return '/usr/bin/capsh'


# Generated at 2022-06-24 23:36:45.022719
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Case 0
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    # Type check
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:36:45.703130
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:36:51.711037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from mock import patch

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Mock/patch module parameters
    mock_module = patch.object(system_capabilities_fact_collector, 'module')
    mock_get_bin_path = patch.object(system_capabilities_fact_collector, 'get_bin_path')
    mock_run_command = patch.object(system_capabilities_fact_collector, 'run_command')

    # Mock/patch module parameter values
    mock_module.return_value.get_bin_path.return_value = '/path/to/capsh'
    mock_run_command.return_value = (0, "Current: =ep\n", "")

    # Unit test

# Generated at 2022-06-24 23:36:57.820629
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:36:59.009413
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:37:03.322247
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

    # First test case
    if(var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}):
        print("Test case 0 passed")
    else:
        print("Test case 0 failed: " + var_0)


# Generated at 2022-06-24 23:37:09.639322
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Mock ansible module

    module_mock = MagicMock()
    module_mock.run_command.return_value = (1, 'stdout', 'stderr')
    module_mock.get_bin_path.return_value = 'path to capsh binary'

    # Call the method

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    method_to_test = system_capabilities_fact_collector.collect

    # Assertions

    assert_equal(module_mock.get_bin_path.call_count, 1)
    assert_equal(module_mock.run_command.call_count, 1)

    system_capabilities_fact_collector.collect(module_mock)

# Generated at 2022-06-24 23:38:10.823056
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

    assert isinstance(var_0['system_capabilities_enforced'], str)
    assert isinstance(var_0['system_capabilities'], list)

# Generated at 2022-06-24 23:38:19.040397
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:38:22.731770
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = None
    var_1 = system_capabilities_fact_collector_0.collect(var_0)
    assert len(var_1) == 0

test_case_0()
test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:38:27.504130
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: capsh just wraps './capsh' and exits with a non-zero exit code -akl
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert system_capabilities_fact_collector_0._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-24 23:38:34.022456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Unit test will fail if any of these assertions fail
    assert not system_capabilities_fact_collector_0.collect()['system_capabilities']
    assert not system_capabilities_fact_collector_0.collect()['system_capabilities_enforced']
    assert sorted(system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)['system_capabilities']) == sorted(list())
    assert sorted(system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)['system_capabilities_enforced']) == sorted(list())

# Generated at 2022-06-24 23:38:37.613869
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_2.collect(system_capabilities_fact_collector_2)
    system_capabilities_fact_collector_3 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_3.collect(system_capabilities_fact_collector_3)


# Generated at 2022-06-24 23:38:39.659003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # test fixture
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # test output
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:38:42.186451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-24 23:38:47.229082
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:47.610632
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:41:05.982658
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: currently skipped -akl
    pass

# Generated at 2022-06-24 23:41:07.292879
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:41:12.506035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:41:14.279442
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)


# Generated at 2022-06-24 23:41:19.130521
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert isinstance(var_0, dict)
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}


# Generated at 2022-06-24 23:41:19.782185
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False
    test_case_0()

# Generated at 2022-06-24 23:41:20.631084
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: implement
    pass


# Generated at 2022-06-24 23:41:24.776884
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)
    assert var['system_capabilities_enforced'] == 'NA'
    assert var['system_capabilities'] == []

# Generated at 2022-06-24 23:41:26.618301
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("in test_SystemCapabilitiesFactCollector_collect")
    ret_val = SystemCapabilitiesFactCollector.collect(SystemCapabilitiesFactCollector)
    assert ret_val == {}


# Generated at 2022-06-24 23:41:33.636946
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Capsh is not available on Windows so the test should exit
    if 'win32' in sys.platform:
        return

    # capsh should not be present on most systems but this is a proof of concept.
    sys.modules['ansible.module_utils.facts.o'] = o
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

    # See if the keys were set as expected
    assert var_1['system_capabilities_enforced'] == 'NA'
    assert var_1['system_capabilities'] == []