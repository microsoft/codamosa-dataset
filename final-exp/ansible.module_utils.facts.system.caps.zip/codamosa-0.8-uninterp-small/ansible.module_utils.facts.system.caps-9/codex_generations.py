

# Generated at 2022-06-24 23:31:55.096729
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

# Test system_capabilities_enforced == NA

# Generated at 2022-06-24 23:32:00.435721
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts = {}
    expected_facts = {'system_capabilities':[], 'system_capabilities_enforced':'NA'}
    assert (system_capabilities_fact_collector_0.collect(collected_facts=collected_facts) == expected_facts)



# Generated at 2022-06-24 23:32:07.947935
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    system_capabilities_fact_collector_obj = SystemCapabilitiesFactCollector()
    # Test case 0:
    # Testing for method collect of class SystemCapabilitiesFactCollector
    # without any parameters
    return_value = system_capabilities_fact_collector_obj.collect()
    assert return_value == {}
    # Test case 1:
    # Testing for method collect of class SystemCapabilitiesFactCollector
    # with parameters module='ansible.module_utils.facts.collector.BaseFactCollector'
    # and collected_facts='ansible.module_utils.facts.collector.FactCollector'
    return_value = system_capabilities_fact_collector_

# Generated at 2022-06-24 23:32:09.535261
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass # method doesn't really 'do' anything

# Generated at 2022-06-24 23:32:11.105590
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:32:11.961286
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:32:13.503365
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector_collect_obj = SystemCapabilitiesFactCollector()
    assert True


# Generated at 2022-06-24 23:32:22.830370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Test with mock for module
    test_module = 'ansible.module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector.module'
    import ansible.module_utils.facts.system.capabilities
    mocked_module = type('MockedModule', (object,), {'get_bin_path': ansible.module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector.get_bin_path, 'run_command': ansible.module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector.run_command})
    import types

# Generated at 2022-06-24 23:32:28.557262
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    class ModuleMock(object):
        def __init__(self):
            return

        def get_bin_path(self, arg_0):
            return '/bin/capsh'

        def run_command(self, arg_0, errors):
            return 0, 'Current: =ep Bounding set =cap_kill,cap_setuid\nSecurebits: 00/0x0/1\n secure-noroot: no (unlocked)\n secure-no-setuid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)\n', 'NA'


# Generated at 2022-06-24 23:32:37.653762
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    keys = ['system_capabilities_enforced', 'system_capabilities']
    content = ['True', ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']]
    ansible_module_0 = get_ansible_module_mock(keys, content)
    result = system_capabilities_fact_collector_0.collect(ansible_module_0)
    assert (result['system_capabilities'] == content[1])

# Generated at 2022-06-24 23:32:44.945520
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert True

# Generated at 2022-06-24 23:32:46.807756
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:49.044173
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    if system_capabilities_fact_collector_0.collect() != {}:
        _msg = 'assertion error'
        raise AssertionError(_msg)

if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:32:54.158930
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()
    var_1 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)
    var_2 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)


# Generated at 2022-06-24 23:33:02.433512
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = SystemCapabilitiesFactCollector()
    with patch.object(var_2, 'run_command', return_value=(0, '', '')):
        with patch.object(var_2, 'get_bin_path', return_value=''):
            with patch.object(BaseFactCollector, 'collect'):
                assert var_1.collect() == {}


# Generated at 2022-06-24 23:33:06.223827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_1 = MockModule()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(module=module_1)
    # TODO: assert something here


# Generated at 2022-06-24 23:33:08.670237
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:15.730727
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    # Test for valid 'isinstance' list
    var_1 = [i for i in var_0.keys()]
    var_1 = [i for i in var_1 if not isinstance(i, BaseFactCollector)]
    assert not var_1

    # Test for valid 'isinstance' list
    var_2 = [i for i in var_0.values()]
    var_2 = [i for i in var_2 if not isinstance(i, BaseFactCollector)]
    assert not var_2

    # Test for valid 'isinstance' list
    var_3

# Generated at 2022-06-24 23:33:16.231571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:33:19.803926
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:35.379995
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = system_capabilities_fact_collector_0.get_bin_path('capsh')
    rc, out, err = system_capabilities_fact_collector_0.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'
                enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]
    
    var_1 = system_capabilities_fact_

# Generated at 2022-06-24 23:33:41.400953
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect()
    assert var_2 == {}
    assert system_capabilities_fact_collector_2.name == 'caps'


# Generated at 2022-06-24 23:33:42.008497
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True == True


# Generated at 2022-06-24 23:33:44.173777
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect(SystemCapabilitiesFactCollector())
    assert True


# Generated at 2022-06-24 23:33:51.935835
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_3 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_4 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_5 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_6 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_7 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_8 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector

# Generated at 2022-06-24 23:33:53.769297
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect(SystemCapabilitiesFactCollector())


# Generated at 2022-06-24 23:34:00.211322
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = {}
    var_2['shell'] = '/bin/sh'
    var_3 = {}
    var_3['system'] = 'Linux'
    var_3['python'] = '2.7.17'
    var_3['python_version'] = '2.7'
    var_2['ansible_facts'] = var_3
    var_2['msg'] = 'All items completed'
    var_2['failed'] = False
    var_2['invocation'] = {'module_name': 'setup'}
    var_3 = {}
    var_3[''] = 'AMQ1'

# Generated at 2022-06-24 23:34:05.098611
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    assert var_2 == {}
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_3 == {}

# Generated at 2022-06-24 23:34:10.021641
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:34:17.794351
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts = {}
    collected_facts['local'] = {}
    var_0 = system_capabilities_fact_collector_0.collect(module, collected_facts)
    assert var_0['system_capabilities_enforced'] == 'NA'
    assert var_0['system_capabilities'] == []


# Generated at 2022-06-24 23:34:34.887110
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = SystemCapabilitiesFactCollector()
    var_3 = system_capabilities_fact_collector_0.collect(var_2)
    assert isinstance(var_3, dict)



# Generated at 2022-06-24 23:34:45.949406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # default behavior
    # TODO: store a copy of the original values and restore them after test
    module_0 = stub()
    system_capabilities_fact_collector_0.caps_module = module_0
    capsh_path_0 = module_0.get_bin_path('capsh')
    if capsh_path_0:
        rc_0, out_0, err_0 = module_0.run_command([capsh_path_0, "--print"], errors='surrogate_then_replace')
        enforced_caps_0 = []
        enforced_0 = 'NA'
        for line_0 in out_0.splitlines():
            if len(line_0) < 1:
                continue

# Generated at 2022-06-24 23:34:51.341683
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_fact_collector = SystemCapabilitiesFactCollector()

    # collect test without parameter 'caps_fact_collector'
    caps_fact_collector.collect()

    # collect test with parameter 'caps_fact_collector'
    caps_fact_collector.collect(caps_fact_collector)



# Generated at 2022-06-24 23:34:53.362186
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector_2.collect()


# Generated at 2022-06-24 23:35:03.111355
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self, fail=False):
            self._fail = fail

        def run_command(self, command, errors='surrogate_then_replace'):
            if self._fail:
                raise Exception('SNAFU')

            if command == ['capsh', '--print']:
                out = "Current: =eip\nsome other stuff."
                return 0, out, ''
            elif command == ['command', '--version']:
                out = 'version'
                return 0, out, ''
            else:
                raise Exception('Unexpected command')

        def get_bin_path(self, executable):
            if executable == 'capsh':
                return '/sbin/capsh'

# Generated at 2022-06-24 23:35:10.216492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_fixture_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_fixture_1 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_fixture_0.collect()
    var_1 = system_capabilities_fact_collector_fixture_1.collect(system_capabilities_fact_collector_fixture_0)


# Generated at 2022-06-24 23:35:21.316283
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:35:25.446358
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert bool(system_capabilities_fact_collector_0.collect() == {}) == bool(True)

# Generated at 2022-06-24 23:35:27.981827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert var_1 == {}


# Generated at 2022-06-24 23:35:34.796888
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Test method collect of class SystemCapabilitiesFactCollector')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == {}, var_0
    var_0 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_2)
    assert var_0 == {}, var_0


# Generated at 2022-06-24 23:36:04.097736
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_3 = system_capabilities_fact_collector_1.collect()
    # Case 1: no module
    var_4 = system_capabilities_fact_collector_1.collect(var_3)
    # Case 2: no capsh_path
    var_5 = system_capabilities_fact_collector_1.collect(var_4)

# Generated at 2022-06-24 23:36:07.816793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # From /usr/include/stdlib.h:
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:12.785894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    # TODO: create some test cases using the following primary key attributes
    # name = None
    system_capabilities_fact_collector_2.name = None
    # _fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])
    system_capabilities_fact_collector_2._fact_ids = set(['system_capabilities', 'system_capabilities_enforced'])

    system_capabilities_fact_collector_2.collect()

# Generated at 2022-06-24 23:36:20.422174
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile

    # NOTE: for tests that need a module fixture, patch below (as needed) -akl
    l_name = 'my_test_fact_name'
    l_value = 'my_test_fact_value'
    l_fact = {}
    l_fact[l_name] = l_value

    l_caps_file_name = 'my_caps_file_name'
    l_caps_file_path = os.path.join(tempfile.gettempdir(), l_caps_file_name)
    # create test data file
    with open(l_caps_file_path, 'w') as l_caps_file:
        l_caps_file.write('Current:\t=ep')

    l_mock_ansible_module = Mock(name='AnsibleModule')


# Generated at 2022-06-24 23:36:26.099127
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    print(var_0)
    assert var_0 == {'system_capabilities': [],
                     'system_capabilities_enforced': 'NA'}
    
    
# NOTE: deepcopy(var_0) as kwargs to mock_run_command() -akl 

# Generated at 2022-06-24 23:36:30.213667
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:31.990820
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_2.collect()

# Generated at 2022-06-24 23:36:34.395265
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Tests on valid input
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:36.309529
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == True

# Generated at 2022-06-24 23:36:39.695508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    print(str(var_2))
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    print(str(var_3))


# Generated at 2022-06-24 23:37:38.429923
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()
    var_3 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

# Generated at 2022-06-24 23:37:44.464825
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:37:53.698057
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_3 = {}
    var_3['capsh_path'] = None
    var_3['enforced_caps'] = []
    var_3['enforced'] = 'NA'
    var_3['enforced_caps'] = [i.strip() for i in line.split('=')[1].split(',')]
    var_3['enforced'] == 'False'
    var_3['enforced'] = 'True'
    var_3['facts_dict'] = {}
    var_3['facts_dict']['system_capabilities'] == enforced_caps
    var_3['facts_dict']['system_capabilities_enforced'] == enforced
    var_3['facts_dict'] == None

# Generated at 2022-06-24 23:38:00.590394
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Define object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Invoke the method
    result = system_capabilities_fact_collector.collect()

    # Expected output is not none and the result is equal to the expected output
    assert result is not None
    assert result == {}


# Generated at 2022-06-24 23:38:09.949169
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    assert var_0 == {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_sys_admin', 'cap_sys_boot', 'cap_sys_chroot', 'cap_sys_module', 'cap_sys_rawio', 'cap_sys_ptrace', 'cap_sys_pacct', 'cap_sys_admin', 'cap_sys_boot', 'cap_sys_chroot', 'cap_sys_module', 'cap_sys_rawio', 'cap_sys_ptrace', 'cap_sys_pacct']}


# Generated at 2022-06-24 23:38:13.821375
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # NOTE: patch object(s) here and test -akl
    system_capabilities_fact_collector_0._module = None

    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:38:16.864547
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('\n# Begin of method collect in class SystemCapabilitiesFactCollector')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    print('\n# End of method collect in class SystemCapabilitiesFactCollector')


# Generated at 2022-06-24 23:38:21.535798
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:38:25.997105
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()
    assert var_2 == {}
    var_3 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    assert var_3 == {}


# Generated at 2022-06-24 23:38:32.524418
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Add mocks for the module, the return value and the side effects
    var_1 = 'mock_var_1'
    var_3 = 'mock_var_3'
    var_4 = 'mock_var_4'
    mock_module = MagicMock(get_bin_path=MagicMock(return_value=var_1))
    mock_run_command = MagicMock(return_value=[var_3, var_4, ''])
    mock_module.run_command = mock_run_command

    # Create an instance of the object
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Run the collect method
    system_capabilities_fact_collector_0.collect(module=mock_module)

    # Check if run_command was called
   

# Generated at 2022-06-24 23:40:52.050043
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:40:55.160150
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() is None

# Generated at 2022-06-24 23:41:00.385376
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)
    assert isinstance(system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0), dict)


# Generated at 2022-06-24 23:41:05.698685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()
    var_1 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)

# Generated at 2022-06-24 23:41:06.346212
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:41:16.268857
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2= system_capabilities_fact_collector_0.collect()
    assert var_2 == {}, "Incorrect return value from collect"

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_3= system_capabilities_fact_collector_0.collect()
    assert var_3 == {}, "Incorrect return value from collect()"

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_4= system_capabilities_fact_collector_0.collect()
    assert var_4 == {}, "Incorrect return value from collect()"

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var

# Generated at 2022-06-24 23:41:17.147244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:41:18.213282
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:41:24.147823
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # TODO: mock get_bin_path and run_command, test that 'system_capabilities' and
    # TODO: 'system_capabilities_enforced' are in returned dict
    # TODO: test each case when run_command returns
    # TODO: rc, out, err = mock.run_command()  # return_value = (0, '', '')
    # TODO: rc, out, err = mock.run_command()  # return_value = (-2, '', '')
    # TODO: rc, out, err = mock.run_command()  # return_value = (127, '', '')
    # TODO: rc, out, err = mock.run_command()  # return_value = (0,

# Generated at 2022-06-24 23:41:28.758119
# Unit test for method collect of class SystemCapabilitiesFactCollector