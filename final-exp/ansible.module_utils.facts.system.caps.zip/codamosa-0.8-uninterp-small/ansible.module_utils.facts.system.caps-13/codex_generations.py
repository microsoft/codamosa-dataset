

# Generated at 2022-06-24 23:31:55.821239
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    dict_out = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:06.280087
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    def mock_get_bin_path(module, path):
        return path


# Generated at 2022-06-24 23:32:08.123111
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_obj_0 = SystemCapabilitiesFactCollector()
    collected_facts_dict = {}
    system_capabilities_fact_collector_obj_0.collect(None, collected_facts_dict)


# Generated at 2022-06-24 23:32:10.108688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test with default arguments
    # TODO: Add test
    return

# Generated at 2022-06-24 23:32:12.764845
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:22.138000
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Check that facts returned by method collect of class
    SystemCapabilitiesFactCollector are consistent with expected ones
    """
    test_module = ansible_module_mock
    test_module.get_bin_path.return_value = 'capsh'
    test_module.run_command.return_value = (0, "Current: =ep", "")

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = system_capabilities_fact_collector.collect(test_module)
    assert collected_facts == {'system_capabilities': [],
                               'system_capabilities_enforced': 'False'}
    test_module.get_bin_path.assert_called_once_with('capsh')
    test_module.run_command.assert_called_once_

# Generated at 2022-06-24 23:32:24.139808
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:25.630253
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:35.999961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # TODO: make a mock module object
    # --> add .run_command() method that returns a
    #     tuple of (0, 0, 0)
    # --> add .get_bin_path() method that returns
    #     a string (ABSOLUTE PATH TO CAPSH BINARY)
    #     or None
    # --> add .get_files() method that returns
    #     a dict of files with absolute paths as keys
    # --> add .run_command() method that returns
    #     a tuple of (0, 0, 0)
    # TODO: make a mock collected_facts dict
    # TODO: make a mock module object
    # TODO: call method collect of system_capabilities_fact_collector_0


# Generated at 2022-06-24 23:32:39.860697
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        dict_1 = dict({})
        dict_0 = system_capabilities_fact_collector_0.collect(dict_1)
        return dict_0
    except Exception as exception_0:
        print(str(exception_0))

# Generated at 2022-06-24 23:32:44.505319
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup and exercise the test case
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:47.537033
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock the module
    module = type('module', (), {
        'get_bin_path': lambda self, exec_name: 'bin/python',
        'run_command': lambda self, cmd, errors='surrogate_then_replace': ('', '', ''),
    })

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(module)

    assert 'capabilities' in var_0


# Generated at 2022-06-24 23:32:49.723153
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:32:56.318019
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)
    assert var_1 == {}



# Generated at 2022-06-24 23:32:59.173185
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert {} == system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:33:04.664551
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:33:07.925253
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect(system_capabilities_fact_collector, system_capabilities_fact_collector)


# Generated at 2022-06-24 23:33:09.278895
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Please write unit test for method collect in class SystemCapabilitiesFactCollector
    pass

# Generated at 2022-06-24 23:33:15.464841
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Test for 0 case
    test_case_0()


if __name__ == '__main__':
    # import ansible tests
    pass

# Generated at 2022-06-24 23:33:20.896181
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:33:31.148026
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:33.368006
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    module_mock = MockitoTestCase()
    var_2 = system_capabilities_fact_collector.collect(module_mock)
    assert_equals(var_2, {})

# Generated at 2022-06-24 23:33:39.429405
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Setup
    # Import modules needed for this unit test -akl
    import tempfile
    import mock

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector() # NOTE: calling method w/o optional args -akl

    # NOTE: mocks -akl
    mock_module_0 = mock.Mock()
    mock_module_0.run_command.return_value = (0,
                                              '''Current: =ep
                                                 CapInh: =
                                                 CapPrm: =
                                                 CapEff: =
                                                 CapBnd: =
                                                 CapAmb: =''', '')

    mock_module_1 = mock.Mock()

# Generated at 2022-06-24 23:33:40.764728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = SystemCapabilitiesFactCollector()
    var_0.collect(var_1, var_1)



# Generated at 2022-06-24 23:33:43.312780
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:33:44.871079
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()
    assert var_2 == {}

# Generated at 2022-06-24 23:33:48.072267
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("START test_SystemCapabilitiesFactCollector_collect")
    caps_fact_collector = SystemCapabilitiesFactCollector()
    assert caps_fact_collector.collect() is not None
    print("END test_SystemCapabilitiesFactCollector_collect")

# Generated at 2022-06-24 23:33:52.022350
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = SystemCapabilitiesFactCollector.get_caps_data()
    var_3 = SystemCapabilitiesFactCollector.parse_caps_data()
    var_4 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:52.727152
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert 1 == 1


# Generated at 2022-06-24 23:33:56.427712
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_instance = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_instance.system_capabilities = None
    system_capabilities_fact_collector_instance.system_capabilities_enforced = None
    system_capabilities_fact_collector_instance.collect()
    system_capabilities_fact_collector_instance.collect(system_capabilities_fact_collector_instance, system_capabilities_fact_collector_instance)


# Generated at 2022-06-24 23:34:14.644235
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = NotImplementedError()
    try:
        var_2 = system_capabilities_fact_collector_0.collect(var_0)
        assert False
    except Exception:
        assert True
    # Unit test for method collect of class BaseFactCollector
    try:
        var_2 = system_capabilities_fact_collector_0.collect(var_0)
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-24 23:34:17.883302
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:21.017541
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
  var_0 = system_capabilities_fact_collector_0.collect()
  assert var_0 == {}

# Generated at 2022-06-24 23:34:26.756557
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)



# Generated at 2022-06-24 23:34:31.139339
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    assert isinstance(var, dict)


# Generated at 2022-06-24 23:34:33.610192
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    result = SystemCapabilitiesFactCollector().collect()
    assert(result.get('system_capabilities_enforced')) is not None
    assert(result.get('system_capabilities')) is not None

# Generated at 2022-06-24 23:34:38.524478
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)
    var_2 = system_capabilities_fact_collector_0.collect(collected_facts=(var_0 if var_0 else None), module=(system_capabilities_fact_collector_0 if system_capabilities_fact_collector_0 else None))



# Generated at 2022-06-24 23:34:43.980314
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()
    system_capabilities_fact_collector_1.collect(None, system_capabilities_fact_collector_1)
    system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1, system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:34:47.511934
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        system_capabilities_fact_collector_0.collect()
    except:
        print("Exception in <function collect>")
        print("-" * 60)
        traceback.print_exc(file=sys.stdout)
        print("-" * 60)


if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:34:50.391994
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
# No operation


# Generated at 2022-06-24 23:35:20.681732
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # given
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect = collect_mock
    module_mock = mock_module()
    collected_facts_mock = mock_collected_facts()

    # when
    result = system_capabilities_fact_collector.collect(module_mock, collected_facts_mock)

    # then
    assert result == 'test_fn_call_result'

# unit test for method get_facts

# Generated at 2022-06-24 23:35:29.165754
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)
    var_0 = system_capabilities_fact_collector_0.collect()
    system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:35:33.823395
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Add tests, where appropriate
    # Test 1: no module specified
    # Test 2: no module specified and collected_facts != None
    # Test 3: module specified, but capsh_path != None
    # Test 4: module specified and collected_facts != None, but capsh_path != None
    # Test 5: module specified and capsh_path != None, but capsh_path == None
    pass



# Generated at 2022-06-24 23:35:38.352887
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_0.collect()
    var_1 = SystemCapabilitiesFactCollector()
    var_1.collect(var_0, var_0)


# Generated at 2022-06-24 23:35:38.707494
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('test')

# Generated at 2022-06-24 23:35:45.218332
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    # var_2 == {}
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)
    # var_3 == {}

# Generated at 2022-06-24 23:35:54.397435
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, "")
    var_4 = system_capabilities_fact_collector_0.collect("")
    var_5 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    var_6 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:36:00.975134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Define mock values for method collect of class SystemCapabilitiesFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3, BytesIO
    from ansible.module_utils.pycompat24 import get_exception
    import os
    import sys
    import json
    import pytest
    import tempfile

    class AnsibleModuleMock:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            pass

    ansible_module_mock = AnsibleModuleMock()
    system_capabilities_fact

# Generated at 2022-06-24 23:36:06.805161
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:36:15.611103
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Note: method called without module argument
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(None)
    assert var_0 == {}
    # Note: method called with module argument
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

# Generated at 2022-06-24 23:37:22.275974
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:27.252837
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert(var_0 == {})
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)
    assert(var_1 == {})

# Generated at 2022-06-24 23:37:30.408641
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert True

# Generated at 2022-06-24 23:37:31.319124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Collect facts related to systems 'capabilities' via capsh
    pass


# Generated at 2022-06-24 23:37:33.066611
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    assert var == {}

# Generated at 2022-06-24 23:37:35.197248
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect()
    assert var_2 == {}

# Generated at 2022-06-24 23:37:38.412310
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    var_2 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:37:47.534123
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == dict(system_capabilities=['chown', 'dac_override', 'dac_read_search', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap', 'mac_override', 'mac_admin'], system_capabilities_enforced='True')

# Generated at 2022-06-24 23:37:48.677725
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect()


# Generated at 2022-06-24 23:37:52.138858
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:40:16.425191
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:40:22.560779
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)



# Generated at 2022-06-24 23:40:25.642735
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
  var_2 = system_capabilities_fact_collector_2.collect()
  var_3 = system_capabilities_fact_collector_2.collect(system_capabilities_fact_collector_2, system_capabilities_fact_collector_2)


# Generated at 2022-06-24 23:40:30.197684
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    returned_0 = system_capabilities_fact_collector.collect()
    assert returned_0 == {}



# Generated at 2022-06-24 23:40:31.618197
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:38.038667
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:40:38.556177
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:40:42.677966
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:40:47.622124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:40:53.038576
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test case with file arguments and normal return value
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect()
    # Test case with file arguments and normal return value
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect(system_capabilities_fact_collector, system_capabilities_fact_collector)
