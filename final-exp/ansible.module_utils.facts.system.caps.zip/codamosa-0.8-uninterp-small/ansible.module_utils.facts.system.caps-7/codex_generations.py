

# Generated at 2022-06-24 23:31:59.250111
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tmp_module = type('', (), {})
    tmp_module.run_command = type('', (), {'return_value': (0, "Current: =ep", None)})
    tmp_module.get_bin_path = type('', (), {'return_value': '/usr/bin/capsh'})

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect(tmp_module)

    assert result['system_capabilities'] == []
    assert result['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-24 23:32:07.490323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    expected_facts_dict_0 = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    module_0 = None
    collected_facts_0 = {'ansible_facts': {}}
    test_module_name_0 = 'ansible.module_utils.facts.system.caps.module'
    mock_module_0 = MagicMock(name=test_module_name_0)
    mock_module_0.get_bin_path = MagicMock(return_value = '/usr/bin/capsh')
    mock_module_0.run_command = MagicMock(return_value=(0, 'Current: =ep', '', ''))
    mock_module_0.run_command.return_

# Generated at 2022-06-24 23:32:09.710468
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:13.708961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_collect_0 = SystemCapabilitiesFactCollector()
    module = None
    collected_facts = {}
    ret = system_capabilities_fact_collector_collect_0.collect(module, collected_facts)
    assert type(ret) == dict


# Generated at 2022-06-24 23:32:18.183761
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # NOTE: mock module, runshell() and seek_file() -akl
    # Create an instance of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # call function collect of class SystemCapabilitiesFactCollector with
    # argument module
    # There are currently no return values for this method
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:25.171951
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    param_0 = None
    param_1 = None
    try:
        ret_val_0 = system_capabilities_fact_collector_0.collect(param_0, param_1)
        print('ret_val_0: {}'.format(ret_val_0))
        system_capabilities_fact_collector_0.collect(param_0, param_1)
    except Exception as e:
        print('Exception: {}'.format(e))
    else:
        raise Exception('Expected Exception not thrown')



# Generated at 2022-06-24 23:32:30.334735
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    if not hasattr(system_capabilities_fact_collector_1, 'collect') and callable(system_capabilities_fact_collector_1.collect):
        raise AssertionError('expected SystemCapabilitiesFactCollector to have a "collect" method')

# Generated at 2022-06-24 23:32:40.406221
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:41.911060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:51.106598
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    facts_dict = system_capabilities_fact_collector_0.collect()
    system_capabilities_0 = facts_dict.get('system_capabilities')
    system_capabilities_enforced_0 = facts_dict.get('system_capabilities_enforced')

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        print("[ERROR] Script does not accept arguments")
        sys.exit(1)
    test_case_0()
    # Unit test for method collect of class SystemCapabilitiesFactCollector
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:33:00.760878
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = system_capabilities_fact_collector_0.collect()
    assert collected_facts_0 is None

# Generated at 2022-06-24 23:33:06.287878
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    f_name = 'ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector.collect'
    f_mock = mock.mock_open(read_data='\nCurrent: =ep\nBounding set =cap_chown,cap_dac_override+i\n')
    with mock.patch('%s.open' % f_name, f_mock):
        data = {'system_capabilities': ['cap_chown', 'cap_dac_override+i'], 'system_capabilities_enforced': 'False'}
        assert SystemCapabilitiesFactCollector().collect() == data

# Generated at 2022-06-24 23:33:08.015218
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = SystemCapabilitiesFactCollector.collect()
    assert facts_dict == {}

# Generated at 2022-06-24 23:33:10.608218
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # AssertionError: capsh_path is None
    try:
        assert system_capabilities_fact_collector_0.collect() == {}
    except AssertionError:
        pass

# Generated at 2022-06-24 23:33:16.119211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    sys.modules['_ansible_module_mock'] = MagicMock()
    system_capabilities_fact_collector_1.collect(module=MagicMock(), collected_facts=None)
    assert True


# Generated at 2022-06-24 23:33:26.465348
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    capsh_path = '/usr/sbin/capsh'

# Generated at 2022-06-24 23:33:31.149076
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Implement unit test
    # http://stackoverflow.com/questions/415511/how-to-get-current-time-in-python
    raise NotImplementedError

# Generated at 2022-06-24 23:33:32.607353
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}



# Generated at 2022-06-24 23:33:34.605081
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:33:38.495586
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:51.662107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:33:57.414569
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # NOTE: get_caps_data() results mocked
    # -> if capsh_path: -> return (0, '', '')
    # -> for line in out.splitlines():
    #     if len(line) < 1:
    #         continue
    #     if line.startswith('Current:'):
    #         if line.split(':')[1].strip() == '=ep':
    #             enforced = 'False'
    #         else:
    #             enforced = 'True'
    #             enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:59.654872
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:34:02.386459
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:34:04.991402
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:09.628517
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert 'system_capabilities_enforced' in var_1.keys()
    assert 'system_capabilities' in var_1.keys()

# Generated at 2022-06-24 23:34:13.032794
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:16.591057
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert(True)

# Generated at 2022-06-24 23:34:18.886456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:22.640600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    if var_0:
        exit(1)

# Generated at 2022-06-24 23:34:38.328765
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create instance
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # create fake module
    fake_module = FakeModule()
    # call method collect
    # assert that returned data is not none
    assert system_capabilities_fact_collector.collect(module=fake_module) != None
    # assert that returned data is correct
    # TODO: update the test to check that returned data is correct
    assert system_capabilities_fact_collector.collect(module=fake_module) != ''

# Unit test class FakeModule

# Generated at 2022-06-24 23:34:41.486090
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:34:43.974158
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:34:49.757129
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = {}
    assert var_0 == var_1

# Generated at 2022-06-24 23:34:53.077555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


# Generated at 2022-06-24 23:34:55.655031
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}



# Generated at 2022-06-24 23:34:57.919168
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = object()
    # Call the method
    var_0 = system_capabilities_fact_collector_0.collect(module=module_0)


# Generated at 2022-06-24 23:34:59.741084
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    assert var_0 == {}

# Generated at 2022-06-24 23:35:01.080831
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:06.165865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    print('type(system_capabilities_fact_collector_1) = %s' % type(system_capabilities_fact_collector_1))
    print('system_capabilities_fact_collector_1.name = %s' % system_capabilities_fact_collector_1.name)
    var_1 = system_capabilities_fact_collector_1.collect()
    print('type(var_1) = %s' % type(var_1))
    print('var_1 = %s' % var_1)

if __name__ == "__main__":
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:35:32.480693
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert len(var_0['system_capabilities_enforced']) == 2
    assert len(var_0['system_capabilities']) >= 0


# Generated at 2022-06-24 23:35:34.638638
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:35:39.342314
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    parm_0 = {}
    parm_1 = {}
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect(parm_0, parm_1)

# Generated at 2022-06-24 23:35:49.236261
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock import module_utils.basic, module_utils.facts.collector
    # Test case: unenforced capabilities (not in list)
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = type(MockModuleUtilBasic_0)()
    var_2.run_command.return_value = (0, 'Current: =ep', '')
    var_2.get_bin_path.return_value = ''
    var_3 = {'ansible_module': var_2}
    var_1.collect(collected_facts=var_3)
    assert var_2.run_command.call_count == 1
    var_4 = var_2.get_bin_path.call_count 

# Generated at 2022-06-24 23:35:52.575303
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    method_result = test_case_0()
    assert method_result['system_capabilities_enforced'] == 'True'
    assert method_result['system_capabilities'] == ['cap_net_raw+eip', 'cap_sys_ptrace+ep']

# Generated at 2022-06-24 23:35:54.259950
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:35:56.329339
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:59.738638
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {}


# Generated at 2022-06-24 23:36:06.769239
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert (var_0['system_capabilities_enforced'] == 'NA')
    assert (var_0['system_capabilities'].__class__ == list)
    assert (var_0['system_capabilities_enforced'].__class__ == str)


# Generated at 2022-06-24 23:36:12.838854
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert isinstance(var_1, dict) == True
    assert var_1['system_capabilities_enforced'] == 'NA'
    assert var_1['system_capabilities'] == []



# Generated at 2022-06-24 23:37:12.585071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # Tests should be added
    assert False



# Generated at 2022-06-24 23:37:16.321659
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = BaseFactCollector()
    var_3 = var_1.collect(module=var_2.module, collected_facts=var_2.collect)
    var_1.run_commands_on_remote()

# Generated at 2022-06-24 23:37:18.358084
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:23.975716
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Return value of method collect of class SystemCapabilitiesFactCollector
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = {}

    var_3 = var_1.collect()
    assert var_3 == var_2

# Generated at 2022-06-24 23:37:26.969402
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Instantiate the fact to be tested
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Call method collect of fact
    var_0 = system_capabilities_fact_collector_0.collect()
    # Assert the results of method collect
    assert var_0 == 'Not implemented!'

# Generated at 2022-06-24 23:37:30.711349
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: no easy way to mock module data, e.g. injected 'module' arg
    # TODO: get_caps_data()/parse_caps_data() for easier mocking -akl
    pass

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 23:37:34.474241
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    assert not var

# Generated at 2022-06-24 23:37:38.095194
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test if the collector collects the correct facts
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    ansible_facts = {'system_capabilities': [], 'ansible_facts':{'system_capabilities': [], 'ansible_system_capabilities': []}}
    # compare the facts collected by the collector with the expected AnsibleFacts
    assert var_1 == ansible_facts

# Generated at 2022-06-24 23:37:47.080394
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: [0] -akl
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    # unit test for method collect() of class SystemCapabilitiesFactCollector
    # NOTE: [1] -akl
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect({'ansible_facts': {}})

# Generated at 2022-06-24 23:37:48.219735
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:04.123176
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: 
    #   - check signature, instance variables -akl
    #   - change expect to return -akl
    #   - construct a 'mock' module object, populate instance variables (e.g. bin_path, changed, ...) -akl
    assert False


# Generated at 2022-06-24 23:40:09.116667
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:15.866547
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(BaseFactCollector.module)
    assert var_1 == {}
    # assert var_1['system_capabilities_enforced'] == 'NA'
    # assert var_1['system_capabilities'] == []


# Generated at 2022-06-24 23:40:22.339063
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Check when no module is present
    var = system_capabilities_fact_collector.collect()
    assert var == {}

    # Check when no binary is present
    # TODO: figure out how to mock a module object and how to mock a binary path



# Generated at 2022-06-24 23:40:23.314707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    emulated_collector = SystemCapabilitiesFactCollector()
    emulated_collector.collect()

# Generated at 2022-06-24 23:40:29.756283
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:34.303775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 23:40:38.912811
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = None
    var_0 = system_capabilities_fact_collector_0.collect(var_1)
    assert var_0 == {}


# Generated at 2022-06-24 23:40:41.068276
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var = SystemCapabilitiesFactCollector()

    var.collect()

# Generated at 2022-06-24 23:40:44.319894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def test_case_0():
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        var_0 = system_capabilities_fact_collector_0.collect()