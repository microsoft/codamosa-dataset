

# Generated at 2022-06-24 23:31:54.888582
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup the class
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:31:57.917440
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:32:04.424680
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:32:15.124927
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: syntax highlighting bug here, it's perfectly valid python -akl
    # TODO: mock return values of module.run_command and module.get_bin_path
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    class MockModule(object):
        def get_bin_path(self, path):
            # NOTE: invoke on 'None' -> return False
            return "/bin/capsh"
        def run_command(self, args):
            return 0, "Current: =ep \nBounding set =cap_chown,cap_fowner+ep", None
    mock_module = MockModule()
    result_dict = system_capabilities_fact_collector.collect(mock_module)
    assert result_dict['system_capabilities_enforced'] == 'False'
    assert result_dict

# Generated at 2022-06-24 23:32:24.353951
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:32:25.354406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # TODO: add this function test case
    # test_case_0()
    pass

# Generated at 2022-06-24 23:32:35.962206
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test uses the same module as in test_all_module_utils_facts
    from ansible.module_utils.facts import ansible_facts

    # Setup: create an instance of the SystemCapabilitiesFactCollector class
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    # Setup: create a mock 'module' which will be used for calling the collect method of
    # SystemCapabilitiesFactCollector
    mock_module_1 = ansible_facts.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
        check_invalid_arguments = True,
        bypass_checks = True
    )

    # Setup: create a mock 'collect' method which will be used to overwrite the
    # collect method of SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:32:39.805305
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = {}
    module_0 = 'module_0'
    collected_facts_0 = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    assert collected_facts_0 == system_capabilities_fact_collector_0.collect(module_0, collected_facts_0)

# Generated at 2022-06-24 23:32:46.888350
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import MagicMock, patch
    from ansible.module_utils import basic

    capsh_path = 'capsh_path'

    class SystemCapabilitiesFactCollector_0():
        def __init__(self):
            pass

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'capsh':
                return capsh_path

    SystemCapabilitiesFactCollector_obj_0 = SystemCapabilitiesFactCollector()
    SystemCapabilitiesFactCollector_obj_0.get_bin_path = MagicMock(side_effect=SystemCapabilitiesFactCollector_0().get_bin_path)
    module_0 = SystemCapabilitiesFactCollector_obj_0
    module_

# Generated at 2022-06-24 23:32:52.334425
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:32:59.224607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect(collected_facts=None)
    assert len(var) != 0

# Generated at 2022-06-24 23:33:05.559390
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var = system_capabilities_fact_collector.collect()
    assert isinstance(var, dict)
    assert var['system_capabilities_enforced'] == 'NA'
    assert isinstance(var['system_capabilities'], list)


# Generated at 2022-06-24 23:33:08.369603
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = var_1.collect()
    print(var_2)
    assert var_2 == {}, 'var_2 == {}'


# Generated at 2022-06-24 23:33:11.175581
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert 'system_capabilities' in var_0
    assert 'system_capabilities_enforced' in var_0



# Generated at 2022-06-24 23:33:15.863957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 ==  {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-24 23:33:19.714159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:33:21.475590
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:33:32.792555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:33:34.888381
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-24 23:33:38.495514
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:33:41.977776
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  pass

# Generated at 2022-06-24 23:33:45.330283
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    #assert var_0 == expected_0
    assert var_0 == {}

# Generated at 2022-06-24 23:33:52.847849
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    print(var_0)

    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:59.867371
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()

# Generated at 2022-06-24 23:34:02.275966
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:34:05.473645
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:12.627510
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    # assert var_0 == True
    # system_capabilities_fact_collector_0.generate_random_string()
    # assert var_0 == True
    # assert system_capabilities_fact_collector_0.collect() == True
    # assert True
    return True



# Generated at 2022-06-24 23:34:16.088870
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect()
    assert var_1 == {}, 'Expected var_1 == <>, but got {}'.format(var_1)

# Test module


# Generated at 2022-06-24 23:34:18.605660
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 is not False, 'Unable to retrieve data for fact SystemCapabilitiesFactCollector'

# Generated at 2022-06-24 23:34:22.035419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
 
    # Test cases
    assert (test_SystemCapabilitiesFactCollector_collect() == None)

# Generated at 2022-06-24 23:34:27.083794
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(module=None)
    assert var_0 == {}


# Generated at 2022-06-24 23:34:32.008873
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == system_capabilities_fact_collector_1._fact_ids


# Generated at 2022-06-24 23:34:35.974695
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    module_3 = None
    var_4 = system_capabilities_fact_collector_2.collect(module=module_3)
    assert var_4 == {}

    # TODO: More tests
    #       1. test if output is invalid, like containing invalid characters
    #       2. test if output ends with newlines

# Generated at 2022-06-24 23:34:41.698685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    # Invoke method
    var_0 = system_capabilities_fact_collector_1.collect()

    # Check return types
    assert isinstance(var_0, dict)

    # Check return values
    assert var_0 == {}


# Generated at 2022-06-24 23:34:44.729089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    method_result_0 = system_capabilities_fact_collector_0.collect()
    assert type(method_result_0) == dict


# Generated at 2022-06-24 23:34:50.625201
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


# Generated at 2022-06-24 23:34:52.679455
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:58.693574
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert set(var_0.keys()) == set(['system_capabilities_enforced', 'system_capabilities'])

# Generated at 2022-06-24 23:35:01.148336
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:10.819985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Assert if get_caps_data return value is parsed correctly
    get_caps_data = lambda: (0, 'Current: =ep', '')
    with mock.patch('ansible.module_utils.facts.collector.SystemCapabilitiesFactCollector.get_caps_data', get_caps_data):
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        var_0 = system_capabilities_fact_collector_0.collect()
        assert var_0 == dict(system_capabilities_enforced='False',
                             system_capabilities=[])

    # Assert if get_caps_data return value is parsed correctly
    get_caps_data = lambda: (0, 'Current: =ep cap_net_admin,cap_net_raw+eip', '')

# Generated at 2022-06-24 23:35:22.439802
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system
    system_capabilities_fact_collector_obj_0 = SystemCapabilitiesFactCollector()

    class MockModule:
        def get_bin_path(self, arg0):
            assert arg0 == 'capsh'
            return 'capsh_bin_path'

        def run_command(self, arg0, arg1):
            assert arg0 == ['capsh_bin_path', '--print']
            assert arg1 == 'errors'
            return 'rc', 'out', 'err'
    mock_module_0 = MockModule()

    rc_expected = 'rc'
    out_expected = 'out'
    err_expected = 'err'

# Generated at 2022-06-24 23:35:25.565658
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert var_1 == {}


# Generated at 2022-06-24 23:35:29.798694
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module = AnsibleModule(
        argument_spec = dict(
        )
    )

    var_0 = system_capabilities_fact_collector_0.collect(module)


if __name__ == '__main__':
    sys.exit(unittest.main())

# Generated at 2022-06-24 23:35:31.635731
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:32.989494
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:34.834393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:39.312243
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:42.315776
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert var_1 == {'system_capabilities_enforced': 'True', 'system_capabilities': []}

# Generated at 2022-06-24 23:35:44.126501
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == None


# Generated at 2022-06-24 23:35:46.047775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-24 23:35:53.506801
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:57.880592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
#

# Generated at 2022-06-24 23:36:00.596528
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:03.477930
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Instantiate class
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector, SystemCapabilitiesFactCollector)



# Generated at 2022-06-24 23:36:07.144283
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:10.314793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # first test
    var_1 = system_capabilities_fact_collector_1.collect()
    assert 'system_capabilities_enforced' in var_1
    assert 'system_capabilities' in var_1

# Generated at 2022-06-24 23:36:15.484522
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_1.collect()
    assert result == None


# Generated at 2022-06-24 23:36:17.147021
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}


# Generated at 2022-06-24 23:36:20.896674
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0 = var_0
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:24.806014
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    return_value_0 = system_capabilities_fact_collector_0.collect()
    assert return_value_0 is None


# Generated at 2022-06-24 23:36:43.256291
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: auto-generate this test method via utility script once mock impl is ready -akl
    pass
# END OF TEST SCRIPT FOR PyUnit

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-24 23:36:45.643515
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:36:49.929519
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    #
    # Test with empty arguments
    #
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict) is True
    assert len(var_0) == 0

    #
    # Test with not empty arguments
    #
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict) is True


# Generated at 2022-06-24 23:36:56.431583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('\n<test_SystemCapabilitiesFactCollector_collect()>')

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    print('\n<test_SystemCapabilitiesFactCollector_collect()> <end>')

# Generated at 2022-06-24 23:36:59.620226
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect(module=None)
    var_2 = var_0.collect(collected_facts=None, module=None)



# Generated at 2022-06-24 23:37:01.244558
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert True


# Generated at 2022-06-24 23:37:08.063841
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


if __name__ == '__main__':
    # Unit test for method collect of class SystemCapabilitiesFactCollector
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:37:12.300131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()



# Generated at 2022-06-24 23:37:17.344388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.capsh.collector import SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_2.collect()
    assert len(var_1) == 2
    assert "system_capabilities_enforced" in var_1
    assert "system_capabilities" in var_1

# Generated at 2022-06-24 23:37:18.489226
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:37:46.126098
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:47.612422
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == None

# Generated at 2022-06-24 23:37:49.238126
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:37:58.434308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def test_case(expected_outcome, module_output=None, capsh_output=None):
        assert True

    # Expected result :
    # False

# Generated at 2022-06-24 23:38:00.732614
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:38:04.867869
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()
    return None

test_case_0()

# Generated at 2022-06-24 23:38:06.717607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    pass

# Generated at 2022-06-24 23:38:10.241431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert var_1 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


# Generated at 2022-06-24 23:38:11.715137
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:17.666134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
       test_case_0()
       print('{} test case passed'.format('test_case_0'))
    except Exception as e:
      print('{} test case failed'.format('test_case_0'))
      print('{} exception: {}'.format(type(e).__name__, e))

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:39:35.089710
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:39:37.847592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:39:44.393765
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    var_1 = system_capabilities_fact_collector_1.collect()
    var_1 = system_capabilities_fact_collector_1.collect()
    var_1 = system_capabilities_fact_collector_1.collect()
    # assert that SystemCapabilitiesFactCollector.collect() is called
    # with module=None and collected_facts=None
    #   and that SystemCapabilitiesFactCollector.collect() returns empty
    #   dictionary
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}


if __name__ == "__main__":
    test_case_0

# Generated at 2022-06-24 23:39:52.167849
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.system import SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert len(var_0) == 2
    var_1 = var_0['system_capabilities_enforced'] is not None
    assert var_1
    var_2 = var_0['system_capabilities'] is not None
    assert var_2

# Generated at 2022-06-24 23:39:57.915310
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:40:02.873404
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:05.116767
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:13.662328
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:40:17.589813
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fixture_0 = None
    expected_0 = {'system_capabilities_enforced': 'NA',
                  'system_capabilities': []}

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    actual_0 = system_capabilities_fact_collector_0.collect(fixture_0)

    assert expected_0 == actual_0, 'Test failed'



# Generated at 2022-06-24 23:40:20.966759
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        var_0 = SystemCapabilitiesFactCollector.collect('')
    except:
        assert False
    else:
        assert True