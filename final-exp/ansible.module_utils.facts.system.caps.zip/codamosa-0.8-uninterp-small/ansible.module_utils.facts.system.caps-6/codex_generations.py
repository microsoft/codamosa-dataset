

# Generated at 2022-06-24 23:31:59.802624
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Return Stub results
    stub_results = {'changed': False, 'failed': False, 'rc': 0}

    # Return Stub cmd
    stub_cmd = ['capsh', '--print']

    # Return Stub out
    stub_out = "Current: =ep\n"

    # Return Stub err
    stub_err = ''

    # Create a StubModule for the 'ansible.module_utils.basic.AnsibleModule' class
    class StubModule:
        def __init__(self, **kwargs):
            self.params = kwargs
            self.exit_json = lambda x: stub_results

            self.run_command = lambda cmd: (0, stub_out, stub_err)

# Generated at 2022-06-24 23:32:03.612909
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:09.123824
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    error_msg = None
    try:
        ret = system_capabilities_fact_collector_0.collect()
        if 0: raise Exception
    except Exception as e:
        error_msg = str(e)
    return [error_msg, ret]

# Generated at 2022-06-24 23:32:11.639134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}

# Generated at 2022-06-24 23:32:13.180681
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collected_facts = {}

    SystemCapabilitiesFactCollector.collect(collected_facts=collected_facts)

# Generated at 2022-06-24 23:32:19.659862
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector, BaseFactCollector)
    assert hasattr(system_capabilities_fact_collector, "name")
    assert hasattr(system_capabilities_fact_collector, "_fact_ids")
    assert system_capabilities_fact_collector._fact_ids == {'system_capabilities_enforced', 'system_capabilities'}
    assert system_capabilities_fact_collector.name == 'caps'

# Generated at 2022-06-24 23:32:26.536873
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = os.path.abspath(os.path.join(os.getcwd(), 'test_case_0', 'capsh'))
    def mock_run_command(cmd, **kwargs):
        if cmd[0] == capsh_path:
            return (0, 'Current: =eip', None)
        return (0, None, None)

    module = Mock()
    module.run_command = mock_run_command
    module.params = {'gather_subset': ['!all', 'capabilities']}
    collected_facts = system_capabilities_fact_collector_0.collect(module=module, collected_facts=Mock())

    # TODO: verify collected_facts

# Generated at 2022-06-24 23:32:28.120483
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:32:30.903346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector_obj = system_capabilities_fact_collector_0
    results = collector_obj.collect()
    assert results == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


# Generated at 2022-06-24 23:32:37.206840
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Call method collect of SystemCapabilitiesFactCollector
    # FIXME: add assertions
    results = system_capabilities_fact_collector_0.collect()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:42.731773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:32:45.373827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test the collect method of SystemCapabilitiesFactCollector
    """
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:32:50.878406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module = None
    collected_facts = None
    return_value = system_capabilities_fact_collector_1.collect(module, collected_facts)
    assert return_value == {}


# Generated at 2022-06-24 23:32:56.416511
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert  'system_capabilities_enforced' in system_capabilities_fact_collector_0.collect()
    assert  'system_capabilities' in system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:58.340795
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:33:08.798750
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Get an instance of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # Don't run test on Windows
    if system_capabilities_fact_collector.on_windows:
        return
    # Mock module
    module = get_an_instance_of_AnsibleModule()
    # Call method collect of SystemCapabilitiesFactCollector
    return_value = system_capabilities_fact_collector.collect(module, None)
    # Assert fact 'system_capabilities_enforced' is one of ['True', 'False', 'NA']
    assert return_value['system_capabilities_enforced'] in ['True', 'False', 'NA']
    # Assert fact 'system_capabilities' is list of length > 0

# Generated at 2022-06-24 23:33:15.808354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector_obj = SystemCapabilitiesFactCollector()
    fact_collector_obj._module = MagicMock()
    fact_collector_obj._module.get_bin_path.return_value = True
    fact_collector_obj._module.run_command.return_value = (0, 'Current: =ep', '')
    assert fact_collector_obj.collect() == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    fact_collector_obj._module.run_command.return_value = (0, 'Current: =ep cap_chown,cap_dac_override +eip', '')

# Generated at 2022-06-24 23:33:26.005660
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    import ansible_collections.ansible.community.plugins.module_utils.facts.system.caps as caps_utils
    # NOTE: mock obj needed in case of 'if not module' exit
    test_case_0_obj = caps_utils
    test_case_0_obj.which = lambda x: 'capsh_path'
    test_case_0_obj.run_command = lambda x, y: ['', '', '']

    # Mock the module
    # NOTE: mock obj needed in case of 'if not module' exit
    import ansible_collections.ansible.community.plugins.module_utils.basic as basic_utils
    test_case_0_obj = basic_utils
    test_case_0_obj.Ansible

# Generated at 2022-06-24 23:33:30.243182
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    rc, out, err = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:33:32.457855
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector, SystemCapabilitiesFactCollector)

# Generated at 2022-06-24 23:33:46.140647
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:33:55.218705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    facts_dict_0 = system_capabilities_fact_collector_0.collect(
        module=None,
        collected_facts=None,
    )
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    facts_dict_1 = system_capabilities_fact_collector_1.collect(
        module=None,
        collected_facts=None,
    )
    assert facts_dict_0 == facts_dict_1


# Generated at 2022-06-24 23:34:04.669551
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    test_module_0 = MockModule()
    test_module_1 = MockModule()
    test_module_1.run_command = Mock(return_value="Current: =ep")
    results = []
    results.append(system_capabilities_fact_collector_0.collect(module=test_module_0, collected_facts={}))
    results.append(system_capabilities_fact_collector_1.collect(module=test_module_1, collected_facts={}))
    expected_results = [{}, {'system_capabilities_enforced': 'False', 'system_capabilities': []}]
    assert results == expected_results


# Generated at 2022-06-24 23:34:16.045787
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path_0 = '/usr/bin/capsh'
    capsh_path_1 = '/usr/bin/capsh'
    rc_0 = 0
    rc_1 = 0
    out_0 = "Current: =ep"
    out_1 = "Current: =ep"
    err_0 = ''
    err_1 = ''
    errors_0 = 'surrogate_then_replace'
    errors_1 = 'surrogate_then_replace'
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module = None
    module.get_bin_path = MagicMock(side_effect=[capsh_path_0, capsh_path_1])

# Generated at 2022-06-24 23:34:18.296318
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_collect = SystemCapabilitiesFactCollector()

    facts_dict = {}
    assert system_capabilities_fact_collector_collect.collect(None, facts_dict) == {}



# Generated at 2022-06-24 23:34:21.756298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    rc, out, err = None, None, None
    rc, out, err = system_capabilities_fact_collector_0.collect(
         module=rc,
        collected_facts=rc)
    assert rc == {}

# Generated at 2022-06-24 23:34:26.458599
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    assert 'system_capabilities' in system_capabilities_fact_collector_0.fact_ids
    assert 'system_capabilities_enforced' in system_capabilities_fact_collector_0.fact_ids

# Generated at 2022-06-24 23:34:36.412516
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:34:39.754130
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:47.209860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.module = None

    rc, out, err = system_capabilities_fact_collector_0.module.run_command(['capsh', "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'
                enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]
    system_

# Generated at 2022-06-24 23:35:00.108576
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    setattr(system_capabilities_fact_collector_0, '_module', None)
    setattr(system_capabilities_fact_collector_0, '_collected_facts', None)
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:01.031599
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False


# Generated at 2022-06-24 23:35:02.539977
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:07.377545
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:35:08.692523
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector_obj = SystemCapabilitiesFactCollector()
    SystemCapabilitiesFactCollector_obj.collect()

# Generated at 2022-06-24 23:35:10.943232
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    if not system_capabilities_fact_collector_0.collect():
        return 1
    return 0


# Generated at 2022-06-24 23:35:12.895354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test not yet implemented -akl
    pass

# Generated at 2022-06-24 23:35:21.936303
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:35:31.218724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    test_module_0 = AnsibleModule(
        argument_spec=dict()
    )
    test_module_0.run_command = MagicMock(return_value=(0, 'Current:\n =ep', ''))
    test_module_0.get_bin_path = MagicMock(return_value='')
    test_dict_0 = system_capabilities_fact_collector_1.collect(module=test_module_0)
    assert test_dict_0['system_capabilities_enforced'] == 'False'
    assert test_dict_0['system_capabilities'] == []

# Generated at 2022-06-24 23:35:41.115422
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = {}
    module_0 = None
    stored_facts_0 = {}
    # Unit-test: test case 0
    try:
        test_case_0()
    except Exception as exception_0:
        print('Unhandled exception: {}'.format(exception_0))

    # Unit-test: test case 1
    try:
        assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
        print('SUCCESS: test case 1')
    except AssertionError as ae_1:
        print('FAILED: test case 1')

    # Unit-test: test case 2

# Generated at 2022-06-24 23:35:48.053060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    baz = SystemCapabilitiesFactCollector()
    result = baz.collect()
    assert result == {}

# Generated at 2022-06-24 23:35:50.636688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    try:
        var_0 = system_capabilities_fact_collector_0.collect()
    except:
        assert False


# Generated at 2022-06-24 23:35:57.852613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Select the module for testing
    module = ansible_module_SystemCapabilitiesFactCollector

    # Select the class for testing
    class_under_test = SystemCapabilitiesFactCollector

    # Build arguments for the test
    args = [module, ]

    # Build kwargs for the test
    kwargs = {
    }

    # Execute the test function
    function_under_test = class_under_test.collect
    function_under_test_return_value = class_under_test.collect(*args, **kwargs)

    # Check the return type
    assert isinstance(function_under_test_return_value, dict)

    # Check the return value
    assert function_under_test_return_value == {}

# Generated at 2022-06-24 23:36:05.731089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect()
    var_4 = system_capabilities_fact_collector_0.collect()
    var_5 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:08.286456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:12.154874
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module_1 = MagicMock(return_value='/usr/bin/capsh')
    collected_facts_1 = MagicMock()
    var_1 = system_capabilities_fact_collector_1.collect(module_1, collected_facts_1)
    var_1 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:36:18.956923
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    ansible_module = AnsibleModule(argument_spec={
        'capsh_path': {'type': 'str', 'required': True}
    })
    ansible_module.get_bin_path = MagicMock(return_value='/usr/bin/capsh')
    ansible_module.run_command = MagicMock(return_value=[0, 'Current:=ep', ''])
    var_0 = system_capabilities_fact_collector_0.collect(module=ansible_module)
    assert var_0 == {}

# Generated at 2022-06-24 23:36:20.847567
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:23.306215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect()
    assert var_1 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}



# Generated at 2022-06-24 23:36:24.904363
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:36:45.733317
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0['system_capabilities_enforced']=='NA'
    assert var_0['system_capabilities']==[]
    assert list(var_0)==['system_capabilities', 'system_capabilities_enforced']



# Generated at 2022-06-24 23:36:48.750412
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Unit test for method collect of class SystemCapabilitiesFactCollector
    # NOTE: test 'if not crash_path' and unindent rest of method -akl
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()



# Generated at 2022-06-24 23:36:54.231156
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/bin/capsh'
    test_module_0 = AnsibleModule(argument_spec={})
    test_module_0.get_bin_path = MagicMock(return_value=capsh_path)
    test_module_0.run_command = MagicMock(return_value=(0, 'Current: = cap_chown,cap_dac_override+eip cap_setfcap+ai',''))
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(test_module_0)

# Generated at 2022-06-24 23:36:58.226592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert 'system_capabilities' in var_0
    assert 'system_capabilities_enforced' in var_0
    

# Generated at 2022-06-24 23:37:00.110271
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:02.449893
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    s = SystemCapabilitiesFactCollector()

    # case 0
    v = s.collect()
    assert v == {'system_capabilities': [],
                 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:37:07.291052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Run test function
    # TODO: assert
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:37:10.847306
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:37:12.397790
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var = SystemCapabilitiesFactCollector()
    var.collect()

# Generated at 2022-06-24 23:37:15.323778
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:43.982628
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: method collect() may lack 'self' argument -akl
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # TODO(akl): implement tests
    assert(True)


# Generated at 2022-06-24 23:37:45.428729
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-24 23:37:49.820471
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("Test collect")
    

# Generated at 2022-06-24 23:37:50.246544
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:37:56.179679
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

    # Ensure that var_1 equals var_1
    assert var_1 ==  var_1

# Generated at 2022-06-24 23:37:59.899160
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:04.422444
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-24 23:38:06.500882
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {"system_capabilities": [], "system_capabilities_enforced": "NA"}


# Generated at 2022-06-24 23:38:09.477760
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'True'}



# Generated at 2022-06-24 23:38:13.629470
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    with pytest.raises((Exception,)) as excinfo:
        var_0 = system_capabilities_fact_collector_0.collect()
    with pytest.raises((Exception,)) as excinfo:
        var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:26.129342
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Assert if the collect method returns a valid value
    # TODO write test
    pass


# Generated at 2022-06-24 23:39:28.039702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:31.954833
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': ['cap_dac_read_search', 'cap_chown'], 'system_capabilities_enforced': 'True'}

# Generated at 2022-06-24 23:39:34.629571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create object for class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:39:37.354585
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:39.450586
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == dict()

# Generated at 2022-06-24 23:39:43.194665
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    print("Result of test {}: {}".format("test_SystemCapabilitiesFactCollector_collect", var_0))
    assert var_0 is None

if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:39:45.288942
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {}, "Incorrect value returned by collect"


# Generated at 2022-06-24 23:39:51.982650
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    # if 'NA' == var_0['system_capabilities_enforced']:
    #     pass  # skipped
    # else:
    #     assert 'setuid' in var_0['system_capabilities']


# Generated at 2022-06-24 23:39:54.694003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector_0 = SystemCapabilitiesFactCollector()
    var_module = None
    var_collected_facts = None
    var_return = fact_collector_0.collect(module=var_module, collected_facts=var_collected_facts)
    assert var_return == {}

