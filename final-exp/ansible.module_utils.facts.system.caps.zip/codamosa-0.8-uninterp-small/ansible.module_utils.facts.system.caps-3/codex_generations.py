

# Generated at 2022-06-24 23:31:53.842540
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Module <type 'ansible.module_utils.basic.AnsibleModule'>
    module_0 = None
    system_capabilities_fact_collector_0.collect(module_0)

# Generated at 2022-06-24 23:31:59.993273
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('\nEntering test_SystemCapabilitiesFactCollector_collect...')

    # Creating object
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Testing method collect
    # It will only return the default values (as defined above)
    # Passing None for argument module
    res = system_capabilities_fact_collector_0.collect()
    print('\nTest 1:')
    print('result = ', res)



# Generated at 2022-06-24 23:32:04.610853
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_1.collect(module=None, collected_facts=None)
    assert result == facts_dict


# Generated at 2022-06-24 23:32:08.383997
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # TODO: add tests
    # assert_equals(, system_capabilities_fact_collector.collect())
    return 0


# Generated at 2022-06-24 23:32:18.047501
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import Collector
    import pytest

    # NOTE: Replace with other imported modules or functions -akl
    from ansible.module_utils import basic as module_utils_basic
    import ansible.module_utils.common.collections as module_utils_common_collections
    import ansible.module_utils.facts.collector as module_utils_facts_collector

    # NOTE: Add proper types to arguments and return values -akl

# Generated at 2022-06-24 23:32:26.398225
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    class CollectMock:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class RunCommandMock:
        def __init__(self, rc, out):
            self.rc = rc
            self.out = out

        def __call__(self, cmd, errors):
            return self.rc, self.out, []

    class GetBinPathMock:
        def __init__(self, out):
            self.out = out

        def __call__(self, cmd):
            return self.out or None

    # when capsh not found

# Generated at 2022-06-24 23:32:27.126882
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:32:37.004185
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        import mock
    except ImportError:
        # NOTE: in order to run this on ansible-test you need to
        # pip install mock on the system you run ansible-test on
        return
    def mock_run_command(module, args, errors='surrogate_then_replace'):
        if args[0] == '/usr/bin/capsh':
            if len(args) == 2:
                return 0, 'Current: =ep Capacity Effective:  =ep Inheritable:  =ep Permitted:  =ep Bounding set =ep', 'stderr'
            else:
                return 1, '', 'stderr'
        else:
            return 1, '', 'stderr'


# Generated at 2022-06-24 23:32:37.768124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  assert True


# Generated at 2022-06-24 23:32:45.211870
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector.
    '''
    # case 0:
    #
    # 1. get_bin_path returns None
    # 2. Collected facts will be the empty dictionary
    #

    # get_bin_path returns None
    crush_path = None

    # Construct an instance of class SystemCapabilitiesFactCollector with
    # and call collect() without parameters
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = system_capabilities_fact_collector_0.collect()

    # The collected facts will be the empty dictionary
    assert collected_facts_0 == {}

    # case 1:
    #
    # 1. get_bin_path returns a non-empty string
    # 2. get_bin_

# Generated at 2022-06-24 23:32:52.709643
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-24 23:32:55.359597
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:33:03.720725
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_1.collect()
    var_2 = system_capabilities_fact_collector_2.collect()


# Generated at 2022-06-24 23:33:05.895203
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Testing capsh fact')


if __name__ == "__main__":
    print('Error: must run as an ansible module')

# Generated at 2022-06-24 23:33:08.325078
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:10.668230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect()
    assert var_1 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-24 23:33:22.234052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # capsh_path
    var_61 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_62 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_63 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_64 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_65 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_66 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_67 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_68 = SystemCapabilitiesFactCollector()
    # capsh_path
    var_69 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:33:25.049920
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_0.collect()
    assert isinstance(result, dict)
    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result


# Generated at 2022-06-24 23:33:31.799191
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Candidate: {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_dac_override,cap_net_admin', 'cap_sys_admin']}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:33:33.794417
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:43.788143
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: We assume we have a capsh binary in our PATH (maybe we can
    #       mock instead?)
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect()
    assert isinstance(result, dict)
    assert "system_capabilities" in result

# Generated at 2022-06-24 23:33:48.435953
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        # noinspection PyUnusedLocal
        system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
        # noinspection PyUnusedLocal
        var_0 = system_capabilities_fact_collector_0.collect()

        assert True
    except:
        assert False


# Generated at 2022-06-24 23:33:53.655522
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.name
    assert var_0 == 'caps'
    assert type(var_0) is str
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert type(var_1) is dict

# Generated at 2022-06-24 23:34:00.478585
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # The 'system_capabilities' key shouldn't exist in the return value of collect() if capsh is not available
    capsh_path = '/bin/capsh'
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = system_capabilities_fact_collector.collect()
    assert 'system_capabilities' not in facts_dict
    # The 'system_capabilities' key should exist in the return value of collect() if capsh is available
    capsh_path = 'capsh'
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = system_capabilities_fact_collector.collect()
    assert 'system_capabilities' in facts_dict

# Generated at 2022-06-24 23:34:02.821819
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:09.260180
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    dictionary_1 = {}
    dictionary_2 = {}
    try:
        dictionary_1 = system_capabilities_fact_collector_0.collect()
    except Exception as e_3:
        dictionary_2['ansible_failed'] = True
        if (not isinstance(e_3, AnsibleUndefinedVariable) or not isinstance(e_3, AnsibleFileNotFound)):
            dictionary_2['ansible_facts'] = {}
            dictionary_2['ansible_facts']['discovered_interpreter_python'] = '/usr/bin/python'
            dictionary_2['changed'] = False
            dictionary_2['ansible_module_results'] = {}

# Generated at 2022-06-24 23:34:12.736029
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:18.235299
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()

    assert var_1 == {}


# Generated at 2022-06-24 23:34:21.406669
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}



# Generated at 2022-06-24 23:34:24.234792
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:34:34.631193
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == dict(system_capabilities=[], system_capabilities_enforced='NA')

# Generated at 2022-06-24 23:34:41.195767
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Instantiate the class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # Call the method collect of class SystemCapabilitiesFactCollector
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:44.869109
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:55.018668
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    ansible_module_0 = MagicMock(name='ansible_module_0')
    ansible_module_0.get_bin_path.return_value = 'capsh'
    ansible_module_0.run_command.return_value = [0, 'Current: =eip', None]

    ansible_module_1 = MagicMock(name='ansible_module_1')
    ansible_module_1.get_bin_path.return_value = 'capsh'
    ansible_module_1.run_command.return_value = [0, 'Current: =ep', None]

    ansible_module_2 = MagicMock(name='ansible_module_2')
    ansible_module_2.get

# Generated at 2022-06-24 23:35:00.799730
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: direct access to '_fact_ids' will be needed, so disable 'protected-access' -akl
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()  # LINT [pycodestyle warnings: protected-access]
    return_value_0 = system_capabilities_fact_collector_0.collect()
    assert return_value_0 == {}


# Generated at 2022-06-24 23:35:02.812640
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:35:07.592135
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:10.781323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 is not None
    assert isinstance(var_0, dict)
    assert "system_capabilities" in var_0
    assert isinstance(var_0['system_capabilities'], list)
    assert "system_capabilities_enforced" in var_0

# Generated at 2022-06-24 23:35:16.422350
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:17.640231
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    object_0 = SystemCapabilitiesFactCollector()
    assert object_0.collect() == {}

# Generated at 2022-06-24 23:35:26.085895
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_1.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:35:31.635366
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        # Mock object
        system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
        module_mock = Mock()
        collected_facts_mock = Mock()
        module_mock.run_command.return_value = [0, 'out', 'err']
        system_capabilities_fact_collector_1.collect(module_mock, collected_facts_mock)
        assert True
    except Exception:
        assert True

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:35:33.521148
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:38.642010
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = 'system_capabilities_enforced'
    var_2 = 'system_capabilities'
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    capsh_path = system_capabilities_fact_collector_1.get_bin_path('capsh')
    rc, out, err = system_capabilities_fact_collector_1.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'

# Generated at 2022-06-24 23:35:41.075980
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-24 23:35:42.883711
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # FIXME: How can I test this?
    # assert(system_capabilities_fact_collector_0.collect() == <EXPECTED_VALUE>)

# Generated at 2022-06-24 23:35:48.408850
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:35:52.611729
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    facts_dict = system_capabilities_fact_collector_0.collect()
    keys = facts_dict.keys()
    assert ('system_capabilities_enforced' in keys) == True
    assert ('system_capabilities' in keys) == True
    # NOTE: unindent

# Generated at 2022-06-24 23:35:57.650700
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()
    pass

# Generated at 2022-06-24 23:36:00.452702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:36:15.980857
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    _system_capabilities_fact_collector = None
    _system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = _system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:36:24.607262
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    assert system_capabilities_fact_collector_0.name == 'caps'
    assert system_capabilities_fact_collector_0._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    print('VARIABLE var_0: %s\n' % repr(var_0))
    print('VARIABLE system_capabilities_fact_collector_0.name: %s\n' % repr(system_capabilities_fact_collector_0.name))

# Generated at 2022-06-24 23:36:26.776215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Arrange
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Act
    result = system_capabilities_fact_collector.collect()

    # Assert
    assert result


# Generated at 2022-06-24 23:36:32.364665
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.name
    system_capabilities_fact_collector_0._fact_ids
    system_capabilities_fact_collector_0.collect()
    system_capabilities_fact_collector_0._fact_ids


# Generated at 2022-06-24 23:36:35.525506
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:36:40.873838
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:45.432454
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert len(var_0) == 2
    assert 'system_capabilities' in var_0
    assert len(var_0['system_capabilities']) == 0
    assert 'system_capabilities_enforced' in var_0
    assert var_0['system_capabilities_enforced'] == 'NA'

# Generated at 2022-06-24 23:36:48.196044
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    params_1 = {}
    compiled_script = {}
    var_3 = system_capabilities_fact_collector_1.collect(params_1, compiled_script)
    assert var_3 == {}



# Generated at 2022-06-24 23:36:49.609826
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:52.139501
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect({})

    assert var_0 == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA',
    }


# Generated at 2022-06-24 23:37:22.417782
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:25.914871
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:32.648330
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    str_0 = 'Current: =ep BOUNDING'
    dict_0 = {}
    dict_1 = system_capabilities_fact_collector_0.collect(str_0, dict_0)
    var_0 = dict_1['system_capabilities_enforced']
    var_1 = dict_1['system_capabilities']
    var_1.remove('BOUNDING')
    assert var_0 == 'False'
    assert var_1 == []


# Generated at 2022-06-24 23:37:34.820401
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:37:35.714383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_0.collect()

# Generated at 2022-06-24 23:37:37.293980
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = var_0.collect()



# Generated at 2022-06-24 23:37:43.633122
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    # TODO: add your test here
    assert var_0

# Generated at 2022-06-24 23:37:50.686468
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = MockModule()
    collected_facts_0 = {}

    # Test case where capsh is not installed
    rc_0, out_0, err_0 = module_0.run_command([], True)
    ret_0 = system_capabilities_fact_collector_0.collect(module_0, collected_facts_0)
    assert ret_0 == {}
    ret_1 = system_capabilities_fact_collector_0.collect(module_0, collected_facts_0)
    assert ret_1 == {}

    # Test the case where capsh is installed with no capabilities
    rc_1, out_1, err_1 = module_0.run_command([], False)
    ret_2 = system_capabilities

# Generated at 2022-06-24 23:37:56.139158
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 is None


# Generated at 2022-06-24 23:37:57.472160
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("Test - collect")

    print("\tExecute: test_SystemCapabilitiesFactCollector_collect")
    test_case_0()

# Generated at 2022-06-24 23:39:03.449901
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert type(var_1) is dict

# Generated at 2022-06-24 23:39:08.283808
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path_0 = os.path.abspath(__file__)
    if not capsh_path_0:
        enforced_caps_0 = []
        enforced_0 = 'NA'
    else:
        rc, out_0, err_0 = module.run_command([capsh_path_0, "--print"], errors='surrogate_then_replace')
        enforced_caps_0 = []
        enforced_0 = 'NA'
        for line_0 in out_0.splitlines():
            if len(line_0) < 1:
                continue
            if line_0.startswith('Current:'):
                if line_0.split(':')[1].strip() == '=ep':
                    enforced_0 = 'False'
                else:
                    enforced_0 = 'True'
                    enforced

# Generated at 2022-06-24 23:39:12.769230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()



# Generated at 2022-06-24 23:39:15.211688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:16.016644
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:39:18.335022
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == None


# Generated at 2022-06-24 23:39:22.181891
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # input parameters
    module = None
    collected_facts = None

    # expected return values
    expected = {}

    # test case
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    got = system_capabilities_fact_collector_0.collect(module, collected_facts)
    assert got == expected, "Expected error"


# Generated at 2022-06-24 23:39:27.446862
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = None
    var_2 = system_capabilities_fact_collector_1.collect(module=var_1)
    assert var_2 == {}


# Generated at 2022-06-24 23:39:35.151733
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/bin/capsh'
    rc = 0

# Generated at 2022-06-24 23:39:39.520176
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # NOTE: Pass in mock module and mock collected_facts, return Facts()
    # instance with mock values -akl
    var_0 = system_capabilities_fact_collector_0.collect(module=MockModule(),
                                                         collected_facts=MockFacts())


# Generated at 2022-06-24 23:41:47.645429
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == { }


# Generated at 2022-06-24 23:41:49.221481
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

