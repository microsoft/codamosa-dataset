

# Generated at 2022-06-24 23:31:57.562592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}

# Generated at 2022-06-24 23:32:01.737267
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # First test with module == None
    system_capabilities_fact_collector.collect(module = None, collected_facts = None)
    # Second test with all the necessary arguments
    system_capabilities_fact_collector.collect(module = None, collected_facts = None)
    # Third test with capsh == None
    system_capabilities_fact_collector.collect(module = None, collected_facts = None)

# Generated at 2022-06-24 23:32:04.083420
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert {'system_capabilities_enforced': 'NA', 'system_capabilities': []} == system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:12.302570
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # set up module
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value="/bin")
    module.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    
    actual_result = system_capabilities_fact_collector_0.collect(module)
    actual_result_system_capabilities = actual_result['system_capabilities']
    actual_result_system_capabilities_enforced = actual_result['system_capabilities_enforced']
    expected_result_system_capabilities = []
    expected_result_system_capabilities_enforced = 'False'

    assert actual_result_system_capabilities == expected_result

# Generated at 2022-06-24 23:32:21.742660
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: return_value and side_effect only needed for mocking 'run_command' -akl
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    # NOTE: This manually coded dictionary mimics the dictionary returned by a mocked
    # 'run_command' method.  It is a list of dictionaries, which is what 'run_command'
    # returns when it has been 'mocked' or stubbed using the 'mock' module.

# Generated at 2022-06-24 23:32:28.205354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test if when capsh isn't installed and if the correct fact
    # is returned
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module_1 = MagicMock()
    module_1.get_bin_path.return_value = None
    collected_facts_1 = None
    assert not system_capabilities_fact_collector_1.collect(module_1,
                                                            collected_facts_1)


# Generated at 2022-06-24 23:32:30.108282
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:40.374344
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    module = MagicMock()
    rc = MagicMock()
    out = MagicMock()
    err = MagicMock()
    module.run_command.return_value = (0, "Current: = cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+ep", "error_test")

# Generated at 2022-06-24 23:32:42.391485
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:32:52.354659
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    class MockModule:
        def get_bin_path(self, path):
            return '/bin/capsh'

# Generated at 2022-06-24 23:33:01.194034
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}


# Generated at 2022-06-24 23:33:04.019502
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Run unit test for method collect of class SystemCapabilitiesFactCollector
    print('Testing method collect of class SystemCapabilitiesFactCollector')
    fc = SystemCapabilitiesFactCollector()
    fc.collect()



# Generated at 2022-06-24 23:33:07.473620
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    assert(system_capabilities_fact_collector_0 is not None)

    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:11.007497
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_var = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_var, SystemCapabilitiesFactCollector)
    # assert isinstance(system_capabilities_fact_collector_var.collect(), dict)


# Generated at 2022-06-24 23:33:14.024164
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:33:23.454817
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #NOTE: these tests are not accurate to what actual system_capabilities return
    test_cases = [
        (
            {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_net_raw', 'cap_chown']},
            {'system_capabilities': 'cap_net_raw, cap_chown'}
        ),
        (
            {'system_capabilities_enforced': 'False', 'system_capabilities': ['cap_net_raw', 'cap_chown']},
            {'system_capabilities': 'cap_net_raw, cap_chown'}
        )
    ]
    #NOTE: arg parser needed to test run_command
    #with mock.patch.object(SystemCapabilitiesFactCollector, 'run_command') as mock_run_command:
        #for

# Generated at 2022-06-24 23:33:30.288104
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
# Test 'collected_facts' == None
    collected_facts_1 = None
# Test 'module' == None
    module_1 = None
    system_capabilities_fact_collector_1.collect(module_1, collected_facts_1)

# Generated at 2022-06-24 23:33:33.085700
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # test_case_0
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_0.collect()
    assert result == {}

# Generated at 2022-06-24 23:33:34.956401
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_collect = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_collect.collect()

# Generated at 2022-06-24 23:33:38.866128
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_0.collect()
    assert result


# Generated at 2022-06-24 23:33:46.441692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector_1.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-24 23:33:57.125625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    ansible_module_mock_0 = MockAnsibleModule()
    ansible_module_mock_1 = MockAnsibleModule()
    ansible_module_mock_2 = MockAnsibleModule()
    ansible_module_mock_1.run_command = Mock(return_value=(0, "Current: =ep", ""))
    ansible_module_mock_1.get_bin_path = Mock(return_value='/bin/capsh')
    ansible_module_mock_2.run_command = Mock(return_value=(0, "Current: =ep cap_setpcap,cap_net_raw+eip", ""))
    ansible_module_mock_2.get_bin_path

# Generated at 2022-06-24 23:34:07.175851
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: _module is a mock of a ansible ANSIBLE_MODULE_UTILS object
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    _module = mock.Mock()

    # NOTE: override class variable _fact_ids to enable test of the collect method
    system_capabilities_fact_collector_0._fact_ids = {'system_capabilities'}
    system_capabilities_fact_collector_0._module = _module
    system_capabilities_fact_collector_0._module.get_bin_path.return_value = "/usr/bin/capsh"

# Generated at 2022-06-24 23:34:12.439104
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module = object
    collected_facts = dict()
    system_capabilities_fact_collector_1.collect(module, collected_facts)

if __name__ == "__main__":
    test_case_0()
    # test_case_1()

# Generated at 2022-06-24 23:34:17.639672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    t_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert t_SystemCapabilitiesFactCollector.collect() == {}

# Generated at 2022-06-24 23:34:20.612960
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    facts_dict = dict()
    assert system_capabilities_fact_collector_1.collect(facts_dict) == {}


# Generated at 2022-06-24 23:34:29.462747
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Create instance of system_capabilities_fact_collector_0
    # with required arguments.
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    print('check if object is an instance of expected class')
    assert isinstance(system_capabilities_fact_collector_0, SystemCapabilitiesFactCollector)
    # NOTE: get method 'collect' of class SystemCapabilitiesFactCollector
    # and store result in 'collect_0'
    collect_0 = system_capabilities_fact_collector_0.collect()
    # NOTE: check if 'collect_0' is not None
    assert collect_0 is not None

# Generated at 2022-06-24 23:34:33.652849
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {}


# Generated at 2022-06-24 23:34:35.884423
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    assert system_capabilities_fact_collector_0.collect() == dict()
    print('test case 0 collected')



# Generated at 2022-06-24 23:34:43.640525
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_caps = []
    system_capabilities_enforced = 'NA'
    mock_module = FakeModule()
    mock_module.run_command = Mock(return_value=('0', "Current: =ep", "Test System Capabilities"))
    system_caps = system_capabilities_fact_collector_0.collect(mock_module)
    assert (system_caps['system_capabilities_enforced'] == 'False')
    assert (system_caps['system_capabilities'] == [])


# Generated at 2022-06-24 23:35:01.429343
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


#
# unit test execution
#
if __name__ == '__main__':
    for test_case in [
        test_SystemCapabilitiesFactCollector_collect,
        test_case_0
    ]:
        try:
            test_case()
            print(test_case.__name__ + ": success")
        except:
            print(test_case.__name__ + ": unit test failure")
            raise

# Generated at 2022-06-24 23:35:12.215876
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    fail_mock = Mock()
    fail_mock.get_bin_path = Mock(return_value=False)
    pass_mock = Mock()
    pass_mock.run_command = Mock(return_value=(0, 'Current: =ep\n', ''))
    pass_mock.get_bin_path = Mock(return_value='/usr/bin/capsh')
    system_capabilities_fact_collector.collect(fail_mock) == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    system_capabilities_fact_collector.collect(pass_mock) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-24 23:35:13.589210
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()



# Generated at 2022-06-24 23:35:16.927441
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    result_facts_dict = fact_collector.collect()
    assert result_facts_dict.get('system_capabilities_enforced') == 'NA'
    assert result_facts_dict.get('system_capabilities') == []

# Generated at 2022-06-24 23:35:22.883215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}
    # NOTE: involves mocking/external dependencies
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}
    # NOTE: involves mocking/external dependencies
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}

# Generated at 2022-06-24 23:35:27.460862
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:35:29.965216
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module = 'mocked_module'
    system_capabilities_fact_collector_0.collect(module)


# Generated at 2022-06-24 23:35:30.439996
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-24 23:35:32.280857
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:33.050595
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()



# Generated at 2022-06-24 23:35:49.173386
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -11414
    var_0 = system_capabilities_fact_collector_0.collect(int_0)


# Generated at 2022-06-24 23:35:49.683341
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True == True

# Generated at 2022-06-24 23:35:52.683615
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)


# Generated at 2022-06-24 23:35:54.527676
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)


# Generated at 2022-06-24 23:35:58.577469
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("%s: calling %s" % (__file__,
                              'test_SystemCapabilitiesFactCollector_collect'))
    # This is where the test would normally go to verify the output
    # of collect, however the results are system dependent and so
    # it can not be verified.
    # system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # result = system_capabilities_fact_collector.collect(module)
    # assert result == expected

# Generated at 2022-06-24 23:36:02.428938
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)


# Generated at 2022-06-24 23:36:06.066975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:36:09.264308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}


# Generated at 2022-06-24 23:36:17.262423
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    var_1 = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    assert var_0 == var_1


# Generated at 2022-06-24 23:36:25.681674
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}
    int_0 = -1
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}
    int_0 = 0
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}
    int_0 = 1
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}


# Generated at 2022-06-24 23:37:00.237739
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    var_1 = system_capabilities_fact_collector_0.get_name()


# Generated at 2022-06-24 23:37:02.724540
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    int_0 = -3505
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:37:07.314497
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)

# Generated at 2022-06-24 23:37:13.342816
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    #Setup an instance
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    #Setup input variable
    int_0 = -3505

    #Execute the collect method
    var_0 = system_capabilities_fact_collector_0.collect(int_0)

    #Verify the collected facts are non-empty
    assert var_0

# Generated at 2022-06-24 23:37:17.343373
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize args
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module = None
    # Invoke method
    ret_val_1 = system_capabilities_fact_collector_1.collect(
        module)
    # Assert the return value
    assert attr_val_0 == ret_val_1

# Generated at 2022-06-24 23:37:20.526617
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collectors = [
        SystemCapabilitiesFactCollector()
    ]
    for collector in collectors:
        pass



# Generated at 2022-06-24 23:37:26.199289
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)



# Generated at 2022-06-24 23:37:34.632934
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = 8454
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:37:36.682157
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)


# Generated at 2022-06-24 23:37:45.931811
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock = AnsibleModuleMock()
    mock.get_bin_path = MagicMock()
    mock.get_bin_path.return_value = '/path/to/capsh'
    mock.run_command = MagicMock()
    mock.run_command.return_value = (0, 'Current: = cap_sys_admin\nBounding set = cap_sys_admin\nSecurebits: 00/0x0/1\'b0 secure-noroot, secure-no-setuid-fixup secure-keep-caps\n', '')

    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_1.collect(mock)
    assert(var_0.get('system_capabilities_enforced') == 'False')
   

# Generated at 2022-06-24 23:38:56.797908
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = 5362
    int_1 = -1225
    int_2 = 1485
    dict_0 = system_capabilities_fact_collector_0.collect(int_0)
    dict_1 = system_capabilities_fact_collector_0.collect(int_1)
    dict_2 = system_capabilities_fact_collector_0.collect(int_2)



# Generated at 2022-06-24 23:39:01.945901
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert set(['system_capabilities_enforced', 'system_capabilities']) == system_capabilities_fact_collector_0.fact_ids


# Generated at 2022-06-24 23:39:07.569174
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:39:16.350906
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    int_0 = int(0)
    var_1 = system_capabilities_fact_collector_1.collect(int_0)
    assert_equal(var_1, {'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap'], 'system_capabilities_enforced': 'True'})

# Generated at 2022-06-24 23:39:20.322602
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    var_1 = system_capabilities_fact_collector_1.collect(int_0)


# Generated at 2022-06-24 23:39:22.142262
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)

# Generated at 2022-06-24 23:39:27.379008
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}


# Generated at 2022-06-24 23:39:29.383607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)

# Generated at 2022-06-24 23:39:32.951253
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    int_0 = -3505
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(int_0)
    assert var_0 == {}


# Generated at 2022-06-24 23:39:34.964630
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)

# Generated at 2022-06-24 23:41:42.499902
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
        int_0 = -3505
        var_0 = system_capabilities_fact_collector_1.collect(int_0)
    except Exception as exc:
        assert False

# Generated at 2022-06-24 23:41:48.563163
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    int_0 = -3505
    var_0 = system_capabilities_fact_collector_0.collect(int_0)

    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
