

# Generated at 2022-06-24 23:32:00.343088
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:32:04.610844
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # NOTE: add module stub for test -akl
    # assert_equal(system_capabilities_fact_collector_1.collect(), {})


# Generated at 2022-06-24 23:32:07.886351
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case = SystemCapabilitiesFactCollector()
    # NOTE: Implement unit tests -akl

# Generated at 2022-06-24 23:32:12.258139
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    collected_facts = {}
    result = system_capabilities_fact_collector_1.collect(module=None, collected_facts=collected_facts)
    assert result == {}


# Generated at 2022-06-24 23:32:21.743193
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Test case 1:
    module = Mock()
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module.get_bin_path.return_value = "/bin/capsh"
    module.run_command.return_value = 0, "Current: =ep", ""
    collected_facts = {}
    result_dict = {}
    result_dict['system_capabilities_enforced'] = 'False'
    result_dict['system_capabilities'] = []

    assert system_capabilities_fact_collector_1.collect(module, collected_facts) == result_dict

    # Test case 2:
    module = Mock()
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:32:32.128752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module_1 = MockModule()
    collected_facts_1 = {}
    system_capabilities_fact_collector_1.collect(module_1, collected_facts_1)
    # TODO replace assert with declared expected value for following assertions

# Generated at 2022-06-24 23:32:33.386409
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:32:42.257071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = Mock()
    setattr(module_0, 'run_command', Mock(return_value=('', '', '')))
    setattr(module_0, 'get_bin_path', Mock(return_value='/usr/bin/capsh'))
    collected_facts_0 = dict(ansible_facts=dict())
    dict_keys = ('ansible_facts')
    dict_values = ({'system_capabilities_enforced': 'NA', 'system_capabilities': []})
    collected_facts_1 = dict(ansible_facts=dict())
    dict_keys = ('ansible_facts')
    dict_values = ({'system_capabilities_enforced': 'NA', 'system_capabilities': []})
   

# Generated at 2022-06-24 23:32:52.357032
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_collect_1 = SystemCapabilitiesFactCollector()
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/usr/bin/capsh'

# Generated at 2022-06-24 23:32:54.264324
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()



# Generated at 2022-06-24 23:33:02.794828
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:08.104180
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    ret = system_capabilities_fact_collector_0.collect()
    assert ret['system_capabilities']==None, str(ret['system_capabilities'])
    assert ret['system_capabilities_enforced']==None, str(ret['system_capabilities_enforced'])


test_case_0()

# Generated at 2022-06-24 23:33:12.016350
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    results = system_capabilities_fact_collector.collect()
    assert type(results) == dict
    assert 'system_capabilities_enforced' in results
    assert type(results['system_capabilities_enforced']) == str
    assert 'system_capabilities' in results
    assert type(results['system_capabilities']) == list
    assert len(results['system_capabilities']) > 0

# Generated at 2022-06-24 23:33:14.595093
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Test collect')
    taken = SystemCapabilitiesFactCollector.collect()
    checks = True
    #TODO: put a correct test, the first check is just to test that the method returns something
    if isinstance(taken, SystemCapabilitiesFactCollector):
        checks = True
    print(checks)

# Generated at 2022-06-24 23:33:18.639050
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    result = SystemCapabilitiesFactCollector().collect()
    assert result is not None
    assert type(result) is dict

# Generated at 2022-06-24 23:33:20.859544
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:33:32.166408
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    In this test we will use a ansible MockModule class to simulate the ansible run
    So we can check the results of the collect method
    '''
    # For this unit test we need the MockModule class
    from ansible.module_utils.facts.collector import MockModule
    # Create a new mock object
    mock_module = MockModule()
    # The mock_module requires we set a path fot its get_bin_path
    mock_module.bin_path = '/bin:/sbin:/usr/bin:/usr/sbin:/home/user/bin'
    # Create our SystemCapabilitiesFactCollector object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # Run our collect method
    facts = system_capabilities_

# Generated at 2022-06-24 23:33:38.540259
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test if 'SystemCapabilitiesFactCollector.collect()' returns correct dict
    """
    # AnsibleModule instance on which we will run 'run_command' (i.e.
    # mock_ansible_module_instance.run_command). We will patch this instance
    # in fixture 'ansible_module'.
    ansible_module = None
    # Fixture 'ansible_module'
    def _ansible_module():
        """Mock 'ansible_module' fixture
        """
        global ansible_module
        if ansible_module is None:
            import ansible.module_utils.facts.system.caps
            ansible_module = ansible.module_utils.facts.system.caps.AnsibleModule(
                argument_spec={},
            )

# Generated at 2022-06-24 23:33:42.005250
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-24 23:33:43.787001
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:58.198872
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test method collect of SystemCapabilitiesFactCollector.
    '''
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert False # TODO: implement your test here

    # mock_BaseFactCollector = mocker.patch('__main__.BaseFactCollector')
    # mock_BaseFactCollector.return_value = mocker.MagicMock()
    # mock_BaseFactCollector.return_value.collect.return_value = {}
    # mock_module = mocker.MagicMock()
    # mock_collected_facts = {}
    # system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # actual = system_capabilities_fact_collector_0.collect(mock_module, mock_collected_facts)
   

# Generated at 2022-06-24 23:34:05.305600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Return some facts about system capabilies.
    '''
    # NOTE: this test only covers unit-testing of the code in the test
    # method.  Any execution of the collect() method will fail without a
    # mock.
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # NOTE: mock the module in the dict, and the module.run_command()
    # call, and assert the final result is as expected
    module = {}

    assert system_capabilities_fact_collector.collect() == {}

# Generated at 2022-06-24 23:34:11.441661
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    test_module_0 = None
    test_collected_facts_0 = None
    test_returned_value_0 = system_capabilities_fact_collector_1.collect(test_module_0, test_collected_facts_0)
    assert test_returned_value_0 is None


# Generated at 2022-06-24 23:34:21.473670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # check that class can run collect() method
    assert system_capabilities_fact_collector_0.collect()
    assert system_capabilities_fact_collector_0.collect(collected_facts={}) == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    assert system_capabilities_fact_collector_0.collect(collected_facts={'local': {}}) == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:34:25.109153
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    result_system_capabilities_fact_collector_0 = {}
    assert result_system_capabilities_fact_collector_0 == system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:33.417621
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Test for if capsh is not installed
    if system_capabilities_fact_collector_1.get_bin_path("capsh") is None:
        assert system_capabilities_fact_collector_1.collect() == {}
    # Test for if capsh is installed
    else:
        assert system_capabilities_fact_collector_1.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-24 23:34:33.899866
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True == True

# Generated at 2022-06-24 23:34:36.259226
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize the class
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Call the method
    actual = system_capabilities_fact_collector_0.collect()

    assert actual == None


if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:34:39.020429
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this depends on the facts plugin being available -akl
    pass

# Generated at 2022-06-24 23:34:42.253618
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

if __name__ == '__main__':
    import pytest

    pytest.main(args=['.'])

# Generated at 2022-06-24 23:34:50.972728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_value = system_capabilities_fact_collector.collect()
    assert var_value == {}


# Generated at 2022-06-24 23:34:54.700586
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    var_2 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:35:01.691253
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    # Test empty call
    var_2 = system_capabilities_fact_collector_1.collect()
    # Test empty call
    var_3 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)
    # Test empty call
    var_4 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

# Test class constructor

# Generated at 2022-06-24 23:35:06.394301
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:35:09.844836
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:35:14.241226
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == var_1
    assert len(var_0) == 1
    assert len(var_0.get("system_capabilities_enforced")) == 2
    assert len(var_0.get("system_capabilities")) == 0
    assert var_0.get("system_capabilities_enforced") == "NA"
    assert var_0.get("system_capabilities") == []


# Generated at 2022-06-24 23:35:18.075488
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert var_0 == var_1


# Generated at 2022-06-24 23:35:21.171440
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:22.492473
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:22.994714
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:35:40.448672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Test needs to be implemented
    # Test with>var_1 = SystemCapabilitiesFactCollector().collect(system_capabilities_fact_collector_0)
    pass


# Generated at 2022-06-24 23:35:41.921077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:48.228594
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:35:50.157086
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:52.575323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:54.673311
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()
    var_1 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)

# Generated at 2022-06-24 23:35:56.144760
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_2 = SystemCapabilitiesFactCollector()
    var_2.collect()


# Generated at 2022-06-24 23:36:00.117483
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:36:04.888603
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # initialize input arguments
    # var_class_0 is a SystemCapabilitiesFactCollector
    var_class_0 = SystemCapabilitiesFactCollector()

    # initialize instance method variables
    # var_return_0 is a Python dictionary
    var_return_0 = None

    var_return_0 = var_class_0.collect()

    return var_return_0

# Generated at 2022-06-24 23:36:09.418107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:36:40.465623
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True == True


# Generated at 2022-06-24 23:36:42.853959
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fixture_file = open('/home/fixturess/ansible_facts.fact')
    fixture_content = fixture_file.read()
    # TODO: implement more assertions
    assert fixture_content != None


# Generated at 2022-06-24 23:36:46.272258
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

test_case_0()

# Generated at 2022-06-24 23:36:49.422333
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = {}
    system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0, collected_facts_0)
    var_1 = collected_facts_0.get('caps')
    assert var_1 is not None


# Generated at 2022-06-24 23:36:53.307062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock the module
    module = AnsibleModule(
        argument_spec=dict()
    )

    # TODO: use a deeper mock here
    module.run_command = MagicMock(
        return_value = (0, 'Current:=ep', '')
    )

    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect(module)

    assert result is not None
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Generated at 2022-06-24 23:36:56.735302
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # run when capsh_path is not available
    var_0 = system_capabilities_fact_collector_0.collect(None, None)
    assert var_0 == {}



# Generated at 2022-06-24 23:37:00.413259
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:37:06.584690
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:37:08.278379
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:37:12.348959
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert not system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:38:17.686227
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    def test_collect(module, collected_facts):
        return {'test': 'test'}
    system_capabilities_fact_collector_0.collect = test_collect
    var_2 = system_capabilities_fact_collector_0.collect()
    assert var_2 == {'test': 'test'}


# Generated at 2022-06-24 23:38:21.631895
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:38:22.732163
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert callable(SystemCapabilitiesFactCollector.collect)


# Generated at 2022-06-24 23:38:26.828199
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
#    assert var_0 == {'system_capabilities': 'NA', 'system_capabilities_enforced': 'NA'}
    print(var_0)


test_case_0()

# Generated at 2022-06-24 23:38:32.804370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector_1, SystemCapabilitiesFactCollector)
    assert isinstance(system_capabilities_fact_collector_1, BaseFactCollector)
    assert isinstance(system_capabilities_fact_collector_1, FactsCollector)
    system_capabilities_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:35.636770
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:38:42.005177
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_instance_0 = SystemCapabilitiesFactCollector()
    str_0 = system_capabilities_fact_collector_instance_0.collect()
    assert str_0 == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}



# Generated at 2022-06-24 23:38:50.847795
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test setup
    var_0 = SystemCapabilitiesFactCollector()


# Generated at 2022-06-24 23:38:57.215913
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup test case data
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    try:
        # Assert the return value of method collect of class SystemCapabilitiesFactCollector is None.
        assert system_capabilities_fact_collector_1.collect() is None
        # Assert the return value of method collect of class SystemCapabilitiesFactCollector is None.
        assert system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1) is None
    finally:
        # Clean up
        pass

# Generated at 2022-06-24 23:39:01.566002
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:41:26.511406
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:41:31.525205
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()
    assert type(var_1) is dict


# Generated at 2022-06-24 23:41:35.802519
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:41:39.725969
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:41:42.410433
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:41:48.336741
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
