

# Generated at 2022-06-24 23:32:04.269395
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create an instance of the class we are testing
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(system_capabilities_fact_collector, SystemCapabilitiesFactCollector)

    # unittest.mock provides a class called Mock which you will use to imitate
    # real objects in your codebase.
    # https://docs.python.org/3/library/unittest.mock.html#unittest.mock.Mock
    # https://docs.python.org/3/library/unittest.mock.html#quick-guide-to-mocking

    # create a mock object of class ansible.module_utils.facts.collector.BaseFactCollector
    mock_base_fact_collector = mock.create_autospec(BaseFactCollector)

   

# Generated at 2022-06-24 23:32:06.199628
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0_collect = system_capabilities_fact_collector_0.collect(module = "fake_module", collected_facts = "fake_collected_facts")

# Generated at 2022-06-24 23:32:11.000472
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Unit test using 'capsh' to gather system capabilities
    class MockModule(object):

        def __init__(self):
            self.run_command_rc = 0

# Generated at 2022-06-24 23:32:19.818650
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collect_facts

    # Prepare test-case for ansible.module_utils.facts.collector.BaseFactCollector.collect

# Generated at 2022-06-24 23:32:23.710183
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}
    assert system_capabilities_fact_collector_0.collect() is not None
    assert system_capabilities_fact_collector_0.collect() == {}



# Generated at 2022-06-24 23:32:25.957649
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-24 23:32:29.646243
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    collected_facts_dict_1 = system_capabilities_fact_collector_1.collect()
    assert collected_facts_dict_1 == {}

# Generated at 2022-06-24 23:32:40.342773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    collected_facts = {'capsh': capsh}
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=0)
    module.get_bin_path = Mock(return_value="/bin/capsh")
    result = system_capabilities_fact_collector_1.collect(module=module, collected_facts=collected_facts)
    assert result['system_capabilities_enforced'] == "True"

# Generated at 2022-06-24 23:32:45.379316
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test collect() of SystemCapabilitiesFactCollector class.
    """
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    assert type(system_capabilities_fact_collector_1.collect()) is dict
    assert system_capabilities_fact_collector_1.collect() == {
        'system_capabilities_enforced': 'False',
        'system_capabilities': [
            'cap_kill',
            'cap_net_bind_service'
        ]
    }


# Generated at 2022-06-24 23:32:48.801376
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    results = system_capabilities_fact_collector_0.collect()
    assert results == {}


# Generated at 2022-06-24 23:32:52.959973
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    __result_0 = {'system_capabilities_enforced': 'NA'}
    return __result_0

# Generated at 2022-06-24 23:32:57.001582
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup test case data
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Invoke method
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)



# Generated at 2022-06-24 23:33:02.265017
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)


# Generated at 2022-06-24 23:33:07.545907
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = b'\x00\x00\x00\x00'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)
    


# Generated at 2022-06-24 23:33:15.045548
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:33:19.848294
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)

# Generated at 2022-06-24 23:33:31.031692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)
    assert var_0 == dict_0
    dict_1 = dict_0
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect(dict_1)
    assert var_2 == dict_1
    dict_2 = dict_0
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()

# Generated at 2022-06-24 23:33:34.463427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    var_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect(dict_0)


# Generated at 2022-06-24 23:33:46.107165
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    dict_0 = {}
    dict_0 = {'capabilities_enforced': 'NA', 'capabilities': None}
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)
    system_capabilities_fact_collector_0.collect(dict_0)
    dict_0 = {}
    dict_0 = {'capabilities_enforced': None, 'capabilities': '=ep'}
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)
    system_capabilities_fact_collector_0.collect(dict_0)

# Generated at 2022-06-24 23:33:57.095762
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:34:08.463606
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Pass an empty dictionary to collect, get an empty dictionary back
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

    # Create a 'None' value and pass it to collect, ensure we get a dictionary back
    # with system_capabilities_enforced & system_capabilities set to 'NA'
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect(None) == {'system_capabilities': 'NA',
                                                                  'system_capabilities_enforced': 'NA'}



# Generated at 2022-06-24 23:34:13.194147
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)

# Generated at 2022-06-24 23:34:17.628942
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)


# Generated at 2022-06-24 23:34:21.908353
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialization of var
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Invocation of method collect
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)




# Generated at 2022-06-24 23:34:23.407101
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: fix this test
    assert False # TODO: fix this test



# Generated at 2022-06-24 23:34:29.562217
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    dict_0 = {'current': '=ep', 'securebits': '0x0/0x0/0x0', 'flags': '0x0'}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)
    var_1 = system_capabilities_fact_collector_0.collect(dict_0)
    var_2 = system_capabilities_fact_collector_0.collect(dict_0)
    var_3 = system_capabilities_fact_collector_0.collect(dict_0)
    var_4 = system_capabilities_fact_collector_0.collect(dict_0)
    var_5 = system_capabilities_fact_collector_0.collect

# Generated at 2022-06-24 23:34:32.374701
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: some code goes here!
    # no output code
    assert True

# Generated at 2022-06-24 23:34:35.822278
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(dict_0)


# Generated at 2022-06-24 23:34:41.325833
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    dict_0 = {'system_capabilities_enforced': '', 'system_capabilities': None}
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == dict_0

# Generated at 2022-06-24 23:34:42.537055
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 23:35:01.118071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = "/usr/bin/capsh"
    out = "Current: =ep"
    err = ""
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    assert(var_0 != var_1)

# Generated at 2022-06-24 23:35:02.920618
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()
    var_1 = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)

# Generated at 2022-06-24 23:35:08.557754
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:35:13.131810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("START")
    print(SystemCapabilitiesFactCollector.__dict__)
    var_0 = SystemCapabilitiesFactCollector()
    print(var_0.__dict__)
    var_1 = var_0.collect()
    print(var_1['system_capabilities_enforced'])
    print(var_1['system_capabilities'])
    var_2 = var_0.collect(var_0)
    print(var_2['system_capabilities_enforced'])
    print(var_2['system_capabilities'])
    print("END")


# Generated at 2022-06-24 23:35:16.794646
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:35:19.501501
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:35:27.665991
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = MockModule()
    module_0.run_command = Mock(return_value=('', '', ''))
    module_0.get_bin_path = Mock(return_value='/bin/capsh')

    var_0 = system_capabilities_fact_collector_0.collect(module_0)
    assert var_0 == {u'system_capabilities_enforced': u'NA', u'system_capabilities': []}

    #NOTE:  test case due to not having perm to run capsh on my system -akl
    module_1 = MockModule()

# Generated at 2022-06-24 23:35:32.635639
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: auto-generated test code
    # NOTE: auto-generated test code
    # NOTE: auto-generated test code
    pass


# Generated at 2022-06-24 23:35:35.866747
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    var_2 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:35:41.225373
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()
    var_3 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)

# Generated at 2022-06-24 23:36:07.710746
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Prepare 'SystemCapabilitiesFactCollector' instance
    # Mock arguments
    options = {}

    # Set up context
    interface = SystemCapabilitiesFactCollector()

    # Invoke method
    response = interface.collect(**options)

    assert isinstance(response, dict)

# Generated at 2022-06-24 23:36:11.055878
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_5 = SystemCapabilitiesFactCollector()
    var_5.collect()
    var_5.collect(system_capabilities_fact_collector_0)
    var_5.name
    var_5._fact_ids


# Generated at 2022-06-24 23:36:16.595670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)

# Generated at 2022-06-24 23:36:20.020872
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect()
    var_3 = system_capabilities_fact_collector_2.collect(system_capabilities_fact_collector_2)

if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:36:23.248308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert True


# Generated at 2022-06-24 23:36:25.303790
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:36:26.933112
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:30.601054
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:34.245571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0.get('system_capabilities_enforced') == 'NA'
    assert var_0.get('system_capabilities') == []


# Generated at 2022-06-24 23:36:37.306536
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_1.collect()
    var_3 = system_capabilities_fact_collector_1.collect(system_capabilities_fact_collector_1)


# Generated at 2022-06-24 23:37:34.187610
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = 'file_0'
    var_3 = dict()
    var_4 = var_1.collect(var_2, var_3)


# Generated at 2022-06-24 23:37:35.829133
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:39.121266
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_0.collect()
    var_3 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    print(repr(var_2))
    print(repr(var_3))


if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:37:43.214041
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fixture_return_value_0 = {}
    var_0 = SystemCapabilitiesFactCollector()
    var_1 = SystemCapabilitiesFactCollector()
    var_2 = SystemCapabilitiesFactCollector()
    var_3 = fixture_return_value_0
    fixture_call_method_0 = fixture_return_value_0
    fixture_call_method_1 = fixture_return_value_0
    fixture_call_method_2 = fixture_return_value_0
    fixture_call_method_3 = fixture_return_value_0
    fixture_call_method_4 = fixture_return_value_0
    fixture_call_method_5 = fixture_return_value_0
    fixture_call_method_6 = fixture_return_value_0
    var_0.get_bin_path = fixture_call_method_

# Generated at 2022-06-24 23:37:47.048957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:37:48.976438
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = dict()
    return_value_0 = system_capabilities_fact_collector_0.collect(collected_facts_0)
    assert return_value_0 == {}



# Generated at 2022-06-24 23:37:55.644816
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(AnsibleModule(parms))
    assert var_0 == 'passed assert'
    # NOTE: assert return value, e.g. 'assert var_0 == ...'
    #assert var_0 == ['']


# Generated at 2022-06-24 23:38:01.169895
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Test get_fact_ids of class SystemCapabilitiesFactCollector')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)
    print('Test get_fact_ids of class SystemCapabilitiesFactCollector')


# Generated at 2022-06-24 23:38:10.963716
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect()
    var_3 = system_capabilities_fact_collector_2.collect(system_capabilities_fact_collector_2)
    system_capabilities_fact_collector_5 = SystemCapabilitiesFactCollector()
    var_5 = system_capabilities_fact_collector_5.collect()
    var_6 = system_capabilities_fact_collector_5.collect(system_capabilities_fact_collector_5)
    system_capabilities_fact_collector_8 = SystemCapabilitiesFactCollector()
    var_8 = system_capabilities_fact_collector_8.collect()
    var_9 = system_capabilities_fact_

# Generated at 2022-06-24 23:38:16.473303
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:40:32.833291
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # test_case_0
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:40:38.793365
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert 'system_capabilities_enforced' in system_capabilities_fact_collector.collect()
    assert 'system_capabilities' in system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:40:41.680386
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:43.008560
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert test_case_0() == True


# Generated at 2022-06-24 23:40:46.821546
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:40:53.000448
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Simple test to ensure method collect of class SystemCapabilitiesFactCollector
    # returns a collection of system capabilities
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect(system_capabilities_fact_collector)
    assert isinstance(result, dict)
    assert isinstance(result['system_capabilities'], list)
    assert result['system_capabilities_enforced'] in ('True', 'False')

# Generated at 2022-06-24 23:40:59.873153
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Testing: SystemCapabilitiesFactCollector.collect()')
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:41:01.881705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:41:07.054589
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)


# Generated at 2022-06-24 23:41:12.855723
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    var_1 = system_capabilities_fact_collector_0.collect(system_capabilities_fact_collector_0)