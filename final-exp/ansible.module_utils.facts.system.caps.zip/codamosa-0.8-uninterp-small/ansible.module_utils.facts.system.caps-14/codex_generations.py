

# Generated at 2022-06-24 23:32:00.316766
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    import ansible.module_utils.facts.system.caps

    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    system_capabilities_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_collector_1 = SystemCapabilitiesFactCollector()

    if not isinstance(system_capabilities_collector_0.collect(), dict):
        raise AssertionError()

    system_capabilities_collector_1.collect()


# Generated at 2022-06-24 23:32:06.933102
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    result_1_1 = {}

    # Determine what to mock
    mock_module_1 = None
    mock_collected_facts_1 = None

    # Call method collect of class SystemCapabilitiesFactCollector on mock object system_capabilities_fact_collector_1
    result_1_1 = system_capabilities_fact_collector_1.collect(module=mock_module_1, collected_facts=mock_collected_facts_1)
    assert result_1_1 == {}


# Generated at 2022-06-24 23:32:08.219540
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:32:14.600541
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts = {'ansible_facts': {}, 'module': None, 'changed': False}
    result_expected = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    result_actual = system_capabilities_fact_collector_0.collect(collected_facts)
    assert result_actual == result_expected

# Generated at 2022-06-24 23:32:23.818091
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    print('\n')
    print('# Test case 0')
    print('\n')
    test_case_0()
    print('\n')
    print('# Test case 1')
    print('\n')
    print('\n')
    print('# Test case 2')
    print('\n')
    print('\n')
    print('# Test case 3')
    print('\n')
    print('\n')
    print('# Test case 4')
    print('\n')
    print('\n')
    print('# Test case 5')
    print('\n')
    print('\n')
    print('# Test case 6')
    print('\n')
    print('\n')

# Generated at 2022-06-24 23:32:29.645996
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module_1 = None
    collected_facts_1 = None
    actual_result_1 = system_capabilities_fact_collector_1.collect(module=module_1, collected_facts=collected_facts_1)
    expected_result_1 = {}
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-24 23:32:36.511592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    result = system_capabilities_fact_collector.collect({'run_command': lambda x, y, z: ('', '', '')})
    assert result == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}


# Generated at 2022-06-24 23:32:37.275454
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    assert 1 == 1


# Generated at 2022-06-24 23:32:39.648075
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    module = None
    collected_facts = None
    system_capabilities_fact_collector_1.collect(module, collected_facts)


# Generated at 2022-06-24 23:32:46.385235
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    collected_facts = {}
    collected_facts['ansible_local'] = {}
    collected_facts['ansible_local']['system_capabilities'] = []
    collected_facts['ansible_local']['system_capabilities'].append('=cap_fowner+ep')
    collected_facts['ansible_local']['system_capabilities'].append('=cap_dac_override+ep')
    collected_facts['ansible_local']['system_capabilities'].append('=cap_dac_read_search+ep')
    collected_facts['ansible_local']['system_capabilities'].append('=cap_setgid+ep')

# Generated at 2022-06-24 23:32:51.957488
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:32:55.456280
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Inits
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Invoke method
    var_0 = system_capabilities_fact_collector_0.collect()

    # Tests
    assert var_0 == {}
    # Test: attr=name
    assert system_capabilities_fact_collector_0.name == 'caps'

# Generated at 2022-06-24 23:32:59.733508
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    print(var_0)


test_case_0()

# Generated at 2022-06-24 23:33:06.217114
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    print(system_capabilities_fact_collector.collect())



# Generated at 2022-06-24 23:33:14.235324
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()
    assert var_0['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-24 23:33:16.486801
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: This will be tested after the implementation of the
    #       collect method.
    #       Test fails if method is not implemented, but will
    #       succeed if the method is implemented, but the
    #       implementation is wrong.
    test_case_0()

# Generated at 2022-06-24 23:33:27.004234
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:33:31.398777
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:33:38.142512
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 in [{}, {'system_capabilities_enforced': 'NA', 'system_capabilities': []}, {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}]


###
# Test Cases


# Generated at 2022-06-24 23:33:43.877816
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert "system_capabilities_enforced" in var_0
    assert "system_capabilities" in var_0

# Generated at 2022-06-24 23:33:54.965718
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    # needs module to obtain path to capsh binary
    system_capabilities_fact_collector_0.collect(module=None)
    # needs module to obtain path to capsh binary
    system_capabilities_fact_collector_0.collect(module=None, collected_facts=None)
    # needs module to obtain path to capsh binary
    system_capabilities_fact_collector_0.collect(module=None, collected_facts=None)



# Generated at 2022-06-24 23:34:00.647345
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    module_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(module_0)


# Generated at 2022-06-24 23:34:08.204371
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    
    # Invocation testing
    args = {'module': {'get_bin_path': {'return_value': 'foobar'}}, 'collected_facts': 'collected_facts'}
    kwargs = {'errors': 'surrogate_then_replace'}
    
    retval0 = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    retval1 = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    retval2 = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    
    # Mock calibration
    my_ansible_module = MockAnsibleModule(function_name='None', function_arguments=args)

# Generated at 2022-06-24 23:34:18.470315
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # What happens when no facts are passed in
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    # What happens when a module with no bin path is supplied
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    var_2 = system_capabilities_fact_collector_2.collect(collected_facts=var_1)
    # What happens when an module path is supplied
    system_capabilities_fact_collector_3 = SystemCapabilitiesFactCollector()
    var_3 = system_capabilities_fact_collector_3.collect(module='/usr/local/bin/capsh', collected_facts=var_1)


# Generated at 2022-06-24 23:34:19.234862
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # collect() method returns a dictionary of collected facts
    pass

# Generated at 2022-06-24 23:34:27.981319
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(
        argument_spec={}
    )
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'True'}
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'True'}
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'True'}
    assert var_1 == {'system_capabilities': [], 'system_capabilities_enforced': 'True'}

# Generated at 2022-06-24 23:34:34.984467
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    try:
        assert isinstance(system_capabilities_fact_collector_0.collect(), dict)
    except AssertionError as e:
        raise(e)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:34:39.991097
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert type(var_0) == dict

# Generated at 2022-06-24 23:34:42.457434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:45.588312
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect(module=None, collected_facts=None)
    assert var_0 == {}


# Generated at 2022-06-24 23:34:55.685218
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("Testing collect of SystemCapabilitiesFactCollector")
    import ansible.module_utils.facts.system.capabilities as test_file
    # Initialize test object
    system_capabilities_fact_collector_0 = test_file.SystemCapabilitiesFactCollector()

    # Testing if callable
    assert callable(system_capabilities_fact_collector_0.collect)


# Generated at 2022-06-24 23:34:57.236141
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert True

# Generated at 2022-06-24 23:34:59.771277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Create an instance of class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()

    # Invoke method collect of SystemCapabilitiesFactCollector.
    var_0 = system_capabilities_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-24 23:35:02.415596
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()

    var_0 = system_capabilities_fact_collector_1.collect()
    assert var_0['system_capabilities_enforced'] == 'NA'
    assert var_0['system_capabilities'] == []

# Generated at 2022-06-24 23:35:08.051370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    

# Generated at 2022-06-24 23:35:11.688186
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_2 = SystemCapabilitiesFactCollector()
    collected_facts_1 = dict()
    collected_facts_1['ansible_check_mode'] = False
    # TODO: mock this module and assert expected call to run_command is made
    var_2 = system_capabilities_fact_collector_2.collect(collected_facts=collected_facts_1)

# Generated at 2022-06-24 23:35:15.167710
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    arg_0 = None
    result = system_capabilities_fact_collector_0.collect(arg_0)


# Generated at 2022-06-24 23:35:17.453774
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    data_0 = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    assert data_0 == "", "The call SystemCapabilitiesFactCollector().collect() does not return expected results"

# Generated at 2022-06-24 23:35:20.763323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:26.306684
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_1.collect()
    assert var_0 is not None
    assert var_0 is not ''
    assert var_0 is not False


# Generated at 2022-06-24 23:35:42.008515
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    system_capabilities_fact_collector.collect()


# Generated at 2022-06-24 23:35:47.163567
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect() #THIS SHOULD NOT FAIL

# Generated at 2022-06-24 23:35:50.051172
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    collected_facts_0 = {}
    system_capabilities_collect_0 = system_capabilities_fact_collector_0.collect(collected_facts_0)

    assert system_capabilities_collect_0 == {}

# Generated at 2022-06-24 23:35:54.610600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

if __name__ == '__main__':
    test_case_0()
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-24 23:35:56.611268
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:58.988116
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()



# Generated at 2022-06-24 23:36:02.989064
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = None
    var_2 = system_capabilities_fact_collector_1.collect(var_1, var_1)
    print(str(var_2))


# Generated at 2022-06-24 23:36:07.816583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    assert 'system_capabilities_enforced' in var_0
    assert 'system_capabilities' in var_0



# Generated at 2022-06-24 23:36:09.864217
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:15.234732
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:36:50.963115
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()
    assert var_1.get('system_capabilities') == []


# Generated at 2022-06-24 23:37:01.636234
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-24 23:37:09.771257
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    find_bin_path_mock_0 = Mock(return_value='/usr/bin/capsh')
    with patch.object(system_capabilities_fact_collector_0, 'get_bin_path', find_bin_path_mock_0):
        run_command_mock_0 = Mock(return_value=('0', 'Current: =ep', '0'))
        with patch.object(system_capabilities_fact_collector_0, 'run_command', run_command_mock_0):
            var_0 = system_capabilities_fact_collector_0.collect()
            assert var_0 == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
            run_

# Generated at 2022-06-24 23:37:18.504311
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    module = ansible_module_mock()

    var_0 = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if var_0:
        var_1 = module.run_command([var_0, "--print"], errors='surrogate_then_replace')
        var_2 = []
        var_3 = 'NA'
        for line in var_1[1].splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    var_3 = 'False'
                else:
                    var_

# Generated at 2022-06-24 23:37:28.274366
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities = SystemCapabilitiesFactCollector()
    # enforcing capabilities

# Generated at 2022-06-24 23:37:34.312926
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:37:35.935152
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:37.978851
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_1 = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector_1.collect()


# Generated at 2022-06-24 23:37:42.793540
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:37:45.467769
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:03.163944
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:05.288199
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:39:09.080855
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    facts_dict = system_capabilities_fact_collector.collect()

    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict

# Generated at 2022-06-24 23:39:13.990303
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:16.127207
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:18.642934
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  # Input:/ Output: arg0:self
  try:
    var_1 = test_case_0()
    assert var_1 is None
  except:
    raise Exception("Method collect threw an exception!")


# Generated at 2022-06-24 23:39:21.430795
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:39:21.870588
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:39:26.081602
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    var_1 = system_capabilities_fact_collector.collect()

# Generated at 2022-06-24 23:39:28.291434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector_0 = SystemCapabilitiesFactCollector()
    var_0 = system_capabilities_fact_collector_0.collect()

    assert var_0 == {}