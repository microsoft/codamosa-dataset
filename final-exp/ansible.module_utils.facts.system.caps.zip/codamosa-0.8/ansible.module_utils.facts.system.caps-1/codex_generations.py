

# Generated at 2022-06-11 04:07:21.621094
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MockModule({'get_bin_path': lambda arg: arg})
    mock_run_command = Mock(return_value=(0, 'Current: =ep\nBounding set =ep', None))
    mock_module.run_command = mock_run_command
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(mock_module)
    assert result == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    assert mock_run_command.call_args_list == [call([
        '/usr/bin/capsh', '--print'], errors='surrogate_then_replace')]


# Generated at 2022-06-11 04:07:25.490075
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # NOTE: FactCollector is a singleton, so don't forget to del() after use
    fc = FactCollector()
    module = fc.get_module()
    fac = SystemCapabilitiesFactCollector()

    fac.collect(module)

# Generated at 2022-06-11 04:07:35.378021
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import shutil
    import os
    import stat
    import glob
    import unittest
    import sys
    from ansible.compat.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import JasonDict
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector

    if sys.version_info[0] >= 3:
        import unittest.mock as mock
    else:
        import mock

    test_dir = tempfile.mkdtemp()
    test_cmd = os.path.join(test_dir, 'capsh')
    test_fh = open(test_cmd, 'w')

# Generated at 2022-06-11 04:07:36.730776
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
   """
   SystemCapabilitiesFactCollector._collect
   """
   pass

# Generated at 2022-06-11 04:07:39.567939
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collectors['system_capabilities'] = SystemCapabilitiesFactCollector()
    # NOTE: create ModuleUtilBase mock
    # -> test a couple different scenarios
    return True

# Generated at 2022-06-11 04:07:48.457751
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule
    import json

    test_facts = Facts(dict(ansible_facts=dict(system_capabilities_enforced='False', system_capabilities=[])))
    module = AnsibleModule(argument_spec=dict())

    # NOTE: Fake capsh is a script that prints a static string -akl
    capsh_path = 'fake-capsh'
    # NOTE: Call collect() indirectly via populate() -akl
    test_collector = SystemCapabilitiesFactCollector(module=module)
    test_collector.populate(module=module, collected_facts=test_facts)


# Generated at 2022-06-11 04:07:58.162550
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}

    # fake ansible module object
    class Options(object):
        def __init__(self, value):
            self.value = value

        def __call__(self, *args, **kwargs):
            return self.value

    class Module(object):
        def __init__(self, value):
            self.value = value

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            if path == 'capsh':
                return '/bin/capsh'
            return None


# Generated at 2022-06-11 04:08:08.208457
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initialize test class
    SystemCapabilitiesFactCollector_obj = SystemCapabilitiesFactCollector()

    # prepare test data
    capsh_path = "test/path/to/bin/capsh"
    capsh_stdout = "Current: =ep\nBounding set =cap_chown,cap_dac_override\n"
    capsh_stderr = ""

    expected = {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }

    # initialize test module
    module_obj = InitializeTestModule(capsh_stdout, capsh_stderr)

    # run collect method of SystemCapabilitiesFactCollector class
    actual = SystemCapabilitiesFactCollector_obj.collect(module_obj, collected_facts=None)

    # validate result


# Generated at 2022-06-11 04:08:13.470434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("")
    print("Testing SystemCapabilitiesFactCollector_collect()")
    # NOTE: this is pretty much how facts.d/init.py works, isn't it? -akl
    class FakeCollector:
        def __init__(self, module=None, collected_facts=None, *args, **kwargs):
            self.collected_facts = collected_facts
            self.module = module

        def collect(self, *args, **kwargs):
            return self.collected_facts

    # NOTE: for Python2.6 compat, use sys.modules to edit the imported module
    # in place -akl
    import sys
    import importlib
    facts_d_module = sys.modules['ansible.module_utils.facts.factsd']
    facts_d_module.SystemCapabilitiesFactCollector = FakeCollect

# Generated at 2022-06-11 04:08:20.628017
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    capsh_output = ("Current: =ep",
                    "CapInh:   =",
                    "CapPrm:   =ep",
                    "CapEff:   =ep",
                    "CapBnd:   =ep",
                    "CapAmb:   =ep")
    fact_collector = SystemCapabilitiesFactCollector()
    capabilities = fact_collector.collect(module, capsh_output)
    assert capabilities == {'system_capabilities': [],
                            'system_capabilities_enforced': 'False'}

# Generated at 2022-06-11 04:08:33.050425
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.system.caps as caps
    import ansible.module_utils.facts.system.system as caps_system
    module = caps_system.System()
    capsh_path = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'

# Generated at 2022-06-11 04:08:42.151467
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    module = MockAnsibleModule({'capsh_path': capsh_path}, {'capsh_path': capsh_path})


# Generated at 2022-06-11 04:08:51.736041
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test get_caps_data() method of SystemCapabilitiesFactCollector class"""
    # Test [1]:
    # Test data:
    # stdout:
    #   Current: =ep
    #   Bounding set =cap_net_bind_service,cap_net_raw+eip
    #   Securebits: 00/0x0/1'b0
    #   secure-noroot: no (unlocked)
    #   secure-no-suid-fixup: no (unlocked)
    #   secure-keep-caps: no (unlocked)
    #   uid=0(root)
    #   gid=0(root)
    #   groups=0(root)


# Generated at 2022-06-11 04:09:00.402158
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    import ansible.module_utils.facts.processor
    fact_processor_obj = ansible.module_utils.facts.processor.FactProcessor()
    from ansible.module_utils.facts.processor import Facts
    collected_facts_obj = Facts()
    fact_collector.collect(module=None, collected_facts=collected_facts_obj)
    fact_processor_obj.collect(collected_facts=collected_facts_obj)
    facts_dict = fact_processor_obj.fetch()
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict

# Generated at 2022-06-11 04:09:07.980109
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    import os
    import tempfile
    import shutil
    module_name = 'ansible.module_utils.facts.capabilities.capsh'
    module_exists = True

    try:
        __import__(module_name)
    except ImportError:
        module_exists = False

    import ansible.module_utils.facts.capabilities as capabilities

    test_temp_dir = tempfile.mkdtemp()
    print("temp dir is:", test_temp_dir)
    test_capsh_file = os.path.join(test_temp_dir, 'capsh')

    ret = None


# Generated at 2022-06-11 04:09:17.204129
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = MockModule()

# Generated at 2022-06-11 04:09:27.256581
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup mock module object
    class MockModule:
        def get_bin_path(self, path, required=False, opt_dirs=[]):
            return '/path/to/capsh'

# Generated at 2022-06-11 04:09:32.882723
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import AnsibleUnsupportedCollector

    # NOTE: not mocked by default b/c not available for OSX testing
    try:
        SystemCapabilitiesFactCollector = get_collector_instance('SystemCapabilitiesFactCollector')
    except AnsibleUnsupportedCollector:
        from nose.plugins.skip import SkipTest
        raise SkipTest("capsh not available")

    fact_collector = SystemCapabilitiesFactCollector()
    fake_module = dict(get_bin_path=lambda x: '/bin/'+x)
    assert fact_collector.collect(module=fake_module) == dict(system_capabilities_enforced='NA', system_capabilities=[])


# Generated at 2022-06-11 04:09:34.947591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
        Test collect in class SystemCapabilitiesFactCollector
    """
    # No error/exception caught
    assert True

# Generated at 2022-06-11 04:09:43.983153
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import sys
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector

    class SystemCapabilitiesFactCollectorTest(SystemCapabilitiesFactCollector):

        # NOTE: Below method is required for BaseFactCollector.
        def __new__(cls, *args, **kwargs):
            obj = super(SystemCapabilitiesFactCollectorTest, cls).__new__(cls, *args, **kwargs)
            return obj

        def get_caps_data(self):
            return 'Current: =ep', ''

        def parse_caps_data(self, capsh_out):
            data = capsh_out.splitlines()

# Generated at 2022-06-11 04:09:47.799976
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:09:52.105979
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ##################################################################
    # Setup
    ##################################################################
    ##################################################################
    # Test
    ##################################################################
    # Unit test returns
    ##################################################################
    # Tear down
    ##################################################################
    # No teardown required
    ##################################################################
    ##################################################################
    # Finish
    ##################################################################
    return

# Generated at 2022-06-11 04:10:01.320341
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: temporary support for get_bin_path() to be removed soon -akl
    from ansible.module_utils.facts.utils import get_bin_path
    def mock_get_bin_path(cmd):
        if cmd == 'capsh':
            return '/path/to/capsh'
        else:
            return None

    # NOTE: temporary module mock support to be removed soon -akl
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            return mock_get_bin_path(cmd)

        def run_command(self, cmd):
            return 0, 'Current: =ep', ''

    m = MockModule()
    SystemCapabilitiesFactCollector().collect(module=m)


# Generated at 2022-06-11 04:10:10.920346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for class SystemCapabilitiesFactCollector'''
    test_facts_dict = dict()

    def test_capsh(module, collected_facts=None, *args, **kwargs):
        '''Mock capsh command'''
        if args[0][0] == capsh_path:
            return 0, test_capsh_output, ''
        else:
            return 1, "", "Can't find %s" % args[0][0]


# Generated at 2022-06-11 04:10:11.908084
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: add unit test -akl
    pass

# Generated at 2022-06-11 04:10:13.517418
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: mock module
    #c = SystemCapabilitiesFactCollector()
    #c.collect()
    pass

# Generated at 2022-06-11 04:10:14.441060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True


# Generated at 2022-06-11 04:10:23.871671
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector

    ansible.module_utils.facts.collector.ModuleNotFound = BaseException
    ansible.module_utils.facts.collector.warnings = [1,2,3]
    ansible.module_utils.facts.collector.warnings.filterwarnings = [8,9,10]
    ansible.module_utils.facts.collector.warnings.filterwarnings.warn = [11,12,13]

# Generated at 2022-06-11 04:10:34.130553
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 04:10:42.997252
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collectors.system.caps as caps

    # Assume module is not present for now (aka. capsh_path == None)
    capsh_path = None

    # Assume that module is present, but command 'capsh --print' fails
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        if rc != 0:
            return facts_dict

    # Assume that module is present and command 'capsh --print' is successful,
    # but command output is not as expected

# Generated at 2022-06-11 04:10:58.499364
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    class FakeModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return capsh_path

        def run_command(self, cmd, **kwargs):
            return 0, 'Current: =ep', ''

    module = FakeModule()
    collected_facts = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

    sut = SystemCapabilitiesFactCollector()

    # if capsh_path:
    fact_dict = sut.collect(module, collected_facts)

    # There should be some keys in fact_dict
    assert fact_dict
    # The key 'system_capabilities_enforced' should be populated

# Generated at 2022-06-11 04:11:07.350566
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockAnsibleModule()
    collected_facts = {}
    sut = SystemCapabilitiesFactCollector(module=module)

    result = sut.collect(collected_facts)

    expected_capsh_path = '/usr/bin/capsh'
    expected_run_command_args = [expected_capsh_path, '--print']
    expected_run_command_kwargs = {'errors': 'surrogate_then_replace'}
    module.run_command.assert_called_with(expected_run_command_args, **expected_run_command_kwargs)
    assert result['system_capabilities'] == [ 'cap_net_admin', 'cap_net_raw', 'cap_setgid', 'cap_setuid' ]
    assert result['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-11 04:11:15.728686
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleMock
    from ansible.module_utils.facts.collector import AnsibleModuleTestCase
    from ansible.module_utils.facts import utils

    # Responses

# Generated at 2022-06-11 04:11:24.332047
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import json
    import unittest
    import copy
    import sys
    import os

    module_name = 'ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector'
    sys.modules[module_name] = __import__(module_name)
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector


# Generated at 2022-06-11 04:11:33.100413
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CapabilityModule
    mm = CapabilityModule()

    c = SystemCapabilitiesFactCollector()
    result = c.collect(module=mm)


# Generated at 2022-06-11 04:11:42.513308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    # NOTE: py3 needs a little help with mock -akl
    if sys.version_info[0] > 2:
        from unittest.mock import patch
    else:
        from mock import patch

    # NOTE: patching module is required for mocking in py3 -akl
    if sys.version_info[0] > 2:
        mod_patch = 'ansible.module_utils.facts.collector.capabilities.SystemCapabilitiesFactCollector'
    else:
        mod_patch = 'ansible.module_utils.facts.collector.capabilities.SystemCapabilitiesFactCollector'

    target = 'ansible.module_utils.facts.collector.capabilities.SystemCapabilitiesFactCollector'
    # NOTE: does not work with imported target class -akl
    # with patch(target + '.

# Generated at 2022-06-11 04:11:46.789310
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    my_collector = ansible_collector.get_collector('caps')

    class MockModule(object):
        def get_bin_path(self):
            pass
    my_module = MockModule()

    my_collector.collect()


# Generated at 2022-06-11 04:11:47.305778
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:11:56.353771
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system import SystemCapabilitiesFactCollector as capsh_collector
    import mock

    frac_mock = mock.Mock(spec=capsh_collector, return_value=None)

    capsh_path = 'capsh'
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

# Generated at 2022-06-11 04:11:58.891314
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_dict = SystemCapabilitiesFactCollector().collect()
    assert fact_dict == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-11 04:12:16.080708
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess
    testobj = SystemCapabilitiesFactCollector()
    testobj.populate()
    assert isinstance(testobj.collect(), dict)
    try:
        subprocess.check_output(['capsh', '--print'])
    except OSError:
        pass

# Generated at 2022-06-11 04:12:25.344472
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def get_bin_path(self, path):
            return capsh_path
        def run_command(self, cmd, errors):
            return rc, out, err

    # Set up the mock objects
    o = {}
    o['stdout'] = 'Current:\n   CapInh: 000000000000001f\n   CapPrm: 0000000000000000\n   CapEff: 000000000000001f\n   CapBnd: 000000000000001f\n   CapAmb: 0000000000000000'
    o['stderr'] = ''
    o['rc'] = 0

    global capsh_path
    capsh_path = 'capsh_path'

    global rc
    rc = o['rc']

    global out
    out = o['stdout']

    global err
    err = o['stderr']

   

# Generated at 2022-06-11 04:12:33.590701
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    This method tests the collect method for SystemCapabilitiesFactCollector
    """
    from ansible.module_utils.six import StringIO

    from ansible.module_utils.facts import collector

    from ansible.module_utils._text import to_bytes
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.debug = False
            self.run_command = lambda args, **kwargs: (0, "", "")
            self.get_bin_path = lambda: "/path/to/capsh"

    module = MockModule()

# Generated at 2022-06-11 04:12:35.759514
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # TODO: See issue #27271
    # This needs to be fixed.
    # assert SystemCapabilitiesFactCollector.collect() = 'foo'
    pass

# Generated at 2022-06-11 04:12:44.346466
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector._DONT_USE_PRIVILEGED_CONTAINER = False
    capsh_path = 'bin/capsh'
    collected_facts = {}
    mod = 'system_capabilities_module'

    def mock_run_command(*args):
        return (0, 'Current: =ep', '')

    def mock_get_bin_path(*args):
        return capsh_path
    caps_collector = SystemCapabilitiesFactCollector()
    caps_collector.collect(mod, collected_facts)['system_capabilities_enforced'] == 'NA'
    caps_collector.collect(mod, collected_facts)['system_capabilities'] == []

    SystemCapabilitiesFactCollector.get_bin_path = mock_get_bin_path
    SystemCapabilitiesFactCollector.run_

# Generated at 2022-06-11 04:12:53.189026
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:12:57.293707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Return output of capsh.
    """
    import textwrap
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector


# Generated at 2022-06-11 04:13:05.232902
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Unit test for collect method of class SystemCapabilitiesFactCollector
    MOCK_MODULE = BaseFactCollector
    MOCK_MODULE.get_bin_path = lambda x: 'capsh_bin'
    MOCK_MODULE.run_command = lambda x, errors='surrogate_then_replace': (0, 'Current: =ep CapInh: = CAP_AUDIT_WRITE', '')
    # TODO: Mock module.run_command() appropriately -akl
    new_inst = SystemCapabilitiesFactCollector()

    assert new_inst.collect(MOCK_MODULE) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-11 04:13:11.065619
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # fake the module class. Capsh is not installed
    class FakeModule:
        def get_bin_path(self, path):
            return False

    # creation of the test object
    test_obj = SystemCapabilitiesFactCollector()

    # get the attributes of the test object
    test_obj_caps = test_obj.collect(FakeModule())
    test_obj_res = test_obj.collect(None)

    # assert results
    assert test_obj_caps == {}
    assert test_obj_res is None

# Generated at 2022-06-11 04:13:11.630358
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:13:47.540651
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts import collector

    # Instantiate the class being tested
    system_capabilities_fact_collector = collector.get_collector(
        'system_capabilities',
        system_capabilities_fact_collector)

    # Get a list of supported keys
    capability_keys = system_capabilities_fact_collector.get_supported_facts()

    # Build the mock module 'ansible_module'
    class MockModule:
        class MockRunCommand:
            def __init__(self, value):
                self.value = value

            def run_command(self, args, errors='surrogate_then_replace'):
                return self.value

        def get_bin_path(self, path):
            return 'capsh_path'


# Generated at 2022-06-11 04:13:55.658031
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """system_capabilities_fact_collector.SystemCapabilitiesFactCollector.collect:
        test if _facts_dict is populated correctly given capsh_path and enforced_caps
    """

    class module_mock:
        def get_bin_path(self, arg):
            return capsh_path
        def run_command(self, arg, errors):
            if not out:
                return (1, '', '')
            return (0, '\n'.join(out), '')

    # case: capsh_path does not exist, so fact should be empty dict
    capsh_path = None
    out = None
    assert(SystemCapabilitiesFactCollector().collect(module_mock(), None) == {})

    # case: capsh_path exists, but no relevant capsh output, so fact should be empty dict
    cap

# Generated at 2022-06-11 04:14:01.954439
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        # Mock methods of module
        """Return path based on 'path_type' if some path exists."""
        def get_bin_path(self, path_type, required=True):
            return 'path/to/capsh'

        """Run command on the remote machine."""
        def run_command(self):
            return 0, 'Current: =ep', None

    m = MockModule()
    f = SystemCapabilitiesFactCollector()
    res = f.collect(m)
    expected_result = {
        "system_capabilities_enforced": "False",
        "system_capabilities": []
    }
    assert res == expected_result

# Generated at 2022-06-11 04:14:09.198818
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Run through all test cases
    for test_case in test_cases:
        obj = SystemCapabilitiesFactCollector()
        if test_case['bin_path_exists']:
            facts = obj.collect(test_case['module'], test_case['collected_facts'])
            assert facts['system_capabilities_enforced'] == test_case['system_capabilities_enforced']
            assert facts['system_capabilities'] == test_case['system_capabilities']
        else:
            facts = obj.collect(test_case['module'], test_case['collected_facts'])
            assert facts['system_capabilities_enforced'] is None
            assert facts['system_capabilities'] is None


# Test cases

# Generated at 2022-06-11 04:14:11.635205
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Note: An implementation of this test is included in the
    # test_SystemCapabilitiesFactCollector_parse_caps_data() unit test.
    print('Skipping SystemCapabilitiesFactCollector.collect() unit tests')


# Generated at 2022-06-11 04:14:17.739974
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class ModuleMock(object):
        def get_bin_path(self, path):
            return '/usr/bin/capsh'

        def run_command(self, args, errors=None):
            return (0, '''
Current: =ep
Bounding set =cap_net_bind_service,cap_net_raw+eip
Securebits: 00/0x0/1'b0
            ''', '')


    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(module=ModuleMock())
    assert result['system_capabilities_enforced'] == 'True'
    assert result['system_capabilities'] == ['cap_net_bind_service', 'cap_net_raw+eip']

# Generated at 2022-06-11 04:14:24.500192
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for method collect of class SystemCapabilitiesFactCollector'''
    mock_module = Mock(name='mock_module')
    mock_module.run_command = Mock(name='mock_run_command')
    mock_module.run_command.return_value = (0, OUTPUT_CAPSH_NOT_ENFORCED, '')
    mock_module.get_bin_path = Mock(name='mock_get_bin_path')
    mock_module.get_bin_path.return_value = '/bin/capsh'

    # Test caps enforced
    mock_module.run_command = Mock(name='mock_run_command')
    mock_module.run_command.return_value = (0, OUTPUT_CAPSH_ENFORCED, '')
    mock_module.get_bin

# Generated at 2022-06-11 04:14:30.746116
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'

# Generated at 2022-06-11 04:14:35.492559
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'Current: =ep Permitted: =ep Inheritable: =ep', ''))
    mock_module.get_bin_path = Mock(return_value='/usr/bin/capsh')
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect(module=mock_module) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-11 04:14:38.718529
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    import json
    import os

    expected_results = json.loads(get_file_content(os.path.join(os.path.dirname(__file__), 'unittests', 'system_capabilities_facts')))
    result = SystemCapabilitiesFactCollector().collect()

    assert result == expected_results

# Generated at 2022-06-11 04:15:43.313544
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create instance of class
    inst = SystemCapabilitiesFactCollector()
    # Test method
    result = inst.collect()
    assert type(result) is dict
    assert 'system_capabilities_enforced' in result
    if result['system_capabilities_enforced'] == 'True':
        assert 'system_capabilities' in result
        assert type(result['system_capabilities']) is list

# Generated at 2022-06-11 04:15:44.129006
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: add unit tests -akl
    pass

# Generated at 2022-06-11 04:15:51.866147
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.basic
    from ansible.module_utils.facts import collector

    facts_dict = dict()
    module_mock = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    module_mock.get_bin_path = lambda path: "/usr/bin/capsh"

# Generated at 2022-06-11 04:16:00.097579
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess
    module = subprocess
    capsh_path = '/usr/bin/capsh'
    collected_facts = {}
    enforced_caps = []
    enforced = 'NA'

# Generated at 2022-06-11 04:16:09.077429
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    fake_module = FakeModule()
    fake_module.get_bin_path.side_effect = lambda x: "/usr/bin/capsh"
    fake_module.run_command = lambda x, y: (0, 'Current: =ep\n', '')
    fake_collector = SystemCapabilitiesFactCollector()

    # Exercise
    facts = fake_collector.collect(fake_module)

    # Verify
    assert len(facts) == 2
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'

    # Setup

# Generated at 2022-06-11 04:16:16.885116
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:16:24.726507
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:16:31.663519
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.core import VariableManager
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts.utils import get_file_content
    import ansible.module_utils.facts.utils


# Generated at 2022-06-11 04:16:33.476402
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = DummyAnsibleModule()
    SystemCapabilitiesFactCollector.collect(module=test_module, collected_facts=None)


# Generated at 2022-06-11 04:16:39.166593
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock

    module = mock.Mock()
    capsh_path = '/bin/capsh'
    module.get_bin_path.return_value = capsh_path
    module.run_command.return_value = (0, 'Current: =ep cap_chown,cap_dac_override+eip cap_setgid,cap_setuid+eip', '')

    collector = SystemCapabilitiesFactCollector
    facts_dict = collector.collect(module=module)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == ['cap_chown', 'cap_dac_override', 'cap_setgid', 'cap_setuid']

