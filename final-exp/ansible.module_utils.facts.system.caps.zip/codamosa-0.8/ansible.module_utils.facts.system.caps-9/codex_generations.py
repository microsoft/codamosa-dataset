

# Generated at 2022-06-11 04:07:23.273019
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # init a mock module
    module = MockModule()

    # init a SystemCapabilitiesFactCollector
    system_caps_facts_collector = SystemCapabilitiesFactCollector()

    # call the collect method in SystemCapabilitiesFactCollector
    system_caps_facts_collector.collect(module)

    # assert that the command we run is 'capsh --print'
    assert module.run_command_args == ['capsh', '--print']

    # assert that the facts dictionary contains the expected data

# Generated at 2022-06-11 04:07:24.974474
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: validate facts_dict
    assert SystemCapabilitiesFactCollector().collect() == {}


# Generated at 2022-06-11 04:07:34.801916
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    class TestModule:
        def run_command(self, commands, errors='surrogate_then_replace'):
            import sys
            if sys.version_info[0] == 2:
                from StringIO import StringIO
            else:
                from io import StringIO


# Generated at 2022-06-11 04:07:35.375263
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:07:36.045038
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:07:41.990260
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()
    # Create a fake module
    module = MockModule()
    # Invoke the collect method of SystemCapabilitiesFactCollector
    # which would return a dictionary of system capabilities
    facts_dict = c.collect(module)
    # Assert that system capabilities are correctly retrieved from
    # the output of running capsh --print via the MockModule
    assert facts_dict['system_capabilities'] == ['CAP_NET_BIND_SERVICE']
    assert facts_dict['system_capabilities_enforced'] == 'True'

# Class MockModule

# Generated at 2022-06-11 04:07:51.597090
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # instantiate the object under test
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # instantiate a dummy module to stand-in for AnsibleModule
    import ansible.module_utils.facts.system.caps as amu_caps
    module = amu_caps.AnsibleModule(argument_spec={},supports_check_mode=False)
    # instantiate a DummyFile in place of file input
    import ansible.module_utils.facts.system.caps as caps_module
    caps_module.open = caps_module.DummyFile
    # create dummy content for the DummyFile to return
    from ansible.module_utils.facts.system.caps import OUTPUT_CONTENTS
    caps_module.DummyFile.CONTENTS = OUTPUT_CONTENTS
    # collect facts
    facts

# Generated at 2022-06-11 04:07:52.209893
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False

# Generated at 2022-06-11 04:08:02.045387
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import platform

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.freebsd
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.darwin
    import ansible.module_utils.facts.system.distribution.windows
    from ansible.module_utils.facts.system.distribution.windows import WindowsDistributionFactCollector
    import ansible

# Generated at 2022-06-11 04:08:04.213108
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect(module, collected_facts) == {}

# Generated at 2022-06-11 04:08:15.033709
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import platform
    import stat
    import tempfile
    import textwrap
    import pty
    platform_system = platform.system()
    if platform_system != 'Linux':
        print('Test for SystemCapabilitiesFactCollector is only for Linux')
        return
    master, slave = pty.openpty()
    capsh_path = 'capsh'
    if module:
        capsh_path = module.get_bin_path(capsh_path)


# Generated at 2022-06-11 04:08:23.038583
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    module = get_module_mock({
        'run_command': [1, 'a\nb\nc\n', ''],
        'get_bin_path': '/usr/bin/capsh',
    })

    result = SystemCapabilitiesFactCollector().collect(module)

    assert result['system_capabilities'] == ['cap_chown', 'cap_dac_override', 'cap_fowner', 'cap_fsetid']
    assert result['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-11 04:08:31.915786
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import imp

    # Load the pseudo module that is used for the unittest
    test_module_path = 'test/unit/module_utils/facts/test_facts_collectors/module_capsh.py'
    test_fake_module = imp.load_source('ansible_fake_module', test_module_path)
    module = test_fake_module.FakeModule()

    # Collect the facts related to systems 'capabilities' via capsh
    c = SystemCapabilitiesFactCollector()
    result = c.collect(module=module, collected_facts=None)

    # Check the expected result
    expected_result = {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    assert result == expected_result

# Generated at 2022-06-11 04:08:41.138751
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile

    module = MagicMock()
    # NOTE: tests should not use real paths
    capsh = '/bin/capsh'
    module.get_bin_path.return_value = capsh
    rc = 0
    out = '''
    Current: =eip
    Bounding set =eip
    Securebits: 00/0x0/1'''
    err = ''
    module.run_command.return_value = (rc, out, err)

    fac = SystemCapabilitiesFactCollector()
    fac.collect(module=module)

    module.get_bin_path.assert_called_with('capsh')
    module.run_command.assert_called_with([capsh, '--print'], errors='surrogate_then_replace')


# Generated at 2022-06-11 04:08:50.143853
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method get_caps_data of class SystemCapabilitiesFactCollector"""
    class MockModule(object):

        def run_command(self):
            return 0, 'Current: =ep', ''

        def get_bin_path(self):
            return 'Mocked bin path'

    capsh_fact_collector = SystemCapabilitiesFactCollector()
    laws_of_unit_tests = capsh_fact_collector.collect(MockModule())
    assert 'system_capabilities_enforced' in laws_of_unit_tests
    assert 'system_capabilities' in laws_of_unit_tests
    assert laws_of_unit_tests['system_capabilities_enforced'] == 'False'
    assert laws_of_unit_tests['system_capabilities'] == []

# Generated at 2022-06-11 04:08:50.706399
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:09:00.939192
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    path = '/usr/bin/capsh'

# Generated at 2022-06-11 04:09:08.201447
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import inspect
    import sys
    import os
    from ansible.test.unit.test_loader import TestLoader
    from ansible.test.unit.test_runner import TestRunner
    from ansible.test.runner_test_loader import RunnerTestLoaderMixin

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    class ExitError(Exception):
        """Exception class to be raised by method get_bin_path and caught by the test case"""
        pass


# Generated at 2022-06-11 04:09:17.363755
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # build test object
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    class TestModule:
        def get_bin_path(self, name, dont_warn=False, opt_dirs=[]):
            return "/usr/bin/capsh"

# Generated at 2022-06-11 04:09:19.763608
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect()
    assert "system_capabilities" in facts_dict


# Generated at 2022-06-11 04:09:30.052272
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockFactCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set([])
        def collect(self, module=None, collected_facts=None):
            return {}

    collector = MockFactCollector(module)
    assert collector.collect() == {}

# Generated at 2022-06-11 04:09:39.745955
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import DictFactCollector
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts import _capsh_out

    cached_facts = {'ansible_facts': {}}
    mock_module = (
        "ansible.module_utils.facts.collector.BaseFactCollector",
        "ansible.module_utils.facts.collector.DictFactCollector",
        "ansible.module_utils.facts.ModuleFactsCollector",
    )
    mock_run_command = (
        "ansible.module_utils.facts.collector.ModuleFactCollector",
    )


# Generated at 2022-06-11 04:09:45.930095
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #NOTE: this is a stub implementation of a class only a single method of which is under test
    import mock
    #this is how to mock the two objects instantiated in the method under test
    caps_collector = mock.Mock(BaseFactCollector)
    module = mock.Mock()
    #create an instance of this class and call the method we want to test, with the mock objects instantiated above injected into the method
    #NOTE: this is only a stub, which does not perform any assertions; it also does not actually exercise the method under test
    SystemCapabilitiesFactCollector().collect(module, caps_collector)

# Generated at 2022-06-11 04:09:46.596735
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:09:55.432998
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts import ansible_collector

    mp = patch('ansible.module_utils.facts.ansible_collector')
    _ansible_collector = mp.start()
    _ansible_collector.__contains__.return_value = True
    _ansible_collector.get_module.return_value = None
    _ansible_collector.get_fact.return_value = None

    capsh_path = ansible_collector.get_bin_path('capsh')
    if not capsh_path:
        return
    rc, out, err = ansible_collector.run_command([capsh_path, "--print"])

    mp.stop()


# Generated at 2022-06-11 04:09:57.321874
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    obj = SystemCapabilitiesFactCollector()
    # TODO: mock/patch modules to test gets
    #obj.collect()
    pass



# Generated at 2022-06-11 04:10:06.767105
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def fake_run_command(cmd, errors, **kwargs):
        # NOTE: parse capsh -akl
        results2 = dict(rc=0,
                        out="""
Current: =ep
Bounding set =eip
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root)
""",
                        err='')
        return results2['rc'], results2['out'], results2['err']

    def fake_get_bin_path(exe, **kwargs):
        return exe

    import ansible.module_utils.facts.collector.system.cap

# Generated at 2022-06-11 04:10:16.266718
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import types

    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    MockedModule = types.new_class('MockedModule', (object,), {
        'run_command': lambda self, cmd: (0, 'Current: =ep', None)
    })

    module = MockedModule()
    module.get_bin_path = lambda name: '/usr/bin/' + name
    sys.modules['ansible.module_utils.basic'] = module
    sys.modules['ansible.module_utils.facts.collector'] = ansible.module_utils.facts.collector

    collector = SystemCapabilitiesFactCollector()


# Generated at 2022-06-11 04:10:26.092548
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    # NOTE: following two imports are not used.  Commenting them out -akl
    # import ansible.module_utils.facts.system.caps
    # from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3


    # Method collect calls get_caps_data which needs a module to run.  The only
    # thing from the module used is get_bin_path which is a stubbed out method.
    # NOTE: see .

# Generated at 2022-06-11 04:10:35.736374
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Tests the ability to collect facts related to the capabilities
    of the system.
    '''

    mock_module = Mock()
    mock_collected_facts = {}

# Generated at 2022-06-11 04:10:56.237277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import subprocess

    class RunCommand():
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, cmd, errors='surrogate_then_replace'):
            return self.rc, self.out, self.err

    class MockedModule():
        def get_bin_path(self, path):
            return '/bin/' + path

    # caps are not enforced
    rc = 0

# Generated at 2022-06-11 04:11:05.186418
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # test collect
    module = ansible_module_mock()
    capsh_path = None
    module.get_bin_path.return_value = capsh_path
    mock_out = 'Current: =\nCapabilities: =\nBounding set =\nSecurebits: 00/0x0/1'
    global run_command
    run_command = [capsh_path, "--print"]
    module.run_command.return_value = (0, mock_out, '')

    collector = SystemCapabilitiesFactCollector(module)
    assert collector.collect() == {
            'system_capabilities': [''],
            'system_capabilities_enforced': 'False'
            }


# Generated at 2022-06-11 04:11:09.955328
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this will break if method collect is renamed or moved -akl
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    facts_dict = SystemCapabilitiesFactCollector.collect()
    print(facts_dict)
    assert isinstance(facts_dict, dict), 'SystemCapabilitiesFactCollector.collect() returned incorrect type.'


# Generated at 2022-06-11 04:11:14.429791
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    c = get_collector_instance('SystemCapabilitiesFactCollector')
    facts = c.collect()
    assert(facts['system_capabilities_enforced'] == 'NA' or
           facts['system_capabilities_enforced'] == 'False' or
           facts['system_capabilities_enforced'] == 'True')
    return True

# Generated at 2022-06-11 04:11:16.589028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    obj = SystemCapabilitiesFactCollector(BaseFactCollector)
    assert obj.name == 'caps'

# Generated at 2022-06-11 04:11:25.192460
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import pytest
    import shutil

    capsh_path = '/bin/capsh'

    class Test_ansible_module_mock():
        def __init__(self):
            self.params = {}
            self.params['path'] = None
            self.params['follow'] = []
            self.params['links'] = 'follow'
            self.params['size'] = 0

        def get_bin_path(self, binary):
            bin_path = capsh_path
            if os.path.exists(bin_path):
                return bin_path
            else:
                print("Error: trying to collect system_capabilities, can't find {}".format(capsh_path))
                return None


# Generated at 2022-06-11 04:11:34.088964
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_fact_collector = SystemCapabilitiesFactCollector()
    print('Testing System Capabilities Fact Collector')
    print('  testing no module argument:')
    assert caps_fact_collector.collect() == {}

    from ansible.module_utils.basic import AnsibleModule
    print('  testing module argument:')
    module = AnsibleModule({}, bypass_checks=True)
    # no capsh installed
    module.run_command = lambda x, **kwargs: (1, '', 'capsh not found')
    assert caps_fact_collector.collect(module=module) == {}

    # capsh installed and correctly run
    module.run_command = lambda x, **kwargs: (0, 'Current: =ep', '')

# Generated at 2022-06-11 04:11:43.474456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import tempfile
    import shutil
    # NOTE: following is a reasonable facsimile of a module instance
    class Module(object):
        def __init__(self):
            self.binary_path = None
            self.capability_path = None
            self.tmpdir = None
            self.tmpbin = None

        def get_bin_path(self, binary_path, required=False, opt_dirs=[]):
            # NOTE: no easy way to mock the env in worker_pids so we
            #       manually create $PATH in the temp dir
            if self.tmpdir is None:
                self.tmpdir = tempfile.mkdtemp()
                self.tmpbin = os.path.join(self.tmpdir, 'bin')
                os.mkdir(self.tmpbin)
                os.en

# Generated at 2022-06-11 04:11:52.351329
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.system.distribution.collector import DistributionCollector

    MockModule = collections.namedtuple('mock_module', ['get_bin_path'])
    MockModule.run_command = lambda x, y, z: (0, "Current: =ep", "")
    module = MockModule(get_bin_path=lambda x: "/bin/capsh")

    scfc = SystemCapabilitiesFactCollector()
    facts_dict = scfc.collect(module=module)

    assert facts_dict == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-11 04:12:02.072431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector(None)
    module = MagicMock()
    module.run_command.return_value = 0, 'Current: =ep', ''
    assert collector.collect(module) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    module.run_command.return_value = 1, '', ''
    assert collector.collect(module) == {}
    module.run_command.return_value = 0, 'Current: =ep', ''
    assert collector.collect(module) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    module.run_command.return_value = 0, 'Current: =eip', ''

# Generated at 2022-06-11 04:12:35.747112
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test collect() method of class SystemCapabilitiesFactCollector.
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    import mock
    import os

    # Test with capsh_path = None.
    mock_module = mock.MagicMock()
    mock_module.get_bin_path.return_value = None
    mock_module.run_command.return_value = (1, '', '')
    mock_collected_facts = mock.MagicMock()

    sys_cap_col = SystemCapabilitiesFactCollector()
    facts = sys_cap_col.collect(mock_module, mock_collected_facts)
    assert facts == {}

    # Test with capsh_path = '/path/

# Generated at 2022-06-11 04:12:44.346502
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = os.path.join(os.path.dirname(__file__), 'resources/system_capabilities_collector_module.py')
    command_mock = MagicMock(return_value=(0, "Current:=ep Bounding set =cap_setpcap,cap_net_raw+eip\nSecurebits: 00/0x0/1'b0 secure-noroot\n secure-noroot: no (unlocked)\n", ""))
    # Mock module load to return a mock for the run_command function call
    module_mock = imp.load_source('ansible.module_utils.facts.system.system_capabilities_collector', module)
    module_mock.run_command = command_mock
    # Call the collect method of the class
    fact_collector = SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:12:53.190344
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test that if capsh is not installed, a NA value is returned for the capability
    '''
    # Create a class mock to be used as the fake module
    class ClassMock(object):
        def __init__(self, return_value=None):
            self.return_value = return_value

        def get_bin_path(self, param=None, opt_dirs=None):
            '''
            SUT: method get_caps_data
            '''
            if param == 'capsh':
                return None
            return 'capsh'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            '''
            SUT: method run_command
            '''
            return (0, 'stdout', 'stderr')


# Generated at 2022-06-11 04:13:02.639789
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import collector_registry
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_text
    import tempfile
    import json
    import pytest


# Generated at 2022-06-11 04:13:11.826175
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        from ansible.module_utils.facts.collector import BaseFactCollector
    except ImportError:
        assert False, "Could not load required module(s) for testing"

    try:
        from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    except ImportError:
        assert False, "Could not load module under test"

    class MockModule(object):
        @staticmethod
        def run_command(args, errors):
            return 1, 'Current: =ep' if args[1] != '--print' else 'Current: =ep cap_net_raw,cap_net_admin+eip', ''

    test_fact_collector = SystemCapabilitiesFactCollector()
    test_facts = test_fact_collector.collect(MockModule())

# Generated at 2022-06-11 04:13:22.068894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import DictFactsCollector

    # NOTE:
    # We mock 'module', 'run_command' & 'get_bin_path'
    module = pytest.Mock()

# Generated at 2022-06-11 04:13:31.055325
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts import BaseModule
    class FakeModule(BaseModule):
        def __init__(self):
            super(FakeModule, self).__init__()
            self._cached_bin_paths = []
        def get_bin_path(self, executable_name, required=False):
            return '/bin/' + executable_name
        def run_command(self, args, errors='strict', check_rc=True, **kwargs):
            return ('', 'Current: =ep', '')

# Generated at 2022-06-11 04:13:37.096456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test of the get method of SystemCapabilitiesFactCollector
    """

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.system.caps

    meth = ansible.module_utils.facts.collectors.system.caps.SystemCapabilitiesFactCollector._collect
    capsh_path = ansible.module_utils.facts.collector.BaseFactCollector().get_bin_path('capsh')
    if capsh_path:
        rc, out, err = ansible.module_utils.facts.collector.BaseFactCollector().run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        expected = {}
        expected['system_capabilities_enforced'] = 'NA'

# Generated at 2022-06-11 04:13:37.681354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:13:46.202724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Return facts for a given module '''
    import tempfile
    import shutil
    import os
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import get_caps_data
    from ansible.module_utils.facts.system.capabilities import parse_caps_data

    def run_module(module_args):
        ''' Simulate AnsibleModule.run_command() method '''
        # FIXME - what is this test supposed to actually do? -akl

    class FakeAnsibleModule(object):
        ''' Simulate AnsibleModule class '''


# Generated at 2022-06-11 04:14:55.989106
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True # FIXME: implement your test here

# Generated at 2022-06-11 04:15:03.217634
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    assert hasattr(SystemCapabilitiesFactCollector, 'collect')
    assert callable(SystemCapabilitiesFactCollector.collect)

    # Declare collector
    collector = SystemCapabilitiesFactCollector()

    # Declare facts
    # TODO: add parameters for mocking: 'capsh_path', 'return_code', 'out', 'err' -akl
    facts_dict = {}
    facts = ModuleFacts(facts=facts_dict)

    # Declare a mock module

# Generated at 2022-06-11 04:15:11.308622
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: must be run as root
    def mock_run_command(args, **kwargs):
        if args == ['capsh', '--print']:
            return 0, 'Current: = cap_net_admin,cap_net_bind_service+eip cap_net_raw,cap_ipc_lock+ei', ''

    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.system.system

    module = ansible.module_utils.facts.system.system.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    module.run_command = mock_run_command
    module.get_bin_path = lambda x: '/bin/%s' % x


# Generated at 2022-06-11 04:15:19.473376
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Module needed to run command
    class FakeModule:
        def __init__(self):
            self.params = {'capabilities': None, 'disable_capabilities': None}

        def get_bin_path(self, executable):
            return '/usr/bin/capsh'

        def run_command(self, command, errors='surrogate_then_replace'):
            return 0, 'Current: =cap_net_admin,cap_net_raw+ep', ''

    # Class to be tested
    class_to_test = SystemCapabilitiesFactCollector()

    # Actual call to method being tested
    actual_returned_value = class_to_test.collect(FakeModule())

    # Expected return value

# Generated at 2022-06-11 04:15:28.168611
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = MockModule()
    test_module.run_command = MockFunction(
        (
            ('capsh --print', '', '', 0),
            ('capsh --print', 'Current: = cap_chown,cap_dac_override+eip cap_fowner=ep', '', 0),
            ('capsh --print', 'Current: = cap_chown,cap_dac_override+eip cap_fowner=ep', 'capsh: caps_from_text() failed', 1),
            ('capsh --print', 'capsh: caps_to_text() failed', '', 1),
        ),
        count=4,
        side_effect=False,
    )


# Generated at 2022-06-11 04:15:36.957203
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test for collect of class SystemCapabilitiesFactCollector '''

# Generated at 2022-06-11 04:15:43.721985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import GenericFactCollector
    from ansible.module_utils.facts import get_collector_object

    module = GenericFactCollector()
    collected_facts = {}
    module.get_bin_path = lambda _: '/bin/capsh'
    module.run_command = lambda _: (0, 'Current:  =ep', '')
    system_caps = get_collector_object('caps').collect(module=module, collected_facts=collected_facts)
    assert system_caps['system_capabilities'] == []
    assert system_caps['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:15:51.460456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mockmodule = MagicMock()

# Generated at 2022-06-11 04:15:59.630777
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collections

    # Setup required class dependencies
    module = ansible_collections.ansible.misc.plugins.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

#    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    caps = ansible_collections.ansible.misc.plugins.module_utils.system.caps.SystemCapabilitiesFactCollector(module)
    facts = caps.collect()

    assert 'system_capabilities_enforced' in facts
    assert 'system_capabilities' in facts
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:16:04.908516
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    sys_caps_fact_collector = SystemCapabilitiesFactCollector()
    
    assert(sys_caps_fact_collector.name == 'caps')
    assert(len(sys_caps_fact_collector._fact_ids) == 2)
    assert('system_capabilities' in sys_caps_fact_collector._fact_ids)
    assert('system_capabilities_enforced' in sys_caps_fact_collector._fact_ids)