

# Generated at 2022-06-11 04:07:24.345958
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, capsh_path):
            self.caps_path = capsh_path
            self.run_args = []

        def get_bin_path(self, name, opts=None):
            return self.caps_path

        def run_command(self, args, **kwargs):
            self.run_args.append(to_bytes(args))

# Generated at 2022-06-11 04:07:25.974296
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:07:35.948261
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: make local imports to stay compatible with python 2.4
#    from ansible.module_utils.facts.collectors.capabilities import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.collectors.capabilities
    fact_collector = ansible.module_utils.facts.collectors.capabilities.SystemCapabilitiesFactCollector

    # expected result
    exp_result = {}
    exp_result['system_capabilities_enforced'] = 'True'

# Generated at 2022-06-11 04:07:42.795851
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: could to be probably mocked better -akl
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.params['collect_subset'] = []
            self.exit_json = None

        def get_bin_path(self, command, opt_dirs=[]):
            return '/usr/bin/capsh'


# Generated at 2022-06-11 04:07:44.546202
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    caps = SystemCapabilitiesFactCollector()
    caps.collect()

# Generated at 2022-06-11 04:07:54.330591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """

    mod = Mock()
    os = Mock()
    os.path = Mock()
    os.path.isfile.return_value = True
    os.path.isabs.return_value = True
    mod.run_command = Mock()
    mod.run_command.return_value = (0, 'Current: =ep\nBounding set =chroot,cap_setuid,cap_setgid,cap_setpcap,cap_setfcap,cap_net_bind_service,cap_audit_write,cap_audit_control,cap_setfcap+p', '')
    mod.get_bin_path = Mock()
    mod.get_bin_path.return_value = '/usr/bin/capsh'
    mod

# Generated at 2022-06-11 04:07:54.930899
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:08:04.776357
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import unittest
    import copy
    import sys
    import shutil
    from ansible.module_utils.facts import collector

    class ModuleStub:

        def __init__(self):
            self.run_command_args = []
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, cmd):
            if cmd == 'capsh':
                return self.get_bin_path_value
            else:
                return None

        def run_command(self, args, errors='surrogate_then_replace'):
            self.run_command_args.append(copy.copy(args))
            return self.run_command_rc, self.run_command_out, self.run_command_err

# Generated at 2022-06-11 04:08:09.700117
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule

    module = AnsibleModule(argument_spec={})
    # NOTE: collect() is already called by AnsibleFactsCollector._collect_subset()
    # NOTE: therefore, collect() method is not explicitly called by test -akl
    assert isinstance(module.ansible_facts['caps'], dict)

# Generated at 2022-06-11 04:08:17.688811
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import filter_collection
    from ansible.module_utils._text import to_text
    import json

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )
    faked_subset = ['system_capabilities']
    result = SystemCapabilitiesFactCollector._get_subset(module, faked_subset)
    assert result == ['system_capabilities']

# Generated at 2022-06-11 04:08:30.444325
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:08:39.723935
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import mock_module
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import test_system_capabilities_fact_collector

    module = mock_module.MockModule()
    collect = test_system_capabilities_fact_collector.SystemCapabilitiesFactCollector()

    # get_caps_data - Return known output, with 'yes' enforced

# Generated at 2022-06-11 04:08:45.596249
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = mock.MagicMock()
    m.run_command.return_value = (1, 'Current:=ep', 'msg')
    res = SystemCapabilitiesFactCollector().collect(m, {})
    assert res.get('system_capabilities', 'NA') == 'NA'
    assert res.get('system_capabilities_enforced', 'NA') == 'NA'

    m.run_command.return_value = (0, 'Current:=ep', 'msg')
    res = SystemCapabilitiesFactCollector().collect(m, {})
    assert res.get('system_capabilities_enforced', 'NA') == 'False'
    assert res.get('system_capabilities', 'NA') == []


# Generated at 2022-06-11 04:08:46.525068
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-11 04:08:56.787625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest

    from ansible.module_utils.facts.collector.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils import basic

    # Disable 'is-a' check due to object being used as a factory.
    # pylint: disable=R0205
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, binary):
            return binary

        def run_command(self, args, errors='surrogate_then_replace'):
            return self.rc, self.out, self.err
    # pylint: enable=R0205

    # Test with capsh returning 'CapInh: =eip'

# Generated at 2022-06-11 04:09:06.113180
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeModule('/fake/capsh')

    collector = SystemCapabilitiesFactCollector(module=module)
    result = collector.collect()


# Generated at 2022-06-11 04:09:10.369342
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import ansible.module_utils.facts.collector.facter as factermod
    import ansible.module_utils.facts.collector.system_capabilities as sc

    facts = factermod.FacterCollector()

    sc_facts = sc.SystemCapabilitiesFactCollector(facts)

    assert sc_facts.collect()

# Generated at 2022-06-11 04:09:19.587439
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock modules, arguments and responses of methods:
    #
    #   - ansible.module_utils.facts.collector.BaseFactCollector.get_bin_path
    #   - ansible.module_utils.basic.AnsibleModule.run_command
    #
    m_run_command = Mock(return_value=('0', 'Current: =ep', ''))

    m_module = Mock(
        get_bin_path=Mock(return_value='/bin/capsh'),
        run_command=m_run_command)

    # Test 1: System capabilities enforced

# Generated at 2022-06-11 04:09:29.571451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test SystemCapabilitiesFactCollector._collect works as expected
    """
    _module = CapshModule()
    # Test with 2.6 kernel

# Generated at 2022-06-11 04:09:37.286229
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # initialize the class and defind a module
    factCollector = SystemCapabilitiesFactCollector()
    module = FakeAnsibleModule()

    # execute collect method
    result = factCollector.collect(module=module)
    assert result == {'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap'], 'system_capabilities_enforced': 'True'}


# Generated at 2022-06-11 04:09:49.075262
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock import and define the return values of subcommands
    def get_bin_path(self, arg):
        return "capsh_path"


# Generated at 2022-06-11 04:09:54.778440
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeModule({
        'run_command': fake_run_command,
        'get_bin_path': fake_get_bin_path
    })
    collector = SystemCapabilitiesFactCollector(module=module)
    facts = collector.collect(module=module)

    assert facts['system_capabilities'] == ['chown', 'dac_override', 'fowner', 'net_raw']
    assert facts['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:10:02.129401
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect()
    assert isinstance(facts_dict, dict), 'Return value is not a dictionary'
    assert 'system_capabilities_enforced' in facts_dict, 'Return value does not contain expected key'
    assert isinstance(facts_dict['system_capabilities_enforced'], str), 'Returned value is not a string'
    assert 'system_capabilities' in facts_dict, 'Return value does not contain expected key'
    assert isinstance(facts_dict['system_capabilities'], list), 'Returned value is not a list'


# Generated at 2022-06-11 04:10:11.782264
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:10:20.844791
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import os
    import json

    def run_command_mock(self, args, **kwargs):
        if args[0] == '/usr/bin/capsh':
            if args[1] == "--print":
                with open(os.path.join(os.path.dirname(__file__), 'capsh_output.json'), 'r') as f_capsh_output:
                    capsh_output = json.load(f_capsh_output)
                    return capsh_output['rc'], capsh_output['out'], capsh_output['err']
        return 0, '', ''

    module = AnsibleModuleStub()


# Generated at 2022-06-11 04:10:31.339285
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # setup/prepare/mock test environment
    mod = MagicMock()
    mod.run_command.return_value = (0, '', '')
    capsh_path = 'path/to/capsh'
    mod.get_bin_path.return_value = capsh_path
    # define test data for this test

# Generated at 2022-06-11 04:10:38.906528
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import mock

    module_args = {}


# Generated at 2022-06-11 04:10:47.586521
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:10:56.561024
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Import class under test + mocks, fakes and fixtures
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.selinux import Enforced

    class FakeModule():

        def __init__(self):
            self.run_command_count = 0

        def run_command(self, *args, **kwargs):
            self.run_command_count += 1
            if self.run_command_count == 1:
                return 0, "", ""

# Generated at 2022-06-11 04:11:05.510269
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    
    module_mock = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module_mock.run_command = lambda cmd, optional_args: (0, 'Current: =ep', '')
    # check:
    # get_bin_path ->
    # get_caps_data ->
    # run_command ->
    # parse_caps_data
    
    caps_mock = SystemCapabilitiesFactCollector(module_mock, {})

# Generated at 2022-06-11 04:11:22.369565
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps as c

    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = ansible.module_utils.facts.collector.get_collector(c.SystemCapabilitiesFactCollector.name)

    assert issubclass(fact_collector.__class__, BaseFactCollector)
    assert fact_collector.name == 'caps'

# Generated at 2022-06-11 04:11:31.267728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import os
    import re
    import tempfile
    import pytest
    os.environ['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
    capsh_path = '/bin/capsh'

# Generated at 2022-06-11 04:11:40.622159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import __main__ as main

    class MockModule(object):

        def __init__(self, *args, **kwargs):
            self._fact_ids = ['system_capabilities']

        def get_bin_path(self, path, required=True):
            bin_dir = os.path.dirname(sys.executable)
            return os.path.join(bin_dir, 'capsh')

        def run_command(self, *args, **kwargs):
            return 0, 'Current: =ep CapInh: CapEff: CapPrm: CapBnd: CapAmb: bound to pid 1234\n', ''

    module = MockModule()
    main.ANSIBLE_MODULE_EXE = 'does_not_matter'

# Generated at 2022-06-11 04:11:42.560771
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: please do not add more test cases here, add to
    # tests/test_utils.test_capabilities.py
    pass

# Generated at 2022-06-11 04:11:51.832474
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: For testing purposes, class SystemCapabilitiesFactCollector is set to
    #   a new (mock) class and the original SystemCapabilitiesFactCollector is
    #   stored and restored after running test_SystemCapabilities_collect()
    #   -akl

    # NOTE: py27 compatibility -akl
    run_command_orig = SystemCapabilitiesFactCollector.run_command

# Generated at 2022-06-11 04:12:01.354974
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of module_utils.basic.AnsibleModule
    module_mock = unittest.mock.MagicMock()

    # Set module_mock.get_bin_path() to return the filename of the file we want capsh to return
    test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'capsh_output.txt')
    module_mock.get_bin_path.return_value = test_file

    # Create a list of 2 paths which will be passed to capsh to allow it to find the capsh_output.txt file
    # NOTE: This is really a hack, since we only want the first path, and a better solution should be found
    test_path = ['.', os.path.dirname(test_file)]


# Generated at 2022-06-11 04:12:10.093525
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # No error if module is None
    scc = SystemCapabilitiesFactCollector()
    facts_dict = scc.collect(module=None, collected_facts=None)
    assert isinstance(facts_dict, dict)
    assert facts_dict == {}

    module = MockModule()
    scc = SystemCapabilitiesFactCollector()
    # No error if module.get_bin_path returns None
    facts_dict = scc.collect(module=module, collected_facts=None)
    assert isinstance(facts_dict, dict)
    assert facts_dict == {}

    # No error if module.get_bin_path returns a string
    module.get_bin_path_return_value = "some string"
    facts_dict = scc.collect(module=module, collected_facts=None)

# Generated at 2022-06-11 04:12:16.562622
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector, get_collector_instance

    fc = get_collector_instance(SystemCapabilitiesFactCollector)
    assert type(fc) is SystemCapabilitiesFactCollector

    # TODO: add test with capsh to validate proper parsing -akl
    def run_command(c, errors='surrogate_then_replace'):
        return (0, 'Current: =ep', '')

    fc.module.run_command = run_command
    fc.collect()

# Generated at 2022-06-11 04:12:25.781947
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    module = FakeModule()
    collector = Collector(module)
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector(module)

    # test when capsh is present
    module.run_command.return_value = (0, to_bytes("Current: =ep"), None)
    facts = system_capabilities_fact_collector.collect(module, collector.collect())
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:12:29.176159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this needs to actually mock 'module' which isn't possible atm -akl
    facts_dict = SystemCapabilitiesFactCollector().collect(None)
    assert facts_dict['system_capabilities_enforced'] == 'NA'
    assert len(facts_dict['system_capabilities']) < 1

# Generated at 2022-06-11 04:12:57.677827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mod = AnsibleModule(
        argument_spec=dict(),
    )

    # Test the case with capsh not installed
    mod.get_bin_path = MagicMock(
        return_value=None
    )
    mod.run_command = MagicMock(
        return_value=(0, "", "")
    )
    output = SystemCapabilitiesFactCollector()
    result = output.collect(module=mod)
    assert result == dict()

    # Test the case with capsh installed and no capabilities set
    mod.get_bin_path = MagicMock(
        return_value='/usr/bin/capsh'
    )

# Generated at 2022-06-11 04:13:07.070124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()

# Generated at 2022-06-11 04:13:15.958680
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import json
    import subprocess
    # NOTE: mocks for module.get_bin_path(capsh), module.run_command(capsh)
    class TestModule:
        def get_bin_path(self, name):
            if name == 'capsh':
                return 'capsh'
            else:
                assert False, 'get_bin_path called with name=%s' % name

# Generated at 2022-06-11 04:13:26.847736
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import DictFactsCollector
    from ansible.module_utils.facts import module_facts
    import json

    def get_bin_path(name, opt_dirs=[]):
        if name == 'capsh':
            return '/bin/capsh'
        else:
            raise Exception("Error")

    def parse_caps_data(stdout):
        facts = {}
        enforced_caps = []
        enforced = 'NA'
        for line in stdout.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'
                else:
                    enforced = 'True'

# Generated at 2022-06-11 04:13:31.728834
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible_collections
    import ansible.module_utils.facts.collector
    import sys
    import io

    # Test that output is parsed correctly, i.e. system_capabilities returned
    # and system_capabilities_enforced is True
    # NOTE: this test depends on bash -akl
    # TODO: mock capsh's output -akl
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    import mock
    from ansible_collections.ansible.builtin.plugins.module_utils.facts import collector

    class MyModule:
        def __init__(self, run_command_return_tuple):
            self.run_command_return_tuple = run_command_return_tuple
            self

# Generated at 2022-06-11 04:13:33.195632
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        import module_utils.facts
    except ImportError:
        print('skipping collection of SystemCapabilities facts')
    else:
        SystemCapabilitiesFactCollector.collect()

# Generated at 2022-06-11 04:13:38.719100
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import json
    import pytest

    from collections import namedtuple
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts import collector

    # mock ansible module
    class MockAnsibleModule():
        def __init__(self):
            pass

        def run_command(self, command, errors='replace'):
            '''
            Mock of ansible module run_command() method for unit testing
            '''
            class MockRunCommand():
                def __init__(self):
                    self.rc = 0
                    self.stdout = ''
                    self.stderr

# Generated at 2022-06-11 04:13:47.540320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system.system_capabilities import get_caps_data
    from ansible.module_utils.facts.collector.system.system_capabilities import parse_caps_data

    # No module
    collector = SystemCapabilitiesFactCollector(None)
    assert collector.collect() == {}

    # No capsh
    module = MockModule("/bin/capsh", False)
    collector = SystemCapabilitiesFactCollector(module)
    assert collector.collect() == {}

    # capsh
    module = MockModule("/bin/capsh", True)
    collector = SystemCapabilitiesFactCollector(module)

# Generated at 2022-06-11 04:13:48.780910
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-11 04:13:49.612506
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: implement unit test
    return

# Generated at 2022-06-11 04:15:01.235615
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector().collect(None, None)

# Generated at 2022-06-11 04:15:09.053904
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #Mocking the run_command, get_bin_path, exists and set_ansible_facts methods.
    class MyMockedModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command_called = False
            self.run_command_output = [0, 'Current: =ep              Bounding set =ep', '']

        def get_bin_path(self, arg, *args, **kwargs):
            return '/usr/bin/capsh'

        def exists(self, arg):
            return True

        def set_ansible_facts(self, arg):
            return True

        def run_command(self, command, *args, **kwargs):
            self.run_command_called = True
            return self.run_command_output

    module = MyMockedModule()

# Generated at 2022-06-11 04:15:17.245004
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FakeModule
    from ansible.module_utils.facts.collector import FakeFactsCollector

    facts = FakeFactsCollector([SystemCapabilitiesFactCollector])
    module = FakeModule(facts.collect)
    result = SystemCapabilitiesFactCollector(module=module).collect()


# Generated at 2022-06-11 04:15:18.919810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass
    # TODO: Test collect()
    # Capsh is a bit of a bear to test.
    # -akl

# Generated at 2022-06-11 04:15:27.595812
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: 'from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector'
    # ALSO: remove '#' from '#from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector'
    # ALSO: (re-?)import module under test
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector

    # create an instance of SystemCapabilitiesFactCollector
    sut = SystemCapabilitiesFactCollector()

    # test collect
    #### TODO: Test collect

    # As of 2016-01-20, there are no tests in test/units/module_utils/facts/collector.py

    # In the first place, I (akl) don't know if I should be testing the SystemCapabilitiesFactCollector.collect
    # method...  Shouldn't

# Generated at 2022-06-11 04:15:36.329709
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    sys_caps_collector = SystemCapabilitiesFactCollector()
    collected_facts = sys_caps_collector.collect(module=module)
    assert 'system_capabilities' in collected_facts
    assert not collected_facts['system_capabilities']
    assert 'system_capabilities_enforced' in collected_facts
    assert collected_facts['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:15:44.693645
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from unittest.mock import Mock
    from ansible.module_utils._text import to_bytes

    mock_module = Mock()
    mock_module.get_bin_path.return_value = '/sbin/capsh'

# Generated at 2022-06-11 04:15:50.921806
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of SystemCapabilitiesFactCollector
    sys_caps = SystemCapabilitiesFactCollector()

    # Assert that the instance is instanciation of BaseFactCollector class
    assert isinstance(sys_caps, BaseFactCollector)

    # Assert that the name of the instance is caps
    assert sys_caps.name == 'caps'

    # Assert system_capabilities_enforced is set in set of fact ids
    assert 'system_capabilities_enforced' in sys_caps.fact_ids

    # Test collect call with empty collected_facts param
    assert sys_caps.collect(collected_facts={}) == {}

# Generated at 2022-06-11 04:15:59.107206
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test SystemCapabilitiesFactCollector.collect"""

    # init
    import mock
    mod_mock = mock.MagicMock()
    test_obj = SystemCapabilitiesFactCollector(None, mod_mock)

    # test each possible output

# Generated at 2022-06-11 04:16:08.025144
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.get_bin_path.return_value = '/bin/capsh'
    module.run_command.return_value = (0, 'Current: =eip', '')
    facts = SystemCapabilitiesFactCollector(module).collect()
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []
    module.reset_mock()
    module.run_command.return_value = (0, 'Current: =ep cap_sys_chroot+i', '')
    facts = SystemCapabilitiesFactCollector(module).collect()
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == ['cap_sys_chroot']
    module.reset_mock()
    module.run