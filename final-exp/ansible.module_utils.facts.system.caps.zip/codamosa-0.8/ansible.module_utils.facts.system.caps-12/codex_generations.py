

# Generated at 2022-06-11 04:07:23.839634
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_path_dict = {'capsh': '/bin/capsh'}
    test_cmd_result = {'rc':0, 'stdout':'Current: =ep', 'stderr':'none'}

    def test_module_get_bin_path(module):
        return test_path_dict[module]

    def test_module_run_command(module, command, errors):
        return test_cmd_result

    module = type('module', (), {})()
    module.get_bin_path = test_module_get_bin_path
    module.run_command = test_module_run_command

    caps_fact = SystemCapabilitiesFactCollector()
    caps_fact.collect(module, None)
    assert caps_fact['system_capabilities'] == []

# Generated at 2022-06-11 04:07:29.356288
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    from ansible.module_utils.facts import collector
    mock_module = mock.MagicMock(name='module')
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = ''

    mock_collector = collector.BaseFactCollector()
    result = mock_collector.collect(mock_module)

    assert result is not None


# Generated at 2022-06-11 04:07:31.544842
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Test collect method of SystemCapabilitiesFactCollector """
    pass
# this will be intercepted by the mock module and no real files will be touched


# Generated at 2022-06-11 04:07:40.823342
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.system import get_file_content
    from ansible.module_utils.facts.collector.system import file_exists
    import os
    import sys

    class MockModuleFacts(ModuleFacts):
        _BIN_PATH_ARG = 'bin_path'
        _bin_path = os.path.expanduser('~/bin')
        _executable_search_paths = ['/usr/local/sbin', '/usr/local/bin', '/usr/sbin', '/usr/bin', '/sbin', '/bin']
        _exists_cache = {}
        _content_cache = {}

       

# Generated at 2022-06-11 04:07:50.180801
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    CAPSH_PATH = None
    if os.path.exists('/usr/bin/capsh'):
        CAPSH_PATH = '/usr/bin/capsh'
    elif os.path.exists('/bin/capsh'):
        CAPSH_PATH = '/bin/capsh'
    else:
        CAPSH_PATH = 'capsh'

    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command = mock.Mock()
    test_module.run_command.return_value = ['0', CAPSH_OUTPUT, '']
    test_module.get_bin_path = mock.Mock()
    test_module.get_bin_path.return_value = CAPSH_PATH

    system_capabilities

# Generated at 2022-06-11 04:08:00.220913
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}
    if not module:
        return facts_dict

    capsh_path = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-11 04:08:09.950625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    capsh_path_rc = 1
    capsh_path_data = b''
    capsh_path_error = b''

    capsh_print_rc = 0
    capsh_print_data = b'Current: = cap_net_raw+eip\n'
    capsh_print_error = b''

    module_no_bin_path = {'get_bin_path': lambda path: None}
    module_with_bin_path = {'get_bin_path': lambda path: capsh_path,
                            'run_command': lambda args, errors: (capsh_path_rc, capsh_path_data, capsh_path_error)
                            }

    collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:08:12.604782
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    sys_caps_fc = SystemCapabilitiesFactCollector(None)

    # Without module param
    result_caps_collected = sys_caps_fc.collect()
    assert result_caps_collected == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-11 04:08:22.778740
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest

    class Test_fakeModuleClass():

        def __init__(self):
            self.run_command_returns = [0, '', '']

        def command_exists(self, command):
            return True

        def get_bin_path(self, command):
            return command

        def run_command(self, command, errors):
            return self.run_command_returns

    class Test_SystemCapabilities_collect(unittest.TestCase):
        def setUp(self):
            self.mockModule = Test_fakeModuleClass()
            self.sut = SystemCapabilitiesFactCollector(self.mockModule)


# Generated at 2022-06-11 04:08:32.359407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors

    # Mock module to be used in unit tests
    class MockModule:
        def get_bin_path(self, arg=None):
            return "/usr/bin/capsh"


# Generated at 2022-06-11 04:08:43.732768
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, 'Current: =ep\nBounding set =ep cap_net_bind_service,cap_net_raw+eip\nSecurebits: 00/0x0/1\'b0 secure-noroot, secure-no-setuid-fixup\nsecure-noroot: no (unconfined)\nsecure-no-setuid-fixup: no (unconfined)\nuid=0(root) gid=0(root) groups=0(root)\n', ''))
    facts = SystemCapabilitiesFactCollector().collect(module=module)
    assert facts['system_capabilities'] == ['cap_net_bind_service',
                                            'cap_net_raw+eip']

# Generated at 2022-06-11 04:08:44.741716
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Add tests
    pass

# Generated at 2022-06-11 04:08:54.696938
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Arrange
    mod = MagicMock()

# Generated at 2022-06-11 04:09:04.737158
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    passes = 0

    # mock module for testing
    module = MockModule('ansible.module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector')
    module.get_bin_path = MagicMock(return_value='/path/to/capsh')

    # run possible commands & return results as needed
    cmd = ['/path/to/capsh', '--print']
    out_pass_1 = '''Current: =eip
Bounding set =eip
Securebits: 00/0x0/1'b0 secure-noroot, noroot
 secure-noroot, noroot
 secure-noroot, noroot
 secure-noroot, noroot
'''

# Generated at 2022-06-11 04:09:14.240939
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collectors.legacy import get_file_content

    module = MagicMock()
    module.get_bin_path.return_value = '/bin/capsh'
    module.run_command.return_value = (0, get_file_content('capsh_print.txt'), '')
    facts_dict = {}
    fact_collector = get_collector_instance(FactCollector, 'system.caps')
    fact_collector.collect(module=module, collected_facts=facts_dict)

# Generated at 2022-06-11 04:09:23.837742
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic
    import ansible.module_utils.basic
    import sys
    import os

    #### Prepare requirements to test
    # Prepare fake ansible module
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=True)
    # Prepare fake facts
    ansible_facts.ANSIBLE_FACTS['ansible_capabilities_enforced'] = 'True'

# Generated at 2022-06-11 04:09:28.906894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock(path='ansible.module_utils.facts.system.capabilities')
    module.run_command = run_command
    assert SystemCapabilitiesFactCollector(module).collect() == {'system_capabilities': ['cap_chown', 'cap_net_bind_service'],
                                                                 'system_capabilities_enforced': 'True'}


# Generated at 2022-06-11 04:09:32.320213
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Unit test for method collect of class SystemCapabilitiesFactCollector """
    module = DummyModule()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        sys_caps = SystemCapabilitiesFactCollector(module=module)
        sys_caps.collect(module=module)
        cap_dict = sys_caps.populate()
        assert cap_dict['system_capabilities']

# Generated at 2022-06-11 04:09:42.125725
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.collectors.system

    module = ansible.module_utils.facts.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)


# Generated at 2022-06-11 04:09:48.509013
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.caps import CapshMockModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCache
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: setUp/tearDown

    # NOTE: test for missing capsh_path
    # NOTE: get_caps_data() -> capsh_path not found
    capsh_path = '/usr/bin/capsh'

# Generated at 2022-06-11 04:10:03.723455
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DummyAnsibleModule()
    # the NOPATH case should not fail
    collect = SystemCapabilitiesFactCollector(module).collect()
    assert collect == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    module = DummyAnsibleModule()
    # the NOPATH case should not fail
    collect = SystemCapabilitiesFactCollector(module, '/path').collect()
    assert collect == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
    module = DummyAnsibleModule()
    # the NOPATH case should not fail
    collect = SystemCapabilitiesFactCollector(module, '/path').collect()
    assert collect == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}



# Generated at 2022-06-11 04:10:06.897514
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module, collected_facts)
    assert facts_dict == {}


# Generated at 2022-06-11 04:10:16.390285
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.sys_info = {
        'distribution': None,
        'distribution_release': None,
        'distribution_version': None,
        'os_family': None,
        'machine': 'x86_64'
    }
    collector.sys_raw_info = {
        'kernel_name': None,
        'kernel_version': None,
        'kernel_architecture': None
    }
    collector.sys_hw_info = {
        'hostname': None,
        'fqdn': None,
        'system': None,
        'bios': {},
        'cpu': {},
        'memory': {},
        'network': {}
    }

# Generated at 2022-06-11 04:10:19.598228
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # load module
    module = AnsibleModule()
    # load class
    target_class = SystemCapabilitiesFactCollector(module)
    # init class with empty json
    target_class.collect(module, {})
    # test if class is not none
    assert target_class is not None

# Generated at 2022-06-11 04:10:28.954179
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Method collect of class SystemCapabilitiesFactCollector returns correct facts when capsh fails """
    # NOTE: use a mock class to make this test more specific to this class -akl

    print()

    # NOTE: move the test class definition into the test method -akl
    class DummyModule(object):
        def get_bin_path(self, capsh_path):
            return capsh_path

        def run_command(self, cmd, errors):
            return (1, "", "")

    module = DummyModule()
    SystemCapabilitiesFactCollector().collect(module)
    # NOTE: at this point we have no assertions. The test passes if it
    # returns without error. -akl


# Generated at 2022-06-11 04:10:29.656419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:10:38.002622
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:10:40.787298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # initialize
    m = {}
    sc = SystemCapabilitiesFactCollector()
    # mock initialize
    sc.module = m
    # test init
    assert sc.name == 'caps'
    # test collect
    assert sc.collect() == {}

# Generated at 2022-06-11 04:10:44.661645
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = Mock_module()
    test_module.run_command = Mock_run_command()
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(test_module)
    test_SystemCapabilitiesFactCollector.collect()
    assert test_module.run_command.call_count == 1

# Mocks

# Generated at 2022-06-11 04:10:53.363024
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    fake_out = ("Capabilities for `/bin/ping':\n"
                "= cap_net_admin,cap_net_raw+ep\n"
                "Current: = cap_net_admin,cap_net_raw+ep\n"
                "\n"
                "Bounding set =cap_net_admin,cap_net_raw\n")
    fake_err = ""
    fake_rc = 0
    # NOTE: -akl 'system_capabilities' is a list of capabilities
    fake_facts_dict = {'system_capabilities': ['cap_net_admin', 'cap_net_raw'],
                       'system_capabilities_enforced': 'False'}
    # NOTE: The 'system_capabilities_enforced' key is set to NA as the 'cap' utility is not installed


# Generated at 2022-06-11 04:11:07.533266
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    # Method collect of class SystemCapabilitiesFactCollector should return String
    assert isinstance(SystemCapabilitiesFactCollector.collect(MockClass(), module), dict)


# Generated at 2022-06-11 04:11:15.910706
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: add '''=NA''' in assign for easier mocking -akl
    capsh_path = ''
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    rc, out, err = (0, '', '')
    module = {'get_bin_path': lambda x: capsh_path,
              'run_command': lambda x: (rc, out, err)
             }
    collector = SystemCapabilitiesFactCollector()

    rc, out, err = (0, 'Current: =\n', '')
    res = collector.collect(module)
    assert res == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

    rc, out, err = (0, 'Current: =ep\n', '')

# Generated at 2022-06-11 04:11:16.748479
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Add test for current method
    pass

# Generated at 2022-06-11 04:11:17.277943
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:11:25.890181
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = dict(run_command=lambda a, b: (0, "Current: =ep Boundingset=cap_bluetooth,cap_net_raw,cap_sys_tty_config,cap_syslog,cap_wake_alarm,cap_dac_read_search", ""))
    fc = SystemCapabilitiesFactCollector()
    fc.collect(m)
    assert fc.get_facts()['system_capabilities_enforced'] == "False"
    assert fc.get_facts()['system_capabilities'] == ['cap_bluetooth',
                                                     'cap_net_raw',
                                                     'cap_sys_tty_config',
                                                     'cap_syslog',
                                                     'cap_wake_alarm',
                                                     'cap_dac_read_search']
   

# Generated at 2022-06-11 04:11:29.915590
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.utils.capabilities import get_caps_data, parse_caps_data
    import json

    data = get_caps_data()
    parsed = parse_caps_data(data)
    assert SystemCapabilitiesFactCollector().collect() == json.loads(json.dumps(parsed))

# Generated at 2022-06-11 04:11:39.163127
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test data
    out_e = 'Current: =epB'
    out_d = 'Current: =epBb'
    # Test code
    # Test enforcement
    Module = type('Module', (object,), {'run_command': lambda self, args: (0, out_e, ''),
                                        'get_bin_path': lambda self, arg: arg})
    module = Module()
    cap = SystemCapabilitiesFactCollector()
    facts = cap.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []
    # Test enforcement with capabilities

# Generated at 2022-06-11 04:11:45.964799
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub

    test_module = AnsibleModuleStub(
        dict(
            ANSIBLE_MODULE_ARGS={},
            ansible_facts={'system_capabilities': [], 'system_capabilities_enforced': 'NA'}
        )
    )

    tc = SystemCapabilitiesFactCollector()
    result = tc.collect(test_module)

    assert result['system_capabilities'] == []
    assert result['system_capabilities_enforced'] == 'NA'



# Generated at 2022-06-11 04:11:50.144310
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeModule(**{'ansible_capabilities':{'privileged': False}})
    facts = SystemCapabilitiesFactCollector().collect(module=module)
    expected = {'system_capabilities': ['cap_chown'], 'system_capabilities_enforced': 'True'}
    assert facts == expected


# Generated at 2022-06-11 04:11:59.336309
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.common.process import get_bin_path
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return get_bin_path(self, name)

        def run_command(self, cmd, errors):
            if name == 'capsh':
                # assume capsh is in $PATH
                path = self.get_bin_path("capsh")
                cwd = os.path.dirname(path)

# Generated at 2022-06-11 04:12:33.411880
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import json

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return os.path.join(os.path.dirname(__file__), 'mock_capsh')

        def run_command(self, arg, errors='surrogate_then_replace'):
            return 0, json.dumps(dict(arg=arg, errors=errors)), ''

    mock_module = MockModule()
    result = SystemCapabilitiesFactCollector(
        mock_module
    ).collect()
    assert result['system_capabilities_enforced'] == 'True'
    assert result['system_capabilities'] == ['cap_net_bind_service=ep', 'cap_sys_chroot=ep']

# Generated at 2022-06-11 04:12:41.930166
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import ModuleFacts
    from ansible.module_utils import facts

    class FakeModule(object):
        def get_bin_path(self, variable):
            return "/path/to/capsh"

        def run_command(self, args, errors='surrogate_then_replace'):
            return (0, "Current: =ep", "")

    class FakeCollector(BaseFactCollector):
        pass

    fake_module = FakeModule()
    fake_collector = FakeCollector(fake_module)
    fake_module.collect_facts = ModuleFacts(fake_module, facts.Facts)

    system_capabilities = SystemCapabilitiesFactCollector(fake_module)
    system_cap

# Generated at 2022-06-11 04:12:50.412751
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    class DummyModule:
        def get_bin_path(self, path):
            return '/path/bin/{0}'.format(path)


# Generated at 2022-06-11 04:13:00.016317
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Here we can use a mock module with mocked methods so that the tests are not
    actually executing commands on our system.
    """
    import sys
    import unittest
    import mock
    import json

    class Mock_AnsibleModule(object):
        def __init__(self, *args, **kwargs):

            self.params = kwargs
            self.exit_json = mock.Mock()
            #print("called AnsibleModule with args: " + str(args) + " and kwargs: " + str(kwargs))

        # By default always exits with error
        def exit_json(self, **kwargs):
            print("exited with: " + str(kwargs))
            sys.exit(1)


# Generated at 2022-06-11 04:13:00.695122
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:13:09.927306
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: setup for test
    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return 'test_capsh_path'
        def run_command(self, *args, **kwargs):
            return 0, 'Current: =ep', ''

    # NOTE: get object
    test_module = TestModule()
    sys_caps = SystemCapabilitiesFactCollector()

    # NOTE: assert that collect() was called with test_module as a param
    # it's a bit hacky way but I don't know any other
    # (if you do, please fix this)
    old_run_command = test_module.run_command
    def clbk(a, b, c, d):
        assert d == test_module

# Generated at 2022-06-11 04:13:19.014025
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import (patch, MagicMock)

    module = MagicMock()
    module.run_command.return_value = (0, 'Current: =ep\n', '')
    module.get_bin_path.return_value = 'capsh_path'
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module=module)
    assert facts == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

    module.run_command.return_value = (0, 'Current: =ep chown', '')
    module.get_bin_path.return_value = 'capsh_path'
    collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:13:29.436629
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: may be easier to use mock module instead of redefining classes
    import platform
    import datetime
    # NOTE: avoid 'self' parameter because we override the class itself
    # NOTE: logic to check if Capsh has been done in advance, so no need to mock
    class MockModule:
        def __init__(self):
            pass

        def get_bin_path(self, executable, required=True):
            return executable

        def run_command(self, command, errors='surrogate_then_replace'):
            return 0, 'Current: =ep', None

    module = MockModule()
    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(module)
    # NOTE: avoid '==' to check equality of dictionary

# Generated at 2022-06-11 04:13:35.350935
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from contextlib import closing

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

        def run_command(self, args, check_rc=None, errors='surrogate_then_replace'):
            capsh_out = None
            capsh_rc = None
            capsh_stderr = None

            if self.params['fail_run_command']:
                capsh_rc = 1


# Generated at 2022-06-11 04:13:43.236540
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ansible_module = MagicMock(AnsibleModule)
    ansible_module.get_bin_path.return_value = "capsh"
    ansible_module.run_command.return_value = (0, "Current: =ep", None)
    ansible_module_Utils_system_capabilities = AnsibleModuleUtilsSystemCapabilities()

    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(ansible_module=ansible_module, ansible_module_Utils_system_capabilities=ansible_module_Utils_system_capabilities)
    systemCapabilitiesFactCollector.collect()
    
    assert systemCapabilitiesFactCollector.collect() == {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }


# Generated at 2022-06-11 04:15:01.371590
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    platform.uname = lambda: ('', '', '', '', '', '')
    #
    # First test on Linux
    #
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    class FakeLinuxModule(ModuleStub):
        def get_bin_path(self, arg):
            return '/bin/capsh'

        def run_command(self, arg1, errors_to_stderr=False, **kwargs):
            assert arg1 == ['/bin/capsh', "--print"]
            assert errors_to_stderr

# Generated at 2022-06-11 04:15:07.624689
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    test_module = AnsibleModuleMock()
    test_module.run_command = Mock()
    test_module.run_command.return_value = [capsh_output]
    facts = fact_collector.collect(test_module)
    assert facts['system_capabilities'] == ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'audit_write', 'setfcap']
    assert facts['system_capabilities_enforced'] == 'True'


# Generated at 2022-06-11 04:15:15.885878
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import tempfile
    import module_utils.facts.system.capabilities
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    mock_module = mock.MagicMock(name='MockModule')
    mock_module.get_bin_path.return_value = '/usr/bin/capsh'

    tmp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 04:15:16.420506
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:15:24.638460
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def run_comm():
        out = '''Current: = cap_chown,cap_dac_override+eip cap_fowner,cap_fsetid+p
       Bounding set =cap_chown,cap_dac_override+eip cap_fowner,cap_fsetid+ep
       Securebits: 00/0x0/1'''
        return 0, out, ''

    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts.collector import get_collector_class

    cls = get_collector_class('SystemCapabilitiesFactCollector')
    c = cls()
    assert c.name == 'caps'

    assert c.collect(None) == {}

   

# Generated at 2022-06-11 04:15:33.615099
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import parse_caps_data
    import ansible.module_utils.facts.system.caps as capsutils
    import os
    import platform
    import shlex
    import shutil
    import tempfile
    import unittest

    # NOTE: "mock.patch" usage in this and following test methods modified from:
    #       https://docs.python-guide.org/writing/tests/
    class MockCheckCall(object):
        def __init__(self, return_value):
            self.return_value = return_value

# Generated at 2022-06-11 04:15:35.491957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # init
    module = None
    collector = SystemCapabilitiesFactCollector(module=module)

    # check
    assert collector.collect() == {}

# Generated at 2022-06-11 04:15:43.866602
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock(get_bin_path=Mock(return_value=True))
    capsh_out = """Capabilities for `/bin/bash'
 current: = cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_sys_chroot+ep
    Bounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_sys_chroot
    Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
    secure-no-suid-fixup: no (unlocked)
    secure-keep-caps: no (unlocked)
 """
   

# Generated at 2022-06-11 04:15:45.916080
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = {}
    result = SystemCapabilitiesFactCollector().collect(module, collected_facts)
    assert 'system_capabilities' in result


# Generated at 2022-06-11 04:15:53.617845
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test to test SystemCapabilitiesFactCollector::collect '''
    import tempfile
    import os
    import os.path
    import shutil

    from ansible.module_utils.facts import collector

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule:
        ''' Simple class to provide run_command() method required to test SystemCapabilitiesFactCollector::collect() '''
        def __init__(self, path):
            self.bin_path = path
        def get_bin_path(self, command):
            """ invoke this to get the full path of a command """
            if command in self.bin_path:
                return os.path.join(self.bin_path, command)
            return None