

# Generated at 2022-06-11 04:07:26.444424
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collectors.system.system_capabilities as system_capabilities

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        """
        Unit test for method collect of class SystemCapabilitiesFactCollector
        """

        class MyModule():
            """
            Class that simulates a module
            """

            def __init__(self):
                """
                Constructor
                """
                pass

            class MyRun:
                """
                Class that simulates a run
                """

                def __init__(self):
                    """
                    Constructor
                    """
                    pass


# Generated at 2022-06-11 04:07:27.326431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Unimplemented
    pass


# Generated at 2022-06-11 04:07:37.383594
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    m_base_fact_collector = mock.patch.object(BaseFactCollector, 'collect')
    m_base_fact_collector.return_value = {}
    import ansible.module_utils.facts.system.caps
    c_caps = ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector()
    m_module = mock.MagicMock()
    m_module.get_bin_path.return_value = 'bin/path'
    m_module.run_command.return_value = (0, 'Current: =ep', '')
    data = c_caps.collect(m_module, None)
    assert data['system_capabilities_enforced'] == 'False'
    assert data

# Generated at 2022-06-11 04:07:40.332627
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Testing if all the values are either None or not None
    try:
        # NOTE: 'fix' FactCollector.get_instance() to allow testing -akl
        caps_facts = SystemCapabilitiesFactCollector()
        assert caps_facts is not None
    except:
        assert False

# Generated at 2022-06-11 04:07:49.592977
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    import platform
    platform_system = platform.system()
    def _get_bin_path(self, binary_name):
        if binary_name == "capsh":
            return "/bogus/bin/capsh"
        return None

    def _run_command(self, args, **kwargs):
        return (0, "Current: =ep", "")

    class FakeModule(object):
        pass

    module = FakeModule()
    module.get_bin_path = _get_bin_path
    module.run_command = _run_command

    scc = SystemCapabilitiesFactCollector()
    results = scc.collect(module)
    if platform_system == "Linux":
        assert results['system_capabilities'] == []

# Generated at 2022-06-11 04:07:59.507467
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mocking module
    class ModuleFake:
        def get_bin_path(self, arg):
            return '/bin/capsh'


# Generated at 2022-06-11 04:08:09.352498
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # No mock module
    caps_fc = SystemCapabilitiesFactCollector()
    # no facts
    assert set() == caps_fc.collect()

    # mock module
    caps_fc = SystemCapabilitiesFactCollector()
    caps_fc.module = AnsibleDummyModule()
    caps_fc.module.run_command = AnsibleDummyRunCommand()
    caps_fc.module.run_command(['/usr/bin/capsh','--print'], errors='surrogate_then_replace')
    facts_dict = caps_fc.collect()
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict
    assert facts_dict['system_capabilities'] == ['cap_net_raw+eip']

# Generated at 2022-06-11 04:08:15.393174
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import ansible.module_utils.facts.collectors.system.system_capabilities as system_capabilities
    reload(system_capabilities)
    fake_system_capabilities_module = mock.Mock()
    fake_system_capabilities_module.run_command.return_value = (0, "Current: =ep", "")
    system_capabilities_collector = system_capabilities.SystemCapabilitiesFactCollector()
    result = system_capabilities_collector.collect(module=fake_system_capabilities_module)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Generated at 2022-06-11 04:08:25.740078
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock(get_bin_path=Mock(return_value='/bin/capsh'))

# Generated at 2022-06-11 04:08:34.960620
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import fallback
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system.caps as SCFC


# Generated at 2022-06-11 04:08:44.917423
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_path = "/bin/capsh"
    # Setup test data

# Generated at 2022-06-11 04:08:54.878792
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m_module = MagicMock()

# Generated at 2022-06-11 04:09:04.921542
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CapabilityModule
    import os
    import tempfile

    def mock_run_command(module, argv=None, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict', text=None, tmpdir=None, create_tmpfile_flags='w+b', create_tmpfile_mode='0644', delegate_to=None, environment=None, socket_path=None, addl_env=None):
        return 0, 'Current: =eip\n', None
    CapabilityModule.run_

# Generated at 2022-06-11 04:09:14.403495
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Set up the class, mock module and parameters.
    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    module=None

    # Test the collect method with a capsh_path
    fact_collector.get_bin_path=lambda bin_path: True

# Generated at 2022-06-11 04:09:24.046310
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    from collections import namedtuple
    import pytest

    # NOTE: not mocking module.get_bin_path()
    TestModule = namedtuple('TestModule', ['run_command'])

    def get_bin_path(binary):
        if binary == 'capsh':
            return ''

    monkeypatch.setattr(collector, 'get_bin_path', get_bin_path)
    monkeypatch.setattr(collector, 'CAPSH_PATH', 'capsh')


# Generated at 2022-06-11 04:09:33.197682
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:09:40.486431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    BaseFactCollector.collect = lambda self, module, collected_facts=None: {}
    collector.collector.collect = lambda self, module, collected_facts=None: {}

    import ansible.module_utils.facts.platform.system_capabilities

    test_obj = ansible.module_utils.facts.platform.system_capabilities.SystemCapabilitiesFactCollector()
    assert test_obj.collect() == {}


# Generated at 2022-06-11 04:09:47.603328
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MockModule()

# Generated at 2022-06-11 04:09:49.306855
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #NOTE: auto-convert parametrized test to pytest parametrize
    # above, since pytest can handle extra parameters.
    pass

# Generated at 2022-06-11 04:09:58.429762
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils._text
    import module_utils.common
    import module_utils.linux
    import module_utils
    import module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.linux
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.common
    import ansible.module_utils.facts.system.distribution.arch


# Generated at 2022-06-11 04:10:13.290505
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use mock module instead to avoid mocking in subclasses -akl
    mock_module = MagicMock(return_value=None)

    mock_module.run_command.return_value = (0, 'Current: =ep', '')

    x = SystemCapabilitiesFactCollector()
    x.collect(mock_module)

    assert mock_module.run_command.call_count == 1

    mock_module.run_command.assert_called_with([
        mock_module.get_bin_path.return_value,
        '--print'
    ], errors='surrogate_then_replace')
    assert x.name == 'caps'
    assert x._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert x.collect_fn == x.collect

# Generated at 2022-06-11 04:10:17.343626
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test the collect method of SystemCapabilitiesFactCollector
       module. The test relies on capsh CLI tool.
    """
    module = AnsibleModule(
        argument_spec = dict()
    )
    collector = SystemCapabilitiesFactCollector(module=module)
    facts = collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 04:10:19.903576
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(None, {})
    assert result == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-11 04:10:30.510697
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Test that fact 'system_capabilities' is correct. """
    import tempfile
    import os
    import inspect


# Generated at 2022-06-11 04:10:38.527527
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: refactor to use test_utils and pytest. -akl

    from ansible.module_utils.facts.collector.capsh import SystemCapabilitiesFactCollector
    from ansible.module_utils.basic import AnsibleModule, run_command

    def mock_run_command(*args, **kwargs):
        assert args[0][0] == 'capsh'
        assert args[0][1] == '--print'
        return (0, 'Current: =ep\nBounding set =ep cap_setpcap,\nSecurebits: 00/0x0/1\nsecure-noroot: no (unlocked)\nsecure-no-suid-fixup: no (unlocked)\nsecure-keep-caps: no (unlocked)\nuid=0(root)', '')


# Generated at 2022-06-11 04:10:39.313970
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: Add unit tests
    pass

# Generated at 2022-06-11 04:10:48.011964
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule:
        def __init__(self):
            self.run_command_results = (0, 'foo', '')

        def get_bin_path(self, *args, **kargs):
            return '/bin/capsh'

        def run_command(*args, **kargs):
            return MockModule.run_command_results

    module = MockModule()
    module.run_command_results = (0, 'Current: =ep', '')
    collector = SystemCapabilitiesFactCollector.collect
    collected_facts = collector(module)
    assert collected_facts == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

    module.run_command_results = (0, 'Current: =ep cap_net_bind_service', '')
    collector = SystemCapabilitiesFactCollect

# Generated at 2022-06-11 04:10:57.044254
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        test_run = True
        def get_bin_path(self, *_):
            return '/path/to/capsh'
        def run_command(self, args, errors):
            if args[0] == '/path/to/capsh':
                if not self.test_run:
                    return 1, '', 'Error'

# Generated at 2022-06-11 04:10:58.251030
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Dummy test
    """
    MOD_UTIL_PATH = 'ansible.module_utils.facts.system.capabilities.{0}'
    pc = SystemCapabilitiesFactCollector()
    pc.collect()


# Generated at 2022-06-11 04:11:07.158121
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    capsh_path = '/usr/bin/capsh'
    out = '''
Capabilities for `/usr/bin/sshd' cap_net_raw+p
  Current: =ep
  Inheritable: =ep
  Bounding set =cap_net_raw,cap_net_bind_service
  Securebits: 00/0x0/1'b0
  secure-noroot: no (unlocked)
  secure-no-suid-fixup: no (unlocked)
  secure-keep-caps: no (unlocked)
  uid=0(root)
  gid=0(root)
  groups=0(root)
'''
    err = ''
    rc = 0

# Generated at 2022-06-11 04:11:26.165492
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    mock_module = Mock(name="module",
                       params={},
                       get_bin_path=Mock(return_value="/usr/bin/capsh"))

    mock_run_command = Mock(return_value=(0, "Current: =ep\nBounding set =ep\nSecurebits: 00/0x0/1'b0", ""))
    mock_module.run_command = mock_run_command

    result = SystemCapabilitiesFactCollector().collect(mock_module)
    assert "system_capabilities_enforced" in result
    assert result["system_capabilities_enforced"] == 'False'
    assert "system_capabilities" in result
    assert result["system_capabilities"] == []


# Generated at 2022-06-11 04:11:27.303099
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("test_SystemCapabilitiesFactCollector_collect not implemented")

# Generated at 2022-06-11 04:11:35.009393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from platform import system
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    if system() != 'Linux':
        return

    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    module.params = {}
    module.run_command = lambda cmd, data=None, **kwargs: (0, b'Current: =ep', b'')

    caps = SystemCapabilitiesFactCollector()
    result = caps.collect(module=module, collected_facts=dict())
    assert type(result['system_capabilities']) is list
    assert result['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:11:44.481114
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    assert sys.version_info.major == 2
    # No error when capsh_path is None
    # set up test environment:
    module = DummyModule()
    module.get_bin_path = DummyGetBinPath()
    module.run_command = DummyRunCommand()
    collector = SystemCapabilitiesFactCollector(module)
    facts = collector.collect()
    # assert facts == {}
    # assert facts['system_capabilities_enforced'] is None
    # assert facts['system_capabilities'] is None
    # No error when capsh_path is not None
    # set up test environment:
    module.get_bin_path.path = 'dummy_path'
    module.get_bin_path.__call__.return_value = module.get_bin_path.path
    #

# Generated at 2022-06-11 04:11:51.207860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock module
    class MockModule(object):
        def get_bin_path(self, app):
            return None

        def run_command(self, args, errors='surrogate_then_replace'):
            return None, None, None

    facts_dict = {}
    module = MockModule()
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(module=module, collected_facts=facts_dict)

    assert result and 'system_capabilities' not in result and 'system_capabilities_enforced' not in result


# Generated at 2022-06-11 04:11:51.757167
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:12:01.241547
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create mock module
    mock_module = AnsibleModuleMock()


# Generated at 2022-06-11 04:12:09.952010
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: could be moved to a doctest style test case...
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):

        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.exit_json = kwargs.get('exit_json', None)
            self.fail_json = kwargs.get('fail_json', None)
            self.run_command = kwargs.get('run_command', None)
            self.params = kwargs.get('params', None)
            self.called = 0
            self.changed = False


# Generated at 2022-06-11 04:12:19.294048
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:12:21.182504
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:12:54.747803
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import Mock as MagicMock

    def get_caps_data(capsh_path, capsh_args, errors):
        class Mock_Stream(object):
            def read(self):
                return 'Current: =ep\n'
        return 0, Mock_Stream(), Mock_Stream()

    module = MagicMock()
    module.get_bin_path.return_value = '/bin/capsh'
    module.run_command.side_effect = get_caps_data
    module.__name__ = '__name__'

    collector = SystemCapabilitiesFactCollector()
    actual = collector.collect(module)
    assert actual['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:13:04.202500
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''

    test_module = AnsibleModule({})

# Generated at 2022-06-11 04:13:13.172332
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:13:23.733128
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_bytes

    module = AnsibleModuleMock()
    capsh_mock = 'Current: = cap_chown,cap_fowner+eip \nBounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid+ep \nSecurebits: 00/0x0/1'
    capsh_mock_2 = 'Current: = cap_chown,cap_fowner+eip \nBounding set =cap_chown+ep'

# Generated at 2022-06-11 04:13:32.238649
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import System
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    test_subject = SystemCapabilitiesFactCollector()

    test_module = type('FakeModule', (), {
        'run_command': lambda s, c, errors='replace': (
            0,
            get_file_content(
                '%s/unit/system_capabilities_output_sample.txt' % os.path.dirname(__file__)
            ),
            ''
        ),
        'get_bin_path': lambda s, b: 'dummy'
    })

    test_collect

# Generated at 2022-06-11 04:13:38.035018
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  from ansible.module_utils.facts import FactCollector, BaseFactCollector
  from ansible.module_utils._text import to_text
  from ansible.module_utils.common.process import get_bin_path
  import os
  import pytest

  class MockModule(object):
    def __init__(self):
      self._bin_path = None # so we don't call get_bin_path() during initialization


# Generated at 2022-06-11 04:13:46.790816
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mainly testing dummy data not a real implementation
    import json
    import tempfile
    # Setup

# Generated at 2022-06-11 04:13:53.315920
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: set up mock for module argument
    mock_module = MagicMock()
    mock_module.run_command = MagicMock(
        # NOTE: set up mock for module.run_command()
        return_value=(0, 'Current: =ep', '')
    )

    # NOTE: instantiate class
    fact_collector = SystemCapabilitiesFactCollector()

    # NOTE: run collect()
    result = fact_collector.collect(mock_module)

    # NOTE: assert result
    assert result == {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }

# Generated at 2022-06-11 04:13:58.191934
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def fake_get_bin_path(name, opt_dirs=[]):
        return "/bin/capsh"

    module = FakeAnsibleModule({})
    module.get_bin_path = fake_get_bin_path

    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()
    c.collect(module=module)

# Unit tests for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:14:03.257079
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import Collector

    collected_facts = Collector().collect(module=None, collected_facts=None)
    fact_collector = SystemCapabilitiesFactCollector(None, collected_facts, None)

    # In python 3.5, returned 'False' string (not a boolean value False)
    assert fact_collector.collect() == {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-11 04:15:19.254095
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils import basic
    import copy
    import json
    import sys

    # NOTE: using module, module_util, ansible to access 'ansible' modules!
    #       -> this is normal since it will actually be called that way!
    module = basic._ANSIBLE_ARGS
    module.params = dict(gather_subset=[SystemCapabilitiesFactCollector.name])
    #module.params.update(dict(gather_timeout=2))

    facts_collector = SystemCapabilitiesFactCollector(module=module)
    collected_facts = Facts(module=module)

    assert facts_collector is not None

# Generated at 2022-06-11 04:15:27.941082
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Preparations
    module = MagicMock()
    collected_facts = {}
    expected_result = {'system_capabilities': [],
                       'system_capabilities_enforced': 'NA'}

    # Test 1
    capsh_path = None

    fact_collector = SystemCapabilitiesFactCollector()
    ret_val = fact_collector.collect(module, collected_facts)

    # Assertions
    assert ret_val == expected_result

    # Test 2
    capsh_path = '/path/to/capsh'

    module.run_command = MagicMock(return_value=(0, 'Current: =eip', ''))
    module.get_bin_path = MagicMock(return_value=capsh_path)


# Generated at 2022-06-11 04:15:31.993155
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    out = test_collector.collect(None, collected_facts)
    assert len(out) == 2
    assert out['system_capabilities_enforced'] == 'NA'
    assert out['system_capabilities'] == None
    return True

# Generated at 2022-06-11 04:15:40.484587
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector

    # create a mock class of module_utils.facts.collector.BaseFactCollector
    class MockFactCollector(BaseFactCollector):
        name = 'mock_fact'
        _fact_ids = set(['mock_fact'])

        def collect(self, module=None, collected_facts=None):
            facts_dict = {'mock_fact': False}
            return facts_dict

    mock_fact_collector = MockFactCollector()

# Generated at 2022-06-11 04:15:48.558595
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Creating a mock module
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value='/usr/bin/capsh')

# Generated at 2022-06-11 04:15:49.882461
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # call method collect of class SystemCapabilitiesFactCollector
    SystemCapabilitiesFactCollector().collect()



# Generated at 2022-06-11 04:15:53.343542
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = type('module', (object,), dict(run_command=lambda x, y: (0, 'Current: =ep', '')))

    facts = SystemCapabilitiesFactCollector().collect(module=module)

    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:16:01.647958
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import textwrap
    import subprocess
    import ansible.module_utils.facts.system.base

    # I need to be able to test to see if a subprocess is running

# Generated at 2022-06-11 04:16:10.537201
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import namespace_facts
    module = namespace_facts.BaseFactsCollectionModule()

    class mock_run_command():
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return self.rc, self.out, self.err


# Generated at 2022-06-11 04:16:18.258451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mocking.patching the module to return a expected value
    import ansible.module_utils.facts.collector.network

    def dummy_get_bin_path(a):
        return 'capsh'

    def dummy_run_command(a, b):
        return 0, "Current: =ep\nSecurebits: 00/0x0/1'b0 secure-noroot", ''

    from ansible.module_utils.facts.collector.capabilities import SystemCapabilitiesFactCollector

    SystemCapabilitiesFactCollector.name = 'caps'

    ansible.module_utils.facts.collector.capabilities.ansible.module_utils.facts.collector.capabilities.get_bin_path = dummy_get_bin_path
    ansible.module_utils.facts.collector.capabilities.ansible.module_utils