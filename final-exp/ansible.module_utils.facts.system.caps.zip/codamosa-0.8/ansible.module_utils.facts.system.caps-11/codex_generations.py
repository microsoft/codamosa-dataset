

# Generated at 2022-06-11 04:07:17.648383
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # gather facts
    c = SystemCapabilitiesFactCollector()
    facts = c.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 04:07:27.160354
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DummyModule()
    capsh_path = module.get_bin_path('capsh')
    enforced = 'True'

# Generated at 2022-06-11 04:07:36.121131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock module
    module = MockedModule()

    # mock run_command() and get_bin_path()
    module.run_command = lambda x, **kwargs: (0, 'Current: =ep\nsecure-bits:', '')
    module.get_bin_path = lambda x: '/bin/capsh'

    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = fact_collector.collect(module=module)

    # assert that there are no errors
    assert collected_facts['ansible_facts']['system_capabilities_enforced'] == 'False'
    assert collected_facts['ansible_facts']['system_capabilities'] == []



# Generated at 2022-06-11 04:07:39.091071
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    c = SystemCapabilitiesFactCollector()
    facts = {'system_capabilities': ['NET_BIND_SERVICE'], 'system_capabilities_enforced': 'True'}
    assert c.collect() == facts


# Generated at 2022-06-11 04:07:47.958685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # set up mock module for test
    module_mock = AnsibleModule(
        argument_spec = dict()
    )
    module_mock.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    module_mock.get_bin_path = MagicMock(return_value='/usr/bin/capsh')
    module_mock.run_command.side_effect = [(0, 'Current: =ep', ''), (0, 'Current: =ep', ''), (0, '', ''), (1, '', '')]

    # set up SUT
    sut = SystemCapabilitiesFactCollector()

    # call method collect of class SystemCapabilitiesFactCollector
    output = sut.collect(module_mock)

    assert output['system_capabilities_enforced']

# Generated at 2022-06-11 04:07:57.573275
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Set up a dummy module
    module = Mock()
    module.get_bin_path = Mock()
    # Set up a dummy fact collector
    fact_collector = SystemCapabilitiesFactCollector(module=module)
    # Set up a dictionary of fake collected facts
    collected_facts = dict()

    # Mock a failing call to capsh
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (1, '', 'None')
    # Run the collect method
    result = fact_collector.collect()
    # Check that the module was called as expected
    module.run_command.assert_has_calls([
        call(['/usr/bin/capsh', '--print'], errors='surrogate_then_replace'),
    ])


# Generated at 2022-06-11 04:08:07.790815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.utils.platform
    from ansible.module_utils.facts import collector

    collecting_subset = ['system_capabilities',
                         'system_capabilities_enforced']

    # class FactCollector(object)
    # _collectors = {'SystemCapabilitiesFactCollector', 'BaseFactCollector'}

    collector._collectors['SystemCapabilitiesFactCollector'] = [
        SystemCapabilitiesFactCollector()
    ]

    # class BaseFactCollector(object)
    # __name__ = 'SystemCapabilitiesFactCollector'
    # name = 'SystemCapabilitiesFactCollector'
    # _fact_ids = ['_fact_ids']

    # class SystemCapabilitiesFactCollector(BaseFactCollector)
    # _fact_ids = ['system_capabilities', 'system_capabilities_enforced']



# Generated at 2022-06-11 04:08:15.342890
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test SystemCapabilitiesFactCollector.collect
    '''
    try:
        from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    except ImportError:
        import pytest
        pytestmark = pytest.mark.skip(
            "Could not import module_utils.facts.collector.system.capabilities.SystemCapabilitiesFactCollector")

    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    #
    # Workaround for https://github.com/pytest-dev/pytest/issues/2011
    #
    collector = SystemCapabilitiesFactCollector()
    #
    # NOTE: more of a black box test than a unit test.

# Generated at 2022-06-11 04:08:25.687771
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import os
    import gc

    # Suppress log output during test runs
    # NOTE: 'capsh' is not present on Travis-CI's Vagrant boxes
    #       -> mock it out/test only the parsing of 'capsh' output

# Generated at 2022-06-11 04:08:34.918497
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test case with caps enforced
    test_module = MockModule()
    test_module.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    capscollector = SystemCapabilitiesFactCollector()
    fact_result = capscollector.collect(module= test_module)
    assert fact_result['system_capabilities_enforced'] == 'False', 'Test failed'
    assert fact_result['system_capabilities'] == [], 'Test failed'

    # Test case with caps enforced but no leading '='

# Generated at 2022-06-11 04:08:44.821565
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_class

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import PSUtilSystemCollector

# Generated at 2022-06-11 04:08:46.122100
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: good candidate for testing with mocks/fakefs -akl
    pass

# Generated at 2022-06-11 04:08:56.371670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector

    module = SystemFactCollector.get_module()
    module.run_command = lambda x, check_rc=True, close_fds=True, executable=None: (0, 'Current: =ep', '')
    mock_module = SystemFactCollector.get_module()
    mock_module.run_command = lambda x, check_rc=True, close_fds=True, executable=None: (0, 'Current: =ep', '')

    collector = SystemCapabilitiesFactCollector(module)
    data = collector.collect(module, CollectedFacts())

    assert data

# Generated at 2022-06-11 04:09:04.103011
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock module to get side effects
    module = Mock(return_value=None)
    module.get_bin_path.return_value = "unittest_path"

    try:
        SystemCapabilitiesFactCollector(module=module).collect()
    except Exception:
        raise AssertionError("Any exception raised during execution of SystemCapabilitiesFactCollector.collect")

    module.get_bin_path.assert_called_with('capsh', False)
    module.run_command.assert_called_with(["unittest_path", "--print"], errors='surrogate_then_replace')


# Generated at 2022-06-11 04:09:09.009304
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create mock module/system environment for unit test
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False)

    # Create instance of class SystemCapabilitiesFactCollector
    fact_collector = SystemCapabilitiesFactCollector()

    # Run test method collect of class SystemCapabilitiesFactCollector
    facts = fact_collector.collect(module)
    assert type(facts) is dict

# Generated at 2022-06-11 04:09:18.175890
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    current = '=ep'
    enforced = 'False'

# Generated at 2022-06-11 04:09:28.203167
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test that the collector method is getting the capabilities.
    """
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch
    import os

    module_path = os.path.sep.join(['ansible_collections',
                                    'notmintest',
                                    'not_a_real_collection',
                                    'plugins',
                                    'modules',
                                    'system',
                                    'capabilities.py'])

# Generated at 2022-06-11 04:09:37.649388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collectors.system.system_capabilities as system_capabilities


# Generated at 2022-06-11 04:09:39.373782
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: write unit tests for SystemCapabilitiesFactCollector.collect() -akl
    pass

# Generated at 2022-06-11 04:09:45.396174
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import FactsHelper

    collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    helper = FactsHelper(module=None)
    helper.populate_facts(collector.collect(module=None, collected_facts=collected_facts))
    assert helper.facts == {'system_capabilities': 'NA', 'system_capabilities_enforced': 'NA'}


if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-11 04:09:59.954966
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    obj = SystemCapabilitiesFactCollector()
    
    import os
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    
    
    class TestModule(object):
        def get_bin_path(self, arg):
            if arg == "capsh":
                path = "capsh"
                return arg
            
        def run_command(self, arg, **kwargs):
            rc = os.EX_OK

# Generated at 2022-06-11 04:10:03.176768
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = {}
    s = SystemCapabilitiesFactCollector()
    c = {}
    f = s.collect(m, collected_facts=c)
    assert f['system_capabilities_enforced'] == 'NA'

# Generated at 2022-06-11 04:10:12.800117
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock Ansible module
    # Load the system_capabilities module
    SystemCapabilitiesModuleMock = lambda: None
    SystemCapabilitiesModuleMock.run_command = lambda self, command, errors: (0, '', '')
    SystemCapabilitiesModuleMock.get_bin_path = lambda self, command: '/usr/bin/capsh'
    module = SystemCapabilitiesModuleMock()

    # Run the collect method
    fact = SystemCapabilitiesFactCollector().collect(module)
    # Check that the collected fact system_capabilities exists
    assert 'system_capabilities' in fact
    # Check that the collected fact system_capabilities is a list
    assert isinstance(fact['system_capabilities'], list)
    # Check that the collected fact system_capabilities_enforced exists

# Generated at 2022-06-11 04:10:22.041319
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        def __init__(self , *args , **kwargs):
            super(FakeSystemCapabilitiesFactCollector, self).__init__( *args , **kwargs )
            self.data = {}
    BaseFactCollector._collectors.append(FakeSystemCapabilitiesFactCollector)
    ansible_collector._COLLECTORS.append(FakeSystemCapabilitiesFactCollector)
    SYSTEM_CAPABILITIES_FACT_COLLECTOR = FakeSystemCapabilitiesFactCollector()

    assert SYSTEM_CAPABILITIES_FACT_COLLECTOR.name == 'caps'
    assert SYSTEM_CAPABILITIES_FACT_

# Generated at 2022-06-11 04:10:24.824892
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    fc = SystemCapabilitiesFactCollector()
    fc.collect()

# Generated at 2022-06-11 04:10:32.169434
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = mock.MagicMock()
    module.get_bin_path.return_value = 'capsh'
    module.run_command.return_value = (0, 'Current: =ep', '')

    result = collect_system_capabilities(module)

    module.run_command.assert_called_once_with([module.get_bin_path.return_value, "--print"], errors='surrogate_then_replace')
    assert result == {'system_capabilities_enforced': 'False',
                      'system_capabilities': []}

# Generated at 2022-06-11 04:10:39.150948
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import CollectorUnsupportedModule
    from ansible.module_utils.facts.collector import CollectorExecutableNotFound

    # NOTE: I don't (yet) like the fact that this is so different...
    class FakeCapshModule(object):
        args = {'capsh_path': None}
        params = {}
        def get_bin_path(self, executable):
            return self.args.get('capsh_path')


# Generated at 2022-06-11 04:10:47.863439
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.collector.system as system
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.collector = system.SystemCapabilitiesFactCollector(module=patch('ansible.module_utils.facts.ansible_collector.AnsibleModule')(
                argument_spec={},
                supports_check_mode=True,
            ))
           

# Generated at 2022-06-11 04:10:56.843667
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock module object
    class MockModule:
        def __init__(self, capsh_path):
            self.capsh_path = capsh_path
        def get_bin_path(self, path):
            return self.capsh_path
        def run_command(self, command, errors):
            return (0, command[0], "")

    # Create a mock module object with capsh path
    module_with_capsh_path = MockModule("/usr/bin/capsh")
    # Create an instance of SystemCapabilitiesFactCollector
    fact_collector = SystemCapabilitiesFactCollector()

    # Call the object's collect method with a mock module object
    fact_collector.collect(module_with_capsh_path)
    
    # Create a mock module object without capsh path
    module_without

# Generated at 2022-06-11 04:11:05.745559
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    enabled_caps = ['=ep', '=eip']
    disabled_caps = ['=ep', '=eip', '=pE']
    disabled_caps_str = '=ep, =eip, =pE'
    enabled_output = 'Current: =ep'
    disabled_output = 'Current: =ep, =eip, =pE'
    lf = '\n'
    c = SystemCapabilitiesFactCollector()
    # NOTE: capsh_path = module.get_bin_path('capsh')
    c.module = MagicMock(get_bin_path=MagicMock(return_value='/usr/bin/capsh'))

    # NOTE: rc, out, err = module.run_command(..)
    #       -> so we mock module.run_command() to return a tuple
   

# Generated at 2022-06-11 04:11:24.851523
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import sys

    if sys.version_info[0] == 3:
        basestring = (str, bytes)

    import ansible.module_utils.facts.collector

    class FakeModuleUtil(object):
        def __init__(self):
            self.capsh_path = '/path/to/capsh'
            self.run_command_called = False

        def get_bin_path(self, __):
            return self.capsh_path

        def exists(self, __):
            return True

        def run_command(self, __, **kwargs):
            self.run_command_called = True
            if self.capsh_path:
                return 0, 'Current: =ep', ''
            return 0, 'Current: =eip', ''


# Generated at 2022-06-11 04:11:27.617506
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: see test_capsh_data() in test_system_capabilities.py -akl
    # TODO: mock capsh_path, module.run_command(), module -> return values for capsh_data() -akl
    pass

# Generated at 2022-06-11 04:11:31.844338
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    collector = SystemCapabilitiesFactCollector(module=module)
    collected_facts = collector.collect()

    assert collected_facts['system_capabilities'] == ['']
    assert collected_facts['system_capabilities_enforced'] == 'False'
    assert len(collected_facts) == 2


# Generated at 2022-06-11 04:11:41.225062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Set-up mocks and required fixtures/data
    module = namedtuple('module', ['run_command', 'get_bin_path'])
    module_inst = module(run_command=lambda x, errors=None: (0, '', ''),
                         get_bin_path=lambda x: '/bin/capsh')

    collect_inst = SystemCapabilitiesFactCollector(module_inst)
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl

    # Run code being tested
    result = collect_inst.collect()

    # Verify results/exceptions
    # NOTE: -> validate_caps_data(caps_data) -akl
    # NOTE: early exit '

# Generated at 2022-06-11 04:11:50.511118
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:11:59.829450
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils._text import to_bytes

    # set up

# Generated at 2022-06-11 04:12:05.269737
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    import pytest
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import BaseFactCollector
    fact_collector = SystemCapabilitiesFactCollector()
    assert issubclass(get_collector_class('system_capabilities'), BaseFactCollector)


# Generated at 2022-06-11 04:12:14.025216
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import unittest
    from unittest.mock import patch
    import collections
    import contextlib
    import os
    import sys

    # Initialize test class
    class SystemCapabilitiesFactCollector_test(unittest.TestCase):
        @classmethod
        def setUp(self):
            self.system_capabilities = collections.namedtuple('system_capabilities', 'system_capabilities_enforced system_capabilities')

        def tearDown(self):
            pass


# Generated at 2022-06-11 04:12:23.397409
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collection
    from ansible.module_utils.facts.collector import FactCollector

    # create test environment
    capsh_path = "/usr/libexec/secrets/capsh"
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda _: capsh_path
    def run_command(_, errors='surrogate_then_replace'):
        # NOTE: basically a 'mock' for system "capsh --print"
        rc = 0

# Generated at 2022-06-11 04:12:24.742000
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: write unit test
    return True

# Generated at 2022-06-11 04:12:57.106035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Test for SystemCapabilitiesFactCollector.collect().'''

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector

    # arrange

# Generated at 2022-06-11 04:13:06.436403
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    This test uses the AnsibleModule fixtures from ansible/test/utils.py
    It loads a test YAML file and returns a dictionary
    '''
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector

    # Build a class object for method collect() for easy testing
    TO = SystemCapabilitiesFactCollector()
    module = AnsibleModule(argument_spec={})

    # System capsh is available and capability is enforced
    TO.module = module
    TO.module.run_command = mock.MagicMock(return_value=(0, 'Current: =ep', ''))
    facts = TO.collect()
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

    # System capsh is available and no capabilities are

# Generated at 2022-06-11 04:13:12.292054
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile

    temp = tempfile.NamedTemporaryFile()
    temp.write('Current:\n  =ep')
    temp.seek(0)

    module = FakeAnsibleModule(
        command=temp.name,
        command_response=('', '', 0),
        params={}
    )

    fact_collector = SystemCapabilitiesFactCollector(module=module)
    facts = fact_collector.collect()
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:13:22.636027
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import ansible.utils.module_docs as module_docs

    # Setup in memory 'modules/<modulename>.py' as required by
    # ansible.module_utils.basic.get_module_path()
    sys.modules['ansible'] = type('FakeModule', (object,), {
            '__file__':
            os.path.join(os.path.dirname(module_docs.__file__), '__init__.py')
    })
    from ansible.module_utils.facts.collector import get_collector_module
    SystemCapabilitiesFactCollector = get_collector_module('SystemCapabilitiesFactCollector')

    # Setup required constants for function test
    capsh_path = '/usr/bin/capsh'

# Generated at 2022-06-11 04:13:26.800731
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    collectr = SystemCapabilitiesFactCollector(module)
    returned_facts = collectr.collect()
    assert returned_facts == {'system_capabilities_enforced': 'True',
             'system_capabilities': ['cap_kill', 'cap_net_admin']}


# Generated at 2022-06-11 04:13:34.404904
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = AnsibleModule(
        argument_spec = dict(),
    )

    Facts = namedtuple('Facts', ('all', 'collectors', 'dumper'))
    facts = Facts(all={}, collectors=[], dumper=None)

    # Create a test instance of SystemCapabilitiesFactCollector
    test_instance = SystemCapabilitiesFactCollector()

    # Test that all of the defined '_fact_ids' in SystemCapabilitiesFactCollector
    #    are returned with collect() method

# Generated at 2022-06-11 04:13:41.904658
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def mock_version_output(module):
        return {
            "capsh": "/usr/bin/capsh",
            "python": "/usr/bin/python"
        }


# Generated at 2022-06-11 04:13:50.739028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_rc_success = 'Current:\t= cap_sys_chroot+ep'
    capsh_rc_false = 'Current:\t=ep'
    capsh_rc_none = 'Current:\t='
    capsh_rc_invalid = 'Current:\t=ep abc'
    capsh_rc_unknown = 'Current:\t='
    capsh_rc_empty = ''
    collector = SystemCapabilitiesFactCollector()
    module = MagicMock()
    module.run_command.return_value = (0, capsh_rc_success, "")
    collector.collect(module)
    module.run_command.assert_called_with([module.get_bin_path.return_value, "--print"], errors='surrogate_then_replace')
    assert module.run_command.called

# Generated at 2022-06-11 04:13:51.314557
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:13:59.106385
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' setup some return values, run the method and verify results'''

    class DummyMod:
        def get_bin_path(self, arg):
            return('/bin/capsh')

        def run_command(self, args, errors):
            if errors:
                return(0, 'Current: =ep', '')
            else:
                return(0, 'Current: =ep', '')

    class DummyFacts:
        def __init__(self, args):
            self.facts_dict = args

        def __iter__(self):
            return iter(self.facts_dict.items())

    mod = DummyMod()
    # run the collect method and verify results

# Generated at 2022-06-11 04:15:07.986877
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: need to mock module (for module_utils.facts.utils.get_file_content)
    #       and module.run_command -akl
    pass

# Generated at 2022-06-11 04:15:15.921381
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
        Unit test for method collect of class SystemCapabilitiesFactCollector
    """

    module = Mock()
    module.run_command.return_value = 0, 'Current: =ep', ''
    module.get_bin_path.return_value = 'capsh'
    module.EXTRA_BIN_PATH = ''
    module.CURSOR_UP_ONE = ''
    module.ERASE_LINE = ''
    module.get_bin_path = lambda x: module.get_bin_path(x)
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module=module)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-11 04:15:23.765040
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/capsh'

# Generated at 2022-06-11 04:15:24.600927
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:15:33.577277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    module_mock = type('module_mock', (object,), {
        'run_command': run_command_mock,
        'get_bin_path': get_bin_path_mock,
        'file_exists': file_exists_mock,
        'sys_executable_mock': sys.executable,
        'exit_json': ExitJson,
        'fail_json': FailJson,
        'check_mode': False,
    })()
    facts_dict = SystemCapabilitiesFactCollector().collect(module=module_mock)
    assert len(facts_dict) == 2
    assert facts_dict['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-11 04:15:42.034830
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_obj = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:15:49.598723
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    module.run_command = MagicMock(return_value=(0, "Current: =ep", ""))
    ansible_collector.module = module
    system_capabilities = SystemCapabilitiesFactCollector()
    result = system_capabilities.collect()

    # Result is a dictionary
    assert result.__class__ == dict
    # Result contains the 'system_capabilities_enforced' key
    assert result.has_key('system_capabilities_enforced')
    # Result contains the 'system_capabilities' key
    assert result.has_key('system_capabilities')

# Generated at 2022-06-11 04:15:57.619886
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import collections
    import sys

    if sys.version_info.major == 2:
        MockModule = collections.namedtuple('MockModule', ['run_command', 'get_bin_path'])
    elif sys.version_info.major == 3:
        class MockModule:
            def __init__(self, run_command, get_bin_path):
                self.run_command = run_command
                self.get_bin_path = get_bin_path

# Generated at 2022-06-11 04:16:06.666941
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys

    # All the code in this file will be executed while the Ansible
    # environment is first initialized.  As a result, all imports
    # that are not part of the standard library (to ensure they are
    # available for use when Ansible is imported) must force
    # Python to load them.

    # The following modules are only available on UNIX-like systems,
    # so only load them on this OS.
    if os.name == 'posix':
        import pwd
        import grp

    mock_module = MockModule()

    # Create a SystemCapabilitiesFactCollector instance.
    system_caps_fact_collector = SystemCapabilitiesFactCollector()

    # Call the collect method with a mock module and an empty collected_facts
    # dict.
    collected_facts = system_caps_fact_collect

# Generated at 2022-06-11 04:16:10.321505
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # 1. Replace the contents of 'test_SystemCapabilitiesFactCollector_collect' with the
    # following code snippet, leaving the 'mock_module' code intact:
    #
    # module = mock_module
    # collector = SystemCapabilitiesFactCollector(module=module)
    # assert 'system_capabilities' in collector.collect()
    pass