

# Generated at 2022-06-11 04:07:22.957749
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector

    _module = AnsibleModuleStub(params=None,
                                check_mode=False)

    _module.run_command = run_command_mock
    _collector = FactsCollector(module=_module)
    _caps_fact_collector = SystemCapabilitiesFactCollector(_module)
    _caps_dict = _caps_fact_collector.collect()

    assert _caps_dict['system_capabilities'] == ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']

# Generated at 2022-06-11 04:07:32.405131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.base
    import ansible.module_utils.facts.system.system

    system_capabilities_enforced_result = 'True'

# Generated at 2022-06-11 04:07:41.272044
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import CAPSH_OUTPUT
    from ansible.module_utils.facts.collector.system import CAPSH_ENFORCED
    from ansible.module_utils.facts.collector.system import CAPSH_ENFORCED_CAPS
    
    collector = SystemCapabilitiesFactCollector()
    module = Mock()
    module.run_command.return_value = (0, CAPSH_OUTPUT, '')
    result = collector.collect(module)
    
    assert result['system_capabilities_enforced'] == CAPSH_ENFORCED
    assert result['system_capabilities'] == CAPSH_ENFORCED_CAPS

    module.run_

# Generated at 2022-06-11 04:07:42.468724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    for dummy in [True, False]:
        for dummy in [True, False]:
            pass

# Generated at 2022-06-11 04:07:49.861036
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for test_SystemCapabilitiesFactCollector_collect()."""
    # Create mock module
    module = AnsibleModule(argument_spec={})
    # Set up class instance
    collector = SystemCapabilitiesFactCollector()
    # Execute method under test
    caps_facts = collector.collect(module)
    # Assert that returned value contains expected facts
    expected = {'system_capabilities_enforced': 'True',
                'system_capabilities': ['CHOWN', 'DAC_OVERRIDE', 'DAC_READ_SEARCH']}
    assert caps_facts == expected


# Generated at 2022-06-11 04:07:59.799340
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import re

    class ModuleStub():
        def __init__(self, path, shell, sudo):
            self.environ = os.environ.copy()
            self.environ['PATH'] = os.pathsep.join((path, self.environ['PATH']))
            self.shell = shell
            self.sudo = sudo

        def get_bin_path(self, cmd):
            return '/bin/' + cmd

        def run_command(self, cmd, errors):
            return 0, 'Current: = cap_chown,cap_dac_override,cap_fowner+eip', ''

    modules = [ModuleStub(path='/bin', shell=False, sudo=False)]
    for module in modules:
        collector = SystemCapabilitiesFactCollector(module=module)
        caps_

# Generated at 2022-06-11 04:08:09.619323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Create instance of class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    print("In test_SystemCapabilitiesFactCollector_collect.")

    # Create mock facts
    collected_facts = {
        "system_capabilities_enforced":"NA",
        "system_capabilities":[]
    }

    # Create mock module
    class MockModule:

        def __init__(self):
            self.run_command_result = 0
            self.run_command_out = ""
            self.run_command_err = ""

        def get_bin_path(self, executable):
            return "capsh"

        def run_command(self, args, errors="strict"):
            out = ""

# Generated at 2022-06-11 04:08:16.258942
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import datetime
    import socket
    from ansible.module_utils.facts.collector import FactCollectorCache
    from ansible.module_utils.facts import collector

    class MockRunner(object):
        def __init__(self, rcval, outval, errval):
            self.rc = rcval
            self.out = outval
            self.err = errval

        def run_command(self, cmdlist, errors='surrogate_then_replace'):
            return self.rc, self.out, self.err

    class MockModule(object):
        def __init__(self, commentval, sockval):
            self.params = {'gather_subset': ''}
            self.rc = 0
            self.comment = commentval
            self.socket = sockval


# Generated at 2022-06-11 04:08:18.883797
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    rc, out, err = collector.collect(None, None)
    assert rc == None
    assert out == {}
    assert err == None

# Generated at 2022-06-11 04:08:29.092073
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    capsh_path = "path/to/capsh/executable"
    collector = SystemCapabilitiesFactCollector()


# Generated at 2022-06-11 04:08:40.936313
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    from ansible.module_utils.facts.collector import get_collector_instance

    mock_module = object()
    mock_module.get_bin_path = lambda x: '/path/capsh'

# Generated at 2022-06-11 04:08:50.534590
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:09:00.796890
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):

        @classmethod
        def get_bin_path(cls, path):
            if path == 'capsh':
                return '/bin/capsh'

        @classmethod
        def run_command(cls, command, **kwargs):
            if command == ['/bin/capsh', '--print']:
                return 0, CapshOutput, ''
            return 123, None, None

    class MockFacts(object):
        pass


# Generated at 2022-06-11 04:09:08.136696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is a case-by-case test, not a black-box test -akl
    capsh_path = "/bin/capsh"
    output = "Current: =ep\nBounding set =cap_chown,cap_dac_override,cap_dac_read_search,"\
             "cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,"\
             "cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,"\
             "cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,"

# Generated at 2022-06-11 04:09:17.283489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    sys.path.append(os.path.dirname(__file__))

    # Capsh binary is present
    module_mock = pytest.Mock()
    module_mock.get_bin_path.return_value = "capsh"
    module_mock.run_command.return_value = (0, 'Current: =ep\nBounding set =cap_sys_admin,cap_sys_chroot+eip\n', '')
    cap = SystemCapabilitiesFactCollector(module_mock)
    cap.collect()

# Generated at 2022-06-11 04:09:27.341635
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import platform
    import pytest

    # NOTE: mocking 'ansible.module_utils.facts.collector.BaseFactCollector.__init__'
    TestSystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(module=None)

    # NOTE: mocking 'ansible.module_utils.facts.collector.BaseFactCollector._get_platform_fact_names'
    TestSystemCapabilitiesFactCollector._platform_fact_names = {
        'system_capabilities_enforced': 1,
        'system_capabilities': 1,
        'system_capabilities_available': 1,
        'system_capabilities_available_list': 1,
        'system_capabilities_supported': 1,
        'system_capabilities_supported_list': 1
    }

    # NOTE: mocking 'ansible.module_

# Generated at 2022-06-11 04:09:27.957197
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # TODO: write tests!

    assert False

# Generated at 2022-06-11 04:09:37.377493
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class module():
        def get_bin_path(self, binary):
            return binary
        def run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd[0] == '/bin/capsh':
                return 0, 'Current: =ep\nBounding set =', ''
            if cmd[0] == '/bin/true':
                return 0, 'output', ''
        def fail_json(self, **kwargs):
            print(kwargs)
            assert False, kwargs

    class collected_facts():
        def __init__(self):
            self.system_capabilities = []
            self.system_capabilities_enforced = False

    module_data = module()
    collected_data = collected_facts()

# Generated at 2022-06-11 04:09:45.871051
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    import io
    import os
    from ansible.module_utils import basic

    class MockModule:
        def __init__(self):
            pass

        def get_bin_path(self, arg):
            return '/bin/capsh'


# Generated at 2022-06-11 04:09:54.766775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    # Init collector
    SystemCapabilitiesFactCollector.collect()
    # Initialize injector
    injector = Collector()
    # Register collector
    injector.register_collector(SystemCapabilitiesFactCollector())
    # Run the injection
    ansible_facts.put(injector)


# Generated at 2022-06-11 04:10:09.616656
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockAnsibleModule()

# Generated at 2022-06-11 04:10:18.685911
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import Collector
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.process import get_bin_path


# Generated at 2022-06-11 04:10:29.095593
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:10:30.558277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Test method collect of class SystemCapabilitiesFactCollector'''
    pass

# Generated at 2022-06-11 04:10:38.527687
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    from ansible.module_utils.facts.collector import AnsibleCollector, BaseFactCollector

    class DummyModule(AnsibleCollector):
        def __init__(self):
            self.params = {}
            self.command_warnings = []

        def get_bin_path(self, executable, opt_dirs=None):
            return '/usr/bin/capsh'


# Generated at 2022-06-11 04:10:47.212681
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """

    import platform

    class TestModule(object):
        """
        Dummy test module class
        """

        @staticmethod
        def get_bin_path(a):
            return "/usr/bin/capsh"


# Generated at 2022-06-11 04:10:56.160277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import errno

    module = mock.MagicMock()

# Generated at 2022-06-11 04:11:05.106245
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector, get_collector_names_from_class
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import tempfile, textwrap

    # NOTE: temporary file used to mock capsh output
    file_fd, file_path = tempfile.mkstemp(prefix="ansible_facts_capsh")
    # NOTE: define a class variable for the temp file path -akl
    SystemCapabilitiesFactCollector.CAPSH_PATH = file_path
    # NOTE: list of collectors to register for mocking purposes
    collectors = [SystemCapabilitiesFactCollector]
    # NOTE: register and initialize the mock collectors
    Collector.init_collectors

# Generated at 2022-06-11 04:11:10.514630
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create instance of class SystemCapabilitiesFactCollector
    module_args = {}
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Invoke method collect of class SystemCapabilitiesFactCollector
    output = system_capabilities_fact_collector.collect(module_args)

    # TODO: assert on output to get better coverage
    # assert False
    assert output['system_capabilities'] != []
    assert output['system_capabilities_enforced'] != 'NA'

# Generated at 2022-06-11 04:11:18.883613
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test setup
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector

    fact_collector = SystemCapabilitiesFactCollector()
    test_facts = {}

    # Test case: non-supported version of 'capsh'
    # Test expectation: no facts added to facts dictionary

# Generated at 2022-06-11 04:11:30.285045
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True


# Generated at 2022-06-11 04:11:33.216273
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:11:42.550941
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import unittest.mock as mock
    test_mod = mock.MagicMock()
    test_caps_output = 'Capabilities for CHILD: = cap_net_raw,cap_sys_ptrace+e Current: =ep Securebits: 00/0x0/1'
    test_mod.run_command.return_value = (0, test_caps_output, '')
    test_facts = {}
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    test_mod.get_bin_path.return_value = '/usr/bin/capsh'
    test_results = test_SystemCapabilitiesFactCollector.collect(module=test_mod, collected_facts=test_facts)

# Generated at 2022-06-11 04:11:51.903150
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    collect_func = SystemCapabilitiesFactCollector()
    test_dict = {}

    # test logic for the following two scenarios
    # 1. 'capsh' command is not present
    # 2. capsh is present but prints nothing
    def run_command(command, data=None, binary_data=False,
                    path_prefix=None, cwd=None,
                    use_unsafe_shell=False, prompt_regex=None,
                    environ_update=None, umask=None,
                    encoding=None, errors='surrogate_then_replace',
                    expand_user_and_vars=True):
        if command[0] != '/usr/bin/capsh':
            return 4, '', ''
        else:
            return 0, '', ''


# Generated at 2022-06-11 04:11:52.446510
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:12:02.152717
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # set up mocking
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

# Generated at 2022-06-11 04:12:07.582625
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup testdata
    args = dict(path='/bin/', type='directory')
    results = dict(changed=False, ansible_facts=dict(system_capabilities_enforced='NA', system_capabilities=[]))

    # create instance of SystemCapabilitiesFactCollector object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # perform test
    result = system_capabilities_fact_collector.collect()
    assert(result == results)

# Generated at 2022-06-11 04:12:16.751202
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
        AnsibleModule_run_command returns (rc, out, err)
        run_command is called with the list containing capsh_path, --print
    '''
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import collector

    import sys
    if sys.version_info.major == 2:
        from mock import patch, MagicMock
    else:
        from unittest.mock import patch, MagicMock

    # We patch the entire class to make sure .collect method calls AnsibleModule_run_command
    with patch.object(SystemCapabilitiesFactCollector, 'collect'):
        sys_cap_fc = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:12:23.790161
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()
    # TODO: mock the module so 'get_bin_path' returns some value
    #       and mock 'get_bin_path' to return a certrain value
    #       and mock 'run_command' to return certain values and test
    #       the resulting data parsed.

# Generated at 2022-06-11 04:12:32.037810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    test_system_capabilities = ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot',
    'mknod', 'audit_write', 'setfcap', 'mac_override']
    mock_output = 'Current:\n =ep' + '\n'.join(test_system_capabilities)
    mock_enforced_caps = [i.strip() for i in mock_output.split('=')[1].split(',')]
    mock_caps_enforced = 'False'

    facts_dict = {}
    # mockup run_command method

# Generated at 2022-06-11 04:12:57.646210
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    

# Generated at 2022-06-11 04:13:07.031134
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:13:13.744400
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps = SystemCapabilitiesFactCollector()
    # generate expected response
    expected_response = {'system_capabilities_enforced': True,
                         'system_capabilities': ["chown", "dac_override", "fowner", "fsetid", "kill", "setgid", "setuid", "setpcap", "net_bind_service", "net_raw", "sys_chroot", "mknod", "audit_write", "setfcap"]}

    # generate actual response
    actual_response = caps.get_caps_data()

    assert actual_response == expected_response

# Generated at 2022-06-11 04:13:24.430509
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import _create_module_mock
    from ansible.module_utils.facts.collector import _create_run_command_mock
    from ansible.module_utils.facts._text.caps import SystemCapabilitiesFactCollector
    module = _create_module_mock()
    module.run_command = _create_run_command_mock(["True"], "")
    result = SystemCapabilitiesFactCollector().collect(module)
    assert result['system_capabilities'] == ['ep']
    module = _create_module_mock()
    module.run_command = _create_run_command_mock(["False"], "")
    result = SystemCapabilitiesFactCollector().collect(module)
    assert result['system_capabilities'] == []
    module = _create

# Generated at 2022-06-11 04:13:32.759734
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import types

    # test normalization
    assert DistributionFactCollector().normalize_name('system') == 'system'
    assert DistributionFactCollector().normalize_name('asdf') == 'asdf'
    assert DistributionFactCollector().normalize_name(None) is None

    # assert the defaults do not raise
    Collector()
    Collector().get_empty_facts

# Generated at 2022-06-11 04:13:38.448957
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    module.get_bin_path.return_value = '/bin/capsh'

# Generated at 2022-06-11 04:13:47.375607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    import tempfile
    import os

    file_path = os.path.join(tempfile.gettempdir(), 'test_SystemCapabilitiesFactCollector_collect.tmp')


# Generated at 2022-06-11 04:13:55.518721
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.caps as caps_mod
    import unittest.mock as mock
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.caps as caps_mod

    run_command = mock.Mock()

# Generated at 2022-06-11 04:14:02.942923
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:14:06.813086
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # test case: SystemCapabilitiesFactCollector class collect method with inputs: module=None, collected_facts=None
    # expected output: empty dictionary
    collector = SystemCapabilitiesFactCollector()
    output = collector.collect(modeule=None, collected_facts=None)
    assert output == {}, "test_SystemCapabilitiesFactCollector_collect output: %s" % output


# Generated at 2022-06-11 04:15:19.948692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # test_collect_base_fact_collector_class
    assert SystemCapabilitiesFactCollector.__bases__ == (BaseFactCollector,)

    # test_collect_returns_dict
    scfc = SystemCapabilitiesFactCollector()
    assert isinstance(scfc.collect(), dict)

    # test_collect_returns_system_capabilities_enforced_fact
    scfc = SystemCapabilitiesFactCollector()
    fc = fact_collector.FactCollector()
    assert 'system_capabilities_enforced' in scfc.collect(fc.module).keys()

    # test_collect_sets_system_capabilities_enforced_fact_as_string
   

# Generated at 2022-06-11 04:15:28.689651
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    # The following mock is equivalent to this command:
    # capsh --print

# Generated at 2022-06-11 04:15:37.457013
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector

    module = basic.AnsibleModule(
        argument_spec=dict()
    )


# Generated at 2022-06-11 04:15:45.746199
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts import collector
    import tempfile
    import os

    def execute_module_mock(module, ignore_check_return=False):
        import tempfile
        import os

        class MockPopen(object):
            """Popen mock that returns custom command output and return code."""
            def __init__(self, *args, **kwargs):
                """Initialize mock instance."""
                self.return_code = 0
                self.args = args
                self.kwargs = kwargs

# Generated at 2022-06-11 04:15:53.444928
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    module_args = dict(path=capsh_path)
    caps_data = '''Current: =ep
Bounding set =ep
Securebits: 00/0x0/1'b0 secure-noroot,noroot changeable
 secure-no-setuid-fixup secure-keep-caps
 secure-no-setuid-fixup secure-keep-caps
 secure-no-setuid-fixup secure-keep-caps
 secure-no-setuid-fixup secure-keep-caps
CapEff: =ep
CapPrm: =ep
CapInh: =ep
CapBnd: =ep
'''
    capsh_data = []
    capsh_data.append(caps_data)
    capsh_rc = (0, '', '')


# Generated at 2022-06-11 04:15:53.946230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:15:56.878975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Test SystemCapabilitiesFactCollector class'''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    fact_class = SystemCapabilitiesFactCollector()
    print(fact_class.collect(module))

# Generated at 2022-06-11 04:16:00.329286
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    unit test for SystemCapabilitiesFactCollector.collect()
    """
    # TODO: mock capsh_path, mock run_command
    # TODO: assert capsh_path is not None
    # TODO: assert capsh_path is None
    # TODO: assert enforced caps
    pass

# Generated at 2022-06-11 04:16:03.672263
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule()
    facts_dict = SystemCapabilitiesFactCollector(module=module).collect()
    assert('system_capabilities_enforced' in facts_dict)
    assert('system_capabilities' in facts_dict)

# Generated at 2022-06-11 04:16:11.983888
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import os
    import sys
    import inspect

    # Find the fact collection script.
    # The fact collection script is a sibling of this module file.
    facts_file_path = inspect.getfile(inspect.currentframe())
    facts_file_dir = os.path.dirname(facts_file_path)
    fact_collector_file_path = os.path.join(facts_file_dir, 'system/capabilities.py')

    # Import the module.
    sys.path.insert(0, facts_file_dir)
    import capabilities

    # Create a SystemCapabilitiesFactCollector instance.
    c = capabilities.SystemCapabilitiesFactCollector()

    # Set a fake module.