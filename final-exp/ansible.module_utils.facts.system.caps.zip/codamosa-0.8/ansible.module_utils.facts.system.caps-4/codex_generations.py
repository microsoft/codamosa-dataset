

# Generated at 2022-06-11 04:07:26.361665
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    try:
        module.run_command = Mock(return_value=(0, "Current: =ep", ""))
        capscollector = SystemCapabilitiesFactCollector()
        result = capscollector.collect(module=module)
        assert result == {
            'system_capabilities': [],
            'system_capabilities_enforced': 'False'
        }
    except Exception:
        assert False

# Generated at 2022-06-11 04:07:36.347823
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class ModuleMock(object):
        def __init__(self, enforce):
            self.module_results = []
            self.run_count = 0
            self.run_command_results = []
            self.check_output_results = []
            self.enforce = enforce

        def get_bin_path(self, name):
            return '/usr/bin/capsh'

        def run_command(self, command, errors='surrogate_then_replace'):
            self.run_count += 1
            if self.enforce:
                out = 'Current: =ep\nSecurebits: 00/0x0/1'
            else:
                out = 'Current: = cap_chown,cap_dac_override+i'
            return 0, out, None


# Generated at 2022-06-11 04:07:42.936789
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import re
    import tempfile
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-11 04:07:52.710213
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.caps as caps
    import ansible.module_utils.facts.system.caps
    reload(caps)
    reload(ansible.module_utils.facts.system.caps)
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapshMock
    from ansible.module_utils.facts.system.caps import CapshGetCapsDataMock

    # build test data
    expected_fields = ['system_capabilities', 'system_capabilities_enforced']
    expected_data   = {'system_capabilities': ['cap_net_bind_service', 'cap_dac_override'],
                       'system_capabilities_enforced': 'True'}

    # build

# Generated at 2022-06-11 04:08:02.124267
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # creating a test module object
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    # creating a test 'Facts' object
    testobj = SystemCapabilitiesFactCollector(module=module)
    # making sure that the testobj is of correct type
    assert isinstance(testobj, SystemCapabilitiesFactCollector)
    # making sure we can access it's data members
    assert testobj.name == 'caps'
    assert testobj._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])
    # get_caps_data() is the only method remaining; calling it to perform the
    # actual test, over testobj.name and testobj._fact_ids
    assert testobj.collect() == {}

# Generated at 2022-06-11 04:08:04.249869
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector().collect() == dict(system_capabilities_enforced='NA',
                                                               system_capabilities=[])

# Generated at 2022-06-11 04:08:13.301621
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # Prepare the test
    SystemCapabilitiesFactCollector.name = 'caps'
    SystemCapabilitiesFactCollector._fact_ids = set(['system_capabilities',
                                                     'system_capabilities_enforced'])

    # Mocks
    class MockModule:
        def __init__(self):
            pass

        def get_bin_path(self, path):
                return '/bin/capsh'


# Generated at 2022-06-11 04:08:23.760927
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: unittest is a built-in python module, but you can use py.test, nose or unittest2 instead
    import unittest
    # NOTE: create a test class that inherits from 'unittest.TestCase'
    class TestSystemCapabilitiesFactCollectorCollect(unittest.TestCase):
        # NOTE: 'setUp' is a method that runs before each test in the test class
        def setUp(self):
            # NOTE: we create a mock 'module' object here.  This might be a custom module, AnsibleModule from ansible.module_utils, or a typical Ansible 'module_util' like ComplexModule (see ansible.module_utils.basic)
            class MockModule(object):
                def get_bin_path(name):
                    return '/bin/capsh'

# Generated at 2022-06-11 04:08:33.166808
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import unittest

    # so the test can run from the top directory
    moduledir = os.path.dirname(os.path.realpath(__file__))

    # prepare some fake facts to pass in
    collected_facts = { }

    # prepare the module object
    class TestModule:
        def __init__(self, verbose=None):
            self.params = {}
            self.check_mode = False
            self.verbose = verbose
            self.run_command_environ_update = {}

        def get_bin_path(self, executable):
            return capsh_path


# Generated at 2022-06-11 04:08:42.185503
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.get_bin_path = lambda x: '/usr/bin/capsh'
    module.run_command = lambda x, errors='surrogate_then_replace': (0, 'Current: =ep\n', '')

    collectors = [SystemCapabilitiesFactCollector()]
    facts = ansible.module_utils.facts.collector.collector_from_list(collectors).collect(module=module)

    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-11 04:08:52.056082
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    module = MagicMock()
    module.get_bin_path.return_value = capsh_path
    module.run_command.return_value = 0, "Current: =ep", ''

    fact_collector = SystemCapabilitiesFactCollector(module)
    collected_facts = fact_collector.collect(module=module)

    assert collected_facts == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

    # Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:09:02.378401
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.community.general.plugins.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    class FakeModule:
        def __init__(*args, **kwargs):
            return None
        class run_command:
            def __init__(*args, **kwargs):
                return None
            def __call__(*args, **kwargs):
                return (0, 'Capabilities: =cap_net_chroot+ep disabled', '')
        class get_bin_path:
            def __init__(*args, **kwargs):
                return None
            def __call__(*args, **kwargs):
                return 'capsh'

# Generated at 2022-06-11 04:09:08.767833
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    facts_dict = SystemCapabilitiesFactCollector(module).collect()

# Generated at 2022-06-11 04:09:10.367770
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collector = SystemCapabilitiesFactCollector()
    print(collector.collect(module))

# Generated at 2022-06-11 04:09:12.186204
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # FIXME: test_collect, verify enforced_caps and enforced are properly evaluated (via mock) -akl
    pass

# Generated at 2022-06-11 04:09:21.211817
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collectors.system.system_capabilities
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleStub
    import tempfile

    with tempfile.NamedTemporaryFile('rb') as stdout:
        with tempfile.NamedTemporaryFile('rb') as stdin:

            stdout.write(to_bytes("Current: =ep\n"))

# Generated at 2022-06-11 04:09:31.118312
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Check calling collect method of SystemCapabilitiesFactCollector class
    # when capsh is not on the path returns an empty dictionary

    c1 = SystemCapabilitiesFactCollector()

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import FactsCollector

    fc1 = FactsCollector(module=AnsibleModule(argument_spec={}, supports_check_mode=False))
    assert c1.collect(module=fc1._module, collected_facts=fc1._collected_facts) == {}

    # Check calling collect method of SystemCapabilitiesFactCollector class
    # when capsh is on the path
    # and when capsh output has no entries corresponding to 'Current:' or '=ep'
    # returns a dictionary containing values: 'system_capabilities_enforced' = '

# Generated at 2022-06-11 04:09:40.903788
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collection_loader

    TestFactCollector = ansible_collection_loader.load_fact_collector('system_capabilities', 'SystemCapabilitiesFactCollector', base_class=BaseFactCollector)
    test_instance = TestFactCollector()

    # Test 'rf' and 'ep' (enforced) capabilities
    def run_method_with_args(args):
        return 0, "Current:\t cap_chown,cap_dac_override,cap_fowner+ep\nBounding set =cap_chown,cap_dac_override,cap_fowner+ep\n", ""
    test_instance.module.run_command = run_method_with_args

    assert test

# Generated at 2022-06-11 04:09:47.862682
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FallbackModuleUtils

    import ansible.utils.module_docs as md
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.system.caps as caps

    # Required for the doc_fragments in the module
    setattr(md, 'AnsibleModule', FallbackModuleUtils.FallbackModuleUtils)

    # Assign some mocked data to the module

# Generated at 2022-06-11 04:09:56.856133
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import json
    import subprocess
    import tempfile
    from ansible.module_utils.facts import Collector

    # Define a system caps collector object
    sys_caps_collector = SystemCapabilitiesFactCollector()

    # Define mocked module for unit test
    class module:
        def __init__(self):
            self.run_command_count = 0

        def run_command(self, *args, **kwargs):
            self.run_command_count = self.run_command_count + 1
            return 0, 'Current: =ep\n', ''

        def get_bin_path(self, *args, **kwargs):
            return '/bin/true'

    # Define mocked module_utils, where capsh is not found

# Generated at 2022-06-11 04:10:04.468629
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    obj = BaseFactCollector()
    # Not testing this method as it will try and call capsh instead of doing any mocking
    return True

# Generated at 2022-06-11 04:10:14.013414
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.system_capabilities import get_caps_data
    from ansible.module_utils.facts.system.system_capabilities import parse_caps_data
    from mock import Mock, patch
    import json
    import os
    import sys

    # Mock AnsibleModule
    module = Mock()
    module.get_bin_path.return_value = "/usr/bin/capsh"

# Generated at 2022-06-11 04:10:23.363244
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def get_bin_path(arg):
        if arg == 'capsh':
            return 'path/to/capsh'
        return None
    class Module(object):
        def __init__(self):
            self.fail_json = lambda **kwargs: None
        def get_bin_path(self, arg):
            return get_bin_path(arg)
        def run_command(self, args, errors='surrogate_then_replace'):
            expect_args = ['path/to/capsh', "--print"]
            assert args == expect_args
            return 0, CAPSH_OUT, None
    module = Module()
    fact_collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:10:33.833637
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Module:
        @staticmethod
        def get_bin_path(name):
            return name


# Generated at 2022-06-11 04:10:42.325482
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this test is more complex than necessary due to the capsh cmd
    # NOTE: -> make some unit test helpers that are easier to mock -akl
    class TestModule(object):
        @staticmethod
        def get_bin_path(name):
            return capsh_path if name == 'capsh' else None

        @staticmethod
        def run_command(cmd):
            return rc, out, err

    def _run_collector(caps_path, caps_rc, caps_out, caps_err):
        capsh_path = caps_path
        rc = (0, caps_rc)
        out = caps_out
        err = caps_err
        collector = SystemCapabilitiesFactCollector
        return collector.collect(module=TestModule)


# Generated at 2022-06-11 04:10:44.250668
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #Creating the object
    o = SystemCapabilitiesFactCollector()

    #Testing the method collect
    assert o.collect() == {}

# Generated at 2022-06-11 04:10:52.936362
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import sys

    if sys.version_info.major < 3:
        from mock import Mock
    else:
        from unittest.mock import Mock

    from ansible.module_utils import facts

    testmodule = facts.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )

    capsh_path = '/somepath/capsh'
    run_command_results = [0,
                           'Current: =ep',
                           '']

    mock_module = Mock(**{'run_command.return_value': run_command_results,
                         'get_bin_path.return_value': capsh_path})

    scfc = SystemCapabilitiesFactCollector(mock_module)
    facts = scfc.collect()


# Generated at 2022-06-11 04:11:02.349029
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Test only a the collect method. The other methods of
    # the class SystemCapabilitiesFactCollector are tested in
    # test_ansible_module_utils_facts_collector.
    import sys
    import os
    import tempfile
    import pytest

    # init stub
    stub_module = type('stub_module', (object,), {})
    stub_module.exit_json = lambda x: sys.exit(x)
    stub_module.fail_json = lambda *x: sys.exit(1)
    stub_module.run_command = lambda *x, **y: (0, 'Current: =ep', '')

    # Generate a temporary file
    (tf_fd, tf_path) = tempfile.mkstemp(prefix='ansible_test_', suffix='.py')
    # And

# Generated at 2022-06-11 04:11:03.864917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collect_obj = SystemCapabilitiesFactCollector()
    assert collect_obj.collect() == {}


# Generated at 2022-06-11 04:11:12.349522
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    module.get_bin_path.return_value = 'capsh_path'

# Generated at 2022-06-11 04:11:32.303485
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content

    # Setup 'module' fake obj
    class FakeModule:
        def __init__(self):
            self._system_capabilities_path = "/system/capabilities/path"
        def get_bin_path(self, bin_name):
            return self._system_capabilities_path
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, "", ""

    # Setup fake os.path
    import os
    real_os_path = os.path
    class FakeOsPath:
        exists = lambda path: True
        isfile = lambda path: True
    os.path = Fake

# Generated at 2022-06-11 04:11:41.677401
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os.path
    import unittest

    class SystemCapabilitiesFactCollectorTestCase(unittest.TestCase):

        def test_empty(self):
            with self.assertRaises(TypeError) as ex:
                SystemCapabilitiesFactCollector().collect()
            self.assertTrue(str(ex.exception).startswith('module must be an ansible module'))

        @unittest.skipIf(os.path.exists('/etc/redhat-release'), 'Not on RHEL/Fedora/CentOS')
        def test_capsh_missing(self):
            from ansible.module_utils.basic import AnsibleModule
            mod = AnsibleModule()
            mod.run_command = lambda x, **y: (0, '', '')
            # NOTE: use __getitem__

# Generated at 2022-06-11 04:11:50.665526
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = mock.MagicMock()
    capsh_path = module.get_bin_path.return_value = "/usr/bin/capsh"
    rc = 0
    out = "Current: =eip cap_net_admin,cap_net_raw,cap_sys_admin,cap_sys_chroot=eip\n"
    err = ""
    module.run_command.return_value = rc, out, err
    c = SystemCapabilitiesFactCollector()
    expected_facts = {'system_capabilities': ['cap_net_admin', 'cap_net_raw', 'cap_sys_admin', 'cap_sys_chroot'], 'system_capabilities_enforced': 'False'}
    assert c.collect(module) == expected_facts

# Generated at 2022-06-11 04:11:57.002582
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create fake module to pass to method (mocking out module)
    module = AnsibleModule({'command': 'get_caps'})

    # Call the method
    facts_dict = SystemCapabilitiesFactCollector().collect(module)

    # Test results
    # NOTE: get_caps_data() return value will be moved here if AnsibleModule.run_command()
    # NOTE: isn't mocked out/an empty return value is faked.
    # NOTE: get_caps_data() mocked out for below test
    assert facts_dict['system_capabilities_enforced'] == 'NA'

# Generated at 2022-06-11 04:12:06.547977
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = mock.MagicMock()

# Generated at 2022-06-11 04:12:15.575033
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:12:20.516155
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleDummy()
    sut = SystemCapabilitiesFactCollector()
    res = sut.collect()
    assert module.run_command_called
    assert 'system_capabilities_enforced' in res
    assert 'system_capabilities' in res

# AnsibleModuleDummy is a dummy class to provide minimal-required attributes
# for SystemCapabilitiesFactCollector to get executed.

# Generated at 2022-06-11 04:12:29.322038
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test case for BSP Linux capsh --print output
    """

    class MockModule(object):
        params = {
        }
        def get_bin_path(self, name):
            return '/bin/capsh'


# Generated at 2022-06-11 04:12:37.596068
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.capabilities as test_module_capabilities

    test_module = FakeModule()

# Generated at 2022-06-11 04:12:38.820648
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    tmp = SystemCapabilitiesFactCollector()
    assert tmp.collect() == {}

# Generated at 2022-06-11 04:13:10.442978
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.capabilities as cc
    import ansible.module_utils.facts.system.platform
    import json


# Generated at 2022-06-11 04:13:20.052052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    fact_collector = SystemCapabilitiesFactCollector(collector)

    out = 'Current: =ep'
    err = ''
    rc = 0
    mock_module = MockModule(out=out, err=err, rc=rc)
    facts = fact_collector.collect(mock_module, None)
    assert facts['system_capabilities_enforced'] == 'False'

    out = 'Current: =ep cap_net_admin,cap_net_raw+eip'
    err = ''
    rc = 0
    mock_module = MockModule(out=out, err=err, rc=rc)
    facts = fact_collector.collect(mock_module, None)

# Generated at 2022-06-11 04:13:29.850009
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    import ansible.module_utils
    import ansible.module_utils.facts.collector
    import ansible.utils
    import ansible.errors
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import collections
    import re

    p = subprocess.Popen(["capsh", "--print"], stdout=subprocess.PIPE,
        stderr=subprocess.PIPE)
    out, err = p.communicate()
    test_caps = json.loads(out)

    my_test_class = ansible.module_utils.facts.collector.FactsCollector
    my_test_class._collectors.append(SystemCapabilitiesFactCollector())

    # NOTE:

# Generated at 2022-06-11 04:13:36.914258
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:13:45.221573
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock the module param 'module'
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/capsh'

# Generated at 2022-06-11 04:13:53.598880
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock module
    import module_utils.facts.fact_collector as fc
    class Module:
        def get_bin_path(path):
            # NOTE: Can't mock this function, so hardcode bin_path -akl
            return "/usr/bin/capsh"

        def run_command(cmd):
            # NOTE: Can't mock this function, so return valid data -akl
            return (0, "Current:\n = cap_sudo", "")

    fc_mod = fc.FactCollector()
    scfc = SystemCapabilitiesFactCollector(Module, fc_mod)
    class Collector:
        def __init__(self, facts):
            self.facts = facts

    c = Collector({})
    scfc.collect(Module, c)

# Generated at 2022-06-11 04:14:01.302448
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils.capsh import get_capsh_output
    from ansible.module_utils.facts.utils.capsh import parse_capsh_output
    from ansible.module_utils.facts.utils.capsh import CapshError
    import io

    class MockModule(object):
        def __init__(self, module_name):
            self.module_name = module_name
            self.run_command = Mock(return_value=(0, '', ''))

    import sys
    if sys.version_info.major == 3:
        open_set_mode = 'w'
    else:
        open_set_mode = 'wb'

# Generated at 2022-06-11 04:14:09.092685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    c = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:14:15.939143
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test collect with valid data
    """
    collector = SystemCapabilitiesFactCollector()
    module = MockModule()
    module.run_command = Mock()
    module.run_command.return_value = (0, 'Current: =ep\nPossible: =ep', '')
    collector.collect(module)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args == \
        (('[\'/usr/sbin/capsh\', \'--print\']',),)
    assert 'caps' in collector.collect()
    assert collector.collect()['caps']['system_capabilities_enforced'] == 'False'
    assert collector.collect()['caps']['system_capabilities'] == ['ep']



# Generated at 2022-06-11 04:14:22.642545
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile

    class MockModule(object):
        def __init__(self):
            self._bin_paths = {}
            self._bin_paths['capsh'] = "capsh"

        def get_bin_path(self, prog):
            return self._bin_paths[prog]

        def run_command(self, cmd, errors='surrogate_then_replace'):
            # NOTE: python3.3 fix -> tempfile.TemporaryDirectory()
            with tempfile.TemporaryDirectory() as tmp:
                out_file = tmp + '/out'
                with open(out_file, 'w') as f:
                    f.write("Current: =ep")
                rc = 0
                err = ''
                with open(out_file, 'r') as f:
                    out = f.read()
           

# Generated at 2022-06-11 04:15:32.200477
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Unit test for SystemCapabilitiesFactCollector.collect() """

    # create temporary file with capsh output
    import tempfile
    tfile = tempfile.NamedTemporaryFile(mode='w+t')
    tfile.write('Current: =ep')
    tfile.flush()

    # set module args
    module_args = dict(
        _ansible_tmpdir='/tmp',
        ansible_facts={'_ansible_tmpdir': tfile.name}
    )

    # create the module
    import ansible.modules.system.linux.facts
    module = ansible.modules.system.linux.facts.SystemFactsModule()
    module.init_module_args(module_args)

    # create collector object from class
    cls = SystemCapabilitiesFactCollector
    obj = cls(module)

# Generated at 2022-06-11 04:15:35.766107
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    generated_facts_dict = system_capabilities_fact_collector.collect()
    assert generated_facts_dict['system_capabilities_enforced'] == 'NA'
    assert generated_facts_dict['system_capabilities'] == []

# Generated at 2022-06-11 04:15:41.220766
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    sys.path.append('/usr/bin')
    import ansible.module_utils.facts.collector as collector

    collector.get_bin_path = lambda x: 'capsh'
    collector.run_command = lambda path, arg: (0, 'Current: =ep', '')

    scfc = SystemCapabilitiesFactCollector()
    assert scfc.collect()['system_capabilities_enforced'] == 'False'
    assert 'system_capabilities' not in scfc.collect()

# Generated at 2022-06-11 04:15:41.735444
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:15:42.350396
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:15:48.415600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import doctest

    examples = """
    >>> caps = SystemCapabilitiesFactCollector()
    >>> caps.collect() # doctest: +ELLIPSIS
    {'system_capabilities_enforced': '...', 'system_capabilities': [...]}
    """
    if platform.system() == "Linux":
        results = doctest.testmod(optionflags=doctest.ELLIPSIS,
                                  extraglobs={'caps': SystemCapabilitiesFactCollector()})
    else:
        results = doctest.testmod(optionflags=doctest.ELLIPSIS)

    assert results.failed == 0

# Generated at 2022-06-11 04:15:53.054864
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['!all', 'caps']))
    )
    # NOTE: capsh may be available, so we need to collect facts and return the subset
    # related to system_capabilties to ensure we pick up these properly
    facts = F.collect(module=module)
    assert 'system_capabilities' not in facts
    assert 'system_capabilities_enforced' not in facts

# Generated at 2022-06-11 04:16:01.311772
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a test AnsibleModule object to use in testing
    class TestAnsibleModule:
        def get_bin_path(self, name):
            return '/bin/capsh'

# Generated at 2022-06-11 04:16:06.622967
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import tempfile
    import shutil
    import os

    class ModuleStub:
        def __init__(self, capsh_path):
            self._caps_path = capsh_path

        def get_bin_path(self, binary):
            return self._caps_path

        def run_command(self, args, errors='surrogate_then_replace'):
            return 0, "Current: =ep", ''

    def create_expected(enforced='NA'):
        return {
            'system_capabilities': [],
            'system_capabilities_enforced': enforced,
        }

    def validate_results(expected, actual):
        assert expected['system_capabilities'] == actual['system_capabilities']

# Generated at 2022-06-11 04:16:14.515431
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import tempfile

    # The system information will be different on every system. Don't test it.
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.libc = None