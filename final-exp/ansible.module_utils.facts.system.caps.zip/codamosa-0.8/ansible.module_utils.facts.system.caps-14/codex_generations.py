

# Generated at 2022-06-11 04:07:24.608172
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import platform

    import pytest

    from ansible.utils.platform import Platform

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    #############################################################
    # `Collector.get_collector_classes`
    #############################################################

    # Test that the SystemCapabilitiesFactCollector is returned for EL platforms
    for platform_name in ("redhat", "fedora", "centos", "scientific", "oraclelinux", "amazon"):
        platform = Platform(platform_name)
        Collector.set_platform(platform)
        collected_classes = Collector.get_collector_classes

# Generated at 2022-06-11 04:07:34.432471
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import subprocess
    import tempfile
    import shutil

    # NOTE: if you don't want this to run as root, you'll have to
    #       find some other way to capture the capabilities for
    #       testing
    if os.geteuid() != 0:
        raise unittest.SkipTest("not running as root, so can't access /proc")

    # NOTE: if you don't have /proc locally, you'll need to create
    #       it manually.  Otherwise the capability tests will fail
    if not os.path.exists('/proc'):
        raise unittest.SkipTest("/proc not present, so can't access kernel capabilities")

    # create a temporary directory to store the capsh binary
    tmpdir = tempfile.mkdtemp()
    # create a temporary python file to run

# Generated at 2022-06-11 04:07:35.038795
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:07:42.403703
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import os
    import tempfile
    import shutil
    import sys

    if platform.system() == 'Darwin':
        # NOTE: This scenario is not supported and cannot be tested on macOS
        return

    if os.geteuid() != 0:
        # NOTE: This scenario is not supported and cannot be tested when not root
        return

    if not sys.version_info[0] >= 3:
        # NOTE: This scenario requires f-strings which are only found in Python 3.6+
        return

    # NOTE: Create test directory to contain fake capsh executable
    with tempfile.TemporaryDirectory() as tmpdirname:
        capsh_fqpn = os.path.join(tmpdirname, 'capsh')
        # NOTE: Create fake capsh

# Generated at 2022-06-11 04:07:52.025018
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    MockModule = type('MockModule', (object,), {'get_bin_path': lambda self, *args: './capsh'})
    MockModule.run_command = lambda self, *args, **kwargs: (0, "Current: =ep\n", '')

    system_caps_collector = SystemCapabilitiesFactCollector()
    system_caps_collector.collect(MockModule(), None)
    assert system_caps_collector.fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    system_caps_collector.collect(MockModule(), {})
    assert system_caps_collector.collect(MockModule(), {}) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    #MockModule.run_command = lambda

# Generated at 2022-06-11 04:08:01.874131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = SystemCapabilitiesFactCollector()
    capsh_path = '/bin/capsh'

# Generated at 2022-06-11 04:08:11.497364
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def get_bin_path(name):
        return 'capsh'


# Generated at 2022-06-11 04:08:19.461445
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockModule():
        def get_bin_path(self, path):
            return 'capsh_path'

        def run_command(self, arg, errors):
            return 0, 'Current: =ep\n', 'err'

    mock_module = MockModule()

    system_caps = SystemCapabilitiesFactCollector(mock_module)
    system_cap_facts = system_caps.collect()
    assert system_cap_facts == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 04:08:29.540724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Dummy function for SystemCapabilitiesFactCollector.collect() to allow unit testing
    '''

    # Initial values for testing
    testing = {}

    # Import necessary libraries and methods from Ansible
    from ansible.module_utils.facts import ansible_collector

    # Instantiate the collector
    col = ansible_collector.get_collector('SystemCapabilitiesFactCollector')

    # Assign the variable 'collected_facts' to the return value of calling col.collect()
    collected_facts = col.collect(testing)

    # Assert that collected_facts is a dictionary type
    assert isinstance(collected_facts, dict)

    # Assert that collected_facts contains the expected keys
    assert len(collected_facts.keys()) == 2
    assert 'system_capabilities_enforced' in collected_facts

# Generated at 2022-06-11 04:08:33.204803
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.params = {}
    facts_dict = SystemCapabilitiesFactCollector().collect(module, {})
    assert facts_dict['system_capabilities'] == ['cap_chown']
    assert facts_dict['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:08:43.971809
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import os
    import tempfile
    from subprocess import CalledProcessError
    from ansible.module_utils.facts import TestModulePhonyAnsibleModule

    # Mock capsh tool path resolution

# Generated at 2022-06-11 04:08:53.997044
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule():
        def get_bin_path(self, resource):
            return capsh_path

        def run_command(self, commands, errors='strip'):
            return rc, out, err

    class MockCollector():
        def __init__(self):
            self._fact_ids = []

    caps = SystemCapabilitiesFactCollector()


# Generated at 2022-06-11 04:08:56.268961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    systemcapabilities = SystemCapabilitiesFactCollector()
    # test empty run_command output
    assert(systemcapabilities.collect() == {})

# Generated at 2022-06-11 04:09:05.760970
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a SimpleNamespace object with some attributes - this will act as a mock module
    class SimpleNamespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    fake_bin_path_list = ['fake_bin_path', 'capsh_path']
    fake_bin_path_output = 'fake_bin_path/capsh'
    fake_binary_name = 'capsh'

# Generated at 2022-06-11 04:09:15.192839
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import unittest.mock as mock
    with mock.patch.object(sys.modules['ansible.module_utils.facts'], 'ansible_module', new_callable=mock.MagicMock) as mock_module:
        collector = SystemCapabilitiesFactCollector()
        collector.capsh_path = '/usr/bin/capsh'
        # NOTE: test_collect mock_module.run_command(...)
        mock_module.run_command.return_value = 0, 'Current: =ep Permitted: =ep Inheritable: =ep Bounding set =ep Capabilities for pid 14732: =ep', ''
        facts_dict = collector.collect()
        assert facts_dict.get('system_capabilities_enforced') == 'False'

# Generated at 2022-06-11 04:09:24.986326
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    facts_dict = {}

    class MockModule(object):
        def __init__(self, rc, out, err):
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, app):
            return '/bin/capsh'
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (self._rc, self._out, self._err)
    # These tests are for capsh output in the case of enforcing caps
    # and not enforcing caps
    # Scenario - enforcing caps
    # rc: 0
    # out:
    # Current: =ep
    #      = cap_ch

# Generated at 2022-06-11 04:09:28.494589
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    SystemCapabilitiesFactCollector - test method collect
    """
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    result = test_SystemCapabilitiesFactCollector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-11 04:09:32.365680
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup a module with some useful defaults
    mock_module = AnsibleModule({
        'command': 'echo "Current: =ep"',
        'module_name': 'test'
    })
    # Setup a FactCollector
    facts = SystemCapabilitiesFactCollector(mock_module)
    # Run method
    result = facts.collect()
    # Check results
    assert result == {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }

# Generated at 2022-06-11 04:09:41.186989
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:

        def get_bin_path(self, name):
            return "/bin/capsh"

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, "Current:\t=ep\nBounding set =cap_chown,cap_dac_override+eip\nSecurebits: 00/0x0/1'b0 secure-noroot, locked-noroot", None

    module_mock = MockModule()
    cap_collector = SystemCapabilitiesFactCollector()
    assert cap_collector.collect(module_mock) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}



# Generated at 2022-06-11 04:09:47.992323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    testdict = {'system_capabilities': ['cap_chown', 'cap_dac_override', 'cap_net_raw', 'cap_sys_nice', 'cap_sys_resource'],
                'system_capabilities_enforced': 'False'}

    class MockModule(object):
        def get_bin_path(self,path):
            return '/usr/bin/capsh'

        def run_command(self, cmd, errors='strict'):
            return (0,'Current: =ep','error')

    class MockFacts(object):
        def __init__(self):
            self.system_capabilities = []
            self.system_capabilities_enforced = 'NA'

    testarg = MockModule()
    testfact = MockFacts()

    testobj = SystemCapabilitiesFactCollector()
   

# Generated at 2022-06-11 04:10:00.475635
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    bfc = SystemCapabilitiesFactCollector()
    class FakeModule:
        def get_bin_path(self, a):
            return '/usr/bin/capsh'

        def run_command(self, a, b):
            return 0, 'Current: = cap_kill,cap_net_bind_service+ep', ''

    assert {'system_capabilities_enforced': 'True',
            'system_capabilities': ['cap_kill', 'cap_net_bind_service']} \
            == bfc.collect(FakeModule())

# Generated at 2022-06-11 04:10:09.956155
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', text=True, log_callback=None, data_binary=False, binary_data=False):
        import os
        import tempfile

        # write command output to a temporary file
        fd, path = tempfile.mkstemp()
        os.write(fd, b"Current:= cap_setpcap,cap_setfcap\n")
        os.close(fd)

# Generated at 2022-06-11 04:10:18.996320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    # Instantiate a SystemCapabilitiesFactCollector and test method collect in it
    scfc = SystemCapabilitiesFactCollector()

    # Prepare the fake module object
    class MockModule:
        def __init__(self, bin_path=None, run_command=None):
            self.bin_path = bin_path
            self.run_command = run_command

        def get_bin_path(self, prog):
            return self.bin_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return self.run_command

    m = MockModule()

    # Test capsh being present

# Generated at 2022-06-11 04:10:29.498791
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Basic unit test for method collect of class SystemCapabilitiesFactCollector
    -akl
    '''
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # No bin path, return empty facts
    fake_module = FakeModule()
    fake_module.run_command = FakeRunCommandNoBinPath()
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(module=fake_module, collected_facts=None)
    assert not facts

    # Empty caps output, return empty facts
    fake_module = FakeModule()
    fake_module.run_command = FakeRunCommandEmptyCapsOutput()
    fact_collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:10:37.918450
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_output = """
Current: =ep
Bounding set =ep
Securebits: 00/0x0/1'b0 secure-noroots changeable,
        (no unconfined executables)
Secure-noroots: no (unconfined executables are allowed)
CapEff: =ep
CapInh: =ep
CapPrm: 0000001fffffffff
CapAmb: 0000000000000000
No inheritable capabilities found
Cpus allowed: 0000003f
"""


# Generated at 2022-06-11 04:10:46.648673
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    test_SystemCapabilitiesFactCollector_collect
    """

    class FakeModuleUtils(object):
        """
        FakeModuleUtils
        """

        def get_bin_path(self, bin_path):
            """
            get_bin_path
            """

            return '/usr/bin/capsh'

        def run_command(self, cmd, errors):
            """
            run_command
            """

# Generated at 2022-06-11 04:10:47.733464
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 04:10:56.722672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestAnsibleModule:
        def get_bin_path(self, exe):
            return '/bin/capsh'
        def run_command(self, args, errors='surrogate_then_replace'):
            return 0, 'Current: =ep\nBounding set =chown,dac_override,fsetid,fowner,mknod,net_raw,setfcap,setpcap,sys_chroot,kill\nSecurebits: 00/0x0/1'+\
                ''' \n secure-noroot: no (unlocked)\n secure-no-suid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root)''', ''

    from facter.collector import BaseFactCollector


# Generated at 2022-06-11 04:11:03.667068
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = Mock()
    module_mock.run_command.return_value=(1,'Current: =ep','NA')

    t_caps = SystemCapabilitiesFactCollector()

    t_caps.collect(module=module_mock)

    assert module_mock.run_command.call_count == 1
    assert module_mock.get_bin_path.call_count == 1
    module_mock.assert_has_calls([call.get_bin_path('capsh'), call.run_command([mock.ANY, '--print'], errors='surrogate_then_replace')])

# Generated at 2022-06-11 04:11:05.227743
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    dc = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in dc.collect(None)

# Generated at 2022-06-11 04:11:24.411111
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/path/to/capsh'
    capsh_cmd = '{0} --print'.format(capsh_path)
    module_patcher = mock.patch('ansible.module_utils.basic.AnsibleModule')
    run_command_patcher = mock.patch('ansible.module_utils.basic.AnsibleModule.run_command')
    module_mock = module_patcher.start()
    run_command_mock = run_command_patcher.start()
    run_command_mock.return_value = 0, CAPSH_STDOUT, ''

    module_mock.get_bin_path.return_value = capsh_path
    scc = SystemCapabilitiesFactCollector()

    # test collector

# Generated at 2022-06-11 04:11:33.180922
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # In unit test, module will be injected to
    # SystemCapabilitiesFactCollector instance as module attribute
    test_module = object()
    test_module.run_command = lambda args, **kwargs: (0, 'Current: =ep\nBounding set =cap_net_bind_service,cap_sys_chroot,cap_dac_override,cap_setgid,cap_setuid,cap_sys_admin,cap_sys_resource+ep\nSecurebits: 00/0x0/1\'b0\nsecure-noroot: no (unlocked)\nsecure-no-suid-fixup: no (unlocked)\nsecure-keep-caps: no (unlocked)\nuid=0(root)', '')
    result = SystemCapabilitiesFactCollector(test_module).collect()

# Generated at 2022-06-11 04:11:41.841629
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: module object needed only by method -akl
    module = None
    module_method = SystemCapabilitiesFactCollector()
    # NOTE: module_method.collect() is this method under test -akl
    # NOTE: collected_facts arg not used -akl
    collected_facts = {}
    expected_facts_dict = {'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap'],
                           'system_capabilities_enforced': 'True'}
    facts_dict = module_method.collect(module=module, collected_facts=collected_facts)
    assert facts_dict == expected_facts_dict

# Generated at 2022-06-11 04:11:51.169870
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import SystemCapabilitiesFactCollector
    import json


# Generated at 2022-06-11 04:11:56.843459
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = AnsibleModuleMock()
    fc = SystemCapabilitiesFactCollector()
    # return correct results when capsh is installed
    m.run_command.return_value = (0, 'Current: =ep', '')
    assert fc.collect(module=m) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}
    # return empty results when capsh is not installed
    fc.module_commands = None
    assert fc.collect(module=m) == {}

# Generated at 2022-06-11 04:12:06.384629
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        import ansible.utils.unsafe_proxy
    except:
        return

    # NOTE: find some way to mock 'ansible.module_utils.facts.collector.BaseFactCollector' here -akl
    # NOTE: mock a module object here and re-use data in -> get_caps_data()/parse_caps_data() -akl

    # module.get_bin_path('capsh') fails
    expected_result = {}
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    # NOTE: mock a module.run_command() call here -akl

    # module.get_bin_path('capsh') success but capsh execution fails
    expected_result = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}

# Generated at 2022-06-11 04:12:15.368011
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import collected_facts
    from ansible.module_utils.facts.collector import get_caps_data
    from ansible.module_utils.facts.collector import parse_caps_data

    print(SystemCapabilitiesFactCollector_collect.__name__)
    # Mock the DummyModule class
    DummyModule_spec = {
        'run_command.return_value': ('', '', ''),
        'get_bin_path.return_value': None,
    }


# Generated at 2022-06-11 04:12:16.794397
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('In test_SystemCapabilitiesFactCollector_collect()')

# Generated at 2022-06-11 04:12:25.944199
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.collectors.system.capabilities as cap_facts
    import ansible.module_utils.facts.collectors.system.capabilities as cap_collector
    from ansible.module_utils.common._text import to_text
    import ansible.module_utils.common.process as process

    class MockModule:
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            self.cmd = cmd
            self.rc = 0

# Generated at 2022-06-11 04:12:27.739557
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector().collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-11 04:12:59.113106
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for method collect of class SystemCapabilitiesFactCollector'''
    ansible_module = MockAnsibleModule('/bin')
    result = SystemCapabilitiesFactCollector(ansible_module).collect()
    assert result['system_capabilities_enforced'] == 'True'
    assert result['system_capabilities'] == ['cap_chown', 'cap_dac_override',
                                             'cap_dac_read_search', 'cap_fowner',
                                             'cap_fsetid', 'cap_kill',
                                             'cap_setgid', 'cap_setuid',
                                             'cap_sys_chroot', 'cap_mknod',
                                             'cap_audit_write', 'cap_setfcap']


# Generated at 2022-06-11 04:13:08.411309
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = {"run_command": MagicMock()}

# Generated at 2022-06-11 04:13:17.186271
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    capsh_path = '/usr/sbin/capsh'
    rc = 0
    out = """Current: =ep
Bounding set =ep
Securebits: 00/0x0/1'b0 secure-noroot, secure-no-suid-fixup
secure-no-suid-fixup secure-keep-caps
  Ambient set =
Capabilities: =ep
Capability Bounding set =ep
Securebits: 00/0x0/1'b0 secure-noroot, secure-no-suid-fixup
secure-no-suid-fixup secure-keep-caps
  Ambient capabilites:
""".encode('utf-8')

    err = b''
    module.get_bin_path.return_value = capsh_path

# Generated at 2022-06-11 04:13:28.059440
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import shutil
    import unittest
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system

    class TestModule:
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, bin):
            return self.path + bin

        def run_command(self, args, **kwargs):
            if args[0] == self.path + 'capsh' and args[1] == '--print':
                return 0, "Current: =ep\n", ''

# Generated at 2022-06-11 04:13:35.419698
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Test the SystemCapabilitiesFactCollector class'''
    all_facts = {}
    class ModuleStub():
        def __init__(self):
            self.run_command_rc = 0

# Generated at 2022-06-11 04:13:40.744111
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    module = MockModule(
        run_command=lambda command, errors: (0, 'Current: =ep', '')
    )
    test_collector = SystemCapabilitiesFactCollector(module=module)

    # Test
    collected_facts = test_collector.collect()

    # Verify
    assert 'system_capabilities_enforced' in collected_facts
    assert 'system_capabilities' in collected_facts
    assert collected_facts['system_capabilities_enforced'] == 'False'
    assert collected_facts['system_capabilities'] == []


# Generated at 2022-06-11 04:13:49.846706
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # load a copy of the module and set the module path
    from ansible.module_utils import facts
    from ansible.module_utils._text import to_bytes
    from ansible.filters import core as core_filters
    # create the module used by the SystemCapabilitiesFactCollector class
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    module.run_command = FakeRunCommand
    module.get_bin_path = FakeGetBinPath
    # monkey patch the module
    module.__class__.__name__ = 'ansible.module_utils.basic.AnsibleModule'

    # invoke the collect method of SystemCapabilitiesFactCollector
    # creating an instance of SystemCapabilitiesFactCollector
    system_capabilities_

# Generated at 2022-06-11 04:13:51.319536
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    c = SystemCapabilitiesFactCollector()
    # TODO: write test code


# Generated at 2022-06-11 04:13:59.140292
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector

    # NOTE: Create a fake capsh in a temp directory
    temp_dir = tempfile.mkdtemp()
    open(os.path.join(temp_dir,"capsh"),"w").close()

    # NOTE: create a fake module object
    class TestAnsibleModule(object):
        def __init__(self):
            pass
        @staticmethod
        def get_bin_path(path):
            return os.path.join(temp_dir,path)

# Generated at 2022-06-11 04:14:06.690673
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # patch import of selinux
    import ansible.module_utils.facts.system.selinux
    ansible.module_utils.facts.system.selinux = None

    # get the facts
    fc = FactCollector(module=None)
    facts = fc.get_facts(collect_subset=['system_capabilities'])

    # make sure we got some caps data
    assert 'system_capabilities' in facts
    assert 'system_capabilities_enforced' in facts

    # assert some coverage

# Generated at 2022-06-11 04:15:19.180478
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def run_command_side_effect(args, errors='surrogate_then_replace'):
        rc = 0

# Generated at 2022-06-11 04:15:27.865151
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleMock
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector

    module = AnsibleModuleMock()

# Generated at 2022-06-11 04:15:36.601570
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    # Prepare the mock module_utils.
    #
    # Below we'll simply use an empty module (as if it were instantiated via
    # `AnsibleModule(argument_spec=dict())`) because the underlying code
    # doesn't rely on any of the attributes being present.
    class MockModule:
        pass

    module = MockModule()

    # Prepare the mock for `run_command()`
    def mock_run_command(args, **kwargs):

        if args[0] == '/usr/bin/capsh':
            stdout = to_bytes('Current: =ep\n')
        else:
            assert False

        return 0, stdout, ''


# Generated at 2022-06-11 04:15:44.951917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test_osx_SystemCapabilitiesFactCollector_collect
    '''
    # TODO: Incomplete test.  We need to find out how to mock a class
    #       method's 'run_command' method.
    #
    #       Also as written, this test will fail as the shell command
    #       xcode-select will not be able to be executed.
    #
    #       The test is here as a place to start.

    import sys
    import os
    import  platform

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import run_collector

# Generated at 2022-06-11 04:15:48.517367
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def run_command(binary, args, **kw):
        pass

    m = type('module', (object,), {
        'run_command': run_command,
        'get_bin_path': lambda x: '/usr/bin/capsh'
    })

    fc = SystemCapabilitiesFactCollector()
    fc.collect(m)

# Generated at 2022-06-11 04:15:56.377300
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock()
    module.get_bin_path = Mock()
    module.run_command = Mock()
    test_obj = SystemCapabilitiesFactCollector()

    # case 0.1 - get_bin_path returns None
    module.get_bin_path.return_value = None
    expected_result = {}
    actual_result = test_obj.collect(module)
    assert actual_result == expected_result

    # case 0.2 - get_bin_path returns valid path
    module.get_bin_path.return_value = '/usr/bin/capsh'

    # case 0.2.1 - run_command returns rc != 0
    module.run_command.return_value = (1, '', 'test msg')
    expected_result = {}
    actual_result = test_obj.collect(module)


# Generated at 2022-06-11 04:16:05.378677
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  # Test normal case when capsh returns valid output
  from ansible.module_utils.facts import Collector
  from ansible.module_utils._text import to_bytes
  module = Collector()
  module.get_bin_path = lambda x: x
  module.run_command = lambda x, errors: (0, to_bytes('Current:\t= eip cap_setpcap,cap_net_admin,cap_net_raw+eip'), to_bytes(''))
  fact_collector = SystemCapabilitiesFactCollector(module=module)
  assert fact_collector.collect() == {
      'system_capabilities_enforced': 'True',
      'system_capabilities': ['cap_setpcap', 'cap_net_admin', 'cap_net_raw']
  }

  # Test case when capsh returns invalid output

# Generated at 2022-06-11 04:16:13.356003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestModuleA(object):
        def __init__(self, rc, out, err, bin_path):
            self.rc = rc
            self.out = out
            self.err = err
            self.bin_path = bin_path

        def get_bin_path(self, binary, required=True):
            if binary == 'capsh':
                return self.bin_path
            return None

        def run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd[0] == self.bin_path:
                return (self.rc, self.out, self.err)
            else:
                return (1, '', 'error')

    class TestModuleB(object):
        def __init__(self, rc, out, err, bin_path=''):
            self.rc

# Generated at 2022-06-11 04:16:21.243981
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFacts

    import sys
    import os
    import copy
    import stat
    import shutil

    # NOTE: create a fake capsh command
    # NOTE: make it executable
    # NOTE: use real directory to avoid issues with LD_LIBRARY_PATH issues
    capsh_path = "/bin/capsh"
    capsh_bin = """
#!/bin/bash

echo "Current:  =ep"
"""
    capsh_fd = open(capsh_path, 'w')
    capsh_fd.write(capsh_bin)
    capsh_fd.close()
    capsh_mode = os.stat(capsh_path).st_mode

# Generated at 2022-06-11 04:16:26.085109
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.system.caps as caps
    import ansible.module_utils.facts.collectors.system.caps as collect_caps
    collect_caps.capsh = caps.capsh
    result = collector.collect(collect_caps.SystemCapabilitiesFactCollector(),
                               None,
                               ["system_capabilities",
                                "system_capabilities_enforced"])
    return result