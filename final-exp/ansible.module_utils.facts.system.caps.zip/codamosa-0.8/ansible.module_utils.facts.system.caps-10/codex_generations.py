

# Generated at 2022-06-11 04:07:16.393489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False

# Generated at 2022-06-11 04:07:18.346123
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    sys_caps_collector = SystemCapabilitiesFactCollector()
    assert sys_caps_collector.collect() == {}


# Generated at 2022-06-11 04:07:20.603198
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    SystemCapabilitiesFactCollector.collect(module)
    '''
    SystemCapabilitiesFactCollector.collect(None)

# Generated at 2022-06-11 04:07:21.162566
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:07:30.401413
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:07:40.062530
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = MagicMock()
    test_module.run_command.return_value = 0, "Current:\t=ep", ""
    class_under_test = SystemCapabilitiesFactCollector()
    result = class_under_test.collect(test_module)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Generated at 2022-06-11 04:07:45.902561
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = '/bin/capsh'
    mock_module.run_command.return_value = (0, 'Current: =ep', '')
    mock_facts = SystemCapabilitiesFactCollector()
    actual_result = mock_facts.collect(mock_module)
    expected_result = {'system_capabilities': [], 'system_capabilities_enforced': 'False'}
    assert actual_result == expected_result

# Generated at 2022-06-11 04:07:46.873740
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: implement unit test
    pass

# Generated at 2022-06-11 04:07:56.519352
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import tempfile
    import os
    import shutil
    import stat
    import __builtin__
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        args = {}
        def __init__(self):
            self.PATH = "/usr/bin:/usr/sbin:/bin:/sbin"
            self.params = {'gather_subset': ['all'], 'gather_timeout': 5}
            self.tmpdir = tempfile.mkdtemp()

        def run_command(self, args, errors='surrogate_then_replace'):
            print("module.run_command: %s" % (args))
            # write capsh output to tmpfile
            capsh_out = ''

# Generated at 2022-06-11 04:07:57.835435
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass
    # TODO: Write a unit test for SystemCapabilitiesFactCollector.collect

# Generated at 2022-06-11 04:08:03.037574
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # The only thing we can easily validate is that the method does not crash
    # -akl

    collector = SystemCapabilitiesFactCollector(dict(), dict(), None)
    collector.collect()

# Generated at 2022-06-11 04:08:08.753190
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Facts(dict):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs
    module = Facts(run_command=lambda *args, **kwargs: (0, 'Current: =ep', ''))
    result = SystemCapabilitiesFactCollector().collect(module=module)
    assert result == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-11 04:08:15.848035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockModule:
        def __init__(self):
            self.params = dict()
        def get_bin_path(self, arg):
            return '/path/to/capsh'

# Generated at 2022-06-11 04:08:17.275045
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #TODO: Implement test
    assert False

# Generated at 2022-06-11 04:08:27.542742
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import pytest

    from ansible.module_utils.facts.collector import collect
    from ansible.module_utils.facts.collector import AnsibleModuleFakeMSG
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import AnsibleModuleMock
    from ansible.module_utils.facts.system.capabilities import AnsibleModuleMockReturnOut

    fact_collector = SystemCapabilitiesFactCollector()

    # Test with no capsh
    collected_facts = collect(fact_collector, AnsibleModuleFakeMSG())
    assert collected_facts['system_capabilities'] == []
    assert collected_facts['system_capabilities_enforced'] == 'NA'

    # Test get_caps_data


# Generated at 2022-06-11 04:08:36.731127
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.bin_path = '/bin/'
            self.run_command_out = ('Current: =ep', 'CapInh: ', 'CapPrm: ', 'CapEff: ', 'CapBnd: ', 'CapAmb:')
            self.run_command_rc = 0

        def get_bin_path(self, app):
            return self.bin_path + app

        def run_command(self, args, errors='surrogate_then_replace'):
            return self.run_command_rc, self.run_command_out, ''

    mod = MockModule()
    facts_dict = SystemCapabilitiesFactCollector().collect(module=mod)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_

# Generated at 2022-06-11 04:08:44.467687
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test function collect of SystemCapabilitiesFactCollector.
    """
    import mock
    import os

    def run_command(args):

        class MockModule(object):
            def __init__(self):
                self.params = {}

            def set_options(self):
                return False

            def get_bin_path(self, path):
                return "/usr/bin/{}".format(path)

            def run_command(self, args, errors="surrogate_then_replace"):
                rc = 0
                out = ""
                err = ""
                if args[0] == "/usr/bin/capsh":
                    if args == ['/usr/bin/capsh', "--print"]:
                        rc = 0

# Generated at 2022-06-11 04:08:52.351429
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test = SystemCapabilitiesFactCollector()
    out = "Current: =ep"
    module = MockModule(out)
    collected_facts = {}
    expected = {'system_capabilities_enforced': 'False',
                'system_capabilities': []}

    fact_dict = test.collect(module, collected_facts)
    assert fact_dict == expected


from ansible.module_utils.facts import collector

from ansible.module_utils.facts.collector import BaseFactCollector

# NOTE: mock.Mock not available in Python2.6
from ansible.module_utils.six import with_metaclass


# Generated at 2022-06-11 04:08:53.732339
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: add a 'simple' unit test for .collect() -akl
    pass

# Generated at 2022-06-11 04:09:03.218633
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def run_command(args, **kwargs):
        if args[0] == '/bin/capsh':
            return 256, 'capsh: =ep not permitted\nCurrent: =ep\n', ''
        else:
            return 256, '', ''
    module = Mock(get_bin_path=Mock(return_value='/bin/capsh'), run_command=run_command)
    collector = SystemCapabilitiesFactCollector(module=module)
    facts = collector.collect()
    assert 'system_capabilities' in facts
    assert facts['system_capabilities'] == []
    assert 'system_capabilities_enforced' in facts
    assert facts['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:09:17.760969
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import re
    import textwrap
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import _CapsFactCollector
    _SystemCapabilitiesFactCollector = _CapsFactCollector.SystemCapabilitiesFactCollector

    class MockModule(object):
        def __init__(self, bin_path, command, stdout):
            self.command = command
            self.bin_path = bin_path
            self.stdout = stdout

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

        def run_command(self, *args, **kwargs):
            return 0, self.stdout, ''


# Generated at 2022-06-11 04:09:19.432804
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module.run_command, module.get_bin_path -akl
    pass

# Generated at 2022-06-11 04:09:20.684952
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:09:30.612903
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class TestModule(object):
        def __init__(self):
            self.called_command = None

        def get_bin_path(self, binary, required=True):
            if binary == "capsh":
                return "/usr/bin/capsh"
            else:
                return None

        def run_command(self, command, check_rc=False, errors='surrogate_then_replace'):
            self.called_command = command

    mod = TestModule()

    facts = {}
    sut = SystemCapabilitiesFactCollector(mod, facts)

    sut.collect()

    assert len(mod.called_command) == 2
    assert mod.called_command[0] == "/usr/bin/capsh"
    assert mod.called_command[1] == "--print"

# Generated at 2022-06-11 04:09:32.879427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: not yet implemented
    assert False, "test not implemented"
    # assert False, "unexpected failure"
    # assert True, "unexpected success"


# Generated at 2022-06-11 04:09:42.563555
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module to be more easily mockable -akl
    module = Mock
    # NOTE: mock module.run_command() to be more easily mockable -akl
    module.run_command = Mock

# Generated at 2022-06-11 04:09:50.003308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #NOTE: using 'fakeansible' module so we don't need to fake 'capsh' on server
    mock_module = FakeAnsibleModule()

# Generated at 2022-06-11 04:09:59.092319
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import surjective_mock

    mock_module = surjective_mock.MockModuleForFacts()
    mock = surjective_mock.SurjectiveMock()

    mock_module.get_bin_path = mock.get_bin_path

    # Test case with capsh_path
    mock_module.get_bin_path.return_value = 'capsh_path'
    mock_module.run_command.return_value = (0, 'Current: =ep', '')

    facts_dict = SystemCapabilitiesFactCollector().collect(mock_module)
    assert facts_dict.get('system_capabilities_enforced') == 'False'
    assert len(facts_dict.get('system_capabilities')) == 0


    # Test case with capsh

# Generated at 2022-06-11 04:10:07.932719
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # initialize Ansible module
    from ansible.module_utils.facts.collector import get_collector_instance
    a = get_collector_instance('SystemCapabilitiesFactCollector')
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()

    # initialize incoming ansible facts
    module = AnsibleModuleMock()
    module.run_command = module_run_command

    # run the collect method of SystemCapabilitiesFactCollector
    result = c.collect(module, None)

    # ensure result is not empty
    assert result.get('system_capabilities') is not None
    assert result.get('system_capabilities_enforced') is not None


# Generated at 2022-06-11 04:10:17.304709
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    A simple unit test, to verify if SystemCapabilitiesFactCollector.collect()
    is returning a proper set of facts, as expected.
    """
    from ansible.module_utils.facts import collector

    class FakeModule(object):
        def __init__(self):
            self.run_command_result = (0, 'Current: =ep\nSecurebits: 00/0x0/1\'b0 secure-noroot', None)
            self.run_command_exception = None

        def get_bin_path(self, path, opt_dirs=None, required=False):
            return "/usr/bin/capsh"

        def run_command(self, args, errors='surrogate_then_replace'):
            if self.run_command_exception:
                raise self.run_command_exception

# Generated at 2022-06-11 04:10:33.832387
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    import sys
    import os
    import unittest
    from contextlib import contextmanager
    from ansible.module_utils.facts import collector

    class fake_module(object):
        @staticmethod
        def get_bin_path(name, opt_dirs=[]):
            return '/bin/capsh'

        @staticmethod
        def run_command(cmd, errors='surrogate_then_replace'):
            return (0, "", "")

        @staticmethod
        def join_path(path1, path2):
            return os.path.join(path1, path2)

    @contextmanager
    def rsysopen(file, *mode):
        yield


# Generated at 2022-06-11 04:10:35.854989
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create instance of class SystemCapabilitiesFactCollector
    factsCollector = SystemCapabilitiesFactCollector()

    # Check that the instance created is of the correct type
    assert isinstance(factsCollector, SystemCapabilitiesFactCollector)


# Generated at 2022-06-11 04:10:40.139868
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    assert fact_collector.collect(collected_facts) == collected_facts # Note: the class doesn't actually have access to module, so this is probably a bug and should be None or something else
    fact_collector = None

# Generated at 2022-06-11 04:10:43.725808
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector

    sc = SystemCapabilitiesFactCollector()

    assert sc._fact_ids == {'system_capabilities',
                            'system_capabilities_enforced'}

    assert sc.name == 'caps'

# Generated at 2022-06-11 04:10:52.433420
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    def mock_module_run_command(self, args, **kwargs):
        class MockRunCommand(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

            def __call__(self, args, **kwargs):
                return (self.rc, self.stdout, self.stderr)

        capsh_path = self.get_bin_path('capsh')
        if args[0] == capsh_path:
            return MockRunCommand(0, out='Current: =ep', err='')()
        else:
            return MockRunCommand(0, out='', err='')()


# Generated at 2022-06-11 04:10:55.264301
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    testCollector = SystemCapabilitiesFactCollector()
    from ansible.module_utils.facts.test_modules.test_system import CapabilitiesModule
    module = CapabilitiesModule()
    assert testCollector.collect(module)

# Generated at 2022-06-11 04:11:04.239688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    from ansible.module_utils.facts.collector import MockModule, MockFile, MockCommand
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector

    os.environ['PATH'] = '.'

    mock_module = MockModule()
    mock_file = MockFile({
        '/proc/sys/kernel/cap_last_cap': '10',
        '/proc/sys/kernel/cap_bound': '8',
    })

    # NOTE: Consider using @mock.patch to mock 'capsh' command -aks
    def mock_exist(path):
        import os
        if path == 'capsh':
            return True
        else:
            return os.path.exists(path)

    # NOTE: Consider using @mock.patch to mock 'capsh'

# Generated at 2022-06-11 04:11:12.700853
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    caps_path = '/usr/bin/capsh'

    class TestModule(object):
        def get_bin_path(self, name):
            return caps_path

        def run_command(self, cmd, **kwargs):
            return capsh_rc, capsh_out, capsh_err
    module = TestModule()
    capsh_rc = 0

# Generated at 2022-06-11 04:11:21.071600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    test collect()
    """

    module = Mock(
        get_bin_path=Mock(return_value='/usr/bin/capsh')
    )
    module.run_command.return_value = (0, 'Current: =ep cap_net_admin,cap_net_raw+ep\nBounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+i\n', "")
    module.INVOCATION = Mock()


    result = {}

# Generated at 2022-06-11 04:11:24.370194
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect()
    assert isinstance(facts_dict, dict)
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict


# Generated at 2022-06-11 04:11:45.925442
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collect_subset

    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set(['fact1', 'fact2'])

        def collect(self, module=None, collected_facts=None):
            return dict(fact1='foo', fact2='bar')

    # if we don't have a valid capsh_path, no facts should be returned
    module = MagicMock(name='module')
    module.get_bin_path.return_value = None
    setattr(module, 'run_command', MagicMock())

    fact_collector = SystemCap

# Generated at 2022-06-11 04:11:54.892647
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """This test function is used to check if collect function returns correct values for each if condition.
    """
    import ansible.module_utils.facts.collector
    import ansible.module_utils.basic
    import os

    # Create mock objects
    module_mock = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    ansible.module_utils.facts.collector.BaseFactCollector.get_bin_path = \
        get_bin_path_mock = lambda self, name: capsh_path_mock
    ansible.module_utils.basic.AnsibleModule.run_command = lambda self, cmd: run_command_mock[cmd]
    ansible.module_utils.basic.AnsibleModule.get_bin_path = get_bin_path_mock

   

# Generated at 2022-06-11 04:11:58.286230
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    os_facts = {}
    obj_collector = SystemCapabilitiesFactCollector(None, config={}, source='test')
    obj_collector.collect()
    assert 'system_capabilities_enforced' in os_facts
    assert 'system_capabilities' in os_facts

# Generated at 2022-06-11 04:12:07.638853
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    module = FakeModule()
    collector = SystemCapabilitiesFactCollector(module=module)

# Generated at 2022-06-11 04:12:11.833704
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import module_util
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    test_module = module_util
    test_collector = SystemCapabilitiesFactCollector(test_module)

    test_collector.collect()
    # assert test_collector.collect() is None
    return


# Generated at 2022-06-11 04:12:21.192251
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:12:29.870017
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import get_file_content
    import json
    import sys

    # Create an AnsibleModule (required to execute ansible code)
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=True
    )

    # Get a reference to the SystemCapabilitiesFactCollector object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Execute tested method
    collected_facts = system_capabilities_fact_collector.collect(module=module)

    # Check the result
    # NOTE: This test is system-specific
    # For

# Generated at 2022-06-11 04:12:35.316877
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Init a module, without failing, even if the module doesn't exist
    module = MagicMock(name='ansible.builtin.get_caps', spec='ansible.module_utils.basic.AnsibleModule')
    module.run_command.return_value = (0, '', '')
    # Create a collector we can test
    collector = SystemCapabilitiesFactCollector()
    # Call the collect() method, with a current module
    result = collector.collect(module=module)
    assert result

# Generated at 2022-06-11 04:12:37.085527
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    module = MockModule()
    fact_collector.collect(module, collected_facts={})

# Generated at 2022-06-11 04:12:45.702891
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess
    class mock_module(object):
        class run_command(object):
            def __init__(self,text):
                self.rc = 0
                if not text:
                    self.rc = 1
                    self.out = None
                    self.err = 'cannot find capsh'

# Generated at 2022-06-11 04:13:18.345265
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Build a mock module
    mock_module = basic.AnsibleModule(argument_spec={})
    mock_module.run_command = lambda *args, **kwargs: (0,
                                                       'Current: =ep\nBounding set =eip\nSecure bits: 00/0x0/1'
                                                       '\n secure-noroot\n secure-no-suid-fixup\n secure-keep-caps',
                                                       '')
    mock_module.get_bin_path = lambda *args: '/bin/capsh'

    # Build a test class and run the collect method
    test_class = collector.FactsCollector()

# Generated at 2022-06-11 04:13:29.158397
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()
    mock_module.get_bin_path.return_value = '/bin/capsh'
    mock_module.run_command.return_value = (0, 'Current: =ep', None)
    # NOTE: for mocking TEST_CASES or subdictionaries -akl
    _expected_facts = {'system_capabilities_enforced': 'False',
                       'system_capabilities': []}
    # NOTE: we cannot have more test cases than facts; if you need to test
    # this condition then mock the return of collect() as it will return a
    # random fact anyway

# Generated at 2022-06-11 04:13:35.774293
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Initializing mock module
    module_mock = AnsibleModuleMock(
        argument_spec={},
        supports_check_mode=True
    )
    module_mock.run_command = mock_run_command

    # Initializing SystemCapabilitiesFactCollector()
    system_capabilities_collector = SystemCapabilitiesFactCollector(module=module_mock,
                                                                    collected_facts=None)
    # Calling collect()
    collected_facts = system_capabilities_collector.collect()
    assert collected_facts['system_capabilities_enforced'] == 'True'
    assert collected_facts['system_capabilities'] == ['cap_chown', 'cap_fowner', 'cap_fsetid']


# Generated at 2022-06-11 04:13:40.197573
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:13:42.495607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    o = SystemCapabilitiesFactCollector()
    assert o.collect() == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA'
    }

# Generated at 2022-06-11 04:13:49.377215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Prepare test
    class CapshModule:
        def run_command(self, args, **options):
            return 0, "Current:\t=ep\nBounding set =ep", ""
        def get_bin_path(self, *args):
            return '/bin/capsh'

    fact_collector = SystemCapabilitiesFactCollector()

    # Run test
    module = CapshModule()
    returned_facts = fact_collector.collect(module)

    # Assert results
    assert returned_facts == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}


# Generated at 2022-06-11 04:13:57.337788
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock module object
    class MockModule(object):
        def get_bin_path(self, cmd):
            return "capsh"

        def run_command(self, args, errors='surrogate_then_replace'):
            out = 'Current: =ep Bounding set =cap_chown,cap_dac_override'
            return (0, out, "")

    module = MockModule()

    # mock collected_facts
    class MockCollectedFacts(object):
        def __init__(self):
            self.data = {}

        def update(self, fact):
            self.data.update(fact)
            return self.data

    collected_facts = MockCollectedFacts()

    collector = SystemCapabilitiesFactCollector(module=module,
    collected_facts=collected_facts)

    facts_

# Generated at 2022-06-11 04:14:04.717072
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import io
    import errno
    import collections
    import os

    class MockModule(object):
        def __init__(self, capsh_path):
            self.caps_data = collections.OrderedDict()

# Generated at 2022-06-11 04:14:08.423426
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    fc = SystemCapabilitiesFactCollector()

    rc, out, err = module.run_command.return_value
    fc.collect(module)

    module.run_command.assert_called_with('/usr/bin/capsh --print'.split(), errors='surrogate_then_replace')


# Generated at 2022-06-11 04:14:13.447606
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockExecuteModule()
    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}
    facts_dict = fact_collector.collect(module=module, collected_facts=collected_facts)
    assert 'system_capabilities_enforced' in facts_dict
    assert 'system_capabilities' in facts_dict
    assert facts_dict['system_capabilities_enforced'] == 'NA'
    assert facts_dict['system_capabilities'] == []


from ansible.module_utils.basic import *

# Generated at 2022-06-11 04:15:28.496311
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class module_helper(object):
        def __init__(self, module, expected_command, expected_out, expected_enforced, expected_caps):
            self.module = module
            self.expected_command = expected_command
            self.expected_out = expected_out
            self.expected_enforced = expected_enforced
            self.expected_caps = expected_caps
            self.run_command_called = False
            self.get_bin_path_called = False
            self.get_bin_path_path = None

        def get_bin_path(self, path):
            if path != 'capsh':
                return None

            self.get_bin_path_called = True
            self.get_bin_path_path = path

            return '/usr/bin/capsh'


# Generated at 2022-06-11 04:15:37.265831
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    # Create instance of SystemCapabilitiesFactCollector
    sys_cap_fact_collector = ansible_collector.get_collector(SystemCapabilitiesFactCollector.name)

    # Set facts dict to be returned by ansible_collector.get_collector('system')
    ansible_collector.set_module_utils_facts_facts(dict(system_capabilities=[]))

    # Get fact_ids supported by SystemCapabilitiesFactCollector
    assert set(sys_cap_fact_collector.collect().keys()) == SystemCapabilitiesFactCollector._fact_ids

    # TODO: test code using capsh return values -akl
    pass

# Generated at 2022-06-11 04:15:41.109334
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule:
        def __init__(self):
            self.run_command = lambda a, b: (0, 'Current: =ep', '')
            self.get_bin_path = lambda b: '/usr/bin/capsh'

    caps = SystemCapabilitiesFactCollector()

    assert caps.collect(MockModule())

# Generated at 2022-06-11 04:15:49.096995
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Unit test for method collect of class SystemCapabilitiesFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = MockRunCommand()

    fact_collector = collector.get_collector('SystemCapabilitiesFactCollector', module=module)
    assert isinstance(fact_collector, SystemCapabilitiesFactCollector)

    out_dict = fact_collector.collect(module=module)
    assert isinstance(out_dict, dict)
    assert out_dict['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-11 04:15:57.076695
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import mock_module_params


# Generated at 2022-06-11 04:16:06.158368
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # No Mock
    mm = ModuleManagerMock()
    kwargs = {
    }

# Generated at 2022-06-11 04:16:13.737104
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock module class for unit test
    class mymodule:
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return ''
        @staticmethod
        def run_command(*args, **kwargs):
            return [0, '', '']
    module = mymodule()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    expected = {'system_capabilities': '', 'system_capabilities_enforced': 'NA'}
    collector = SystemCapabilitiesFactCollector()
    facts = collector.collect(module)
    assert facts == expected

# Generated at 2022-06-11 04:16:15.449213
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # A 'test' for this collector is inherently platform- and version-specific,
    # and so is not much help here.
    pass

# Generated at 2022-06-11 04:16:16.599968
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # unit test for method collect of class SystemCapabilitiesFactCollector
    pass

# Generated at 2022-06-11 04:16:18.569563
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector().collect() == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA'
    }