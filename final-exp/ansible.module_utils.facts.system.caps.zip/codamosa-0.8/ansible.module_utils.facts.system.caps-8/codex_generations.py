

# Generated at 2022-06-11 04:07:22.820213
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FetchModuleCache
    module_mock = FetchModuleCache()
    module_mock.run_command = lambda x,**kwargs: [0, 'Current:	=ep', '']
    module_mock.get_bin_path = lambda x: '/usr/bin/capsh'
    expected_facts = {
        'system_capabilities_enforced': 'False',
        'system_capabilities': [],
    }
    fact_collector = SystemCapabilitiesFactCollector(module_mock)
    assert(fact_collector.collect() == expected_facts)

    module_mock.run_command = lambda x,**kwargs: [0, 'Current:	=ip', '']

# Generated at 2022-06-11 04:07:32.252250
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    # NOTE: use mock module to mock class 'AnsibleModule'
    # NOTE: which is used in function 'collect' of class SystemCapabilitiesFactCollector
    import mock
    import sys

    class MockSystemCapabilitiesCollector(SystemCapabilitiesFactCollector):
        # Overwrite method collect of class SystemCapabilitiesFactCollector
        # to test it
        def collect(self, module=None, collected_facts=None):
            # NOTE: mock 'AnsibleModule' class
            with mock.patch('ansible.module_utils.facts.collector.AnsibleModule', mock.Mock()):
                super(MockSystemCapabilitiesCollector, self).collect(module=module, collected_facts=collected_facts)

    system_

# Generated at 2022-06-11 04:07:41.188581
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Unit tests should not be testing return values of execute_module(),
    # instead mock module_runner.run_module() (and others) and test
    # the return value of run_module() or similar method. -akl
    module = MagicMock()

# Generated at 2022-06-11 04:07:41.749297
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:07:51.261612
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import defaults

    module = defaults.get_module_object('CommandModule', 'command')
    capsh_path = module.get_bin_path('capsh')
    class MockRunCommand():
        text='Current: =ep'
        rc=0
    module.run_command = MockRunCommand

    fact_collector = SystemCapabilitiesFactCollector()
    if capsh_path:
        facts_dict = fact_collector.collect(module)
        assert facts_dict['system_capabilities_enforced'] == 'False'
        assert facts_dict['system_capabilities'] == []
    else:
        facts_dict = fact_collector.collect(module)
        assert 'system_capabilities_enforced' not in facts_dict
        assert 'system_capabilities' not in facts_

# Generated at 2022-06-11 04:08:00.154904
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method SystemCapabilitiesFactCollector.collect of class
    SystemCapabilitiesFactCollector
    """
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector

    fact_collector = SystemCapabilitiesFactCollector()
    assert 'caps' == fact_collector.name
    assert SystemCapabilitiesFactCollector._fact_ids == fact_collector._fact_ids
    assert fact_collector.collect() == None
    assert fact_collector.collect(module=None) == {}

    # TODO: create mock of ansible.module_utils.facts.collector.BaseFactCollector.run_command

# Generated at 2022-06-11 04:08:04.776269
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test for method collect of class SystemCapabilitiesFactCollector '''

    # inputs
    module = None
    collected_facts = {}

    # creation and test
    cls = SystemCapabilitiesFactCollector()
    cls.collect(module, collected_facts)

    # no asserts; collector module functions tested by test_module_utils_facts_collectors.py
    assert True

# Generated at 2022-06-11 04:08:13.696571
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    sut = SystemCapabilitiesFactCollector()

    # Expected result

# Generated at 2022-06-11 04:08:24.353161
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import shutil
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    curdir = os.path.dirname(os.path.realpath('__file__'))
    parentdir = os.path.dirname(curdir)

# Generated at 2022-06-11 04:08:33.692224
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Creating a mock class to be used as a fake AnsibleModule
    class MockAnsibleModule():
        def __init__(self):
            pass

        @staticmethod
        def get_bin_path(filename, *args, **kwargs):
            return '/bin/capsh'

        @staticmethod
        def run_command(cmd_args, *args, **kwargs):
            out = 'Current: = cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip\n'
            return (0, out, None)

# Generated at 2022-06-11 04:08:42.151009
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    dummy_module = DummyModule(dict())
    dummy_module.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    facts_dict = collector.collect(dummy_module, dict())
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []
    assert len(facts_dict) == 2


# Generated at 2022-06-11 04:08:42.647901
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-11 04:08:50.054864
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Patch(target=module, attribute=None, value=None, initial=True)
    def mock_run_command(module, cmd, errors='surrogate_then_replace'):
        print("Mocking: %s" % cmd)
        return 0, "Current: = cap_net_bind_service+ep", ""

    module = MagicMock()
    module.run_command = mock_run_command

    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(module)

    print("RESULT: %s" % result)


# Generated at 2022-06-11 04:09:00.214419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import wsman
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector

    c = wsman.WsmanFactCollector() # Mock CIMC Wsman request
    c.collect()

    m = Collector() # Mock ansible module
    m.run_command = mock.Mock()
    m.run_command.return_value = (0, 'Current: =ep 	Bounding set =cap_sys_admin,cap_sys_nice,cap_syslog,cap_mknod,cap_audit_write,cap_setfcap', '')

    sc = SystemCapabilitiesFactCollector(m)
    s = sc.collect()

# Generated at 2022-06-11 04:09:07.908279
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """SystemCapabilitiesFactCollector.collect test cases"""

    from ansible.module_utils.facts.collector import FactsCollector

    module = AnsibleModule(argument_spec=dict())

    # Mock the module and available class members
    module.run_command = MagicMock(
        return_value=(0, 'Current: =ep\nBounding set =ep cap_net_bind_service\nSecurebits: 00/0x0/1\n', '')
    )
    module.get_bin_path = MagicMock(return_value="capsh")

    # Create the facts collector and populate the facts
    facts_collector = FactsCollector(module=module, collectors=[SystemCapabilitiesFactCollector],
                                     collected_facts=dict())
    facts = facts_collector.collect()

    # Verify results
    assert facts

# Generated at 2022-06-11 04:09:17.125037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ..system_capabilities_collector import SystemCapabilitiesFactCollector

    module = MagicMock()
    setattr(module, 'run_command', MagicMock(return_value=(0, "Current: =ep\nBounding set =cap_chown,cap_dac_override,cap_killing,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip", None)))
    set_module_args(dict())


# Generated at 2022-06-11 04:09:27.220702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    
    # FIXME: needs mocking! -akl
    

# Generated at 2022-06-11 04:09:36.575439
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.utils import AnsibleExit

    class DummyModule(object):
        def __init__(self):
            self.run_command_result = dict()

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, errors='surrogate_then_replace'):
            try:
                return self.run_command_result[cmd]
            except KeyError:
                raise AnsibleExit(msg='Unexpected command')

        def exit_json(self, msg):
            print(json.dumps(msg))

    class TestSystemCapabilitiesFactCollector:
        def test_collect_without_module(self):
            fc = get_

# Generated at 2022-06-11 04:09:45.290364
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_dict = {}
    test_module = MockModule()
    SystemCapabilitiesFactCollector(test_module).collect(test_module, test_dict)
    assert test_dict['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:09:54.184309
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = MockModule()
    fc = SystemCapabilitiesFactCollector(m)
    facts = fc.collect()

# Generated at 2022-06-11 04:10:09.717956
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import sys

    # Python 2.6 introduces the 'OrderedDict' type.  Newer versions of Python
    # have it in 'collections'.  This code ensures that the 'OrderedDict' is
    # available in a way that is both Python 2.6 and Python 3.x compatible.
    if sys.version_info[:2] == (2, 6):
        from ordereddict import OrderedDict
    else:
        from collections import OrderedDict

    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):

        def __init__(self):
            self.params = OrderedDict()
            self.params['gather_subset'] = ['!all', 'cap']
            self.run_command_environ_update = dict()


# Generated at 2022-06-11 04:10:18.804682
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info[0] > 2:
        from builtins import str as text
    else:
        from __builtin__ import unicode as text

    class MockModule:
        def __init__(self, bin_path, return_value=None):
            self.bin_path = bin_path
            self.return_value = return_value

        def get_bin_path(self, _):
            return self.bin_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            if self.return_value:
                return (0, self.return_value, None)

# Generated at 2022-06-11 04:10:29.234723
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collectors.system.system_capabilities as caps
    import ansible.module_utils.facts.collectors.system.system as system
    import ansible.module_utils.facts.collectors.system as system_base
    import ansible.module_utils.facts.collectors as collectors
    import ansible.module_utils.facts.utils as utils
    import ansible.module_utils.facts as ansible_facts

    module = ansible_facts.AnsibleModuleMock()
    module.get_bin_path = system.SystemFactCollector.get_bin_path
    collectors.collectors['system'] = system.SystemFactCollector(module)
    # Add capsh binary
    module.get_bin_path.return_value = 'capsh'
    # Mock capsh response

# Generated at 2022-06-11 04:10:37.800061
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_facts as source_facts

    mod = MockModule()

    # Test case - collector name property
    actual = SystemCapabilitiesFactCollector.name
    expected = 'caps'
    assert actual == expected

    # Test case - SystemCapabilitiesFactCollector has required facts in _fact_ids
    actual = hasattr(SystemCapabilitiesFactCollector, '_fact_ids')
    expected = True
    assert actual == expected

    # Test case - SystemCapabilitiesFactCollector
    # _fact_ids property contains all required fact names
    required_fact_names = {'system_capabilities', 'system_capabilities_enforced'}
    actual = SystemCapabilitiesFactCollector._fact_ids == required_fact_names
    expected = True

# Generated at 2022-06-11 04:10:38.888622
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capability = SystemCapabilitiesFactCollector()
    capability.collect()

# Generated at 2022-06-11 04:10:45.048711
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock

    b = SystemCapabilitiesFactCollector()
    m = mock.Mock()
    m.get_bin_path.return_value = '/bin/capsh'
    m.run_command.return_value = 0, "Current:\tcap_chown,cap_dac_override+eip", "error"
    result = b.collect(module=m, collected_facts=None)

    assert result == {'system_capabilities_enforced': 'True', 'system_capabilities': ['cap_chown', 'cap_dac_override']}

# Generated at 2022-06-11 04:10:45.951922
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:10:47.660485
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Call method collect of SystemCapabilitiesFactCollector to gather facts
    SystemCapabilitiesFactCollector().collect(collected_facts={})

# Generated at 2022-06-11 04:10:56.655330
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import unittest
    import ansible.module_utils.facts.collector

    class AnsibleModuleMock():
        def __init__(self):
            self.module = None
            self.params = None
            self.args = None
            self.check_mode = None

        def run_command(self, command, errors='surrogate_then_replace'):
            output = []
            import os
            output.append(os.getcwd())
            return (0, '\n'.join(output), '')

        def get_bin_path(self, bin_name):
            return '/usr/bin/capsh'

    def get_test_inits_mock(test_case, klass):
        def get_test_inits(self):
            init = {}
            init['module']

# Generated at 2022-06-11 04:11:02.265417
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # pylint: disable=import-error
    from ansible.module_utils.facts.collectors import SystemCapabilitiesFactCollector

    facts_dict = SystemCapabilitiesFactCollector().collect()
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict
    assert isinstance(facts_dict['system_capabilities'], list)
    assert isinstance(facts_dict['system_capabilities_enforced'], str)

# Generated at 2022-06-11 04:11:15.543463
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Init
    test_obj = SystemCapabilitiesFactCollector()

    # Test
    test_obj.collect()

# Generated at 2022-06-11 04:11:24.118021
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Note: This is currently a 'duplicate' of test_SELinuxFactCollector_collect
    # Due to the nature of testing Ansible modules, we'll need to duplicate the
    # tests for the individual fact collectors if we want to be able to test
    # them in isolation.
    import ansible.utils.module_docs as module_docs
    from ansible.utils.module_docs import get_docstring
    from ansible.module_utils.facts.collector import BaseFactCollector
    import pytest
    #from pytest_mock import mocker
    
    # Fake, in-memory module for testing
    class MockModule(object):
        def __init__(self):
            self.check_mode = False
            self.debug = False
            self.failed = False
            self.params = {}

# Generated at 2022-06-11 04:11:32.891812
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = 'module'
    collected_facts = ['collected_facts']

    class MockRunCommand(object):
        def __init__(self):
            self.rc = 0
            self.out = 'Current: =ep'
            self.err = ''

        def __call__(self, args, errors):
            return (self.rc, self.out, self.err)

    # We import one module
    module_import = __import__(module)
    # We use its method
    get_bin_path = module_import.get_bin_path
    run_command = module_import.run_command

    # Mock the module methods
    module_import.get_bin_path = lambda x: "/fake/path/caps"
    module_import.run_command = MockRunCommand()

    # init the collector
    sc

# Generated at 2022-06-11 04:11:42.273387
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    # Make a test module object
    test_module = ansible.module_utils.facts.collector.BaseFactCollector()
    # Mock the module run_command function
    test_module.run_command = create_test_run_command()
    # Test instance of SystemCapabilitiesFactCollector
    test_instance = SystemCapabilitiesFactCollector()
    # Test the return of fact collection method
    result = test_instance.collect(test_module)

# Generated at 2022-06-11 04:11:51.533296
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os

    if sys.version_info < (2, 7):
        from unittest2 import TestCase, TestLoader, SkipTest
    else:
        from unittest import TestCase, TestLoader, SkipTest

    from ansible.module_utils.facts import collector

    class TestModuleUtils(object):
        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])

        def get_bin_path(self, path):
            return '/bin/capsh'

        def run_command(self, cmd, errors='stderr'):
            os.environ['PATH'] = os.path.dirname(__file__)

# Generated at 2022-06-11 04:12:01.041115
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Testcase:
      # 1. module = None
      # 2. capsh_path = None
      # 3. capsh_path = '/usr/bin/capsh'
         # 3.1. Get Current cap
         # 3.2. Get Bounding set and Effective set
    import unittest.mock as mock
    import sys
    test_case_pass = True
    # 1.
    test_obj = SystemCapabilitiesFactCollector()
    test_res = test_obj.collect()
    if test_res != {}:
        test_case_pass = False
    # 2.
    test_obj = SystemCapabilitiesFactCollector()
    test_res = test_obj.collect(mock.Mock(get_bin_path=mock.Mock(return_value=None)))

# Generated at 2022-06-11 04:12:01.603748
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:12:02.009690
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:12:09.791669
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    class SysCapModule:
        def get_bin_path(self, path):
            return '/usr/bin/capsh'
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, 'Capabilities for `/bin/sh\':\nCurrent: =ep\nBounding set =ep cap_setpcap+eip', ''

    m_module = SysCapModule()
    m_facts = ModuleFacts(m_module)
    facts = SystemCapabilitiesFactCollector(
            m_facts).collect()
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

# Generated at 2022-06-11 04:12:19.140320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import test.support
    import os
    import tempfile

    class mock_module(object):

        def __init__(self):
            self.run_command_mock = None

        def get_bin_path(self, path, opt_dirs=[]):
            return self.run_command_mock

        def run_command(self, args, check_rc=None, close_fds=None, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, raise_err=True, input=None, errors=None):
            if self.run_command_mock:
                return 0, 'Current: =ep', ''
            else:
                return 256, '', ''

    def mock__original_load_file(module, datadir, filename):
        return filename

   

# Generated at 2022-06-11 04:12:45.823574
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:12:54.869332
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system
    import subprocess

    class MockModule(object):
        def __init__(self):
            self.binary_location = "/usr/bin/"

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return "/usr/bin/capsh"

        def run_command(self, args):
            return (0, "Current: =ep", "")

    mock_module = MockModule()

    result = dict()
    result['system_capabilities'] = []
    result['system_capabilities_enforced'] = "False"

    c = ansible.module_utils.facts.collector.system.SystemCapabilitiesFactCollector()
    assert c.collect(mock_module) == result

# Generated at 2022-06-11 04:13:04.284134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock module
    module = MagicMock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    module.get_bin_path.return_value = '/usr/bin/capsh'

    # mock collector
    collector = SystemCapabilitiesFactCollector()

    # run collector
    result = collector.collect(module)

    # verify returned facts
    expected_result = {'system_capabilities_enforced': 'False',
                       'system_capabilities': []}
    assert result == expected_result

    # verify module.run_command was called
    expected_command = ['/usr/bin/capsh', '--print']
    module.run_command.assert_called_with(expected_command, errors='surrogate_then_replace')

# Generated at 2022-06-11 04:13:13.249154
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps

    a = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        bypass_checks=False
    )

    bc = ansible.module_utils.facts.collector.BaseFactCollector()
    bc.get_bin_path = lambda self, x=None: '/bin/capsh'
    c = ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector(a, bc)


# Generated at 2022-06-11 04:13:23.816531
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test the case that capsh output is captured successfully
    module = MockModule()
    MockRunner.set_command_response(0, 'Current: =ep')
    fact_collector = SystemCapabilitiesFactCollector(module)
    capsh_facts = fact_collector.collect()
    assert capsh_facts['system_capabilities_enforced'] == 'False'
    assert capsh_facts['system_capabilities'] == []

    # Test the case that capsh binary path is not found
    module = MockModule(command_fails=True)
    fact_collector = SystemCapabilitiesFactCollector(module)
    capsh_facts = fact_collector.collect()
    assert capsh_facts['system_capabilities_enforced'] == 'NA'
    assert capsh_facts['system_capabilities'] == 'NA'



# Generated at 2022-06-11 04:13:32.308116
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = object()
    collected_facts = object()
    fact_collector = SystemCapabilitiesFactCollector(module, collected_facts)
    fact_collector.get_caps_data = lambda: """
Current: =eip
Bounding set =eip
Securebits: 00/0x0/1'b0 secure-noroot, secure-no-suid-fixup
 secure-keep-caps,
Secure-noroot:
  current suid: (0/0)
  fsuid:        (0/0)
  egid:         (0/0)
  sgid:         (0/0)
  fsgid:        (0/0)
capability bounds:
"""
    facts = fact_collector.collect()
    assert facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-11 04:13:38.083058
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector_module = mock.MagicMock()
    fact_collector = SystemCapabilitiesFactCollector(fact_collector_module)

    fact_collector_module.run_command.return_value = (0, "Current: =ep", "")
    facts = fact_collector.collect()
    assert facts == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

    fact_collector_module.run_command.return_value = (0, "Current: =ep cap_sys_nice,cap_net_bind_service", "")
    facts = fact_collector.collect()
    assert facts == {'system_capabilities': ['cap_sys_nice', 'cap_net_bind_service'], 'system_capabilities_enforced': 'False'}

    fact_

# Generated at 2022-06-11 04:13:46.828982
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts

    MOCK_FILE = '/bin/capsh'

# Generated at 2022-06-11 04:13:55.091287
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.capabilities import get_caps_data
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.capabilities import parse_caps_data
    #from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.capabilities import parse_caps_data
    #from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.capabilities import run_command

    import pytest
    import types
    #from mock import patch

    #

# Generated at 2022-06-11 04:13:55.591465
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:15:14.770972
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ################################################################################
    #  Setup:
    #    Get a instance of SystemCapabilitiesFactCollector.
    #
    ################################################################################

    oTestSystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

    ################################################################################
    #  Test:
    #    Check that everything works with the class.
    #
    ################################################################################

    assert oTestSystemCapabilitiesFactCollector.name == 'caps'
    assert len(oTestSystemCapabilitiesFactCollector._fact_ids) == 2
    assert 'system_capabilities' in oTestSystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in oTestSystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-11 04:15:22.603034
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # returns 'NA' for enforced_caps_capsh dictionary (no requirements)
    def mock_run_command(args, errors='surrogate_then_replace'):
        return (0, "", "")
    module = MockModule()
    module.get_bin_path = Mock(return_value=True)
    module.run_command = Mock(side_effect=mock_run_command)
    collector = SystemCapabilitiesFactCollector(module)
    result = collector.collect()
    assert result['system_capabilities_enforced'] == 'NA'
    assert result['system_capabilities'] == 'NA'

    # returns True for enforced_caps_capsh dictionary

# Generated at 2022-06-11 04:15:31.680487
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector
    import json


# Generated at 2022-06-11 04:15:40.221379
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system.caps as capsc

    # Create mock object for AnsibleModule
    class AnsibleModule:
        def __init__(self):
            self.run_command = None

    # Create mock object for _ansible_module_runner
    class AnsibleModuleRunner:
        def __init__(self):
            self.run_command = None

    # Create system capabilities list

# Generated at 2022-06-11 04:15:42.385910
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collectInfo = SystemCapabilitiesFactCollector()
    assert collectInfo.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-11 04:15:50.240298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: get_caps_data()/parse_caps_data() for easier mocking -akl
    # NOTE: these tests will fail if you don't have the capsh program on your
    # system.  You can disable this test by running:
    #     @pytest.mark.skipif(True, reason="Requires capsh to be installed on this system")
    # on the class.
    import pytest


# Generated at 2022-06-11 04:15:58.321277
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    module = AnsibleModule({})
    module.run_command = mock.Mock(return_value=(0, 'Current: =ep', ""))
    module.get_bin_path = mock.Mock(return_value='/bin/capsh')

    system_collector = SystemFactCollector(module=module)
    system_collector._collect()
    fact_collector = SystemCapabilities

# Generated at 2022-06-11 04:16:03.912424
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # set up base class
    BaseFactCollector.__init__ = lambda self: None
    BaseFactCollector.resolve_executable = lambda self, *args, **kwargs: '/bin/ls'

    # init
    collector = SystemCapabilitiesFactCollector()
    collector.run = lambda x: None

    # test
    collector.collect()
    assert collector.facts == {u'system_capabilities_enforced': u'NA',
                               u'system_capabilities': []}

# Generated at 2022-06-11 04:16:12.200475
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector

    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = '/usr/bin/capsh'
    mock_module.run_command.return_value = (0, '\nCurrent: =eip\n', '')


# Generated at 2022-06-11 04:16:20.011787
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import ansible.module_utils.facts.collector.system.SystemCapabilitiesFactCollector as SystemCapabilitiesFactCollector
    import ansible.module_utils.basic as basic
    import ansible.module_utils.facts.collector as collector

    file = tempfile.NamedTemporaryFile(delete=False)
    file.write("Current: =ep\n")
    file.close()

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda cmd, errors='surrogate_then_replace': (0, file.name, '')

    collected_facts = collector.FactsCollector()
    fact_collector = SystemCapabilitiesFactCollector()