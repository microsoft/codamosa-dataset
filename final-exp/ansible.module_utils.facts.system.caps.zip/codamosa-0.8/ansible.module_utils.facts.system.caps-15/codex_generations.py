

# Generated at 2022-06-11 04:07:25.701059
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import json
    import os
    import shutil

    capsh_rc = 0

# Generated at 2022-06-11 04:07:35.558452
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile


# Generated at 2022-06-11 04:07:36.497559
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector.collect()

# Generated at 2022-06-11 04:07:38.783366
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = AnsibleModule()
    assert SystemCapabilitiesFactCollector(m).collect() == {}

# Test that SystemCapabilitiesFactCollector works on systems with capsh

# Generated at 2022-06-11 04:07:47.779971
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.base import BaseSystemCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    CapFactCollector = SystemCapabilitiesFactCollector()
    # Should fail without prior call to setup
    assert CapFactCollector.collect() == {}

    # Pretend to be a module
    module = type('module', (object,), {'get_bin_path': lambda s, bin: bin, 'run_command': lambda s, cmd: (0, 'Current: =ep\n', '')})()
    CapFactCollector.setup(module)

# Generated at 2022-06-11 04:07:51.800298
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = 'ansible.module_utils.facts.system.caps'
    a = dict(system_capabilities=['chown', 'dac_override'],
             system_capabilities_enforced=True)
    assert SystemCapabilitiesFactCollector.collect(module=module, collected_facts=a) == a

# Generated at 2022-06-11 04:07:52.395531
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:08:02.202146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create a stub module object to pass down
    module = AnsibleModuleStub()
    module.run_command.return_value = (0, 'Current: =ep', '')

    # create a stub facts object whose methods can be replaced with mocks
    collected_facts = {}
    # create a SystemCapabilitiesFactCollector object to test
    collector = SystemCapabilitiesFactCollector(module=module,
                                                collected_facts=collected_facts)
    # run the code to be tested
    result = collector.collect()
    # check that the right commands were run
    module.run_command.assert_called_once_with(['capsh', '--print'])
    # check that the right facts were collected
    assert result['system_capabilities'] == []
    assert result['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:08:11.767884
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    capsh_path = "capsh"
    module = '''
            def get_bin_path(self, executable, required=False):
                return 'capsh'
        '''
    facts_dict = {}
    enforced_caps = []
    enforced = 'NA'

# Generated at 2022-06-11 04:08:20.180948
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector

    COLL_MSG = 'Collector %s is missing a required collect method'

    # NOTE: use rw_mock to see what's in the instance ->
    # (easier to tell which method is missing)
    # NOTE: rw_mock doesn't matter for BaseFactCollector (no methods)
    facts_collector = collector.BaseFactCollector(rw_mock=True)
    assert facts_collector.collect, COLL_MSG % facts_collector.name

    facts_collector = collector.SystemCapabilitiesFactCollector(rw_mock=True)
    assert facts_collector.collect, COLL_MSG % facts_collector.name

# Generated at 2022-06-11 04:08:32.608379
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.community.general.plugins.modules.system import os_release
    from ansible.utils.path import unfrackpath

    fake_distribution = {
        'id': 'neptune',
        'name': 'Neptune',
        'version': '1.0.0',
        'version_best': '1.0.0',
        'arch': 'x86_64',
        'major_version': '1',
        'minor_version': '0',
        'pretty_name': 'Neptune',
        'pretty_version': '1.0.0',
        'like': 'debian'
    }
    module = os_release.OsRelease(argument_spec={})

# Generated at 2022-06-11 04:08:35.253666
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector

    caps_fact_collector = Collector.create_collector('SystemCapabilitiesFactCollector', None)

    assert caps_fact_collector.collect() == {}

# Generated at 2022-06-11 04:08:38.124124
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts = SystemCapabilitiesFactCollector().collect()
    assert facts['system_capabilities_enforced'] in ['True', 'False']
    assert isinstance(facts['system_capabilities'], list)

# Generated at 2022-06-11 04:08:45.044963
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    This test case checks the method collect in SystemCapabilitiesFactCollector
    :return: None
    """
    # A good test case.
    mock_module = MagicMock(run_command=lambda x, y: (0, 'Current: =ep', ''))
    mock_module.get_bin_path = MagicMock(return_value='capsh_path')
    mock_collector = SystemCapabilitiesFactCollector()
    result = mock_collector.collect(module=mock_module, collected_facts=None)

    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

    # Another good test case.

# Generated at 2022-06-11 04:08:55.012824
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    mock_module = None
    mock_collected_facts = {}
    # Stub module.run_command()
    def mock_run_command(*args, **kwargs):
        class MockResponse():
            def __init__(self, out, err):
                self.rc = 0
                self.stdout = out
                self.stderr = err


# Generated at 2022-06-11 04:09:03.719147
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of the class to be tested
    scfc = SystemCapabilitiesFactCollector()

    # Create a test 'module' object to pass to collect()
    class CapshModule:
        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/capsh'
        def run_command(self, command_args, errors):
            return 0, 'Current: =ep', ''

    capsh_module = CapshModule()

    # Call method collect() of class SystemCapabilitiesFactCollector
    result = scfc.collect(capsh_module)
    assert result['system_capabilities_enforced'] == 'False'


# Generated at 2022-06-11 04:09:09.290423
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Method collect of class SystemCapabilitiesFactCollector collects
        accurate facts """

    # Create a DummyModule for testing
    from ansible.module_utils.facts import ModuleDummy
    from ansible.module_utils.facts.collector import Capsh
    module = ModuleDummy()

    #capsh = Capsh()
    #caps_data = capsh.get_caps_data(module=module)
    #enforced_caps = capsh.parse_caps_data(caps_data)

    # Create a SystemCapabilitiesFactCollector class object
    system_capabilities_facts_collector = SystemCapabilitiesFactCollector()
    collected_facts = system_capabilities_facts_collector.collect(module=module)

    # Compare collected facts with enforced_caps

# Generated at 2022-06-11 04:09:17.124692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mod_utils = mock()
    mod_utils.run_command.return_value = (0, 'Current: =ep', '')
    mod_utils.get_bin_path.return_value = '/usr/bin/capsh'
    mod = mock()
    mod.run_command.side_effect = mod_utils.run_command
    mod.get_bin_path.side_effect = mod_utils.get_bin_path
    sut = SystemCapabilitiesFactCollector(module=mod)
    result = sut.collect()
    assert result == {'system_capabilities_enforced': 'False',
                      'system_capabilities': []
                      }

# Generated at 2022-06-11 04:09:27.169956
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Module(object):
        def __init__(self, capsh_path):
            self.params = {}
            self._capsh_path = capsh_path
            self._capsh_stdout = self._capsh_stdout_value()

        def get_bin_path(self, arg, opt_dirs=[]):
            return self._capsh_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, self._capsh_stdout, ''


# Generated at 2022-06-11 04:09:32.810996
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import sys

    # Python 2.6 needs mock.patch.object()
    if sys.version_info[0:2] == (2, 6):
        m_object = mock.patch.object
    else:
        m_object = mock.patch

    module = mock.Mock()
    fake_facts = {'distribution': 'RedHat'}
    capsh_path = '/bin/capsh'
    m_get_bin_path = m_object(module, 'get_bin_path')
    m_get_bin_path.return_value = capsh_path
    m_run_command = m_object(module, 'run_command')
    m_run_command.return_value = 0, '', ''

# Generated at 2022-06-11 04:09:46.703449
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system

    class TestModule:
        def get_bin_path(self, executable):
            if executable == 'capsh':
                return '/tmp/capsh'
            raise Exception('Error')


# Generated at 2022-06-11 04:09:55.561796
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.get_bin_path = Mock()
    module.get_bin_path.return_value = '/usr/local/bin/capsh'

    module.run_command = Mock()

# Generated at 2022-06-11 04:09:56.149077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:09:59.402562
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = {}
    collected_facts = {}
    system_caps_collector = SystemCapabilitiesFactCollector(module=module,
            collected_facts=collected_facts)
    if system_caps_collector._capsh_path:
        system_caps_collector.collect()

# Generated at 2022-06-11 04:10:09.064933
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Construct a mock module object
    values = dict(capsh_path=None)
    get_bin_path_mock = type('', (), {'return_value': values['capsh_path']})
    run_command_mock = type('', (), dict(return_value=('mock_rc', 'mock_out', 'mock_err')))
    setattr(get_bin_path_mock, 'return_value', values['capsh_path'])
    class Module:
        def __init__(self):
            self.get_bin_path = get_bin_path_mock
            self.run_command = run_command_mock
    module = Module()

    # Construct a mock facts dictionary
    collected_facts = {}

    # Construct a SystemCapabilitiesFactCollector
    sut = SystemCap

# Generated at 2022-06-11 04:10:18.246896
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # pylint: disable=W0212
    # NOTE: -> fake_module for easier mocking -akl
    test_module = SystemCapabilitiesFactCollector.fake_module()
    SystemCapabilitiesFactCollector.run_command = lambda self, cmd, errors='surrogate_then_replace': (0, "Current: = cap_setfcap+eip cap_dac_read_search+eip", None)
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(test_module)
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl

# Generated at 2022-06-11 04:10:28.598578
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import json
    import mock
    import os

    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector

    collector = SystemCapabilitiesFactCollector()

    # test for required module missing
    def test_module_missing(module_name, missing_required_lib):
        # if this method is mocked, mock_module will return None
        def mock_module(module_name):
            if module_name == 'capsh':
                return None
            else:
                return mock.MagicMock()

        # mock ansible.module_utils.facts.collector.BaseFactCollector.get_module
        with mock.patch.object(BaseFactCollector, 'get_module', side_effect=mock_module) as mock_module_function:
            # make the call
            result

# Generated at 2022-06-11 04:10:37.378842
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import socket
    import unittest


    class Mock(object):
        '''
        Mock class for module testing
        '''
        def __init__(self):
            self.params = {'capabilities_path': None}

        def get_bin_path(self, executable):
            '''
            Mocking function equivalent to what would be invoked
            '''
            if platform.system() == 'FreeBSD' and executable == 'capsh':
                return '/usr/local/bin/capsh'
            else:
                return None

        def run_command(self, command, errors='surrogate_then_replace'):
            '''
            Mocking function equivalent to what would be invoked
            '''

# Generated at 2022-06-11 04:10:46.069296
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    import ansible.module_utils.facts.system.system
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.distribution


# Generated at 2022-06-11 04:10:54.746393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DictModule({'run_command': mocked_run_command})
    facts = SystemCapabilitiesFactCollector({}, module).collect()
    assert facts['system_capabilities'] == ['cap_chown', 'cap_dac_override', 'cap_fowner',
            'cap_fsetid', 'cap_kill', 'cap_setgid', 'cap_setuid', 'cap_setpcap', 'cap_net_bind_service', 'cap_sys_chroot',
            'cap_mknod', 'cap_audit_write', 'cap_setfcap', 'cap_mac_override', 'cap_sys_admin', 'cap_sys_boot',
            'cap_sys_nice', 'cap_sys_resource', 'cap_sys_time']
    assert facts['system_capabilities_enforced']

# Generated at 2022-06-11 04:11:15.120669
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import BaseFileEntry
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import delete_dir
    from ansible.module_utils.facts.utils import file_exists
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_mode
    from ansible.module_utils.facts.utils import get_file_size
    import os
    import shut

# Generated at 2022-06-11 04:11:23.620707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import json
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes

    if not os.path.exists('/usr/bin/capsh'):
        raise Exception('error: please install the libcap2-bin package')

    # NOTE: implement _get_capsh_data() and parse_capsh_data() for easier mocking -akl
    ModuleMock = namedtuple('ModuleMock', ['run_command', 'get_bin_path'])

    # NOTE: implement _get_capsh_data() and parse_capsh_data() for easier mocking -akl
    def _get_capsh_data(module):
        with open('/usr/bin/capsh', 'rb') as data_file:
            return data_file.read()



# Generated at 2022-06-11 04:11:32.469001
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is necessary for mocking to work on python2
    from __builtin__ import __import__ as builtin_import
    import sys

    # our mock module class
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False, required_if=None, required_by=None,
                     map_values_list=None):
            args = {}
            self.params = args

        def exit_json(self, **kwargs):
            print(kwargs)


# Generated at 2022-06-11 04:11:33.460030
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:11:42.789887
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import cache

    from ansible.module_utils.facts.collector.system.capabilities.caps import (
        SystemCapabilitiesFactCollector,
    )
    from ansible.module_utils.facts.utils import MockModuleUtils # for for 'get_file_contents'
    import os

    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert SystemCapabilitiesFactCollector._platform == 'All'

    # get_caps_data()/parse_caps_data()

# Generated at 2022-06-11 04:11:44.093754
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollectorTest = SystemCapabilitiesFactCollector()

# Generated at 2022-06-11 04:11:51.206692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Pass in some expected output and the module will return
    the facts that the method collect of the class
    SystemCapabilitiesFactCollector will collect
    """

    # The mock_module fixture contains a function that can be used
    # by the unit tests to mock the module
    mock_module = Mock()
    mock_module.get_bin_path.return_value = 'NA'
    mock_module.run_command.return_value = 'NA'

    expected_return_value = {}
    return_value = SystemCapabilitiesFactCollector.collect(mock_module)

    assert return_value == expected_return_value

# Generated at 2022-06-11 04:12:00.724534
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule

    # NOTE: stubs for mock objects
    class MockModule(ModuleStub):
        def get_bin_path(self, arg):
            return '/bin/capsh'

        def run_command(self, arg, arg2):
            return 0, to_bytes('Current: = cap_setpcap,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time+ep'), to_bytes('')



# Generated at 2022-06-11 04:12:09.460609
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Test with enforced caps
    class TestWithEnforcedCaps:
        def run_command(self, args, **kwargs):
            return (0, "Current: =ep\nBounding set =cap_net_raw,cap_net_admin,cap_net_bind_service,cap_net_broadcast,cap_net_raw+ep\nSecurebits: 00/0x0/1'b0 secure-noroot,noroot chroot@ syslog\nSecurebits: 00/0x0/1'b0 secure-noroot,noroot chroot@ syslog", '')
        def get_bin_path(self, arg):
            return '/usr/bin/capsh'

    a = SystemCapabilitiesFactCollector()
    b = TestWithEnforcedCaps()
    c = None


# Generated at 2022-06-11 04:12:18.797920
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect(): 
    # Ensure that module_utils.facts.collector.get_file_content() returns a string for the file content
    # This step is necessary for testing purposes. Without modifying the 
    # 'get_file_content' method the collected facts are always empty,
    # since the "capsh" command is not executed.
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector as collector

    capsh_path_mock = '/bin/capsh'
    capsh_result_mock = 'Capabilities: =ep'
    def get_file_content(file_path, encoding='utf-8', errors='surrogate_then_replace'):
        print('get_file_content: ', file_path)

# Generated at 2022-06-11 04:12:48.758951
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockAnsibleModule()
    module.run_command.return_value = ('0', "Current: =ep", '')
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module)
    assert facts_dict == {'system_capabilities_enforced': 'False', 'system_capabilities': []}



# Generated at 2022-06-11 04:12:58.056675
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import shlex

    from ansible.module_utils.facts.collector import AnsibleModuleMock


    class AnsibleModuleMockSubclass(AnsibleModuleMock):
        def run_command(self, command_args, errors='surrogate_then_replace'):
            cmd = shlex.split(command_args[0])[0]

# Generated at 2022-06-11 04:13:07.339224
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import os
    import platform

    module = mock.Mock()
    caps_data = """Current: =ep
Bounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip
"""
    # NOTE: get_caps_data()/parse_caps_data() for easier mocking -akl
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, caps_data, '')
    module.get_bin_path = mock.Mock()


# Generated at 2022-06-11 04:13:16.256141
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import sys
    import io
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system_capabilities import test_SystemCapabilitiesFactCollector_collect
    from ansible.module_utils.facts.collector.system_capabilities import test_SystemCapabilitiesFactCollector_collect_no_capsh
    from ansible.module_utils.facts.collector.system_capabilities import test_SystemCapabilitiesFactCollector_collect_caps_not_enforced

# Generated at 2022-06-11 04:13:27.142440
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors import SystemCapabilitiesFactCollector
    
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect()
    
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict
    
    # On a system that is know to require enforced capabilities, make sure
    # that system_capabilities_enforced equals True and system_capabilities
    # is a non empty list.
    if "cap_net_bind_service=ep" in facts_dict['system_capabilities']:
        assert facts_dict['system_capabilities_enforced'] == 'True'
        assert facts_dict['system_capabilities']
    # On a system that is know to not require enforced capabilities, make sure


# Generated at 2022-06-11 04:13:34.404491
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}

    def mock_run_command(arg1, arg2):
        if arg1 == ['capsh', '--print']:
            return (0, 'Current: =ep', '')

    import ansible.module_utils.facts.system.caps as caps

    def mock_get_bin_path(arg1):
        return 'capsh'

    caps.run_command = mock_run_command
    caps.get_bin_path = mock_get_bin_path

    collector = SystemCapabilitiesFactCollector(None)

    result = collector.collect(None, facts_dict)

    # Asserting the result is as expected
    if result['system_capabilities'] != [] and result['system_capabilities_enforced'] != 'False':
        exit('Test failed')

# Generated at 2022-06-11 04:13:41.906701
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub

    module = AnsibleModuleStub()
    module.run_command = lambda *args, **kwargs: test_caps_data, '', '', ''
    module.get_bin_path = lambda *args, **kwargs: '/usr/bin/capsh'
    caps = SystemCapabilitiesFactCollector(module)

    # test 'system_capabilities' is set to right value in test_caps_data

# Generated at 2022-06-11 04:13:42.792240
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print(SystemCapabilitiesFactCollector.collect())

# Generated at 2022-06-11 04:13:51.636002
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import subprocess
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector

    capsh_path = sys.executable
    current_path = os.getcwd()
    os.chdir(tempfile.gettempdir())
    open('capsh', 'a').close()
    os.chmod('capsh', 0o777)
    os.environ['PATH'] = tempfile.gettempdir() + os.pathsep + os.environ['PATH']
    x = subprocess.Popen(['capsh', "--print"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout,

# Generated at 2022-06-11 04:13:52.420696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False, "unit test cases needed"

# Generated at 2022-06-11 04:15:09.429304
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector._capsh_output = "Current:\n \
CapInh:  00000000a80425fb  CapPrm:  00000000a80425fb  CapEff:  00000000a80425fb\n \
CapBnd:  00000000a80425fb  CapAmb:  0000000000000000\n"
    result = SystemCapabilitiesFactCollector().collect()
    assert result == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-11 04:15:17.621366
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts import fact_collector

    class DummyModule(object):
        def __init__(self):
            return

        def run_command(self, cmd, errors):
            self.cmd = cmd

# Generated at 2022-06-11 04:15:26.077883
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import ansible.module_utils.basic as ansible_basic_utils
    import ansible.module_utils.facts.collector as ansible_collector_utils
    import ansible.module_utils.facts as ansible_facts_utils

    collector_obj = SystemCapabilitiesFactCollector()
    module = ansible_basic_utils.AnsibleModule(argument_spec={})
    # Unit:
    module.run_command = lambda x, **args: [0, "Current: =ep", ""]
    assert collector_obj.collect(module) == {'system_capabilities_enforced': 'False',
                                             'system_capabilities': []}
    # Unit:

# Generated at 2022-06-11 04:15:34.901560
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import tempfile
    import json
    import os
    import sys
    import shutil
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import xrange

    def mock_module_run_command(cap):
        class MockModule:
            class Run_command:
                def __init__(self):
                    self.rc = 0
                    self.stdout = b""
                    self.stderr = b""

# Generated at 2022-06-11 04:15:43.303719
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test with good result
    module = Mock(run_command=Mock(return_value=(0, 'Current: =ep\nBounding set =cap_chown,cap_dac_override+i', '')),
                  get_bin_path=Mock(return_value=True))
    coll = SystemCapabilitiesFactCollector()
    facts_dict = coll.collect(module)
    assert facts_dict['system_capabilities'] == ['cap_chown', 'cap_dac_override+i']
    assert facts_dict['system_capabilities_enforced'] == 'False'
    # Test with no result
    module = Mock(run_command=Mock(return_value=(127, '', '')), get_bin_path=Mock(return_value=True))
    coll = SystemCapabilitiesFactCollector()


# Generated at 2022-06-11 04:15:51.085582
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    #import unittest
    import mock

    #mock_module = mock.MagicMock()
    #mock_module.run_command.return_value = (0,
    #                                        'Current: =ep Bounding set =cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_

# Generated at 2022-06-11 04:15:59.257919
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import capsh_present
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.collector import set_file_content
    import sys
    import os
    import tempfile

    class test_module():
        def __init__(self):
            self.run_command_environ_update = None
            self.run_command_called = None
            self.run_command_stdin_args = None
            self.bin_path = None
            self.run_command_stdin = None
            self.run_command

# Generated at 2022-06-11 04:16:08.197407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collector.clear()
    ansible_collector.get_collector(SystemCapabilitiesFactCollector.name)

    from ansible.module_utils.facts.collector.system import SystemCollector
    SystemCollector._platform = None

    from ansible.modules.system import dmidecode
    dmidecode.dmidecode = None
    dmidecode.ansible_collections.ansible.builtin = None
    dmidecode.ansible.module_utils.basic = None
    dmidecode.ansible.module_utils.facts.system.dmidecode = None
    dmidecode.ansible.module_utils.facts.system.hw_detect = None
    dmidecode.ansible

# Generated at 2022-06-11 04:16:15.942316
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock, patch

    mock_module = Mock()

# Generated at 2022-06-11 04:16:23.787233
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collectors.generic.capsh import get_caps_data, parse_caps_data
    import collections
    import ansible.module_utils.facts.collectors.base as test_module
    import ansible.module_utils.facts.system.system as my_system
    import ansible.module_utils.facts.system.capsh as my_capsh
    my_system.path.exists = lambda x: x == test_module.get_bin_path('capsh')