

# Generated at 2022-06-11 04:07:15.481052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: test this with some actual data -akl
    # NOTE: build expected output as a string first, then -> dict
    pass

# Generated at 2022-06-11 04:07:17.367017
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("unit test for SystemCapabilitiesFactCollector_collect()")
    print("NOT IMPLEMENTED.")


# Generated at 2022-06-11 04:07:26.908323
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import os
    import json
    import pytest

    from ansible.module_utils.facts.collector import CachingFile

    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    from ansible.module_utils.facts.system.caps import get_cap_data

    def get_fact_data(id):
        fact_data = fact_collector.collect(module=None, collected_facts=None)
        return fact_data[id]

    fact_collector = SystemCapabilitiesFactCollector()

    # With capsh command available
    with pytest.raises(StopIteration):
        f = next(i for i in os.listdir('/proc/') if i.isdigit())
        f = int(f)
        os.close(f)


# Generated at 2022-06-11 04:07:36.959046
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import pytest
    from ansible.module_utils.facts.collector import AnsibleCollector

    #
    # This test will recognize Linux as it's running on Travis and Travis runs
    # Debian.  It'll also recognize Darwin as that's the other test platform.
    #
    if os.name in ('nt', 'os2', 'ce'):
        pytest.skip("This test is not supported on Windows.")

    if os.name == 'posix':
        capsh_path = None
        capsh_exe = 'capsh.exe'
        if os.path.isfile(capsh_exe):
            capsh_path = capsh_exe
        else:
            pytest.skip("This test requires that capsh is installed.")


# Generated at 2022-06-11 04:07:43.142110
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_collector_init
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system import caps

    # set up the mock module class required by the collect method
    module = MockModule()
    collector = SystemCapabilitiesFactCollector()
    # mock the method used to get the command path
    get_bin_path_orig = module.get_bin_path
    def get_bin_path_side_effect(name):
        if name == 'capsh':
            return '/bin/capsh'
        else:
            return get_bin_path

# Generated at 2022-06-11 04:07:52.986891
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    class MockModule():
        def __init__(self):
            self.params = {}
            self.run_command = run_command

        def get_bin_path(arg):
            return arg

    def run_command(cmd, err=None):
        if cmd[0] == 'capsh':
            rc = 0

# Generated at 2022-06-11 04:07:55.110377
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test method collect with empty module
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {}


# Generated at 2022-06-11 04:08:04.915296
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    This is not a unit test in the classical sense.  The method
    SystemCapabilitiesFactCollector.collect has been designed to be
    tested in integration with an AnsibleModule.  This test uses a
    patched AnsibleModule.
    """

    class FakeModule(object):
        """
        Fake AnsibleModule as required by SystemCapabilitiesFactCollector.collect
        """

        def __init__(self, module_name, module_args, check_invalid_arguments=False, bypass_checks=False):
            self.module_name = module_name
            self.module_args = module_args
            self.check_invalid_arguments = check_invalid_arguments
            self.bypass_checks = bypass_checks
            self.params = {}
            self.result = {}
            self.version = {}
           

# Generated at 2022-06-11 04:08:12.363858
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = get_module_mock()
    collected_facts = {'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'setfcap'], 'system_capabilities_enforced': 'True'}

    collector = SystemCapabilitiesFactCollector()
    result = collector.collect(module, collected_facts)

    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result



# Generated at 2022-06-11 04:08:12.863914
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-11 04:08:25.740066
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest

    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector


# Generated at 2022-06-11 04:08:34.972263
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    import json


# Generated at 2022-06-11 04:08:43.580679
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import sys
    import os
    import re

    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector


# Generated at 2022-06-11 04:08:53.446215
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    @summary: Check if facts related to systems 'capabilities' can
                be collected via capsh
    '''
    # Run test with capsh not installed
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "", "")
    collected_facts = {}
    fact_collector = SystemCapabilitiesFactCollector()
    facts = fact_collector.collect(mock_module, collected_facts)
    # Assert method collect did not return any facts
    assert not facts

    # Run test with capsh installed
    # NOTE: This output is simulated, because we're not testing capsh itself -akl

# Generated at 2022-06-11 04:09:03.720409
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_dict = {'system_capabilities': ['cap_dac_read_search'], 'system_capabilities_enforced': 'True'}

# Generated at 2022-06-11 04:09:12.819223
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import subprocess
    from ansible.module_utils.facts import collector


# Generated at 2022-06-11 04:09:21.731626
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' SystemCapabilitiesFactCollector.collect - test cases '''
    from ansible.module_utils.facts import ansible_collector

    # 1 - values

# Generated at 2022-06-11 04:09:31.569932
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class TestModule(object):
        def __init__(self):
            self.params = None

        def get_bin_path(self, binary, required=False):
            return '/bin/capsh'


# Generated at 2022-06-11 04:09:35.083116
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DummyModule()
    result = SystemCapabilitiesFactCollector().collect(module)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Test fixture

# Generated at 2022-06-11 04:09:44.058612
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os

    import ansible.module_utils.facts.collectors.system.caps as system_caps_collector
    import ansible.module_utils.facts.collector as facts_collector
    import ansible.module_utils.facts.utils as facts_utils

    file_path = os.path.join(os.path.dirname(__file__), '../test_data/test_capsh_output')

    test_module = facts_utils.TestModule(params=dict())

    test_module.run_command = lambda x, y: (0, open(file_path, 'r').read(), '')

    collector = system_caps_collector.SystemCapabilitiesFactCollector(module=test_module)

    result = collector.collect()
    assert result['system_capabilities_enforced'] == "True"
   

# Generated at 2022-06-11 04:09:54.005381
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_type

    module = get_collector_type('SystemCapabilitiesFactCollector')
    system_capabilities_fact_collector = module()
    system_capabilities_fact_collector._module = module
    system_capabilities_fact_collector.run()

# Generated at 2022-06-11 04:09:54.586597
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-11 04:10:03.782554
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils._text import to_bytes

    def run_command(self, args, check_rc=True):
        if args[0] == '/usr/bin/capsh':
            rc = 0
            out = b"Current: =ep\n"
        else:
            rc = 1
            out = b''
        return (rc, out, b'')

    def get_bin_path(self, executable):
        if executable == 'capsh':
            return '/usr/bin/capsh'
        else:
            return None

    module = MockModule({'run_command': run_command, 'get_bin_path': get_bin_path})
    fact_collector = SystemCapabilitiesFactCollector()
    actual_result = fact

# Generated at 2022-06-11 04:10:05.510588
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    populate this method with some unit tests
    """
    # assert 'caps' in collected_facts

# Generated at 2022-06-11 04:10:09.524054
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    with open('/proc/1/status') as f:
        assert f.read()
    facts_dict = get_collector_instance('SystemCapabilitiesFactCollector').collect()
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-11 04:10:14.933502
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ SystemCapabilitiesFactCollector - collect
    Runs a unit test against the method collect
    """
    # create an instance of the module
    module = AnsibleModule()

    # create an instance of the SystemCapabilitiesFactCollector class
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # run the method collect with a given module
    system_capabilities_fact_collector.collect(module)


# Generated at 2022-06-11 04:10:20.299292
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Testing with dummy module and its output
    from ansible.module_utils.facts.collector import DummyModule
    mod = DummyModule()
    mod.run_command.side_effect = [[0, 'Current: =ep', '']]
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.collect(module=mod) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-11 04:10:22.579146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: rewrite this test to avoid mocking module.run_command() -akl
    # FIXME: test
    assert False


# Generated at 2022-06-11 04:10:33.169822
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    module_mock = basic.AnsibleModule(argument_spec={})
    facts_mock = Facts(module_mock)

    BaseFactCollector.collect = lambda self, module=None, collected_facts=None: {}
    BaseFactCollector.get_capabilities = lambda self: 'system_capabilities'
    BaseFactCollector.get_enforced = lambda self: 'system_capabilities_enforced'

    collector = SystemCapabilitiesFactCollector(module_mock, facts_mock)

    assert collector.collect() == {'system_capabilities': [], 'system_capabilities_enforced': False}

# Generated at 2022-06-11 04:10:41.346487
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import mock
    from ansible.module_utils.facts import timeout

    # mock 'ansible.module_utils.facts.timeout.TimeoutError' -akl
    class Bailout(Exception): pass
    mock_TimeoutError = mock.Mock()
    mock_TimeoutError.side_effect = Bailout
    sys.modules['ansible.module_utils.facts.timeout.TimeoutError'] = mock_TimeoutError


    # mock 'ansible.module_utils.facts.collector.BaseFactCollector.__init__'
    def noop(self, *args, **kwargs): pass
    mock_BaseFactCollector__init__ = mock.Mock()
    mock_BaseFactCollector__init__.side_effect = noop
    mock_BaseFactCollector__init__.__name

# Generated at 2022-06-11 04:11:01.841134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import tempfile
    import os

    # Arrange
    # Create test file with predictable contents
    fd, fname = tempfile.mkstemp(prefix='ansible_unittest_')
    f = os.fdopen(fd, 'w')
    f.write('Current: =ep')
    f.close()

    # create instance of SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()

    # Act
    # call the method collect
    result = c.collect(module=None, collected_facts=None)
    # Assert

# Generated at 2022-06-11 04:11:08.624885
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector

    module = AnsibleCollector(None)
    module.get_bin_path = lambda x: '/usr/bin/capsh'
    module.run_command = lambda x, errors='surrogate_then_replace': (0, 'Current: =ep\nBounding set =cap_sys_chroot+p', '')
    caps = SystemCapabilitiesFactCollector()

    assert caps.collect(module) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# vim: set expandtab:ts=4:sw=4:

# Generated at 2022-06-11 04:11:14.090722
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {'system_capabilities': ['chown', 'dac_override', 'fsetid', 'fowner', 'froot', 'kill', 'setgid', 'setuid', 'setpcap', 'net_raw', 'dac_read_search', 'sys_chroot', 'mknod', 'audit_write', 'setfcap'], 'system_capabilities_enforced': 'True'}
    assert SystemCapabilitiesFactCollector().collect(collected_facts=None) == facts_dict

# Generated at 2022-06-11 04:11:22.430954
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    should return 2 values
    '''
    # Setup
    m = Mock()
    ansible_module_instance = Mock()
    ansible_module_instance.get_bin_path.return_value = '/path/capsh'
    m.get_bin_path.return_value = '/path/capsh'
    ansible_module_instance.run_command.return_value = (0, 'Current: =ep', '')
    m.run_command.return_value = (0, 'Current: =ep', '')
    s = SystemCapabilitiesFactCollector(ansible_module_instance)

    # Exercise
    returned = s.collect()

    # Verify
    assert len(returned) == 2
    assert 'system_capabilities' in returned
    assert returned['system_capabilities'] == []
   

# Generated at 2022-06-11 04:11:31.348177
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    module = AnsibleModuleMock()
    temp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 04:11:40.715819
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    caps_fact_collector = fact_collector.get_collector('caps')
    ansible_module_instance = {}
    ansible_module_instance['get_bin_path'] = lambda arg1: '/bin/capsh'

# Generated at 2022-06-11 04:11:49.963120
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test if the capsh output of a system is parsed properly.
    '''

    capsh_output = (
        """
Current: =ep
Bounding set =ep 
Securebits: 00/0x0/1'b0 secure-noroot,
    secure-no-suid-fixdown secure-keep-caps
secure-noroot: no (unlocked)
secure-no-suid-fixdown: no (unlocked)
secure-keep-caps: no (unlocked)
CapEff: =ep
"""
    )

    class TestMo(object):

        def get_bin_path(self, path):
            return path

        def run_command(self, *args, **kwargs):
            return 0, capsh_output, ''

    test_mo = TestMo()
    capf = SystemCap

# Generated at 2022-06-11 04:11:52.215315
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector_collect(
        "ansible.module_utils.facts.system.capabilities.capsh.LinuxSystemCapabilitiesFactCollector_collect")



# Generated at 2022-06-11 04:12:01.889656
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    SystemCapabilitiesFactCollector.collect
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    print('''
    Test method collect of class SystemCapabilitiesFactCollector
    ''')

    fake_module = FakeModule()
    capsh_path = 'capshpath'

# Generated at 2022-06-11 04:12:10.380002
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import get_caps_data

    testcollector = SystemCapabilitiesFactCollector(AnsibleModule)

# Generated at 2022-06-11 04:12:36.615452
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    parm = {
            'get_bin_path': lambda x: '/bin/capsh'
            }
    SystemCapabilitiesFactCollector().collect(mock_module(parm))

# Generated at 2022-06-11 04:12:45.229815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import pytest
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import (system_capabilities_utils)
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import (test_module_util)
    from ansible.module_utils.facts.collector import (BaseFactCollector)
    from ansible.module_utils.facts.collector import (SystemCapabilitiesFactCollector)
    from ansible.module_utils.facts.collector import (get_collector_class)

    # We are patching these methods as not part of this unit test
    @staticmethod
    def is_capability_supported():
        return True

    @staticmethod
    def install_capability_test_files():
        return False


# Generated at 2022-06-11 04:12:49.401193
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Unit test for method collect of class SystemCapabilitiesFactCollector'''
    collector = SystemCapabilitiesFactCollector()
    facts_dict = collector.collect(module=None, collected_facts=None)
    assert isinstance(facts_dict, dict)
    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict

# Generated at 2022-06-11 04:12:54.434005
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Local import to make it easier to test
    from ansible.module_utils.facts import collector as facts_collector
    # Given
    test_class = SystemCapabilitiesFactCollector()
    test_class._module = None
    # When
    actual_result = test_class.collect()
    # Then
    assert actual_result == {"system_capabilities": [], "system_capabilities_enforced": "NA"}

# Generated at 2022-06-11 04:13:03.846629
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # unit test class init
    dummy_module = object()
    sut = SystemCapabilitiesFactCollector()

    # mock & stub
    # capsh_path
    capsh_path = './capsh'
    sut._module_finder.get_bin_path = lambda _: capsh_path
    # ...
    rc = 0

# Generated at 2022-06-11 04:13:12.903616
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from .. import SystemCapabilitiesFactCollector, BaseFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class MockModule(object):
        pass

    class MockAnsibleModule(object):
        def __init__(self, *arg, **kwargs):
            self.module = MockModule()
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'capsh':
                return 'capsh'

        def run_command(self, *args, **kwargs):
            return 0, 'Current: =ep', ''

    module = MockModule()
    module.params = {}
    module.ansible_facts = dict()
    module.exit_json = basic. AnsibleModule.exit_

# Generated at 2022-06-11 04:13:14.520781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test that collect method is properly populated
    """
    SystemCapabilitiesFactCollector().collect()



# Generated at 2022-06-11 04:13:25.099855
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import json
    import textwrap

    def get_module_mock(**kwargs):
        get_bin_path_ret = ''

# Generated at 2022-06-11 04:13:33.230783
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for SystemCapabilitiesFactCollector.collect()
    """
    # NOTE: capsh is not available on windows -akl
    # NOTE: this unit test should be removed when dropping python 2 supprt -akl
    if 'win32' in os.name:
        return
    else:
        module, collector, module_mock = get_collector_mock("capsh")

# Generated at 2022-06-11 04:13:38.755417
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

    # Testing with empty module
    result = systemCapabilitiesFactCollector.collect(module=None, collected_facts={})
    assert len(result) == 0

    # Testing with non empty module
    class Module:
        def __init__(self, init=None):
            self.init = init

# Generated at 2022-06-11 04:14:49.792075
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: '/bin/capsh'

# Generated at 2022-06-11 04:14:55.025490
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    values = {'run_command.return_value': (0, 'Current: =ep\nBounding set =cap_net_raw,cap_net_admin+eip', '')}
    result = SystemCapabilitiesFactCollector().collect(ansible_facts={}, module_mock=MagicMock(**values))
    system_capabilities = ['cap_net_raw', 'cap_net_admin+eip']
    assert result['system_capabilities'] == system_capabilities
    assert result['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:14:59.982609
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = mock.MagicMock()
    module.get_bin_path = mock.MagicMock(return_value='/bin/capsh')
    module.run_command = mock.MagicMock(return_value=(0, 'Current: =ep\nBounding set =cap_chown,cap_dac_override+eip', ''))

    c = SystemCapabilitiesFactCollector()
    res = c.collect(module)
    assert res['system_capabilities_enforced'] == 'False'
    assert res['system_capabilities'] == []

# Generated at 2022-06-11 04:15:07.772761
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # return values of run_command
    rc = 0

# Generated at 2022-06-11 04:15:15.997632
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    to_be_tested = SystemCapabilitiesFactCollector()
    mocked_module = Mock()
    mocked_module.get_bin_path.return_value = 'capsh_path'

# Generated at 2022-06-11 04:15:23.839432
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    # expected facts
    expected_facts = dict(
        system_capabilities=['chown', 'dac_override'],
        system_capabilities_enforced='True'
    )

    # create instance
    instance = get_collector_instance(SystemCapabilitiesFactCollector)

    # set required config and method options

# Generated at 2022-06-11 04:15:33.138964
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:15:41.559735
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    class FakeModule:
        def get_bin_path(self, binary):
            return '/bin/capsh'

# Generated at 2022-06-11 04:15:49.526306
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts = dict()
    caps_module = MockSystemCapabilitiesFactCollector()
    assert caps_module.collect(MockModule(), facts) == {}

    caps_module = MockSystemCapabilitiesFactCollector()
    caps_module.capsh_path = None
    ret = caps_module.collect(MockModule(), facts)
    assert ret == {}

    caps_module = MockSystemCapabilitiesFactCollector()
    caps_module.capsh_path = 'capsh'
    caps_module.run_command_status = 0

# Generated at 2022-06-11 04:15:53.308370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep', ''))
    collector = SystemCapabilitiesFactCollector(module=module)
    facts = collector.collect()
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

