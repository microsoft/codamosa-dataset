

# Generated at 2022-06-11 04:07:25.976865
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info.major < 3:
        import __builtin__ as builtins
    else:
        import builtins

    import mock
    import os

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    def mock_get_bin_path(name, opt_dirs=[]):
        if name == 'capsh':
            return capsh_path

    def mock_run_command(args, errors=None):
        if args == [capsh_path, "--print"]:
            return 0, capsh_output, ''
        return 255, '', ''

    capsh_path = 'capsh_path/capsh'

# Generated at 2022-06-11 04:07:35.959975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import signal
    import subprocess
    # Check if capsh is installed
    CAPSH_PATH = None
    for path in os.environ["PATH"].split(os.pathsep):
        path = path.strip('"')
        exe_file = os.path.join(path, 'capsh')
        if os.path.isfile(exe_file) and os.access(exe_file, os.X_OK):
            CAPSH_PATH = exe_file

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.fail = False
            self.exit_args = dict(rc=0, stdout='', stderr='', msg='')
            self.debug_call_count = 0
            self.debug_

# Generated at 2022-06-11 04:07:42.795656
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import shutil
    import tempfile
    import textwrap
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.common.process import get_bin_path

    temp_capsh_path = tempfile.NamedTemporaryFile()
    temp_capsh_path.write(textwrap.dedent(u'''\
        #!/bin/sh
        echo Current: =ep
        ''').encode('utf-8'))
    temp_capsh_path.flush()
    temp_capsh_path.seek(0)

    shutil.copy(temp_capsh_path.name, '/tmp/capsh')

# Generated at 2022-06-11 04:07:52.582903
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Verify that SystemCapabilitiesFactCollector.collect() returns a dict of
    system capability related facts.
    """
    import os
    import sys

    # NOTE: python2/3 compat
    if sys.version_info.major == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils.facts import collector

    class MockModule:
        def __init__(self):
            self._ansible_version = '2.9.9'
            self._ansible_module_name = 'command'
            self._ansible_module_version = '2.9.9'
            self._ansible_sysvars = {
                'run_once': False,
            }


# Generated at 2022-06-11 04:08:02.406143
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test collect with basic run_command mock
    module = MockAnsibleModule()

# Generated at 2022-06-11 04:08:11.959060
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    We test this method by mocking the run_command() method call,
    as we want to test the parse_caps_data() method in isolation.

    The capsh tool returns different results based on the kernel
    being used, and the tool itself is not easily installed on local
    development systems.
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    my_module_mock = basic.AnsibleModule(
        argument_spec = dict()
    )

    my_module_mock.run_command = _mock_run_command_capsh

    fact_collector = collector.get_collector('caps')
    fact_collector.collect(module=my_module_mock,
                           collected_facts=dict())

    # Check that the expected capabilities were parsed

# Generated at 2022-06-11 04:08:21.782451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    capabilities = set([])

    ##
    ## Test with no capabilities
    ##
    c = SystemCapabilitiesFactCollector()

    module = FakeAnsibleModule(
                              capsh_path = "/path/to/capsh",
                              capsh_output = None,
                              capsh_enforced_caps = capabilities,
                              capsh_rc = 0
                              )
    collected_facts = c.collect(module=module)

    assert collected_facts['system_capabilities'] == []
    assert collected_facts['system_capabilities_enforced'] == 'NA'

    ##
    ## Test with capsh returning no capabilities
    ##
    c = SystemCapabilitiesFactCollector()


# Generated at 2022-06-11 04:08:31.544249
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect as tscfc
    from ansible.module_utils.facts.utils.caps_data_parser import parse_caps_data


# Generated at 2022-06-11 04:08:40.774427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.system.capabilities
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts
    import ansible.module_utils.facts.utils
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.collections
    import ansible.module_utils.six
    import collections
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.urls

# Generated at 2022-06-11 04:08:50.442208
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from . import BaseFactCollector
    from . import SystemCapabilitiesFactCollector

    class fake_module():
        class fake_run_command():
            pass

        def get_bin_path(self, command):
            return '/bin/capsh'

        def run_command(self, cmd, **kwargs):
            return '1', 'Current: =ep', ''

    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.BaseFactCollector = BaseFactCollector
    ansible.module_utils.facts.collector.SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system
    ansible.module_utils.facts.system.SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector

    module = fake_module()

# Generated at 2022-06-11 04:09:03.356672
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Fake_module():
        def __init__(self):
            self.run_command_type = 'bad'
            self.caps_type = 'bad'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_type = 'good'
            return(0, "Current: =ep", "")

        def get_bin_path(self, capsh_path):
            self.caps_type = 'good'
            return "/sbin/capsh"

    module = Fake_module()
    fact = SystemCapabilitiesFactCollector()

    # Test with a non existing command
    fact.collect(module)
    assert not module.run_command_type == 'good'
    assert not module.caps_type == 'good'

# Generated at 2022-06-11 04:09:11.765570
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collectors.system.caps as caps
    capsh_path = '/usr/bin/capsh'
    test_module = type('TestModule', (object,), {
        'get_bin_path': lambda self, arg: capsh_path
        , 'run_command': lambda self, args, **kwargs: (0, 'Current: =ep', '')
    })()
    test_system_capabilities_collector = caps.SystemCapabilitiesFactCollector(test_module)
    # caps.run_command = lambda self, args, **kwargs: (0, 'Current: =ep', '')
    assert test_system_capabilities_collector.collect() == {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }

# Generated at 2022-06-11 04:09:20.818627
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/usr/bin/capsh'
    cmd_rc_mock = MagicMock()
    cmd_rc_mock.returncode = 0
    cmd_out_mock = MagicMock()

# Generated at 2022-06-11 04:09:30.753959
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:09:40.487952
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command_capsh = dict()
            self.params['binary'] = 'capsh'
            self.run_command_capsh['bin_path'] = '/usr/bin/capsh'

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'capsh':
                return self.run_command_capsh['bin_path']
            assert False

        def run_command(self, args, **kwargs):
            assert args[0] == '/usr/bin/capsh'
            assert args[1] == '--print'

# Generated at 2022-06-11 04:09:43.598835
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """This is a test of method collect of class SystemCapabilitiesFactCollector"""
    # TODO: Add more tests here
    testobj = SystemCapabilitiesFactCollector()
    # TODO: Add method-specific tests here
    assert testobj.collect()



# Generated at 2022-06-11 04:09:51.623358
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.utils import get_processor
    from ansible.module_utils._text import to_bytes
    import json
    import os

    # TODO: test w/ explicitly w/ -> get_caps_data()/parse_caps_data()
    #       instead of calling collect() directly
    module = AnsibleModule(argument_spec=dict())
    capsh_path = module.get_bin_path('capsh')
    enforced_caps = []
    enforced = 'NA'
    out = ''

# Generated at 2022-06-11 04:09:57.825011
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create an instance of class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Check if it is an instance of BaseFactCollector class
    assert isinstance(system_capabilities_fact_collector, BaseFactCollector)

    # Check the attributes of __init__
    assert system_capabilities_fact_collector.name == 'caps'

    # Check whether it can be cast to a set
    assert isinstance(set(system_capabilities_fact_collector._fact_ids), set)

# Generated at 2022-06-11 04:09:59.446065
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect()
    assert 'system_capabilities' in result

# Generated at 2022-06-11 04:10:03.045899
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create instance
    instance = SystemCapabilitiesFactCollector()

    # check attributes
    assert instance.name == 'caps'
    assert instance._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])

    # TODO: test collect()

# Generated at 2022-06-11 04:10:17.423443
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class mock_module():
        # Attributes
        class_path_attribute = 'ansible.module_utils.facts.system.caps'
        # Methods
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return '/usr/bin'

# Generated at 2022-06-11 04:10:27.610651
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:10:36.684287
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system
    import tempfile
    import re

    # Create a temporary file to use for input
    fd, caps_in = tempfile.mkstemp()

# Generated at 2022-06-11 04:10:45.226311
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import json
    #from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector
    module = mock.Mock()

# Generated at 2022-06-11 04:10:52.974503
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = {}
    capsh_path = ''
    returncode = 0
    cmd_output = 'Current: =ep Securebits: 00/0x0/1'
    errcall = ''

    mock_subprocess_popen = MockSubprocessPopen(cmd_output, returncode, errcall)
    with patch.object(subprocess, 'Popen', mock_subprocess_popen):
        collected_facts = SystemCapabilitiesFactCollector().collect(module=module, collected_facts=collected_facts)

    assert collected_facts['system_capabilities_enforced'] == 'False'
    assert collected_facts['system_capabilities'] == []


# Generated at 2022-06-11 04:11:02.347364
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:11:10.755023
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.common
    import ansible.module_utils.facts

    module = ansible.module_utils.common.DummyModule(argument_spec=dict())
    module.run_command = ansible.module_utils.facts.fake_command
    capsh_path = "/usr/bin/capsh"
    module.get_bin_path = lambda x: capsh_path if x == 'capsh' else None

    # Test error
    module.run_command.side_effect = Exception("Test exception")
    cap_col = SystemCapabilitiesFactCollector(module=module)
    res = cap_col.collect()
    assert not res

    # Test missing binary
    module.run_command.side_effect = None
    module.get_bin_path = lambda x: None
    cap_col = System

# Generated at 2022-06-11 04:11:19.125222
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    import fact_collector_unit_tests
    unit_test = fact_collector_unit_tests.FactCollectorUnitTest()
    ################################################
    # NOTE: call self.assertTrue(expected_result) #
    #       call self.assertFalse(expected_result)#
    #       call self.assertEqual(expected_result)#
    #       call self.assertRaises()               #
    ################################################
    # NOTE: test stub for method collect of class SystemCapabilitiesFactCollector
    SystemCapabilitiesFactCollector_collect_stub = unit_test.SystemCapabilitiesFactCollector_collect_stub
    module = unit_test.module
    collect = unit_test.collect
   

# Generated at 2022-06-11 04:11:27.656813
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import __builtin__ as builtins
    # NOTE: backported from execution_module.run_command() in Ansible 2.3.0.0
    #       since run_command is not available for our version of Ansible yet -akl
    def run_command(self, args, check_rc=True, close_fds=False, executable=None,
                    data=None, binary_data=False, path_prefix=None, cwd=None,
                    use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None,
                    encoding=None, errors='surrogate_then_replace', log_errors=True,
                    shell=None):

        return 0, None, None

    class FakeModule(object):
        def __init__(self, name, module_args):
            self

# Generated at 2022-06-11 04:11:36.883987
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create mocks
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/capsh')

    # Call method collect
    result = SystemCapabilitiesFactCollector.collect(module)

    # Assertions
    assert  result == {'system_capabilities_enforced': False, 'system_capabilities': []}
    module.get_bin_path.assert_called_once_with('capsh')
    module.run_command.assert_called_once_with(['/usr/bin/capsh', '--print'], errors='surrogate_then_replace')

# Generated at 2022-06-11 04:11:56.963701
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Verify method collect of class SystemCapabilitiesFactCollecto
    """
    import mock
    import tempfile

    test_fixture_file = tempfile.NamedTemporaryFile(mode='w+t', delete = False)
    test_fixture_file.write("Current: =eip")
    test_fixture_file.close()

    mock_module = mock.Mock()
    mock_module.run_command.return_value = (0, test_fixture_file.name, '')
    test_object = SystemCapabilitiesFactCollector()
    test_object.collect(mock_module)
    mock_module.run_command.assert_called_once_with([mock_module.get_bin_path.return_value, '--print'], errors='surrogate_then_replace')

# Generated at 2022-06-11 04:12:06.510158
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ validate the collect method of SystemCapabilitiesFactCollector class """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector, SystemCapabilities
    import os.path

    capsh_path = os.path.join(os.path.dirname(__file__), 'test_capsh_output.txt')
    with open(capsh_path, 'r') as input_file:
        output = input_file.read()

    test_input = [os.path.join(os.path.dirname(__file__), 'capsh'), "--print"]
    test_input.insert(0, output)
    test_input.insert(0, 0)
    test_input.insert(0, True)

    # NOTE: 'mock

# Generated at 2022-06-11 04:12:15.509082
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import json
    import sys
    import os

    class TestModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, prog):
            return '/bin/' + prog

        def run_command(self, cmd, errors):
            if (cmd[1] == "--print"):
                if (os.path.isfile("capsh_print")):
                    with open("capsh_print","r") as f:
                      return (0, f.read(), "")
            return (1, "", "")

    test_params = {"capabilities_mode": "advanced"}
    test_module = TestModule(test_params)
    collector = SystemCapabilitiesFactCollector(test_module)

# Generated at 2022-06-11 04:12:18.716253
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    systemFactCollector = SystemCapabilitiesFactCollector()
    facts = systemFactCollector.collect()

    assert facts['system_capabilities_enforced'] == 'False'
    assert 'cap_net_admin' in facts['system_capabilities']

# Generated at 2022-06-11 04:12:27.712925
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFailException
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def get_bin_path(self, command, opt_dirs=None):
            assert command == 'capsh'
            return '/path/to/command'

        def run_command(self, command, errors='surrogate_then_replace'):
            assert command == ['/path/to/command', '--print']
            return 0, to_bytes('Current: =cap_net_admin,cap_net_raw+ep'), ''

    module_obj = MockModule()

    # make sure the class is implemented completely

# Generated at 2022-06-11 04:12:33.334670
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda x: ('', 'Current: =ep', '')

    capsh_fact = SystemCapabilitiesFactCollector()
    result = capsh_fact.collect(module=module)

    # what to test? only that caps data is stored in facts
    # not the content of it?
    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result

# Generated at 2022-06-11 04:12:41.709592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Test method collect of class SystemCapabilitiesFactCollector in
    module_utils/facts/system/capabilities.py
    '''

    # Unit: pseudo classes stub
    class MockModule(object):
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'capsh':
                return '/bin/capsh'

# Generated at 2022-06-11 04:12:50.217455
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Mock(object):
        def run_command(self, cmd, errors):
            out = ''
            err = ''
            rc = 0

# Generated at 2022-06-11 04:12:59.805774
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # collect facts for a module with capsh_path defined
    module = MockModule(capsh_path='/bin/capsh')
    settings = dict()
    resource = SystemCapabilitiesFactCollector(module=module, settings=settings)
    res_dict = resource.collect(module=module)
    assert res_dict['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-11 04:13:01.124802
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = 'fakes'
    # TODO
    assert True

# Generated at 2022-06-11 04:13:32.510833
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-11 04:13:38.239207
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}
    if not module:
        return facts_dict

    capsh_path = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-11 04:13:47.063052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()

# Generated at 2022-06-11 04:13:55.258952
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector

    ##########################################################################
    # Setup for test
    ##########################################################################
    _mock_module = mock.Mock()
    _mock_module.run_command = mock.Mock()
    _mock_module.run_command.return_value = (0, 'Current: =ep', '')
    _mock_module.get_bin_path = mock.Mock()
    _mock_module.get_bin_path.return_value = '/usr/bin/capsh'
    system_caps_fact_collector = SystemCapabilitiesFactCollector(_mock_module)

    ##########################################################################
    # Test

# Generated at 2022-06-11 04:14:02.700637
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Create an instance of an AnsibleModule
    module_mock = AnsibleModule(argument_spec={})
    # Get the FactsCollector object
    facts_collector = FactsCollector(module_mock, {}, {})
    # Get the SystemCapabilitiesFactCollector object
    system_caps_collector = facts_collector.collectors['system_capabilities']

    # Set return values
    module_mock.get_bin_path.return_value = 'capsh_path'

# Generated at 2022-06-11 04:14:04.331805
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    SystemCapabilitiesFactCollector(module, collected_facts).collect()


# Generated at 2022-06-11 04:14:05.801857
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector.collect() == {}

# Generated at 2022-06-11 04:14:13.449278
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.caps as caps

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            self.capsh_path = '/sbin/capsh'

# Generated at 2022-06-11 04:14:14.304817
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print()


# Generated at 2022-06-11 04:14:16.664027
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    collector = SystemCapabilitiesFactCollector()
    fact_list = collector.collect(module, collected_facts)
    assert 'system_capabilities' in fact_list
    assert 'system_capabilities_enforced' in fact_list

# Generated at 2022-06-11 04:15:25.340015
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: better to mock 'run_command()' of class SystemCapabilitiesFactCollector -akl
    # NOTE: better to mock 'get_caps_data()' of class SystemCapabilitiesFactCollector -akl
    # NOTE: better to mock 'parse_caps_data()' of class SystemCapabilitiesFactCollector -akl
    capsh_path=''

# Generated at 2022-06-11 04:15:27.979592
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # User running ansible is not allowed to run capsh
    # Expected output:
    # ansible_system_capabilities: NA
    # ansible_system_capabilities_enforced: NA
    pass

# Generated at 2022-06-11 04:15:36.716804
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import shutil
    import sys
    import os
    import stat
    # Create temporary directory to store test files
    temp_dir = tempfile.mkdtemp()
    # Create temporary files
    temp_stdout = tempfile.mktemp(dir=temp_dir)
    temp_data = tempfile.mktemp(dir=temp_dir)
    # Create some sample data

# Generated at 2022-06-11 04:15:45.044392
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Run collect() and verify correct (and copious) output.
    """
    # NOTE: -> module arg will be None/test_module mock -akl
    # module = None
    # NOTE: -> mock of return values -akl
    # rc = 0
    # out = "Current: = cap_chown,cap_dac_override+eip\nBounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio

# Generated at 2022-06-11 04:15:52.724296
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
        Updates:
           - Added capability tests
    """
    import os,tempfile
    test_file_fd, test_file_name = tempfile.mkstemp()
    test_file_obj = os.fdopen(test_file_fd, "w")

    module = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../', 'modules', 'script.py'))

# Generated at 2022-06-11 04:15:53.200130
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-11 04:16:01.457538
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os
    import textwrap

    # create a 'caps' executable
    capsh_path = tempfile.NamedTemporaryFile(delete=False, mode=0o755)
    capsh_path.close()
    # NOTE: use a tempfile for the script so that it is deleted automatically
    # and therefore doesn't impact other tests.
    capsh_script = tempfile.NamedTemporaryFile()
    capsh_script.write(textwrap.dedent("""\
        #!{0}
        echo "Current: cap_net_raw+ep"
        """.format(os.environ['SHELL'])).encode("UTF-8"))
    capsh_script.close()
    os.rename(capsh_script.name, capsh_path.name)

    # NOTE: adjust

# Generated at 2022-06-11 04:16:10.407098
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pprint
    import ansible.module_utils.facts.system.capabilities
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import parse_caps_data
    from ansible.module_utils.facts.system.capabilities import get_caps_data

    # Use the ansible system module dummy object
    from ansible.module_utils.facts.system.base import DummyAnsibleModule

    # Init the DummyAnsibleModule...
    dumy_ansible_module = DummyAnsibleModule()
    dumy_ansible_module.run_command_environ_update = {'LC_ALL': 'C'}

    #
    # Test SystemCapabilitiesFactCollector when enforce = True
   

# Generated at 2022-06-11 04:16:15.086943
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = type("Module", (object,), {
        "run_command": lambda self, args, errors='surrogate_then_replace':
            (0, 'Current: =ep', ''),
    })
    # NOTE: use mock testing method -akl
    facts_dict = SystemCapabilitiesFactCollector.collect(module)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []

# Generated at 2022-06-11 04:16:20.247397
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = create_ansible_module_mock()
    mock_module.run_command.return_value = (0, 'Current: =ep\nBounding set =cap_sys_boot cap_sys_nice\n', '')

    c = SystemCapabilitiesFactCollector()
    result = c.collect(module=mock_module)

    assert result['system_capabilities'] == ['cap_sys_boot', 'cap_sys_nice']
    assert result['system_capabilities_enforced'] == 'False'