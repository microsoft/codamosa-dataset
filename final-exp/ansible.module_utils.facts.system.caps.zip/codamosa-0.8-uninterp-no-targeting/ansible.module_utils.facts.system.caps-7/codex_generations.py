

# Generated at 2022-06-20 18:51:10.422414
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.utils.module_docs_fragments
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system
    import importlib

    # Load base classes that were 'collected' by our collector
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.base import BaseFileContentCollector
    from ansible.module_utils.facts.system.base import BaseHardwareCollector
    from ansible.module_utils.facts.system.base import BaseNetworkCollector
    from ansible.module_utils.facts.system.base import BaseFileSystemCollector
    from ansible.module_utils.facts.system.base import BaseServiceMgrCollect

# Generated at 2022-06-20 18:51:11.023018
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:13.226759
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'


# Generated at 2022-06-20 18:51:24.299469
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_cap_fact_collector = SystemCapabilitiesFactCollector()
    # NOTE: -> mock_module() for easier mocking -akl
    class MockModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/usr/bin/capsh'

        def run_command(self, arg, errors):
            return 0, 'Current: =ep', ''

    mock_module = MockModule()
    facts = system_cap_fact_collector.collect(mock_module)
    assert isinstance(facts, dict)
    assert 'system_capabilities_enforced' in facts.keys()
    assert 'system_capabilities' in facts.keys()
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced']

# Generated at 2022-06-20 18:51:33.260456
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import get_collector_names
    import os

    def mock_run_command(*args, **kwargs):
        if args[0] == [os.path.sep.join(['/bin', 'capsh']), "--print"]:
            rc = 0
            out = ('Current: =ep')
            err = ''
        else:
            rc = 1
            out = ''
            err = ''
        return rc, out, err

    def mock_get_bin_path(*args, **kwargs):
        if args[0] == 'capsh':
            return os.path.sep.join(['/bin', 'capsh'])
        return None

    module_mock = type('moduleMock')()

# Generated at 2022-06-20 18:51:39.075669
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock(**_module_defaults)
    module.run_command.return_value = (0, 'Current: =ep', '')
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = system_capabilities_fact_collector.collect(module=module)
    assert collected_facts['system_capabilities_enforced'] == 'False'
    assert collected_facts['system_capabilities'] == []



# Generated at 2022-06-20 18:51:50.299338
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    capsh_path = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'

# Generated at 2022-06-20 18:51:56.816369
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import tempfile
    import os
    temp_fd, temp_name = tempfile.mkstemp()
    temp_file = os.fdopen(temp_fd, 'w')

# Generated at 2022-06-20 18:52:04.150954
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    def get_bin_path(name):
        return name

    def run_command(args, errors):
        return (0, "Current: =ep\n", "")

    class DummyModule(object):
        def __init__(self):
            self.params = {'testing': True}
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    import pytest

    collected_facts = {}
    module = DummyModule()
    system_caps = SystemCapabilitiesFactCollector()
    system_caps.collect(module, collected_facts)

    assert collected_facts['system_capabilities_enforced'] == 'False'
    assert collected_facts['system_capabilities'] == []

# Generated at 2022-06-20 18:52:15.172589
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: mock module object to ensure code only tested
    #       and not the actual implementation
    module = MockModule()
    # Instantiate fact collector
    fact_collector = SystemCapabilitiesFactCollector(module=module)

    # NOTE: make sure available as we're testing it
    assert fact_collector.name == 'caps'

    collected_facts = dict()
    # NOTE: call is made with module so we can test that
    #       the method actually worked
    # NOTE: setting collected_facts to a value so we can
    #       assert that it has been updated
    facts_dict = fact_collector.collect(module=module, collected_facts=collected_facts)
    assert facts_dict['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-20 18:52:20.424873
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    f = SystemCapabilitiesFactCollector()
    assert f.__class__.__name__ == 'SystemCapabilitiesFactCollector'

# Generated at 2022-06-20 18:52:25.678070
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = mock.MagicMock()
    m.run_command.return_value = (0, 'Current: =pe', '')
    module = m
    collector = SystemCapabilitiesFactCollector()

    facts = collector.collect(module=module)

    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:52:28.754527
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:36.081078
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import StringIO
    from ansible.module_utils.facts import ModuleStub

    # Test enforced
    module = ModuleStub.create(dict(
        run_command_environ_update=dict(LANG='C', LC_ALL='C', LC_MESSAGES='C', LC_CTYPE='C'),
        command_warnings=[]
    ))

    module.run_command = lambda args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False: \
        (0, "Current: =ep", '')

    capcollector = SystemCapabilitiesFactCollector(module, "capsh")
    collected_facts = {}
    capcollector.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-20 18:52:37.830935
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
  capsFactCollector = SystemCapabilitiesFactCollector()
  assert capsFactCollector.name == 'caps'

# Generated at 2022-06-20 18:52:45.026028
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import ansible.module_utils.facts.system.system_capabilities as module_system_capabilities

    class MockModule:
        def __init__(self):
            self.run_command_results = dict()

# Generated at 2022-06-20 18:52:48.954356
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-20 18:53:00.106796
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    class Module:
        def __init__(self):
            self.run_command = run_command

            # NOTE: set to True for convenience of debugging output
            self._debug = False

        def get_bin_path(self, path_name, opt_dirs=[]):
            return '/bin/capsh'

        

# Generated at 2022-06-20 18:53:06.040450
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import get_collector_class

    # A couple of simple example tests of the collector class constructor
    assert get_collector_class('capabilities') == SystemCapabilitiesFactCollector
    assert get_collector_class('caps') == SystemCapabilitiesFactCollector

    # And a non-existent collector name
    assert get_collector_class('blah') is None

# Generated at 2022-06-20 18:53:08.363505
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    c = SystemCapabilitiesFactCollector()
    assert c.collect() == { 'system_capabilities': [], 'system_capabilities_enforced': 'NA' }

# Generated at 2022-06-20 18:53:15.654471
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == \
        set(['system_capabilities_enforced', 'system_capabilities'])

# Generated at 2022-06-20 18:53:18.698400
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SCFC = SystemCapabilitiesFactCollector()
    assert SCFC.name == 'caps'
    assert SCFC._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])



# Generated at 2022-06-20 18:53:23.565036
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])



# Generated at 2022-06-20 18:53:24.505684
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: add testing
    return

# Generated at 2022-06-20 18:53:34.836867
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: better 'mock' module, e.g. https://github.com/brianr/mockito-python
    class MockModule(object):
        @staticmethod
        def get_bin_path(cmd, required=False):
            return '/usr/bin/capsh'


# Generated at 2022-06-20 18:53:38.850704
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:42.287578
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}

# Generated at 2022-06-20 18:53:54.261290
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest

    @pytest.mark.parametrize("capsh_out, caps_enforced, caps_list", [
        ("Current: = cap_chown,cap_dac_override,cap_fowner=eip cap_net_bind_service=ep,cap_net_raw=ep\n", 'True', ['chown', 'dac_override', 'fowner', 'net_bind_service', 'net_raw']),
        ("Current: =ep\n", 'False', []),
        ("Current:\n", 'NA', []),
    ])
    def test_capsh_out(mocker, capsh_out, caps_enforced, caps_list):
        mocker.patch('os.path.exists', return_value=True)

# Generated at 2022-06-20 18:54:04.895976
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY2
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.urls import open_url
    import io

    # Optional import of OpenSSL
    try:
        import OpenSSL
    except ImportError:
        pass

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=True
    )
    module.exit_json = module.exit_json
    module.fail_json

# Generated at 2022-06-20 18:54:12.814150
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.test import ModuleTestCase

    class TestSystemCapabilitiesFactCollector(ModuleTestCase):
        def test_collect(self):
            self.assertEqual(
                SystemCapabilitiesFactCollector.collect(dict()),
                {'system_capabilities': 'NA',
                 'system_capabilities_enforced': 'NA'}
            )
    test_SystemCapabilitiesFactCollector = TestSystemCapabilitiesFactCollector()
    test_SystemCapabilitiesFactCollector.setUp()
    test_SystemCapabilitiesFactCollector.test_collect()
    test_SystemCapabilitiesFactCollector.tearDown()

# Generated at 2022-06-20 18:54:20.682855
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:54:30.868661
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = MagicMock()
    m.run_command.return_value = 0, "Current: =ep \nBounding set =cap_net_raw,cap_net_admin,cap_net_bind_service,cap_net_broadcast,cap_net_raw+eip\nSecurebits: 00/0x0/1'b0 secure-noroot, secure-no-suid-fixup, secure-keep-caps", ''
    m.get_bin_path.return_value = '/usr/bin/capsh'
    scfc = SystemCapabilitiesFactCollector()
    result = scfc.collect(m)
    assert result.get('system_capabilities_enforced') == 'False'

# Generated at 2022-06-20 18:54:34.462992
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids.__contains__('system_capabilities')
    assert not SystemCapabilitiesFactCollector._fact_ids.__contains__('test')

test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:54:43.093429
# Unit test for constructor of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:54:43.926504
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-20 18:54:55.260663
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Check if class instance exists
    fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(fact_collector, SystemCapabilitiesFactCollector)

    # Check if system capabilities are correctly collected
    caps_dict = fact_collector.collect()
    assert 'system_capabilities' in caps_dict
    assert 'system_capabilities_enforced' in caps_dict

    # Check if system capabilities are correctly collected
    # and enforced is set to True
    assert 'system_capabilities_enforced' in caps_dict
    assert 'system_capabilities' in caps_dict
    if len(caps_dict['system_capabilities']) > 0:
        assert caps_dict['system_capabilities_enforced'] == 'True'
    else:
        assert caps_dict['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:54:59.209058
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])
    assert obj.collect() == {}

# Generated at 2022-06-20 18:55:00.114288
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:03.021090
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    capsh_path = "capsh"
    sut = SystemCapabilitiesFactCollector()
    expected = {}
    actual = sut.collect(module, collected_facts)
    assert(expected == actual)



# Generated at 2022-06-20 18:55:04.242507
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-20 18:55:23.014445
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import get_collector_instance

    module = get_collector_instance('SystemCapabilitiesFactCollector')
    Collectfacts = SystemCapabilitiesFactCollector.collect(module, {})
    assert 'system_capabilities_enforced' in Collectfacts
    assert 'system_capabilities' in Collectfacts

# Generated at 2022-06-20 18:55:33.749894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    enforced_caps = ['cap_chown', 'cap_dac_override', 'cap_dac_read_search', 'cap_fowner', 'cap_fsetid', 'cap_kill', 'cap_setgid', 'cap_setuid', 'cap_sys_chroot', 'cap_sys_ptrace', 'cap_sys_admin', 'cap_sys_boot']


# Generated at 2022-06-20 18:55:39.128744
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fake_module = DummyAnsibleModule()
    # Instantiate SystemCapabilitiesFactCollector
    caps_facts = SystemCapabilitiesFactCollector()
    # Run SystemCapabilitiesFactCollector's internal collect() method
    caps_facts.collect(module=fake_module)
    # Check if collect() method returned what is expected
    assert caps_facts.name == 'caps'
    assert set(caps_facts._fact_ids) == set(['system_capabilities',
                                             'system_capabilities_enforced'])


# Generated at 2022-06-20 18:55:49.483676
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:55:58.425529
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/usr/bin/capsh'
    rc = 0
    out = """Current: =ep
Bounding set =cap_sys_admin,cap_sys_ptrace,cap_mknod,cap_audit_write,cap_setfcap+eip
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-noroot-locked: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
 uid=0(root)
 gid=0(root)
 groups=0(root)
"""
    err = ''
    module = MockModule(capsh_path, rc, out, err)
    collector = SystemCapabilitiesFactCollector()
    collected_facts = {}

# Generated at 2022-06-20 18:56:00.737192
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    t = SystemCapabilitiesFactCollector()
    assert t.name == 'caps'
    assert t._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:11.430657
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_data_dir = FilesystemFactsCollector
    results = {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

    def get_bin_path_mock_first_then_none(arg):
        # first return a fake path for capsh
        if get_bin_path_mock_first_then_none.counter == 0:
            get_bin_path_mock_first_then_none.counter += 1
            return 'capsh_path'
        else:
            return None
    get_bin_path_mock_first_then_none.counter = 0


# Generated at 2022-06-20 18:56:15.700818
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Unit test for constructor of class SystemCapabilitiesFactCollector
    """
    test_obj = SystemCapabilitiesFactCollector()
    assert test_obj._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:19.633642
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector.fact_ids == {'system_capabilities',
                                                           'system_capabilities_enforced'}


# Generated at 2022-06-20 18:56:30.357138
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}

    module = MockModule()
    capsh_path = module.get_bin_path('capsh')
    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    enforced_caps = []
    enforced = 'NA'
    for line in out.splitlines():
        if len(line) < 1:
            continue
        if line.startswith('Current:'):
            if line.split(':')[1].strip() == '=ep':
                enforced = 'False'
            else:
                enforced = 'True'
                enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

    facts_dict['system_capabilities_enforced'] = enforced
    facts_dict

# Generated at 2022-06-20 18:57:07.936255
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    my_class = SystemCapabilitiesFactCollector(module)
    assert my_class.name == 'caps'
    assert my_class._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:16.530126
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    global system_capabilities
    global system_capabilities_enforced

    # system_capabilities & system_capabilities_enforced are
    # considered as attributes of SystemCapabilitiesFactCollector class
    system_capabilities = []
    system_capabilities_enforced = 'NA'

    # Constructor for class SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # Asserts for the constructor class
    assert system_capabilities_fact_collector.platform == 'Generic'
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])
    assert system_capabilities_fact_collector.collect

# Generated at 2022-06-20 18:57:21.250329
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock module
    module = MagicMock()
    # Create a mock ansible module
    ansible_module = MagicMock(module=module)
    # Set a return value for method run_command
    ansible_module.run_command.return_value = (0, "Current: =ep", "")
    # mock fact module is not needed, so return None for that parameter
    facts_dict = SystemCapabilitiesFactCollector().collect(module=module, collected_facts=None)
    # Assert that facts_dict contains the expected data
    assert facts_dict == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-20 18:57:24.981321
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.collect() == {
        'system_capabilities' : [],
        'system_capabilities_enforced' : 'NA'
    }

# Generated at 2022-06-20 18:57:28.528328
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Instantiate an instance of the SystemCapabilitiesFactCollector
    obj = SystemCapabilitiesFactCollector()
    # Make sure the object is an instance of the BaseFactCollector
    assert isinstance(obj, BaseFactCollector)

# Generated at 2022-06-20 18:57:37.387765
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Current: =ep\n', ''))
    s = SystemCapabilitiesFactCollector()
    facts = s.collect(module, {})
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

    module.run_command = Mock(return_value=(0, 'Current: =ep cap_net_admin,cap_net_raw+eip\n', ''))
    facts = s.collect(module, {})
    assert facts['system_capabilities_enforced'] == 'True'
    assert facts['system_capabilities'] == ['cap_net_admin', 'cap_net_raw']



# Generated at 2022-06-20 18:57:45.945999
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    import pytest

    class MockModule(object):
        ''' mock module class '''
        def __init__(self, *args, **kwargs):
            self._verbosity = kwargs.get('verbosity', 0)
            self._debug = kwargs.get('debug', False)
            self._result = {
                'failed': False,
                'rc': 0,
                'stderr': False,
                'stdout': False,
            }

        @property
        def params(self):
            ''' mock params property '''

# Generated at 2022-06-20 18:57:50.977235
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test of instantiation
    obj_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert obj_SystemCapabilitiesFactCollector.name == 'caps'
    assert obj_SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:57:58.944026
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    if False:
        module.run_command = lambda x, **kw: (0, 'Current: =ep', '')

# Generated at 2022-06-20 18:58:01.923399
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:59:16.252539
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector.fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:59:19.700473
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}



# Generated at 2022-06-20 18:59:23.534279
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect()
    assert result == {
        'system_capabilities_enforced': 'NA',
        'system_capabilities': []
    }


# Generated at 2022-06-20 18:59:24.702869
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:59:26.480887
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass


# Generated at 2022-06-20 18:59:33.597668
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: get_caps_data()/parse_caps_data() for easier mocking -akl
    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = dict()

    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (0, OUTPUT, None)
    fact_collector.collect(module, collected_facts)
    assert collected_facts['system_capabilities_enforced'] == 'False'
    assert collected_facts['system_capabilities'] == []


# Generated at 2022-06-20 18:59:43.633724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: unindent
    capsh_path = '/usr/bin/capsh'

# Generated at 2022-06-20 18:59:54.868146
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FakeModule
    from ansible_collections.ansible.dist.plugins.module_utils.facts.system.caps.system_capabilities import FakeArgv
    import os
    import pwd
    import sys

    # fake the returncode, stdout, and stderr in the module invocation
    # TODO: use the FakeModule we have instead

# Generated at 2022-06-20 18:59:55.895466
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 19:00:01.825688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test for method collect of class SystemCapabilitiesFactCollector '''
    #
    #  instance with attributes
    #    name: 'caps'
    #    _fact_ids: { 'system_capabilities', 'system_capabilities_enforced' }
    #
    pass