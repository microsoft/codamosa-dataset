

# Generated at 2022-06-20 18:51:11.140567
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    fact_module = ansible_collector.get_fact_module(
        'ansible.module_utils.facts.system.caps')
    TestClass = fact_module.SystemCapabilitiesFactCollector

    TestClass.collect()

# Generated at 2022-06-20 18:51:14.005731
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:51:25.152576
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.virtual.system.caps as mock_caps

    # Run the collect method
    # No 'capsh' command available?
    # return an empty dictionary
    actual = SystemCapabilitiesFactCollector.collect()
    assert actual == {}

    # use a fake module (passed in module param)
    # 'capsh' command exists, but returns nothing
    # return an empty dictionary
    capsh_path = '/bin/capsh'

# Generated at 2022-06-20 18:51:26.409925
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'


# Generated at 2022-06-20 18:51:35.140341
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""

    class MockModule(object):
        def get_bin_path(self, path):
            return path


# Generated at 2022-06-20 18:51:37.122369
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:47.549683
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    target = 'caps'
    collector = SystemCapabilitiesFactCollector(module=module)
    result = collector.collect(module=module)

    expected = {'system_capabilities_enforced': 'True',
                'system_capabilities': ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']}
    assert result == expected


# Generated at 2022-06-20 18:51:55.621088
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # system_capabilities_enforced is missing from this fact list
    fact_list = ['system_capabilities', 'test']

    c = SystemCapabilitiesFactCollector(fact_list)
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced', 'test'])

    # Assert that calling the constructor more than once with different inputs updates the
    # internal _fact_ids list
    c._fact_ids = set()
    assert c._fact_ids == set()

    fact_list = ['system_capabilities_enforced', 'test']

    c = SystemCapabilitiesFactCollector(fact_list)
    assert c.name == 'caps'

# Generated at 2022-06-20 18:51:57.266275
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    f = SystemCapabilitiesFactCollector()
    assert f is not None
    assert f.name == 'caps'

# Generated at 2022-06-20 18:51:59.723674
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:03.033152
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:07.977644
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: not sure what testing a private method buys us -akl
    # NOTE: would either use a fixture, or could use FauxModule to mock -akl
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import os

    # create a fake module instance
    class FauxModule:
        def __init__(self):
            self.params = dict()
            self.run_command = os.system

        def get_bin_path(self, arg, required=False):
            if arg == 'capsh':
                return 'capsh'
            else:
                return None
    # create a fake instance of BaseFactCollect

# Generated at 2022-06-20 18:52:18.376446
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    try:
        # NOTE: -> module_utils.module_finder import AnsibleModule
        from ansible.module_utils.facts.collector import AnsibleModule

        # NOTE: -> module_utils.module_runner import _load_params
        from ansible.module_utils.module_runner import _load_params

        module = AnsibleModule(argument_spec={})
        module.run_command = run_command_func
        module.get_bin_path = get_bin_path_func

        # NOTE: -> system_capabilities.collect()
        collector = SystemCapabilitiesFactCollector()
        collector.collect(module=module)

    except Exception as e:
        raise Exception("problem executing test_SystemCapabilitiesFactCollector_collect: {}".format(e))


# Mock of ansible.module_utils.module_runner.run

# Generated at 2022-06-20 18:52:25.814352
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # collect() will return SystemCapabilities dictionary
    cmd_to_exit_map = {
        'capsh --print': dict(rc=0, out='''
Current: =eip
Bounding set =eip
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
Capabilities: =eip
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
''', err='')
    }
    mock_module = MockModule(cmd_to_exit_map)

# Generated at 2022-06-20 18:52:27.144247
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-20 18:52:28.452056
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:52:35.784468
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    def mock_get_bin_path(binary, required=True):
        if binary == 'capsh':
            return '/sbin/capsh'
        else:
            return None

    def mock_run_command(args, rcs, outdata, errdata, errors):
        return (0, "/sbin/capsh --print Current: =eip cap_setpcap,cap_setfcap+ei", '')

    module = type('FakeModule', (object,), {
        'get_bin_path': mock_get_bin_path,
        'run_command': mock_run_command
    })()

    # Create the instance to be tested
    test_obj = SystemCapabilitiesFactCollector()
    test_obj.collect(module)

# Generated at 2022-06-20 18:52:40.862085
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Module:
        def get_bin_path(self, path):
            return None

        def run_command(self, cmd, errors=None):
            return 0, "Current: =ep", ""

    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(Module())

    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []



# Generated at 2022-06-20 18:52:42.204940
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:44.544388
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = os
    collected_facts = {}
    data = SystemCapabilitiesFactCollector().collect(module, collected_facts)
    assert data['system_capabilities']

# Generated at 2022-06-20 18:53:01.751183
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible_module_test_module
    from ansible.module_utils.facts.collectors.capabilities import SystemCapabilitiesFactCollector 
    test_system_capabilities_fact_collector = SystemCapabilitiesFactCollector(ansible_module_test_module.MockModule())

    mock_module = ansible_module_test_module.MockModule()

    assert test_system_capabilities_fact_collector.collect(mock_module) == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

    mock_module.get_bin_path = lambda self, path : True
    mock_module.run_command = lambda self, command : 0, "Current: =cap_chown,cap_dac_override+eip", ""
    assert test_system_capabilities_

# Generated at 2022-06-20 18:53:10.730201
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''Test case for method collect of class SystemCapabilitiesFactCollector'''
    import tempfile
    test_file_fd, test_file_name = tempfile.mkstemp()
    with open(test_file_name, 'w') as f:
        f.write("Current: = cap_setpcap+i\n\
Bounding set =cap_setpcap\n\
Securebits: 00/0x0/1'b0\n\
 secure-noroot: no (unlocked)\n\
 secure-no-suid-fixup: no (unlocked)\n\
 secure-keep-caps: no (unlocked)\n\
uid=0(root) gid=0(root) groups=0(root)")

    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:53:14.958766
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    foo_collector = SystemCapabilitiesFactCollector()
    assert foo_collector.name == 'caps'
    assert foo_collector._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:23.174232
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock module and return value of command capsh --print that is run
    import ansible.module_utils.facts.collectors.system.capabilities
    import ansible.module_utils.facts.collectors.system.capabilities
    import ansible.module_utils.facts.collectors.system.capabilities


# Generated at 2022-06-20 18:53:26.189564
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:53:36.984924
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest
    from mock import Mock
    from ansible.module_utils.facts import collector

    class MyException(Exception):
        pass

    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'Current: =ep cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip\n', '')
    mock_module.get_bin_path.return_value = '/bin/capsh'

# Generated at 2022-06-20 18:53:40.187077
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:46.852268
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = object()

    # NOTE: insert test code here...
    # TODO: return a valid set of facts + data-driven coverage
    #
    # e.g.
    #
    # class ModuleStub(object):
    #     def __init__(self):
    #         self.output = {
    #             'capsh_path': '/bin/capsh',
    #             'rc': 0,
    #             'out': 'Current: =ep',
    #             'err': '',
    #         }
    #     def get_bin_path(self, exe):
    #         return self.output['capsh_path']
    #     def run_command(self, args, errors='surrogate_then_replace'):
    #         return self.output['rc'], self.output['out'

# Generated at 2022-06-20 18:53:58.912850
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    def test_method(self, module=None, collected_facts=None):
        return SystemCapabilitiesFactCollector._get_caps_data(module)

    ans = ansible_collector.AnsibleCollector(None, 'test', None)
    ans.add_collection('test', BaseFactCollector)
    ans.get_collection('test').get_fact('test').collect = test_method
    res = ans.get_collection('test').get_fact('test').collect()
    assert len(res) == 2
    assert res['system_capabilities_enforced']

# Generated at 2022-06-20 18:54:03.139704
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:17.331700
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector()
    assert a.name == "caps"
    assert a._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:20.433165
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert len(sut._fact_ids) == 2
    assert 'system_capabilities' in sut._fact_ids
    assert 'system_capabilities_enforced' in sut._fact_ids

# Generated at 2022-06-20 18:54:25.425546
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    capsh_path = module.get_bin_path('capsh')
    # NOTE: 'if not capsh_path' should be checked before method collect is called.
    #       So this is an invalid test. -akl
    for forced in [True, False]:
        caps = ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']
        facts = {}
        if not forced:
            caps.remove('setuid')
            caps.remove('setgid')
            caps.remove('net_bind_service')
            enforced = 'False'
        else:
            enforced

# Generated at 2022-06-20 18:54:30.280154
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])


# Generated at 2022-06-20 18:54:31.811376
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_caps = SystemCapabilitiesFactCollector()
    assert system_caps



# Generated at 2022-06-20 18:54:34.382474
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:39.634714
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/usr/bin/capsh'
    module.run_command.return_value = (0, 'Current: =ep', None)
    c = SystemCapabilitiesFactCollector('/usr/bin/capsh', 'capsh')
    ret = c.collect(module)
    assert ret['system_capabilities_enforced'] == 'False'
    assert ret['system_capabilities'] == ['e', 'p']


# Generated at 2022-06-20 18:54:49.659220
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors import get_collector_instance

    # Common module_utils imports
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, 'Current:\t= cap_setpcap,cap_net_bind_service,cap_sys_ptrace,cap_chown,cap_fowner+eip', '')
    mock_module.get_bin_path.return_value = '/usr/bin/capsh'
    system_col_inst = get_collector_instance(SystemCapabilitiesFactCollector, mock_module)
    collected_system_facts = system_col_inst.collect()

    assert 'system_capabilities_enforced' in collected_system_facts
    assert 'system_capabilities' in collected_system_facts
    assert collected

# Generated at 2022-06-20 18:54:53.611841
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    o = SystemCapabilitiesFactCollector()
    assert o.name == 'caps'
    assert o._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert SystemCapabilitiesFactCollector.__name__ == 'SystemCapabilitiesFactCollector'

# Generated at 2022-06-20 18:54:54.352500
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facter = SystemCapabilitiesFactCollector()
    facter.name == 'caps'


# Generated at 2022-06-20 18:55:26.727337
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SCFC = SystemCapabilitiesFactCollector()
    
    # Unit test for method collect with no module
    def test_noModule():
        assert SCFC.collect() == {}
    test_noModule()
    # Unit test for method collect with module and no capsh
    def test_module_noCapsh():
        module = getModuleMock()
        module.get_bin_path.return_value = None
        assert SCFC.collect(module) == {}
    test_module_noCapsh()
    # Unit test for method collect with module, capsh and invalid output
    def test_module_capsh_invalidOuput():
        module = getModuleMock()
        module.get_bin_path.return_value = "capsh"

# Generated at 2022-06-20 18:55:31.162022
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])
    assert collector.collect() == {}

# Generated at 2022-06-20 18:55:32.289589
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    SystemCapabilitiesFactCollector.collect(module)

# Generated at 2022-06-20 18:55:33.709518
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #TODO: implement this unit test
    pass

# Generated at 2022-06-20 18:55:36.403785
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    assert facts_dict == {'system_capabilities_enforced': 'NA',
                          'system_capabilities': []}

# Generated at 2022-06-20 18:55:37.328849
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 18:55:47.501000
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Create an instance of SystemCapabilitiesFactCollector
    system_cap_fc = SystemCapabilitiesFactCollector()

    # Check if the created instance is of the correct type
    assert(isinstance(system_cap_fc, SystemCapabilitiesFactCollector))

    # Check if the created instance has the correct name
    assert(system_cap_fc.name == 'caps')

    # Check if the created instance has the correct (and nonempty) set of fact_ids.
    assert(system_cap_fc._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced']))

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:56.505933
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os.path
    import sys
    import os
    import ansible_collections.ansible.community.plugins.module_utils.basic

    # Create a fake module
    class FakeModule:
        def __init__(self, path, rc=0, out='', err=''):
            self.run_command_path = path
            self.run_command_rc = rc
            self.run_command_out = out
            self.run_command_err = err

        def get_bin_path(self, binary):
            return self.run_command_path

        def run_command(self, params, **kwargs):
            assert params[0] == self.run_command_path

            return (self.run_command_rc, self.run_command_out, self.run_command_err)


# Generated at 2022-06-20 18:55:57.273522
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'

# Generated at 2022-06-20 18:56:03.466550
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock module
    module = MockModule()
    module.get_bin_path.return_value = None

    # Mock collected_facts
    collected_facts = {}

    # Call method collect
    SystemCapabilitiesFactCollector().collect(module, collected_facts)
    # Check result
    assert collected_facts == {}

    # Mock module
    module.get_bin_path.return_value = "/usr/bin/capsh"
    # Mock run_command

# Generated at 2022-06-20 18:57:02.016512
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    sys_caps = SystemCapabilitiesFactCollector(module=module)
    assert 'system_capabilities' in sys_caps.collect()

# Generated at 2022-06-20 18:57:03.679909
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'


# Generated at 2022-06-20 18:57:13.211316
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Tests SystemCapabilitiesFactCollector.collect()
    """
    import os
    import tempfile
    import pwd
    import stat
    import shutil
    import ansible.module_utils.facts.collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.six.moves import builtins

    # NOTE: pip install mock. Use mock_open from python3 unittest.mock if/when ansible is on 3.x.
    from mock import MagicMock, mock_open

    test_user = 'test_user'
    test_uid = 100

    # NOTE: no try/finally

# Generated at 2022-06-20 18:57:20.381873
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    assert platform.system() == 'Linux'

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.capabilities.system_capabilities import SystemCapabilitiesFactCollector

    module_mock = Mock()
    module_mock.get_bin_path.return_value = '/bin/capsh'
    module_mock.run_command.return_value = 0, 'Current: =ep', ''

    system_capabilities_collector = SystemCapabilitiesFactCollector(module_mock)

    facts_dict = system_capabilities_collector.collect()

    assert 'system_capabilities' in facts_dict
    assert 'system_capabilities_enforced' in facts_dict


# Generated at 2022-06-20 18:57:30.454083
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os.path
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../..'))
    from plugin_loader import ModuleLoader
    module = ModuleLoader.load_module('import_role')
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue

# Generated at 2022-06-20 18:57:38.934688
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()

    # Get system capabilities with "capsh --print" command
    capsh_path = "/bin/capsh"
    out = "Current: =ep"
    err = ""
    rc = 0
    module = MagicMock(name="module", spec=ModuleUtility)
    module.run_command.return_value = rc, out, err
    module.get_bin_path.return_value = capsh_path
    collected_facts = None

    # Run the collect method and validate results
    result = collector.collect(module=module, collected_facts=collected_facts)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

    # Get system capabilities with "capsh --print" command

# Generated at 2022-06-20 18:57:47.500175
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
        import tempfile, os
        testdir = "%s/ansible_facts" % tempfile.gettempdir()
        testfile = "%s/facts.d/test_system_caps.sh" % testdir
        if not os.path.exists(testdir):
            os.makedirs(testdir)
        f=open(testfile, 'w')
        f.write('''#!/bin/sh
echo -n "=ep"
''')
        f.close()

# Generated at 2022-06-20 18:57:57.608881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # GIVEN
    # test module for use in collect method
    class Module(object):
        def get_bin_path(self, *args, **kwargs):
            return 'capsh'

        def run_command(self, *args, **kwargs):
            return None, 'Current: = cap_full_set\nBounding set =cap_full_set\nSecurebits: 00/0x0/1\n secure-noroot: no (unlocked)\n secure-no-suid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)', None

    # WHEN
    cap_collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:58:03.204683
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Unit test for constructor of class SystemCapabilitiesFactCollector"""
    # NOTE: this feels odd, why not have name param in constructor? -akl
    assert SystemCapabilitiesFactCollector.name == 'caps'
    # NOTE: this feels odd, why not have _fact_ids param in constructor? -akl
    expected_set = {'system_capabilities',
                    'system_capabilities_enforced'}
    assert SystemCapabilitiesFactCollector._fact_ids == expected_set

# Generated at 2022-06-20 18:58:05.415360
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_my_arr = SystemCapabilitiesFactCollector()
    assert test_my_arr._fact_ids == set(['system_capabilities',
                                         'system_capabilities_enforced'])


# Generated at 2022-06-20 19:00:21.477862
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector is not None
    assert fact_collector._fact_ids is not None
    assert len(fact_collector._fact_ids) == 2
    assert 'system_capabilities' in fact_collector._fact_ids
    assert 'system_capabilities_enforced' in fact_collector._fact_ids


# Generated at 2022-06-20 19:00:24.649625
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 19:00:27.161819
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:33.153666
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit testing of SystemCapabilitiesFactCollector method collect()
    """
    # import needed dependancies

    import sys # required to mock module member of BaseFactCollector

    # create instance of SystemCapabilitiesFactCollector
    scfc = SystemCapabilitiesFactCollector()

    # mock test values

# Generated at 2022-06-20 19:00:41.000276
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def get_bin_path(self, arg):
            return "capsh"

        def run_command(self, arg):
            return 0, "Current:  =ep", ""

    caps_obj = SystemCapabilitiesFactCollector()
    fact = caps_obj.collect(MockModule(), {})
    assert fact['system_capabilities_enforced'] == 'False'
    assert fact['system_capabilities'] == []

# Generated at 2022-06-20 19:00:46.937009
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert 'caps' == collector.name
    assert set(['system_capabilities', 'system_capabilities_enforced']) == collector._fact_ids

# Generated at 2022-06-20 19:00:48.404419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # assert what?
    pass

# Generated at 2022-06-20 19:00:52.857014
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:54.724724
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector



# Generated at 2022-06-20 19:01:06.048485
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: copied remainder of this method from test_class_CapabilitiesFactCollector of
    # test_module_facts.py -akl
    module = AnsibleModuleMock()