

# Generated at 2022-06-20 18:51:10.758165
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities = SystemCapabilitiesFactCollector()
    assert system_capabilities.name == "caps"
    assert system_capabilities._fact_ids == {"system_capabilities",
                                             "system_capabilities_enforced"}

# Generated at 2022-06-20 18:51:13.353723
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ Unit test for constructor of class SystemCapabilitiesFactCollector"""
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'

# Generated at 2022-06-20 18:51:13.919462
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:51:24.298655
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: because of the nature of the capabilities file, we can't mock a sample output, as
    # it will contain the capabilities of the current process and test runner
    # instead, we need to mock the module execution and return sample output
    module = MagicMock(spec=AnsibleModule)
    module.get_bin_path.return_value = "/usr/bin/capsh"
    module.run_command.return_value = (0, "Current: =ep \n", "")

    fact_collector = SystemCapabilitiesFactCollector()
    result = fact_collector.collect(module=module)

    assert result['system_capabilities'] == []
    assert result['system_capabilities_enforced'] == "False"


# Generated at 2022-06-20 18:51:26.632645
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                          'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:30.198832
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fields = set(['system_capabilities', 'system_capabilities_enforced'])
    SystemCapabilitiesFactCollector()
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == fields


# Generated at 2022-06-20 18:51:31.548705
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Class: SystemCapabilitiesFactCollector
    Method: collect
    Behavior: expected behavior that the method meets
    """
    pass

# Generated at 2022-06-20 18:51:39.410893
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys

    if sys.version_info.major == 2:
        import mock
        import __builtin__ as builtins

        mock_module = mock.Mock()

# Generated at 2022-06-20 18:51:40.988417
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-20 18:51:42.428560
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj =  SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:47.109451
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test = SystemCapabilitiesFactCollector()
    assert(test)
    assert(test.collect())

# Generated at 2022-06-20 18:51:48.950035
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    o = SystemCapabilitiesFactCollector()
    f = o.collect()
    assert f == {}

# Generated at 2022-06-20 18:51:51.674563
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sc = SystemCapabilitiesFactCollector()
    assert sc.name == 'caps'
    assert sc._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:52:01.434025
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test with capsh missing
    module = Mock()
    module.get_bin_path.return_value = None
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module)
    assert facts_dict == {'system_capabilities': [], 'system_capabilities_enforced': "NA"}

    # Test with capsh present and running as uid 0
    module = Mock()
    module.command_stdout = 'Capabilities for `/bin/sh\nCurrent: =ep\nBounding set =cap_chown,cap_dac_override,cap_setgid,cap_setuid+eip\nSecurebits: 00/0x0/1'
    module.run_command.return_value = (0, module.command_stdout, '')


# Generated at 2022-06-20 18:52:02.465068
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj1 = SystemCapabilitiesFactCollector()
    assert False



# Generated at 2022-06-20 18:52:07.571332
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Tests functionality of 'collect' method of SystemCapabilitiesFactCollector class."""

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system.caps

    # prepare a class to use in testing
    collected_facts = ansible.module_utils.facts.collector.CollectedFacts()
    module = ansible.module_utils.facts.SystemCapabilitiesFactCollector(
        collected_facts)

    # prepare a class instance needed in testing
    mod_instance = ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector()

    # initialize SystemCapabilitiesFactCollector class
    mod_instance.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-20 18:52:08.501720
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-20 18:52:14.425944
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector_instance = SystemCapabilitiesFactCollector()
    fact_ids = fact_collector_instance._fact_ids
    assert len(fact_ids) == 2, "Fact ids should be 2"
    assert 'system_capabilities' in fact_ids, "system_capabilities is not in fact_ids"
    assert 'system_capabilities_enforced' in fact_ids, "system_capabilities_enforced is not in fact_ids"

# Generated at 2022-06-20 18:52:24.836109
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: require test method to end in 'unit' to make them easily
    # distinguishable -akl
    import sys
    import os
    import unittest
    # FIXME: is 'module' imported above used in this method? -akl
    try:
        from ansible.module_utils.ansible_release import __version__ as ansible_version
    except ImportError:
        ansible_version = "2.4.0.0"

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_ids

    return_

# Generated at 2022-06-20 18:52:29.010462
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert collector.collect() == {}


# Generated at 2022-06-20 18:52:36.339231
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Ensure capsh facts are collected properly
    """
    import ansible.module_utils.facts.collector

    collector = ansible.module_utils.facts.collector.get_collector('SystemCapabilitiesFactCollector')
    # NOTE: constructors should be testable via duck typing, i.e. this should work in py2/py3 -akl
    assert isinstance(collector, SystemCapabilitiesFactCollector)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 18:52:39.916673
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE/TODO: Add mocking of module object and caps response
    #           Add test cases with capsh (and other utilities like auditctl) output variations
    #           When mocking module object, make sure you can detect its type and mock
    #           module.run_command() for all supported platforms.
    assert False

# Generated at 2022-06-20 18:52:41.159123
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-20 18:52:44.384295
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:55.889702
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.system.capabilities_linux import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities_linux import _get_caps_data
    import types
    import sys
    import pytest

    class FakeModule:
        @staticmethod
        def get_bin_path(binary):
            if binary == 'capsh':
                return 'capsh'
            else:
                return None

        # HELPERS
        @staticmethod
        def run_command(args, errors='surrogate_then_replace'):
            return 0, 'Current: =ep', []


# Generated at 2022-06-20 18:53:06.744719
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    import os

    path_to_collector = os.path.join(os.path.dirname(__file__), '../', '../', '..', 'ansible', 'module_utils', 'facts', 'collector')
    if not os.path.exists(path_to_collector):
        path_to_collector = os.path.join(os.path.dirname(__file__), '../../')

    if os.path.isdir(path_to_collector) and path_to_collector not in sys.path:
        sys.path.append(path_to_collector)
    from system_capabilities import SystemCapabilitiesFactCollector

    capsh

# Generated at 2022-06-20 18:53:09.144457
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # If a class is instantiated without errors, then I would consider the test successful
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:53:11.029902
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-20 18:53:16.004078
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_collector = SystemCapabilitiesFactCollector()
    assert capsh_collector.name == 'caps'
    assert capsh_collector._fact_ids.issubset(set(['system_capabilities', 'system_capabilities_enforced']))

# Generated at 2022-06-20 18:53:18.389312
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert fact._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:53:34.324981
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test the output of SystemCapabilitiesFactCollector.collect()"""
    import sys
    import io
    import unittest
    import ansible.module_utils.facts.collector
    if sys.version_info[0] > 2:
        from unittest.mock import patch  # Python 3
    else:
        from mock import patch  # Python 2
    try:
        from builtins import open  # Python 3
    except ImportError:
        pass  # Python 2

    class ModuleStub(object):
        """Fake AnsibleModule that stubs out the run_command() method."""

        def __init__(self, *args, **kwargs):  # pylint: disable=bad-mcs-classmethod-argument, unused-argument
            self.params = {}
            self.result = {}

# Generated at 2022-06-20 18:53:38.005156
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:40.323177
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module_mock = None
    collected_facts = None
    sut = SystemCapabilitiesFactCollector()
    assert sut is not None

# Generated at 2022-06-20 18:53:42.920960
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Need to implement this test
    # NOTE: see tests/units/module_utils/facts/collector/test_base.py -akl
    pass

# Generated at 2022-06-20 18:53:45.308892
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    print(fc._fact_ids)
    assert(fc.name == 'caps')


# Generated at 2022-06-20 18:53:50.038395
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert len(sut._fact_ids) == 2
    assert 'system_capabilities' in sut._fact_ids
    assert 'system_capabilities_enforced' in sut._fact_ids


# Generated at 2022-06-20 18:53:54.699872
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}


# Generated at 2022-06-20 18:53:55.692914
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:59.960316
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert hasattr(s, '_fact_ids')
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-20 18:54:02.427838
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert obj.name == 'caps'

# Generated at 2022-06-20 18:54:21.666934
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.system.capabilities import SystemCapabilitiesFactCollector
    import sys
    import collections

    # Initialize a class of type BaseFactCollector
    # but with SystemCapabilitiesFactCollector instead
    # because we want to test SystemCapabilitiesFactCollector
    class TestSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector, BaseFactCollector):
        pass

    # Create an object of type TestSystemCapabilitiesFactCollector
    test_sys_caps_obj = TestSystemCapabilitiesFactCollector()

    # Get the "collect" method of a BaseFactCollector class
    caps_collect_method = getattr(BaseFactCollector, "collect")

    # Create a mock for the module
    mock_module

# Generated at 2022-06-20 18:54:31.692479
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # This method accepts 'module' as param and being a unit test, 
    # we don't have access to module class object directly here.
    # We are monkey-patching module object (class) and its get_bin_path method 
    # to return a valid capsh executable path
    import ansible.module_utils.facts.system.capabilities
    ansible.module_utils.facts.system.capabilities.module.get_bin_path = lambda path: "/bin/capsh"
    collector_obj = SystemCapabilitiesFactCollector()
    mock_ansible_module = object()
    returned_fact_dict = collector_obj.collect(mock_ansible_module)
    assert 'system_capabilities' in returned_fact_dict
    assert 'system_capabilities_enforced' in returned_fact_dict

# Generated at 2022-06-20 18:54:34.582934
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc_instance = SystemCapabilitiesFactCollector()

    assert scfc_instance.name == 'caps'
    assert scfc_instance._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:43.222006
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = type('', (), {})()
    avail_caps = ['cap_net_bind_service',
                  'cap_net_raw',
                  'cap_sys_chroot',
                  'cap_setgid',
                  'cap_dac_read_search',
                  'cap_fowner',
                  'cap_setuid',
                  'cap_sys_admin',
                  'cap_sys_nice',
                  'cap_dac_override',
                  'cap_sys_resource',
                  'cap_setpcap',
                  'cap_sys_ptrace',
                  'cap_audit_write',
                  'cap_mac_admin',
                  'cap_sys_rawio',
                  'cap_linux_immutable',
                  'cap_mknod',
                  'cap_sys_boot']

# Generated at 2022-06-20 18:54:43.968405
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:54:55.301261
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # setup
    class MockInstance:
        def get_bin_path(*args, **kwargs):
            return '/usr/bin/capsh'

        def run_command(*args, **kwargs):
            return 0, """Current: = cap_net_bind_service+ep
Bounding set =cap_chown,cap_dac_override,cap_net_bind_service,cap_setpcap,cap_sys_ptrace,cap_setgid,cap_setuid+p
Securebits: 00/0x0/1'b0 secure-noroot secure-no-suid secure-keep-caps
               """

    class Mock:
        def __init__(self):
            self.module = MockInstance()

    # exercise
    collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:04.991374
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.system.caps

    capsh_path = "/usr/bin/capsh"

# Generated at 2022-06-20 18:55:14.588181
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    '''
    def setUp(self):
        # create a fresh instance of SystemCapabilitiesFactCollector before each test
        self.caps = Collector.init_collector(SystemCapabilitiesFactCollector)
    '''
    # create a fresh instance of SystemCapabilitiesFactCollector before each test
    caps = Collector.init_collector(SystemCapabilitiesFactCollector)
    #caps._fact_ids = 'system_capabilities'
    assert isinstance(caps, SystemCapabilitiesFactCollector)


# Generated at 2022-06-20 18:55:16.766058
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module_name = 'ansible.module_utils.facts.system.caps'
    sut = SystemCapabilitiesFactCollector()
    actual = sut.name
    expected = 'caps'
    assert actual == expected

# Generated at 2022-06-20 18:55:17.348425
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:55:48.521611
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:55:54.619879
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile
    import os
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    import os
    import re
    import shlex
    import subprocess
    import platform
    import sys

    class FakeModule(object):
        def __init__(self):
            self.__success = False
            self.__text = ""

        def get_bin_path(self, name, **kwargs):
            return name

        def run_command(self, args, **kwargs):
            rc = 0
            out = ""
            err = ""

            if self.__success == False:
                rc = 1
                out = ""
                err = "capsh: Error: cannot load the capability computation library\n"

# Generated at 2022-06-20 18:55:56.641916
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class_ = SystemCapabilitiesFactCollector
    assert class_ is not None

# Generated at 2022-06-20 18:56:03.044567
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.facts = {}
        def get_bin_path(self, app):
            return "/bin/capsh"

# Generated at 2022-06-20 18:56:06.664907
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:17.518003
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test check that calling collect()
    on class SystemCapabilitiesFactCollector
    will call collect_capabilities() and
    return a dict

    """
    import mock

    class MockModule(object):
        pass

    with mock.patch('ansible.module_utils.facts.collector.collect_capabilities',
                    return_value=dict(system_capabilities=['some', 'caps'])):
        module = MockModule()
        setattr(module, 'get_bin_path', lambda bin: bin)
        setattr(module, 'run_command', lambda cmd, errors='surrogate_then_replace': (0, 'Current: =ep', ''))
        sys_collector = SystemCapabilitiesFactCollector()
        actual = sys_collector.collect(module=module)

# Generated at 2022-06-20 18:56:19.634346
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    # Test if constructor of class SystemCapabilitiesFactCollector returns an instance of SystemCapabilitiesFactCollector
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-20 18:56:23.901808
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == "caps"
    assert facts.collect_fn == facts.collect
    assert facts._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:56:27.668318
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])


# Generated at 2022-06-20 18:56:30.126300
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:34.476448
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == "caps"
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:35.033943
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:57:37.285263
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:40.689471
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mySystemCapabilities = SystemCapabilitiesFactCollector()
    test_module = None
    test_facts = None
    expected_result = {'system_capabilities_enforced': 'NA', 'system_capabilities': []}
    result = mySystemCapabilities.collect(test_module, test_facts)
    assert result == expected_result

# Generated at 2022-06-20 18:57:43.888045
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh = SystemCapabilitiesFactCollector()
    assert capsh.name == "caps"
    assert capsh._fact_ids == {'system_capabilities_enforced', 'system_capabilities'}

# Generated at 2022-06-20 18:57:51.306018
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.system_capabilities
    # TODO add tests for SystemCapabilitiesFactCollector.get_caps_data() and SystemCapabilitiesFactCollector.parse_caps_data()
    from ansible.module_utils.facts.collector import AnsibleCollector
    ac = AnsibleCollector()
    ac.add_collection(ansible.module_utils.facts.system.system_capabilities.SystemCapabilitiesFactCollector())
    ac.populate()
    assert ('system_capabilities' in ac.facts)
    assert ('system_capabilities_enforced' in ac.facts)

# Generated at 2022-06-20 18:57:54.920092
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    main_obj = SystemCapabilitiesFactCollector()
    print("Facts names:", main_obj.name)
    print("Facts ids:", main_obj._fact_ids)

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:58:04.648422
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class ModuleMock(object):
        def __init__(self, rc, out, err, bin_path):
            self.rc = rc
            self.out = out
            self.err = err
            self.bin_path = bin_path

        def get_bin_path(self, path):
            return self.bin_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (self.rc, self.out, self.err)

    # NOTE: Capsh installed and successful run
    rc1, out1, err1 = 0, "Current: =ep\n", ""
    mod1 = ModuleMock(rc1, out1, err1, '/some/path/capsh')
    res1 = SystemCapabilitiesFactCollector().collect(module=mod1)

# Generated at 2022-06-20 18:58:06.624408
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:58:08.679758
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector.collect(None) == {}

# Generated at 2022-06-20 19:00:13.835750
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 19:00:17.996025
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    out = c.collect()
    assert "system_capabilities" in out
    assert "system_capabilities_enforced" in out

# Generated at 2022-06-20 19:00:25.768432
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub

    def mock_get_bin_path(name, opt_dirs=[]):
        if name == 'capsh':
            return '/bin/capsh'

    def mock_run_command(cmd, **kwargs):
        if cmd[0] == '/bin/capsh':
            return 0, FakeCapsOutput.CAPSH_WITH_EFFECTS, ''

    module = AnsibleModuleStub(
        get_bin_path=mock_get_bin_path,
        run_command=mock_run_command,
        check_mode=True
    )

    collector = SystemCapabilitiesFactCollector()
    collector.collect(module)
    assert module.exit_json.call_count == 1

# Generated at 2022-06-20 19:00:27.162369
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    the_test = SystemCapabilitiesFactCollector()
    assert the_test.name == 'caps'

# Generated at 2022-06-20 19:00:28.434056
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    factCollector = SystemCapabilitiesFactCollector()
    assert factCollector.name == 'caps'

# Generated at 2022-06-20 19:00:29.879121
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj is not None

# Generated at 2022-06-20 19:00:35.111202
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:41.706857
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = lambda: None
    mock_module.get_bin_path = lambda x: "/bin/capsh"
    mock_module.run_command = lambda x, **kwargs: (0, 'Current: =ep', '')
    ar = SystemCapabilitiesFactCollector()
    assert ar.collect(mock_module) == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-20 19:00:47.813197
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    result = collector.collect() 
    #assert len(result) == 2
    #assert result['system_capabilities'] == []
    #assert result['system_capabilities_enforced'] == 'NA'

# Generated at 2022-06-20 19:00:56.654424
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_collected_facts = {'system_capabilities': ['CAP_CHOWN', 'CAP_DAC_OVERRIDE', 'CAP_FSETID', 'CAP_FOWNER', 'CAP_MKNOD', 'CAP_NET_RAW', 'CAP_SETGID', 'CAP_SETUID', 'CAP_SETFCAP', 'CAP_SETPCAP', 'CAP_NET_BIND_SERVICE', 'CAP_SYS_CHROOT', 'CAP_KILL'], 'system_capabilities_enforced': 'True'}