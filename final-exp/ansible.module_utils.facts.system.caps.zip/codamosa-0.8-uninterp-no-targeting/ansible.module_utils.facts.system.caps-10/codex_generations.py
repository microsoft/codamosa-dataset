

# Generated at 2022-06-20 18:51:14.589405
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_text
    import os

    module = None
    my_obj = SystemCapabilitiesFactCollector(module)
    my_obj.collect()

    result = my_obj.collect()
    assert 'system_capabilities_enforced' in result
    assert 'system_capabilities' in result
    assert result['system_capabilities'] == []
    assert result['system_capabilities_enforced'] == 'NA'



# Generated at 2022-06-20 18:51:25.788676
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Note: This is using the SystemCapabilitiesFactCollector for testing,
    #       since it does not require any package installations.
    from ansible.module_utils.facts import collector

    facts_dict = {}

# Generated at 2022-06-20 18:51:34.580517
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class TestModule(object):
        def __init__(self, result):
            self.result = result
        def get_bin_path(self, *args, **kwargs):
            return self.result
        def run_command(self, *args, **kwargs):
            return self.result
    
    testobj = SystemCapabilitiesFactCollector()
    # Constructor
    assert testobj.name == 'caps'
    assert testobj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    
    # collect()
    # no module argument
    assert testobj.collect() == {}
    # capsh_path is None
    testobj.module = TestModule(None)
    assert testobj.collect() == {}
    # rc != 0

# Generated at 2022-06-20 18:51:41.260484
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleUtilsLegacyFactCollector
    module = ModuleUtilsLegacyFactCollector()
    module.get_bin_path = lambda x: '/sbin/capsh'
    module.run_command = lambda x: (1, 'Current: = cap_setpcap+eip cap_setfcap+eip\nBounding set =cap_chown+eip cap_dac_override+eip', '')
    assert 'system_capabilities' in SystemCapabilitiesFactCollector().collect(module)
    assert SystemCapabilitiesFactCollector().collect(module)['system_capabilities'] == ['cap_chown', 'cap_dac_override']
    module.run_command = lambda x: (1, 'Current: =ep', '')

# Generated at 2022-06-20 18:51:43.436396
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Constructor of class SystemCapabilitiesFactCollector
    """
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-20 18:51:53.281016
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    fact_collector = SystemCapabilitiesFactCollector()
    fake_module = BaseFactCollector()

# Generated at 2022-06-20 18:51:58.027970
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Constructor for class SystemCapabilitiesFactCollector
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

    # Function collect of class SystemCapabilitiesFactCollector
    assert c.collect() == {}

# Generated at 2022-06-20 18:51:58.605840
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:00.202169
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        SystemCapabilitiesFactCollector()
    except:
        assert False



# Generated at 2022-06-20 18:52:04.397069
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import  BaseFactCollector

    capsh_path = "test/test_module.py"
    test_method = False
    class_obj = None
    class_obj = SystemCapabilitiesFactCollector()
    if class_obj:
        class_obj = SystemCapabilitiesFactCollector(capsh_path)
        if class_obj:
            test_method = True
    assert test_method

# Generated at 2022-06-20 18:52:16.641496
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 18:52:20.153254
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SUT = SystemCapabilitiesFactCollector()
    assert SUT.name == 'caps'
    assert SUT._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])



# Generated at 2022-06-20 18:52:24.830156
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # NOTE: FactCollector.collect_only() -> FactCollector().collect() -akl
    facts = FactCollector().collect()


if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-20 18:52:33.590052
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import sys

    module = mock.MagicMock()
    module.get_bin_path.return_value = 'capsh'
    module.run_command.return_value = 0, 'Current: =ep', ''
    sys.modules['_module'] = module

    from ansible.module_utils.facts.collectors.system.caps import SystemCapabilitiesFactCollector
    fact_collector = SystemCapabilitiesFactCollector()
    enforce_capabilities_data = fact_collector.collect()

    if enforce_capabilities_data['system_capabilities_enforced'] == 'False':
        print("enforce_capabilities_data['system_capabilities_enforced'] is False")
    else:
        raise Exception('enforce_capabilities_data["system_capabilities_enforced"] is not False')

    module

# Generated at 2022-06-20 18:52:38.023390
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:39.644311
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:52:42.128325
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: these assertions need to be fleshed out -akl
    module_mock = Mock()
    facts_dict = SystemCapabilitiesFactCollector().collect(module=module_mock)
    assert True

# Generated at 2022-06-20 18:52:52.681246
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import imp
    import sys
    import os
    import tempfile
    # Below maybe needed if not called from ansible-test or ansible-playbook.
    # sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "utils"))
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.collectors import get_collector_class
    from ansible.module_utils.facts.collector import Collector

    ########################################################################
    # We create a temporary file system, to simulate a scenario, where capsh
    # is not available, ie. /usr/bin/capsh does not exist.
    ########################################################################
    # Create a temporary directory to serve as the root for our temporary file
    # system

# Generated at 2022-06-20 18:52:57.177334
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_module = MockFactModule()
    fact = SystemCapabilitiesFactCollector()
    assert fact.collect(fact_module) == {'system_capabilities': ['cap_setuid+ep', 'cap_setgid+ep'], 'system_capabilities_enforced': 'True'}

# Generated at 2022-06-20 18:53:07.870289
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class MockModule():
        def __init__(self):
            self.run_command = ['capsh', '--print']

        def get_bin_path(self, command):
            return '/bin/' + command

    module = MockModule()

# Generated at 2022-06-20 18:53:20.652962
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import itertools
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.caps
    import os
    import stat
    import unittest


# Generated at 2022-06-20 18:53:30.585061
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    import sys
    import os

    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector, FactCache
    from ansible.module_utils._text import to_bytes, to_text
    
    sys.modules['ansible.module_utils.facts.collector'] = ansible.module_utils.facts.collector
    sys.modules['ansible.module_utils.facts.collector.BaseFactCollector'] = BaseFactCollector
    sys.modules['ansible.module_utils.facts.collector.Collector'] = Collector

# Generated at 2022-06-20 18:53:34.200724
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:44.348770
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import ansible_runner
    from ansible.module_utils.facts.collector import collect_subset

    class FakeModule(object):
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, binary):
            return binary


# Generated at 2022-06-20 18:53:49.043685
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert capabilities_fact_collector.name == 'caps'
    assert capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                         'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:55.049693
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    unit test for constructor of SystemCapabilitiesFactCollector
    '''
    cap = SystemCapabilitiesFactCollector()

    assert isinstance(cap, BaseFactCollector)
    assert cap.name == 'caps'
    assert isinstance(cap._fact_ids, set)
    assert 'system_capabilities' in cap._fact_ids
    assert 'system_capabilities_enforced' in cap._fact_ids

# Generated at 2022-06-20 18:54:01.213007
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Constructor for SystemCapabilitiesFactCollector
    """
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps', "Wrong name, expected 'caps'"
    assert fact._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']), \
        "Wrong ids, expected set('system_capabilities', 'system_capabilities_enforced')"

# Generated at 2022-06-20 18:54:03.276911
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector.__new__(SystemCapabilitiesFactCollector)
    assert result.name == 'caps'

# Generated at 2022-06-20 18:54:04.493945
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    o = SystemCapabilitiesFactCollector()
    assert o.name == 'caps'
    assert o.collect() == {}

# Generated at 2022-06-20 18:54:07.835040
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:21.533662
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_text

    test_module = DummyAnsibleModule()
    test_module.params = dict()
    test_module.run_command = run_command

    facts_collector = FactsCollector(DummyModuleManager(), test_module)
    system_capabilities_fact_collector = facts_collector.collectors['system_capabilities']

    test_module.get_bin_path = get_bin_path
    result = system_capabilities_fact_collector.collect()

    assert 'system_capabilities' in result
    assert result['system_capabilities'] == []
    assert 'system_capabilities_enforced' in result

# Generated at 2022-06-20 18:54:31.611728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    
    import ansible_collections.ansible.builtin.plugins.module_utils as module_utils
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.collector as collector
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.system.caps as caps
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.system.system as system
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.utils as utils
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.system.distribution as distribution
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.system.platform as platform
    import ansible_col

# Generated at 2022-06-20 18:54:39.868021
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def mock_run_command(cmd, errors='surrogate_then_replace'):
        # NOTE: the first part of the return value for mock_run_command is
        # the return code, the second is the stdout, and the third is the
        # stderr.  I've added a bunch of newlines and whitespace to make
        # the tests more readable.
        if 'capsh' in cmd and '--print' in cmd:
            return 0, capsh_resp, ''
        else:
            return 1, '', ''

    def mock_get_bin_path(binary):
        if binary == 'capsh':
            return 'capsh'
        else:
            return None


# Generated at 2022-06-20 18:54:43.645463
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_input = {'get_bin_path' : lambda x: None}
    assert SystemCapabilitiesFactCollector(None).collect(test_input) == {'system_capabilities':[], 'system_capabilities_enforced': 'NA'}


# Generated at 2022-06-20 18:54:47.626519
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-20 18:54:53.150911
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])



# Generated at 2022-06-20 18:55:03.469651
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Stub/Mock command module dependency -akl
    class MockCommandModule:
        def __init__(self):
            pass

        def get_bin_path(self, tool_name, required=False):
            if tool_name == 'capsh':
                return '/usr/bin/capsh'


# Generated at 2022-06-20 18:55:11.658020
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    module.run_command.return_value = (0, 'Current: =ep', '')
    capsh_path = module.get_bin_path.return_value = 'capsh'
    sut = SystemCapabilitiesFactCollector()
    actual = sut.collect(module)
    assert actual == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 18:55:14.435632
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:55:20.351685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Unit test for method collect of class SystemCapabilitiesFactCollector"""
    class MockModule():
        def __init__(self, return_value, return_code=0):
            self.return_value = return_value
            self.return_code = return_code
        def get_bin_path(self, cmd):
            return cmd
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return self.return_code, self.return_value, ""


# Generated at 2022-06-20 18:55:40.161684
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class MockModule(object):
        def __init__(self):
            self.run_command = 'capsh'
            self.exit_json = True
            self.bin_path = '/usr/bin/'
            self.check_mode = False
            self.warnings = []
            self.deprecations = []

        def get_bin_path(self, cmd, required=False):
            return self.bin_path

    module = MockModule()
    capsh = SystemCapabilitiesFactCollector(module)
    assert capsh._fact_ids == set(['system_capabilities',
                                   'system_capabilities_enforced'])
    assert capsh.name == 'caps'

# Generated at 2022-06-20 18:55:43.006040
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector

    b = SystemCapabilitiesFactCollector()
    assert {} == b.collect()

# Generated at 2022-06-20 18:55:46.165542
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c1 = SystemCapabilitiesFactCollector()
    assert c1.name == 'caps'
    assert 'system_capabilities' in c1._fact_ids
    assert 'system_capabilities_enforced' in c1._fact_ids

# Generated at 2022-06-20 18:55:50.782272
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

    system_caps = SystemCapabilitiesFactCollector()
    assert system_caps.name == 'caps'
    assert system_caps._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])



# Generated at 2022-06-20 18:55:59.672574
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockAnsibleModule()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        output = '''Capabilities for `/bin/uname': = cap_chown,cap_net_admin,cap_setgid+ep
Bounding set =cap_chown,cap_net_admin,cap_setgid
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root)
Current: = cap_chown,cap_net_admin,cap_setgid+eip'''

# Generated at 2022-06-20 18:56:10.234978
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import RelativePathFinder
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import ansible.module_utils.facts.system.caps as caps
    import sys
    import json
    import os


# Generated at 2022-06-20 18:56:18.215457
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system import set_capsh_path, get_caps_data, parse_caps_data
    collector.__init__('vagrant_dev_box')
    set_capsh_path('/usr/bin/capsh')
    SystemCapabilitiesFactCollector._fact_ids = set(['system_capabilities',
                     'system_capabilities_enforced'])
    print(SystemCapabilitiesFactCollector().collect())

# Generated at 2022-06-20 18:56:20.188999
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use mock module, 'ansible_module', and mock the run_command() method -akl
    pass

# Generated at 2022-06-20 18:56:21.165881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:56:32.489399
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    helper = SystemCapabilitiesFactCollector()
    mydict = {'capsh':'/bin/capsh'}
    out = 'Current: =ep\n'
    err = ''
    rc = 0
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = mydict['capsh']
    module_mock.run_command.return_value = (rc, out, err)
    result = helper.collect(module=module_mock)
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []
    # ... repeat with 'enforced' ...

# Generated at 2022-06-20 18:57:08.193985
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    SystemCapabilitiesFactCollector._fact_ids = set(['system_capabilities',
                                                     'system_capabilities_enforced'])
    SystemCapabilitiesFactCollector.collect()

# Generated at 2022-06-20 18:57:16.872560
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    Unit test for method collect of class SystemCapabilitiesFactCollector
    '''
    # pylint: disable=W0212
    dut = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in dut._fact_ids
    assert 'system_capabilities_enforced' in dut._fact_ids
    assert dut.get_fact_names() == {'capsh_path', 'system_capabilities', 'system_capabilities_enforced'}
    assert dut.get_facts_interface() == 'default'
    assert not dut.collect()
    assert not dut.collect(module=None)

# Generated at 2022-06-20 18:57:21.945643
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Returns a dictionary containing facts about system capabilities

    :returns: A dictionary containing facts about system capabilities
    """
    from ansible_collections.community.general.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.community.general.plugins.modules.system import capsh

    # If there is no capsh installed on the system, we return the necessary info to run capsh (if available) or fail and skip
    def run_command_mock(args, **kwargs):
        return 0, "Current: =ep", ""

    # If there is no capsh installed on the system, we return the necessary info to run capsh (if available) or fail and skip

# Generated at 2022-06-20 18:57:31.845992
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create and initialize fact collector object
    collector = SystemCapabilitiesFactCollector()
    module = mock.MagicMock()
    module.get_bin_path.return_value = "/bin/capsh"

    # Setup return values for module.run_command
    rc = 0

# Generated at 2022-06-20 18:57:39.779359
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    capsh_path = 'capsh_path'
    command_result = (0, 'Current: = cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip', '')

    def run_command_mock(cmd, **kwargs):
        if cmd[0] == capsh_path:
            return command_result
        return (1, '', '')


# Generated at 2022-06-20 18:57:49.396665
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.system_capabilities.facts_module import SystemCapabilitiesFactCollector
    from ansible.utils.display import Display
    # import pdb; pdb.set_trace()
    module = sys.modules[__name__]

    module.Display = Display


# Generated at 2022-06-20 18:57:58.225728
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Instantiate a mock module and mock results of module.run_command('capsh')
    class MockModule(object):
        def __init__(self):
            self.bin_path_value = '/bin/capsh'

        def get_bin_path(self, bin_path):
            return self.bin_path_value


# Generated at 2022-06-20 18:58:06.733212
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import tempfile
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_collector_class
    from ansible.module_utils.facts.collectors.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collectors.filesystem import FilesystemCollector
    from ansible.module_utils.facts.collectors.pkg_mgr import PackageManagerCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts.collectors.posix.distribution import DistributionCollector

# Generated at 2022-06-20 18:58:09.627100
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    coll = SystemCapabilitiesFactCollector()
    assert coll._fact_ids == set(['system_capabilities',
                                  'system_capabilities_enforced'])

# Generated at 2022-06-20 18:58:18.314698
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )


# Generated at 2022-06-20 18:59:22.051951
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    f = FactsCollector()
    f.collectors = [SystemCapabilitiesFactCollector()]
    assert isinstance(f.collectors[0], SystemCapabilitiesFactCollector)

# Generated at 2022-06-20 18:59:33.439973
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = ansible.module_utils.facts.module_provisioner.ModuleProvisioner({}, [])
    m.run_command = lambda x: (0, 'Current: =ep', '')
    facts = SystemCapabilitiesFactCollector().collect(module=m)
    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []

    m.run_command = lambda x: (0, 'Current: cap_sys_admin=ep cap_dac_override=ep', '')
    facts = SystemCapabilitiesFactCollector().collect(module=m)
    assert facts['system_capabilities_enforced'] == 'True'
    assert facts['system_capabilities'] == ['cap_sys_admin', 'cap_dac_override']

# Generated at 2022-06-20 18:59:43.583958
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module_mock = Mock()

# Generated at 2022-06-20 18:59:48.988418
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector()
    assert result.name == 'caps'
    assert result._fact_ids == set(['system_capabilities',  'system_capabilities_enforced'])
    assert result.collect() == {}


# Generated at 2022-06-20 18:59:59.052169
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    system_capabilities_enforced = 'False'
    system_capabilities = []
    returned_json = {'current': '= cap_chown,cap_dac_override+ep', 'bounding': '= cap_chown,cap_dac_override', 'effective': '= cap_chown,cap_dac_override', 'inheritable': '= cap_chown,cap_dac_override', 'permitted': '= cap_chown,cap_dac_override', 'status': 0}
    module = {'get_bin_path': lambda x: x, 'run_command': lambda x, y: (0, returned_json, '')}
    systemCapCollector = SystemCapabilitiesFactCollector()
    output = systemCapCollector.collect(module)

# Generated at 2022-06-20 19:00:01.548619
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap = SystemCapabilitiesFactCollector()
    assert cap.name == 'caps'


# Generated at 2022-06-20 19:00:04.884958
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: since capsh is not available, test this with 'bin/python' -akl
    scfc = SystemCapabilitiesFactCollector()
    assert scfc is not None

# Generated at 2022-06-20 19:00:08.688902
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    f = SystemCapabilitiesFactCollector()
    assert f.name == 'caps'
    assert f._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:21.250714
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector
    """
    # Build mock module
    def get_bin_path_side_effect(app):
        return '/usr/bin/' + app

# Generated at 2022-06-20 19:00:28.350551
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Dummy module reference used for testing
    class DummyModule():
        def __init__(self, result_dict):
            self.result_dict = result_dict

        def get_bin_path(self, item):
            return self.result_dict[item]

        def run_command(self, args, errors=None):
            return self.result_dict[args[0]]

    # Create instance of class SystemCapabilitiesFactCollector
    scfc = SystemCapabilitiesFactCollector()

    # run test with capsh present, standard caps