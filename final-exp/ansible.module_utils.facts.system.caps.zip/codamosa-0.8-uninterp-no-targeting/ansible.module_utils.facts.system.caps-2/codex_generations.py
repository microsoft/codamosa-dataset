

# Generated at 2022-06-20 18:51:10.257087
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:11.939159
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-20 18:51:18.161861
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class SystemCapabilitiesFactCollectorTest(SystemCapabilitiesFactCollector):
        name = 'caps'
        _fact_ids = set(['system_capabilities',
                         'system_capabilities_enforced'])

    class Module(object):
        def __init__(self):
            self.run_command = self._run_command
            self.get_bin_path = self._get_bin_path

        def _get_bin_path(self, name):
            if name == 'capsh':
                path = '/bin/capsh'
            return path

        def _run_command(self, args, errors):
            if args[0] == '/bin/capsh':
                rc = 0

# Generated at 2022-06-20 18:51:28.624382
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import strip_dir_prefix
    from ansible.module_utils._text import to_native
    import os

    class AnsibleModuleMock:

        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'capsh':
                return 'capsh'
            else:
                return None

        def run_command(self, args, errors='surrogate_then_replace'):
            rc = 0
            out = err = ''

# Generated at 2022-06-20 18:51:29.842499
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    factcollector = SystemCapabilitiesFactCollector()
    assert factcollector.name == 'caps'


# Generated at 2022-06-20 18:51:33.049638
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test class SystemCapabilitiesFactCollector"""

    # Get SystemCapabilitiesFactCollector object
    collect_obj = SystemCapabilitiesFactCollector()

    # Assert name and fact_ids class variables
    assert collect_obj.name == 'caps'
    assert collect_obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}



# Generated at 2022-06-20 18:51:34.219517
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'

# Generated at 2022-06-20 18:51:35.054929
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:51:35.445187
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:51:36.018594
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:51:41.739750
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert isinstance(SystemCapabilitiesFactCollector._fact_ids, set)

# Generated at 2022-06-20 18:51:42.358457
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 18:51:52.361566
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    module = FactsCollector()
    module.get_bin_path = lambda x: '/bin/true'
    module.run_command = lambda x, **kwargs: (0, 'Current:  =ep', '')
    collector = SystemCapabilitiesFactCollector()
    collector.collect(module)
    assert collector.collect(module) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}
    module.run_command = lambda x, **kwargs: (0, 'Current:  =ep cap_sys_admin,cap_sys_boot', '')
    collector = SystemCapabilitiesFactCollector()
    collector.collect(module)

# Generated at 2022-06-20 18:52:01.473166
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    module.params.update(
        {
            'caps': {
                'system_capabilities': ['foo', 'bar', 'baz'],
                'system_capabilities_enforced': 'True'
            }
        }
    )

    m_path = Mock()
    m_path.capsh_path = 'capsh'
    m_module = Mock()
    m_module.get_bin_path = m_path.get_bin_path
    m_module.run_command = Mock()
    m_module.run_command.return_value = (0, '', '')

    sys = SystemCapabilitiesFactCollector()

    assert sys.collect(m_module) == module.params['caps']

# Generated at 2022-06-20 18:52:03.816010
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:09.230694
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    expected_system_capabilities = ['system_capabilities_enforced', 'system_capabilities']
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(expected_system_capabilities)

# Generated at 2022-06-20 18:52:13.297707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fakeFactModule = FakeFactModule()
    cap_collector = SystemCapabilitiesFactCollector()
    result = cap_collector.collect(module=fakeFactModule)
    for key in ['system_capabilities', 'system_capabilities_enforced']:
        assert key in result


# Generated at 2022-06-20 18:52:21.004317
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockCommand
    from ansible.module_utils.facts.collector import AnsibleExitJson
    from ansible.module_utils.facts.collector import AnsibleFailJson

    # initialize MockModule
    mm = MockModule(
        CAPSH_PATH_0 = '/usr/bin/capsh',
        CAPSH_PATH_1 = '/usr/sbin/capsh',
        CAPSH_PATH_NONE = None,
        CAPSH_PATH_EXEC = None,
    )

    # command succeeds

# Generated at 2022-06-20 18:52:30.870012
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: uses 'mock' module

    # NOTE: use mock objects (instead of 'mock' module;
    # when testing method which uses module 'ansible.module_utils.basic'
    class ModuleMock:
        def __init__(self):
            self.run_command_rc = 0

# Generated at 2022-06-20 18:52:33.552884
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()

    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])



# Generated at 2022-06-20 18:52:42.012040
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None

    caps_collector = SystemCapabilitiesFactCollector()
    facts_dict = caps_collector.collect(module)

    assert facts_dict['system_capabilities_enforced'] == 'NA'
    assert facts_dict['system_capabilities'] == []

# Generated at 2022-06-20 18:52:45.251741
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:52.111744
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector(None)
    output = fact_collector.collect()
    print(output)
    assert output == {'system_capabilities': ['cap_chown', 'cap_dac_override', 'cap_setgid', 'cap_setuid', 'cap_fowner', 'cap_fsetid', 'cap_net_bind_service', 'cap_sys_chroot'], 'system_capabilities_enforced': 'True'}

# Generated at 2022-06-20 18:53:03.716223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Note: This test is kinda of hard to mock because of the BaseFactCollector.__call__
# method that is used to execute the module.  This test is not executed on TravisCI
# and needs to be executed locally
# def test_SystemCapabilitiesFactCollector_collect():
#     # Mocked inputs
#     module = mock.MagicMock()
#     module.get_bin_path.return_value = '/bin/capsh'
#     module.run_command.return_value = (0, 'Current: =ep', '')
#
#     # Expected output
#     expected_out = {
#         'system_

# Generated at 2022-06-20 18:53:05.847304
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    
    # Build class instance
    result = SystemCapabilitiesFactCollector()
    # Check expected results
    assert result.name == 'caps'

# Generated at 2022-06-20 18:53:06.827525
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:53:17.290154
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import platform
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    capsh_path = os.path.join(os.path.dirname(__file__), '../../../test/units/module_utils/capsh_out')
    obj = SystemCapabilitiesFactCollector({'capsh_path': {'path': capsh_path}})
    assert isinstance(obj, BaseFactCollector)

    obj = SystemCapabilitiesFactCollector({'capsh_path': {'path': ''}})
    assert isinstance(obj, BaseFactCollector)

    assert obj.name == 'caps'


# Generated at 2022-06-20 18:53:23.011282
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class obj(object):
        def __init__(self, name, path_type='path'):
            self.name = name
            self.path_type = path_type

        def get_bin_path(self, name, opt_dirs=[]):
            expected_name = 'capsh'
            if name != expected_name:
                raise AssertionError('Unexpected program name {}.  Expected {}'.format(name, expected_name))
            path = '/usr/bin/capsh'
            return path

    module = obj('capsh')
    collected_facts = {}
    x = SystemCapabilitiesFactCollector()
    actual_caps = x.collect(module=module, collected_facts=collected_facts)


# Generated at 2022-06-20 18:53:25.009380
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert isinstance(x, SystemCapabilitiesFactCollector)
    assert isinstance(x.name, str)

# Generated at 2022-06-20 18:53:35.462255
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    # NOTE: provide mocked run_command()
    # -> assert run_command(), out, err -> enforce, enforced_caps
    # -> assert facts_dict
    # NOTE: mock get_bin_path()
    # -> assert no path -> facts_dict == {}
    # -> assert path -> return run_command(), out, err
    m_get_bin_path = None
    m_run_command = None
    m_capsh_path = None
    m_enforced = None
    m_enforced_caps = None
    m_out = None
    m_err = None
    m_rc = 0

    # test no path -> facts_dict == {}
    m_get_bin_path.return_value = None
    caps_collector = SystemCapabilitiesFactCollector(module)
    assert caps_collect

# Generated at 2022-06-20 18:53:58.673377
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Test if the collect method of SystemCapabilitiesFactCollector works as expected '''
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts import comparator
    from ansible.module_utils.facts.collector import get_collector

    test_module = TestModule(module_name="ansible.module_utils.facts.collector.caps.SystemCapabilitiesFactCollector")
    test_module.run_command = fake_run_command
    test_module.get_bin_path = fake_get_bin_path
    SystemCapabilitiesFactCollector.__bases__ = (BaseFactCollector,)
    TestSystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

    # Test with none
    TestSystemCapabilitiesFactCollector.collect(test_module, {})

# Generated at 2022-06-20 18:54:02.956654
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert 'caps' in SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-20 18:54:04.383059
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj == obj


# Generated at 2022-06-20 18:54:05.800612
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_collector = SystemCapabilitiesFactCollector()
    assert facts_collector.name == 'caps'

# Generated at 2022-06-20 18:54:10.977215
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import Collector

    Collector.add_collector(SystemCapabilitiesFactCollector())
    my_caps = Collector.get_collector('caps')

    assert my_caps.name == 'caps'
    assert 'system_capabilities' in my_caps._fact_ids
    assert 'system_capabilities_enforced' in my_caps._fact_ids

# Generated at 2022-06-20 18:54:19.919779
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    capsh_path = "/usr/bin/capsh"

    class MockAnsibleModule:

        def get_bin_path(self, name):
            return capsh_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            rc = 0
            out = 'Current: = =ep\n\
     CapInh: 00000000a80425fb\n\
     CapPrm: 00000000a80425fb\n\
     CapEff: 00000000a80425fb\n\
     CapBnd: 00000000a80425fb\n\
 CapAmb: 0000000000000000'
            err = ''
            return rc, out, err

    class MockFacts:
        system_capabilities = None
        system_capabilities_enforced = None
        def __init__(self):
            self.system

# Generated at 2022-06-20 18:54:23.279226
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert 'system_capabilities' in obj._fact_ids
    assert 'system_capabilities_enforced' in obj._fact_ids


# Generated at 2022-06-20 18:54:30.200883
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_facts
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    import pytest

    caps_collector = SystemCapabilitiesFactCollector()
    caps_collector.collect(ansible_collected_facts)

    print(ansible_collected_facts)
    assert 'system_capabilities' in ansible_collected_facts
    assert 'system_capabilities_enforced' in ansible_collected_facts

# Generated at 2022-06-20 18:54:32.568584
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:40.674187
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.modules.system.capabilities import capsh_parse
    from ansible.module_utils.facts.utils.capabilities import get_capsh_path, get_caps_data, parse_caps_data

    o = SystemCapabilitiesFactCollector()
    assert o.name == 'caps'
    assert o._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

    assert isinstance(o, BaseFactCollector)
    assert o.name == 'caps'
    assert o._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

    assert get_capsh_path() == '/usr/bin/capsh'

# Generated at 2022-06-20 18:55:08.051850
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test for SystemCapabilitiesFactCollector.collect()
    """
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    col = SystemCapabilitiesFactCollector()
    # TODO: add some test data
    assert col.collect()


# Generated at 2022-06-20 18:55:12.347532
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])


# Generated at 2022-06-20 18:55:15.048796
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test constructor of SystemCapabilitiesFactCollector"""
    testobj = SystemCapabilitiesFactCollector()
    assert hasattr(testobj, '_fact_ids')
    assert hasattr(testobj, 'name')

# Generated at 2022-06-20 18:55:16.827572
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-20 18:55:18.994897
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    a = SystemCapabilitiesFactCollector()
    assert a.name == 'caps'
    assert not a.get_facts()

# Generated at 2022-06-20 18:55:21.198223
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
        facts_dict = SystemCapabilitiesFactCollector()
        assert facts_dict.name == 'caps'

# Generated at 2022-06-20 18:55:21.742015
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:55:23.419659
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'


# Generated at 2022-06-20 18:55:26.933008
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()

    # Ensure class attribute names exist
    assert fact.name
    assert fact._fact_ids

    # Ensure class attribute types are correct
    assert isinstance(fact.name, str)
    assert isinstance(fact._fact_ids, set)

# Generated at 2022-06-20 18:55:27.534696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert False

# Generated at 2022-06-20 18:56:23.583581
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sc = SystemCapabilitiesFactCollector()
    assert sc.name == 'caps'
    assert sc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:27.008706
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:36.182218
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # mock setup
    #   3 shell commands
    #   -> 3 mocked results
    result_cmd_1 = dict(rc=0, out="", err="")
    result_cmd_2 = dict(rc=0, out="", err="")
    result_cmd_3 = dict(rc=0, out="Current: =ep", err="")
    m = mock_module_helper()
    m.run_command.side_effect = [result_cmd_1, result_cmd_2, result_cmd_3]

    # run SystemCapabilitiesFactCollector.collect()
    result = SystemCapabilitiesFactCollector(m).collect()

    # test result of SystemCapabilitiesFactCollector.collect()
    assert result == dict(
        system_capabilities=list(),
        system_capabilities_enforced="False",
    )

# Generated at 2022-06-20 18:56:43.489320
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # NOTE: class members for easier mocking -akl
    #
    # mocked name
    _name = 'caps'
    # mocked fact_ids
    _fact_ids = set(['system_capabilities',
                     'system_capabilities_enforced'])

    # NOTE: create mock objects for all parameters of the collect method
    #
    # mock module argument
    module = MockModule()
    # set bin_path
    module.bin_path_cache = {'capsh': '/bin/capsh', 'capsh2': '/bin/capsh2'}
    # mock run_command method
    module.run_command = _mocked_run_command

    # NOTE: class instance for easy access to it's members -akl
    caps_cls = SystemCapabilitiesFactCollector()

    # NOTE: mock collect_facts method


# Generated at 2022-06-20 18:56:48.175686
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Constructor Test
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:53.417361
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_collector = SystemCapabilitiesFactCollector()
    collected_facts = {}

    class MockModule:
        @staticmethod
        def get_bin_path(binary):
            return "/bin/capsh"

        @staticmethod
        def run_command(cmd, errors):
            if cmd == ['/bin/capsh', "--print"]:
                return 0, 'Current: =ep\nBounding set =cap_chown,cap_dac_override,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap', ''
            else:
                return 0, '', ''


# Generated at 2022-06-20 18:56:56.026266
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert 'caps' == s.name
    assert set(['system_capabilities', 'system_capabilities_enforced']) == s._fact_ids

# Generated at 2022-06-20 18:56:59.455009
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test class constructor"""

    # Call constructor
    obj = SystemCapabilitiesFactCollector()

    # Check attributes
    assert obj.name == "caps"
    assert obj._fact_ids == {"system_capabilities", "system_capabilities_enforced"}



# Generated at 2022-06-20 18:57:02.994195
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities',
                                   'system_capabilities_enforced'}
    assert hasattr(collector, 'collect')

# Generated at 2022-06-20 18:57:12.712948
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.run_command_return_value = (0, 'Current: =ep', '')

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/capsh'

        def run_command(self, *args, **kwargs):
            return self.run_command_return_value

    class MockFacts:
        pass

    mock_module = MockModule()
    mock_facts = MockFacts()
    sys_caps_collector = SystemCapabilitiesFactCollector()
    facts_dict = sys_caps_collector.collect(mock_module, mock_facts)

    # Make sure that 'facts_dict' is populated
    assert len(facts_dict) > 0


# Generated at 2022-06-20 18:59:19.507596
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:59:24.563155
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = mock()
    m.get_bin_path = lambda x: '/bin/capsh'
    m.run_command.return_value = 0, 'Current: =ep', ''
    res = SystemCapabilitiesFactCollector().collect(m)
    assert res['system_capabilities'] == []
    assert res['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:59:27.364562
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'

# Generated at 2022-06-20 18:59:31.917008
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps.name == 'caps'
    assert sys_caps._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])

# Generated at 2022-06-20 18:59:35.639156
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:59:44.289860
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.sys_info.caps import SystemCapabilitiesFactCollector as SysCap
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.utils.shlex import shlex_split

    # mocking
    real_get_file_content = get_file_content

    def mock_get_file_content(path, default=None, strip=False):
        if path == '/proc/sys/kernel/caps_enabled':
            return '1'
        return real_get_file_content(path, default, strip)

    get_file

# Generated at 2022-06-20 18:59:54.970787
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    import ansible.module_utils.facts.collector.system as system_capabilities_collector

    class TestBaseFactCollector(BaseFactCollector):
        name = 'caps'
        _fact_ids = set(['system_capabilities',
                         'system_capabilities_enforced'])

    class TestCollector(Collector):
        _fact_collector_class = TestBaseFactCollector


# Generated at 2022-06-20 19:00:06.814199
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # mocked_module - will return exit_code 0, stdout, and stderr and save in that order the 3 arguments given to run_command
    mocked_module = MagicMock(**{'run_command.return_value': (0, 'Current: =ep\n', '')})
    facts_dict = SystemCapabilitiesFactCollector().collect(mocked_module)
    assert facts_dict['system_capabilities_enforced'] == 'False'
    assert facts_dict['system_capabilities'] == []

    # mocked_module - will return exit_code 0, stdout, and stderr and save in that order the 3 arguments given to run_command

# Generated at 2022-06-20 19:00:10.984741
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect(): # pylint: disable=redefined-outer-name
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    # Need to re-assign sys.modules after monkey-patching, pylint: disable=unused-variable
    sys_modules = FactCollector._monkey_patch_sys_modules()
    sys_modules = DistributionFactCollector._monkey_patch_sys_modules()
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['gather_subset'] = None

# Generated at 2022-06-20 19:00:16.592056
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert set(c._fact_ids) == {'system_capabilities', 'system_capabilities_enforced'}
    # TODO: assert c._platform == 'Generic'