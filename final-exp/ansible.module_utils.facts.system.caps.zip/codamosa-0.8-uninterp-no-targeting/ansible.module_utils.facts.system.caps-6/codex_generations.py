

# Generated at 2022-06-20 18:51:05.010846
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'



# Generated at 2022-06-20 18:51:07.269603
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test the method collect of SystemCapabilitiesFactCollector
    """
    pass

# Generated at 2022-06-20 18:51:11.288745
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# NOTE: this is a hack to get autodoc working -akl
# autodoc_dynamic_classes['facts.system.SystemCapabilitiesFactCollector'] = SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:17.679890
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup mock module and fact collector
    from ansible.module_utils.facts import module_facts
    from ansible.module_utils.facts import collector

    module_mock = module_facts.AnsibleModuleMock(
        params=dict(),
        tmpdir='/tmp')
    module_mock.get_bin_path = lambda x: "/bin/%s" % x
    module_mock.run_command = lambda x, check_rc=True, close_fds=True: ('', 'Current:\tep boundingset', '')

    fact_collector = SystemCapabilitiesFactCollector(module_mock)

    # Execute collect and retrieve collected facts
    fact_collector.collect()
    collected_facts = fact_collector.get_facts()

    # Assert that the collected facts are as expected
   

# Generated at 2022-06-20 18:51:23.106236
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:51:30.436426
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import tempfile

    fd, tmpfilename = tempfile.mkstemp()
    os.close(fd)
    test_data = '''Current: =eip
Bounding set =eip
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root),113(apparmoradmin),114(apparmor)
'''

    with open(tmpfilename, 'w') as f:
        f.write(test_data)

    module = Mock()
    module.get_bin_path.return_value = tmpfilename
    module.run_command.return_value = 0, test_data

# Generated at 2022-06-20 18:51:36.890120
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()


# Generated at 2022-06-20 18:51:39.390546
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c._name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:51:44.603970
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemCapabilitiesFactCollector_instance = SystemCapabilitiesFactCollector()
    assert 'caps' == systemCapabilitiesFactCollector_instance.name
    assert 'system_capabilities' in systemCapabilitiesFactCollector_instance._fact_ids
    assert 'system_capabilities_enforced' in systemCapabilitiesFactCollector_instance._fact_ids

# Generated at 2022-06-20 18:51:47.933622
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    f = SystemCapabilitiesFactCollector()
    assert f.name == 'caps'
    assert f._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-20 18:51:53.159496
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    for c in SystemCapabilitiesFactCollector.__bases__:
        assert issubclass(SystemCapabilitiesFactCollector, c)

# Generated at 2022-06-20 18:51:54.253776
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-20 18:51:57.745946
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                               'system_capabilities_enforced'])
    return True

# Generated at 2022-06-20 18:52:04.955763
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:52:07.608783
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_fact_collector = SystemCapabilitiesFactCollector()
    assert capsh_fact_collector.name == 'caps'

# Generated at 2022-06-20 18:52:16.874196
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = mock.Mock()

# Generated at 2022-06-20 18:52:20.348502
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-20 18:52:24.836237
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE:
    # - mock module.run_command()
    # - mock get_caps_data() (calls module.run_command())
    # - mock parse_caps_data(data)
    pass

# Generated at 2022-06-20 18:52:26.097722
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector(None, None)


# Generated at 2022-06-20 18:52:29.122217
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None

    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:37.994752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    # NOTE: mock out data sources, where possible -akl

# Generated at 2022-06-20 18:52:41.150223
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = SystemCapabilitiesFactCollector()
    results = fact_collector.collect(module, collected_facts)
    assert 'system_capabilities' in results
    assert 'system_capabilities_enforced' in results

# Generated at 2022-06-20 18:52:43.809836
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_collector = SystemCapabilitiesFactCollector()
    assert test_collector.name == 'caps'
    assert 'system_capabilities_enforced' in test_collector._fact_ids
    assert 'system_capabilities' in test_collector._fact_ids

# Generated at 2022-06-20 18:52:44.736193
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:52:49.420631
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:00.515053
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = MagicMock(params=dict())
    mock_capsh = MagicMock(return_value='/bin/foo')
    mock_run_command = MagicMock(return_value=(0, '{}', ''))
    mock_module.get_bin_path = mock_capsh
    mock_module.run_command = mock_run_command


    facts_dict = SystemCapabilitiesFactCollector.collect(mock_module, {})

# Generated at 2022-06-20 18:53:01.813665
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:53:05.529782
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_caps = SystemCapabilitiesFactCollector()
    assert system_caps.name == 'caps'
    assert system_caps._fact_ids == set(['system_capabilities',
                                         'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:06.827613
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capabilities=SystemCapabilitiesFactCollector()
    assert capabilities.name == 'caps'

# Generated at 2022-06-20 18:53:13.080295
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class SystemCapabilitiesFactCollectorMock:
        def get_bin_path(self, arg):
            return arg


# Generated at 2022-06-20 18:53:19.640651
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:30.386776
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    Util.load_test_data_files(['facts/sys_caps_precise.txt', 'facts/sys_caps_root_precise.txt'])
    # setup the module arguments
    args = dict()

    # set the module arguments
    set_module_args(args)

    # create a facts object
    ac = SystemCapabilitiesFactCollector()

    # create a facts result
    facts_result = dict()

    # execute the code to be tested
    ac.collect(None, facts_result)

    # make assertions
    assert 'system_capabilities' in facts_result
    assert 'system_capabilities_enforced' in facts_result
    assert len(facts_result['system_capabilities']) > 0
    assert facts_result['system_capabilities_enforced'] == 'True'


# Generated at 2022-06-20 18:53:34.783112
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = 'ansible_collected_facts'
    # NOTE: replace w/ mock.MagicMock() and other mocking -akl
    class FakeModule:
        def __init__(self):
            self.params = {}

# Generated at 2022-06-20 18:53:44.721813
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import subprocess

    # NOTE: add a mock `capsh` command:
    #   $ echo 'Current: =ep'
    #   Current: =ep

    module = os.environ.get('ANSIBLE_MODULE_EXE', 'ansible-module-mock')
    process = subprocess.Popen(
        'if test -z "$1"; then echo Current: =ep; else ' + module + ' "$@"; fi',
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True,
        close_fds=True,
        executable='/bin/bash')

    module_output = b''

# Generated at 2022-06-20 18:53:49.421106
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    my_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector(None)
    assert my_SystemCapabilitiesFactCollector.name == 'caps'
    assert my_SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:01.028107
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:54:08.734057
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector.system_capabilities as caps
    import ansible.module_utils.facts.collector.system_capabilities as capsmock

    def get_caps_data_mock(self):
        return 0, 'Current: =ep', ''

    capsmock.caps.SystemCapabilitiesFactCollector.get_caps_data = get_caps_data_mock

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.params['gather_subset'] = ['!all', 'system_capabilities', 'system_capabilities_enforced']
    module.exit_json = lambda x: x

    facts_dict = collector.filter_facts

# Generated at 2022-06-20 18:54:18.268455
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

    def run_module():
        module_args = dict()
        module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)
        module.run_command = run_command
        return module


# Generated at 2022-06-20 18:54:20.402910
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    mc = SystemCapabilitiesFactCollector()
    assert mc.name == 'caps'
    assert mc._fact_ids == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:23.006388
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Declare class object
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    # Asserts here
    assert 'caps' == system_capabilities_fact_collector.name
    assert 'True' == system_capabilities_fact_collector.is_available  # TODO: update this -akl



# Generated at 2022-06-20 18:54:44.325171
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    capsh_path = module.get_bin_path('capsh')
    facts_dict = {}
    rc = 0
    out = ''
    err = ''
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'
                else:
                    enforced = 'True'
                    enforced_caps

# Generated at 2022-06-20 18:54:55.436131
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:55:05.079201
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    class MockModule(ModuleBase):
        def __init__(self):
            self._capsh_path = '/usr/bin/capsh'

        def get_bin_path(self, binary):
            return self._capsh_path

        def run_command(self, cmd, errors=None):
            if len(cmd) == 2 and cmd[0] == self._capsh_path and cmd[1] == '--print':
                return (0, "Current: =ep\nPossible: =ep", '')

    capabilities_collector = SystemCapabilitiesFactCollector()
    capabilities_collector.collect

# Generated at 2022-06-20 18:55:07.696889
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-20 18:55:11.661288
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    testObj = SystemCapabilitiesFactCollector()
    
    assert testObj.name == 'caps'
    assert testObj._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:55:14.756762
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    o = SystemCapabilitiesFactCollector()
    assert o.name == 'caps'
    assert o._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    assert o.collect() == {}

# Generated at 2022-06-20 18:55:18.468008
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance

    obj = get_collector_instance('SystemCapabilitiesFactCollector')
    assert obj.name == 'caps'

    # Assert _fact_ids is set
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Unit test to verify the collect method of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:55:26.526295
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    uname_mock = mock.Mock()
    uname_mock.return_value = "Linux"
    ansible.module_utils.facts.system.linux.uname = uname_mock

    run_command_mock = mock.Mock()
    run_command_mock.return_value = (0, '/usr/libexec/capsh --print', '')
    ansible.module_utils.facts.system.linux.run_command = run_command_mock

    get_bin_path_mock = mock.Mock()
    get_bin_path_mock.return_value = "/usr/libexec/capsh"
    ansible_mock = mock.Mock()
    ansible_mock.get_bin_path.return_value = "/usr/libexec/capsh"


# Generated at 2022-06-20 18:55:37.406802
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    with patch.object(SystemCapabilitiesFactCollector, 'has_capsh', return_value=True), \
         patch.object(SystemCapabilitiesFactCollector, '_parse_caps_data', return_value=('test_enforced', 'test_caps')):
        results = {}
        fact_collector = SystemCapabilitiesFactCollector()
        result = fact_collector.collect(None, results)
        assert result
        assert result['system_capabilities_enforced'] == 'test_enforced'

# Generated at 2022-06-20 18:55:41.280494
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}

# Generated at 2022-06-20 18:56:15.059751
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fail_dict = dict(msg='Failed to test SystemCapabilitiesFactCollector.')
    class FakeModule(object):
        def __init__(self):
            self.run_command_response = dict(rc=0, out='', err='')

        def get_bin_path(self, executable):
            return '/bin/capsh'

        def run_command(self, cmd):
            return self.run_command_response

    fm = FakeModule()

# Generated at 2022-06-20 18:56:17.944243
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector(None)
    assert s.name == 'caps'
    assert sorted(s._fact_ids) == sorted(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:20.252095
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    result = SystemCapabilitiesFactCollector().collect()

    assert result['system_capabilities_enforced'] == 'NA'
    assert result['system_capabilities'] == []

# Generated at 2022-06-20 18:56:31.000813
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact = SystemCapabilitiesFactCollector()
    module = MockModule()

    # Mock the module used to run the command
    rc, out, err = 0, get_capsh_print_output(), ""

    module.run_command.return_value = (rc, out, err)
    result = fact.collect(module=module)

    # Verify the method run_command was called with the correct arguments
    assert module.run_command.called
    args, kwargs = module.run_command.call_args
    assert args[0] == ['capsh', '--print']

    # Verify the resulting facts are correct
    assert result['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:56:40.494417
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.system_capabilities import test_SystemCapabilitiesFactCollector_collect
    from ansible.module_utils.facts.utils.file import FactsFile
    from ansible.module_utils import basic

    import os
    import socket
    import unittest

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_SystemCapabilitiesFactCollector_collect(self):
            tmp_dir = os.path.realpath(os.path.curdir)

# Generated at 2022-06-20 18:56:44.470881
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj
    assert isinstance(obj, SystemCapabilitiesFactCollector)
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:50.390866
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    This is a simple "smoke test" to make sure that this class can be
    instantiated.  This does NOT test the actual data collection.
    '''
    from ansible.module_utils.facts import toolchain

    fact_collector = SystemCapabilitiesFactCollector(module=toolchain.DummyModule())
    assert fact_collector.name == 'caps'
    assert fact_collector.collect() == {}

# Generated at 2022-06-20 18:56:54.966415
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:57:01.380669
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import base
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    x = SystemCapabilitiesFactCollector()
    assert isinstance(x,BaseFactCollector)
    assert x.name == 'caps'
    assert set(x._fact_ids) == set(['system_capabilities',
                                'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:05.036103
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector


# Generated at 2022-06-20 18:58:14.150497
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    col = SystemCapabilitiesFactCollector()
    assert col.name == "caps"
    assert len(col._fact_ids) == 2


# Generated at 2022-06-20 18:58:16.753561
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_cap = SystemCapabilitiesFactCollector()
    assert sys_cap.name == 'caps'
    assert sys_cap._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:58:23.186402
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule():
        def get_bin_path(self, name, opts=None):
            return '/bin/capsh'

        def run_command(self):
            return (0, 'Current: = cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+eip', '')
    d = SystemCapabilitiesFactCollector(module=MockModule())
    results = d.collect()

    assert(results['system_capabilities_enforced'] == 'True')

# Generated at 2022-06-20 18:58:32.532685
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_local

    facts_module = ansible_local.AnsibleModule({}, {})
    facts_module.get_bin_path = lambda x: x
    facts_module.run_command = lambda x, errors=False: (0, '', '')

    result = SystemCapabilitiesFactCollector().collect(facts_module, {})
    assert result['system_capabilities_enforced'] == 'NA'
    assert result['system_capabilities'] == []
    # NOTE: No parsing needs to be done. This code is meant to collect the
    #       system capabilities.
    # TODO: Add a test with a mocked capsh output to test the parsing code.

# Generated at 2022-06-20 18:58:33.698609
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.collect() == {}

# Generated at 2022-06-20 18:58:39.686214
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, path):
            return capsh_path

        def run_command(self, args, errors=None):
            return 0, capsh_output, ""

    capsh_path = 'capsh'
    facts_dict = {}
    collected_facts = {}
    capsh_output = ("""Current: =ep
Bounding set =ep
Secure bits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
gid=0(root)
groups=0(root)
""")

    collector = SystemCapabilitiesFactCollector(MockModule(), facts_dict, collected_facts)


# Generated at 2022-06-20 18:58:43.541103
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:58:49.619336
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock(run_command=Mock(return_value=(0, 'Current: = cap_setgid+eip cap_setuid+ep', '')))
    test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    test_caps = test_SystemCapabilitiesFactCollector.collect(module=module)
    assert module.run_command.call_count == 1
    assert test_caps['system_capabilities_enforced'] == 'True'
    assert test_caps['system_capabilities'] == ['cap_setgid+eip', 'cap_setuid+ep']

# Generated at 2022-06-20 18:58:52.081269
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-20 18:58:56.461887
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Test function to test constructor of class SystemCapabilitiesFactCollector
    '''
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])
    assert SystemCapabilitiesFactCollector.collect is not None
