

# Generated at 2022-06-20 18:51:09.884006
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    capsh_path = '/bin/capsh'
    rc = 0

# Generated at 2022-06-20 18:51:21.414484
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:31.121077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create class instance
    cls = SystemCapabilitiesFactCollector()

    # creating module class object with custom get_bin_path method
    class MyModule:
        def __init__(self):
            self.rc=0

# Generated at 2022-06-20 18:51:33.424530
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])



# Generated at 2022-06-20 18:51:40.575752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    m = MagicMock()

# Generated at 2022-06-20 18:51:51.089134
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Test 1: capsh not present, no fact populated
    module_path = 'ansible.module_utils.basic.AnsibleModule'
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False,
                           bypass_checks=True)
    module.get_bin_path = lambda x: None
    collector = SystemCapabilitiesFactCollector(module)
    facts = collector.collect()
    assert(facts['system_capabilities'] == [])
    assert(facts['system_capabilities_enforced'] == 'NA')

    # Test 2: capsh present but not cap_net_raw for enforced

# Generated at 2022-06-20 18:51:54.061781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class ModuleMock:
        def __init__(self):
            pass
        def get_bin_path(self, path):
            pass
        def run_command(self):
            pass

    instance = SystemCapabilitiesFactCollector()
    instance.collect(ModuleMock, {})

# Generated at 2022-06-20 18:51:57.092512
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts.name == 'caps'
    assert 'system_capabilities' in facts._fact_ids
    assert 'system_capabilities_enforced' in facts._fact_ids

# Generated at 2022-06-20 18:51:59.946868
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    o = SystemCapabilitiesFactCollector()
    assert o.name == 'caps'
    assert o._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:02.622145
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap_fact = SystemCapabilitiesFactCollector()
    assert cap_fact.name == 'caps'
    assert cap_fact._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:11.527289
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {'system_capabilities',
                                        'system_capabilities_enforced'}

# Generated at 2022-06-20 18:52:15.136436
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Constructor of class SystemCapabilitiesFactCollector successfully
    returns an instance of SystemCapabilitiesFactCollector
    '''
    collector = SystemCapabilitiesFactCollector()
    assert isinstance(collector, SystemCapabilitiesFactCollector)


# Generated at 2022-06-20 18:52:24.835696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def get_bin_path(self,name):
            return "capsh_path"
        def run_command(self,cmd, **options):
            assert cmd == [ "capsh_path", "--print" ]

# Generated at 2022-06-20 18:52:33.557573
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import subprocess
    import platform

    module = {}

    def get_bin_path(name):
        if platform.system() == 'Linux':
            return '/usr/bin/capsh'
        else:
            return None

    def run_command(cmd, **kwargs):
        try:
            proc = subprocess.Popen(cmd, **kwargs)
        except OSError:
            return None
        rc = proc.wait()
        out = proc.stdout.read()
        err = proc.stderr.read()
        return rc, out, err

    def run_command_enospc(cmd, **kwargs):
        return 1, b'', b'ENOSPC'

    module.get_bin_path = get_bin_path
    module.run_command = run_command

# Generated at 2022-06-20 18:52:41.191879
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    CapabilitiesMockFactsCollector = collector.get_collector_class('SystemCapabilitiesFactCollector')

    MockModule = type('MockAnsibleModule', (object,), dict(run_command=lambda self, cmd, errors: (0, 'Current: =ep', '')))
    module = MockModule()
    CapabilitiesMockFactsCollector().collect(module)
    assert module.facts['system_capabilities_enforced'] == 'False'
    assert module.facts['system_capabilities'] == []

# Generated at 2022-06-20 18:52:43.665106
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = {}
    instance = SystemCapabilitiesFactCollector()
    instance.collect(module, collected_facts)

# Generated at 2022-06-20 18:52:46.261407
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    res = SystemCapabilitiesFactCollector()
    assert res.name == SystemCapabilitiesFactCollector.name
    assert res._fact_ids == SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-20 18:52:51.381162
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # additional attributes used in assert
    # module_mock = Mock()
    # module_mock.run_command.return_value = (1, "Current: =ep", "")

    obj = SystemCapabilitiesFactCollector()

    actual = obj.collect()

    expected = dict(system_capabilities_enforced="NA",
                    system_capabilities=[])

    assert actual == expected
    # assert module_mock.run_command.called
    # assert module_mock.run_command.call_count == 1
    # assert module_mock.run_command.call_args[0] == (['/usr/bin/capsh', '--print'],)
    # assert module_mock.run_command.call_args[1] == dict(errors='surrogate_then_replace')

# Generated at 2022-06-20 18:52:53.714551
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps', 'failed to create SystemCapabilitiesFactCollector object'

# Generated at 2022-06-20 18:52:58.640194
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = '/usr/bin/capsh'
    module = FakeModule(capsh_path, 'capsh')
    collector = SystemCapabilitiesFactCollector(module)
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
  

# Generated at 2022-06-20 18:53:07.086003
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:09.479393
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()

    assert c.name == 'caps'
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:53:13.315599
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    my_fact_col = SystemCapabilitiesFactCollector( DummyModule() )
    assert 'system_capabilities_enforced' in my_fact_col.collect()


# Generated at 2022-06-20 18:53:17.460386
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:20.046184
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])
    assert obj.collect() == {}

# Generated at 2022-06-20 18:53:30.516749
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.run_command_call_count = 0

        def get_bin_path(self, bin_path):
            return bin_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            self.run_command_call_count += 1

# Generated at 2022-06-20 18:53:34.447354
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    res = SystemCapabilitiesFactCollector()
    assert res is not None
    assert res.name == 'caps'
    assert res._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:38.513913
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector(None)
    assert c.name == 'caps'
    assert c.priority == 50
    assert c._fact_ids == set(["system_capabilities_enforced", "system_capabilities"])

# Generated at 2022-06-20 18:53:39.106831
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 18:53:46.481948
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class ModMock:
        BIN_PATH = './bin'
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '%s/%s' % (self.BIN_PATH, name)


# Generated at 2022-06-20 18:54:07.834773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec = dict()
    )


# Generated at 2022-06-20 18:54:09.122961
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:54:12.430268
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # SystemCapabilitiesFactCollector() returns and
    # instance of SystemCapabilitiesFactCollector
    assert isinstance(SystemCapabilitiesFactCollector(),
            SystemCapabilitiesFactCollector)


# Generated at 2022-06-20 18:54:16.152126
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test the default constructor
    test_factCollector = SystemCapabilitiesFactCollector()
    assert test_factCollector.name == 'caps'
    assert set(test_factCollector._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:20.084955
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector

    caps_collector = get_collector_instance('SystemCapabilities', ansible_collector)
    caps_dict = caps_collector.collect(module=None, collected_facts=None)
    assert caps_dict == {}

# Generated at 2022-06-20 18:54:26.449978
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_collector = SystemCapabilitiesFactCollector()
    test_module = "ansible_test_module"
    test_facts = {}
    test_collector.collect(test_module, test_facts)
    expected_system_capabilities = ['']
    expected_system_capabilities_enforced = 'NA'
    assert test_facts['system_capabilities'] == expected_system_capabilities
    assert test_facts['system_capabilities_enforced'] == expected_system_capabilities_enforced

# Generated at 2022-06-20 18:54:27.984815
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: Test ... -akl
    pass


# Generated at 2022-06-20 18:54:34.181622
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import cache
    import os

    module = os.path.join(os.path.dirname(__file__), '../../../test/loader_fixture.py')

    c = FactsCollector()
    c.collect(module=module)
    assert cache.FACT_CACHE['system_capabilities'] == ['cap_net_bind_service', 'cap_setuid']

# Generated at 2022-06-20 18:54:38.072708
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])
    assert obj.collect() == {}

# Generated at 2022-06-20 18:54:42.576600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mm = AnsibleModuleMock
    mm.run_command = MagicMock(return_value=(0, 'Current: =\nBounding set =chown,dac_override,fowner,fsetid,kill,setgid,setuid,setpcap,net_bind_service,net_raw,sys_chroot,mknod,audit_write,setfcap\nSecurebits: 00/0x0/1' '', ''))
    mm.get_bin_path = MagicMock(return_value='/usr/bin/capsh')
    cc = SystemCapabilitiesFactCollector()
    res = cc.collect(module=mm)
    assert res['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:55:14.511619
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = '''
        {
            "ansible_system_capabilities": "=ep",
            "ansible_system_capabilities_enforced": "False",
            "ansible_path": "/bin:/usr/local/bin:/usr/bin",
            "ansible_env": {
                "PATH": "/bin:/usr/local/bin:/usr/bin",
                "LANG": "en_US.UTF-8",
                "HOME": "/root",
                "LOGNAME": "root"
            }
        }'''

    sc = SystemCapabilitiesFactCollector()
    assert sc.collect(module) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-20 18:55:16.443540
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:55:21.372664
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.cache.memory import FactCache

    from ansible.module_utils.facts.test_module import TestModule
    from ansible.module_utils.facts.test_module import TestModuleArgs

    import os
    import tempfile

    test_module = TestModule()
    test_module.run_command = os.system

    # create a temp file to use
    tmp_file = tempfile.mkstemp()[1]
    test_module.get_bin_path = lambda x: tmp_file


# Generated at 2022-06-20 18:55:24.449266
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_collector.name == 'caps'
    assert system_capabilities_collector._fact_ids == {'system_capabilities_enforced', 'system_capabilities'}

# Generated at 2022-06-20 18:55:29.003675
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import __gather_facts__
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.capabilities import get_caps_data
    from ansible.module_utils.facts.system.capabilities import parse_caps_data
    import sys

    class MockAnsibleModule(object):
        def __init__(self):
            self.capsh_path = None
            self.params = {}
            self.check_mode = False
            self.debug = False

# Generated at 2022-06-20 18:55:33.789267
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # get the collected facts from SystemCapabilitiesFactCollector.collect method
    collected_facts = SystemCapabilitiesFactCollector().collect()
    assert collected_facts is not None
    assert collected_facts['system_capabilities_enforced'] is not None
    assert collected_facts['system_capabilities'] is not None

# Generated at 2022-06-20 18:55:37.816115
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DummyModule()
    facts_dict = SystemCapabilitiesFactCollector().collect(module)
    assert set(facts_dict.keys()) == SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-20 18:55:48.572128
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    capsh_path = '/sbin/capsh'
    capsh_output = '''
Current: =ep
Bounding set =ep
Securebits: 
    secure-noroot: no (unlocked)
    secure-no-suid-fixup: no (unlocked)
    secure-keep-caps: no (unlocked)
    secure-no-initial-privs: no (unlocked)
Capabilities for user binaries: =
Capabilities for suid/sgid binaries: =
Permitted set =
Inheritable set =
Ambient set =
Capabilities: =
Capability bitmap =
'''
    module = type('module', (object,), {'run_command': lambda x: (0, capsh_output, ''), 'get_bin_path': lambda x: capsh_path})
    caps = SystemCapabilities

# Generated at 2022-06-20 18:55:54.617979
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.caps.system_capabilities import SystemCapabilitiesFactCollector

    class MockModule:
        class RunCommand:
            def __init__(self):
                self.action = None
                self.command = None
                self.errors = None
                self.rc = None

            def __call__(self, *args, **kwargs):
                self.action = args[0]
                self.command = args[1]
                self.errors = args[2]
                self.rc = rc
                return rc

# Generated at 2022-06-20 18:56:04.551407
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import mock
    import platform
    import __main__ as main

    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # NOTE: this should be moved into a shared module_utils/facts/fakes.py -akl
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {
                'module_name': 'test_SystemCapabilitiesFactCollector',
                'module_args': '',
                'capsh_out': ("Current: =ep\n"
                              "Bounding set =ep\n"),
            }

        # NOTE: stub out get_bin_path() to

# Generated at 2022-06-20 18:57:00.275545
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:10.880578
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
#
# NOTE: method collect runs: capsh --print
#
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector


# Generated at 2022-06-20 18:57:13.723498
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert systemCapabilitiesFactCollector.name == 'caps'
    assert systemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}

# Generated at 2022-06-20 18:57:17.329516
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SUT = SystemCapabilitiesFactCollector()

    assert isinstance(SUT, BaseFactCollector)
    assert SUT.name == 'caps'
    assert list(SUT._fact_ids) == \
         ['system_capabilities',
          'system_capabilities_enforced']

# Generated at 2022-06-20 18:57:22.151037
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule():
        def get_bin_path(self, binary):
            if binary == 'capsh':
                return 'capsh'
            else:
                return None


# Generated at 2022-06-20 18:57:24.434985
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:57:27.616366
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:29.308819
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-20 18:57:31.807132
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector()
    assert result.name == 'caps'
    assert result._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:57:35.228815
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}



# Generated at 2022-06-20 18:59:41.449937
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.test_module_test_module import TestModule
    testmodule = TestModule('', '', '', '')
    SystemCapabilitiesFactCollector().collect(testmodule)

# Generated at 2022-06-20 18:59:47.908633
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_collector = SystemCapabilitiesFactCollector()
    assert test_collector.name == 'caps'
    assert test_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])


# Generated at 2022-06-20 18:59:50.403722
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass
test_collect = test_SystemCapabilitiesFactCollector_collect

# Generated at 2022-06-20 18:59:53.575386
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert 'system_capabilities' in x._fact_ids
    assert 'system_capabilities_enforced' in x._fact_ids
    assert len(x._fact_ids) == 2

# Generated at 2022-06-20 19:00:06.164516
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import os
    import mock
    import tempfile
    import json

    class TestFactsModule(object):

        def __init__(self):
            self.run_command_called = False
            self.run_command_counter = 0
            self.run_command_call_args = []
            self.run_command_call_kwargs = []
            self.run_command_response = (0, 'Current: =ep', '')

        def get_bin_path(self, arg, *args, **kwargs):
            return '/bin/capsh'

        def run_command(self, args, *kwargs):
            self.run_command_called = True
            self.run_command_counter += 1
            self.run_command_call_args.append(args)
            self.run_command_

# Generated at 2022-06-20 19:00:09.781487
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import SYSTEM_CAPABILITIES_FACT_COLLECTOR

    # collect() returns a dict with keys [system_capabilities, system_capabilities_enforced]
    result = SYSTEM_CAPABILITIES_FACT_COLLECTOR.collect()
    # If a key does not exist in the dict or if its value is None, it is not included in the output
    assert 'system_capabilities' in result
    assert 'system_capabilities_enforced' in result
    assert result['system_capabilities'] is not None
    assert result['system_capabilities_enforced'] is not None

# Generated at 2022-06-20 19:00:15.064338
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities','system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:15.898073
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 19:00:18.614791
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj, SystemCapabilitiesFactCollector)


# Generated at 2022-06-20 19:00:19.991970
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'