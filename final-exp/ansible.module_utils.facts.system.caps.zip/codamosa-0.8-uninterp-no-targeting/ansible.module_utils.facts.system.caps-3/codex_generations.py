

# Generated at 2022-06-20 18:51:04.412538
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:51:09.819626
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}


# vim: set et ts=8 sw=4 sts=4 :

# Generated at 2022-06-20 18:51:15.114568
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Test to make sure that the SystemCapabilitiesFactCollector is initialised correctly.
    """

    sut = SystemCapabilitiesFactCollector()

    assert sut
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

    assert sut.collect() is None

# Generated at 2022-06-20 18:51:26.368233
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils.facts.utils import get_file_lines

    facts = get_module_facts(get_file_lines('./test/unit/ansible/module_utils/facts/system/caps_facts.py'))

    caps_collector = SystemCapabilitiesFactCollector()
    result = caps_collector.collect(facts)

# Generated at 2022-06-20 18:51:27.365232
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:51:36.087400
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.base import BaseFile, BaseSystem
    import os

    caps_file_path = "capsfile"

    # NOTE: probably no need to create a mock of BaseFile, but left in for
    #  readability

    class MockBaseFile(BaseFile):
        def __init__(self):
            self.name = caps_file_path
            self.path = caps_file_path
            self.path_exists = False
            self.__lines = []

        def read_file(self):
            if self.path_exists:
                return self.__lines
            elif self.path_exists == False:
                return []


# Generated at 2022-06-20 18:51:42.012308
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import DictFactsCollector
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible.module_utils.facts.system.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.rdmesg.rdmesg
    import ansible.module_utils.facts.network.lom
    import ansible.module_utils.facts.system.caps


# Generated at 2022-06-20 18:51:46.874481
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert len(obj._fact_ids) == 2
    assert obj.name in obj._fact_ids
    assert 'system_capabilities' in obj._fact_ids
    assert 'system_capabilities_enforced' in obj._fact_ids


# Generated at 2022-06-20 18:51:55.245896
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:52:00.245345
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert isinstance(c._fact_ids, set)
    assert 'system_capabilities' in c._fact_ids
    assert 'system_capabilities_enforced' in c._fact_ids

    # NOTE: _fact_ids should be frozenset -akl

test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:52:07.709162
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: tests should use 'from ansible.module_utils.facts import collector'
    # to silence pyflakes.
    from ansible.module_utils.facts import collector
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:52:11.004067
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == {'system_capabilities',
                                                           'system_capabilities_enforced'}

# Generated at 2022-06-20 18:52:14.147093
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert 'caps' == collector.name
    assert {'system_capabilities', 'system_capabilities_enforced'} == collector._fact_ids



# Generated at 2022-06-20 18:52:17.642504
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:52:19.169179
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector(None)
    assert obj

# Generated at 2022-06-20 18:52:27.441501
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    module = get_collector_instance('SystemCapabilitiesFactCollector')
    module._check_module.return_value = True


# Generated at 2022-06-20 18:52:30.368074
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collect_method = SystemCapabilitiesFactCollector().collect
    assert (collect_method() == {})
    #assert (collect_method(None, {'sys_capabilities': 'all'}) == {})

# Generated at 2022-06-20 18:52:38.023619
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = Mock(name="module")
    module.run_command = Mock(name="run_command")
    module.run_command.return_value = (0, "Current: =ep Permitted: chown,dac_override,fowner,fsetid,kill,setgid,setuid,setpcap,net_bind_service,net_raw,sys_chroot,mknod,audit_write,setfcap", "")


# Generated at 2022-06-20 18:52:38.699756
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector().name == 'caps'

# Generated at 2022-06-20 18:52:45.840167
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import get_collection_module
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(current_dir, '..', '..', '..', 'unit', 'module_utils', 'facts', 'system')
    test_file = os.path.join(test_dir, 'test_data', 'output_capsh_current_capabilities.txt')
    capsh_path = os.path.join(test_dir, 'bin', 'capsh')
    capsh_cmd = [capsh_path, '--print']
   

# Generated at 2022-06-20 18:53:02.954347
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:53:11.320509
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test method collect of class SystemCapabilitiesFactCollector
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    class MockModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return "/bin/capsh"
        def run_command(self):
            return (0, 'Current: =ep', "")
    collector.collectors[SystemCapabilitiesFactCollector.name] = SystemCapabilitiesFactCollector()
    collected_facts = collector.collect_fact(MockModule())
    assert collected_facts["system_capabilities_enforced"] == "False"
    assert collected_facts["system_capabilities"] == []

# Generated at 2022-06-20 18:53:19.371852
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create instance of class without calling init method
    module = FakeModule()
    # call the collect method of class
    module.run_command = run_command
    instance = SystemCapabilitiesFactCollector()
    results = instance.collect(module=module, collected_facts=None)
    # assert that result["system_capabilities_enforced"] is enforced
    assert(results["system_capabilities_enforced"] == enforced)
    # assert that result["system_capabilities"] is enforced_caps
    assert(results["system_capabilities"] == enforced_caps)



# Generated at 2022-06-20 18:53:21.618229
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys = SystemCapabilitiesFactCollector()
    assert sys.name == 'caps'

# Generated at 2022-06-20 18:53:22.198021
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 18:53:32.547487
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.capabilities
    import unittest
    import unittest.mock

    class MockModule:
        def get_bin_path(self, binary):
            return '/bin/capsh'


# Generated at 2022-06-20 18:53:34.364693
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c.collect() == {}

# Generated at 2022-06-20 18:53:44.504827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    # Setup the module object
    set_module_args(dict(gather_subset='all'))
    module = AnsibleModule(
        argument_spec=get_module_args(),
        supports_check_mode=True
    )

    # Replace real capsh command with a mock
    module.run_command = MagicMock(return_value=(0, dict(), dict()))

    # Replace the real method with a mock
    facts_collector = FactsCollector()
    facts_collector.collector = MagicMock(return_value=dict())
    facts_collector.get

# Generated at 2022-06-20 18:53:47.007841
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:59.055986
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    fake_out = '''Current: =eip
Bounding set =eip
Securebits: 00/0x0/1'b0 secure-noroot, loose
 secure-noroot,
CapEff: =eip
Ambient set =<none>
Noeuid:
Nosuid:
Noexec:'''
    from ansible.module_utils.facts.collector import AnsibleModuleMock
    stub_mod = AnsibleModuleMock()
    stub_mod.run_command.return_value = (0, fake_out, '')

    # Exercise
    res = SystemCapabilitiesFactCollector(stub_mod).collect()

    # Verify
    assert 'system_capabilities' in res
    assert res['system_capabilities'] == ['eip']

# Generated at 2022-06-20 18:54:12.716839
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Let's test this class object
    test_obj = SystemCapabilitiesFactCollector()

    # Check if inherited
    assert issubclass(SystemCapabilitiesFactCollector, BaseFactCollector)

# Generated at 2022-06-20 18:54:14.376467
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'


# Generated at 2022-06-20 18:54:18.616791
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    collector = SystemCapabilitiesFactCollector(module)
    assert collector.collect() == {
        'system_capabilities': ['cap_net_admin', 'cap_net_raw'],
        'system_capabilities_enforced': "True"
    }

from ansible.module_utils.basic import *



# Generated at 2022-06-20 18:54:29.837894
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fake_module = type('module', (object,), {
        'get_bin_path': lambda path: '/bin/capsh',
        'run_command': lambda *args, **kwargs: (0, 'Current: =', None)
    })

    fake_module_bad = type('module', (object,), {
        'get_bin_path': lambda path: None,
        'run_command': lambda *args, **kwargs: (0, 'Current: =', None)
    })

    real_module = type('module', (object,), {
        'get_bin_path': None,
        'run_command': None
    })

    collector = SystemCapabilitiesFactCollector()

    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])
   

# Generated at 2022-06-20 18:54:33.394920
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    caps_fact_collector = SystemCapabilitiesFactCollector()
    assert caps_fact_collector.name == 'caps'
    assert caps_fact_collector._fact_ids == set(['system_capabilities',
                                                 'system_capabilities_enforced'])



# Generated at 2022-06-20 18:54:35.511721
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: real test(s) would require mocking file paths
    # but for now just test for provided module in path
    assert SystemCapabilitiesFactCollector.collect() == {}

# Generated at 2022-06-20 18:54:43.562304
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollectorException
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import ansible_collector

    m = mock.mock_open(read_data=to_bytes(
        get_file_content('/proc/caps', scrubber=True)
    ))
    with pytest.raises(FactsCollectorException):
        fc = FactsCollector()
       

# Generated at 2022-06-20 18:54:53.565370
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # imports
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector

    fc = SystemCapabilitiesFactCollector()
    assert isinstance(fc, BaseFactCollector)

    fc = ansible_collector.get_collector('caps')
    assert isinstance(fc, SystemCapabilitiesFactCollector)

    assert fc.name == 'caps'
    #assert set(fc._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])

    assert callable(fc.collect)

# Generated at 2022-06-20 18:55:00.072877
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: -> use mock instead of patching internal method -akl

    collector = SystemCapabilitiesFactCollector
    module = AnsibleModule()

    result = collector.collect(module=module)
    assert result['system_capabilities_enforced'] == 'NA'
    assert result['system_capabilities'] == []

    result = collector.collect(None)
    assert result['system_capabilities_enforced'] == ''
    assert result['system_capabilities'] == ''

# Generated at 2022-06-20 18:55:03.146459
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:55:39.120023
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Make instance of a module
    module = MockModule()
    # Make instance of SystemCapabilitiesFactCollector
    cap_fact = SystemCapabilitiesFactCollector(module=module)

    # Test with capsh binary not available
    module.set_bin_path('capsh', '/usr/bin')
    collected_facts = cap_fact.collect()
    assert collected_facts['system_capabilities_enforced'] == 'NA'
    assert collected_facts['system_capabilities'] == []

    # Test with capsh binary available
    module.set_bin_path('capsh', None)
    collected_facts = cap_fact.collect()
    assert collected_facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-20 18:55:49.495081
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    from ansible.module_utils.facts import FactModule
    fm = FactModule()
    fm.exit_json = lambda x: x
    result = (1, "Current:\n  CapInh: =ep\n  CapPrm: =ep\n  CapEff: =eip\nCapBnd: =ep\nCapAmb: =ep", '')
    fm.run_command = lambda x: result
    data = SystemCapabilitiesFactCollector().collect(fm)
    assert data.get('system_capabilities') == []
    assert data.get('system_capabilities_enforced') == 'False'

# Generated at 2022-06-20 18:55:51.474839
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert collector.collect() == {}

# Generated at 2022-06-20 18:55:55.179786
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-20 18:55:56.045364
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:58.590479
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-20 18:56:08.526346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import unittest2 as unittest
    from ansible.module_utils.facts.collector import BaseFactCollector

    class AnsibleModuleFake:
        def get_bin_path(self, executable):
            if executable in ['capsh']:
                return executable
            else:
                return None


# Generated at 2022-06-20 18:56:10.495285
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_result = SystemCapabilitiesFactCollector()
    assert test_result.name == 'caps'

# Generated at 2022-06-20 18:56:18.757786
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock of AnsibleModule
    import ansible.module_utils.facts.system.caps
    am = ansible.module_utils.facts.system.caps.AnsibleModuleMock()
    am.run_command.return_value = (0, 'Current: =ep', '')

    scc = SystemCapabilitiesFactCollector()
    rc = scc.collect(module=am)

    assert 'system_capabilities_enforced' in rc
    assert 'system_capabilities' in rc
    assert rc['system_capabilities_enforced'] == 'False'
    assert rc['system_capabilities'] == []


# Generated at 2022-06-20 18:56:21.175780
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj.name, str)
    assert isinstance(obj._fact_ids, set)
    assert 'system_capabilities' in obj._fact_ids
    assert 'system_capabilities_enforced' in obj._fact_ids

# Generated at 2022-06-20 18:57:29.141103
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.capabilities import SystemCapabilitiesFactCollector
    class MockModule(object):
        def __init__(self, output):
            self.run_command_output = output

        def get_bin_path(self, name):
            return '/usr/bin/capsh'


# Generated at 2022-06-20 18:57:38.046667
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a module mock
    module_mock = Mock()

    # Create a module mock returns_value
    capsh_path_mock = Mock()
    # NOTE: Add capsh_path_mock to return_values of module_mock
    module_mock.get_bin_path.return_value = capsh_path_mock

    # Create a module mock returns_value
    out_mock = Mock()

# Generated at 2022-06-20 18:57:39.787993
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test the constructor of class SystemCapabilitiesFactCollector"""
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-20 18:57:49.397346
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # Load 'system_capabilities' plugin
    FactsCollector()._load_collectors(get_collector_instance)

    # Create SystemCapabilitiesFactCollector instance
    class ModuleMock:

        def get_bin_path(self, exe):
            if exe == 'capsh':
                return exe


# Generated at 2022-06-20 18:57:52.465941
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:57:54.885980
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_cap_obj = SystemCapabilitiesFactCollector()
    assert sys_cap_obj

# Test collect method of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:58:02.323528
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create a mock to replace module class
    class ModuleMock(object):
        class run_command(object):
            return (1, 'Current: =ep', '')

    # Create an instance of the class under test
    sut = SystemCapabilitiesFactCollector()

    # Call the function under test
    result = sut.collect(ModuleMock, {})

    # Assert that we got the expected result
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Generated at 2022-06-20 18:58:04.856439
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import os

    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert obj.collect() == {}

# Generated at 2022-06-20 18:58:08.438270
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule()
    # NOTE: use mock to populate module's run_command() return values -akl

    # NOTE: assertEqual() collection value with expected value -akl
    assertEqual(collection_value, expected_value)

# Generated at 2022-06-20 18:58:16.982537
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule
    import os

    class AnsibleModule:
        def run_command(self, cmd, errors='strict'):
            path = cmd[0]

# Generated at 2022-06-20 19:00:21.392881
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: unit test for 'get_caps_data()', and 'parse_caps_data()' -akl
    # NOTE: unit test for 'get_caps_data()', and 'parse_caps_data()' -akl
    assert(0)



# Generated at 2022-06-20 19:00:25.998832
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == "caps"
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-20 19:00:27.399011
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'



# Generated at 2022-06-20 19:00:30.377970
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:33.999184
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'

# Generated at 2022-06-20 19:00:39.082781
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert (collector.collect(collected_facts=None) == 
            {'system_capabilities_enforced': 'NA', 'system_capabilities': []})

# Generated at 2022-06-20 19:00:43.449698
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector_obj = SystemCapabilitiesFactCollector()

    assert fact_collector_obj
    assert fact_collector_obj.name == 'caps'
    assert len(fact_collector_obj._fact_ids) == 2
    assert 'system_capabilities' in fact_collector_obj._fact_ids
    assert 'system_capabilities_enforced' in fact_collector_obj._fact_ids


# Generated at 2022-06-20 19:00:44.827044
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 19:00:50.706737
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Constructor test
    obj = SystemCapabilitiesFactCollector()
    assert type(obj) == SystemCapabilitiesFactCollector
    # _fact_ids should be of type set
    assert type(obj._fact_ids) == set


# Generated at 2022-06-20 19:00:53.288199
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    tc = SystemCapabilitiesFactCollector()
    assert isinstance(tc.name, str)
    assert 'caps' == tc.name
    assert isinstance(tc._fact_ids, set)