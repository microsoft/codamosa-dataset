

# Generated at 2022-06-20 18:51:04.792608
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector

# class CapabilitiesFactModule

# Generated at 2022-06-20 18:51:10.932667
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_collector
    assert system_capabilities_collector.name == 'caps'
    assert system_capabilities_collector._fact_ids == set(['system_capabilities',
                                                           'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:17.341950
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
        Test that the method collect() of class
        SystemCapabilitiesFactCollector works as intended.
    """
    class Mock_module(object):
        def __init__(self, *args, **kwargs):
            pass
        def get_bin_path(self, prog):
            return '/bin/capsh'
        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (0, 'Current: =ep\nSecurebits: 00/0x0/1\'b0\n secure-noroot: no (unlocked)\n secure-no-suid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root)', '')

    test_obj = SystemCapabilitiesFactCollector()
    test_

# Generated at 2022-06-20 18:51:21.414232
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set([
        'system_capabilities',
        'system_capabilities_enforced'
    ])

# Generated at 2022-06-20 18:51:22.952604
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert SystemCapabilitiesFactCollector.collect() == {}


# Generated at 2022-06-20 18:51:32.220070
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)
    class MockModule:
        FAKE_MODE = Struct(BIN_SUFFIX='.fake', NO_DEFAULT_PATH=False)
        def __init__(self):
            self.mode = self.FAKE_MODE
        def get_bin_path(self, name, **kwargs):
            return name + self.mode.BIN_SUFFIX

# Generated at 2022-06-20 18:51:39.009290
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit tests for SystemCapabilitiesFactCollector"""
    capsh_path = 'capsh'

# Generated at 2022-06-20 18:51:50.202570
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Mock module
    class MockModule:
        def __init__(self):
            pass

        def get_bin_path(self, arg, required=False):
            return 'path/to/capsh'


# Generated at 2022-06-20 18:51:54.588427
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:56.403292
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x is not None
    assert x.name == 'caps'

# Generated at 2022-06-20 18:52:00.885411
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])



# Generated at 2022-06-20 18:52:06.922402
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import os

    # NOTE: create fake module with fake parameters -akl
    class FakeModule():
        params = {'follow': False}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'capsh':
                return '/usr/bin/capsh'

        def run_command(*args, **kwargs):
            if args and len(args) > 1 and args[1] == '--print':
                output_lines = []
                if os.path.exists('/proc/thread-self'):
                    output_lines.append('Version:     ' + to_bytes(3.2))

# Generated at 2022-06-20 18:52:09.109692
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-20 18:52:17.392263
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # facts
    import ansible.module_utils.facts.collector
    facts_to_include = set(['system_capabilities',
                            'system_capabilities_enforced'])
    ansible.module_utils.facts.collector.FACTS_TO_GATHER.update(facts_to_include)
    # mocks
    import ansible.module_utils.facts.system.system
    from ansible.module_utils.facts.system.system import SystemCapabilitiesFactCollector
    ansible.module_utils.facts.system.system.RunAsCapshEnv = run_as_capsh_env
    ansible.module_utils.facts.system.system.RunAsCapsh = run_as_capsh
    ansible.module_utils.facts.system.system.RunAsNoCapshEnv = run

# Generated at 2022-06-20 18:52:19.436224
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:52:30.330440
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:52:35.624193
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    SystemCapabilitiesFactCollector.collect(module=None, collected_facts=None)
    """
    module_arg_spec = dict(
        get_bin_path=dict(type='str'),
        run_command=dict(type='str')
    )
    module = AnsibleModule(argument_spec=module_arg_spec)
    s = SystemCapabilitiesFactCollector()
    res = s.collect(module)
    assert res['system_capabilities_enforced'] == 'True'
    assert res['system_capabilities'] == ['cap_setuid', 'cap_setgid']


# Generated at 2022-06-20 18:52:38.134922
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:43.077668
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Change the following as necessary
    from ansible.module_utils.facts import ansible_facts

    mock_module = None
    mock_facts = ansible_facts
    mock_collected_facts = None

    sut = SystemCapabilitiesFactCollector()
    result = sut.collect(mock_module, mock_collected_facts)

    # Test result
    #print('result.keys(): ', result.keys())
    assert result == 2


# Generated at 2022-06-20 18:52:43.666757
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 18:52:53.763205
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:05.111293
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''
    class SystemCapabilitiesFactCollector
    '''
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import list_collectors

    # NOTE: using real values to avoid mocking code
    # NOTE: ... and also because we run this code only if capsh can be found
    # NOTE: ... and also because it's unit test, not acceptance/integration test
    # NOTE: ... and also because we can (we should be running as root here)
    # NOTE: -> kinda forgot functional programming here ... -akl

# Generated at 2022-06-20 18:53:06.491759
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fc = SystemCapabilitiesFactCollector()
    assert fc.name == 'caps'
    assert fc._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:53:08.992211
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:17.835125
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
  test_module = MockModule()
  test_module.run_command = Mock(return_value=(1, "Current: =ep", ""))
  test_SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
  test_result = test_SystemCapabilitiesFactCollector.collect(test_module)
  assert type(test_result) is dict
  assert test_result['system_capabilities_enforced'] == 'False'
  assert type(test_result['system_capabilities']) is list
  assert test_result['system_capabilities'] == ["ep"]


# Generated at 2022-06-20 18:53:29.065502
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()
    capsh_path = module.get_bin_path('capsh')
    # NOTE: early exit 'if not crash_path' and unindent rest of method -akl
    if capsh_path:
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'

# Generated at 2022-06-20 18:53:29.608705
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass

# Generated at 2022-06-20 18:53:37.617745
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # We can't use isinstance here since it is a metaclass
    assert hasattr(SystemCapabilitiesFactCollector, '__metaclass__')
    assert type(SystemCapabilitiesFactCollector) == type

    # Required values
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert 'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector._fact_ids

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:53:42.116296
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
    assert fact_collector.collect() == {}

# Generated at 2022-06-20 18:53:46.627969
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert hasattr(collector, 'name')
    assert hasattr(collector, '_fact_ids')
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:07.124416
# Unit test for constructor of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:54:09.009453
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert not SystemCapabilitiesFactCollector.depends

# Generated at 2022-06-20 18:54:18.540858
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Test with capsh available and some capabilities enforced """

    # test with one capability and "Current:" output line
    module = FakeModule({'rc': 0,
                         'out': 'Current: =ep cap_net_raw',
                         'err': ''})
    collector = SystemCapabilitiesFactCollector(module)

    data = collector.collect()
    assert data.get('system_capabilities_enforced') == 'False'
    assert data.get('system_capabilities') == []

    # test with one capability and "Current:" output line
    module = FakeModule({'rc': 0,
                         'out': 'Current: = cap_net_raw',
                         'err': ''})
    collector = SystemCapabilitiesFactCollector(module)

    data = collector.collect()

# Generated at 2022-06-20 18:54:22.277602
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Check for existence of function `get_facts`
    # assert 'get_facts' in dir(SystemCapabilitiesFactCollector)
    assert callable(SystemCapabilitiesFactCollector.collect)


# Generated at 2022-06-20 18:54:23.234671
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:54:26.799504
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert len(obj._fact_ids) == 2
    assert 'system_capabilities' in obj._fact_ids
    assert 'system_capabilities_enforced' in obj._fact_ids

# Generated at 2022-06-20 18:54:29.694318
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-20 18:54:30.515303
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:54:33.431518
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    assert SystemCapabilitiesFactCollector().name == 'caps'
    assert SystemCapabilitiesFactCollector()._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])


# Generated at 2022-06-20 18:54:36.712259
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test if the new parameters(enforced, enforced_caps) are added and if the old parameters are not included"""

    module = Mock()
    module.get_bin_path.return_value = "/usr/sbin/capsh"
    module.run_command.return_value = (0, "Current: =ep", "")

    collection = SystemCapabilitiesFactCollector()
    result = collection.collect(module)

    assert result['system_capabilities'] == []
    assert result['system_capabilities_enforced'] == 'False'
    assert 'capabilities' not in result
    assert 'capabilities_enforced' not in result

# Generated at 2022-06-20 18:55:01.615920
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == { 'system_capabilities', 'system_capabilities_enforced' }

# Generated at 2022-06-20 18:55:02.503876
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:14.241771
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Test facts are collected from 'capsh' command
    """
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch
    from ansible_collections.ansible.misc.plugins.module_utils import facts
    from ansible_collections.ansible.misc.plugins.module_utils.facts import collector

    SystemCapabilitiesFactCollector = collector.get_collector("SystemCapabilitiesFactCollector")

    with patch.object(facts.module_utils.facts.utils.module, 'run_command') as run_command_mock:
        run_command_mock.return_value = (0, "Current: =ep", "")
        c = SystemCapabilitiesFactCollector(module=None)
        system_capabilities = c.collect()

# Generated at 2022-06-20 18:55:20.245714
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = object()

# Generated at 2022-06-20 18:55:21.827147
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert type(fact_collector) == SystemCapabilitiesFactCollector
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:55:27.864849
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Test with valid input
    collected_facts = {}
    module = MagicMock()
    module.run_command = MagicMock(return_value = (0, 'Current:\t= ip\npermitted:\tcap_net_admin,cap_net_raw+eip', ''))
    module.get_bin_path = MagicMock(return_value = '/usr/sbin/capsh')
    SystemCapabilitiesFactCollector(module=module, collected_facts=collected_facts).collect()
    assert collected_facts['system_capabilities'] == ['cap_net_admin', 'cap_net_raw+eip']
    assert collected_facts['system_capabilities_enforced'] == 'True'

    # Test with invalid input
    collected_facts = {}
    module = MagicMock()

# Generated at 2022-06-20 18:55:38.177691
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # setup test object
    # FIXME: This should be a mock object instead
    test_caps = SystemCapabilitiesFactCollector()

    # setup mock module obj
    class MockModule(object):
        def get_bin_path(self, prog):
            if prog == 'capsh':
                return '/bin/capsh'
            else:
                return None

        def run_command(self, args, errors='strict'):
            retval = 0
            out = 'Current: =ep\nCapInh:  =\nCapPrm:  =\nCapEff:  =\n'
            err = ''

            return retval, out, err

    test_module = MockModule()

    # do the test
    test_caps.collect(test_module)
    # FIXME: Verify proper output -akl

# Generated at 2022-06-20 18:55:40.613833
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'


# Generated at 2022-06-20 18:55:50.077575
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # create a mock module and class
    mock_module = type('MockModule', (), {'get_bin_path': lambda self, arg: arg,
                                          'run_command': lambda self, args: (0, 'Current: =ep', '')
                                          })
    mock_class = type('MockClass', (), {'_fact_ids': [],
                                        'name': 'system_capabilities'
                                        })

    system_capabilities_collector = SystemCapabilitiesFactCollector()
    system_capabilities_collector.__class__ = mock_class

    # Create a fake ansible module
    module = mock_module()

    expected_result = {'system_capabilities': [],
                       'system_capabilities_enforced': 'False'
                       }


# Generated at 2022-06-20 18:55:57.209984
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import logging
    import unittest
    class FakeModule:
        def get_bin_path(self, a):
            return '/bin/capsh'

# Generated at 2022-06-20 18:56:56.860548
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Test the collect method of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:56:59.523446
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module_loader, global_loader, plugin_loader = (None, None, None)
    collected_facts = None
    SystemCapabilitiesFactCollector(module_loader, global_loader, plugin_loader, collected_facts)

# Generated at 2022-06-20 18:57:09.099775
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # This will be a class for testing purposes
    class TestModule(object):
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, _):
            return '/bin/capsh'
    # This will be a function for testing purposes
    def run_command(*args, **kwargs):
        return 0, "Current: =ep", ""

    test = SystemCapabilitiesFactCollector()
    test_module = TestModule()
    facts = test.collect(module=test_module, collected_facts={})
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:57:09.753089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:57:12.357641
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    facts_dict = obj.collect()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:15.321942
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert set(s._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])

##### Mock module required methods

# Generated at 2022-06-20 18:57:18.080157
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_test = SystemCapabilitiesFactCollector()
    name_test = fact_test.name
    facts_test = fact_test.collection()
    assert name_test == 'caps'
    assert type(facts_test) == dict

# Generated at 2022-06-20 18:57:23.001897
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    # check that name assigned to instance is indeed 'caps'
    assert scfc.name == 'caps' 
    # check that _fact_ids contains the system_capabilities and system_capabilities_enforced keys
    assert 'system_capabilities' in scfc._fact_ids
    assert 'system_capabilities_enforced' in scfc._fact_ids

# Generated at 2022-06-20 18:57:32.680975
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """This is a private method. Do not call directly."""
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.caps as caps
    import mock
    import sys


# Generated at 2022-06-20 18:57:40.167568
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import sys
    import tempfile
    from ansible.module_utils.facts.capabilities import CapabilitiesFactModule
    fake_module = CapabilitiesFactModule()
    fake_module.run_command = run_command
    collector.add_collector(SystemCapabilitiesFactCollector(fake_module))
    output = collector.collect(fake_module)
    assert 'system_capabilities' in output
    assert output['system_capabilities'] == ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid',
                                             'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod',
                                             'audit_write', 'setfcap']
   

# Generated at 2022-06-20 18:59:57.513726
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut is not None
    assert sut.name == 'caps'
    assert set(['system_capabilities',
                'system_capabilities_enforced']) == sut._fact_ids

# Generated at 2022-06-20 19:00:07.644524
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.system.system as system
    M, module, params, all_facts, system_capabilities, \
        system_capabilities_enforced = system.get_all_the_params()
    S = SystemCapabilitiesFactCollector()
    S.collect(module, all_facts)
    assert S.name == 'caps'
    assert S._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

    # NOTE: expanded out, thinking we should expand out the default unit test
    # to better test the 'data type' logic -akl
    module.run_command = lambda x, **kw: (0, '[capabilities]\nEffective: =ep', '')
    S.collect(module, all_facts)

# Generated at 2022-06-20 19:00:11.246654
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:16.103090
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    SystemCapabilitiesFactCollector._collect()
    """
    import sys
    import os
    import subprocess
    # No facts to collect, so return nothing
    if sys.version_info.major < 3:
        import __builtin__ as builtins
    else:
        import builtins

    from ansible.module_utils._text import to_bytes

    test_obj = SystemCapabilitiesFactCollector()
    test_obj.collect()
    assert not test_obj.collect()  # empty

# Main function for testing
if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector_collect()
    print('Hooray! Test of class SystemCapabilitiesFactCollector passed!')

# Generated at 2022-06-20 19:00:20.187698
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:31.203884
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = {}
    capsh_path = module.get_bin_path('capsh')
    collector = SystemCapabilitiesFactCollector()

    # Tests if capsh is not installed
    def mock_get_bin_path_no_capsh(binary):
        return None

    module.get_bin_path = mock_get_bin_path_no_capsh
    assert collector.collect(module, collected_facts) is not None

    # Tests if capsh is installed
    def mock_get_bin_path_capsh(binary):
        return '/bin/capsh'

    module.get_bin_path = mock_get_bin_path_capsh
    assert collector.collect(module, collected_facts) is not None

# Generated at 2022-06-20 19:00:32.467607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 19:00:40.700558
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    argument_spec = {
        'module': object,
        'collected_facts': object
    }
    module = object
    collected_facts = object
    fact_collector = SystemCapabilitiesFactCollector

    result = fact_collector.collect(module=module,
                                    collected_facts=collected_facts)

    assert result == {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA'
    }

# Generated at 2022-06-20 19:00:48.405244
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert len(collector._fact_ids) == 2
    assert 'system_capabilities' in collector._fact_ids
    assert 'system_capabilities_enforced' in collector._fact_ids


# Generated at 2022-06-20 19:00:56.453952
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    facts_dict = {}
    # This is a small method, so just mock the right thing and call the method
    cap_mod = type('caps', (object,), {})
    cap_mod.run_command = lambda command, **kwargs: (0, 'Current: =ep', '')
    cap_mod.get_bin_path = lambda executable, **kwargs: '/bin/foo'
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect(module=cap_mod)
    assert len(facts_dict) == 2
    assert facts_dict['system_capabilities'] == []
    assert facts_dict['system_capabilities_enforced'] == 'False'