

# Generated at 2022-06-20 18:51:17.108652
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import __utils__ as ansible_module_utils_facts_utils
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import CapabilitiesFacts

    ansible_module_mock = ansible_module_utils_facts_utils.AnsibleModuleMock()
    ansible_module_mock.run_command.return_value = (0, 'testing', None)
    ansible_module_mock.get_bin_path.return_value = True

    system_capabilities_fact_collector_obj = SystemCapabilitiesFactCollector(module=ansible_module_mock, collected_facts=None)

# Generated at 2022-06-20 18:51:21.414382
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities',
                          'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:28.227450
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    given:
        - a SystemCapabilitiesFactCollector
    when:
        - collect() is called
    then:
        - system_capabilities: [] is returned
        - system_capabilities_enforced: False is returned
    """
    _SystemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    _SystemCapabilitiesFactCollector_collect = _SystemCapabilitiesFactCollector.collect()
    assert _SystemCapabilitiesFactCollector_collect == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-20 18:51:34.181743
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import mock
    import sys

    # Create an instance of the module class and mock all public methods/properties
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, 'Current: =ep', '')

    collector = SystemCapabilitiesFactCollector(module=module_mock)
    facts = collector.collect()

    assert 'system_capabilities' in facts
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:51:37.058812
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_collector = SystemCapabilitiesFactCollector()
    assert test_collector.name == 'caps'
    assert test_collector._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:42.536427
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class Mock_module(object):

        def __init__(self):
            self.run_command_result = (0, 'Current: =ep', '')

        def get_bin_path(self, name, required=False):
            return os.path.join(os.path.dirname(__file__), name)

        def run_command(self, cmd, check_rc=None, quiet=None, environ_update=None):
            return self.run_command_result

    capsh_collector = SystemCapabilitiesFactCollector()

    module = Mock_module()
    # Test not enforced capabilities
    actual = capsh_collector.collect(module)
    assert actual == dict(system_capabilities=['e', 'p'], system_capabilities_enforced=False)
    # Test enforced capabilities
    module.run

# Generated at 2022-06-20 18:51:46.053979
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps.name == 'caps'
    assert sys_caps._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:54.883788
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    ''' Unit test for method collect of class SystemCapabilitiesFactCollector '''
    # NOTE: This test is ANSIBLE specific and should be moved elsewhere
    # as it is not a unit test for SystemCapabilitiesFactCollector
    # but for a test method for the Ansible module 'system_capabilities'
    # which happens to use SystemCapabilitiesFactCollector.
    #
    # -akl
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.system.caps import get_caps_data
    from ansible.module_utils.facts.system.caps import parse_caps_data

    # NOTE: 'from ansible.module_utils.basic import *' does not import 'run_command'
    # so we use ANSIBLE_MODULE_EXIT_JSON and

# Generated at 2022-06-20 18:51:55.837385
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:51:58.651917
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:03.365692
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fake_module = FakeModule()
    assert len(SystemCapabilitiesFactCollector(fake_module).collect()) == 2


# Generated at 2022-06-20 18:52:14.955300
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    # The mock_open() function works together with the patch() function to replace the open() function during our tests.
    # The mock object returned by mock_open() is a file-like object, so it needs to be read by the method that’s being tested.
    # The read() method of a file-like object returns the text that was passed in to it upon creation.
    # Since we’re mocking the open() function, we have to pass the mock object returned by mock_open() to the read() method.
    #
    # We can use the readlines() method of a file-like object to read the lines one by one.
    # The readlines() method returns a list, so we can loop

# Generated at 2022-06-20 18:52:16.768275
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mc = SystemCapabilitiesFactCollector()
    mc.collect()

# Generated at 2022-06-20 18:52:24.867538
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleMock()
    m_subprocess_popen = module.subprocess.Popen

# Generated at 2022-06-20 18:52:28.368025
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector.system.system_capabilities
    c = ansible.module_utils.facts.collector.system.system_capabilities.SystemCapabilitiesFactCollector()
    assert c.collect() == {}

# Generated at 2022-06-20 18:52:31.384731
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = SystemCapabilitiesFactCollector().collect()
    assert 'system_capabilities_enforced' in facts_dict
    assert 'system_capabilities' in facts_dict


# Generated at 2022-06-20 18:52:38.023101
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.caps import CAPS
    import sys
    test_result = {'system_capabilities_enforced': 'True',
                   'system_capabilities': CAPS}
    # Using a class allows mocking/monkeypatching module.run_command method
    class TestModule(object):
        args = []

# Generated at 2022-06-20 18:52:39.833875
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MagicMock()
    collected_facts = {}
    SystemCapabilitiesFactCollector().collect(module, collected_facts)

# Generated at 2022-06-20 18:52:46.570300
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = simple_mock('/usr/bin/capsh')

# Generated at 2022-06-20 18:52:57.700307
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # unit test -akl
    # mock out module.run_command() -> (0, capsh_no_enforce, None)
    # mock out module.get_bin_path(capsh) -> /usr/bin/capsh
    # mock out module.exit_json() -> raise Exception()
    # mock out module.fail_json() -> raise Exception()

    class FakeModule(object):
        def __init__(self):
            self._run_command_return = None
            self._get_bin_path_return = None

        def run_command(self, arg, errors=None):
            return self._run_command_return

        def get_bin_path(self, name):
            return self._get_bin_path_return

        def exit_json(self, **kwargs):
            raise Exception()


# Generated at 2022-06-20 18:53:02.678209
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    testee = SystemCapabilitiesFactCollector()
    assert testee.name == 'caps'

# Generated at 2022-06-20 18:53:08.323877
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.utils import load_provider_arguments
    module = FakeModule({})
    loaded_arg_spec = load_provider_arguments(module)
    set_module_args({'provider': loaded_arg_spec})
    sysfact = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in sysfact.collect()

# Generated at 2022-06-20 18:53:19.656263
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    def log(msg):
        print(msg)

    class FactCollectorModule:
        def get_bin_path(self, a_bin_path):
            return "capsh"


# Generated at 2022-06-20 18:53:30.387828
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import module_wrapper
    from ansible.module_utils.facts import ansible_collection_converter
    from ansible.module_utils.facts import ansible_capabilities_converter

    test_module = module_wrapper()

# Generated at 2022-06-20 18:53:31.378466
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    module = None
    sut = SystemCapabilitiesFactCollector(module)
    assert sut is not None

# Generated at 2022-06-20 18:53:42.595241
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_module = 'fake module'

    capsh_path = 'fake/path'

    module_mock = type('module_mock', (), {'get_bin_path': lambda x, y: capsh_path})
    module_mock_obj = module_mock()

    run_command_mock = type('run_command_mock', (), {'return_value': (0, 'Current: =ep', '')})
    run_command_mock_obj = run_command_mock()

    module_mock_obj.run_command = run_command_mock_obj.return_value

    capfact = SystemCapabilitiesFactCollector()

    assert capfact.collect(module_mock_obj) == {'system_capabilities': [], 'system_capabilities_enforced': 'False'}

# Generated at 2022-06-20 18:53:54.520681
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup a module
    module = 'fake'
    capsh_path = '/usr/bin/capsh'

    def capsh_side_effects(args, errors='surrogate_then_replace'):
        # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
        rc, out, err = (1, '', '')

# Generated at 2022-06-20 18:53:55.867264
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:53:57.979839
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj.collect() == {}

# Generated at 2022-06-20 18:54:02.253653
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Constructor
    SystemCapabilitiesFactCollector()

    # Does not raise exception if invoked with 'module' arg
    SystemCapabilitiesFactCollector(module=None)
    SystemCapabilitiesFactCollector(module=object())
    SystemCapabilitiesFactCollector(module=object(), collected_facts=None)

# Generated at 2022-06-20 18:54:09.599939
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:54:15.406729
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    def mock_file_exists(self, file_path):
        return True
    import ansible.module_utils.facts.system.caps as caps
    caps.file_exists = mock_file_exists

    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:54:20.802436
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mod = ansible_module()
    facts = SystemCapabilitiesFactCollector().collect(module=mod)
    assert facts['system_capabilities'] == ['chown', 'dac_override', 'fowner', 'fsetid', 'kill', 'setgid', 'setuid', 'setpcap', 'net_bind_service', 'net_raw', 'sys_chroot', 'mknod', 'audit_write', 'setfcap']
    assert facts['system_capabilities_enforced'] == 'True'


# Generated at 2022-06-20 18:54:23.969895
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced']
                                                           )

# Generated at 2022-06-20 18:54:33.897168
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector
    mod_cls = collector.BaseFactCollector
    o_base_collector = ansible.module_utils.facts.collector.BaseFactCollector
    ansible.module_utils.facts.collector.BaseFactCollector = mod_cls
    
    mod_cls = ansible.module_utils.facts.system.caps
    o_collector = mod_cls.SystemCapabilitiesFactCollector
    mod_cls.SystemCapabilitiesFactCollector = collector.BaseFactCollector
    
    fc = mod_cls.SystemCapabilitiesFactCollector()
    
    # Test empty input
    assert fc.collect() == {}
    
    # Test no path
    fc._module = type

# Generated at 2022-06-20 18:54:36.287627
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:41.561830
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()
    mock_capsh_path = '/usr/bin/capsh'
    mock_module.get_bin_path.return_value = mock_capsh_path
    mock_module.run_command.return_value = 0, 'Current: =ep', ''
    mock_collector = SystemCapabilitiesFactCollector()
    test_dict = mock_collector.collect(mock_module)
    assert test_dict['system_capabilities_enforced'] == 'False'
    assert test_dict['system_capabilities'] == []

# Generated at 2022-06-20 18:54:48.791262
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Test class SystemCapabilitiesFactCollector method collect.
    """
    import pytest
    ModuleData = namedtuple('ModuleData',
                            'run_command, get_bin_path')
    class Module:
        # pylint: disable=too-few-public-methods
        def __init__(self):
            self.data = ModuleData(run_command=self.run_command,
                                   get_bin_path=self.get_bin_path)
        # pylint: disable=no-self-use
        def run_command(self, cmd, **kwargs):
            return (self.data.run_command(cmd, **kwargs))
        def get_bin_path(self, arg):
            return (self.data.get_bin_path(arg))


# Generated at 2022-06-20 18:54:59.536025
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.system.caps as caps
    import ansible.module_utils.facts as facts

    m = Collector()
    m._load_collectors()
    c = SystemCapabilitiesFactCollector()

    # get_caps_data() tests
    try:
        c.get_caps_data(m, [], out='Current: =ep', err='')
    except Exception as e:
        assert False, "c.get_caps_data(m, [], out='Current: =ep', err='') raised an exception: %s" % repr(e)


# Generated at 2022-06-20 18:55:01.297961
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test to test SystemCapabilitiesFactCollector.collect() functionality
    """
    test_obj = SystemCapabilitiesFactCollector()
    test_obj.collect()

# Generated at 2022-06-20 18:55:25.395859
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.capabilities import SystemCapabilitiesFactCollector
    # Mock object to mock BaseFactCollector class methods
    bfc = BaseFactCollector
    # Mock object to mock SystemCapabilitiesFactCollector class collect method
    scfc = SystemCapabilitiesFactCollector()
    scfc._fact_ids = set(['system_capabilities',
                          'system_capabilities_enforced'])
    # Mock object to mock get_caps_data() method
    def get_caps_data():
        return 'Current: =ep\nBounding set =cap_net_raw,cap_net_admin+eip'

    # Mock object to mock parse_caps_data() method
   

# Generated at 2022-06-20 18:55:28.237738
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        SystemCapabilitiesFactCollector()
    except:
        assert False, "Error in creating object of class SystemCapabilitiesFactCollector"

# Generated at 2022-06-20 18:55:37.879067
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector.system.caps import facts_on_linux
    class TestModule(object):
        def get_bin_path(self, name):
            return '/bin'


# Generated at 2022-06-20 18:55:40.994638
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {'system_capabilities': [], 'system_capabilities_enforced': 'NA'}

# Generated at 2022-06-20 18:55:47.805936
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Test that collect method of class SystemCapabilitiesFactCollector
# returns correct values, when the module run_command function returns
# valid data.
#def test_SystemCapabilitiesFactCollector_collect():
#    x = SystemCapabilitiesFactCollector()
#    assert x.collect() == SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:56.763679
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: to get better test coverage need to mock run_command()
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collectors.system.caps
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collectors.system.caps
    module = ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collectors.system.caps
    collected_facts = {}
    s = ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collectors.system.caps.SystemCapabilitiesFactCollector()
    i = s.collect(module, collected_facts)

# Generated at 2022-06-20 18:55:59.193932
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == "caps"
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])
    assert s._platform == 'All'

# Generated at 2022-06-20 18:56:02.051924
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    SystemCapabilitiesFactCollector()
    assert get_collector_instance(SystemCapabilitiesFactCollector.name)

# Generated at 2022-06-20 18:56:06.213335
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collect = SystemCapabilitiesFactCollector()
    assert collect.name == 'caps'
    assert collect._fact_ids == set(['system_capabilities',
                                     'system_capabilities_enforced'])


# Generated at 2022-06-20 18:56:08.621651
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Returned facts are empty because of no input
    facts = SystemCapabilitiesFactCollector().collect()
    assert len(facts) == 0

# Generated at 2022-06-20 18:56:40.935736
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:56:43.425467
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = {}
    # Arrange
    scfc = SystemCapabilitiesFactCollector()
    # Act
    result = scfc.collect(module=None, collected_facts=None)

    assert result == facts_dict

# Generated at 2022-06-20 18:56:44.510643
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collecto

# Generated at 2022-06-20 18:56:50.639207
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    data = SystemCapabilitiesFactCollector()
    # Verify name of the collector
    assert data.name == 'caps'
    # Verify fact ids
    assert data._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']), \
        "Failure: Expected _fact_ids to be " + str(set(['system_capabilities', 'system_capabilities_enforced']) + " but got: " + str(data._fact_ids))



# Generated at 2022-06-20 18:57:01.576201
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import module_utils.facts.system.capabilities
    import ansible.module_utils.facts.collector

    SystemCapsClass = module_utils.facts.system.capabilities.SystemCapabilitiesFactCollector
    CollectClass = ansible.module_utils.facts.collector.BaseFactCollector

    # instantiate the class
    system_caps_obj = SystemCapsClass({})
    # instantiate the collect object
    collect_obj = CollectClass({})

    # check caps_obj is subclass of CollectClass
    assert isinstance(system_caps_obj, CollectClass)

    # check caps_obj.collect method is defined
    assert callable(system_caps_obj.collect)

    # check the collect method return is dict
    assert isinstance(system_caps_obj.collect(), dict)

# Generated at 2022-06-20 18:57:07.067324
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector constructor"""
    system_capabilities = SystemCapabilitiesFactCollector()
    assert system_capabilities.__class__.__name__ == 'SystemCapabilitiesFactCollector'
    assert system_capabilities.name == 'caps'
    assert system_capabilities._fact_ids == {'system_capabilities_enforced', 'system_capabilities'}

# Generated at 2022-06-20 18:57:07.935595
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:57:16.530169
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test if get_caps_data and parse_caps_data methods return values correctly based on input.
    """
    import mock
    mock_module = mock.Mock()
    mock_module.get_bin_path.return_value = 'capsh'

# Generated at 2022-06-20 18:57:24.390859
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print('Testing SystemCapabilitiesFactCollector::collect')

    class MockModule(object):
        ''' Mock class for implementing module methods '''
        def get_bin_path(self, arg1):
            return capsh_path
        def run_command(self, arg1, arg2):
            return (0,'','Current: =ep','','')


    class MockSystemCapabilitiesFactCollector(SystemCapabilitiesFactCollector):
        ''' Mock class for overriding method is_file '''
        def is_file(self, arg1):
            return True

    capsh_path = '/bin/capsh'

    test_obj = MockSystemCapabilitiesFactCollector()
    mock_module = MockModule()

# Generated at 2022-06-20 18:57:34.954494
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    inst = SystemCapabilitiesFactCollector(module)
    # NOTE: get_caps_data()/parse_caps_data() for easier mocking -akl
    data = (0, 'Current: =ep\nBounding set =ep', '')
    inst._get_caps_data = lambda x: data
    inst._parse_caps_data = lambda x: x
    # NOTE: refactored method format -akl
    result = inst.collect()
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []
    # NOTE: refactored method format -akl
    data = (0, 'Current: =ep\nBounding set =ep', '')
    inst._get_caps_data = lambda x: data
    inst._

# Generated at 2022-06-20 18:58:52.456047
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s.name == 'caps'
    assert s._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:59:00.125745
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import NetworkFactCollector
    from ansible.module_utils.facts.collectors.network.base import NetworkCollector
    import os
    import tempfile
    import pytest
    import json

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self._socket_path = None
            self._debug = dict()
            self.check_mode = None
            self.no_log = None
            self._ansible_version = '2.10.0'
            self._ansible_module_name = 'NetworkCollector'
            self._ansible_facts_dir = tempfile.gettempdir()


# Generated at 2022-06-20 18:59:05.390313
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == "caps", "Constructor failed to set name attribute"
    assert x._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']), "Constructor failed to set fact names"


# Generated at 2022-06-20 18:59:10.764631
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert isinstance(s, SystemCapabilitiesFactCollector)
    assert s.name == 'caps'
    assert s._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:59:23.099538
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from subprocess import Popen, PIPE, STDOUT
    from ansible.module_utils.facts.collector import BaseFactCollector
    import time
    import os

    popen_args = ['/bin/sh', '-c',
        '/bin/echo \'Current: =ep\' && '
        '/usr/bin/env sleep 3']

    popen_env = dict(os.environ)
    popen_env['PATH'] = '/usr/bin:/bin'

    module = BaseFactCollector()

    start = time.time()
    rc, out, err = module.run_command([ '/bin/cat', '/proc/cmdline' ], errors='surrogate_then_replace')
    print("run_command returned in %s seconds" % (time.time() - start))
    assert rc == 0
    assert out

# Generated at 2022-06-20 18:59:26.796829
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert instance is not None
    assert instance.name == "caps"


# Generated at 2022-06-20 18:59:28.056131
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector



# Generated at 2022-06-20 18:59:29.022213
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:59:36.129379
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFacts
    import os
    import tempfile
    import textwrap

    caps_file = textwrap.dedent("""
    Current: =ep
    Bounding set =cap_permitted=,cap_inheritable=
    Securebits: 00/0x0/1'b0
    secure-noroot: no (unlocked)
    secure-no-suid-fixup: no (unlocked)
    secure-keep-caps: no (unlocked)
    uid=0(root)
    gid=0(root)
    groups=0(root),1(bin),2(daemon),3(sys),4(adm),6(disk),10(wheel)
    """)
   

# Generated at 2022-06-20 18:59:44.446015
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collector
    SystemCapabilitiesFactCollector = collector.get_collector('caps')
    fake_module = dummy_module()
    fake_module.run_command = dummy_command_run
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector(fake_module)
    result = system_capabilities_fact_collector.collect()