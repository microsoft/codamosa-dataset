

# Generated at 2022-06-20 18:51:16.333195
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_dict = dict()

    try:
        module.get_bin_path.return_value = '/bin/capsh'
    except NameError:
        pass

    module.run_command.return_value = 0, 'Current: =ep Bounding set =cap_net_bind_service,cap_net_raw+eip Bounding set =cap_net_bind_service,cap_net_raw+eip Effective: =ep Permitted: =ep Inheritable: =ep Ambient: 			', []

    def capsh_path():
        return capsh_path

    def get_bin_path(capsh_path, *args, **kwargs):
        return capsh_path()

    try:
        module.get_bin_path.side_effect = get_bin_path
    except NameError:
        pass



# Generated at 2022-06-20 18:51:20.381665
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities',
                             'system_capabilities_enforced'}


# Generated at 2022-06-20 18:51:29.438423
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DummyModule()
    module.capsh_path = 'dummy'
    facts_dict = {}
    capsh_path = module.get_bin_path('capsh')
    assert capsh_path == 'dummy'
    rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
    assert rc == 0
    assert 'Current:' in out
    assert '=ep' in out
    facts_dict = SystemCapabilitiesFactCollector.collect(module=module, collected_facts=None)
    assert facts_dict == {'system_capabilities_enforced': 'False', 'system_capabilities': ['ep']}

# Generated at 2022-06-20 18:51:37.753017
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import textwrap
    import unittest

    class TestansibleModule(object):
        def get_bin_path(self, x):
            return 'capsh_path'
        def run_command(self, x, y):
            return 0, textwrap.dedent("""\
                                     Current: =ep
                                     Bounding set =ep
                                     Securebits: 00/0x0/1'b0
                                     secure-noroot: no (unlocked)
                                     secure-no-suid-fixup: no (unlocked)
                                     secure-keep-caps: no (unlocked)
                                     uid=0(root)
                                     gid=0(root)
                                     groups=0(root)
                                     """), ""


# Generated at 2022-06-20 18:51:41.222352
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = None
    collected_facts = {}
    # any (non-None) module object will do
    SUT = SystemCapabilitiesFactCollector()
    assert(SUT.collect(module, collected_facts) == {})

# Generated at 2022-06-20 18:51:45.574228
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities',
                                                                'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:48.754549
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:51:53.159492
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()

    assert 'caps' == fact_collector.name
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:01.395371
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = object()
    collected_facts = object()
    output = object()
    fact_collector = SystemCapabilitiesFactCollector()
    fact_collector._get_capsh_output = lambda *args, **kwargs: output
    fact_collector._parse_capsh_output = lambda output: {'system_capabilities': ['CAP1', 'CAP2'],
                                                         'system_capabilities_enforced': 'True'}
    facts = fact_collector.collect(module, collected_facts)
    assert facts['system_capabilities'] == ['CAP1', 'CAP2']
    assert facts['system_capabilities_enforced'] == 'True'



# Generated at 2022-06-20 18:52:02.431558
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-20 18:52:15.650247
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system_capabilities import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.six
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    import six

    # NOTE: need to mock AnsibleModule.get_bin_path() and run_command() -akl
    ansible.module_utils.facts.collector.AnsibleModule = ansible.module_utils.facts.utils.Ansible

# Generated at 2022-06-20 18:52:19.214784
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    #
    # setup test environment
    #
    # test code
    #
    print(SystemCapabilitiesFactCollector.name)
    print(SystemCapabilitiesFactCollector._fact_ids)
    #
    # teardown test environment
    #

# Generated at 2022-06-20 18:52:22.334461
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test SystemCapabilitiesFactCollector class constructor"""

    obj = SystemCapabilitiesFactCollector()

    assert obj.name == 'caps'
    assert obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert obj.collect() == {}


# Generated at 2022-06-20 18:52:26.512995
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts import ModuleFactsService
    from ansible.module_utils.facts.collector import Collector
    import ansible_collections
    m = ModuleFactsService()
    c = Collector()
    m.add_collector(c)
    SystemCapabilitiesFactCollector(m)



# Generated at 2022-06-20 18:52:30.409572
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Unit test for constructor of class SystemCapabilitiesFactCollector
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert 'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids
    assert 'system_capabilities_enforced' in SystemCapabilitiesFactCollector._fact_ids



# Generated at 2022-06-20 18:52:32.327851
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert systemCapabilitiesFactCollector is not None

# Generated at 2022-06-20 18:52:37.521345
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector


# Generated at 2022-06-20 18:52:44.833442
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector.system.system_capabilities

    # NOTE: in python 2.7 this will be 'instancemock',
    #       capability is available since 3.2
    class ModuleMock:
        def __init__(self):
            self.assertion_failed = None
            self.valid_caps = False
            self.tmpdir = None
            self.caps_path = None

        def get_bin_path(self, capsh):
            if capsh == 'capsh':
                if self.valid_caps:
                    return self.caps_path
                else:
                    return None


# Generated at 2022-06-20 18:52:48.432362
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:59.520612
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import tempfile

    module_mock = BaseFactCollector()

    module_mock.get_bin_path = BaseFactCollector.get_bin_path
    module_mock.run_command = BaseFactCollector.run_command

    module_mock.get_bin_path.return_value = '/usr/bin/capsh'


    # capsh prints 'Current: = =ep' when capabilities are not enforced
    fake_capsh_not_enforced = tempfile.NamedTemporaryFile(mode='w+')

# Generated at 2022-06-20 18:53:07.825883
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:09.425675
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # TODO: implement unit test
    pass

# Generated at 2022-06-20 18:53:20.256830
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # module_utils/facts/system/caps.py
    '''
    Test case to test _collect function of SystemCapabilitiesFactCollector class of caps.py
    '''
    def get_caps_data(module, collected_facts):
        '''
        Custom function for collecting data for the function SystemCapabilitiesFactCollector.collect(self, module=None, collected_facts=None)
        '''
        return (None, None, None)

    def parse_caps_data(data):
        '''
        Custom function for parsing data for the function SystemCapabilitiesFactCollector.collect(self, module=None, collected_facts=None)
        '''
        facts_dict = {"system_capabilities_enforced": None,
                      "system_capabilities": None}
        return facts_dict

    # Not setting module for caps.py

# Generated at 2022-06-20 18:53:22.711816
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fc = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in fc.collect()

# Generated at 2022-06-20 18:53:26.466567
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_collector = SystemCapabilitiesFactCollector()
    assert test_collector.name == 'caps'
    assert 'system_capabilities' in test_collector._fact_ids
    assert 'system_capabilities_enforced' in test_collector._fact_ids

# Generated at 2022-06-20 18:53:29.193919
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities',
                                                         'system_capabilities_enforced'}


# Generated at 2022-06-20 18:53:29.776567
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:53:31.351805
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    Collector = SystemCapabilitiesFactCollector()
    assert Collector.name == 'caps'
    assert Collector._fact_ids == {'system_capabilities_enforced',
                                   'system_capabilities'}

# Generated at 2022-06-20 18:53:32.588691
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    pass


# Generated at 2022-06-20 18:53:33.376764
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:46.362606
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-20 18:53:48.804211
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'

# Generated at 2022-06-20 18:53:53.155254
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ SystemCapabilitiesFactCollector: constructor test
    """
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:54:04.094671
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import difflib
    import os
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts import ansible_collected_facts

    # call collect() method of SystemCapabilitiesFactCollector class
    system_capabilities_collector = SystemCapabilitiesFactCollector()

    # NOTE: collect() requires ansible_module_gather_timeout to be defined in ansible_collected_facts
    ansible_collected_facts['ansible_module_gather_timeout'] = 60.0

    # read in sample data from file
    basepath = os.path.dirname(__file__)

# Generated at 2022-06-20 18:54:13.864097
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = DummyModule()
    collected_facts = {}

    # make sure that not any exception will be raised
    SystemCapabilitiesFactCollector().collect(module=module, collected_facts=collected_facts)

    assert collected_facts['system_capabilities'] == ['CAP_CHOWN', 'CAP_DAC_OVERRIDE', 'CAP_FSETID', 'CAP_FOWNER', 'CAP_MKNOD', 'CAP_NET_RAW', 'CAP_SETGID', 'CAP_SETUID', 'CAP_SETFCAP', 'CAP_NET_BIND_SERVICE', 'CAP_SYS_CHROOT', 'CAP_KILL', 'CAP_AUDIT_WRITE', 'CAP_DAC_READ_SEARCH']
    assert collected_facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-20 18:54:21.620716
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # create class
    capcoll = SystemCapabilitiesFactCollector()
    # create AnsibleModule stub
    am = AnsibleModule()
    # add capsh to command path
    am.get_bin_path = MagicMock(return_value='/usr/bin/capsh')
    # add run_command method to AnsibleModule stub

# Generated at 2022-06-20 18:54:24.313116
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:34.142641
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockModule()

    # early exit if not capsh_path
    cc = SystemCapabilitiesFactCollector()
    cc.collect(None) == cc.collect(module)
    cc.get_caps_data(module) == cc.parse_caps_data(None)
    module.run_command.assert_not_called()

    # run_command, capsh standard output, enforcement unset
    module.run_command.return_value = (0, 'Current: =ep', None)
    cc.collect(module) == cc.collect(module)
    cc.get_caps_data(module) == cc.parse_caps_data('Current: =ep')

# Generated at 2022-06-20 18:54:37.173565
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:45.680827
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: using subTest()s to separate test cases for better readability -akl
    import os
    import tempfile
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # base case

# Generated at 2022-06-20 18:55:18.044062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fixture = {
        'capsh_path': 'C:\\cygwin64\\bin\\capsh',
        'current_caps': ' Current: =eip cap_setpcap,cap_net_bind_service,cap_sys_chroot+eip cap_setpcap,cap_net_bind_service',
        'status': 0,
        'stdout': '',
        'stderr': ''
    }
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = fixture['capsh_path']
    mock_module.run_command.return_value = (
        fixture['status'],
        fixture['stdout'],
        fixture['stderr'],
        )

    c = SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:26.363200
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import shutil, os

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True
    )

    # NOTE: change any 'None' to '[]' to test an empty set of data;
    #       increase the length of the values for testing the
    #       'system_capabilities' list
    test_data = {
        'system_capabilities_enforced': 'True',
        'system_capabilities': ['cap_chown', 'cap_dac_override', 'cap_net_bind_service', 'cap_net_raw'],
    }

# Generated at 2022-06-20 18:55:30.562997
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c1 = SystemCapabilitiesFactCollector()
    assert c1.name == 'caps'
    assert c1._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:55:35.143299
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    assert system_capabilities_fact_collector.name == 'caps'
    assert system_capabilities_fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:55:36.824398
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModule
    facts_dict = {}
    result = SystemCapabilitiesFactCollector.collect(module, facts_dict)

# Generated at 2022-06-20 18:55:39.166175
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    ''' unit test for SystemCapabilitiesFactCollector() '''
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:41.444615
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert type(sut) is SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:55:46.635159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Try to run "capsh" if found
    fact_collector = SystemCapabilitiesFactCollector()
    facts_dict = fact_collector.collect()
    try:
        assert 'system_capabilities' in facts_dict
        assert 'system_capabilities_enforced' in facts_dict
    # if not, then ok
    except AssertionError:
        pass

# Generated at 2022-06-20 18:55:49.580961
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc_obj = SystemCapabilitiesFactCollector()
    assert scfc_obj.name == 'caps'
    assert scfc_obj._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:55:50.563997
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# Generated at 2022-06-20 18:56:48.927486
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_exception
    collector = SystemCapabilitiesFactCollector()
    res = collector.collect()

    assert 'system_capabilities' in res
    assert 'system_capabilities_enforced' in res

# Generated at 2022-06-20 18:56:55.452162
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test constructor of SystemCapabilitiesFactCollector class"""

    # Instantiate object of type SystemCapabilitiesFactCollector
    cap_collector = SystemCapabilitiesFactCollector()

    # Test constructor
    assert cap_collector.name == 'caps'
    assert cap_collector._fact_ids == set(['system_capabilities',
                                           'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:59.278408
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ Unit test for constructor of class SystemCapabilitiesFactCollector """
    system_cap_fact_collector = SystemCapabilitiesFactCollector()

    assert system_cap_fact_collector == 'caps'
    assert system_cap_fact_collector == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:09.981077
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import pytest
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NO_DEFAULT
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts.collector import get_collectors_names

# Generated at 2022-06-20 18:57:11.383165
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    print("\n\n############")
    print("\nTesting SystemCapabilitiesFactCollector.collect:\n")


# Generated at 2022-06-20 18:57:12.179429
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import F

# Generated at 2022-06-20 18:57:14.349676
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])

# Generated at 2022-06-20 18:57:21.087324
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class Mock_Module():
        def get_bin_path(self, path):
            return path


# Generated at 2022-06-20 18:57:30.847752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Tests for SystemCapabilitiesFactCollector.collect()
    """

    # create mock module
    mock_module = MockModule()

    # create instance of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()

    # call the collect method of SystemCapabilitiesFactCollector
    system_capabilities_fact_collector.collect(mock_module)

    # check that facts were stored correctly
    expected_result = {
        'system_capabilities': ['cap_chown', 'cap_fowner', 'cap_mknod', 'cap_net_bind_service'],
        'system_capabilities_enforced': 'True'
    }
    assert system_capabilities_fact_collector.get_facts() == expected_result



# Generated at 2022-06-20 18:57:39.212779
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:59:48.902821
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-20 18:59:59.051888
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: Initialize test to use 'module' object -akl
    module = AnsibleModule(argument_spec=dict())
    # NOTE: Initialize test with no prior collected_facts -akl
    collected_facts = dict()
    # NOTE: Create an instance of the class -akl
    inst = SystemCapabilitiesFactCollector(module=module,
                                           collected_facts=collected_facts)
    # NOTE: Expected results from 'collect' method -akl

# Generated at 2022-06-20 19:00:03.897744
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
  test_instance = SystemCapabilitiesFactCollector()
  assert test_instance.name == 'caps'
  assert test_instance._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 19:00:06.046977
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert SystemCapabilitiesFactCollector.name == 'caps'
    
    

# Generated at 2022-06-20 19:00:08.246482
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Unit test for method collect of class SystemCapabilitiesFactCollector"""
    import ansible.module_utils.facts.system.caps
    obj = ansible.module_utils.facts.system.caps.SystemCapabilitiesFactCollector()
    result = obj.collect()
    assert result is not None

# Generated at 2022-06-20 19:00:21.013912
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 19:00:24.287596
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    facts_collector = SystemCapabilitiesFactCollector()
    result = facts_collector.collect()
    assert result == {}

# Generated at 2022-06-20 19:00:32.447236
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import json

    # Create a mock module object
    mock_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # Make a copy of the module so we can modify it
    module = mock_module.params.copy()
    module['run_command'] = mock_module.run_command

    # Create a mock facts object

# Generated at 2022-06-20 19:00:38.007040
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 19:00:41.438686
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == "caps"
    assert x._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
