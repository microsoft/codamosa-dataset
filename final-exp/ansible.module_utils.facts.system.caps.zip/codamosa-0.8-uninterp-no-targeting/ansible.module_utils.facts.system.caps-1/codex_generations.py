

# Generated at 2022-06-20 18:51:17.599603
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    # Unit test with mock objects
    class MockModule(object):
        def get_bin_path(self, path):
            return True
    class MockRunModule(object):
        def run_command(object, command, errors=None):
            return ('0', 'Current: = eip cap_net_raw,cap_net_admin=eip', 'err')

    mock_module = MockModule()
    mock_run_command = MockRunModule()

    # Test calling collect() with no arg
    collector = SystemCapabilitiesFactCollector(mock_module)
    assert collector.collect() == {}

    # Test calling collect() with mock arg

# Generated at 2022-06-20 18:51:28.457591
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import platform
    import tempfile


# Generated at 2022-06-20 18:51:37.726749
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import subprocess
    import sys
    import os
    import ansible.module_utils.facts.collector

    module_name = 'ansible.module_utils.facts.collector'
    module = sys.modules[module_name]

    # Mock os.access
    def _mock_access(path, mode):
        return True
    _access_orig = os.access
    os.access = _mock_access

    # Mock subprocess.Popen
    class _MockPopen(object):
        def __init__(self, args, **kwargs):
            self.stdout = subprocess.PIPE
            self.stderr = subprocess.PIPE
            self.returncode = 0

# Generated at 2022-06-20 18:51:48.718004
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # Mock imports
    import ansible.module_utils.facts.collector

    def run_command_success(command, errors='surrogate_then_replace'):
        print('Running command: ' + command)
        output = "Current: =ep\nBounding set =cap_net_raw+ep"
        return 0, output, ""

    def run_command_failure(command, errors='surrogate_then_replace'):
        print('Running command: ' + command)
        return 1, '', 'capsh not found in PATH: No such file or directory'

    def get_bin_path(bin_path_name):
        return bin_path_name


# Generated at 2022-06-20 18:51:52.139338
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])



# Generated at 2022-06-20 18:52:01.904751
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile

    mock_module = type('', (), {})()
    test_output = 'Current: = cap_setgid,cap_setuid\n'
    test_source = 'Current: = cap_setgid,cap_setuid\n'
    mock_module.run_command = lambda x, **kwargs: (0, test_output, '')
    mock_module.get_bin_path = lambda x: '/bin/capsh'
    mock_module.params = {
        'pipelining': False,
    }
    mock_module.tmpdir = tempfile.gettempdir()

    mock_caps = {}

    # Case 1: Output is returned as a string
    mock_caps['output'] = test_output
    collect = SystemCapabilitiesFactCollector(mock_module)


# Generated at 2022-06-20 18:52:03.431031
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert len(fact._fact_ids) == 2

# Generated at 2022-06-20 18:52:11.881089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    # NOTE: mock_module is a MagicMock, pass it in to the method as a stand-in for module param -akl
    result = SystemCapabilitiesFactCollector().collect(mock_module)

    # Assert that the returned result is a dict
    assert isinstance(result, dict)

    # Assert that the result only includes the keys from the defined fact set
    fact_set = SystemCapabilitiesFactCollector._fact_ids
    result_keys = set(result.keys())
    for key in result_keys:
        assert key in fact_set

# Generated at 2022-06-20 18:52:18.959160
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.system.caps import test_SystemCapabilitiesFactCollector_collect
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector_module

    testmodule = SystemCapabilitiesFactCollector_module()

    testmodule.run_command = lambda args, errors: (
        0 if 'print' in args else 1,
        'Current: =ep', 'error')

    testmodule.get_bin_path = lambda name: '/usr/bin/' + name + '-x86_64'

    new_collector = SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:52:21.433302
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert isinstance(collector, object)


# Generated at 2022-06-20 18:52:29.000970
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Constructor test
    '''
    fact_collector = SystemCapabilitiesFactCollector()
    """
    Testing the constructor of class SystemCapabilitiesFactCollector
    """

    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:31.723593
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == set(['system_capabilities_enforced', 'system_capabilities'])



# Generated at 2022-06-20 18:52:33.308464
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_cap_fact_collector = SystemCapabilitiesFactCollector()
    assert sys_cap_fact_collector.name == 'caps'

# Generated at 2022-06-20 18:52:38.213888
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Unit test for constructor.
    """
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:41.772886
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import ModuleStub
    module = ModuleStub()
    module.get_bin_path.return_value = '/capsh'
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, 'Current: =ep', None)

    caps = SystemCapabilitiesFactCollector()
    result = caps.collect(module)

    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []


# Generated at 2022-06-20 18:52:52.372666
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.utils.module_docs_fragments
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts()
    module.get_bin_path = lambda x: '/bin/capsh'

# Generated at 2022-06-20 18:52:54.868829
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: get_caps_data()/parse_caps_data() like all other fact collectors -akl
    pass

# Generated at 2022-06-20 18:52:57.414686
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:53:05.945526
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup
    module = None
    collected_facts = None
    expected = {}

    # Override path
    capsh_path = 'fake_capsh_path'
    SystemCapabilitiesFactCollector._capsh_path = capsh_path
    # Override run_command
    SystemCapabilitiesFactCollector._run_command = lambda self, cmd, errors: (0, capsh_out, None)

    # Run test
    results = SystemCapabilitiesFactCollector.collect(module, collected_facts)

    # Assertions
    assert results == expected


test_SystemCapabilitiesFactCollector_collect()

# Generated at 2022-06-20 18:53:08.242665
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = SystemCapabilitiesFactCollector()
    assert facts._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert facts.name == 'caps'

# Generated at 2022-06-20 18:53:21.343853
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    collector = SystemCapabilitiesFactCollector()
    out = '''Current: =ep
Bounding set =ep
Securebits: 00/0x0/1'b0
 secure-noroot: no (unlocked)
 secure-no-suid-fixup: no (unlocked)
 secure-keep-caps: no (unlocked)
uid=0(root)
'''
    expected_result = {
        u'system_capabilities_enforced': 'False',
        u'system_capabilities': ['ep']
    }

    assert collector.collect(1,2, capsh_path='stuff', rc=0, out=out, err=None) == expected_result

# Generated at 2022-06-20 18:53:31.765981
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Set up the ansible module.
    module = MockModule()

# Generated at 2022-06-20 18:53:32.326584
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:33.470628
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-20 18:53:43.828272
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Validating the data returned by collect() of SystemCapabilitiesFactCollector """
    # NOTE: just hard-code a string as command output -akl
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -kl

# Generated at 2022-06-20 18:53:48.609746
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capability_collector = SystemCapabilitiesFactCollector()
    assert system_capability_collector.name == 'caps'
    assert system_capability_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:53:52.187216
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    target_obj = SystemCapabilitiesFactCollector()
    assert target_obj.name == 'caps'
    assert target_obj._fact_ids == set(['system_capabilities_enforced', 'system_capabilities'])

# Generated at 2022-06-20 18:53:59.055476
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = FakeAnsibleModule()
    capsh_path = module.get_bin_path('capsh')
    fact_collector = SystemCapabilitiesFactCollector()
    actual = fact_collector.collect(module=module, collected_facts=None)
    if capsh_path:
        assert 'system_capabilities' in actual
        assert 'system_capabilities_enforced' in actual
    else:
        assert actual == {}

# Unit test stubs

# Generated at 2022-06-20 18:54:05.382696
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # prep
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, 'Current: =ep', ''))
    cap_obj = SystemCapabilitiesFactCollector()
    # execute
    actual = list(cap_obj.collect(module).items())
    # verify
    expected = [('system_capabilities', []), ('system_capabilities_enforced', 'False')]
    assert (sorted(actual) == sorted(expected))


# Generated at 2022-06-20 18:54:08.853125
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test constructor:
    scfc = SystemCapabilitiesFactCollector();
    assert(scfc.name == 'caps')
    assert(scfc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced']))


# Generated at 2022-06-20 18:54:23.104664
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == \
        set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:32.993011
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.common import Capsh
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import sys

    # NOTE: make sure we are testing with a C locale
    old_lc = None
    old_lang = None
    lc_all_set = False
    lang_set = False
    if 'LC_ALL' in os.environ:
        lc_all_set = True
        old_lc = os.environ.get('LC_ALL')
    if 'LANG' in os.environ:
        lang_set = True
        old_lc = os

# Generated at 2022-06-20 18:54:40.970607
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.run_command_ran = False
            self.rc = 0

# Generated at 2022-06-20 18:54:42.565786
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system = SystemCapabilitiesFactCollector()

    assert(system.name == 'caps')

# Generated at 2022-06-20 18:54:46.750047
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # arrange
    module = Mock()
    module.get_bin_path.return_value = '/bin/capsh'
    module.run_command.return_value = 0, 'Current: =ep', ''

    # act
    actual = SystemCapabilitiesFactCollector().collect(module)

    # assert
    assert actual == {'system_capabilities_enforced': 'False', 'system_capabilities': []}

# Generated at 2022-06-20 18:54:48.111131
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-20 18:54:59.168869
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    module = 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.caps.SystemCapabilitiesFactCollector.collect'

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):

        def setUp(self):
            self.SystemCapabilitiesFactCollector_instance = SystemCapabilitiesFactCollector()

        @patch(module)
        def test_collect(self, mock_collect):
            self.SystemCapabilitiesFactCollector_instance.collect()
            self.assertTrue(mock_collect.called)

    unittest.main

# Generated at 2022-06-20 18:55:04.332902
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    fact_data = {}
    fact_collector = SystemCapabilitiesFactCollector(fact_data, {})

    module = True
    collected_facts = None
    ret_val = fact_collector.collect(module, collected_facts)

    assert module
    assert not collected_facts
    assert ret_val
    assert not ret_val['system_capabilities_enforced']
    assert not ret_val['system_capabilities']
    return

# Generated at 2022-06-20 18:55:06.353396
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    oc = SystemCapabilitiesFactCollector()
    oc.collect()

# Generated at 2022-06-20 18:55:08.051933
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    cap_collector = SystemCapabilitiesFactCollector()
    assert cap_collector.name == 'caps'

# Generated at 2022-06-20 18:55:40.806960
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import errno
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector

    class TestSystemCapabilitiesFactCollector(unittest.TestCase):

        def setUp(self):
            collector.sys = MagicMock()
            self.caps = SystemCapabilitiesFactCollector()
            self.caps.get_file_content = MagicMock(return_value={})
            self.caps.get_file_lines = MagicMock(return_value=[])


# Generated at 2022-06-20 18:55:43.568543
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 18:55:50.142271
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts

    ansible.module_utils.facts_cache.CACHE = {}
    ansible.module_utils.facts_cache.FACT_CACHE_TIMEOUT = 0

    c = SystemCapabilitiesFactCollector()
    c.populate()
    res = c.get_fact_cache()

    assert 'system_capabilities' in res
    assert 'system_capabilities_enforced' in res

# Generated at 2022-06-20 18:55:57.282489
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    test_module = ansible_collector._create_module_mock('/tmp/ansible_facts_test_module')

# Generated at 2022-06-20 18:56:01.915100
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import SystemCapabilitiesFactCollector

    system_caps_fact_collector = SystemCapabilitiesFactCollector()
    assert isinstance(system_caps_fact_collector, BaseFactCollector)
    assert system_caps_fact_collector.name == 'caps'
    assert system_caps_fact_collector._fact_ids == set(['system_capabilities',
                                                        'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:02.987695
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-20 18:56:04.884455
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(), SystemCapabilitiesFactCollector)

# Generated at 2022-06-20 18:56:06.435841
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:56:08.010660
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-20 18:56:11.095875
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == { 'system_capabilities', 'system_capabilities_enforced' }



# Generated at 2022-06-20 18:57:10.315530
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert sut.name == 'caps'
    assert sut._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:57:13.638941
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == {
        'system_capabilities',
        'system_capabilities_enforced',
    }



# Generated at 2022-06-20 18:57:17.991270
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Unit test for constructor of class SystemCapabilitiesFactCollector"""
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector
    assert fact_collector.name == 'caps'
    assert fact_collector.priority == 75
    assert fact_collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}


# Generated at 2022-06-20 18:57:19.757817
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector is not None
    assert collector.name == 'caps'


# Generated at 2022-06-20 18:57:29.809375
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    def test_run(mock_m1):
        """Test run of CapabilitiesFactCollector.collect()"""

        systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()

        systemCapabilitiesFactCollector.collect(mock_m1, 
            collected_facts={})

    import mock
    mock_m1 = mock.Mock()
    mock_m1.get_bin_path.return_value = "/sbin/capsh"

# Generated at 2022-06-20 18:57:38.495806
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: shouldn't be mocking methods/properties for other classes
    #       -akl
    class MockModule(object):
        def get_bin_path(self, binary):
            return binary


# Generated at 2022-06-20 18:57:47.457744
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import pytest

# Generated at 2022-06-20 18:57:49.978009
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'


# Generated at 2022-06-20 18:57:58.306687
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """ Unit test for method SystemCapabilitiesFactCollector.collect """
    import sys
    import mock

    class DummyModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, prog, opt_dirs=[]):
            return '/bin/capsh'

        def run_command(self, args, check_rc=None, close_fds=False, executable=None, run_in_check_mode=False, encoding='utf-8', errors='surrogate_then_replace', data=None, binary_data=False):
            """ Return some dummy output for the specified command """
            if '--print' in args:
                out = 'Current: =ep\n'
            else:
                out = '/usr/bin/capsh --print\n'
            return

# Generated at 2022-06-20 18:58:05.977752
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: pass in test methods to determine order of execution of test methods
    def mock_capsh_path():
        return None

    def mock_execute_command():
        return (0, 'Current: =ep BOUNDING CapInh CapPrm CapEff', '')

    mock_module = type('', (object,), dict(run_command=mock_execute_command, get_bin_path=mock_capsh_path))

    obj = SystemCapabilitiesFactCollector()
    collected_facts = dict(collector=dict())

    for fact in obj._fact_ids:
        result = obj.collect(module=mock_module, collected_facts=collected_facts)
        assert collected_facts['collector']['caps'] == result

# Generated at 2022-06-20 19:00:16.357515
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'

# Generated at 2022-06-20 19:00:25.029604
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 19:00:32.633393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # set up values needed by the method 'collect'
    # FIXME this method is OS-specific, not generic -akl
    set_module_args = {'path': '/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin'}

    # construct a mock for the module
    fake_module = type('AnsibleModule',
                       (),
                       {
                           "run_command": run_command,
                           "get_bin_path": get_bin_path
                       }
                       )
    # set the return value for the mocked method 'run_command'
    run_command.return_value = (0,
                                "Current: =ep",
                                "")
    # set the return value for the mocked method 'get_bin_path'
    get_bin_path

# Generated at 2022-06-20 19:00:36.995341
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector(None)

    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 19:00:45.361846
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import ansible_local
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    import sys
    import os

    # NOTE: mocked to behave like the linux & macOS versions -akl
    class my_module:
        def __init__(self):
            self.params = {}
            self.paths = ['/bin', '/sbin', '/usr/bin', '/usr/sbin']
            self.facts = {}
            self.fail_json = lambda **kw: sys.exit(1)
            self.warn = lambda msg: 'WARN: %s' % msg
            self.file_exists

# Generated at 2022-06-20 19:00:48.274355
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """Test for constructor"""

    c = SystemCapabilitiesFactCollector()
    assert c is not None


# Generated at 2022-06-20 19:00:54.724208
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    try:
        SystemCapabilitiesFactCollector()
    except Exception:
        raise AssertionError('fail to instantiate class')
    try:
        SystemCapabilitiesFactCollector().collect()
    except Exception:
        raise AssertionError('fail to collect facts')

# Generated at 2022-06-20 19:01:04.225765
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Create an empty module
    module = type('module', (), {})()
    
    # Create an object of class SystemCapabilitiesFactCollector
    obj = SystemCapabilitiesFactCollector()

    # Check if the class SystemCapabilitiesFactCollector instance has the attributes name and _fact_ids
    assert hasattr(obj, 'name')
    assert hasattr(obj, '_fact_ids')

    # Check if the class SystemCapabilitiesFactCollector instance has the method collect
    assert hasattr(obj, 'collect')
