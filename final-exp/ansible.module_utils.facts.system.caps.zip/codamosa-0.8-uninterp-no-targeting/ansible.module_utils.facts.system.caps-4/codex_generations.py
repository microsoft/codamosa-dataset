

# Generated at 2022-06-20 18:51:05.071558
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass  # stub for now

# Generated at 2022-06-20 18:51:09.576607
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids == set(['system_capabilities',
                                                             'system_capabilities_enforced'])



# Generated at 2022-06-20 18:51:13.226245
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}



# Generated at 2022-06-20 18:51:13.791319
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:16.733908
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert isinstance(c._fact_ids, set)
    assert c._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

# Generated at 2022-06-20 18:51:24.781051
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    class MockModule:
        def get_bin_path(self, arg):
            return 'path/to/capsh'
        def run_command(self, arg, **kwargs):
            if arg == ['path/to/capsh', '--print']:
                return 0, 'Current: =ep', None

    module = MockModule()
    result = SystemCapabilitiesFactCollector.collect(module)
    assert result == {'system_capabilities': [],
                      'system_capabilities_enforced': 'False'}

# Generated at 2022-06-20 18:51:30.119772
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_dict = {}
    capsh_path = '/usr/bin/capsh'
    out = "Current:\n=ep"
    enforced = 'False'
    enforced_caps = []
    facts_dict['system_capabilities_enforced'] = enforced
    facts_dict['system_capabilities'] = enforced_cap
    fact_collector = SystemCapabilitiesFactCollector
    assert fact_collector.collect(caps_path, facts_dict) == {}

# Generated at 2022-06-20 18:51:30.998689
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:51:39.076245
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    class MockModule:
        def get_bin_path(self, name):
            return capsh_path

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return rc, out, err


# Generated at 2022-06-20 18:51:40.403411
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    unittest.main()

# Generated at 2022-06-20 18:51:46.963371
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """ This is a redundant test. I just want to ensure the class constructor
    works as expected.
    """
    obj = SystemCapabilitiesFactCollector()
    assert obj.__class__.__name__ == 'SystemCapabilitiesFactCollector'


# Generated at 2022-06-20 18:51:55.298203
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    ansible_version = '2.9'
    system_capabilities_enforced = 'True'

# Generated at 2022-06-20 18:51:58.121118
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:52:02.351721
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: mock out all methods except constructor
    class_instance = SystemCapabilitiesFactCollector()
    assert class_instance.name == 'caps'
    assert len(class_instance._fact_ids) == 2
    assert 'system_capabilities' in class_instance._fact_ids
    assert 'system_capabilities_enforced' in class_instance._fact_ids

# Generated at 2022-06-20 18:52:07.709393
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.utils.path import which
    from ansible.module_utils.facts import collector
    from ansible.module_utils.six import PY3

    if not which('capsh'):
        pytest.skip("capsh command not found")

    test_collected_facts = collector.CollectedFacts()
    test_collector = SystemCapabilitiesFactCollector(module=None)

    # Verify that when capsh command is found and returns data that
    # the collectors method 'collect' stores that data in the correct
    # dictionary keys in the 'ansible_facts' dictionary.
    test_facts = test_collector.collect(module=module_mock_base_command(),
                                        collected_facts=test_collected_facts)
    assert 'system_capabilities' in test_facts

# Generated at 2022-06-20 18:52:16.924164
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class TestModule:
        def __init__(self):
            self.path = '/bin'
            self.params = {}

        def get_bin_path(self, binary):
            return self.path

        def run_command(self, binary, errors):
            return 0, 'Current: =ep Permitted: =ep', ''


    assert SystemCapabilitiesFactCollector.name == 'caps'

    test_instance = SystemCapabilitiesFactCollector()
    assert test_instance.name == 'caps'
    assert test_instance._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}

    test_module = TestModule()
    assert test_instance.collect(test_module) == {
        "system_capabilities_enforced": 'False',
        "system_capabilities": []}

# Generated at 2022-06-20 18:52:20.683154
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Construct TestModule
    # It is not possible to test this method as it relies on a command that is not always available on the system.
    # As the method does not do anything if the command is not available, it will succeed.
    # This can be seen as a success.
    pass

# Generated at 2022-06-20 18:52:28.626082
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils import basic

    module = AnsibleModuleStub(basic)
    capsh_path = module.get_bin_path('capsh')
    f = SystemCapabilitiesFactCollector(module)
    result = f.collect()
    if capsh_path:
        assert 'system_capabilities' in result
        assert 'system_capabilities_enforced' in result
    else:
        assert 'system_capabilities' not in result
        assert 'system_capabilities_enforced' not in result

# Generated at 2022-06-20 18:52:30.463176
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert 'system_capabilities' in SystemCapabilitiesFactCollector._fact_ids

# Generated at 2022-06-20 18:52:33.404704
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set([
        'system_capabilities',
        'system_capabilities_enforced'
    ])

# Generated at 2022-06-20 18:52:37.393758
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:52:38.213089
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'

# Generated at 2022-06-20 18:52:39.708601
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name is not None
    assert obj._fact_ids is not None

# Generated at 2022-06-20 18:52:43.820530
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Test get_caps_data

    # I don't know how to mock out module.run_command()
    # But since it's a method in derived class of BaseFactCollector
    # I'll simply move it and related code to a class method and
    # can mock that out for unit testing.

    # Test capsh does not exist
    facts = {}
    obj = SystemCapabilitiesFactCollector()
    obj.get_caps_data(facts, 'module')
    assert('system_capabilities' not in facts)
    assert('system_capabilities_enforced' not in facts)

    # Test capsh exists, but is not found, etc.
    pass


# Generated at 2022-06-20 18:52:55.204988
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3, b


# Generated at 2022-06-20 18:53:00.334094
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    # ARRANGE
    fact_collector = SystemCapabilitiesFactCollector()
    # ACT
    dic = fact_collector.collect()
    # ASSERT
    assert len(dic) == 2
    assert 'system_capabilities' in dic
    assert 'system_capabilities_enforced' in dic

# Generated at 2022-06-20 18:53:05.576990
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # NOTE: -> get_caps_data()/parse_caps_data() for easier mocking -akl
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities',
                                            'system_capabilities_enforced'])

# Generated at 2022-06-20 18:53:08.282680
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    result = SystemCapabilitiesFactCollector()
    assert isinstance(result, SystemCapabilitiesFactCollector)
    assert isinstance(result._fact_ids, set)
    assert result.name == 'caps'

# Generated at 2022-06-20 18:53:19.655419
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # setup
    module = Mock()
    module.run_command.return_value = (0, "Current: =ep\nBounding set =cap_chown,cap_dac_override,cap_sys_admin,cap_setgid,cap_setuid\nSecurebits: 00/0x0/1'b0\n secure-noroot: no (unlocked)\n secure-no-suid-fixup: no (unlocked)\n secure-keep-caps: no (unlocked)\nuid=0(root) gid=0(root) groups=0(root)\n", '')
    module.get_bin_path.return_value = '/bin/capsh'
    # execute
    result = SystemCapabilitiesFactCollector().collect(module=module, collected_facts={})
    # verify

# Generated at 2022-06-20 18:53:30.386917
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible.module_utils.facts.capabilities import SystemCapabilitiesFactCollector
    from ansible.utils.path import unfrackpath
    import os

    # Create a test module
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)
    # Create a test class instance
    collector = SystemCapabilitiesFactCollector()

    def set_mock_run_command(mock_run_command):
        module.run_command = mock_run_command

    # Test with a mocked run_command

# Generated at 2022-06-20 18:53:38.383003
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert isinstance(SystemCapabilitiesFactCollector(),
                      BaseFactCollector)


# Generated at 2022-06-20 18:53:42.773362
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    """
    Test SystemCapabilitiesFactCollector constructor
    """
    fact = SystemCapabilitiesFactCollector()
    assert fact.name == 'caps'
    assert set(fact._fact_ids) == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-20 18:53:47.055171
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemcapabilities = SystemCapabilitiesFactCollector()
    assert systemcapabilities is not None
    assert systemcapabilities.name == 'caps'
    #assert len(systemcapabilities._fact_ids) == 2
    assert isinstance(systemcapabilities._fact_ids,set)

# Generated at 2022-06-20 18:53:59.149089
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import ModuleUtilsLegacy
    module = ModuleUtilsLegacy("stdin_path", "stdout_path")
    module.run_command = lambda args, **kwargs: (0, to_bytes("Current: = \n"), to_bytes(""))
    module.get_bin_path = lambda name: "/usr/bin/capsh"
    f = SystemCapabilitiesFactCollector(module).collect()
    assert f['system_capabilities_enforced'] == 'False'
    assert f['system_capabilities'] == []
    # Test with enforced capabilities

# Generated at 2022-06-20 18:54:02.256261
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {
             'system_capabilities',
             'system_capabilities_enforced'}

# Generated at 2022-06-20 18:54:07.482229
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test values for SystemCapabilitiesFactCollector.name and
    # SystemCapabilitiesFactCollector._fact_ids
    name = 'caps'
    _fact_ids = set(['system_capabilities',
                     'system_capabilities_enforced'])
    expected_output = (name, _fact_ids)
    test_object = SystemCapabilitiesFactCollector()
    actual_output = (test_object.name, test_object._fact_ids)
    assert(expected_output == actual_output)

# Generated at 2022-06-20 18:54:10.748737
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert instance.name == 'caps'
    assert instance._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:11.767610
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    SystemCapabilitiesFactCollector().collect()

# Generated at 2022-06-20 18:54:20.118848
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """
    Unit test all methods of class SystemCapabilitiesFactCollector
    """
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system.caps import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system.caps import test_SystemCapabilitiesFactCollector_collect
    from ansible.module_utils.facts import Collector

    # Test collector class
    assert issubclass(SystemCapabilitiesFactCollector, BaseFactCollector)

    # Test method collect
    facts_dict = {}
    assert isinstance(SystemCapabilitiesFactCollector.collect(None, facts_dict), dict)



# Generated at 2022-06-20 18:54:21.614806
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()

    assert collector is not None

# Generated at 2022-06-20 18:54:41.797988
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = MockAnsibleModule()
    capsh_path = module.get_bin_path('capsh')
    if capsh_path:
        rc, out, err = module.run_command([capsh_path, "--print"], errors='surrogate_then_replace')
        enforced_caps = []
        enforced = 'NA'
        for line in out.splitlines():
            if len(line) < 1:
                continue
            if line.startswith('Current:'):
                if line.split(':')[1].strip() == '=ep':
                    enforced = 'False'
                else:
                    enforced = 'True'
                    enforced_caps = [i.strip() for i in line.split('=')[1].split(',')]

        assert enforced == 'True'

# Generated at 2022-06-20 18:54:44.084861
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-20 18:54:46.470827
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    x = SystemCapabilitiesFactCollector()
    assert isinstance(x, SystemCapabilitiesFactCollector)
    assert x.name == 'caps'

# Generated at 2022-06-20 18:54:51.126197
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    o = SystemCapabilitiesFactCollector()
    assert isinstance(o, SystemCapabilitiesFactCollector)
    assert o.name == 'caps'
    assert o._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-20 18:54:54.495501
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facter = SystemCapabilitiesFactCollector()
    assert facter.name == 'caps'
    assert facter._fact_ids == set(['system_capabilities',
                                    'system_capabilities_enforced'])



# Generated at 2022-06-20 18:54:58.119467
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test call of constructor with mandatory arguments
    result = SystemCapabilitiesFactCollector()
    assert result._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:55:00.360612
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    cpfact = SystemCapabilitiesFactCollector()
    assert cpfact.name == 'caps'

if __name__ == '__main__':
    test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:03.398969
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:55:07.499775
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts = dict()
    fact_collector = SystemCapabilitiesFactCollector()
    assert fact_collector.name == 'caps'
    assert fact_collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:55:17.213573
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    """Test AnsibleModule's run_command method"""

    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.collectors.system.system_capabilities as m_system

    # Create a dummy AnsibleModule
    am = ansible_collector.AnsibleModuleStub(
        name='TestSystemCapabilitiesFactCollector',
        argspec={}
    )

    # Add the method being tested
    m_system.AnsibleModule = am

    # Create the actual collector
    t = SystemCapabilitiesFactCollector()

    # Call the method being tested
    test_result = t.collect()

    # Test the result
    am.run_command.assert_called_once_with(["capsh", "--print"], errors='surrogate_then_replace')
   

# Generated at 2022-06-20 18:55:49.879032
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Create the SystemCapabilitiesFactCollector instance
    system_caps = SystemCapabilitiesFactCollector()

    # Run the collect method
    result = system_caps.collect()

    # Return the results of the method
    return result

# Generated at 2022-06-20 18:55:51.082854
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert isinstance(obj, SystemCapabilitiesFactCollector)

# Generated at 2022-06-20 18:55:57.018773
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_class

    collector = get_collector_class(Collector.collectors[2])
    systemcapabilities_fc = SystemCapabilitiesFactCollector()

    # Unit test to assert that collect method returns a dictionary
    assert isinstance(systemcapabilities_fc.collect(), dict)


# Generated at 2022-06-20 18:55:59.629478
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    c = SystemCapabilitiesFactCollector()
    assert c.name == 'caps'
    assert c._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:10.143352
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import pytest

    module = pytest.Mock()
    module.run_command = pytest.Mock(return_value='{"msg": "hello"}')
    mod_ret = {
        'rc': 0,
        'out': 'Current: =ep',
        'err': ''
    }
    module.run_command = pytest.Mock(return_value=mod_ret)

    collected_facts = {}

    obj = SystemCapabilitiesFactCollector()

    assert obj.name == 'caps'

    facts = obj.collect(module=module, collected_facts=collected_facts)

    assert facts['system_capabilities_enforced'] == 'False'
    assert facts['system_capabilities'] == []


# Generated at 2022-06-20 18:56:19.910789
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
# Create a system capabilities fact collector
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])
# Create a dummy module instance
    class TestModule:
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return "/usr/bin/capsh"

# Generated at 2022-06-20 18:56:30.203421
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Verify that the constructor throws an exception if not given a module argument
    try:
      SystemCapabilitiesFactCollector()
      assert False, "Should raise exception when not given a module"
    except:
      pass

    module = type('test', (object,), {})
    # Verify that the constructor throws an exception if not given a module argument
    try:
      SystemCapabilitiesFactCollector(module)
      assert False, "Should raise exception when not given a module"
    except:
      pass

    module = type('test', (object,), {})
    # Verify that the constructor throws an exception if not given a module argument
    try:
      SystemCapabilitiesFactCollector(module)
      assert False, "Should raise exception when not given a module"
    except:
      pass

# Generated at 2022-06-20 18:56:40.057956
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: use a mock module rather than the actual module, so that it can
    #       be used in unit tests (ie. *not* on real systems -akl)
    module_mock = MockModule()
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = '/bin/capsh'
    # NOTE: need to mock module.get_bin_path() to return '/bin/capsh'
    #       so that the condition 'if capsh_path:' is True -akl


# Generated at 2022-06-20 18:56:49.747211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector


# Generated at 2022-06-20 18:56:54.830114
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    print('Executing test_SystemCapabilitiesFactCollector:')
    collector = SystemCapabilitiesFactCollector()
    print('    SystemCapabilitiesFactCollector initialized.')

# Execute test
test_SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:58:02.817990
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector()
    assert scfc.name == 'caps'
    assert scfc._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:58:12.241642
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    collector = SystemCapabilitiesFactCollector()

    temp_dir = tempfile.mkdtemp()
    temp_file = temp_dir + '/capsh'
    fake_content = 'Content of capsh-script'
    f = open(temp_file, 'w')
    f.write(fake_content)
    f.close()
    os.chmod(temp_file, 0o755)

    # fact doesn't exist

# Generated at 2022-06-20 18:58:12.752371
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:58:16.524063
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    system_capability_collector = SystemCapabilitiesFactCollector()
    assert system_capability_collector is not None
    assert system_capability_collector.name == 'caps'
    assert system_capability_collector._fact_ids == set(['system_capabilities',
                                                         'system_capabilities_enforced'])

# Generated at 2022-06-20 18:58:23.037954
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            if name == 'capsh':
                # Return path to mock capsh.
                return self.params.get('capsh_path', None)

        def run_command(self, cmd, errors):
            return self.params['run_command_result']

    class MockFacts(dict):
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict
            super(MockFacts, self).__init__()

        def __getitem__(self, item):
            return self.facts_dict[item]

        def __setitem__(self, name, value):
            self.facts_dict[name] = value


# Generated at 2022-06-20 18:58:33.314100
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:58:39.478092
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system.system_capabilities import SystemCapabilitiesFactCollector
    from ansible.module_utils.facts.collector.system.system_capabilities import CapshDataParseError
    from ansible.module_utils.facts import FactCollectorCache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    base_fact_collector = BaseFactCollector(module)
    fact_collector_cache = FactCollectorCache(base_fact_collector)
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector(module, fact_collector_cache)
    system_caps = system_capabilities_fact_collector.collect()

# Generated at 2022-06-20 18:58:49.474349
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # Setup test
    scope = {}
    scope['capsh_path'] = '/usr/bin/capsh'
    scope['awk_path'] = '/usr/bin/awk'
    scope['system_capabilities'] = ['= cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_net_bind_service,cap_net_raw,cap_sys_chroot,cap_mknod,cap_audit_write,cap_setfcap+ep']
    scope['system_capabilities_enforced'] = ['True']

    # Run test
    test_obj = SystemCapabilitiesFactCollector()
    x = test_obj.collect(module=scope)

# Generated at 2022-06-20 18:58:56.604675
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()

    assert isinstance(instance, SystemCapabilitiesFactCollector)
    assert hasattr(instance, 'name')
    assert instance.name == 'caps'
    assert hasattr(instance, 'collect')
    assert callable(instance.collect)
    assert hasattr(instance, '_fact_ids')
    assert isinstance(instance._fact_ids, set)
    assert len(instance._fact_ids) == 2
    assert 'system_capabilities' in instance._fact_ids
    assert 'system_capabilities_enforced' in instance._fact_ids

# Generated at 2022-06-20 18:58:58.219971
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Test a successful instantiation of the class SystemCapabilitiesFactCollector
    assert SystemCapabilitiesFactCollector().name == 'caps'