

# Generated at 2022-06-20 18:51:10.614974
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:12.885048
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    '''
    Unit test function
    :return:
    '''
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    return

# Generated at 2022-06-20 18:51:20.281810
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    #
    # Initialization
    #
    module = ansible.module_utils.facts.collectors.linux.capsh.SystemCapabilitiesFactCollector()
    #
    # Test 1: capsh not available
    #
    fact_names = module.collect(collected_facts=None)
    #assert fact_name in fact_names
    #
    # Test 2: capsh available
    #
    fact_names = module.collect(collected_facts=None)
    #assert fact_name in fact_names
    #

# Generated at 2022-06-20 18:51:21.511270
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector

# Generated at 2022-06-20 18:51:31.199436
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mc = SystemCapabilitiesFactCollector()
    module = AnsibleModule(
        argument_spec=dict(
            ansible_system_capabilities='(list) capabilities of the current user',
            ansible_system_capabilities_enforced='(Bool) capabiliies enforced',
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 18:51:37.817614
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:51:48.804329
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    import sys

# Generated at 2022-06-20 18:51:52.390715
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sys_caps = SystemCapabilitiesFactCollector()
    assert sys_caps.name == 'caps'
    assert sys_caps._fact_ids == set(['system_capabilities',
                                      'system_capabilities_enforced'])



# Generated at 2022-06-20 18:52:02.114605
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector.system.capsh import SystemCapabilitiesFactCollector

    capsh_act = '/usr/bin/capsh'

    module = AnsibleModule(
        argument_spec = {},
        supports_check_mode = False
    )
    module.run_command = lambda cmd, check, environ_update, stdin, stdin_add_newline, chunked: ['NA']
    collector = SystemCapabilitiesFactCollector(module=module)
    assert collector.collect() == {}

    module = AnsibleModule(
        argument_spec = {},
        supports_check_mode = False
    )

# Generated at 2022-06-20 18:52:04.503149
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    system_cap_facts_collector = SystemCapabilitiesFactCollector()

    # Check name and _fact_ids are initialized properly
    assert system_cap_facts_collector.name == 'caps'
    assert len(system_cap_facts_collector._fact_ids) == 2

# Generated at 2022-06-20 18:52:16.616772
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # We need to mock the facts class, so create a local import
    import ansible.module_utils.facts.system.caps
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector
    import ansible.module_utils.facts

    # Create a dummy class to mock the ansible module, and add it to the module_utils
    # so when we import we can get the mocked version
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            pass
        @staticmethod
        def run_command(cmd, errors='surrogate_then_replace'):
            return (0, 'Current: =ep\n', '')
        @staticmethod
        def get_bin_path(bin, required=False):
            return '/sbin/capsh'

   

# Generated at 2022-06-20 18:52:19.118612
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Create an instance of class SystemCapabilitiesFactCollector
    caps_facts = SystemCapabilitiesFactCollector()
    assert caps_facts.name == 'caps'

# Generated at 2022-06-20 18:52:21.424432
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])



# Generated at 2022-06-20 18:52:24.836659
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    myCapFact =  SystemCapabilitiesFactCollector()
    assert myCapFact.name == 'caps'
    assert myCapFact._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:52:33.554612
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collectors_names
    from ansible.module_utils.facts.collector import get_all_fact_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors

    # Build a dict of dict with the results of each collector
    facts_dict_expected = {
        'system_capabilities': [],
        'system_capabilities_enforced': 'NA', 
    }

    # Get an instance of 'SystemCapabilitiesFactCollector' class
    c = get_collector_instance('SystemCapabilitiesFactCollector')

# Generated at 2022-06-20 18:52:43.235157
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils._text import to_bytes as to_bytes_mock
    from ansible.module_utils.basic import AnsibleModuleMock
    from ansible.module_utils.six.moves.builtins import mock

    m = AnsibleModuleMock(exit_json=exit_json_mock)
    m.run_command = run_command_mock
    m.get_bin_path = get_bin_path_mock
    m.to_bytes = to_bytes_mock
    m.ansible_module = AnsibleModule

    sut = SystemCapabilitiesFactCollector()
    result = sut.collect(module=m)

# Generated at 2022-06-20 18:52:54.254345
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    '''unit test for the SystemCapabilitiesFactCollector, for collect() method '''
    from ansible.module_utils.facts.collector import BaseFactCollector
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(name='run_command')
    module.run_command.return_value = 0, 'Current:=ep', None
    module.get_bin_path = MagicMock()
    SystemCapabilitiesFactCollector.name = 'caps'
    SystemCapabilitiesFactCollector._fact_ids = set(['system_capabilities',
                                                     'system_capabilities_enforced'])
    module.get_bin_path.return_value = '/bin/capsh'
    test_obj = SystemCapabilitiesFactCollector(module=module)

# Generated at 2022-06-20 18:53:05.529437
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import mock
    import pickle

    facts_dict = {}
    module = mock.MagicMock()

    module.get_bin_path.return_value = True

# Generated at 2022-06-20 18:53:09.144751
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    facts_collector = SystemCapabilitiesFactCollector()
    assert facts_collector.name == 'caps'
    assert facts_collector._fact_ids == set(['system_capabilities',
                                             'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:20.045575
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCapabilitiesFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content

    # Prepare mock data
    test_data_dir = '%s/unit/ansible_collections/ansible/community/plugins/module_utils/facts/system/' \
                    'test_data/SystemCapabilitiesFactCollector' % os.getcwd()
    capsh_output = get_file_content(test_data_dir + os.sep + 'capsh_output')

    # Mock AnsibleModule
    am = AnsibleModule()
    am.run_command = MagicMock(return_value=(0, capsh_output, ''))
    am.get_bin_path

# Generated at 2022-06-20 18:53:28.450387
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    x = SystemCapabilitiesFactCollector()
    assert x.name == 'caps'
    assert x._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:30.097911
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    s = SystemCapabilitiesFactCollector()
    assert s is not None
    assert s.name == 'caps'

# Generated at 2022-06-20 18:53:33.685760
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():

    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:37.663978
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector(None)
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])


# Generated at 2022-06-20 18:53:45.803468
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: this is not a real unit test, it needs capsh --print output
    # to be available.
    module = Mock()
    module.run_command = Mock(return_value=(0, '...', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/capsh')
    module.params = {'gather_subset': ['all']}
    collected_facts = {}
    facts = SystemCapabilitiesFactCollector()
    facts.collect(module=module, collected_facts=collected_facts)

    assert 'system_capabilities_enforced' in collected_facts
    assert collected_facts['system_capabilities_enforced'] in ('True', 'False', 'NA')
    assert 'system_capabilities' in collected_facts

# Generated at 2022-06-20 18:53:49.899637
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert 'system_capabilities' in obj._fact_ids
    assert 'system_capabilities_enforced' in obj._fact_ids
    assert obj._fact_ids.__len__() == 2

# Generated at 2022-06-20 18:53:51.283156
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:53:53.859211
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    assert system_capabilities_fact_collector.name == 'caps'

# Generated at 2022-06-20 18:53:58.199728
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == set(['system_capabilities',
                                       'system_capabilities_enforced'])
    # NOTE: test collect() via integration tests. -akl

# Generated at 2022-06-20 18:54:02.952550
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    import pytest
    a = SystemCapabilitiesFactCollector()
    assert isinstance(a,SystemCapabilitiesFactCollector)
    assert a.name is not None
    # NOTE: _fact_ids is None if 'name' is None ??
    assert a._fact_ids is not None
    # NOTE: _fact_ids is set not check set content (??)
    #assert len(a._fact_ids) == 2
    # NOTE: _fact_ids is set check set content (??)
    assert isinstance(a._fact_ids, set)
    assert 'system_capabilities' in a._fact_ids
    assert 'system_capabilities_enforced' in a._fact_ids
    # NOTE: _fact_ids is set check set content (??)
    with pytest.raises(KeyError):
        a._fact_

# Generated at 2022-06-20 18:54:17.168159
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = get_mock_module("capsh")
    capsh_path = module.get_bin_path('capsh')
    module.run_command = get_mock_run_command(capsh_path)
    f = SystemCapabilitiesFactCollector(module=module)
    facts = f.collect()
    assert facts 
    # NOTE: is this really a good test? [0] and [1] should be fixed... -akl
    assert facts['system_capabilities'][0] == 'cap_sys_boot'
    assert facts['system_capabilities'][1] == 'cap_sys_time'
    assert facts['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-20 18:54:23.552516
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system.caps

    if sys.version_info[0] == 2:
        builtin_open = '__builtin__.open'
    else:
        builtin_open = 'builtins.open'

    class MockModule():
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'capsh':
                return '/usr/bin/capsh'
            return ''


# Generated at 2022-06-20 18:54:26.450426
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    test_instance = SystemCapabilitiesFactCollector()
    assert test_instance.name == 'caps'
    assert test_instance._fact_ids == set(['system_capabilities', 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:35.941358
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    def test_run(cmd, errors='surrogate_then_replace'):
        rc = 0
        out = '''Current: =ep
CapInh: =
CapPrm: =
CapEff: =
CapBnd: =
CapAmb: =
'''
        err = ''
        return rc, out, err

    module                  = Mock()
    module.get_bin_path.return_value = capsh_path = '/bin/capsh'
    module.run_command.side_effect    = test_run

    bfc = BaseFactCollector

    bfc.module                  = module
    bfc.load_from_module        = Mock()
    bfc.run_command

# Generated at 2022-06-20 18:54:44.118410
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    test_host = {
        'caps': {
            'system_capabilities': ['CAP_CHOWN', 'CAP_DAC_OVERRIDE'],
            'system_capabilities_enforced': "False"
        }
    }
    test_module = FakeAnsibleModule(test_host)
    test_module.params = {"filter": "ansible_system_capabilities"}
    test_module.run_command = run_command_mock
    result = SystemCapabilitiesFactCollector(test_module).collect()
    assert result == {'system_capabilities': ['CAP_CHOWN', 'CAP_DAC_OVERRIDE'],
                      'system_capabilities_enforced': 'False'}


# Generated at 2022-06-20 18:54:47.831907
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:54:58.968665
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:55:05.369836
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    class notAModule(object):
        def __init__(self):
            self.path = '/bin/'
        def get_bin_path(self, name):
            return self.path + name
    assert SystemCapabilitiesFactCollector({'system_capabilities':[], 'system_capabilities_enforced':'False'}).collect(notAModule())
    o = notAModule()
    o.path = '/no/bin/'
    assert SystemCapabilitiesFactCollector({'system_capabilities':[], 'system_capabilities_enforced':'NA'}).collect(o)


# Generated at 2022-06-20 18:55:07.697127
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    col = SystemCapabilitiesFactCollector()
    assert col.name == 'caps'

# Generated at 2022-06-20 18:55:17.337340
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # Get a singleton instance of SystemCapabilitiesFactCollector
    caps_collector = SystemCapabilitiesFactCollector()
    # Make sure the name attribute of the instance is set to the specified value
    assert caps_collector.name == 'caps'
    # Make sure the _fact_ids attribute of the instance is set to the specified value
    # NOTE: would have preferred to do a set comparison here, but this would have
    #       required specifying the ordering of the elements in _fact_ids, which
    #       is not ideal. So, instead, this is being tested as if it was a set
    #       (unordered) comparison. This should be fine because the ordering of
    #       the elements in _fact_ids doesn't matter.
    assert len(caps_collector._fact_ids) == 2
    assert 'system_capabilities' in caps_collect

# Generated at 2022-06-20 18:55:40.291211
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import sys
    if sys.version_info.major < 3:
        import mock
    else:
        from unittest import mock
    module = mock.MagicMock()

    # Neither capsh nor acct present
    module.get_bin_path.return_value = None
    result = SystemCapabilitiesFactCollector().collect(module=module)
    assert not result['system_capabilities']
    assert result['system_capabilities_enforced'] == 'NA'

    # capsh is present, unrable to run
    module.get_bin_path.return_value = '/bin/capsh'
    module.run_command.return_value = (1, '', 'capsh: sys_capset failed')
    result = SystemCapabilitiesFactCollector().collect(module=module)

# Generated at 2022-06-20 18:55:43.714043
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    collector = SystemCapabilitiesFactCollector()
    assert collector.name == 'caps'
    assert collector._fact_ids == {'system_capabilities', \
                                   'system_capabilities_enforced'}

# Generated at 2022-06-20 18:55:44.672628
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()

# Generated at 2022-06-20 18:55:46.204596
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    instance = SystemCapabilitiesFactCollector()
    assert isinstance(instance, SystemCapabilitiesFactCollector)

# Generated at 2022-06-20 18:55:47.662961
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'

# Generated at 2022-06-20 18:55:49.074495
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:55:57.972691
# Unit test for method collect of class SystemCapabilitiesFactCollector

# Generated at 2022-06-20 18:55:59.932958
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    assert SystemCapabilitiesFactCollector.name == 'caps'
    assert SystemCapabilitiesFactCollector._fact_ids, set(['system_capabilities',
                                                           'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:06.218863
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.caps import SystemCapabilitiesFactCollector

    fact_collector = SystemCapabilitiesFactCollector(BaseFactCollector)
    fact_collector.get_caps_data = lambda: ([], None, None)
    fact_collector.parse_caps_data = lambda caps_data: ''

    fact_collector.collect()



# Generated at 2022-06-20 18:56:17.002822
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.urls.fetch
    import ansible.module_utils.urls.basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import open_url
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()


# Generated at 2022-06-20 18:56:48.852197
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    coll = SystemCapabilitiesFactCollector()
    assert coll.name == 'caps'
    assert coll._fact_ids == set(['system_capabilities',
                     'system_capabilities_enforced'])

# Generated at 2022-06-20 18:56:50.920817
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    scfc = SystemCapabilitiesFactCollector(None)
    assert scfc.name == 'caps'
    assert scfc._fact_ids == {'system_capabilities', 'system_capabilities_enforced'}
    assert scfc.collect() == {}

# Generated at 2022-06-20 18:56:53.564479
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: needs mocking for proper unit testing
    assert True

# Generated at 2022-06-20 18:56:54.481617
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    SystemCapabilitiesFactCollector()


# Generated at 2022-06-20 18:57:03.995062
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    import os
    import sys
    import unittest

    class SystemCapabilitiesFactCollectorMockModule:
        def __init__(self):
            self.facts = {}
            self.params = {}

        def exit_json(self, ansible_facts, **kwargs):
            self.facts = ansible_facts

        def fail_json(self, msg, **kwargs):
            self.exit(msg)

    # Make sure we have capsh on this system
    if not os.access("/usr/bin/capsh", os.X_OK):
        raise unittest.SkipTest(
            "Skipping SystemCapabilitiesFactCollector due to missing capsh on this system")

    mymodule = SystemCapabilitiesFactCollectorMockModule()
    c = SystemCapabilitiesFactCollector(mymodule)
    test_facts

# Generated at 2022-06-20 18:57:07.664748
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    sut = SystemCapabilitiesFactCollector()
    assert set(sut.collect_methods.keys()) == sut._fact_ids
    assert sut.name == 'caps'


# Generated at 2022-06-20 18:57:16.302600
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    module = AnsibleModuleMock(**{
        'run_command.return_value': (0, "Current: =ep\nBounding set =ep cap_kill cap_net_bind_service cap_net_raw+eip cap_setfcap+eip cap_setgid+eip cap_setuid+eip cap_sys_chroot+eip cap_sys_ptrace+eip cap_sys_admin+eip ", ''),
        'get_bin_path.return_value': 'capp_command_path',
    })
    fact_collector = SystemCapabilitiesFactCollector(module)
    result = fact_collector.collect(module, {})
    assert result['system_capabilities_enforced'] == 'False'
    assert result['system_capabilities'] == []

# Generated at 2022-06-20 18:57:21.128707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():

    collector = SystemCapabilitiesFactCollector()
    caps = collector.collect(module=None, collected_facts=None)
    assert caps['system_capabilities'] == ['cap_chown', 'cap_dac_override', 'cap_dac_read_search', 'cap_fowner', 'cap_fsetid', 'cap_kill', 'cap_setgid', 'cap_setuid', 'cap_sys_chroot', 'cap_sys_ptrace', 'cap_sys_tty_config', 'cap_mknod', 'cap_audit_write', 'cap_setfcap']
    assert caps['system_capabilities_enforced'] == 'True'

# Generated at 2022-06-20 18:57:28.907043
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: maybe initialize a fake Module class and mock it?
    # Fake Module class not necessary if you mock the run_command method
    caps_path = '/sbin/capsh'
    module = lambda: None
    module.get_bin_path = lambda *args: caps_path
    module.run_command = lambda *args, **kwargs: (0, 'Current: =ep', '')
    facts = SystemCapabilitiesFactCollector().collect(module=module)
    assert facts['system_capabilities'] == []
    assert facts['system_capabilities_enforced'] == 'False'

# Generated at 2022-06-20 18:57:31.435148
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    obj = SystemCapabilitiesFactCollector()
    assert obj.name == 'caps'
    assert obj._fact_ids == set(['system_capabilities',
                                 'system_capabilities_enforced'])

# Generated at 2022-06-20 18:58:38.554782
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    assert True

# Generated at 2022-06-20 18:58:39.035707
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    pass

# Generated at 2022-06-20 18:58:43.317912
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    # object of class SystemCapabilitiesFactCollector
    obj = SystemCapabilitiesFactCollector()
    # compare name variable of class SystemCapabilitiesFactCollector with caps
    assert obj.name == 'caps'


# Generated at 2022-06-20 18:58:47.090014
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    p = SystemCapabilitiesFactCollector()
    assert p.name == 'caps'
    assert p._fact_ids == set(['system_capabilities',
                               'system_capabilities_enforced'])



# Generated at 2022-06-20 18:58:54.513793
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, "Current: =ep", "")
    mock_module.get_bin_path.return_value = "/usr/bin/capsh"
    assert SystemCapabilitiesFactCollector.collect(mock_module) == {
        'system_capabilities_enforced': 'False',
        'system_capabilities': []
    }

# Generated at 2022-06-20 18:59:01.042331
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    # NOTE: make run_command an OK method on the module -akl
    def ok_module():
        def run_command(self, command):
            return 0, 'Current: = cap_setpcap,cap_setfcap+i', None
        return None
    # NOTE: initialize collector
    caps_coll = SystemCapabilitiesFactCollector()
    # NOTE: initialize module
    module = ok_module()
    # NOTE: initialize 'module.run_command' so we can mock it
    module.run_command = ok_module().run_command
    # NOTE: validate response
    assert caps_coll.collect(module) == {'system_capabilities': []}
    # NOTE: delete 'module.run_command' so we can mock it

# Generated at 2022-06-20 18:59:10.282147
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts_utils import MockModule
    import sys

    try:
        import capsh
    except ImportError:
        # capsh module not present, skip test (assume we don't want to run tests with missing dependencies)
        sys.exit()

    module = MockModule({
        'capsh': capsh,
    })
    SystemCapabilitiesFactCollector().collect(module=module)

# Generated at 2022-06-20 18:59:11.857716
# Unit test for constructor of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector():
    systemCapabilitiesFactCollector = SystemCapabilitiesFactCollector()
    assert systemCapabilitiesFactCollector is not None

# Generated at 2022-06-20 18:59:18.150285
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # test inputs
    module = None
    collected_facts = None

    # expected results
    expected = {}

    # code to be tested
    system_capabilities_fact_collector = SystemCapabilitiesFactCollector()
    actual = system_capabilities_fact_collector.collect(module, collected_facts)

    assert expected == actual

# Generated at 2022-06-20 18:59:20.416804
# Unit test for method collect of class SystemCapabilitiesFactCollector
def test_SystemCapabilitiesFactCollector_collect():
    # NOTE: these are done in separate unit tests, to make mocking easier -akl
    pass