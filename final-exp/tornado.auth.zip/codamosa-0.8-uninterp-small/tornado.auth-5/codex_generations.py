

# Generated at 2022-06-26 07:37:05.754029
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    path = "/statuses/update"
    access_token = dict()
    post_args = dict()
    asyncio.get_event_loop().run_until_complete(twitter_mixin_0.twitter_request(
        path, access_token, post_args, ))



# Generated at 2022-06-26 07:37:07.415090
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.authenticate_redirect()


# Generated at 2022-06-26 07:37:18.300749
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    print("test_GoogleOAuth2Mixin_get_authenticated_user")
    o_auth2_mixin_0 = OAuth2Mixin()

# Generated at 2022-06-26 07:37:20.017613
# Unit test for method authorize_redirect of class OAuth2Mixin
def test_OAuth2Mixin_authorize_redirect():
    o_auth2_mixin_0 = OAuth2Mixin()
    o_auth2_mixin_0.authorize_redirect()
    return 


# Generated at 2022-06-26 07:37:22.437872
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    # Create an OpenIdMixin object
    o_auth2_mixin_0 = OpenIdMixin()
    # Call method get_authenticated_user on the OpenIdMixin object
    response = httpclient.HTTPResponse()
    response.body = '{"is_valid":true}'
    user = o_auth2_mixin_0._on_authentication_verified(response)



# Generated at 2022-06-26 07:37:34.004635
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    oauth_mixin_0 = OAuthMixin()
    response_0 = __fake_coroutine(response_0=object())
    body_0 = __fake_coroutine(body_0='"\\u00c3\\u00a5\\u00c3\\u00a5\\u00c3\\u00a5\\u00c3\\u00a5\\u00c3\\u00a5"')
    get_auth_http_client_0 = response_0.body
    oauth_consumer_token_0 = oauth_mixin_0._oauth_consumer_token()

# Generated at 2022-06-26 07:37:44.062204
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():

    class FacebookGraphLoginHandler(object):
        pass

    facebook_graph_login_handler_0 = FacebookGraphLoginHandler()
    facebook_graph_login_handler_0.get_argument = FacebookGraphMixin.get_argument
    facebook_graph_login_handler_0.get_authenticated_user = FacebookGraphMixin.get_authenticated_user
    facebook_graph_login_handler_0.oauth2_request = FacebookGraphMixin.oauth2_request
    facebook_graph_login_handler_0.authorize_redirect = FacebookGraphMixin.authorize_redirect

    # Test 1
    print("Test 1 :")
    print("  -- README Example :")

    print("     -- Test get_authenticated_user :")
    test_get_authenticated_user_1 = test_get_authenticated_user

# Generated at 2022-06-26 07:37:45.313940
# Unit test for method authorize_redirect of class OAuthMixin
def test_OAuthMixin_authorize_redirect():
    o_auth_mixin_0 = OAuthMixin()
    o_auth_mixin_0.authorize_redirect()


# Generated at 2022-06-26 07:37:59.079251
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    # Test cases
    # testcase_0: OAuth2Mixin doesn't exist.
    # testcase_1: FacebookGraphMixin exist
    # testcase_2: success
    # testcase_3: request timeout
    # testcase_4: HTTPError
    # testcase_5: HTTPClientError
    
    fgm = FacebookGraphMixin()
    # testcase_0: OAuth2Mixin doesn't exist

# Generated at 2022-06-26 07:38:03.799668
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    """OAuthMixin.get_authenticated_user()"""
    # Test OAuthMixin.get_authenticated_user()
    oauth_mixin_0 = OAuthMixin()
    try:
        oauth_mixin_0.get_authenticated_user()
    except NotImplementedError:
        pass
    except Exception:
        raise Exception # pragma: no cover


# Generated at 2022-06-26 07:39:10.406409
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    o_auth2_mixin_0 = OAuth2Mixin()
    o_auth2_mixin_0.get_authenticated_user()


# Generated at 2022-06-26 07:39:20.537446
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    facebook_graph_mixin_1 = FacebookGraphMixin()
    facebook_graph_mixin_2 = FacebookGraphMixin()
    facebook_graph_mixin_3 = FacebookGraphMixin()
    facebook_graph_mixin_4 = FacebookGraphMixin()
    facebook_graph_mixin_5 = FacebookGraphMixin()
    facebook_graph_mixin_6 = FacebookGraphMixin()
    facebook_graph_mixin_7 = FacebookGraphMixin()
    facebook_graph_mixin_8 = FacebookGraphMixin()
    facebook_graph_mixin_9 = FacebookGraphMixin()
    facebook_graph_mixin_10 = FacebookGraphMixin()
    facebook_graph_mixin_11 = FacebookGraphMixin()
    facebook_graph_mixin

# Generated at 2022-06-26 07:39:24.006013
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    facebook_graph_mixin_0.facebook_request("path", "access_token", "post_args")

if __name__ == "__main__":
    test_FacebookGraphMixin_facebook_request()
    print("test finished !")

# Generated at 2022-06-26 07:39:28.987974
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    handler = MockRequestHandler()
    oauth1 = OAuth1Mixin()
    oauth1.get_authenticated_user()


# Generated at 2022-06-26 07:39:42.849953
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
  o_auth2_mixin_0 = OAuth2Mixin()
  url_0 = "/test/url"
  access_token_0 = None
  post_args_0 = dict()
  # The first argument is unused. It was added for backwards compatibility.
  return_value_0 = o_auth2_mixin_0.oauth2_request(None, url_0, access_token_0, post_args_0)

  # Check the type of return value
  assert return_value_0 is None
  print("Testcase for method OAuth2Mixin.oauth2_request passed.")

if __name__ == '__main__':
  test_OAuth2Mixin_oauth2_request()

# Generated at 2022-06-26 07:39:48.951985
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    o_auth2_mixin_0 = OAuth2Mixin()
    new_entry = o_auth2_mixin_0.oauth2_request("https://graph.facebook.com/me/feed",post_args={"message": "I am posting from my Tornado application!"},
                                               access_token="1")
    assert isinstance(new_entry, object)


# Generated at 2022-06-26 07:39:56.574601
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    from tornado.httpclient import HTTPClientError
    logging.info("test_OAuth2Mixin_oauth2_request begin\n")
    o_auth2_mixin_1 = OAuth2Mixin()
    try:
        o_auth2_mixin_1.oauth2_request()
    except HTTPClientError as e:
        logging.info("HTTPClientError: \n")
        logging.info(e)
    logging.info("test_OAuth2Mixin_oauth2_request end\n")


# Generated at 2022-06-26 07:40:02.753487
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    t_m_0 = TwitterMixin()
    url = t_m_0._TWITTER_BASE_URL + "/statuses/user_timeline/btaylor" + ".json"
    http_0 = t_m_0.get_auth_http_client()

    # Analyze the response variable
    response = http_0.fetch(url)

    # Invoke the callback function and analyze the result
    tornado.ioloop.IOLoop.instance().run_sync(response)

# Generated at 2022-06-26 07:40:04.197545
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    o_auth2_mixin_0 = OAuth2Mixin()
    o_auth2_mixin_0.oauth2_request()



# Generated at 2022-06-26 07:40:11.020045
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    o_facebook_graph_mixin = FacebookGraphMixin()
    path0 = "path0"
    access_token0 = "access_token0"
    post_args0 = {"key0": "value0"}
    o_facebook_graph_mixin.facebook_request(path=path0, access_token=access_token0, post_args=post_args0)


# Generated at 2022-06-26 07:40:51.967546
# Unit test for method authorize_redirect of class OAuth2Mixin
def test_OAuth2Mixin_authorize_redirect():
    o_auth2_mixin_0 = OAuth2Mixin()
    request_handler_0 = RequestHandler()
    result = o_auth2_mixin_0.authorize_redirect(request_handler_0)
    assert is_instance(result, bool)
    result = o_auth2_mixin_0.authorize_redirect(request_handler_0, 'redirect_uri_0', 'client_id_0', 'client_secret_0', 'extra_params_0', 'scope_0', 'response_type_0')
    assert is_instance(result, bool)


# Generated at 2022-06-26 07:40:54.852460
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    o_auth_mixin_obj = OAuthMixin()
    o_auth_mixin_obj.get_authenticated_user()


# Generated at 2022-06-26 07:41:00.248133
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    o_auth2_mixin_0 = GoogleOAuth2Mixin()
    o_auth2_mixin_0.get_authenticated_user()


# Generated at 2022-06-26 07:41:06.588731
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twi_mix = TwitterMixin()
    twi_mix.authenticate_redirect()
    twi_mix.twitter_request("", {})


# Generated at 2022-06-26 07:41:08.227746
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin = TwitterMixin()
    twitter_mixin.authenticate_redirect()


# Generated at 2022-06-26 07:41:13.345827
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    path = 'example_pass'
    access_token = {'access_token': 'access_token', 'token_secret': 'token_secret'}
    post_args = {'post_key': 'post_value'}
    twitter_request_return_value = twitter_mixin_0.twitter_request(path, access_token, post_args)
    return twitter_request_return_value


# Generated at 2022-06-26 07:41:21.387440
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    o_auth2_mixin_0 = OAuth2Mixin()
    url_0 = ""
    access_token_0 = ""
    post_args_0 = {}
    o_auth2_mixin_0.oauth2_request(url_0, access_token_0, post_args_0)
    # XXX: Return type is not implemented


# Generated at 2022-06-26 07:41:32.133341
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():

    class MockHttpClient():
        async def fetch(self, url: str, **kwargs: Any) -> httpclient.HTTPResponse:
            return httpclient.HTTPResponse([], 200, request_time=0.0, reason='',
                                           body='{"my_key": "my_val"}', effective_url='https://api.twitter.com/1.1/statuses/user_timeline/btaylor.json')

    class MockRequestHandler(RequestHandler):
        def require_setting(self, key: str, feature: str = '') -> None:
            pass

        def settings(self) -> Dict[str, Any]:
            return {"twitter_consumer_key": "my_consumer_key",
                    "twitter_consumer_secret": "my_consumer_secret"}


# Generated at 2022-06-26 07:41:37.613251
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    google_oauth2mixin_0 = GoogleOAuth2Mixin()
    google_oauth2mixin_0.get_authenticated_user(redirect_uri='http://your.site.com/auth/google', code=google_oauth2mixin_0.get_argument('code'))


# Generated at 2022-06-26 07:41:48.761423
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    o_auth_mixin_0 = OAuthMixin()
    path_0 = "http://dev.twitter.com/"
    access_token_0 = {"key": "access_token", "secret": "access_token"}
    args_0 = {"key": "value"}
    test_function_0 = asyncio.coroutine(o_auth_mixin_0.twitter_request)
    future_0 = test_function_0(path_0, access_token_0, **args_0)
    loop_0 = asyncio.get_event_loop()
    result_0 = loop_0.run_until_complete(future_0)
    test_result_0 = {}
    assert result_0 == test_result_0

# Generated at 2022-06-26 07:42:35.344830
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    # test_case_0: This is the case when all the argument values are correct
    # then this function returns the authenticated user data
    open_id_mixin_0 = OpenIdMixin()
    async_h_t_t_p_client_0 = open_id_mixin_0.get_auth_http_client()
    result = open_id_mixin_0.get_authenticated_user(async_h_t_t_p_client_0)
    assert result is not None



# Generated at 2022-06-26 07:42:40.553033
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.authenticate_redirect(callback_uri = None)
    twitter_mixin_0.authenticate_redirect(callback_uri = "vjmgoreboytvzkyt")


# Generated at 2022-06-26 07:42:44.598395
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    http = TwitterMixin()
    async_h_t_t_p_client = http.get_auth_http_client()
    async_future = async_h_t_t_p_client.fetch(http._oauth_request_token_url())
    http._on_request_token(http._OAUTH_AUTHENTICATE_URL, None, async_future)

test_TwitterMixin_authenticate_redirect()


# Generated at 2022-06-26 07:42:48.666420
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    o_a_m_0 = OAuth2Mixin()
    url_0 = str()
    access_token_0 = None # type: Optional[str]
    post_args_0 = None # type: Optional[Dict[str, Any]]
    test_case_0()
    o_a_m_0.oauth2_request(
        url_0,
        access_token_0,
        post_args_0,
    )


# Generated at 2022-06-26 07:42:51.549539
# Unit test for method authorize_redirect of class OAuthMixin
def test_OAuthMixin_authorize_redirect():
    oauth_mixin_0 = OAuthMixin()
    async_h_t_t_p_client_0 = oauth_mixin_0.get_auth_http_client()


# Generated at 2022-06-26 07:43:00.663859
# Unit test for method authorize_redirect of class OAuth2Mixin
def test_OAuth2Mixin_authorize_redirect():
    oauth2_mixin_0 = OAuth2Mixin()
    oauth2_mixin_0._OAUTH_AUTHORIZE_URL = "??"
    oauth2_mixin_0.authorize_redirect(redirect_uri=None, client_id=None)


# Generated at 2022-06-26 07:43:12.442372
# Unit test for method authorize_redirect of class OAuthMixin
def test_OAuthMixin_authorize_redirect():
    # Init
    o_auth_mixin = OAuthMixin()
    o_auth_mixin._OAUTH_REQUEST_TOKEN_URL = "http://twitter.com/oauth/request_token"
    o_auth_mixin._OAUTH_ACCESS_TOKEN_URL = "http://twitter.com/oauth/access_token"
    o_auth_mixin._OAUTH_AUTHORIZE_URL = "http://twitter.com/oauth/authorize"
    o_auth_mixin._OAUTH_NO_CALLBACKS = False
    o_auth_mixin._OAUTH_VERSION = "1.0a"
    callback_uri = "http://127.0.0.1/auth/twitter/oauth_callback"
    extra_params = None
    http_client = o_auth

# Generated at 2022-06-26 07:43:22.467426
# Unit test for method authorize_redirect of class OAuthMixin
def test_OAuthMixin_authorize_redirect():
    import tornado.httpclient
    open_id_mixin_0 = OAuthMixin()
    async_h_t_t_p_client_0 = open_id_mixin_0.get_auth_http_client()
    callback_uri_0 = None
    extra_params_0 = None
    http_client_0 = tornado.httpclient.AsyncHTTPClient()
    open_id_mixin_0.authorize_redirect(callback_uri_0, extra_params_0, http_client_0)

@pytest.mark.asyncio
async def test_OAuthMixin_get_authenticated_user():
    import tornado.web
    import tornado.httpclient
    _OAUTH_AUTHORIZE_URL = "https://api.twitter.com/oauth/authorize"
    _OA

# Generated at 2022-06-26 07:43:25.091059
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    google_oauth2_mixin_0 = GoogleOAuth2Mixin()
    #Callback type: (str,str) -> Dict[str, Any]
    #Success: Callback(str,str)
    #Failure: Callback(str,str)
    #Validate callback returns: Dict[str, Any]
    #Validate callback does not return None: Dict[str, Any]


# Generated at 2022-06-26 07:43:27.152267
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    o_auth_mixin_0 = OAuthMixin()
    async_h_t_t_p_client_0 = o_auth_mixin_0.get_auth_http_client()



# Generated at 2022-06-26 07:44:58.581990
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    redirect_uri_0 = "https://www.myurl.com"
    client_id_0 = "clientidclientidclientidclientid"
    client_secret_0 = "clientsecretclientsecretclientsecret"
    code_0 = "code_0code_0code_0code_0code_0code_0"
    extra_fields_0 = None
    await facebook_graph_mixin_0.get_authenticated_user(redirect_uri_0, client_id_0, client_secret_0, code_0, extra_fields_0)


# Generated at 2022-06-26 07:45:07.496609
# Unit test for method authorize_redirect of class OAuthMixin
def test_OAuthMixin_authorize_redirect():
    callback_uri = 'http://www.fake.com'
    extra_params = {'key' : 'value'}
    test_oauth_mixin = OAuthMixin()
    test_oauth_mixin._OAUTH_AUTHORIZE_URL = 'http://fakeurl.com'
    test_oauth_mixin._OAUTH_REQUEST_TOKEN_URL = 'http://fakeurl.com'
    test_oauth_mixin._OAUTH_NO_CALLBACKS = False
    test_oauth_mixin._on_request_token = mock.Mock()
    # set up mock http client
    http_client = mock.Mock()
    http_client.fetch = mock.Mock()
    http_client.fetch.return_value = MockHTTPResponse()
    test

# Generated at 2022-06-26 07:45:12.163309
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    OAuthMixin_0 = OAuthMixin()
    # self.get_argument('oauth_token') has not been implemented
    OAuthMixin_0.get_authenticated_user()


# Generated at 2022-06-26 07:45:20.163319
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_instance_0 = TwitterMixin()
    twitter_mixin_instance_0.get_auth_http_client()
    twitter_mixin_instance_0.get_auth_http_client()
    twitter_mixin_instance_0.twitter_request(
        "statuses/user_timeline/btaylor", access_token=dict()
    )
    twitter_mixin_instance_0.twitter_request(
        "statuses/user_timeline/btaylor", post_args=dict(), access_token=dict()
    )



# Generated at 2022-06-26 07:45:28.883444
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    o_a_m_0 = OAuthMixin()
    class request_handler_0(object):
        def get_argument(self, arg_name, default=None):
            return default
        def clear_cookie(self, cookie_name):
            pass
        def get_cookie(self, cookie_name):
            return '_oauth_request_token'
        def set_cookie(self, cookie_name, data):
            pass
        def redirect(self, url):
            pass
        def finish(self, data):
            pass
        @property
        def request(self):
            class request_0(object):
                @property
                def full_url(self):
                    return 'url'
            return request_0()
    http_client_0 = o_a_m_0.get_auth_http_client()

# Generated at 2022-06-26 07:45:40.753737
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    # Prepare test objects
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.get_auth_http_client()
    twitter_mixin_0._oauth_request_token_url('http://www.example.com/')
    twitter_mixin_0.oauth_consumer = {}
    twitter_mixin_0.request = {'body': 'Callback URL not authorized'}
    twitter_mixin_0._OAUTH_VERSION = '1.0'
    twitter_mixin_0._OAUTH_AUTHORIZE_URL = 'http://www.example.com/'
    twitter_mixin_0._OAUTH_ACCESS_TOKEN_URL = 'http://www.example.com/'

# Generated at 2022-06-26 07:45:43.271672
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    # Test 0
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.authenticate_redirect()


# Generated at 2022-06-26 07:45:54.029606
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    # Get an instance of the class
    google_o_auth2_mixin_0 = GoogleOAuth2Mixin()

    # Value for argument 'redirect_uri'
    string_0 = get_string_0()

    # Value for argument 'code'
    string_1 = get_string_1()

    try:
        coro = google_o_auth2_mixin_0.get_authenticated_user(string_0, string_1)
        future = tornado.ioloop.IOLoop.current().run_sync(lambda: coro)
        dict_0 = future

        # The returned result is a dictionary
        assert isinstance(dict_0, dict)
    except Exception as e:
        print('Exception: {}'.format(e))
        raise(e)



# Generated at 2022-06-26 07:45:58.782759
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    redirect_uri_0 = ''
    code_0 = ''
    google_oauth2_mixin_0 = GoogleOAuth2Mixin()
    google_oauth2_mixin_1 = GoogleOAuth2Mixin()
    google_oauth2_mixin_1.get_authenticated_user(redirect_uri_0, code_0)


# Generated at 2022-06-26 07:46:07.688668
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():

    # Create a subclass of OpenIdMixin so that it can be used to test the get_authenticated_user method
    class TestOpenIdMixin(OpenIdMixin):
        """Subclass of OpenIdMixin that can be used to test the get_authenticated_user method"""
        _OPENID_ENDPOINT = "https://www.google.com/accounts/o8/ud"

        def _on_authentication_verified(self, response):
            handler = cast(RequestHandler, self)
            if b"is_valid:true" not in response.body:
                raise AuthError("Invalid OpenID response: %r" % response.body)

            # Make sure we got back at least an email from attribute exchange
            ax_ns = None