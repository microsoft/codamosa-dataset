

# Generated at 2022-06-26 07:37:05.754012
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    facebook_graph_mixin = FacebookGraphMixin()
    facebook_graph_mixin.oauth2_request = mock_function1
    facebook_graph_mixin.oauth2_request("url", access_token="access_token", post_args="post_args")


# Generated at 2022-06-26 07:37:10.307266
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    class MainHandler(tornado.web.RequestHandler, twitter_mixin.TwitterMixin):
        @tornado.web.authenticated
        async def get(self):
            new_entry = await self.twitter_request(
                "/statuses/update",
                post_args={"status": "Testing Tornado Web Server"},
                access_token=self.current_user["access_token"])
            if not new_entry:
                # Call failed; perhaps missing permission?
                await self.authorize_redirect()
                return
            self.finish("Posted a message!")

# Unit tests for class FacebookGraphMixin

# Generated at 2022-06-26 07:37:15.080846
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    http_client = httpclient.AsyncHTTPClient()
    mixin = OAuthMixin()
    mixin._OAUTH_ACCESS_TOKEN_URL = "/oauth_access_token"
    mixin._OAUTH_REQUEST_TOKEN_URL = "/oauth_request_token"
    mixin._OAUTH_AUTHORIZE_URL = "/oauth_authorize"
    mixin._OAUTH_VERSION = "1.0a"
    mixin._OAUTH_NO_CALLBACKS = False
    mixin._oauth_consumer_token = lambda: {"key": 1, "secret": 2}

# Generated at 2022-06-26 07:37:21.560804
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    path_0 = "/me/feed"
    access_token_0 = None
    post_args_0 = {"message": "I am posting from my Tornado application!"}
    dict_0 = {}
    dict_0.__setitem__("message", "I am posting from my Tornado application!")
    dict_0.__setitem__("access_token", None)
    dict_0.__setitem__("path", "/me/feed")
    dict_0.__setitem__("url", "https://graph.facebook.com/me/feed")
    dict_0.__setitem__("args", ())
    dict_0.__setitem__("kwargs", {})
    dict_0.__setitem__("post_args", {})
    dict_0

# Generated at 2022-06-26 07:37:23.809804
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.authenticate_redirect()


# Generated at 2022-06-26 07:37:33.972162
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    from tornado.concurrent import Future
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port

    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import url_concat
    from tornado.escape import to_unicode
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, ExpectLog, gen_test

    http_client = httpclient.AsyncHTTPClient()

    class TwitterMixinTest1(TwitterMixin):
        def get_auth_http_client(self) -> httpclient.AsyncHTTPClient:
            return http_client

        def get_auth_http_client_factory(self) -> httpclient.HTTPClient:
            return http_client_factory


# Generated at 2022-06-26 07:37:40.574923
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    redirect_uri_0 = 'http://redirect_uri.com'
    client_id_0 = 'client_id_0'
    client_secret_0 = 'client_secret_0'
    code_0 = 'code_0'
    facebook_graph_mixin_0.get_authenticated_user(redirect_uri_0, client_id_0, client_secret_0, code_0)


# Generated at 2022-06-26 07:37:45.374323
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    str_0 = "statuses/user_timeline/btaylor"
    dict_0 = {'key': 123, 'secret': 'secret'}
    twitter_mixin_0.get_auth_http_client = test_TwitterMixin_get_auth_http_client
    twitter_mixin_0.twitter_request(str_0, dict_0)


# Generated at 2022-06-26 07:37:59.139723
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    # Create a new instance of FacebookGraphMixin class
    facebook_graph_mixin = FacebookGraphMixin()

    # Test method with all valid parameters.
    # Test for function that does not return anything.
    # A tuple is return
    result = facebook_graph_mixin.get_authenticated_user(
        "asdf", "asdf", "asdf", "asdf", ["asdf"]
    )
    # Test for function that returns something
    # result = facebook_graph_mixin.get_authenticated_user("asdf", "asdf", "asdf", "asdf", ["asdf"])
    # Test for function that raises an exception
    # result = facebook_graph_mixin.get_authenticated_user("asdf", "asdf", "asdf", "asdf", ["asdf"])

# Unit

# Generated at 2022-06-26 07:38:01.056016
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    openid_mixin = OpenIdMixin()
    openid_mixin.get_authenticated_user()


# Generated at 2022-06-26 07:39:14.981980
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    twitter_mixin_0 = TwitterMixin()
    assert twitter_mixin_0._OAUTH_REQUEST_TOKEN_URL == 'https://api.twitter.com/oauth/request_token'
    assert twitter_mixin_0._OAUTH_ACCESS_TOKEN_URL == 'https://api.twitter.com/oauth/access_token'
    assert twitter_mixin_0._OAUTH_AUTHORIZE_URL == 'https://api.twitter.com/oauth/authorize'
    assert twitter_mixin_0._OAUTH_VERSION == '1.0a'
    assert twitter_mixin_0._OAUTH_NO_CALLBACKS == False
    twitter_mixin_0._OAUTH_REQUEST_TOKEN_URL = twitter_mixin_0._OAUTH_AUTHORIZE_URL

# Generated at 2022-06-26 07:39:17.233256
# Unit test for method authorize_redirect of class OAuth2Mixin
def test_OAuth2Mixin_authorize_redirect():
    oauth2_mixin_0 = OAuth2Mixin()
    oauth2_mixin_0.authorize_redirect()


# Generated at 2022-06-26 07:39:18.300826
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin_0 = TwitterMixin()



# Generated at 2022-06-26 07:39:26.078018
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    path = "dangerous_url"
    access_token = "fq3YwKQd3G7cjsaW.HZ7p"
    post_args = {}
    args = {}
    args['content_type'] = 'application/x-www-form-urlencoded'
    future = facebook_graph_mixin_0.facebook_request(path, access_token, post_args, **args)
    url = facebook_graph_mixin_0._FACEBOOK_BASE_URL + path
    # Checking that the output of the function matches the expected value
    assert future is not None



# Generated at 2022-06-26 07:39:33.750781
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    path = "/btaylor/picture"
    access_token = "access_token_0"
    post_args = None
    args = {"arg0": 0, "arg1": 1, "arg2": 2, "arg3": 3}
    facebook_graph_mixin_0.facebook_request(
        path=path, access_token=access_token, post_args=post_args, **args
    )


# Generated at 2022-06-26 07:39:38.346434
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    # test1
    facebook_graph_mixin_test_1 = FacebookGraphMixin()
    result = facebook_graph_mixin_test_1.facebook_request(path="/btaylor/picture",access_token=None,post_args=None)



# Generated at 2022-06-26 07:39:42.153260
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    redirect_uri_0 = ''
    client_id_0 = ''
    client_secret_0 = ''
    code_0 = ''
    extra_fields_0 = dict()
    return facebook_graph_mixin_0.get_authenticated_user(redirect_uri_0, client_id_0, client_secret_0, code_0, extra_fields_0)


# Generated at 2022-06-26 07:39:54.612421
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    open_id_mixin_0 = OpenIdMixin()
    http_client_0 = httpclient.AsyncHTTPClient()
    async def async_get_0():
        return await open_id_mixin_0.get_authenticated_user(http_client_0)

    class RequestHandler_0(RequestHandler):
        
        def post(self):
            pass

    request_handler_0 = RequestHandler_0(method='POST')
    request_handler_0.request.full_url = mock_function()

# Generated at 2022-06-26 07:39:55.907474
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    oauth_mixin_1 = OAuthMixin()


# Generated at 2022-06-26 07:40:02.990433
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    open_id_mixin_0 = OpenIdMixin()
    http_client = httpclient.AsyncHTTPClient()
    response = httpclient.HTTPResponse(
        request=httpclient.HTTPRequest("http://www.example.com"),
        code=200,
        buffer=b"is_valid:true",
        effective_url="http://www.example.com/",
        error=None,
    )
    user = open_id_mixin_0._on_authentication_verified(response)
    assert user["email"] == u''
    assert user["name"] == u''
    assert user["first_name"] == u''
    assert user["last_name"] == u''
    assert user["locale"] == u''
    assert user["username"] == u''
    assert user["claimed_id"] == None

# Generated at 2022-06-26 07:40:40.417430
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    redirect_uri_0 = ""
    client_id_0 = ""
    client_secret_0 = ""
    code_0 = ""
    try:
        facebook_graph_mixin_0.get_authenticated_user(redirect_uri_0, client_id_0, client_secret_0, code_0)
    except Exception as error_0:
        print(error_0)


# Generated at 2022-06-26 07:40:50.561367
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    settings = {
        "facebook_api_key": "api_key",
        "facebook_secret": "secret",
    }

    google_oauth2_mixin_0 = GoogleOAuth2Mixin()
    google_oauth2_mixin_0.settings = settings
    redirect_uri = "http://your.site.com/auth/google"
    code = "code"
    access_token = "access_token"
    user = {"name": "name"}
    google_oauth2_mixin_0.get_auth_http_client = lambda : MockHttpClient(return_value=access_token)
    google_oauth2_mixin_0.oauth2_request = lambda a, access_token: MockOauth2(access_token)

    assert google_oauth2_mixin_0.get

# Generated at 2022-06-26 07:40:59.937916
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    path = "/account/verify_credentials"
    access_token_0 = dict()
    access_token_0["key"] = "access_token_0['key']"
    access_token_0["secret"] = "access_token_0['secret']"
    user = twitter_mixin_0.twitter_request(path, access_token_0)
    if user is not None:
        user["username"] = "user['username']"
    assert user is not None


# Generated at 2022-06-26 07:41:07.984543
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    # Test 1; Path = /me/feed
    facebook_graph_mixin_0 = FacebookGraphMixin()
    facebook_graph_mixin_0.facebook_request(path="/me/feed", 
                              post_args={"message": "I am posting from my Tornado application!"},
                              access_token="")


# Generated at 2022-06-26 07:41:09.748647
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.authenticate_redirect(callback_uri=None)


# Generated at 2022-06-26 07:41:12.519594
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    path = "https://api.twitter.com/1.1/statuses/user_timeline/btaylor"
    access_token = {"key": "y"}
    twitter_mixin_0.twitter_request(path, access_token)

# Generated at 2022-06-26 07:41:20.585769
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    facebook_graph_mixin_url = FacebookGraphMixin()
    param_access_token = None
    param_path = "/me/feed"
    param_post_args = {"message": "I am posting from my Tornado application!"}
    result = facebook_graph_mixin_url.facebook_request(param_path, param_access_token, param_post_args)


# Generated at 2022-06-26 07:41:27.170776
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    path = "/statuses/user_timeline/btaylor"
    access_token = {}
    post_args = {}
    args = {}
    result = twitter_mixin_0.twitter_request(path, access_token, post_args, **args)
    assert type(result) == awaitable


# Generated at 2022-06-26 07:41:32.493498
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    import aiohttp
    import asyncio

    async def testing_handler():
        http_client_0 = await aiohttp.ClientSession(
            connector=aiohttp.TCPConnector(ssl=False)
        ).__aenter__()
        return await OpenIdMixin().get_authenticated_user(http_client_0)

    asyncio.run(testing_handler())



# Generated at 2022-06-26 07:41:45.258646
# Unit test for method authenticate_redirect of class OpenIdMixin
def test_OpenIdMixin_authenticate_redirect():
    print("\n------------- test_OpenIdMixin_authenticate_redirect --------------")
    http_client = httpclient.AsyncHTTPClient()
    openid_mixin_0 = OpenIdMixin()
    openid_mixin_0.authenticate_redirect(callback_uri = None, ax_attrs = ["name", "email", "language", "username"])
    openid_mixin_0.authenticate_redirect(callback_uri = "http://a.b.c.d/e/f/g/h", ax_attrs = ["name"])
    openid_mixin_0.authenticate_redirect(callback_uri = "http://a.b.c.d/e/f/g/h", ax_attrs = ["name", "name"])
    openid_mixin_0.authent

# Generated at 2022-06-26 07:42:20.755497
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_1 = FacebookGraphMixin()
    redirect_uri = 'http://example.com/redirect'
    client_id = 'client_id'
    client_secret = 'client_secret'
    code = 'code'
    if facebook_graph_mixin_1.get_authenticated_user(redirect_uri, client_id, client_secret, code) is None:
        print('Test case for method get_authenticated_user of class FacebookGraphMixin failed')
    else:
        print('Test case for method get_authenticated_user of class FacebookGraphMixin passed')


# Generated at 2022-06-26 07:42:23.022205
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_muxin_0 = TwitterMixin()
    assert twitter_muxin_0 is not None
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 07:42:25.751688
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin = TwitterMixin()
    callback_uri = "http://"
    twitter_mixin.authenticate_redirect(callback_uri)


# Generated at 2022-06-26 07:42:35.794816
# Unit test for method facebook_request of class FacebookGraphMixin
def test_FacebookGraphMixin_facebook_request():
    import httpclient_models_test.test_case_models as test_case_models
    import httpclient_models_test.test_case_0 as test_case_0
    test_case_0.test_case_0()
    print('test_FacebookGraphMixin_facebook_request ...')
    print(test_case_models.inputs_0['input_0'][0])
    facebook_graph_mixin = FacebookGraphMixin()
    facebook_graph_mixin.oauth2_request = test_case_models.inputs_0['input_0'][0]

# Generated at 2022-06-26 07:42:39.879392
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    openid_mixin_0 = OpenIdMixin() # create an async_http_client
    openid_mixin_0.get_authenticated_user()



# Generated at 2022-06-26 07:42:52.746528
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    
    # TEST 0:
    import tornado.web
    import tornado.auth
    
    class MainHandler(tornado.web.RequestHandler, tornado.auth.FacebookGraphMixin):
        @tornado.web.authenticated
        async def get(self):
            new_entry = await self.oauth2_request(
                "https://graph.facebook.com/me/feed",
                post_args={"message": "I am posting from my Tornado application!"},
                access_token=self.current_user["access_token"])
    

# Generated at 2022-06-26 07:42:54.988489
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()

# Generated at 2022-06-26 07:42:59.724809
# Unit test for method get_authenticated_user of class OAuthMixin
def test_OAuthMixin_get_authenticated_user():
    oauth_mixin_0 = OAuthMixin()
    oauth_mixin_0.get_authenticated_user()


# Generated at 2022-06-26 07:43:08.397919
# Unit test for method oauth2_request of class OAuth2Mixin
def test_OAuth2Mixin_oauth2_request():
    oauth2_mixin_2 = OAuth2Mixin()
""" Tests oauth2_request(self, url, access_token=None, post_args=None, **args)
    Parameters: url, url
    access_token, optional, access token
    post_args, dict of arguments to be passed
    args, dict of arguments
"""

# Generated at 2022-06-26 07:43:12.943153
# Unit test for method authorize_redirect of class OAuthMixin
def test_OAuthMixin_authorize_redirect():
    # (str, str, str, str)
    oauth_mixin_0 = OAuthMixin()

    return oauth_mixin_0.authorize_redirect(
        '', '', '', ''
    )


# Generated at 2022-06-26 07:44:04.137338
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    path_0 = '/statuses/user_timeline/btaylor'
    access_token_0 = {}
    post_args_0 = {}
    response_0 = twitter_mixin_0.twitter_request(path_0, access_token_0, post_args_0)


# Generated at 2022-06-26 07:44:05.924759
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    openid_mixin_0 = OpenIdMixin()
    openid_mixin_0.get_authenticated_user()


# Generated at 2022-06-26 07:44:11.558902
# Unit test for method twitter_request of class TwitterMixin
def test_TwitterMixin_twitter_request():
    twitter_mixin_0 = TwitterMixin()
    path_0 = ""
    access_token_0 = {'key': 'http', 'secret': 'http://api.twitter.com/oauth/request_token'}
    post_args_0 = {}
    args_0 = {}
    result = twitter_mixin_0.twitter_request(path_0, access_token_0, post_args_0, args_0)


# Generated at 2022-06-26 07:44:14.364044
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():

    facebook_graph_mixin = FacebookGraphMixin()
    assert hasattr(facebook_graph_mixin, "get_authenticated_user")
    facebook_graph_mixin.get_authenticated_user("", "", "", "")


# Generated at 2022-06-26 07:44:15.398581
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    FacebookGraphMixin().get_authenticated_user()


# Generated at 2022-06-26 07:44:17.991594
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    tw_mixin = TwitterMixin()
    tw_mixin.authenticate_redirect("tests/test_custom_oauth_mixins.py")


# Generated at 2022-06-26 07:44:19.719348
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    google_oauth2_mixin_0 = GoogleOAuth2Mixin()
    test_code = '<some-id>'
    test_redirect_uri = '<some-redirect-uri>'
    assert True # TODO: implement your test here


# Generated at 2022-06-26 07:44:22.151706
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_0 = FacebookGraphMixin()
    facebook_graph_mixin_0.get_authenticated_user('', '', '', '')


# Generated at 2022-06-26 07:44:27.055388
# Unit test for method authenticate_redirect of class TwitterMixin
def test_TwitterMixin_authenticate_redirect():
    twitter_mixin_0 = TwitterMixin()
    twitter_mixin_0.get_auth_http_client()
    twitter_mixin_0._oauth_request_token_url()
    twitter_mixin_0._on_request_token()
    twitter_mixin_0.authenticate_redirect()


# Generated at 2022-06-26 07:44:29.707511
# Unit test for method get_authenticated_user of class GoogleOAuth2Mixin
def test_GoogleOAuth2Mixin_get_authenticated_user():
    googol_oauth2_mixin_0 = GoogleOAuth2Mixin()
    exception_0 = None
    try:
        googol_oauth2_mixin_0.get_authenticated_user()
    except Exception as e:
        exception_0 = e

    if exception_0:
        print(exception_0.__class__.__name__)
        print(exception_0)
        assert False
    else:
        assert True


# Generated at 2022-06-26 07:46:02.990924
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    # Prepare data
    redirect_uri = 'example.com'
    client_id = 'dummy'
    client_secret = 'dummy'
    code = 'dummy'
    extra_fields = {'id': 'dummy'}

    # Execute the target method
    facebook_graph_mixin = FacebookGraphMixin()
    result = facebook_graph_mixin.get_authenticated_user(redirect_uri, client_id, client_secret, code, extra_fields)

    # The result should be a type of Future
    assert isinstance(result, Future)


# Generated at 2022-06-26 07:46:14.273111
# Unit test for method get_authenticated_user of class OpenIdMixin
def test_OpenIdMixin_get_authenticated_user():
    openidmixin_obj_0 = OpenIdMixin()
    class RequestHandler(object):
        def get_argument(self, arg0):
            if arg0 == "openid.ns.ax":
                return "http://openid.net/srv/ax/1.0"
            if arg0 == "openid.ns.ax.type.name":
                return "http://axschema.org/namePerson"
            if arg0 == "openid.ax.type.name":
                return "http://axschema.org/namePerson"
            if arg0 == "openid.ns.ax.type.firstname":
                return "http://axschema.org/namePerson/first"

# Generated at 2022-06-26 07:46:21.564968
# Unit test for method get_authenticated_user of class FacebookGraphMixin
def test_FacebookGraphMixin_get_authenticated_user():
    facebook_graph_mixin_1 = FacebookGraphMixin()
    facebook_graph_mixin_1.get_authenticated_user("redirect_uri", "client_id", "client_secret", "code", "extra_fields")
