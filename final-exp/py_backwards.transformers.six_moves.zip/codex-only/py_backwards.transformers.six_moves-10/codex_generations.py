

# Generated at 2022-06-23 22:59:16.653599
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert t.dependencies == ['six']

# Generated at 2022-06-23 22:59:19.235996
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()


# Generated at 2022-06-23 22:59:20.893636
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:59:25.724047
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("foo", "bar")
    assert module.name == "foo"
    assert module.new == "foo"
    assert module.old == "bar"
    module = MovedModule("foo", "bar", "zoo")
    assert module.name == "foo"
    assert module.new == "zoo"
    assert module.old == "bar"

# Generated at 2022-06-23 22:59:27.369337
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 22:59:29.900357
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert (SixMovesTransformer.rewrites
            == _get_rewrites())
    assert SixMovesTransformer.rewrites is not _get_rewrites()


# Generated at 2022-06-23 22:59:40.531238
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-23 22:59:46.053901
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule("builtins", "__builtin__")
    assert m1.name == "builtins"
    assert m1.old == "__builtin__"
    assert m1.new == "builtins"

    m2 = MovedModule("builtins", "__builtin__", "all_builtins")
    assert m2.name == "builtins"
    assert m2.old == "__builtin__"
    assert m2.new == "all_builtins"



# Generated at 2022-06-23 22:59:56.415988
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') != MovedAttribute('cStringIO', 'cStringIO', 'io', 'String')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') != MovedAttribute('cStringIO', 'cString', 'io', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') != MovedAttribute('cStringI', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') != Moved

# Generated at 2022-06-23 23:00:04.247100
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import codegen
    m = type(codegen).modules['six.moves']
    rewrites = []
    for k, v in m.items():
        if isinstance(v, types.ModuleType):
            rewrites.append((v.__name__, 'six.moves.' + k))
    for k, v in m.__dict__.items():
        if isinstance(v, types.ModuleType):
            rewrites.append((v.__name__, 'six.moves.' + k))
    assert set(SixMovesTransformer.rewrites) == set(rewrites)

# Generated at 2022-06-23 23:00:09.711968
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    oldAttr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    newAttr = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="StringIO")
    assert (oldAttr.name == newAttr.name)
    assert (oldAttr.new_mod == newAttr.new_mod)
    assert (oldAttr.new_attr == newAttr.new_attr)

# Generated at 2022-06-23 23:00:13.789134
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError) as excinfo:
        MovedModule()
    assert '__init__()' in str(excinfo.value)
    assert 'expected at least 1 arguments' in str(excinfo.value)


# Generated at 2022-06-23 23:00:18.793930
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'old'
    assert not hasattr(m, 'old')

    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'
    assert not hasattr(m, 'old')



# Generated at 2022-06-23 23:00:21.273438
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.old == 'old'
    assert module.new == 'new'



# Generated at 2022-06-23 23:00:29.093955
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('cStringIO', 'cStringIO', None, 'StringIO')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'cStringIO'
    assert attr.new_attr == 'StringIO'

    attr = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'cStringIO'

# Generated at 2022-06-23 23:00:35.954807
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = MovedModule("builtins", "__builtin__")
    assert moves.name == "builtins"
    assert moves.new == "builtins"
    moves = MovedModule("configparser", "ConfigParser")
    assert moves.name == "configparser"
    assert moves.new == "configparser"
    moves = MovedModule("configparser", "ConfigParser", "configparser")
    assert moves.name == "configparser"
    assert moves.new == "configparser"
    moves = MovedModule("configparser", "ConfigParser", "configparser.configparser")
    assert moves.name == "configparser"
    assert moves.new == "configparser.configparser"
    moves = MovedModule("configparser", "ConfigParser", "abc.def")
    assert moves.name == "configparser"

# Generated at 2022-06-23 23:00:37.356336
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites()
    assert SixMovesTransformer

# Generated at 2022-06-23 23:00:47.260580
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr', new_attr='new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod')
    assert MovedAttribute('name', 'old_mod', None)
    assert MovedAttribute('name', None, None)


# Generated at 2022-06-23 23:00:58.794320
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:01.508696
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "new"

# Generated at 2022-06-23 23:01:07.153322
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("abc", "old", "new")
    assert mm.name == "abc", "__init__ should set name"
    assert mm.new == "new", "__init__ should set new"
    mm = MovedModule("abc", "old")
    assert mm.name == "abc", "__init__ should set name"
    assert mm.new == "abc", "__init__ should set new by default"

# Generated at 2022-06-23 23:01:11.344579
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_attr == "StringIO"
    assert attr.new_mod == "io"



# Generated at 2022-06-23 23:01:15.671206
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('new_name', 'old_name', 'new_name', 'old_attr', None)
    assert move.name == 'new_name'
    assert move.new_mod == 'new_name'
    assert move.new_attr == 'old_attr'

# Generated at 2022-06-23 23:01:23.982064
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr_name = 'test_attribute'
    attr_old_mod = 'test_mod'
    attr_new_mod = 'new_test_mod'
    attr_old_attr = 'old'
    attr_new_attr = 'new'
    attr = MovedAttribute(attr_name, attr_old_mod, attr_new_mod, attr_old_attr, attr_new_attr)
    assert attr.name == attr_name
    assert attr.new_mod == attr_new_mod
    assert attr.new_attr == attr_new_attr


# Generated at 2022-06-23 23:01:28.719123
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('foo', 'a', 'b')
    assert ma.name == 'foo'
    assert ma.new_mod == 'b'
    assert ma.new_attr == 'foo'

    ma = MovedAttribute('foo', 'a', 'b', 'attr')
    assert ma.name == 'foo'
    assert ma.new_mod == 'b'
    assert ma.new_attr == 'attr'

# Generated at 2022-06-23 23:01:36.453039
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    @eager
    def test_iter():
        yield MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__
        yield MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").__dict__
        yield MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").__dict__
        yield MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").__dict__
        yield MovedAttribute("intern", "__builtin__", "sys").__dict__
        yield MovedAttribute("map", "itertools", "builtins", "imap", "map").__dict__

# Generated at 2022-06-23 23:01:37.817687
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-23 23:01:41.883620
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"


# Generated at 2022-06-23 23:01:46.161423
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('ModuleName', 'OldName', 'NewName')
    assert mm.name == 'ModuleName'
    assert mm.old == 'OldName'
    assert mm.new == 'NewName'

    mm = MovedModule('ModuleName', 'OldName')
    assert mm.name == 'ModuleName'
    assert mm.old == 'OldName'
    assert mm.new == 'ModuleName'


# Generated at 2022-06-23 23:01:49.218059
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attr.name == 'name'
    assert moved_attr.new_mod == 'new_mod'
    assert moved_attr.new_attr == 'new_attr'


# Generated at 2022-06-23 23:01:54.904815
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:01:55.996866
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')

# Generated at 2022-06-23 23:01:59.475366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # This used to raise TypeError: __init__() takes from 3 to 5 positional arguments but 6 were given
    MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")

# Generated at 2022-06-23 23:02:08.504558
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:11.544353
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-23 23:02:14.605004
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert(module.name == "builtins" and module.old == "__builtin__" and module.new == "builtins")

# Generated at 2022-06-23 23:02:16.458350
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t
    assert 'six' in t.dependencies

# Generated at 2022-06-23 23:02:18.965706
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'


# Generated at 2022-06-23 23:02:22.961264
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import random

    def get_rewrites():
        # NOTE: random.shuffle mutates the rewrites list
        random.shuffle(_get_rewrites())
        yield from _get_rewrites()

    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.rewrites == get_rewrites()

# Generated at 2022-06-23 23:02:35.127248
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:40.485666
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old")
    assert mod.name == "name"
    assert mod.old == "old"
    assert mod.new == "name"

    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.old == "old"
    assert mod.new == "new"

# Generated at 2022-06-23 23:02:50.821352
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert 'urllib.parse' in SixMovesTransformer.rewrites
    assert 'urllib.error' in SixMovesTransformer.rewrites
    assert 'urllib.request' in SixMovesTransformer.rewrites
    assert 'urllib.response' in SixMovesTransformer.rewrites
    assert 'urllib.robotparser' in SixMovesTransformer.rewrites
    assert 'urllib' in SixMovesTransformer.rewrites
    assert 'urllib2' not in SixMovesTransformer.rewrites
    assert 'six.moves.urllib.parse.urlparse' in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:02:54.869844
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('queue', 'Queue')
    assert m.name == 'queue'
    assert m.new == 'queue'
    m = MovedModule('queue', 'Queue', 'queue')
    assert m.name == 'queue'
    assert m.new == 'queue'



# Generated at 2022-06-23 23:02:58.727013
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('module', 'old', 'new')
    assert moved_module.name == 'module'
    assert moved_module.new == 'new'



# Generated at 2022-06-23 23:03:09.858534
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..transform import Class
    from .six_moves import _get_six_moves
    from .six_moves import _make_six_import_rewrite

    class SixMovesTransformer(Class):
        for prefix, moves in prefixed_moves:
            for move in moves:
                if isinstance(move, MovedAttribute):
                    path = '{}.{}'.format(move.new_mod, move.new_attr)
                    yield _make_six_import_rewrite(path, 'six.moves{}.{}'.format(prefix, move.name))
                elif isinstance(move, MovedModule):
                    yield _make_six_import_rewrite(move.new, 'six.moves{}.{}'.format(prefix, move.name))


# Generated at 2022-06-23 23:03:15.978068
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("test", "mod", "mod").name == "test"
    assert MovedAttribute("test", "mod", "mod").new_mod == "mod"
    assert MovedAttribute("test", "mod", "mod").new_attr == "test"
    assert MovedAttribute("test", "mod", "mod", "old_attr").new_attr == "old_attr"
    assert MovedAttribute("test", "mod", "mod", new_attr="new_attr").new_attr == "new_attr"


# Generated at 2022-06-23 23:03:25.473938
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("hello", "howdy", "hi")
    assert m.name == 'hello'
    assert m.new_mod == 'hi'
    assert m.new_attr == 'hello'
    m = MovedAttribute("hello", "howdy", "hi", "hell", "ho")
    assert m.name == 'hello'
    assert m.new_mod == 'hi'
    assert m.new_attr == 'ho'
    m = MovedAttribute("hello", "howdy", "hi", "hell")
    assert m.name == 'hello'
    assert m.new_mod == 'hi'
    assert m.new_attr == 'hell'

# Generated at 2022-06-23 23:03:28.223811
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'name'
    assert m.old == 'old'

    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'
    assert m.old == 'old'



# Generated at 2022-06-23 23:03:33.413740
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case = MovedModule("test_name", "old_name", "new_name")
    assert test_case.name == "test_name", "name of test_case should be 'test_name'"
    assert test_case.new == "new_name", "new name of test_case should be 'new_name'"
    test_case_2 = MovedModule("test_name_2", "old_name_2")
    assert test_case_2.name == "test_name_2", "name of test_case_2 should be 'test_name_2'"
    assert test_case_2.new == "test_name_2", "new name of test_case_2 should be 'test_name_2'"
    return None

# Generated at 2022-06-23 23:03:39.238292
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_module", "new_module", "old", "new")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_module"
    assert moved_attribute.new_attr == "new"



# Generated at 2022-06-23 23:03:44.400868
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for move in _moved_attributes:
        if isinstance(move, MovedAttribute):
            assert isinstance(move.name, str)
            assert isinstance(move.old_mod, str)
            assert isinstance(move.new_mod, str)
            assert isinstance(move.old_attr, str) or move.old_attr is None
            assert isinstance(move.new_attr, str) or move.new_attr is None
            if move.old_mod is not None:
                assert move.old_attr is None or move.old_attr != move.name
            if move.new_mod is not None:
                assert move.new_attr is None or move.new_attr != move.name

# Generated at 2022-06-23 23:03:51.686138
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute("a")
    with pytest.raises(TypeError):
        MovedAttribute("a", "b")

    assert str(MovedAttribute("a", "b", "c")) == "a -> six.moves.a"
    assert str(MovedAttribute("a", "b", "c", "d", "e")) == "a -> six.moves.a"
    assert str(MovedAttribute("a", "b", None, "d", "e")) == "a -> e"


# Unit tests for SixMovesTransformer

# Generated at 2022-06-23 23:04:01.843452
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:04:06.262378
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a = MovedAttribute("cStringIO", "cStringIO", "io")
    assert a.new_attr == "cStringIO"

    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "ABC")
    assert a.new_attr == "ABC"

# Generated at 2022-06-23 23:04:17.999748
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:04:28.486399
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Re-create the `_get_rewrites` function in order to test it.

    # NOTE: This only runs correctly on Python 2.7
    assert (sys.version_info[0], sys.version_info[1]) == (2, 7)

    def _get_rewrites():
        for prefix, moves in prefixed_moves:
            for move in moves:
                if isinstance(move, MovedAttribute):
                    path = '{}.{}'.format(move.new_mod, move.new_attr)
                    yield (path, 'six.moves{}.{}'.format(prefix, move.name))
                elif isinstance(move, MovedModule):
                    yield (move.new, 'six.moves{}.{}'.format(prefix, move.name))


# Generated at 2022-06-23 23:04:31.815762
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar', 'qux')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'qux'

# Generated at 2022-06-23 23:04:37.094281
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.dependencies == ['six']
    assert len(t.rewrites) == len(_get_rewrites())
    for rewrite in t.rewrites:
        assert rewrite in _get_rewrites()
    assert t.target == (2, 7)
    assert t.__doc__ == "Replaces moved modules with ones from `six.moves`."

# Generated at 2022-06-23 23:04:39.873994
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar", "baz").new == "baz"
    assert MovedModule("foo", "bar").new == "bar"



# Generated at 2022-06-23 23:04:45.652800
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("a", "b", "c", "d", "e")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "e"

    a = MovedAttribute("a", "b", "c", "d", None)
    assert a.new_attr == "d"



# Generated at 2022-06-23 23:04:47.509452
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # just test the constructor
    assert SixMovesTransformer(None).name == 'SixMovesTransformer'

# Generated at 2022-06-23 23:04:49.848404
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'

# Generated at 2022-06-23 23:04:50.965836
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:01.239197
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") == MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") != MovedAttribute("name1", "old_mod", "new_mod", "old_attr", "new_attr")
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") != MovedAttribute("name", "old_mod1", "new_mod", "old_attr", "new_attr")

# Generated at 2022-06-23 23:05:02.107793
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:07.538380
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute(name='name1', old_mod='old_mod1', new_mod='new_mod1')
    assert obj.name == 'name1'
    assert obj.new_mod == 'new_mod1'
    assert obj.new_attr == 'name1'


# Generated at 2022-06-23 23:05:11.707966
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name','old','new')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'new'
    b = MovedModule('name2','old2')
    assert b.name == 'name2'
    assert b.old == 'old2'
    assert b.new == 'name2'

# Generated at 2022-06-23 23:05:14.357745
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "StringIO"



# Generated at 2022-06-23 23:05:20.265123
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 23:05:26.735223
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("range", "__builtin__", "builtins", "xrange", "range").name == "range"

# Generated at 2022-06-23 23:05:30.418979
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert(move.name == 'cStringIO')
    assert(move.new_mod == 'io')
    assert(move.new_attr == 'StringIO')


# Generated at 2022-06-23 23:05:36.708349
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()
    assert obj.target == (2, 7)
    assert len(obj.rewrites) == len(_get_rewrites())


if __name__ == "__main__":
    print(test_SixMovesTransformer.__doc__)
    test_SixMovesTransformer()
    print("Done.")

# Generated at 2022-06-23 23:05:38.668212
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b") == MovedModule("a", "b", "a")

# Generated at 2022-06-23 23:05:43.146774
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.new == "name"

    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.new == "new"


# Generated at 2022-06-23 23:05:51.700614
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('queue', 'Queue')
    assert mod.name == 'queue'
    assert mod.old == 'Queue'
    assert mod.new == 'queue'
    
    mod = MovedModule('queue', 'Queue', 'queue')
    assert mod.name == 'queue'
    assert mod.old == 'Queue'
    assert mod.new == 'queue'
    
    mod = MovedModule('queue', 'Queue', 'old_queue')
    assert mod.name == 'queue'
    assert mod.old == 'Queue'
    assert mod.new == 'old_queue'

# Generated at 2022-06-23 23:05:52.930165
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:57.025403
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"

# Generated at 2022-06-23 23:05:59.177951
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=unused-variable
    transformer = SixMovesTransformer

# Generated at 2022-06-23 23:06:05.055741
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "cStringIO"
    old_mod = "cStringIO"
    new_mod = "io"
    old_attr = "StringIO"
    new_attr = "StringIO"
    moved_attr = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert(moved_attr.name == name)
    assert(moved_attr.new_attr == new_attr)

# Generated at 2022-06-23 23:06:13.793199
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import six
    from ..six.moves import queue
    from ..six.moves.queue import Queue
    from ..six.moves import urllib
    from ..six.moves.urllib import parse
    from ..six.moves.urllib.parse import urlparse
    from ..six.moves import urllib_parse
    from ..six.moves.urllib_parse import urlparse
    from ..six.moves import urllib_error
    from ..six.moves.urllib_error import URLError
    from ..six.moves import urllib_request
    from ..six.moves.urllib_request import urlopen
    from ..six.moves import urllib_response
    from ..six.moves.urllib_response import addbase
   

# Generated at 2022-06-23 23:06:20.583017
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').old == 'ConfigParser'
    assert MovedModule('configparser', 'ConfigParser', 'ConfigParser').new == 'ConfigParser'
    assert MovedModule('configparser', 'ConfigParser', 'ConfigParser').old == 'ConfigParser'


# Generated at 2022-06-23 23:06:23.934798
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Arrange
    t = SixMovesTransformer

    # Assert
    assert t.target == (2, 7)
    assert t.dependencies == ['six']

# Generated at 2022-06-23 23:06:25.782954
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")



# Generated at 2022-06-23 23:06:36.371811
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from six.moves import filter, filterfalse, input
    filter = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    filterfalse = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    moved_in = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert filter.name == "filter" and filter.new_mod == "builtins" and filter.new_attr == "filter"
    assert filterfalse.name == "filterfalse" and filterfalse.new_mod == "itertools" and filterfalse.new_attr == "filterfalse"
    assert moved_in.name == "input" and moved_in.new_mod == "builtins" and moved_in

# Generated at 2022-06-23 23:06:38.375317
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert len(st.rewrites) == 63, 'bad num rewrites'

# Generated at 2022-06-23 23:06:47.849422
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(_moved_attributes[0]) == "MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr='StringIO', new_attr=None)"
    assert str(_moved_attributes[1]) == "MovedAttribute(name='filter', old_mod='itertools', new_mod='builtins', old_attr='ifilter', new_attr='filter')"
    assert str(_moved_attributes[18]) == "MovedModule(name='builtins', old='__builtin__', new='builtins')"
    assert str(_moved_attributes[19]) == "MovedModule(name='configparser', old='ConfigParser', new='configparser')"

# Generated at 2022-06-23 23:06:57.571321
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "int").new_attr

# Generated at 2022-06-23 23:07:09.637876
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    code = '''
    from six.moves.urllib.parse import urlencode
    from six.moves.urllib import parse as p
    from six.moves.urllib.parse import urljoin
    from six.moves import xmlrpc_client as x
    from six.moves import configparser as c
    '''
    ast = ast27.parse(code)
    tr = SixMovesTransformer()
    tr.visit(ast)

    def _get_path(node):
        return '.'.join(getattr(node, 'names', [getattr(node, 'name', None)])[0])

    assert _get_path(ast.body[0].names[0]) == 'urllib.parse.urlencode'

# Generated at 2022-06-23 23:07:18.517280
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("a", 'b', 'c')
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "a"

    b = MovedAttribute("b", 'c', 'd', 'e')
    assert b.name == "b"
    assert b.new_mod == "d"
    assert b.new_attr == "e"

    c = MovedAttribute("c", 'd', 'e', 'f', 'g')
    assert c.name == "c"
    assert c.new_mod == "e"
    assert c.new_attr == "g"



# Generated at 2022-06-23 23:07:22.249886
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.old == "__builtin__"
    assert moved_module.new == "builtins"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:07:29.389131
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("foo", "bar")
    assert a.name == "foo"
    assert a.new == "foo"
    a2 = MovedModule("foo", "bar", "baz")
    assert a2.name == "foo"
    assert a2.new == "baz"
    a3 = MovedModule("foo", "bar", None)
    assert a3.name == "foo"
    assert a3.new == "foo"

# Generated at 2022-06-23 23:07:35.225279
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer('test', (2, 7))
    rewrites = transformer.rewrites
    assert isinstance(rewrites, list)
    assert isinstance(rewrites[0], tuple)
    assert isinstance(rewrites[0][0], str)
    assert isinstance(rewrites[0][1], str)
    assert rewrites[0][0].startswith('six.moves')

# Generated at 2022-06-23 23:07:36.973790
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    converter = SixMovesTransformer(None)
    assert converter.target == (2, 7)
    assert sorted(converter.rewrites) == sorted(_get_rewrites())

# Generated at 2022-06-23 23:07:42.709512
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.target == (2, 7)
    assert len(s.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + \
           len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + \
           len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)
    assert s.dependencies == ['six']


# Generated at 2022-06-23 23:07:47.544678
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=protected-access
    assert (
        list(SixMovesTransformer().rewrites) ==
        list(_get_rewrites())
    )


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:07:52.268327
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'name'

    a = MovedModule('name', 'old', 'new')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'new'


# Generated at 2022-06-23 23:07:57.974726
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('old', 'new', 'newmod')
    assert m.name == 'old'
    assert m.new_attr == 'old'
    assert m.new_mod == 'newmod'
    m = MovedAttribute('old', 'new', 'newmod', old_attr='oldattr', new_attr='newattr')
    assert m.name == 'old'
    assert m.new_attr == 'newattr'
    assert m.new_mod == 'newmod'

# Generated at 2022-06-23 23:08:00.939874
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('new_name', 'old_name').new == 'new_name'
    assert MovedModule('new_name', 'old_name').name == 'old_name'

# Generated at 2022-06-23 23:08:07.297070
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("aa", "bb")
    assert module.name == "aa"
    assert module.new == "aa"
    assert module.old == "bb"
    module = MovedModule("aa", "bb", "cc")
    assert module.name == "aa"
    assert module.new == "cc"
    assert module.old == "bb"


# Generated at 2022-06-23 23:08:13.298874
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moves_transformer = SixMovesTransformer()
    import_map = {}
    for prefix, moves in six_moves_transformer.rewrites:
        for move in moves:
            if isinstance(move, MovedModule):
                import_map[move.new] = 'six.moves{}.{}'.format(prefix, move.name)
    for key in import_map:
        assert 'six.moves' in import_map[key]
        assert 'six.moves' in key

# Generated at 2022-06-23 23:08:15.478391
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    # tests that the rewrites are all (target, replacement) pairs
    for rewrite in transformer.rewrites:
        assert(len(rewrite) == 2)
        assert(rewrite[0] != rewrite[1])

# Generated at 2022-06-23 23:08:27.548864
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    importer = SixMovesTransformer()
    assert importer

# Generated at 2022-06-23 23:08:33.563614
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert x.name == "name"
    y = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert y.new_attr == "old_attr"
    z = MovedAttribute("name", "old_mod", "new_mod")
    assert z.new_attr == 'name'

# Generated at 2022-06-23 23:08:36.292193
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('configparser', '_some_module')
    assert mod.name == 'configparser'
    assert mod.new == 'configparser'
    assert mod.old == '_some_module'


# Generated at 2022-06-23 23:08:38.005243
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-23 23:08:41.610360
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"

# Generated at 2022-06-23 23:08:53.031608
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == "builtins"
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == "filter"

# Generated at 2022-06-23 23:09:04.164542
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

    ma = MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
    assert ma.name == "getcwdb"
    assert ma.new_mod == "os"
    assert ma.new_attr == "getcwdb"

    ma = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert ma.name == "filter"
    assert ma.new_mod == "builtins"
    assert ma.new_attr == "filter"

# Generated at 2022-06-23 23:09:13.174454
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class Thing:
        def __init__(self, name, old=None, new=None):
            self.name = name
            self.old = old
            self.new = new
    thing = Thing('thing', 'old', 'new')
    thing_to_compare = MovedModule('thing', 'old', 'new')
    assert thing.__dict__['name'] == thing_to_compare.__dict__['name']
    assert thing.__dict__['old'] == thing_to_compare.__dict__['old']
    assert thing.__dict__['new'] == thing_to_compare.__dict__['new']


# Generated at 2022-06-23 23:09:16.694950
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"