

# Generated at 2022-06-23 22:59:21.907697
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # https://github.com/Li-xing/py2to3/issues/6
    # Several test cases that cause failure
    transformer = SixMovesTransformer(2.7)
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert transformer.rewrites[path] == 'six.moves{}.{}'.format(prefix, move.name)
            elif isinstance(move, MovedModule):
                assert transformer.rewrites[move.new] ==  'six.moves{}.{}'.format(prefix, move.name)

# Generated at 2022-06-23 22:59:24.975906
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-23 22:59:32.833300
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module1 = MovedModule("test_module1", "test_old_module1", "test_new_module1")
    moved_module2 = MovedModule("test_module2", "test_old_module2")
    assert moved_module1.name == "test_module1"
    assert moved_module1.old == "test_old_module1"
    assert moved_module1.new == "test_new_module1"
    assert moved_module2.name == "test_module2"
    assert moved_module2.old == "test_old_module2"
    assert moved_module2.new == "test_module2"

# Generated at 2022-06-23 22:59:43.547990
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 22:59:47.699068
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert(m.name == "cStringIO")
    assert(m.new_mod == "io")
    assert(m.new_attr == "StringIO")

# Generated at 2022-06-23 22:59:50.434743
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')

# Generated at 2022-06-23 22:59:55.916323
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule('name', 'old', 'new')
    assert t.name == 'name'
    assert t.old == 'old'
    assert t.new == 'new'

    t = MovedModule('name', 'old')
    assert t.name == 'name'
    assert t.old == 'old'
    assert t.new == 'name'


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 22:59:59.329716
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-23 23:00:08.756470
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"
    assert MovedModule("copyreg", "copy_reg").name == "copyreg"

    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").new == "dbm.gnu"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").name == "dbm_gnu"


# Generated at 2022-06-23 23:00:09.454566
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import transforms

# Generated at 2022-06-23 23:00:18.368403
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('x', 'a', 'b')
    assert m.name == 'x'
    assert m.new_mod == 'b'
    assert m.new_attr == 'x'
    m = MovedAttribute('x', 'a', 'b', 'c')
    assert m.name == 'x'
    assert m.new_mod == 'b'
    assert m.new_attr == 'c'
    m = MovedAttribute('x', 'a', 'b', 'c', 'd')
    assert m.name == 'x'
    assert m.new_mod == 'b'
    assert m.new_attr == 'd'


# Generated at 2022-06-23 23:00:28.725581
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves.urllib.parse
    assert hasattr(six.moves.urllib.parse, "quote")
    assert hasattr(six.moves.urllib.parse, "quote_plus")
    assert hasattr(six.moves.urllib.parse, "unquote_to_bytes")
    assert hasattr(six.moves.urllib.parse, "unquote_plus")
    assert hasattr(six.moves.urllib.parse, "unquote")
    assert hasattr(six.moves.urllib.parse, "urlencode")
    assert hasattr(six.moves.urllib.parse, "splitquery")
    assert hasattr(six.moves.urllib.parse, "splittag")

# Generated at 2022-06-23 23:00:30.842131
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "Test"
    old = "Tester"
    new = "Testing"
    moved_module = MovedModule(name, old, new)
    assert moved_module.name == name
    assert moved_module.old == old
    assert moved_module.new == new

# Generated at 2022-06-23 23:00:31.975182
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None).rewrites == dict(_get_rewrites())


# Generated at 2022-06-23 23:00:33.407457
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:00:37.182316
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == \
    {'name': 'cStringIO', 'old_mod':'cStringIO', 'new_mod': 'io', 'old_attr':'StringIO', 'new_attr': None}

# Generated at 2022-06-23 23:00:40.588610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:00:44.081056
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.target == (2, 7)
    assert len(st.rewrites) == 63 # changes with every upstream version of six
    assert st.dependencies == ['six']

# Generated at 2022-06-23 23:00:48.979021
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("test", "old", "new", "old_attr", "new_attr")
    assert attr.name == 'test'
    assert attr.new_mod == 'new'
    assert attr.new_attr == 'new_attr'

# Generated at 2022-06-23 23:00:52.017267
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('modulename', 'oldname').new == 'modulename'
    assert MovedModule('modulename', 'oldname', 'newname').new == 'newname'

# Generated at 2022-06-23 23:00:54.615170
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("test", "firsttest", "secondtest")
    MovedModule("test", "firsttest")
    MovedModule("test")


# Generated at 2022-06-23 23:01:06.015056
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(
        name='name',
        old_mod='old_mod',
        new_mod='new_mod',
        old_attr='old_attr',
        new_attr='new_attr'
    )
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'

    move = MovedAttribute(
        name='name',
        old_mod='old_mod',
        new_mod='new_mod',
        old_attr='old_attr',
    )
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'old_attr'


# Generated at 2022-06-23 23:01:10.688189
# Unit test for constructor of class MovedModule
def test_MovedModule():

    moved_module = MovedModule("FullName", "FullName")
    assert moved_module.name == "FullName"
    assert moved_module.new == "FullName"

    moved_module = MovedModule("FullName", "FullName", "NewName")
    assert moved_module.name == "FullName"
    assert moved_module.new == "NewName"


# Generated at 2022-06-23 23:01:13.598604
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser", "configparser").new == "configparser"

# Generated at 2022-06-23 23:01:19.519743
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six.moves.urllib.parse
    assert six.moves.urllib.parse.quote_plus == urllib.parse.quote_plus
    assert six.moves.urllib.parse.ParseResult == urllib.parse.ParseResult

    import six.moves.configparser
    assert six.moves.configparser.ConfigParser == configparser.ConfigParser

    import six.moves.urllib.request
    assert six.moves.urllib.request.urlopen == urllib.request.urlopen

    import six.moves.urllib.error
    assert six.moves.urllib.error.URLError == urllib.error.URLError

    import six.moves.urllib.robotparser
    assert six.moves.ur

# Generated at 2022-06-23 23:01:28.863744
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:30.816944
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.new == "builtins"

# Generated at 2022-06-23 23:01:34.666468
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('test', 'source')
    assert move.name == 'test'
    assert move.new == 'test'
    assert move.old == 'source'

    move = MovedModule('test2', 'source2', 'target2')
    assert move.name == 'test2'
    assert move.new == 'target2'
    assert move.old == 'source2'

# Generated at 2022-06-23 23:01:41.188852
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .transforms import SixMovesTransformer
    from .transforms import BaseTransform
    from .base import BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseTransform)
    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    assert hasattr(SixMovesTransformer, 'rewrites')
    assert hasattr(SixMovesTransformer, 'dependencies')


# Generated at 2022-06-23 23:01:48.293615
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:52.029866
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.new == 'builtins'
    moved_module = MovedModule('configparser', 'ConfigParser', 'configparser')
    assert moved_module.name == 'configparser'
    assert moved_module.new == 'configparser'


# Generated at 2022-06-23 23:01:53.202616
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 60

# Generated at 2022-06-23 23:01:55.111184
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule(name='abc', new='def', old='ghi')
    assert module.name == 'abc'
    assert module.new == 'def'
    assert module.old == 'ghi'



# Generated at 2022-06-23 23:02:02.078374
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").__dict__ == {'name': "builtins", 'old': "__builtin__", 'new': "builtins"}
    assert MovedModule("urllib.parse", __name__ + ".moves.urllib_parse").__dict__ == {'name': "urllib.parse", 'old': __name__ + ".moves.urllib_parse", 'new': "urllib.parse"}


# Generated at 2022-06-23 23:02:11.212018
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule('tkinter', 'Tkinter')
    assert test_moved_module.name == 'tkinter'
    assert test_moved_module.old == 'Tkinter'
    assert test_moved_module.new == 'tkinter'

    test_moved_module = MovedModule('tkinter', 'Tkinter', 'tkinter')
    assert test_moved_module.name == 'tkinter'
    assert test_moved_module.old == 'Tkinter'
    assert test_moved_module.new == 'tkinter'

    test_moved_module = MovedModule('tkinter', 'Tkinter', 'tkinter.test')
    assert test_moved_module.name == 'tkinter'

# Generated at 2022-06-23 23:02:15.267331
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    for rewrite in transformer.rewrites:
        assert rewrite[0].startswith('six.moves')
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 23:02:24.328126
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test a constructor with parameters,
    # and check that all the fields are set correctly.
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"

    # Test a constructor without parameters for old_attr
    # and check that the default value is used.
    attr = MovedAttribute("name2", "old_mod2", "new_mod2", "old_attr2")
    assert attr.name == "name2"
    assert attr.new_mod == "new_mod2"
    assert attr.new_attr == "old_attr2"

    # Test a constructor without parameters

# Generated at 2022-06-23 23:02:25.863487
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 30

# Generated at 2022-06-23 23:02:32.064662
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # test constructor with all parameters
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'
    # test constructor with only required parameter
    m = MovedModule('name')
    assert m.name == 'name'
    assert m.old == m.new == 'name'

# Generated at 2022-06-23 23:02:37.831316
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("m1", "m2", "m3")
    assert x.name == "m1"
    assert x.old == "m2"
    assert x.new == "m3"
    x = MovedModule("m1", "m2")
    assert x.name == "m1"
    assert x.old == "m2"
    assert x.new == "m1"

# Generated at 2022-06-23 23:02:40.434721
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-23 23:02:47.113065
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'
    moved_module = MovedModule('name', 'old')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'name'



# Generated at 2022-06-23 23:02:51.045144
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from_module = 'a.b'
    target_module = 'c'
    attribute = 'd'
    moved_module = MovedModule(attribute, from_module, target_module)
    assert moved_module.name == attribute
    assert moved_module.new == target_module

# Generated at 2022-06-23 23:02:56.147942
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # This should work
    MovedAttribute("cStringIO", "cStringIO", "io")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    # This should not work
    with pytest.raises(AssertionError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    with pytest.raises(AssertionError):
        MovedAttribute("cStringIO", "cStringIO", "io", "", "StringIO")


# Generated at 2022-06-23 23:03:02.941881
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('module', 'old', 'new')
    assert moved_module.name == 'module'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'

    moved_module = MovedModule('module', 'old')
    assert moved_module.name == 'module'
    assert moved_module.old == 'old'
    assert moved_module.new == 'module'


# Generated at 2022-06-23 23:03:13.396699
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:03:17.685548
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import builtins
    assert builtins.__name__ == 'builtin'
    t = SixMovesTransformer()
    assert t.rewrites[0][1] == 'six.moves.cStringIO'
    assert t.rewrites[-1][1] == 'six.moves.urllib.parse'

# Generated at 2022-06-23 23:03:19.545144
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-23 23:03:26.010809
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("a", "b", "c")
    assert move.name == "a"
    assert move.new_mod == "c"
    assert move.new_attr == "a"

    move = MovedAttribute("a", "b", "c", "d", "e")
    assert move.name == "a"
    assert move.new_mod == "c"
    assert move.new_attr == "e"


# Generated at 2022-06-23 23:03:34.328991
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    aa = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert aa.name == "cStringIO"
    assert aa.new_mod == "io"
    assert aa.new_attr == "StringIO"

    aa = MovedAttribute("cStringIO", "cStringIO", "io")
    assert aa.name == "cStringIO"
    assert aa.new_mod == "io"
    assert aa.new_attr == "cStringIO"

    aa = MovedAttribute("cStringIO", "cStringIO", "io", "")
    assert aa.name == "cStringIO"
    assert aa.new_mod == "io"
    assert aa.new_attr == ""

# Generated at 2022-06-23 23:03:37.170232
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("a", "b")
    assert m.name == "a"
    assert m.new == "b"


# Generated at 2022-06-23 23:03:41.723857
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Given, When
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    # Then
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:51.593236
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("reload", "imp", "importlib")
    assert x.name == 'reload'
    assert x.old_mod is None
    assert x.new_mod == 'importlib'
    assert x.old_attr is None
    assert x.new_attr is None

    x = MovedAttribute("reload", "imp", "importlib", "reload")
    assert x.name == 'reload'
    assert x.old_mod is None
    assert x.new_mod == 'importlib'
    assert x.old_attr is None
    assert x.new_attr == 'reload'

    x = MovedAttribute("reload", "imp", "importlib", "reload", "reimport")
    assert x.name == 'reload'
    assert x.old_mod is None
   

# Generated at 2022-06-23 23:03:56.734692
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(MagicMock(target_version=(2, 7)))
    assert not transformer.skip_file

    assert transformer.dependencies == ['six']
    assert transformer.mod_name == 'SixMovesTransformer'
    assert transformer.target == (2, 7)
    rewrites = _get_rewrites()
    assert transformer.rewrites == rewrites

# Generated at 2022-06-23 23:04:05.794070
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-23 23:04:13.144815
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) == 54
    assert len(_urllib_parse_moved_attributes) == 22
    assert len(_urllib_error_moved_attributes) == 3
    assert len(_urllib_request_moved_attributes) == 34
    assert len(_urllib_response_moved_attributes) == 4
    assert len(_urllib_robotparser_moved_attributes) == 1

# Generated at 2022-06-23 23:04:22.179376
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"


# Generated at 2022-06-23 23:04:28.880561
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").old == "bar"
    assert MovedModule("foo", "bar").new == "foo"
    assert MovedModule("foo", "bar", "baz").old == "bar"
    assert MovedModule("foo", "bar", "baz").new == "baz"



# Generated at 2022-06-23 23:04:30.564615
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 46

# Generated at 2022-06-23 23:04:36.663970
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__') == MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__', '__builtin__') == MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__', '__builtin__2') != MovedModule('builtins', '__builtin__')

# Test that the rewrites are not empty

# Generated at 2022-06-23 23:04:48.214903
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    if sys.version_info < (2, 7):
        # SixMovesTransformer should be instantiated and work correctly
        # even if the current version of python is < 2.7
        trans = SixMovesTransformer()
        assert trans.module_map == {}
        assert trans.rewrites == list(_get_rewrites())
    else:
        # if python is 2.7 or newer, six.moves module won't be available
        # and thus transformer shouldn't work.
        # Specific exception is thrown to allow test to run on python version >= 2.7
        exc_info = None
        try:
            SixMovesTransformer()
        except ImportError as exc:
            exc_info = exc.args
        assert exc_info == ('No module named moves',)

# Generated at 2022-06-23 23:04:50.607707
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    r = _get_rewrites()
    assert t.rewrites == r


# Generated at 2022-06-23 23:04:58.655600
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io',
                          'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').new_attr == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO',
                          'io', 'StringIO', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io',
                          new_attr='new_attr').new_attr == 'new_attr'



# Generated at 2022-06-23 23:05:04.178008
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for SixMovesTransformer

    Raises
    ------
    AssertionError
        If unit test fails

    """
    from fix_imports import SixMovesTransformer
    from . import utils

    script = """
        import six.moves.urllib.parse
        import six.moves.urllib.error
        import six.moves.urllib.request
        import six.moves.urllib.response
        import six.moves.urllib.robotparser
    """

    test_suite = utils.generate_test_suite(script)
    transformer = SixMovesTransformer(None, test_suite)
    transformer.run()


# Generated at 2022-06-23 23:05:13.844314
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Unit test for constructor of class SixMovesTransformer"""
    import sys
    import unittest
    import astroid
    from astroid import MANAGER
    from pylint.checkers import imports
    from pylint.testutils import CheckerTestCase, Message

    if sys.version_info[:2] != (2, 7):
        # No need to test the targetted version, do not display error message
        return

    class TestSixMovesTranformer(CheckerTestCase):
        CHECKER_CLASS = imports.ImportsChecker


# Generated at 2022-06-23 23:05:20.237037
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").name == "copyreg"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"


# Generated at 2022-06-23 23:05:30.458971
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils.helpers import get_dummy_module

    # noinspection PyProtectedMember
    dummy_module = get_dummy_module(txt='''
    from six.moves import html_parser, urllib
    from six.moves.urllib import request
    ''')
    transformer = SixMovesTransformer(dummy_module)
    assert transformer._from_imports == {'six.moves': ['html_parser', 'urllib.request']}
    assert transformer._from_imports_level == {'six.moves': 0}
    assert transformer._from_imports_full == {'six.moves': ['html_parser', 'urllib.request']}

# Generated at 2022-06-23 23:05:42.442562
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("foo", "bar", "baz")
    assert move.name == "foo"
    assert move.new_mod == "baz"
    assert move.new_attr == "foo"

    move = MovedAttribute("foo", "bar", "baz", "qux", "quux")
    assert move.name == "foo"
    assert move.new_mod == "baz"
    assert move.new_attr == "quux"

    move = MovedAttribute("foo", "bar", "baz", "qux")
    assert move.name == "foo"
    assert move.new_mod == "baz"
    assert move.new_attr == "qux"

    move = MovedAttribute("foo", "bar", "baz", new_attr="quux")
    assert move.name

# Generated at 2022-06-23 23:05:43.903666
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer(None, None)
    assert hasattr(instance, 'rewrites')

# Generated at 2022-06-23 23:05:50.834739
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from copy import copy
    import sys
    # test that constructed object is a MovedModule object
    mod = MovedModule('pytest', 'test')
    assert type(mod) == MovedModule
    # test that attributes 'name' and 'mod' of the MovedModule object
    # are initialized
    assert mod.name == 'pytest'
    assert mod.new == 'test'
    assert mod.old == None
    # test that the constructor of MovedModule object can also be
    # called with three arguments
    # test that the attribute 'old' of the MovedModule object is
    # initialized if a third argument is passed to the constructor
    mod_copy = copy(mod)
    mod_copy.old = 'test.py'
    mod_orig = MovedModule('pytest', 'test', 'test.py')

# Generated at 2022-06-23 23:05:52.369635
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer._rewrites) == 2 * len(prefixed_moves) - 3    # 3 prefixes without rewrites

# Generated at 2022-06-23 23:05:53.180264
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:56.651154
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                assert isinstance(move, MovedAttribute) == True
            elif isinstance(move, MovedModule):
                assert isinstance(move, MovedModule) == True

# Generated at 2022-06-23 23:06:07.809191
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 23:06:15.709405
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("old_attr", "old_mod", "new_mod")
    assert attr.name == attr.new_attr == "old_attr"
    assert attr.new_mod == "new_mod"

    attr = MovedAttribute("old_attr", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "old_attr"
    assert attr.new_attr == "new_attr"
    assert attr.new_mod == "new_mod"

    attr = MovedAttribute("old_attr", "old_mod", "new_mod", "old_attr")
    assert attr.name == attr.new_attr == "old_attr"
    assert attr.new_mod == "new_mod"

    att

# Generated at 2022-06-23 23:06:18.912784
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule('name', 'old', 'new')
    assert movedModule.name == 'name'
    assert movedModule.new == 'new'



# Generated at 2022-06-23 23:06:22.888572
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('queue', 'Queue')
    assert module.name == 'queue'
    assert module.old == 'Queue'
    assert module.new == 'queue'


# Generated at 2022-06-23 23:06:27.072055
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert a.name == "name"
    assert a.new_mod == "new_mod"
    assert a.new_attr == "new_attr"


# Generated at 2022-06-23 23:06:36.761928
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

    move = MovedAttribute("cStringIO", "cStringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "cStringIO"
    assert move.new_attr == "cStringIO"



# Generated at 2022-06-23 23:06:46.886091
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').name == 'filter'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == 'builtins'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'

# Generated at 2022-06-23 23:06:50.315209
# Unit test for constructor of class MovedModule
def test_MovedModule():
    exception = MovedModule("exception", "foo", "bar")
    assert exception.name == "exception"
    assert exception.old is None
    assert exception.new == "bar"

# Generated at 2022-06-23 23:06:54.017277
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        MovedAttribute('a', 'b')
    except TypeError as e:
        assert False, str(e)

    try:
        MovedAttribute('a', 'b', old_attr='c', new_attr='d')
    except TypeError as e:
        assert False, str(e)

    try:
        MovedAttribute('a', 'b', old_mod='c')
    except TypeError as e:
        assert False, str(e)


# Generated at 2022-06-23 23:06:58.645534
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule(False, 1)
    with pytest.raises(TypeError):
        MovedModule(1, '2')
    with pytest.raises(TypeError):
        MovedModule('1', '')
    with pytest.raises(TypeError):
        MovedModule(1, False)


# Generated at 2022-06-23 23:07:02.369454
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert transformer.target == (2, 7)
    assert_equal(transformer.dependencies, ['six'])
    assert_equal(transformer.rewrites, _get_rewrites())


# Generated at 2022-06-23 23:07:03.594670
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()

# Generated at 2022-06-23 23:07:12.500500
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('email_mime_base', 'email.MIMEBase', 'email.mime.base')
    assert module.name == 'email_mime_base'
    assert module.new == 'email.mime.base'
    module = MovedModule('email_mime_base', 'email.MIMEBase')
    assert module.new == 'email_mime_base'
    module = MovedModule('email_mime_base')
    assert module.name == 'email.mime.base'


# Generated at 2022-06-23 23:07:17.151900
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    assert moved_module.name == '_dummy_thread'
    assert moved_module.new == '_dummy_thread'
    assert moved_module.old == 'dummy_thread'



# Generated at 2022-06-23 23:07:19.947683
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    t = ('foo', 'bar', 'foo')
    assert (mm.name, mm.old, mm.new) == t


# Generated at 2022-06-23 23:07:23.115375
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import module_load
    from . import SixMovesTransformer
    m = module_load()
    p = m.path
    print(list(SixMovesTransformer().run(m)))

# Generated at 2022-06-23 23:07:26.014555
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Just run constructor, it will fail if rewrites are not set.
    SixMovesTransformer()

# Generated at 2022-06-23 23:07:29.474425
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('foo', 'one', 'two', 'l', 'r')
    assert obj.name == 'foo'
    assert obj.new_mod == 'two'
    assert obj.new_attr == 'r'



# Generated at 2022-06-23 23:07:32.994427
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"



# Generated at 2022-06-23 23:07:35.226508
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer(None)


# 6to5 style import from this module (e.g., from six_moves import ...)

# Generated at 2022-06-23 23:07:37.764142
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    m = SixMovesTransformer()
    assert m.target == (2, 7)
    assert m.rewrites == _get_rewrites()
    assert m.dependencies == ['six']

# Generated at 2022-06-23 23:07:48.072521
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute('a', 'b', 'c', 'd', 'e')
    assert x.name == 'a'
    assert x.new_mod == 'b'
    assert x.new_attr == 'd'
    x = MovedAttribute('a', 'b', 'c')
    assert x.name == 'a'
    assert x.new_mod == 'b'
    assert x.new_attr == 'a'
    x = MovedAttribute('a', 'b', 'c', 'd')
    assert x.name == 'a'
    assert x.new_mod == 'b'
    assert x.new_attr == 'd'

# Generated at 2022-06-23 23:07:49.521499
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 161

# Generated at 2022-06-23 23:07:56.150755
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Tests doing nothing is working."""
    move = MovedAttribute("a", "b", "c")
    assert move.name == "a"
    assert move.new_mod == "c"
    assert move.new_attr == "a"
    move = MovedAttribute("a", "b", "c", old_attr="d")
    assert move.name == "a"
    assert move.new_mod == "c"
    assert move.new_attr == "d"
    move = MovedAttribute("a", "b", "c", new_attr="d")
    assert move.name == "a"
    assert move.new_mod == "c"
    assert move.new_attr == "d"

# Generated at 2022-06-23 23:08:06.467613
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('test', 'old', 'new')
    assert mm.name == 'test'
    assert mm.old == 'old'
    assert mm.new == 'new'
    mm = MovedModule('test', 'old')
    assert mm.name == 'test'
    assert mm.old == 'old'
    assert mm.new == 'test'
    mm = MovedModule('six.moves.t', 'six.moves.t')
    assert mm.name == 'six.moves.t'
    assert mm.old == 'six.moves.t'
    assert mm.new == 'six.moves.t'


# Generated at 2022-06-23 23:08:12.220605
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = list(SixMovesTransformer().rewrites)
    assert len(rewrites) == len(_moved_attributes + _urllib_parse_moved_attributes
                                + _urllib_error_moved_attributes
                                + _urllib_request_moved_attributes
                                + _urllib_response_moved_attributes
                                + _urllib_robotparser_moved_attributes)

# Generated at 2022-06-23 23:08:15.720846
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"


# Generated at 2022-06-23 23:08:20.199036
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.filter' in SixMovesTransformer.rewrites.keys()
    assert 'six.moves.urllib.parse.urlparse' in SixMovesTransformer.rewrites.keys()

# Generated at 2022-06-23 23:08:26.879844
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ba = MovedAttribute("foo", "mod", "newmod", "x", "y")
    assert ba.name == "foo"
    assert ba.new_mod == "newmod"
    assert ba.new_attr == "y"
    ba = MovedAttribute("foo", "mod", "newmod", "x")
    assert ba.new_attr == "x"
    ba = MovedAttribute("foo", "mod", "newmod")
    assert ba.new_attr == "foo"

# Generated at 2022-06-23 23:08:29.593403
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    expected = set(['six.moves.filter', 'six.moves.map'])
    result = set(t.rewrites.keys())
    assert result == expected

# Generated at 2022-06-23 23:08:32.030382
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.new == 'new'

# Generated at 2022-06-23 23:08:35.863369
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_mod = MovedModule("test_mod", "old_mod", "new_mod")
    assert test_mod.name == "test_mod"
    assert test_mod.old == "old_mod"
    assert test_mod.new == "new_mod"

    test_mod = MovedModule("test_mod", "old_mod")
    assert test_mod.name == "test_mod"
    assert test_mod.old == "old_mod"
    assert test_mod.new == "test_mod"

# Generated at 2022-06-23 23:08:40.918694
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", None).name == "name" \
        and MovedModule("name", "old", None).new == "name" \
        and MovedModule("name", "old", None).old == "old"
    assert MovedModule("name", "old", "new").name == "name" \
        and MovedModule("name", "old", "new").new == "new" \
        and MovedModule("name", "old", "new").old == "old"


# Generated at 2022-06-23 23:08:42.561110
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:08:44.564230
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.__class__.__name__ == 'SixMovesTransformer'
    assert s.target == (2, 7)
    assert s.__class__.rewrites is not None

# Generated at 2022-06-23 23:08:51.239835
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for test_case in _moved_attributes:
        if isinstance(test_case, MovedAttribute):
            move_attribute = MovedAttribute(test_case.name, test_case.old_mod, test_case.new_mod)  # noqa: E501
            assert move_attribute.name == test_case.name
            assert move_attribute.new_mod == test_case.new_mod
            assert move_attribute.new_attr == test_case.name

# Generated at 2022-06-23 23:08:57.476305
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule('queue', 'Queue')
        MovedModule('queu')
        MovedModule('que', 'Queue', 'que')
        MovedModule('qu', 'Queue', 'qu')
        MovedModule(1, 'Queue')
        MovedModule('queue', 1)
        MovedModule('queue', 'Queue', 1)
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-23 23:09:07.256913
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six.moves.urllib.parse as module
    from six.moves.urllib.parse import urldefrag
    import sys
    sys.path.append('.')
    transformer = SixMovesTransformer()

# Generated at 2022-06-23 23:09:10.930501
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("hello", "world").name == "hello"
    assert MovedModule("hello", "world").new == "world"
    assert MovedModule("hello", "world").old == "world"

# Generated at 2022-06-23 23:09:17.638342
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        move_names = []
        for move in moves:
            if isinstance(move, MovedAttribute):
                move_names.append('{}.{}'.format(move.new_mod, move.new_attr))
            elif isinstance(move, MovedModule):
                move_names.append(move.new)
        assert set(SixMovesTransformer.rewrites.keys()) == set(move_names)