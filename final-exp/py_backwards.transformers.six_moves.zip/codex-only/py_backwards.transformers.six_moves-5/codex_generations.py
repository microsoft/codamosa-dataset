

# Generated at 2022-06-23 22:59:19.479072
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")) == "<MovedAttribute cStringIO>"

# Generated at 2022-06-23 22:59:21.479256
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    '''
    If this passes, the SixMovesTransformer constructor was executed
    '''
    pass

# Generated at 2022-06-23 22:59:25.136178
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"



# Generated at 2022-06-23 22:59:28.346041
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("tkinter_tix", "Tix", "tkinter.tix")
    assert m.name == "tkinter_tix"
    assert m.new == "tkinter.tix"

# Generated at 2022-06-23 22:59:32.508147
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Arrange
    name = 'name'
    old = 'old'
    new = 'new'

    # Act
    result = MovedModule(name, old, new)

    # Assert
    assert result.name == 'name'
    assert result.old == 'old'
    assert result.new == 'new'


# Generated at 2022-06-23 22:59:38.472860
# Unit test for constructor of class MovedModule
def test_MovedModule():
    cases = [
        (('os', 'os', ''), "MovedModule('os', 'os')"),
        (('CGIHTTPServer', 'CGIHTTPServer', 'http.server'), "MovedModule('CGIHTTPServer', 'CGIHTTPServer', 'http.server')")
    ]
    for (args, expected_output) in cases:
        assert MovedModule(*args).__repr__() == expected_output

# Generated at 2022-06-23 22:59:49.434987
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert str(MovedAttribute("foobar", "old_mod", "new_mod")) == \
        "MovedAttribute(name='foobar', old_mod='old_mod', new_mod='new_mod')"
    assert str(MovedAttribute("foobar", "old_mod", "new_mod", "old_attr", "new_attr")) == \
        "MovedAttribute(name='foobar', old_mod='old_mod', new_mod='new_mod', old_attr='old_attr', new_attr='new_attr')"
    assert str(MovedAttribute("foobar", "old_mod", "new_mod", "old_attr")) == \
        "MovedAttribute(name='foobar', old_mod='old_mod', new_mod='new_mod', old_attr='old_attr')"



# Generated at 2022-06-23 22:59:59.712685
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('copyreg', 'copy_reg').name == 'copyreg'
    assert MovedModule('copyreg', 'copy_reg').new == 'copyreg'
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu').name == 'dbm_gnu'
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu').new == 'dbm.gnu'

# Generated at 2022-06-23 23:00:04.386404
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves
    for name in _get_rewrites():
        if 'six' in name[1]:
            assert hasattr(six, name[1].split('.')[1])
        elif 'moves' in name[1]:
            assert hasattr(six.moves, name[1].split('.')[2])

# Generated at 2022-06-23 23:00:06.737543
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test for constructor of MovedModule.

    In the MovedModule constructor, the new argument can be omitted and give
    the same value as the name argument.  We test that the assignment works.
    """
    module = MovedModule('name')
    assert module.name == 'name'
    assert module.new == 'name'

# Generated at 2022-06-23 23:00:15.019834
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"


# Generated at 2022-06-23 23:00:23.436820
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:28.439504
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that the SixMovesTransformer is constructed"""
    t = SixMovesTransformer
    assert ["os.getcwd", "six.moves.getcwd"] in t.rewrites
    assert ["urllib.parse.urlparse", "six.moves.urllib_parse.urlparse"] in t.rewrites

# Generated at 2022-06-23 23:00:31.118173
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer({
        'six': (1, 0),
    })
    assert transformer.rewrites == SixMovesTransformer.rewrites
    assert transformer.dependencies == SixMovesTransformer.dependencies

# Generated at 2022-06-23 23:00:33.298268
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("configparser", "ConfigParser")
    assert module.name == "configparser"
    assert module.new == "configparser"
    assert module.old == "ConfigParser"

# Generated at 2022-06-23 23:00:42.992277
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('test', 'old', 'new')
    assert moved_attribute.name == 'test'
    assert moved_attribute.old_mod == 'old'
    assert moved_attribute.new_mod == 'new'
    assert moved_attribute.old_attr is None
    assert moved_attribute.new_attr == 'test'

    moved_attribute = MovedAttribute('test', 'old', 'new', 'old_attr')
    assert moved_attribute.new_attr == 'old_attr'

    moved_attribute = MovedAttribute('test', 'old', 'new', None, 'new_attr')
    assert moved_attribute.new_attr == 'new_attr'

    moved_attribute = MovedAttribute('test', 'old', 'new', 'old_attr', 'new_attr')
    assert moved_attribute.new

# Generated at 2022-06-23 23:00:47.777709
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('test_module', 'test_old', 'test_new')
    assert moved_module.name == 'test_module'
    assert moved_module.old == 'test_old'
    assert moved_module.new == 'test_new'


# Generated at 2022-06-23 23:00:57.195161
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

    # Check that the right number of rewrites were extracted
    assert len(transformer.rewrites) is 512  # type: ignore

    # Check that the right rewrites were extracted
    assert transformer.rewrites[0] == ('builtins.filter', 'six.moves.filter')
    assert transformer.rewrites[126] == ('io.StringIO', 'six.moves.cStringIO.StringIO')
    assert transformer.rewrites[512 - 1] == ('urllib.robotparser.RobotFileParser',
                                             'six.moves.urllib_robotparser.RobotFileParser')

# Generated at 2022-06-23 23:01:05.430671
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == 'cStringIO'
    assert a.new_mod == 'io'
    assert a.new_attr == 'StringIO'
    assert a.old_attr == 'StringIO'
    b = MovedAttribute("cStringIO", "cStringIO", "io")
    assert b.name == 'cStringIO'
    assert b.new_mod == 'io'
    assert b.new_attr == 'cStringIO'
    assert b.old_attr == 'cStringIO'

# Generated at 2022-06-23 23:01:10.921354
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    move = MovedAttribute("name", "old_mod", "new_mod")
    move = MovedAttribute("name", "old_mod", None)
    move = MovedAttribute("name", "old_mod", None, "old_attr")



# Generated at 2022-06-23 23:01:21.913063
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Create an virtual module for testing
    class Module(object):
        lines = []
        def insert_import(self, index, module, name=None):
            if name is None:
                name = module
            self.lines.insert(index, 'import {} as {}\n'.format(module, name))
        def __getitem__(self, i):
            return self.lines[i]
        def __len__(self):
            return len(self.lines)

    module = Module()

# Generated at 2022-06-23 23:01:23.699611
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:01:32.431782
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("CookieJar", "cookielib", "http.cookiejar")
    assert m.name == "CookieJar"
    assert m.new_mod == "http.cookiejar"
    assert m.new_attr == "CookieJar"

    m = MovedAttribute("repr", "__builtin__", None)
    assert m.name == "repr"
    assert m.new_mod == "repr"
    assert m.new_attr == "repr"

    m = MovedAttribute("StringIO", "cStringIO", "io", "StringIO")
    assert m.name == "StringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-23 23:01:42.324641
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                expected_result = 'six.moves{}.{}'.format(prefix, move.name)
                assert (path, expected_result) in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                path = move.new
                expected_result = 'six.moves{}.{}'.format(prefix, move.name)
                assert (path, expected_result) in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:01:45.228672
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"

# Generated at 2022-06-23 23:01:47.880776
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('module_name', 'old_name', 'new_name')
    assert moved_module.name == 'module_name'
    assert moved_module.old == 'old_name'
    assert moved_module.new == 'new_name'


# Generated at 2022-06-23 23:01:51.251559
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer('2.7', verbose=True)
    assert transformer.target == (2, 7)
    assert transformer.verbose
    assert len(transformer.rewrites) == 93


if __name__ == "__main__":
    # Run the unit tests
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-23 23:01:53.996520
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
  assert ma.name == "cStringIO"
  assert ma.new_mod == "io"
  assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:01:55.089616
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-23 23:01:56.438365
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer.rewrites) == list(_get_rewrites())

# Generated at 2022-06-23 23:02:01.251332
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name","old_mod","new_mod","old_attr","new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-23 23:02:06.331300
# Unit test for constructor of class MovedModule
def test_MovedModule():
    i = 0
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedModule):
                assert move.name == '_urllib_robotparser'
                assert move.new == 'urllib.robotparser'
                i += 1
    assert i == 1

# Generated at 2022-06-23 23:02:07.453318
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:02:11.109198
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("winreg", "_winreg")
    assert MovedModule("winreg", "_winreg").name == "winreg"
    assert MovedModule("winreg", "_winreg").new == "winreg"


# Generated at 2022-06-23 23:02:16.208973
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ATTR = MovedAttribute('test', 'test_old_mod', 'test_new_mod', old_attr='test_old_attr', new_attr='test_new_attr')
    assert ATTR.name == 'test'
    assert ATTR.new_mod == 'test_new_mod'
    assert ATTR.new_attr == 'test_new_attr'


# Generated at 2022-06-23 23:02:21.077657
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert attr.name == 'cStringIO', "name should be 'cStringIO'"
    assert attr.new_mod == 'io', "new_mod should be 'io'"
    assert attr.new_attr == 'StringIO', "new_attr should be 'StringIO'"

# Generated at 2022-06-23 23:02:24.112514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('arg1', 'arg2', 'arg3')
    assert obj.name == 'arg1'
    assert obj.old == 'arg2'
    assert obj.new == 'arg3'

# Generated at 2022-06-23 23:02:30.510147
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    t = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert t.name == "cStringIO"
    assert t.new_mod == "cStringIO"
    assert t.new_attr == "StringIO"

    t = MovedAttribute("cStringIO", "cStringIO", "io")
    assert t.new_attr == "cStringIO"


# Generated at 2022-06-23 23:02:32.912011
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six.moves
    # Just check that module six.moves exists
    assert six.moves is not None


# Generated at 2022-06-23 23:02:37.831510
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_moved_attribute.name == "cStringIO"
    assert test_moved_attribute.new_mod == "io"
    assert test_moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-23 23:02:44.147483
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from darglint.refactor import RefactoringTool
    from darglint.config import load_yaml
    with open('tests/data/config.yml') as f:
        ref = RefactoringTool(load_yaml(f))
        assert SixMovesTransformer.rewrites == ref.get_rewrites()
        assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:02:47.404396
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"


# Generated at 2022-06-23 23:02:55.693313
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for constructor of class MovedAttribute
    move = MovedAttribute("name1", "old_mod1", "new_mod1", "old_attr1", "new_attr1")
    move2 = MovedAttribute("name2", "old_mod2", None, None, None)
    move3 = MovedAttribute("name3", None, "new_mod3", None, None)
    assert move.name == 'name1'
    assert move.new_mod == 'new_mod1'
    assert move.new_attr == 'new_attr1'
    assert move2.name == 'name2'
    assert move2.new_mod == 'name2'
    assert move2.new_attr == 'name2'
    assert move3.name == 'name3'

# Generated at 2022-06-23 23:03:05.639196
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_attr == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").new_attr == "old_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"



# Generated at 2022-06-23 23:03:10.744262
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old', 'new')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'new'

    b = MovedModule('name', 'old')
    assert b.name == 'name'
    assert b.old == 'old'
    assert b.new == 'name'



# Generated at 2022-06-23 23:03:14.504233
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("a", "b", "c")
    assert x.name == "a"
    assert x.old == "b"
    assert x.new == "c"
    x = MovedModule("d", "e")
    assert x.name == "d"
    assert x.old == "e"
    assert x.new == "d"


# Generated at 2022-06-23 23:03:18.726126
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name','old','new')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'


# Generated at 2022-06-23 23:03:24.829482
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_MovedAttribute.name == "cStringIO"
    assert test_MovedAttribute.old_mod == "cStringIO"
    assert test_MovedAttribute.new_mod == "io"
    assert test_MovedAttribute.old_attr == "StringIO"


# Generated at 2022-06-23 23:03:33.747402
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 98
    assert len(SixMovesTransformer.dependencies) == 1

    urllib_parse_moved_attributes_length = len(_urllib_parse_moved_attributes)
    assert urllib_parse_moved_attributes_length == 20

    urllib_parse_moved_attributes_first = _urllib_parse_moved_attributes[0]
    assert urllib_parse_moved_attributes_first.name == 'ParseResult'
    assert urllib_parse_moved_attributes_first.new_mod == 'urllib.parse'
    assert urllib_parse_moved_attributes_first.new_attr == 'ParseResult'

    urllib_parse_moved_

# Generated at 2022-06-23 23:03:46.047506
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import re
    import textwrap
    # Unit test with an import statement
    input_file_path = '/path/to/SampleClass.py'
    input_code = textwrap.dedent("""
        import urlparse
        import pipes
        import urllib

        def sample_method():
            pass
    """)
    input_code_without_leading_newlines = re.sub(r'(?m)^\n', '', input_code)
    output_code = textwrap.dedent("""
        from six.moves import urllib, urlparse
        import pipes

        def sample_method():
            pass
    """)
    output_code_without_leading_newlines = re.sub(r'(?m)^\n', '', output_code)

# Generated at 2022-06-23 23:03:46.811163
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer

# Generated at 2022-06-23 23:03:50.127005
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"


# Generated at 2022-06-23 23:03:52.554159
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("name", "old")
    assert test.name == "name"
    assert test.old == "old"
    assert test.new == "name"

# Generated at 2022-06-23 23:03:55.821577
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Ensure that SixMovesTransformer is being created correctly."""
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.target == (2,7)

# Generated at 2022-06-23 23:04:05.110195
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("arg1", "mod1", "new_mod", "arg2", "new_attr").name == "arg1"
    assert MovedAttribute("arg1", "mod1", "new_mod", "arg2", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("arg1", "mod1", "new_mod", "arg2", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("arg1", "mod1", "new_mod", "arg2").name == "arg1"
    assert MovedAttribute("arg1", "mod1", "new_mod", "arg2").new_mod == "new_mod"
    assert MovedAttribute("arg1", "mod1", "new_mod", "arg2").new_attr == "arg2"

# Generated at 2022-06-23 23:04:09.933157
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    assert 'six.moves' in sys.modules

    # Create SixMovesTransformer object and make sure _get_rewrites
    # is called before constructor
    six_moves_transformer_object = SixMovesTransformer()



# Generated at 2022-06-23 23:04:12.144557
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six
    item = six.moves.StringIO  # type: ignore
    assert item



# Generated at 2022-06-23 23:04:20.697853
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # empty string
    move = MovedModule("", "__builtin__")
    assert move.name == ""
    assert move.new == ""
    # None
    move = MovedModule(None, "__builtin__")
    assert move.name == None
    assert move.new == None
    # nomral case
    move = MovedModule("abc", "__builtin__")
    assert move.name == "abc"
    assert move.new == "__builtin__"
    # new name
    move = MovedModule("abc", "__builtin__", "__builtin_d__")
    assert move.name == "abc"
    assert move.new == "__builtin_d__"

# Generated at 2022-06-23 23:04:30.713390
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def __test_SixMovesTransformer():
        """
        str(SixMovesTransformer(None))
        """
    from .. import testing
    from .. import utils
    from . import base
    from .sixmoves import SixMovesTransformer
    testing.run_test_module_by_name(__name__)
    t = utils.get_doctest_examples(__test_SixMovesTransformer)
    assert len(t) == 1
    expected = 'Replaces moved modules with ones from `six.moves`.'
    actual = base.BaseImportRewrite.__doc__.strip().split("\n")[0]
    assert actual == expected

# Generated at 2022-06-23 23:04:37.391058
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import py2to3.fixes.sixmoves

# Generated at 2022-06-23 23:04:42.592059
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").old == "old"


# Generated at 2022-06-23 23:04:52.357259
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("foo", "bar", "qux", "old_attr_name", "new_attr_name")
    assert move.name == "foo"
    assert move.old_mod == "bar"
    assert move.new_mod == "qux"
    assert move.old_attr == "old_attr_name"
    assert move.new_attr == "new_attr_name"

    move = MovedAttribute("foo", "bar", None, "old_attr_name", "new_attr_name")
    assert move.new_mod == "foo"

    move = MovedAttribute("foo", "bar", "qux", "old_attr_name", None)
    assert move.new_attr == "old_attr_name"


# Generated at 2022-06-23 23:04:55.492928
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # If a moved module occurs in both 2.7 and 3.x, 2.7 gets a higher
    # priority and so should be included first in the rewrites list.
    assert SixMovesTransformer.rewrites[0][0] == 'queue.Queue'

# Generated at 2022-06-23 23:05:00.052303
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert test.name == "filter"
    assert test.new_mod == "builtins"
    assert test.new_attr == "filter"


# Generated at 2022-06-23 23:05:05.657112
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    instance_1 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert instance_1.name == 'name'
    assert instance_1.new_mod == 'new_mod'
    assert instance_1.new_attr == 'new_attr'
    instance_2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert instance_2.name == 'name'
    assert instance_2.new_mod == 'new_mod'
    assert instance_2.new_attr == 'old_attr'
    instance_3 = MovedAttribute("name", "old_mod", "new_mod")
    assert instance_3.name == 'name'
    assert instance_3.new_mod == 'new_mod'

# Generated at 2022-06-23 23:05:07.188454
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.filter' in SixMovesTransformer._rewrites

# Generated at 2022-06-23 23:05:13.361958
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old') != MovedModule('name', 'old2')
    assert MovedModule('name', 'old') != MovedModule('name2', 'old')
    assert MovedModule('name', 'old') != MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'old')

# Generated at 2022-06-23 23:05:19.820984
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import ast
    import six

    mod = ast.parse('__import__("six.moves").moves')
    assert not sys.modules.get(mod.body[0].value.args[0].s)
    SixMovesTransformer.rewrites = six.moves._moved_attributes
    SixMovesTransformer.visit(mod)
    assert mod.body[0].value.args[0].s == 'six.moves'
    del SixMovesTransformer.rewrites


# Generated at 2022-06-23 23:05:24.981886
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-23 23:05:32.347697
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:36.664422
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert (st.rewrites, st.module) == _get_rewrites()


transform = SixMovesTransformer.needing_dependencies

# Generated at 2022-06-23 23:05:41.899972
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('foo', 'bar', 'baz', 'a', 'b')
    MovedAttribute('foo', 'bar', 'baz', 'a')
    MovedAttribute('foo', 'bar', 'baz')
    with pytest.raises(TypeError):
        MovedAttribute('foo', 'bar', 'baz', 'a', 'b', 'c')


# Generated at 2022-06-23 23:05:53.333133
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert type(x) == MovedAttribute
    assert x.name == "cStringIO"
    assert x.old_mod == "cStringIO"
    assert x.new_mod == "io"
    assert x.old_attr == "StringIO"
    assert x.new_attr == "StringIO"
    assert x.__dict__ == dict(name='cStringIO', new_mod='io', new_attr='StringIO')

    y = MovedAttribute("cStringIO")
    assert y.name == "cStringIO"
    assert y.old_mod == "cStringIO"
    assert y.new_mod == "cStringIO"
    assert y.old_attr is None

# Generated at 2022-06-23 23:05:55.718700
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # the 'set' function is not supported by Python 2
    assert set(SixMovesTransformer._get_rewrites()) == set(_get_rewrites())

# Generated at 2022-06-23 23:06:03.033182
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # test the default constructor
    item = MovedModule("UserString", "UserString")
    assert item.name == item.new == "UserString"

    # test the non-default constructor
    item = MovedModule("UserString", "UserString", "collections")
    assert item.name == "UserString"
    assert item.new == "collections"

    # test the old constructor
    item = MovedModule("UserString", "UserString", new="collections")
    assert item.name == "UserString"
    assert item.new == "collections"

# Generated at 2022-06-23 23:06:10.648927
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def t(source, target):
        return SixMovesTransformer._check_six(source, target)

    assert t('six.moves.input', '__builtin__.input')
    assert t('six.moves.builtins.input', '__builtin__.input')
    assert t('six.moves', '')
    assert t('six.moves.urllib', 'six.moves.urllib')
    assert t('six.moves.urllib.parse.ParseResult', 'urllib.ParseResult')
    assert t("six.moves.builtins.map(int, 'hello')", "__builtin__.map(int, 'hello')")
    assert t("six.moves.builtins.input()", "__builtin__.raw_input()")
    assert t

# Generated at 2022-06-23 23:06:13.721916
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("builtins", "__builtin__")
    assert mod.name == "builtins"
    assert mod.new == "builtins"
    assert mod.old == "__builtin__"



# Generated at 2022-06-23 23:06:14.989494
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None, None).rewrites == set(rewrites)

# Generated at 2022-06-23 23:06:26.638387
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("builtins", "__builtin__")
    assert x.name == "builtins"
    assert x.old == "__builtin__"
    assert x.new == "builtins"
    x = MovedModule("configparser", "ConfigParser")
    assert x.name == "configparser"
    assert x.old == "ConfigParser"
    assert x.new == "configparser"
    x = MovedModule("copyreg", "copy_reg")
    assert x.name == "copyreg"
    assert x.old == "copy_reg"
    assert x.new == "copyreg"
    x = MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert x.name == "dbm_gnu"
    assert x.old == "gdbm"


# Generated at 2022-06-23 23:06:27.694499
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:06:37.714242
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites is _get_rewrites()
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)
    assert transformer.applies_to('six.moves') is True
    assert transformer.applies_to('six.moves.urllib.parse') is True
    assert transformer.applies_to('six.moves.urllib.error') is True
    assert transformer.applies_to('six.moves.urllib.request') is True
    assert transformer.applies_to('six.moves.urllib.response') is True
    assert transformer.applies_to('six.moves.urllib.robotparser') is True

# Generated at 2022-06-23 23:06:41.868426
# Unit test for constructor of class MovedModule
def test_MovedModule():
    p = MovedModule('name', 'old', 'new')
    assert p.name == 'name'
    assert p.old == 'old'
    assert p.new == 'new'
    assert str(p) == 'name (new)'


# Generated at 2022-06-23 23:06:49.891437
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule('builtins', '__builtin__')
    assert(mm1.name == 'builtins')
    assert(mm1.old == '__builtin__')
    assert(mm1.new == 'builtins')

    mm2 = MovedModule('builtins', '__builtin__', 'builtins')
    assert(mm2.name == 'builtins')
    assert(mm2.old == '__builtin__')
    assert(mm2.new == 'builtins')

    mm3 = MovedModule('builtins', '__builtin__', '__builtin__')
    assert(mm3.name == 'builtins')
    assert(mm3.old == '__builtin__')
    assert(mm3.new == 'builtins')


# Generated at 2022-06-23 23:06:53.957305
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(TypeError):
        SixMovesTransformer()
    # TypeError: Can't instantiate abstract class SixMovesTransformer
    with pytest.raises(NotImplementedError):
        SixMovesTransformer.get_rewrites()

# Generated at 2022-06-23 23:07:01.242291
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None, None)

# Generated at 2022-06-23 23:07:09.247139
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test input of MovedAttribute.  Name string and default new_mod (name).
    move = MovedAttribute("cStringIO", "cStringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "cStringIO"
    assert move.new_attr is None
    move = MovedAttribute("cStringIO", "cStringIO", new_attr="StringIO")
    assert move.new_attr == "StringIO"


# Generated at 2022-06-23 23:07:13.060329
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("string", "string_old")
    assert moved_module.name == "string"
    assert moved_module.new == "string"
    assert moved_module.old == "string_old"


# Generated at 2022-06-23 23:07:14.074535
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    print(SixMovesTransformer)

# Generated at 2022-06-23 23:07:19.412772
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name','old_mod','new_mod','old_attr','new_attr').name == "name"
    assert MovedAttribute('name','old_mod','new_mod','old_attr','new_attr').new_mod == "new_mod"
    assert MovedAttribute('name','old_mod','new_mod','old_attr','new_attr').new_attr == "new_attr"


# Generated at 2022-06-23 23:07:21.858011
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 23:07:24.918343
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(MovedModule("name", "old")) == "MovedModule('name', old, name)"
    assert repr(MovedModule("name", "old")) == "MovedModule('name', old, name)"

# Generated at 2022-06-23 23:07:26.267939
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"


# Generated at 2022-06-23 23:07:31.290264
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = MovedModule('name', 'old')
    assert moves.name == 'name'
    assert moves.old == 'old'
    assert moves.new == 'name'
    moves = MovedModule('name', 'old', 'new')
    assert moves.name == 'name'
    assert moves.old == 'old'
    assert moves.new == 'new'



# Generated at 2022-06-23 23:07:32.946479
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule("builtins", "__builtin__"), MovedModule)

# Generated at 2022-06-23 23:07:36.263275
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert not hasattr(SixMovesTransformer, '_rewrites')

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:07:43.964814
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:07:47.649510
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    # If this is moved to a separate module, that module must also
    # be imported by the test.
    assert six.moves.winreg.__name__ == "winreg"

# Generated at 2022-06-23 23:07:48.718290
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()



# Generated at 2022-06-23 23:07:49.765349
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()



# Generated at 2022-06-23 23:07:51.123782
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-23 23:07:57.593471
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Unit test for MovedAttribute"""
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'

    ma = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma.name == 'name'
    assert ma.new_mod == 'name'
    assert ma.new_attr == 'name'

    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'old_attr'


# Unit test

# Generated at 2022-06-23 23:08:01.495407
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:08:08.407079
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").__dict__ == {
        'name': 'name',
        'new_mod': 'new_mod',
        'new_attr': 'name'
    }
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").__dict__ == {
        'name': 'name',
        'new_mod': 'new_mod',
        'new_attr': 'new_attr'
    }
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").__dict__ == {
        'name': 'name',
        'new_mod': 'new_mod',
        'new_attr': 'old_attr'
    }

# Generated at 2022-06-23 23:08:16.524957
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:20.672301
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    r = SixMovesTransformer()
    assert len(r.rewrites) == len(_get_rewrites())
    assert r.target == (2, 7)
    assert r.dependencies == ['six']

# Generated at 2022-06-23 23:08:24.457523
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("queue", "Queue")
    assert moved_module.name == "queue"
    assert moved_module.old == "Queue"
    assert moved_module.new == "queue"


# Generated at 2022-06-23 23:08:28.487522
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m_attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m_attr.name == "cStringIO"
    assert m_attr.new_mod == "io"
    assert m_attr.new_attr == "cStringIO"


# Generated at 2022-06-23 23:08:38.058909
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("range", "__builtin__", "builtins", "xrange", "range").name == "range"
    assert MovedAttribute("range", "__builtin__", "builtins", "xrange", "range").new_mod == "builtins"
    assert MovedAttribute("range", "__builtin__", "builtins", "xrange", "range").new_attr == "range"

# Generated at 2022-06-23 23:08:41.276038
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    expected = {'name': 'name', 'old': 'old', 'new': 'new'}
    assert moved_module.__dict__ == expected


# Generated at 2022-06-23 23:08:46.775839
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old").old == "old"

# Generated at 2022-06-23 23:08:58.333887
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()

# Generated at 2022-06-23 23:09:00.738333
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for path, _ in _get_rewrites():
        assert path[0] == 's' or path[0] == 'f'

# Generated at 2022-06-23 23:09:07.721249
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("module_name", "package_name", "new_module_name") == MovedModule("module_name", "package_name")
    assert MovedModule("module_name", "package_name").name == "module_name"
    assert MovedModule("module_name", "package_name").new == "module_name"
    assert MovedModule("module_name", "package_name", "new_module_name").name == "module_name"
    assert MovedModule("module_name", "package_name", "new_module_name").new == "new_module_name"


# Generated at 2022-06-23 23:09:12.150729
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name')
    assert a.name == 'name'
    assert a.new == 'name'

    b = MovedModule('name', 'old', 'new')
    assert b.name == 'name'
    assert b.new == 'new'



# Generated at 2022-06-23 23:09:15.396245
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import SixMovesTransformer
    from .utils.testing import check
    from . import transforms

    transforms.install_builtin_transforms()
    check(SixMovesTransformer)



# Generated at 2022-06-23 23:09:20.574139
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.new == "name"
    moved_module_with_new = MovedModule("name", "old", "new")
    assert moved_module_with_new.name == "name"
    assert moved_module_with_new.new == "new"

