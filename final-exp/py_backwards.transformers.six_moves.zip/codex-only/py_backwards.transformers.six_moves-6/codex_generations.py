

# Generated at 2022-06-23 22:59:25.584371
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("m", "o", "n")
    assert m.name == "m"
    assert m.new_mod == "n"
    assert m.new_attr == "m"

    m = MovedAttribute("m", "o", "n", "o", "n")
    assert m.name == "m"
    assert m.new_mod == "n"
    assert m.new_attr == "n"

    m = MovedAttribute("m", "o", "n", "o")
    assert m.name == "m"
    assert m.new_mod == "n"
    assert m.new_attr == "o"

    m = MovedAttribute("m", "o", None, "o")
    assert m.name == "m"
    assert m.new_mod == "m"


# Generated at 2022-06-23 22:59:27.659059
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(AttributeError):
        # noinspection PyStatementEffect
        SixMovesTransformer()

# Generated at 2022-06-23 22:59:34.891636
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_attr == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").new_attr == "old_attr"


# Generated at 2022-06-23 22:59:40.742911
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert x.name == 'name'
    assert x.new_mod == 'new_mod'
    assert x.new_attr == 'new_attr'
    y = MovedAttribute('name', 'old_mod', 'new_mod')
    assert y.name == 'name'
    assert y.new_mod == 'new_mod'
    assert y.new_attr == 'name'
    z = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert z.name == 'name'
    assert z.new_mod == 'new_mod'
    assert z.new_attr == 'old_attr'

# Generated at 2022-06-23 22:59:48.119173
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("winreg", "_winreg")
    assert moved_module.name == "winreg"
    assert moved_module.new == "winreg"

    moved_module = MovedModule("winreg", "_winreg", "winreg32")
    assert moved_module.name == "winreg"
    assert moved_module.new == "winreg32"

    with pytest.raises(TypeError):
        MovedModule(None, "_winreg", "winreg32")

# Generated at 2022-06-23 22:59:52.135691
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    source = """
    import urllib
    """
    expected = """
    import six.moves.urllib
    """
    transformer = SixMovesTransformer(source)
    assert transformer.code == expected
    assert transformer.has_changes
    assert transformer.source == source

# Generated at 2022-06-23 22:59:56.364686
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule("a", "b")
    assert moved.name == "a"
    assert moved.new == "a"

    moved = MovedModule("a", "b", "c")
    assert moved.name == "a"
    assert moved.new == "c"


# Generated at 2022-06-23 22:59:58.988874
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # This import is needed because of the eager annotations in SixMovesTransformer
    from .six_moves_transformer import SixMovesTransformer
    SixMovesTransformer().rewrites

# Generated at 2022-06-23 23:00:01.692292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    assert SixMovesTransformer._get_rewrites()[0] == \
        ('io.StringIO', 'six.moves.cStringIO')

# Generated at 2022-06-23 23:00:05.002755
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-23 23:00:07.647410
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('test', 'test', 'test1')
    assert mm.name == 'test'
    assert mm.new == 'test1'

    mm = MovedModule('test', 'test')

# Generated at 2022-06-23 23:00:13.972305
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # basic test as in six
    ma = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert str(ma) == 'filter'
    assert ma.name == 'filter'
    assert ma.new_mod == 'builtins'
    assert ma.new_attr == 'filter'
    # new attr is None
    ma = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', None)
    assert str(ma) == 'filter'
    assert ma.new_attr == 'filter'
    # old attr is None
    ma = MovedAttribute('filter', 'itertools', 'builtins', None, 'filter')
    assert str(ma) == 'filter'
    assert ma.new_attr == 'filter'
    # both attrs are

# Generated at 2022-06-23 23:00:19.789640
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'new'
    obj = MovedModule('name', 'old')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'name'
    assert repr(obj) == 'MovedModule(name, old, new=None)'


# Generated at 2022-06-23 23:00:22.647847
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('module_name', 'old_name', 'new_name')
    assert mm.name == 'module_name'
    assert mm.old == 'old_name'
    assert mm.new == 'new_name'


# Generated at 2022-06-23 23:00:32.885939
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma1.name == "cStringIO"
    assert ma1.new_mod == "io"
    assert ma1.new_attr == "cStringIO"
    ma2 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma2.name == "cStringIO"
    assert ma2.new_mod == "io"
    assert ma2.new_attr == "StringIO"
    ma3 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert ma3.name == "filter"
    assert ma3.new_mod == "builtins"
    assert ma3.new_attr == "filter"
    ma4 = Moved

# Generated at 2022-06-23 23:00:36.561409
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("my_module", "my_old_module", "my_new_module")
    assert moved_module.name == "my_module"
    assert moved_module.old == "my_old_module"
    assert moved_module.new == "my_new_module"



# Generated at 2022-06-23 23:00:42.813671
# Unit test for constructor of class MovedModule
def test_MovedModule():

    moved_module = MovedModule('module1', 'module2')
    assert moved_module.name == "module1"
    assert moved_module.new == "module1"
    assert moved_module.old == None

    moved_module = MovedModule('module1', 'module2', 'module3')
    assert moved_module.name == "module1"
    assert moved_module.new == "module3"
    assert moved_module.old == None


# Generated at 2022-06-23 23:00:47.979363
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-23 23:00:59.436961
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import six
    # _moved_attributes is not available by default in Python 2.7
    if sys.version_info[:2] == (2, 7):
        for prefix, moves in prefixed_moves:
            for move in moves:
                if isinstance(move, MovedAttribute):
                    path = '{}.{}'.format(move.new_mod, move.new_attr)
                    # The result should be available in six.moves
                    assert getattr(six, 'moves' + prefix)[move.name]
                    # And the result should be imported
                    assert move.new_mod in sys.modules
                    assert move.new_attr in sys.modules[move.new_mod].__all__
                    # And the result should be available in the original module

# Generated at 2022-06-23 23:01:09.605035
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'

    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == 'filter'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'filter'

    move = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert move.name == 'input'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'input'


# Generated at 2022-06-23 23:01:20.492354
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('cStringIO', 'cStringIO', "io")
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'cStringIO'
    attr = MovedAttribute('cStringIO', 'cStringIO', "io", 'StringIO')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'
    attr = MovedAttribute('cStringIO', 'cStringIO', "io", old_attr='StringIO')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'

# Generated at 2022-06-23 23:01:29.747327
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from repair.utils import unparse
    from repair.transformer import RepairTransformer
    import ast
    import sys
    source_code = """
import re
import six
from six.moves import urllib
"""
    tree = ast.parse(source_code)
    transformer = SixMovesTransformer()
    transformer = RepairTransformer(transformer, sys.version_info.major)
    transformed_tree = transformer.visit(tree)
    transformed_source_code = unparse(transformed_tree)
    assert transformed_source_code == """
import re
import six
import urllib
"""
    transformer = SixMovesTransformer()
    transformer = RepairTransformer(transformer, sys.version_info.major)
    transformed_tree = transformer.visit(tree)

# Generated at 2022-06-23 23:01:31.038098
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-23 23:01:37.017093
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute(
        name="cStringIO",
        old_mod="cStringIO",
        new_mod="io",
        old_attr="StringIO",
        new_attr=None
    )
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "cStringIO"

# Generated at 2022-06-23 23:01:46.276812
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "mod", "newmod")
    assert attr.name == "name"
    assert attr.new_mod == "newmod"
    assert attr.new_attr == "name"

    attr = MovedAttribute("name", "mod", "newmod", "attr")
    assert attr.new_attr == "attr"

    attr = MovedAttribute("name", "mod", "newmod", None, "attr")
    assert attr.new_attr == "attr"

    attr = MovedAttribute("name", "mod", "newmod", "attr", "newattr")
    assert attr.new_mod == "newmod"
    assert attr.new_attr == "newattr"


# Generated at 2022-06-23 23:01:50.128178
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'name'
    old_mod = 'old_mod'
    new_mod = 'new_mod'
    old_attr = 'old_attr'
    new_attr = 'new_attr'

    move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)

    assert move.name == name
    assert move.new_mod == new_mod
    assert move.new_attr == new_attr

# Generated at 2022-06-23 23:01:52.111726
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("winreg", "_winreg")

    assert mm.name == "winreg"
    assert mm.new == "winreg"


# Generated at 2022-06-23 23:01:54.743732
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # This is needed because the class definition above is effectively
    #   class SixMovesTransformer:
    #       ...
    #
    #   SixMovesTransformer = eager(SixMovesTransformer)
    #
    # and so nose tests the function in place of the class.
    assert isinstance(SixMovesTransformer, type)

# Generated at 2022-06-23 23:02:06.002900
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"

    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"

    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "old_attr"


# Generated at 2022-06-23 23:02:08.045677
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    importer = SixMovesTransformer()
    assert importer.rewrites == dict(_get_rewrites())

# Generated at 2022-06-23 23:02:13.898837
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    moved_modules = []
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedModule):
                moved_modules.append(move)
    for move in moved_modules:
        if isinstance(move, MovedModule):
            assert move.name in six.moves.__dict__
            assert move.new in six.moves.__dict__

# Generated at 2022-06-23 23:02:23.413126
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(AttributeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "after").new_attr == "after"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "after").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "after").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "after").new_attr == "after"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "").new_attr == "cStringIO"

# Unit

# Generated at 2022-06-23 23:02:35.501656
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six

# Generated at 2022-06-23 23:02:38.533165
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    r = MovedAttribute(name="open", new_mod="io", old_attr="open", new_attr="open")
    assert r.name == "open"
    assert r.new_attr == "open"

# Generated at 2022-06-23 23:02:50.040719
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr0 = MovedAttribute("name", "old_mod", "new_mod")
    assert attr0.new_mod == "new_mod"
    assert attr0.new_attr == "name"
    attr1 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert attr1.new_mod == "new_mod"
    assert attr1.new_attr == "old_attr"
    attr2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr2.new_mod == "new_mod"
    assert attr2.new_attr == "new_attr"

# Generated at 2022-06-23 23:02:53.231508
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mova = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert mova.name == 'cStringIO'
    assert mova.new_mod == 'io'
    assert mova.new_attr == 'StringIO'



# Generated at 2022-06-23 23:02:57.120319
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule(name = 'name', old = 'old', new = 'new')
    assert mm.name == 'name' and mm.old == 'old' and mm.new == 'new'


# Generated at 2022-06-23 23:03:07.145521
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import stubs
    from . import utils
    from . import test_six_moves

    importlib.reload(test_six_moves)
    importlib.reload(stubs)
    importlib.reload(utils)
    from .test_six_moves import test_SixMovesTransformer_import_rewrites

    six_moves_integration = SixMovesTransformer()
    kwargs = test_SixMovesTransformer_import_rewrites()

    assert kwargs.__class__.__name__ == "dict"
    assert kwargs['import_rewrites'] == six_moves_integration.rewrites

# Generated at 2022-06-23 23:03:12.109201
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer._get_rewrites() == SixMovesTransformer.rewrites
    assert len(SixMovesTransformer.rewrites) == 116
    assert ('cookielib', 'six.moves.http_cookiejar') in SixMovesTransformer.rewrites
    assert ('operator.index', 'six.moves.operator') not in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:03:14.358091
# Unit test for constructor of class MovedModule
def test_MovedModule(): # pylint: disable=unused-variable, function-redefined, redefined-outer-name
    MovedModule("builtins", "__builtin__")
    MovedModule("configparser", "ConfigParser", "configparser")

# Generated at 2022-06-23 23:03:22.997555
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test case 1:
    # Without importing new module, only original name given
    test_module = MovedModule("test_module","test_module")
    assert test_module.name == "test_module"
    assert test_module.new == "test_module"

    # Test case 2:
    # Without importing new module, original and new name given
    test_module = MovedModule("new_test_module","test_module")
    assert test_module.name == "new_test_module"
    assert test_module.new == "new_test_module"


# Generated at 2022-06-23 23:03:24.170061
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:03:28.375333
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"



# Generated at 2022-06-23 23:03:33.277869
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:03:43.272406
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule("builtins","__builtin__")
    assert m1.name == "builtins"
    assert m1.new == "builtins"

    m2 = MovedModule("copyreg", "copy_reg")
    assert m2.name == "copyreg"
    assert m2.new == "copyreg"

    m3 = MovedModule("tkinter_simpledialog", "SimpleDialog", "tkinter.simpledialog")
    assert m3.name == "tkinter_simpledialog"
    assert m3.new == "tkinter.simpledialog"



# Generated at 2022-06-23 23:03:52.224243
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = [MovedModule("builtins", "__builtin__"),
             MovedModule("configparser", "ConfigParser"),
             MovedModule("dbm_gnu", "gdbm", "dbm.gnu"),
             MovedModule("urllib_parse", "moves.urllib_parse"),
             MovedModule("urllib_error", "moves.urllib_error"),
             MovedModule("urllib_request", "moves.urllib_request"),
             MovedModule("urllib_response", "moves.urllib_response"),
             MovedModule("urllib_robotparser", "urllib.robotparser")]
    for move in moves:
        assert move.name in move.new

# Generated at 2022-06-23 23:04:02.392465
# Unit test for constructor of class MovedModule

# Generated at 2022-06-23 23:04:08.246283
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('a', 'b', 'c')
    assert a.name == 'a'
    assert a.new_mod == 'c'
    assert a.new_attr == 'a'

    a = MovedAttribute('a', 'b', 'c', 'old_attr', 'new_attr')
    assert a.name == 'a'
    assert a.new_mod == 'c'
    assert a.new_attr == 'new_attr'

    a = MovedAttribute('a', 'b', 'c', new_attr='new_attr')
    assert a.name == 'a'
    assert a.new_mod == 'c'
    assert a.new_attr == 'new_attr'

    a = MovedAttribute('a', 'b', 'c', 'old_attr')

# Generated at 2022-06-23 23:04:19.228847
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for move in _moved_attributes + _urllib_parse_moved_attributes + _urllib_error_moved_attributes + _urllib_request_moved_attributes + _urllib_response_moved_attributes + _urllib_robotparser_moved_attributes:
        if isinstance(move, MovedModule):
            assert move.new in SixMovesTransformer.rewrites
            assert SixMovesTransformer.rewrites[move.new] == 'six.moves{}.{}'.format(prefix, move.name)
        if isinstance(move, MovedAttribute):
            if move.new_attr is None:
                assert '.'.join([move.new_mod, move.new_attr]) in SixMovesTransformer.rewrites
                assert SixMovesTrans

# Generated at 2022-06-23 23:04:28.123397
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "name"
    attr = MovedAttribute("name", "old_mod", "new_mod", old_attr="old_attr")
    assert attr.new_attr == "old_attr"
    attr = MovedAttribute("name", "old_mod", "new_mod", old_attr="old_attr", new_attr="new_attr")
    assert attr.new_attr == "new_attr"

# Generated at 2022-06-23 23:04:38.176835
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    ma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "cStringIO"
    ma = MovedAttribute("cStringIO", "cStringIO", None)
    assert ma.name == "cStringIO"
    assert ma.new_mod == "cStringIO"
    assert ma.new_attr == "cStringIO"

# Generated at 2022-06-23 23:04:43.520792
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("a", 1, 2, 3, 4)
    assert m.name == "a"
    assert m.new_mod == 1
    assert m.new_attr == 3
    m = MovedAttribute("b", 2)
    assert m.new_mod == 2
    assert m.new_attr == "b"

# Generated at 2022-06-23 23:04:49.450231
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for move in _moved_attributes:
        if isinstance(move, MovedAttribute):
            if move.old_mod == None:
                assert move.old_attr == None
                assert move.old_attr == move.new_attr
                assert move.old_mod == move.new_mod
            else:
                assert move.old_attr != None
                assert move.old_attr != move.new_attr

# Generated at 2022-06-23 23:04:59.777201
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute('a', 'b', 'c')
    assert moved.name == 'a'
    assert moved.new_mod == 'c'
    assert moved.new_attr == 'a'

    moved = MovedAttribute('a', 'b', None, 'x', 'y')
    assert moved.name == 'a'
    assert moved.new_mod == 'a'
    assert moved.new_attr == 'y'

    moved = MovedAttribute('a', 'b', None, 'x')
    assert moved.name == 'a'
    assert moved.new_mod == 'a'
    assert moved.new_attr == 'x'

    moved = MovedAttribute('a', 'b', None, new_attr='y')
    assert moved.name == 'a'
    assert moved.new_mod == 'a'

# Generated at 2022-06-23 23:05:01.697737
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("name", "old", "new")
    assert test_module.name == "name"
    assert test_module.old == "old"
    assert test_module.new == "new"


# Generated at 2022-06-23 23:05:10.854977
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert moved_attr.name == 'cStringIO'
    assert moved_attr.new_mod == 'io'
    assert moved_attr.new_attr == 'StringIO'
    moved_attr = MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    assert moved_attr.name == 'input'
    assert moved_attr.new_mod == 'builtins'
    assert moved_attr.new_attr == 'input'


# Generated at 2022-06-23 23:05:20.122568
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"
    attr = MovedAttribute("cStringIO", "cStringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "cStringIO"
    assert attr.new_attr == "cStringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"


# Unit test

# Generated at 2022-06-23 23:05:21.850706
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0

# Generated at 2022-06-23 23:05:26.145334
# Unit test for constructor of class MovedModule
def test_MovedModule():
    global _moved_attributes
    for i,move in enumerate(_moved_attributes):
        if isinstance(move, MovedModule):
            assert move.name == move.new
        else:
            assert move.name == move.old_attr

# Generated at 2022-06-23 23:05:33.881778
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'
    ma = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'name'
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'old_attr'

# Generated at 2022-06-23 23:05:44.368699
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("test", "mod1", "mod2")
    if not (moved.name == "test" and moved.new_mod == "mod2" and moved.new_attr == "test"):
        raise AssertionError
    moved = MovedAttribute("test", "mod1", "mod2", "old_test", "new_test")
    if not (moved.name == "test" and moved.new_mod == "mod2" and moved.new_attr == "new_test"):
        raise AssertionError
    moved = MovedAttribute("test", "mod1")
    if not (moved.name == "test" and moved.new_mod == "test" and moved.new_attr == "test"):
        raise AssertionError

# Generated at 2022-06-23 23:05:55.556460
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").__dict__ == \
        {'name': 'name', 'old_mod': 'old_mod', 'new_mod': 'new_mod', 'old_attr': None, 'new_attr': None}
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").__dict__ == \
        {'name': 'name', 'old_mod': 'old_mod', 'new_mod': 'new_mod', 'old_attr': 'old_attr', 'new_attr': 'old_attr'}

# Generated at 2022-06-23 23:05:58.688383
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 23:06:02.522133
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    p = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert p.name == "cStringIO"
    assert p.new_mod == "io"
    assert p.new_attr == "StringIO"


# Generated at 2022-06-23 23:06:09.093065
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old_name")
    assert moved_module.name == "name"
    assert moved_module.new == "name"
    assert moved_module.old == "old_name"
    moved_module = MovedModule("name", "old_name", "new_name")
    assert moved_module.name == "name"
    assert moved_module.new == "new_name"
    assert moved_module.old == "old_name"


# Generated at 2022-06-23 23:06:11.646814
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").new == "bar"
    assert MovedModule("foo", "bar", "baz").new == "baz"


# Generated at 2022-06-23 23:06:16.916717
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('name', 'old', 'new')
    assert moved.name == 'name'
    assert moved.old == 'old'
    assert moved.new == 'new'

    moved = MovedModule('name', 'old')
    assert moved.name == 'name'
    assert moved.old == 'old'
    assert moved.new == 'name'

# Generated at 2022-06-23 23:06:28.522499
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule('name')

    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'

    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'

    assert MovedModule('name', 'old', new=None).name == 'name'
    assert MovedModule('name', 'old', new=None).old == 'old'

# Generated at 2022-06-23 23:06:33.565919
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule(name="name", old="old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule(name="name", old="old", new="new")
    assert m.name == "name"
    assert m.new == "new"


# Generated at 2022-06-23 23:06:40.580823
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-23 23:06:47.849559
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_1 = MovedModule("builtins", "__builtin__")
    moved_module_2 = MovedModule("configparser", "ConfigParser")
    moved_module_3 = MovedModule("urllib", "urllib")

    assert moved_module_1.name == "builtins"
    assert moved_module_1.new == "builtins"
    assert moved_module_2.name == "configparser"
    assert moved_module_2.new == "configparser"
    assert moved_module_3.name == "urllib"
    assert moved_module_3.new == "urllib"



# Generated at 2022-06-23 23:06:50.952958
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"

# Generated at 2022-06-23 23:06:58.268401
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("old_mod", "old_attr", "new_mod", "new_attr")
    assert a.name == "old_mod"
    assert a.new_mod == "new_mod"
    assert a.old_attr == "old_attr"
    assert a.new_attr == "new_attr"
    b = MovedAttribute("old_mod", "new_mod")
    assert b.name == "old_mod"
    assert b.new_mod == "new_mod"
    assert b.old_attr is None
    assert b.new_attr == "old_mod"


# Unit tests for rewrites:

# Generated at 2022-06-23 23:06:59.612656
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:07:03.538318
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("test", "old", "new", "attr", "attr")
    assert a.name == "test"
    assert a.new_mod == "new"
    assert a.new_attr == "attr"

# Generated at 2022-06-23 23:07:15.384319
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert 'aaa.bbb.ccc' == MovedAttribute('aaa.bbb.ccc', None, None).name
    assert 'aaa.bbb.ddd' == MovedAttribute('aaa.bbb.ccc', None, 'aaa.bbb.ddd').new_mod
    assert 'ccc' == MovedAttribute('aaa.bbb.ccc', None, 'aaa.bbb.ddd').new_attr
    assert 'ccc' == MovedAttribute('aaa.bbb.ccc', None, 'aaa.bbb.ddd', 'xxx', 'ccc').new_attr
    assert 'YYY' == MovedAttribute('aaa.bbb.ccc', 'aaa.bbb.xxx', 'aaa.bbb.ddd', 'XXX', 'YYY').new_attr


# Generated at 2022-06-23 23:07:24.268903
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import MoveImports
    from ..tests.test_cross_version import TransformationTest
    from ..utils.helpers import get_ast_node_name
    from ..transforms.import_ import _get_module_name
    from .base import BaseTransformer
    from .six_moves import SixMovesTransformer as NewSixMovesTransformer

    # Test _get_module_name
    class TestTransformer(MoveImports, TransformationTest):
        transformer = NewSixMovesTransformer
        expected_output = "from six.moves import filter\n"
        transform_source = "from itertools import filter"
        transform_target = "from six.moves import filter"

        def test_correct_module_import_detected(self):
            """Checks that the correct module is chosen to import from."""

# Generated at 2022-06-23 23:07:30.621539
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import unittest
    # test case for MovedModule.__init__
    class TestCase(unittest.TestCase):
        def test_single_parameter(self):
            testobj = MovedModule("Queue", "queue")
            self.assertEqual(testobj.name, "Queue")
            self.assertEqual(testobj.new, "queue")
    unittest.main(exit=False, verbosity=2)

# Generated at 2022-06-23 23:07:37.476465
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:07:42.321192
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-23 23:07:44.851662
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert type(MovedAttribute("commands", "commands", "subprocess")) is MovedAttribute


# Generated at 2022-06-23 23:07:49.815947
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_MovedAttribute.name == "cStringIO"
    assert test_MovedAttribute.new_mod == "cStringIO"
    assert test_MovedAttribute.new_attr == "StringIO"


# Generated at 2022-06-23 23:07:54.571716
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("test1", "test2")
    assert x.name == "test1"
    assert x.new == "test2"
    assert x.name == "test1"
    assert x.new == "test2"
    y = MovedModule("test3", "test4", "test5")
    assert y.name == "test3"
    assert y.new == "test5"

# Generated at 2022-06-23 23:07:55.975037
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # this test only checks that the constructor doesn't raise any exceptions
    SixMovesTransformer()

# Generated at 2022-06-23 23:07:59.360073
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule("name", "old", "new")
    assert movedmodule.name == "name"
    assert movedmodule.old == "old"
    assert movedmodule.new == "new"



# Generated at 2022-06-23 23:08:01.236437
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    importer = SixMovesTransformer()
    assert importer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:08:04.800717
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')



# Generated at 2022-06-23 23:08:14.026127
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
   

# Generated at 2022-06-23 23:08:15.140730
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("builtins", "__builtin__")


# Generated at 2022-06-23 23:08:27.033430
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:36.947590
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # No rewrites, then it's empty - no need to run any
    six_moves_transformer = SixMovesTransformer([])
    assert not six_moves_transformer.check_prerequisites()


# Generated at 2022-06-23 23:08:39.390020
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('base', 'new')
    assert m.name == 'base'
    assert m.new == 'new'


# Generated at 2022-06-23 23:08:42.467209
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'


# Generated at 2022-06-23 23:08:47.388830
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

if __name__ == '__main__':
    from . import helpers, debug
    helpers.test_rewrite(SixMovesTransformer, debug.print_code_and_tree,
                         debug.code_str)
    helpers.test_rewrite(SixMovesTransformer, debug.print_diff)

# Generated at 2022-06-23 23:08:58.972615
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute(
        "cStringIO", "cStringIO", "io", "StringIO").__dict__ == \
        {'name': 'cStringIO', 'old_mod': 'cStringIO',
         'new_mod': 'io', 'old_attr': 'StringIO', 'new_attr': 'StringIO'}
    assert MovedAttribute(
        "filter", "itertools", "builtins", "ifilter", "filter").__dict__ == \
        {'name': 'filter', 'old_mod': 'itertools',
         'new_mod': 'builtins', 'old_attr': 'ifilter', 'new_attr': 'filter'}
    assert MovedAttribute(
        "filterfalse", "itertools", "itertools", "ifilterfalse",
        "filterfalse").__

# Generated at 2022-06-23 23:09:02.202548
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()
    assert hasattr(obj, 'target')
    assert hasattr(obj, 'rewrites')
    assert hasattr(obj, 'dependencies')
    assert callable(obj)

# Generated at 2022-06-23 23:09:04.077050
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:09:14.699005
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from asttokens import ASTTokens
    from flake8_polyfill import options, run
    from flake8_polyfill.tests.util import make_test_case

    argv = [
        '--disable=I999',
        '--select=S404',
        __file__,
    ]

    opts, _ = options.parse_args(argv=argv)
    style_guide = run.get_style_guide(parse_argv=False, args=opts)
    linter = style_guide.options.create_plugin_instance(style_guide)

    filename = __file__

# Generated at 2022-06-23 23:09:23.166683
# Unit test for constructor of class SixMovesTransformer