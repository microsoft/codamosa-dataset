

# Generated at 2022-06-23 22:59:16.700360
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule('name', 'old', 'new')
    assert test.name == 'name'
    assert test.old == 'old'
    assert test.new is 'new'



# Generated at 2022-06-23 22:59:18.654091
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(list(_get_rewrites())) > 0



# Generated at 2022-06-23 22:59:25.507961
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") ==\
           MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert not MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")\
           == MovedAttribute("cStringIO", "cStringIO", "io", "StringIO2")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__repr__() ==\
           "MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr='StringIO', new_attr='StringIO')"

# Generated at 2022-06-23 22:59:34.335189
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-23 22:59:40.515534
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 22:59:51.648428
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod')
    MovedAttribute('name', 'old_mod', None, 'old_attr', 'new_attr')
    MovedAttribute('name', 'old_mod', None, 'old_attr')
    MovedAttribute('name', 'old_mod', None, new_attr='new_attr')
    MovedAttribute('name', 'old_mod', None)

# Generated at 2022-06-23 23:00:01.901593
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    '''
    python -m lib2to3.fixes.fix_six.test_SixMovesTransformer
    '''
    from libmodernize.fixes.six import SixMovesTransformer as SMT
    from lib2to3.fixes.fix_wrap_imports import FixWrapImports

    # Test if SixMovesTransformer is a subclass of BaseImportRewrite
    assert issubclass(SMT, BaseImportRewrite)

    # Test if SixMovesTransformer is a subclass of FixWrapImports
    assert issubclass(SMT, FixWrapImports)

    # Test if SixMovesTransformer has the right dependencies
    assert SMT.dependencies == ['six']

    # Test if SixMovesTransformer has the right rewrites
    assert SMT.rewrites == _get_rewrites()

    return

# Generated at 2022-06-23 23:00:05.101222
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("cStringIO", "cStringIO", "io")
    MovedAttribute("cStringIO", "cStringIO")
    MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="StringIO")
    MovedAttribute("cStringIO", "cStringIO", "io", old_attr="__StringIO__", new_attr="StringIO")


# Generated at 2022-06-23 23:00:07.429330
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"



# Generated at 2022-06-23 23:00:11.642182
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('test', 'test1', 'test2')
    assert moved.name == 'test'
    assert moved.old == 'test1'
    assert moved.new == 'test2'
    moved = MovedModule('test', 'test1')
    assert moved.name == 'test'
    assert moved.old == 'test1'
    assert moved.new == 'test'


# Generated at 2022-06-23 23:00:15.317577
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Check that SixMovesTransformer works as expected."""
    assert SixMovesTransformer.rewrites == \
        dict(_get_rewrites())
    assert SixMovesTransformer.__doc__ != None

# Generated at 2022-06-23 23:00:16.283712
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:17.942235
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('os', 'os')
    assert isinstance(moved_module, MovedModule)

# Generated at 2022-06-23 23:00:28.297018
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        from six import moves
    except ImportError:
        print("Failed to import module 'six'")
        raise

    try:
        from urllib import parse, error, request, response, robotparser
    except ImportError:
        print("Failed to import module 'urllib'")
        raise

    import sys

    rewrites = SixMovesTransformer._get_rewrites()
    assert type(rewrites) is list
    assert len(rewrites) > 10
    assert len(rewrites) < 20

    # Tests for 6 moves.
    for path, rewrite in rewrites:
        assert type(path) is str
        assert type(rewrite) is str
        if path == 'http.cookies':
            assert 'six.moves' in rewrite
            assert rewrite.endswith(path)


# Generated at 2022-06-23 23:00:29.626701
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo", "old", "new")


# Generated at 2022-06-23 23:00:36.459942
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("test", "test.old", "test").new_attr == "test"
    assert MovedAttribute("test", "test.old", "test").new_mod == "test"
    assert MovedAttribute("test", "test.old", "test").name == "test"
    assert MovedAttribute("test", "test.old", "test.new").new_attr == "test"
    assert MovedAttribute(
        "test", "test.old", "test.new").new_attr == "test"
    assert MovedAttribute("test", "test.old", "test.new",
                          old_attr="old_test").new_attr == "old_test"

# Generated at 2022-06-23 23:00:40.421721
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old')
    assert moved_module.name == 'name'
    assert moved_module.new == 'name'
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.new == 'new'


# Generated at 2022-06-23 23:00:43.526126
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 23:00:55.124372
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c').new_attr == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd').new_attr == 'd'
    assert MovedAttribute('a', 'b', 'c', new_attr='d').new_attr == 'd'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'
    assert MovedAttribute('a', 'b', 'c', new_attr='d').new_attr == 'd'

    assert MovedAttribute('a', 'b', 'c').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd').name == 'a'
    assert MovedAttribute('a', 'b', 'c', new_attr='d').name == 'a'

# Generated at 2022-06-23 23:01:06.492763
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "CStringIO").name

# Generated at 2022-06-23 23:01:17.418561
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tfm = SixMovesTransformer()

# Generated at 2022-06-23 23:01:20.068388
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old')
    assert MovedModule('name', 'old') != MovedModule('name', 'old', 'new')

# Generated at 2022-06-23 23:01:23.464751
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-23 23:01:28.236960
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'foo'

    mm = MovedModule('foo', 'bar', 'yak')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'yak'


# Generated at 2022-06-23 23:01:31.221793
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('name1','old1','new1')
    assert moved.name=='name1'

if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-23 23:01:35.773241
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_object = MovedModule("name", "old")
    assert test_object.name == "name"
    assert test_object.old == "old"
    assert test_object.new == "name"
    test_object = MovedModule("name", "old", "new_name")
    assert test_object.name == "name"
    assert test_object.old == "old"
    assert test_object.new == "new_name"


# Generated at 2022-06-23 23:01:41.812553
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    basedir = os.path.abspath(os.path.dirname(__file__))
    test_file = os.path.join(basedir, "test_data", "test_six_moves_1.py")
    with open(test_file, "r") as f:
        tree = ast.parse(f.read())
    transformer = SixMovesTransformer()
    res = transformer.visit(tree)
    assert ('six.moves.urllib_parse.urlparse' in astor.to_source(res))
    assert ('six.moves.urllib_parse.quote' in astor.to_source(res))
    assert ('six.moves.urllib_parse.urlencode' in astor.to_source(res))

# Generated at 2022-06-23 23:01:48.896384
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test that constructor of class SixMovesTransformer generates
    # rewrites as expected:
    transformer = SixMovesTransformer()
    result = transformer.rewrites

    # test that method _get_rewrites produces rewrites as expected:

# Generated at 2022-06-23 23:01:52.151533
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mv = MovedModule('name', 'old')
    assert mv.name == 'name'
    assert mv.new == 'name'
    mv = MovedModule('name', 'old', 'new')
    assert mv.name == 'name'
    assert mv.new == 'new'



# Generated at 2022-06-23 23:01:54.585272
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('NewModule', 'oldmod')
    assert mm.name == 'NewModule'
    assert mm.new == 'NewModule'
    mm = MovedModule('NewModule', 'oldmod', 'newmod')
    assert mm.name == 'NewModule'
    assert mm.new == 'newmod'

# Generated at 2022-06-23 23:02:05.964117
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"

    move = MovedAttribute("zip", "itertools", "builtins", "izip", "zip")
    assert move.name == "zip"
    assert move.new_mod == "builtins"
    assert move.new_attr == "zip"


# Generated at 2022-06-23 23:02:13.243476
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").old == "__builtin__"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").old == "ConfigParser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"


# Generated at 2022-06-23 23:02:18.002032
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new is None
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "new"

# Generated at 2022-06-23 23:02:25.957530
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import sys

    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") == MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != MovedAttribute("StringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != MovedAttribute("cStringIO", "cStringIO", "builtins", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != MovedAttribute("cStringIO", "cStringIO", "io", "StingIO")

# Generated at 2022-06-23 23:02:37.311082
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:02:48.746188
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moves = [MovedAttribute("cStringsIO", "cStringsIO", "io"),
             MovedAttribute("cStringsIO", "cStringsIO", "io", "StringIO"),
             MovedAttribute("cStringsIO", "cStringsIO", "io",
                            "StringIO", "cStringsIO")]
    assert (moves[0].name, moves[0].new_mod, moves[0].new_attr) == \
        ('cStringsIO', 'io', 'cStringsIO')
    assert (moves[1].name, moves[1].new_mod, moves[1].new_attr) == \
        ('cStringsIO', 'io', 'StringIO')

# Generated at 2022-06-23 23:02:51.978921
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=no-value-for-parameter
    module = MovedModule("reprlib", "repr")
    assert module.name == "reprlib" and module.new == 'repr'



# Generated at 2022-06-23 23:02:59.025578
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('x', 'a', 'b', 'y', 'z')
    MovedAttribute('x', 'a', 'b', 'y')
    MovedAttribute('x', 'a', 'b')
    MovedAttribute('x', 'a', None)
    MovedAttribute('x', 'a', None, 'y', 'z')
    MovedAttribute('x', 'a', None, 'y')

# Generated at 2022-06-23 23:03:02.834029
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:05.026694
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('', '').name == ''
    assert MovedModule('', '').new == ''

# Generated at 2022-06-23 23:03:10.259833
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("foo", "bar")
    assert mm.name == "foo"
    assert mm.new == "foo"
    assert mm.old == "bar"

    mm = MovedModule("foo", "bar", "foobar")
    assert mm.name == "foo"
    assert mm.new == "foobar"
    assert mm.old == "bar"

# Generated at 2022-06-23 23:03:17.953784
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mv.name == "cStringIO"
    assert mv.new_mod == "io"
    assert mv.new_attr == "StringIO"

    mv2 = MovedAttribute("random", None, None)
    assert mv2.name == "random"
    assert mv2.new_mod == "random"
    assert mv2.new_attr == "random"

    mv3 = MovedAttribute("range", None, None, old_attr="xrange", new_attr="range")
    assert mv3.name == "range"
    assert mv3.new_attr == "range"

# Generated at 2022-06-23 23:03:22.999063
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    expected = "MovedAttribute(name='foo', old_mod='bar', new_mod='baz', old_attr='ker', new_attr='ker')"
    assert(repr(MovedAttribute("foo", "bar", "baz", "ker", "ker")) == expected)


# Generated at 2022-06-23 23:03:24.946580
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert hasattr(SixMovesTransformer, 'target')
    assert hasattr(SixMovesTransformer, 'rewrites')
    assert hasattr(SixMovesTransformer, 'dependencies')

# Generated at 2022-06-23 23:03:30.683160
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import urllib.parse

# Generated at 2022-06-23 23:03:38.193524
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .utils import assert_conversion
    from .common_tests.six_moves.examples import base, urllib, urllib_parse


# Generated at 2022-06-23 23:03:42.128644
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"



# Generated at 2022-06-23 23:03:47.070000
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"



# Generated at 2022-06-23 23:03:52.151473
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.new == 'new'

    moved_module = MovedModule('name', 'old')
    assert moved_module.name == 'name'
    assert moved_module.new == 'name'

    moved_module = MovedModule('name')
    assert moved_module.name == 'name'
    assert moved_module.new == 'name'


# Generated at 2022-06-23 23:03:55.366648
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _ = SixMovesTransformer()  # No error is good enough for a unit test.


if __name__ == '__main__':
    # Unit test
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:03:59.498070
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule("name", "old", new="new")
    assert m.name == "name"
    assert m.new == "new"


# Generated at 2022-06-23 23:04:03.405354
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:04:08.577703
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "name"
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "old_attr"
    attr = MovedAttribute("name", "old_mod", "new_mod", new_attr="new_attr")
    assert attr.new_attr == "new_attr"
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.new_attr

# Generated at 2022-06-23 23:04:13.530991
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"



# Generated at 2022-06-23 23:04:16.183863
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # _get_rewrites() should not be empty
    assert len(SixMovesTransformer.rewrites) > 0

# Generated at 2022-06-23 23:04:17.993938
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("moves", "six")
    assert module.name == "moves"
    assert module.old == "six"
    assert module.new == "six"

# Generated at 2022-06-23 23:04:21.043781
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old', 'new', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new'
    assert move.new_attr == 'new_attr'



# Generated at 2022-06-23 23:04:25.853354
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("old", "new")
    assert mm.name == "old"
    assert mm.new == "new"
    mm = MovedModule("old", None)
    assert mm.name == "old"
    assert mm.new == "old"


# Generated at 2022-06-23 23:04:29.670093
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule("abc", "abc")
        MovedModule("abc", "abc", "def", "ghi")

# Generated at 2022-06-23 23:04:36.232388
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").old == "bar"
    assert MovedModule("foo", "bar").new == "foo"
    assert MovedModule("foo", "bar", "baz").name == "foo"
    assert MovedModule("foo", "bar", "baz").old == "bar"
    assert MovedModule("foo", "bar", "baz").new == "baz"


# Generated at 2022-06-23 23:04:39.735539
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmod = MovedModule("builtins", "__builtin__")
    assert movedmod.name == "builtins"
    assert movedmod.new == "builtins"



# Generated at 2022-06-23 23:04:43.662304
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'

# Generated at 2022-06-23 23:04:44.584380
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == list(_get_rewrites())

# Generated at 2022-06-23 23:04:46.202129
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == list(_get_rewrites())

# Generated at 2022-06-23 23:04:54.375512
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module11 = MovedModule("configparser", "ConfigParser")
    moved_module12 = MovedModule("configparser", "ConfigParser", "configparser")
    moved_module21 = MovedModule("builtins", "__builtin__")
    moved_module22 = MovedModule("builtins", "__builtin__", "builtins")

    assert moved_module11.name == "configparser"
    assert moved_module11.old == "ConfigParser"
    assert moved_module11.new == "ConfigParser"
    assert moved_module12.name == "configparser"
    assert moved_module12.old == "ConfigParser"
    assert moved_module12.new == "configparser"
    assert moved_module21.name == "builtins"
    assert moved_module21.old == "__builtin__"
   

# Generated at 2022-06-23 23:04:55.397473
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:04:56.672931
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _ = SixMovesTransformer  # noqa

# Generated at 2022-06-23 23:05:04.765101
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    """Test if constructor of SixMovesTransformer class works well."""
    # This test requires pytest.
    assert len(_moved_attributes) == 2
    assert len(_urllib_parse_moved_attributes) == 2
    assert len(_urllib_error_moved_attributes) == 2
    assert len(_urllib_request_moved_attributes) == 2
    assert len(_urllib_response_moved_attributes) == 2
    assert len(_urllib_robotparser_moved_attributes) == 2
    assert len(prefixed_moves) == 2
    assert len(_get_rewrites()) == 2

# Generated at 2022-06-23 23:05:14.462232
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.token import NAME
    from lib2to3.fixer_util import Name
    from ..utils.pytree import Leaf, Node

    t = SixMovesTransformer
    assert t.target == (2, 7)

# Generated at 2022-06-23 23:05:17.395026
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:05:29.711139
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()

# Generated at 2022-06-23 23:05:32.528727
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """
    >>> print(MovedModule('a', 'b', 'c'))
    <MovedModule name='a', old='b', new='c'>
    """


# Generated at 2022-06-23 23:05:34.660235
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("mymodule", "mymodule", "mymodule")



# Generated at 2022-06-23 23:05:40.402327
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .six_moves import SixMovesTransformer
    from .utils import Source
    a = Source("from os import getcwd")
    b = a.getvalue()
    assert b != a
    c = Source("from six.moves.os import getcwd")
    d = c.getvalue()
    assert b == d

# Generated at 2022-06-23 23:05:45.165544
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute=MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name=="name"
    assert moved_attribute.new_mod=="new_mod"
    assert moved_attribute.new_attr=="new_attr"


# Generated at 2022-06-23 23:05:48.109263
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_attribute = MovedModule("builtins", "__builtin__")
    assert test_moved_attribute.name == "builtins"
    assert test_moved_attribute.old == "__builtin__"
    assert test_moved_attribute.new == "builtins"

# Generated at 2022-06-23 23:05:51.199628
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('foo', 'six.moves.foo')
    assert m.name == 'foo'
    assert m.new == 'foo'
    #
    m = MovedModule('foo', 'six.moves.foo', 'bar')
    assert m.name == 'foo'
    assert m.new == 'bar'



# Generated at 2022-06-23 23:06:01.900921
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute("name", "old_mod")
    assert MovedAttribute("name", "old_mod", "new_mod").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod").old_mod == "old_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", None).name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", None).old_mod == "old_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", None).new_mod

# Generated at 2022-06-23 23:06:09.861685
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old")
    assert a.name == "name"
    assert a.new_mod == "name"
    assert a.new_attr == "name"
    a = MovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert a.name == "name"
    assert a.new_mod == "new"
    assert a.new_attr == "new_attr"
    a = MovedAttribute("name", "old")
    assert a.name == "name"
    assert a.new_mod == "name"
    assert a.new_attr == "name"



# Generated at 2022-06-23 23:06:16.651818
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("builtins", "__builtin__")
    assert m.name == "builtins"
    assert m.new == "builtins"
    assert m.old == "__builtin__"
    m = MovedModule("builtins", "__builtin__", "__builtin__")
    assert m.name == "builtins"
    assert m.new == "__builtin__"
    assert m.old == "__builtin__"
    m = MovedModule("builtins", "__builtin__", "__builtins__")
    assert m.name == "builtins"
    assert m.new == "__builtins__"
    assert m.old == "__builtin__"


# Generated at 2022-06-23 23:06:25.049924
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Check the construction
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    # Check the default construction
    b = MovedAttribute("filter", "itertools", "builtins")
    assert b.name == "filter"
    assert b.new_mod == "builtins"
    assert b.new_attr == "filter"


# Generated at 2022-06-23 23:06:29.431268
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    assert moved_attribute.name == 'input'
    assert moved_attribute.new_attr == 'input'
    assert moved_attribute.new_mod == 'builtins'


# Generated at 2022-06-23 23:06:36.907022
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("tkinter", "Tkinter") == MovedModule("tkinter", "Tkinter")
    assert MovedModule("winreg", "_winreg") == MovedModule("winreg", "_winreg")
    assert MovedModule("winreg", "_winreg") != MovedModule("winreg", "winreg")
    assert MovedModule("winreg", "_winreg", "winreg") == MovedModule("winreg", "_winreg")
    assert MovedModule("tkinter", "Tkinter", "tkinter") == MovedModule("tkinter", "Tkinter")

# Generated at 2022-06-23 23:06:38.544238
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:47.944164
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    mld = SixMovesTransformer()

# Generated at 2022-06-23 23:06:49.075378
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.urllib.parse.urlparse' in SixMovesTransformer.rewrites



# Generated at 2022-06-23 23:06:50.846235
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:06:52.238788
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:55.678911
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    res = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert res.name == "cStringIO"
    assert res.new_mod == "io"
    assert res.new_attr == "StringIO"



# Generated at 2022-06-23 23:06:59.877409
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.refactor import get_fixers_from_package
    fixers = get_fixers_from_package('libmodernize.fixes.six')
    assert fixers != []
    for fixer in fixers:
        if fixer.name == 'six_moves':
            fixer = fixer(None, '2.7')
            assert len(list(fixer.rewrites)) == 63
            return
    assert False

# Generated at 2022-06-23 23:07:03.808512
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-23 23:07:13.435468
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('base', 'math', 'base')
    assert a.name == 'base'
    assert a.new_mod == 'base'
    b = MovedAttribute('foo', 'bar', 'baz')
    assert b.name == 'foo'
    assert b.new_mod == 'baz'
    c = MovedAttribute('qux', 'quux', 'quuz', 'corge', 'garply')
    assert c.name == 'qux'
    assert c.new_mod == 'quuz'
    assert c.new_attr == 'garply'


# Generated at 2022-06-23 23:07:15.955735
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(sorted(SixMovesTransformer.rewrites)) == sorted(_get_rewrites())
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:07:22.982765
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _SixMovesTransformer = SixMovesTransformer()
    assert _SixMovesTransformer.target == (2, 7)
    assert _SixMovesTransformer.rewrites == _get_rewrites()
    assert _SixMovesTransformer.dependencies == ['six']


if __name__ == '__main__':
    from logging import basicConfig, INFO
    from data.rewrite_imports import RewriteImportsData
    from tests import test_all

    basicConfig(level=INFO, format='%(levelname)s:%(message)s')
    test_all(RewriteImportsData)

# Generated at 2022-06-23 23:07:24.273157
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:07:26.555548
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    importer = SixMovesTransformer()



# Generated at 2022-06-23 23:07:28.490423
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-23 23:07:33.340865
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(MovedModule("builtins", "__builtin__")) == "MovedModule('builtins', '__builtin__')"
    assert str(MovedModule("builtins", "__builtin__", "foo")) == "MovedModule('builtins', '__builtin__', 'foo')"

# Generated at 2022-06-23 23:07:37.891107
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("getcwd", "os", "os").name == "getcwd"
    assert MovedModule("getcwd", "os", "os").new == "os"
    assert MovedModule("getcwd", "os", "os").old == "os"
    assert MovedModule("getcwd", "os").name == "getcwd"
    assert MovedModule("getcwd", "os").new == "getcwd"
    assert MovedModule("getcwd", "os").old == "os"



# Generated at 2022-06-23 23:07:49.927766
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            name = move.name
            new_name = move.new
            if isinstance(move, MovedAttribute):
                new_name = '{}.{}'.format(move.new_mod, move.new_attr)
            if move.new_attr is None or move.new_attr==move.name:
                expected = 'six.moves{}.{}'.format(prefix, name)
            else:
                expected = 'six.moves{}.{} as {}'.format(prefix, name, new_name)
            actual = SixMovesTransformer._rewrites[new_name]
            assert actual == expected
        assert ('six' in SixMovesTransformer.dependencies)

# Generated at 2022-06-23 23:07:53.175639
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"


# Generated at 2022-06-23 23:08:04.850298
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:14.097717
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    from ..utils.helpers import eager
    rewrites = [('urllib.request', 'six.moves.urllib_request'),
                ('http.server', 'six.moves.http_server'),
                ('urllib.robotparser', 'six.moves.urllib_robotparser')]
    transformer = SixMovesTransformer(None, rewrites, None)
    assert transformer.rewrites == rewrites
    assert transformer.dependencies == ['six']
    assert isinstance(transformer, BaseImportRewrite)
    assert not transformer.is_eager
    assert hasattr(transformer, 'eager')
    assert hasattr(SixMovesTransformer, 'rewrites')
    assert hasattr(SixMovesTransformer, 'eager')
   

# Generated at 2022-06-23 23:08:25.546316
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("a", "b", "c", "d", "e")
    assert ma.new_attr == "d"
    assert ma.old_attr == "d"
    ma = MovedAttribute("a", "b", "c", "d", None)
    assert ma.new_attr == "d"
    assert ma.old_attr == "d"
    ma = MovedAttribute("a", "b", "c", None, "e")
    assert ma.new_attr == "a"
    assert ma.old_attr == "a"


if __name__ == '__main__':
    import sys
    import os
    import tempfile
    from lib2to3.main import main

    stdout = sys.stdout

# Generated at 2022-06-23 23:08:26.119275
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:08:36.209623
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("MovedAttribute", "__builtin__", "builtins")
    assert move.name == 'MovedAttribute'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'MovedAttribute'

    move = MovedAttribute("MovedAttribute", "__builtin__", "builtins", "bad_attribute", "new_attribute")
    assert move.name == 'MovedAttribute'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'new_attribute'

    move = MovedAttribute("MovedAttribute", "__builtin__", "builtins", "bad_attribute")
    assert move.name == 'MovedAttribute'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'bad_attribute'

   

# Generated at 2022-06-23 23:08:43.138446
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(MovedModule('foolib', 'old.foolib', 'new.foolib').name == 'foolib')
    assert(MovedModule('foolib', 'old.foolib', 'new.foolib').new == 'new.foolib')
    assert(MovedModule('foolib', 'old.foolib').name == 'foolib')
    assert(MovedModule('foolib', 'old.foolib').new == 'foolib')


# Generated at 2022-06-23 23:08:50.919726
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert x.name == 'cStringIO'
    assert x.new_mod == 'io'
    assert x.new_attr == 'StringIO'
    x = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert x.name == 'filter'
    assert x.new_mod == 'builtins'
    assert x.new_attr == 'ifilter'


# Generated at 2022-06-23 23:08:53.539561
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:08:57.807503
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'


# Generated at 2022-06-23 23:09:01.907289
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    expr = 'MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")'
    actual = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    desired = eval(expr)
    assert actual == desired

# Generated at 2022-06-23 23:09:04.513593
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rb = SixMovesTransformer(
        target=(2, 7),
        rewrites=_get_rewrites(),
        dependencies=['six'])

    assert rb.target == (2, 7)
    assert rb.rewrites == _get_rewrites()
    assert rb.dependencies == ['six']

# Generated at 2022-06-23 23:09:07.257641
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("hello", "world")
    eq_(mm.name, "hello")
    eq_(mm.new, "hello")
    eq_(mm.old, "world")

# Generated at 2022-06-23 23:09:10.989912
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "old")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "name"



# Generated at 2022-06-23 23:09:13.615663
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name","old","new")
    assert mm.name == "name"
    assert mm.new == "new"


# Generated at 2022-06-23 23:09:18.801283
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('foo', 'bar')
    assert obj.name is 'foo'
    assert obj.old is 'bar'
    assert obj.new is 'foo'
    obj = MovedModule('foo', 'bar', 'baz')
    assert obj.name is 'foo'
    assert obj.old is 'bar'
    assert obj.new is 'baz'