

# Generated at 2022-06-23 22:59:10.388444
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert str(SixMovesTransformer) == "SixMovesTransformer()"

# Generated at 2022-06-23 22:59:19.982697
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test all four possible constructors
    mov1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mov1.name == "cStringIO"
    assert mov1.new_mod == "io"
    assert mov1.new_attr == "StringIO"

    mov2 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert mov2.name == "filter"
    assert mov2.new_mod == "builtins"
    assert mov2.new_attr == "filter"

    mov3 = MovedAttribute("intern", "__builtin__", "sys")
    assert mov3.name == "intern"
    assert mov3.new_mod == "sys"
    assert mov3.new_attr == "intern"

    mov

# Generated at 2022-06-23 22:59:30.087176
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    # Note that 'six.moves' is discarded, hence the below assert

# Generated at 2022-06-23 22:59:40.718889
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 22:59:51.886432
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    class DummyFile:
        pass
    dummy_file = DummyFile()
    dummy_file.src_data = '''
from six.moves import copyreg, builtins, urllib_parse, configparser
from six.moves.urllib.request import urlopen
from six.moves.urllib.parse import quote

import six.moves.urllib.parse

copyreg.copy_reg
builtins.filter
urllib_parse.quote
configparser.ConfigParser
urlopen('http://example.com/')
quote('http://example.com/')'''
    t = SixMovesTransformer(dummy_file)
    t.setup()

# Generated at 2022-06-23 22:59:54.120985
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_FiveImportsTransformer = SixMovesTransformer()
    assert test_FiveImportsTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:00:04.341007
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.target == (2, 7)
    assert six_moves_transformer.dependencies == ["six"]

# Generated at 2022-06-23 23:00:05.418334
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    # call base class constructor
    BaseImportRewrite.__init__(t)

# Generated at 2022-06-23 23:00:09.800824
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name", None, "new")
    assert mm.name == "name"
    assert mm.old is None
    assert mm.new == "new"


# Generated at 2022-06-23 23:00:11.766014
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('foo', 'bar', 'baz')
    assert mod.name == 'foo'
    assert mod.old == 'bar'
    assert mod.new == 'baz'

# Generated at 2022-06-23 23:00:21.563888
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedModule('n', 'o', 'n')
    assert x.name == 'n'
    assert x.new == 'n'
    assert x.old == 'o'
    x = MovedAttribute('a', 'b', 'c', 'd', 'e')
    assert x.name == 'a'
    assert x.new_mod == 'c'
    assert x.old_mod == 'b'
    assert x.new_attr == 'e'
    assert x.old_attr == 'd'
    x = MovedAttribute('a', 'b', 'c', 'd')
    assert x.name == 'a'
    assert x.new_mod == 'c'
    assert x.old_mod == 'b'
    assert x.new_attr == 'd'

# Generated at 2022-06-23 23:00:26.552524
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_obj.name == "cStringIO"
    assert move_obj.new_mod == "io"
    assert move_obj.new_attr == "StringIO"


# Generated at 2022-06-23 23:00:30.370818
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test whether move is an instance of MovedAttribute
    assert isinstance(_get_rewrites()[0][1], MovedAttribute)

    # test whether move is an instance of MovedModule
    assert isinstance(_get_rewrites()[1][1], MovedModule)

# Generated at 2022-06-23 23:00:38.406609
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('tkinter', 'Tkinter').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter').old == 'Tkinter'
    assert MovedModule('tkinter', 'Tkinter').new == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter', 'Tkinter_new').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter', 'Tkinter_new').old == 'Tkinter'

# Generated at 2022-06-23 23:00:50.097057
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # class MovedAttribute:
    # def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    nt.assert_equal(move.name, "name")
    nt.assert_equal(move.new_mod, "new_mod")
    nt.assert_equal(move.new_attr, "new_attr")

    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    nt.assert_equal(move.name, "name")
    nt.assert_equal(move.new_mod, "new_mod")

# Generated at 2022-06-23 23:00:53.651215
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server")
    assert mm.name == "CGIHTTPServer"
    assert mm.new == "http.server"


# Generated at 2022-06-23 23:00:59.086905
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_test = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute_test.name == "cStringIO"
    assert moved_attribute_test.new_mod == "io"
    assert moved_attribute_test.new_attr == "StringIO"



# Generated at 2022-06-23 23:01:09.320731
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    result = SixMovesTransformer.rewrites
    assert any('six.moves.urllib_parse' in x for x in result)
    # This test should not be here but the data structure we are testing is
    # large and complex and the test is so simple that I think it is a
    # reasonable trade-off.
    assert any('six.moves.urllib.parse' in x for x in result)
    assert any('six.moves.urllib.error' in x for x in result)
    assert any('six.moves.urllib.request' in x for x in result)
    assert any('six.moves.urllib.response' in x for x in result)
    assert not any('.urllib.robotparser' in x for x in result)

# Generated at 2022-06-23 23:01:15.189830
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod_1 = MovedModule('tensorflow', 'tensorflow')
    assert mod_1.name == 'tensorflow'
    assert mod_1.new == 'tensorflow'

    mod_2 = MovedModule('torch', 'torch', 'pt')
    assert mod_2.name == 'torch'
    assert mod_2.new == 'pt'



# Generated at 2022-06-23 23:01:21.221035
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"

    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"


# Generated at 2022-06-23 23:01:24.167700
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("winreg", "_winreg")
    assert moved_module.name == "winreg"
    assert moved_module.new == "winreg"



# Generated at 2022-06-23 23:01:26.860120
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'email.mime.base' in SixMovesTransformer.rewrites
    assert 'six.moves.email_mime_base' in SixMovesTransformer.rewrites.values()

# Generated at 2022-06-23 23:01:32.293669
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'
    move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'

# Generated at 2022-06-23 23:01:33.420301
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import six_moves_transformer_test

# Generated at 2022-06-23 23:01:42.455329
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'cStringIO'
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert ma.new_attr == 'StringIO'
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', None, 'StringIO')
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'StringIO'

# Generated at 2022-06-23 23:01:47.522495
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name_1', 'old_1', 'new_1') == MovedModule('name_1', 'old_1', 'new_1')
    assert MovedModule('name_2', 'old_2') == MovedModule('name_2', 'old_2', 'name_2')
    assert(MovedModule('name_1', 'old_1') != MovedModule('name_2', 'old_2'))
    assert MovedModule('name_1', 'old_1') != None

# Generated at 2022-06-23 23:01:52.111907
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert len(t.rewrites) == 44
    assert ('six.moves.urllib.parse.urlencode',
            'six.moves.urllib.request.urlencode') in t.rewrites
    assert ('six.moves.urllib.parse.quote_plus',
            'six.moves.urllib.request.quote_plus') in t.rewrites


# Generated at 2022-06-23 23:01:54.186685
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("testattr", "testmod", "testmod2") == MovedAttribute("testattr", "testmod", "testmod2", None, "testattr")

# Generated at 2022-06-23 23:02:04.885146
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Space separated
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    b = MovedAttribute("cStringIO cStringIO io StringIO")
    assert a == b

    # Comma separated
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    b = MovedAttribute("cStringIO,cStringIO,io,StringIO")
    assert a == b

    # Isolated
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    b = MovedAttribute("cStringIO, cStringIO, io, StringIO")
    assert a == b

    # Tabs separated
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-23 23:02:07.519244
# Unit test for constructor of class MovedModule
def test_MovedModule():
    r = MovedModule('name', 'old', 'new')
    assert r.name == 'name'
    assert r.old == 'old'
    assert r.new == 'new'


# Generated at 2022-06-23 23:02:11.940603
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").old == "bar"
    assert MovedModule("foo", "bar").new == "foo"
    assert MovedModule("foo", "bar", "baz").new == "baz"


# Generated at 2022-06-23 23:02:16.739325
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    target = (2, 7)
    rewrites = _get_rewrites()
    dependencies = ['six']
    _SixMovesTransformer = SixMovesTransformer()
    assert _SixMovesTransformer.target == target
    assert _SixMovesTransformer.rewrites == rewrites
    assert _SixMovesTransformer.dependencies == dependencies

# Generated at 2022-06-23 23:02:22.695866
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"



# Generated at 2022-06-23 23:02:34.659306
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(
        "cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert move.name == "cStringIO"
    assert move.old_mod is None
    assert move.new_mod == "io"
    assert move.old_attr is None
    assert move.new_attr == "StringIO"
    move = MovedAttribute(
        "cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.old_mod is None
    assert move.new_mod == "io"
    assert move.old_attr is None
    assert move.new_attr == "StringIO"

# Generated at 2022-06-23 23:02:42.288466
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class MovedModule2(MovedModule):
        def __init__(self, name, new):
            MovedModule.__init__(self, name, name, new)

    for name, new in [('module_name', 'new_module_name'),
                      ('module', 'MODULE'),
                      ('module1', 'module2'),
                      ('m2', 'm2')]:
        mod = MovedModule2(name, new)
        assert mod.name == name
        assert mod.new == new


# Unit tests for class MovedAttribute

# Generated at 2022-06-23 23:02:43.554703
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    with pytest.raises(TypeError):
        SixMovesTransformer()  # type: ignore

# Generated at 2022-06-23 23:02:48.213795
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("abc", "old_mod", "new_mod", old_attr="old_attr", new_attr="new_attr")
    assert move.name == "abc"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-23 23:02:51.815227
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("abc", "d", "e", "f", "g")
    assert moved_attribute.name == "abc"
    assert moved_attribute.new_mod == "d"
    assert moved_attribute.new_attr == "f"



# Generated at 2022-06-23 23:02:56.286504
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == \
           MovedModule('name', 'old') == \
           MovedModule('name', 'old', 'name') == \
           MovedModule('name', 'old', name='name')

# Generated at 2022-06-23 23:03:07.940301
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six.moves.urllib.parse as moved_parse
    mv = MovedAttribute("parse_qs", "urlparse", "urllib.parse")
    assert mv.new_mod == "urllib.parse"
    assert mv.new_attr == "parse_qs"

    # Test different strings and check moved attribute
    mv = MovedAttribute("parse_qs", "six.moves.urllib.parse", "urllib.parse")
    assert mv.name == "parse_qs"
    assert mv.new_mod == "urllib.parse"
    assert mv.new_attr == "parse_qs"
    assert hasattr(moved_parse, "parse_qs")

    # Test that function exists

# Generated at 2022-06-23 23:03:14.522729
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("foo", "old_foo", "new_foo")
    assert moved_module.name == "foo"
    assert moved_module.old == "old_foo"
    assert moved_module.new == "new_foo"
    # Constructor with 2 parameters
    moved_module = MovedModule("bar", "old_bar")
    assert moved_module.name == "bar"
    assert moved_module.old == "old_bar"
    assert moved_module.new == "bar"



# Generated at 2022-06-23 23:03:16.551706
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=pointless-statement
    SixMovesTransformer()

# Generated at 2022-06-23 23:03:19.494675
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("ab", "ba", "baa")
    assert m.name == "ab"
    assert m.new == "baa"



# Generated at 2022-06-23 23:03:29.928727
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()

# Generated at 2022-06-23 23:03:32.709071
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"


# Generated at 2022-06-23 23:03:34.289177
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('urllib', 'urllib', 'six.moves.urllib')

# Generated at 2022-06-23 23:03:35.539605
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rw = SixMovesTransformer()
    assert rw.target == (2, 7)
    assert len(rw.rewrites) == len(_get_rewrites())

# Generated at 2022-06-23 23:03:40.361237
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").old == "__builtin__"
    assert MovedModule("builtins", "__builtin__").new == "builtins"

# Generated at 2022-06-23 23:03:47.709756
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd").new_attr == "getcwd"
    assert MovedAttribute("intern", "__builtin__", "sys").new_mod == "sys"



# Generated at 2022-06-23 23:03:54.232025
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ex1 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ex1.name == "cStringIO"
    assert ex1.new_mod == "io"
    assert ex1.new_attr == "cStringIO"
    ex2 = MovedAttribute("intern", "__builtin__", "sys")
    assert ex2.name == "intern"
    assert ex2.new_mod == "sys"
    assert ex2.new_attr == "intern"
    assert ex2.old_mod == "__builtin__"

# Generated at 2022-06-23 23:03:59.200048
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule('tkinter', 'Tkinter')
    mm2 = MovedModule('Tkinter', 'tkinter')
    assert mm1 == mm2
    assert mm1.name == mm2.name
    assert mm1.old == mm2.old
    assert mm1.new == mm2.new
    assert repr(mm1) == repr(mm2)

# Generated at 2022-06-23 23:04:03.158170
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.new == "new"


# Generated at 2022-06-23 23:04:08.402697
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma.name == 'name'
    assert ma.old_mod == 'old_mod'
    assert ma.new_mod == 'new_mod'
    assert ma.old_attr == None
    assert ma.new_attr == 'name'
    ma = MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr', new_attr='new_attr')
    assert ma.name == 'name'
    assert ma.old_mod == 'old_mod'
    assert ma.new_mod == 'new_mod'
    assert ma.old_attr == 'old_attr'
    assert ma.new_attr == 'new_attr'

# Generated at 2022-06-23 23:04:14.320232
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Check that the constructor works correctly
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    # Check that the constructor gives the right attributes for the object
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:04:16.874652
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("configparser", "ConfigParser")
    assert move.name == "configparser"
    assert move.new == "configparser"


# Generated at 2022-06-23 23:04:17.894981
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__")

# Generated at 2022-06-23 23:04:21.228707
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.target == (2, 7)
    assert s.rewrites == _get_rewrites()
    assert s.dependencies == ['six']

# Covers test case in test/test_venv_six.py:TestVenvSix.test_six_moves

# Generated at 2022-06-23 23:04:32.871425
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attr.name == "cStringIO"
    assert moved_attr.new_mod == "io"
    assert moved_attr.new_attr == "StringIO"
    moved_attr = MovedAttribute("cStringIO", "cStringIO")
    assert moved_attr.name == "cStringIO"
    assert moved_attr.new_mod == "cStringIO"
    assert moved_attr.new_attr == "cStringIO"
    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io",
                                "StringIO", "new_attr")
    assert moved_attr.name == "cStringIO"
    assert moved_attr.new_mod == "io"
    assert moved

# Generated at 2022-06-23 23:04:33.904991
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _get_rewrites()

# Generated at 2022-06-23 23:04:37.589162
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("X")
    assert mm.name == "X"
    assert mm.new == "X"

    mm = MovedModule("X", "Y")
    assert mm.name == "X"
    assert mm.new == "Y"

    mm = MovedModule("X", "Y", "Z")
    assert mm.name == "X"
    assert mm.new == "Z"


# Generated at 2022-06-23 23:04:38.954419
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('os', 'os')


# Generated at 2022-06-23 23:04:45.414221
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('math', 'math_module')
    assert m.name == 'math'
    assert m.old == 'math_module'
    assert m.new == 'math'
    m = MovedModule('math', 'math_module', 'math_new')
    assert m.name == 'math'
    assert m.old == 'math_module'
    assert m.new == 'math_new'

# Generated at 2022-06-23 23:04:53.932529
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # type: () -> None
    d = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert d.name == "cStringIO"
    assert d.new_mod == "io"
    assert d.new_attr == "StringIO"

    # Passing in a None value to new_mod is equivalent to
    # passing in a string value of the same name as name.
    d = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert d.name == "cStringIO"
    assert d.new_mod == "cStringIO"
    assert d.new_attr == "StringIO"

    # If old_attr is None, then new_attr is set to name

# Generated at 2022-06-23 23:05:02.990109
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # type: () -> None
    import six
    # Check if a MovedModule is working as expected
    moved_module = MovedModule("urllib", "urllib", "six.moves.urllib")
    assert moved_module.name == "urllib"
    assert moved_module.new == "six.moves.urllib"
    # Check for instance of MovedModule
    assert isinstance(moved_module, MovedModule)
    # Check for instance of MovedAttribute
    assert not isinstance(moved_module, MovedAttribute)
    # Check for instance of any six.moves classes
    assert isinstance(moved_module, six.moves.urllib)

# Generated at 2022-06-23 23:05:13.122694
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()

# Generated at 2022-06-23 23:05:21.916960
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:25.828217
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    for name, replacement in s.rewrites:
        assert isinstance(name, str)
        assert isinstance(replacement, str)


# Generated at 2022-06-23 23:05:29.267543
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('a', 'b', 'c')
    assert moved_module.name == 'a'
    assert moved_module.old == 'b'
    assert moved_module.new == 'c'

# Generated at 2022-06-23 23:05:41.410970
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test if `_get_rewrites` produces expected output
    moves = list(SixMovesTransformer._get_rewrites())

# Generated at 2022-06-23 23:05:43.092768
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    ob_SixMovesTransformer = SixMovesTransformer()
    pass

# Generated at 2022-06-23 23:05:46.040824
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('queue', 'Queue')
    MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:05:53.398251
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("winreg", "_winreg")
    assert moved_module.name == "winreg"
    assert moved_module.old == "_winreg"
    assert moved_module.new == "winreg"

    moved_module = MovedModule("winreg", "_winreg", "winreg2")
    assert moved_module.name == "winreg"
    assert moved_module.old == "_winreg"
    assert moved_module.new == "winreg2"



# Generated at 2022-06-23 23:05:54.547316
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites() == SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:06:00.253730
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute(name = "a", old_mod = "b", new_mod = "c", old_attr = "d", new_attr = "e")
    assert m.name == "a"
    assert m.new_mod == "c"
    assert m.new_attr == "e"


# Generated at 2022-06-23 23:06:10.029601
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"
    attr = MovedAttribute("zip_longest", "itertools", "itertools", "izip_longest", "zip_longest")
    assert attr.name == "zip_longest"
    assert attr.new_mod == "itertools"
    assert attr.new_attr == "zip_longest"
    attr = MovedAttribute("reload_module", "__builtin__", "imp", "reload")
    assert attr.name == "reload_module"

# Generated at 2022-06-23 23:06:20.415440
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    from six.moves import http_client
    from six.moves.urllib.parse import urlparse
    from six.moves.urllib.error import HTTPError

    # sys.modules['six.moves.urllib.parse'] = urlparse
    # sys.modules['six.moves.urllib.error'] = HTTPError


# Generated at 2022-06-23 23:06:31.623918
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'bar', 'baz') == MovedAttribute('foo', 'bar', 'baz')
    assert MovedAttribute('foo', 'bar', 'baz', '', '') == MovedAttribute('foo', 'bar', 'baz', '', '')
    assert MovedAttribute('foo', 'bar', 'baz', 'x', 'y') == MovedAttribute('foo', 'bar', 'baz', 'x', 'y')
    assert MovedAttribute('foo', 'bar', 'baz', 'x', 'y') != MovedAttribute('foo', 'bar', 'baz', 'x', 'z')
    assert MovedAttribute('foo', 'bar', 'baz', 'x', 'y') != MovedAttribute('foo', 'bar', 'baz', 'y', 'y')
    assert MovedAttribute

# Generated at 2022-06-23 23:06:36.682027
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'

# Generated at 2022-06-23 23:06:46.816949
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:54.710698
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrite = SixMovesTransformer()
    assert rewrite.target == (2, 7)
    assert 'six.moves' in rewrite.dependencies
    assert len(rewrite.rewrites) == len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes) + len(_moved_attributes)

# Generated at 2022-06-23 23:06:55.841158
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites() is not _SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:07:08.299757
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Check the rewrites
    rewrites = list(SixMovesTransformer.rewrites)
    assert len(rewrites) == 141
    assert rewrites[0] == ('builtins.cStringIO', 'six.moves.cStringIO')
    assert rewrites[1] == ('builtins.filter', 'six.moves.filter')
    assert rewrites[2] == ('itertools.filterfalse', 'six.moves.filterfalse')
    assert rewrites[3] == ('builtins.input', 'six.moves.input')
    assert rewrites[4] == ('sys.intern', 'six.moves.intern')
    assert rewrites[5] == ('builtins.map', 'six.moves.map')

# Generated at 2022-06-23 23:07:11.309742
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MM = MovedModule("TestModule", "TestModule")
    assert MM.name == "TestModule"
    assert MM.new == "TestModule"


# Generated at 2022-06-23 23:07:15.883703
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test MovedModule's construction."""
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.old == '__builtin__'
    assert moved_module.new == 'builtins'
    moved_module = MovedModule('builtins', '__builtin__', 'noshift')
    assert moved_module.new == 'noshift'


# Generated at 2022-06-23 23:07:24.371674
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("test", "mod1", "mod2")
    assert move.name == "test"
    assert move.new_mod == "mod2"
    assert move.new_attr == "test"

    move = MovedAttribute("test", "mod1", "mod2", "old_attr")
    assert move.name == "test"
    assert move.new_mod == "mod2"
    assert move.new_attr == "old_attr"

    move = MovedAttribute("test", "mod1", "mod2", old_attr="old_attr", new_attr="new_attr")
    assert move.name == "test"
    assert move.new_mod == "mod2"
    assert move.new_attr == "new_attr"

# Generated at 2022-06-23 23:07:26.655751
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six.moves
    six.moves.input('')



# Generated at 2022-06-23 23:07:28.641939
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('abc', 'abc', 'abc') == MovedModule('abc', 'abc')

# Unit tests for class MovedModule

# Generated at 2022-06-23 23:07:32.656110
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'


# Generated at 2022-06-23 23:07:34.457448
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm is not None


# Generated at 2022-06-23 23:07:39.428770
# Unit test for constructor of class MovedModule
def test_MovedModule():
    testModule = MovedModule("test", "test")
    assert testModule.name == "test"
    assert testModule.old == "test"
    assert testModule.new == "test"

    testMod = MovedModule("test", "test", "testNew")
    assert testMod.name == "test"
    assert testMod.old == "test"
    assert testMod.new == "testNew"

# Generated at 2022-06-23 23:07:43.155390
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3 import refactor
    from libfuturize.fixes.fix_six_moves import SixMovesTransformer
    SixMovesTransformer(refactor.RefactoringTool(), [])


# Generated at 2022-06-23 23:07:46.148167
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"

# Generated at 2022-06-23 23:07:48.985575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('name', 'old')
    assert mod.name == 'name'
    assert mod.new == 'name'
    mod = MovedModule('name', 'old', 'new')
    assert mod.name == 'name'
    assert mod.new == 'new'


# Generated at 2022-06-23 23:07:51.183509
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('builtins', '__builtin__')
    assert(move.name == 'builtins')
    assert(move.new == 'builtins')


# Generated at 2022-06-23 23:07:54.138720
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

# Generated at 2022-06-23 23:07:56.641506
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule("builtins", "__builtin__")
    assert movedModule.name == "builtins"
    assert movedModule.new == "builtins"



# Generated at 2022-06-23 23:08:00.835727
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move1.name == "cStringIO"
    assert move1.new_mod == "io"
    assert move1.new_attr == "StringIO"


# Generated at 2022-06-23 23:08:06.049640
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mv.name == "cStringIO"
    assert mv.new_mod == "io"
    assert mv.new_attr == "StringIO"


# Generated at 2022-06-23 23:08:10.747569
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MM = MovedModule('a', 'b')
    assert MM.name == 'a'
    assert MM.old == 'b'
    assert MM.new == 'a'

    MM = MovedModule('a', 'b', 'B')
    assert MM.name == 'a'
    assert MM.old == 'b'
    assert MM.new == 'B'



# Generated at 2022-06-23 23:08:13.828956
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.target == (2, 7)
    assert s.rewrites == [('os.getcwd', 'six.moves.getcwd'), ('os.getcwdb', 'six.moves.getcwdb'), ('os.getcwdu', 'six.moves.getcwd')]

# Generated at 2022-06-23 23:08:17.963107
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = [
        MovedModule("a", "b", "c"),
        MovedModule("d", "e", "f", "g"),
        MovedModule("h", "i"),
        MovedModule("j", "k", "l", "m", "n"),
    ]
    for move in moves:
        assert move.name == move.new
        if move.old != move.new:
            assert move.old == move.new[-1]

# Generated at 2022-06-23 23:08:26.400494
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr_1 = MovedAttribute("hello", "foo", "bar")
    assert attr_1.name == "hello"
    assert attr_1.new_mod == "bar"
    assert attr_1.new_attr == "hello"
    attr_2 = MovedAttribute("hello", "foo", "bar", "old_hello", "new_hello")
    assert attr_2.name == "hello"
    assert attr_2.new_mod == "bar"
    assert attr_2.new_attr == "new_hello"


# Generated at 2022-06-23 23:08:30.836789
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError) as excinfo:
        MovedAttribute(1, 1, 1, 1, 1)
    assert excinfo.type is TypeError
    assert str(excinfo.value) == "__init__() takes at least 3 arguments (5 given)"



# Generated at 2022-06-23 23:08:34.959764
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'new_attr'


# Generated at 2022-06-23 23:08:37.546656
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import warnings
    import sys
    if sys.version_info > (3,):
        with warnings.catch_warnings(record=True) as log:
            SixMovesTransformer()
            assert len(log) == 1

# Generated at 2022-06-23 23:08:39.913646
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("queue", "Queue")
    assert mod.name == 'queue'
    assert mod.new == 'queue'



# Generated at 2022-06-23 23:08:50.914838
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pysrc = """from six import moves
from six.moves import http_cookies
from six.moves import urllib
from six.moves import urllib_parse
from six.moves import urllib_error
from six.moves import urllib_request
from six.moves import urllib_response
from six.moves import urllib_robotparser
from six.moves import configparser
from six.moves.urllib_parse import urlparse
from six.moves.urllib_parse import quote
from six.moves.urllib_error import URLError
from six.moves.urllib_request import urlopen
from six.moves.urllib_robotparser import RobotFileParser"""

# Generated at 2022-06-23 23:09:02.251586
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Apply the test to all version of python
    # We don't use the target decorator for that purpose
    for version in [(2, 7), (3, 0), (3, 1), (3, 2), (3, 3)]:
        SixMovesTransformer.target = version
        SixMovesTransformer.rewrites = _get_rewrites()

        # Test if the constructor of SixMovesTransformer is correct
        # def _get_rewrites():
        #     for prefix, moves in prefixed_moves:
        #         for move in moves:
        #             if isinstance(move, MovedAttribute):
        #                 path = '{}.{}'.format(move.new_mod, move.new_attr)
        #                 yield (path, 'six.moves{}.{}'.format(prefix, move.name))


# Generated at 2022-06-23 23:09:09.931368
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old", "new")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new"
    assert moved_attribute.new_attr == "name"

    moved_attribute = MovedAttribute("name", "old", "new", "old_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new"
    assert moved_attribute.new_attr == "old_attr"

    moved_attribute = MovedAttribute("name", "old", "new", None, "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new"
    assert moved_attribute.new_attr == "new_attr"