

# Generated at 2022-06-23 22:59:23.630720
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("module", "old")
    assert module
    assert module.name == "module"
    assert module.new == "module"
    module = MovedModule("module", "old", "new")
    assert module.name == "module"
    assert module.new == "new"

# Generated at 2022-06-23 22:59:28.347102
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    assert six.moves.cStringIO.StringIO is io.StringIO

# Generated at 2022-06-23 22:59:30.675157
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']
    assert len(transformer.rewrites) == 365


transformer = SixMovesTransformer()

# Generated at 2022-06-23 22:59:41.623233
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # six.moves modules don't exist in Python 2.6, so we have to monkeypatch
    # them in
    import sys
    sys.modules['six.moves.urllib.parse'] = 'six.moves.urllib.parse'
    sys.modules['six.moves.urllib.error'] = 'six.moves.urllib.error'
    sys.modules['six.moves.urllib.request'] = 'six.moves.urllib.request'
    sys.modules['six.moves.urllib.response'] = 'six.moves.urllib.response'
    sys.modules['six.moves.urllib.robotparser'] = 'six.moves.urllib.robotparser'

    transformer = SixMovesTransformer()
    assert len

# Generated at 2022-06-23 22:59:47.694530
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedMod = MovedModule("foo", "bar", "baz")
    assert movedMod.name == "foo"
    assert movedMod.old == "bar"
    assert movedMod.new == "baz"
    movedMod = MovedModule("foo", "bar")
    assert movedMod.name == "foo"
    assert movedMod.old == "bar"
    assert movedMod.new == "foo"



# Generated at 2022-06-23 22:59:58.071176
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('name', 'old_module', 'new_module')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_module'
    assert attr.new_attr == 'name'
    attr = MovedAttribute('name', 'old_module', 'new_module', 'old_attr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_module'
    assert attr.new_attr == 'old_attr'
    attr = MovedAttribute('name', 'old_module', 'new_module', 'old_attr', 'new_attr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_module'
    assert attr.new_attr == 'new_attr'


# Generated at 2022-06-23 22:59:59.858126
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:00:03.776181
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd").new_attr == "getcwdu"

# Generated at 2022-06-23 23:00:06.047760
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.new == 'builtins'
    assert moved_module.old is None
    assert moved_module


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:00:13.097420
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    error_msg1 = 'name={}, old_mod={}, new_mod={}, old_attr={}, new_attr={}'
    error_msg2 = 'name={}, new_mod={}, new_attr={}'
    move = MovedAttribute('move', 'old_module', 'new_module', 'old_attr', 'new_attr')
    assert move.name == 'move'
    assert move.new_mod == 'new_module'
    assert move.new_attr == 'new_attr'
    move = MovedAttribute('move', 'old_module', 'new_module', 'old_attr')
    assert move.name == 'move'
    assert move.new_mod == 'new_module'
    assert move.new_attr == 'old_attr'

# Generated at 2022-06-23 23:00:22.204977
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").new_attr == "filterfalse"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_attr == "raw_input"
    assert MovedAttribute("intern", "__builtin__", "sys").new_attr == "intern"
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map").new_attr == "imap"
    assert M

# Generated at 2022-06-23 23:00:32.663481
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:42.284729
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError) as excinfo:
        MovedAttribute()
    assert '__init__() missing 4 required positional arguments' in str(excinfo.value)
    assert MovedAttribute('name', 'mod', 'newmod', 'oldattr') is not None # type: ignore
    with pytest.raises(TypeError) as excinfo:
        MovedAttribute('name', 'mod', 'newmod', 'oldattr', 'newattr', 'spare')
    assert '__init__() takes at most 5 arguments (6 given)' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        MovedAttribute(1, 'mod', 'newmod')
    assert '__init__() takes exactly 1 positional argument' in str(excinfo.value)


# Generated at 2022-06-23 23:00:53.795916
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transforms = [
        ('six.moves.range', 'six.moves.range', 'range'),
        ('six.moves.map', 'six.moves.map', 'map'),
        ('six.moves.StringIO', 'six.moves.StringIO', 'StringIO'),
        ('six.moves.getcwdb', 'six.moves.getcwdb', 'getcwdb'),
        ('six.moves.urllib.request.build_opener', 'six.moves.build_opener', 'build_opener'),
        ('six.moves.urllib.request.HTTPDigestAuthHandler', 'six.moves.HTTPDigestAuthHandler', 'HTTPDigestAuthHandler'),
    ]

# Generated at 2022-06-23 23:00:58.432296
# Unit test for constructor of class MovedModule
def test_MovedModule():
    instance = MovedModule("builtins", "__builtin__")
    assert isinstance(instance, MovedModule)
    assert instance.name == "builtins"
    assert instance.new == "builtins"
    assert instance.old == "__builtin__"


# Generated at 2022-06-23 23:01:03.761821
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("tkinter", "Tkinter").name == "tkinter"
    assert MovedModule("tkinter", "Tkinter").new == "tkinter"
    assert MovedModule("tkinter", "Tkinter", "foo").name == "tkinter"
    assert MovedModule("tkinter", "Tkinter", "foo").new == "foo"



# Generated at 2022-06-23 23:01:05.674018
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__") == MovedModule("builtins", "__builtin__")

# Generated at 2022-06-23 23:01:12.679807
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('builtins', '__builtin__')
    assert module.name == 'builtins'
    assert module.new == 'builtins'
    module = MovedModule('winreg', '_winreg')
    assert module.name == 'winreg'
    assert module.new == 'winreg'
    module = MovedModule('socketserver', 'SocketServer')
    assert module.name == 'socketserver'
    assert module.new == 'socketserver'
    module = MovedModule('_thread', 'thread', '_thread')
    assert module.name == '_thread'
    assert module.new == '_thread'

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:01:23.418537
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", None, None)
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == None
    moved_attribute = MovedAttribute("name", "old_mod", "", "old_attr", "")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == ""
    assert moved_attribute.new

# Generated at 2022-06-23 23:01:28.471708
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .utils import TestRewriteImports
    import sys
    import six

    # Test import
    assert 'six' in sys.modules, "Module not imported"

    # Test constructor of class SixMovesTransformer
    instance = TestRewriteImports('six.moves', SixMovesTransformer)
    assert isinstance(instance._transformer, SixMovesTransformer), \
        "Can't create an instance of class SixMovesTransformer"

# Generated at 2022-06-23 23:01:34.996695
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_from_six = MovedModule("winreg", "_winreg")
    assert module_from_six.name == "winreg"
    assert module_from_six.new == "_winreg"
    module_from_six = MovedModule("winreg", "_winreg", "winreg")
    assert module_from_six.name == "winreg"
    assert module_from_six.new == "winreg"
    module_from_six = MovedModule("winreg", "_winreg", new="winreg")
    assert module_from_six.name == "winreg"
    assert module_from_six.new == "winreg"



# Generated at 2022-06-23 23:01:37.771542
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'foo'

# Generated at 2022-06-23 23:01:47.081118
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__repr__() == "MovedAttribute("

# Generated at 2022-06-23 23:01:48.681208
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:01:53.164175
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a','b','c','d','e').name == 'a'
    assert MovedAttribute('a','b','c').name == 'a'
    assert MovedAttribute('a','b','c', 'd').name == 'a'
    assert MovedAttribute('a','b','c','d','e').new_mod == 'c'
    assert MovedAttribute('a','b','c').new_mod == 'c'
    assert MovedAttribute('a','b','c', 'd').new_mod == 'c'
    assert MovedAttribute('a','b','c','d','e').old_attr == 'd'
    assert MovedAttribute('a','b','c').old_attr == 'a'
    assert MovedAttribute('a','b','c', 'd').old_attr == 'd'
    assert Moved

# Generated at 2022-06-23 23:01:54.402892
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that the dependencies are correct."""
    transformer = SixMovesTransformer()
    assert transformer.dependencies == ['six']


# Generated at 2022-06-23 23:02:05.281078
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    d = {"name":"cStringIO","old_mod":"cStringIO","new_mod":"io","old_attr":"StringIO","new_attr":"StringIO"}
    a = MovedAttribute(**d)
    assert d.items() <= a.__dict__.items()
    # if new_mod is None, new_mod = name
    d = {"name":"cStringIO","old_mod":"cStringIO"}
    a = MovedAttribute(**d)
    d = {"name":"cStringIO","old_mod":"cStringIO","new_mod":"cStringIO"}
    assert d.items() <= a.__dict__.items()
    # if new_attr is None, new_attr = name
    d = {"name":"cStringIO","old_mod":"cStringIO","new_mod":"io"}
    a = Moved

# Generated at 2022-06-23 23:02:16.407668
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attributes = MovedAttribute("string", "module", None, None, None)
    assert moved_attributes.name == "string"
    assert moved_attributes.new_mod == "string"
    assert moved_attributes.new_attr == "string"
    assert repr(moved_attributes) == "MovedAttribute(name='string', old_mod='module', new_mod='string', old_attr=None, new_attr='string')"
    moved_attributes = MovedAttribute("string", "module", "new_module", "old_attr", "new_attr")
    assert moved_attributes.name == "string"
    assert moved_attributes.new_mod == "new_module"
    assert moved_attributes.new_attr == "new_attr"
    assert repr(moved_attributes)

# Generated at 2022-06-23 23:02:23.992240
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod') == \
        MovedAttribute('name', 'old_mod', 'new_mod', 'name')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr') == \
        MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'old_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') == \
        MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')



# Generated at 2022-06-23 23:02:35.702326
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests the constructor of class SixMovesTransformer"""

# Generated at 2022-06-23 23:02:38.378427
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    assert moved_module.old == "__builtin__"



# Generated at 2022-06-23 23:02:42.981172
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

# Generated at 2022-06-23 23:02:44.630126
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites()) == list(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:02:54.117567
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:56.622667
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for path, replacement in SixMovesTransformer.rewrites:
        assert callable(replacement)

# Generated at 2022-06-23 23:03:01.184830
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("http_client", "httplib", "http.client")
    assert moved_module.name == "http_client"
    assert moved_module.old == "httplib"
    assert moved_module.new == "http.client"

# Generated at 2022-06-23 23:03:12.022174
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()


# Generated at 2022-06-23 23:03:14.987619
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == set(_get_rewrites())
    assert transformer.dependencies == set(['six'])


# Generated at 2022-06-23 23:03:18.725756
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    for k, v in t.rewrites:
        assert k == v[len('six.moves'):].lstrip('.')



# Generated at 2022-06-23 23:03:19.198651
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

# Generated at 2022-06-23 23:03:22.680247
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.fixes.fix_six import SixMovesTransformer
    import libfuturize.fixes.fix_six as six
    assert SixMovesTransformer.rewrites == six._get_rewrites()

# Generated at 2022-06-23 23:03:24.784163
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attrib = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attrib.name == "cStringIO"
    assert moved_attrib.new_mod == "io"
    assert moved_attrib.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:33.706840
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
   

# Generated at 2022-06-23 23:03:35.984778
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer._get_rewrites()) == 116

# Generated at 2022-06-23 23:03:47.490100
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst.codemod import CodemodContext
    from libcst.matchers import Call, Name, Arg
    from libcst.metadata import PositionProvider

    class DummyContext(CodemodContext):
        def __init__(self):
            self.position_provider = PositionProvider()

    transformer = SixMovesTransformer(DummyContext())

# Generated at 2022-06-23 23:03:53.971021
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(name='abc', old='abc', new='abc').__dict__ == {
        'name': 'abc', 'old': 'abc', 'new': 'abc'}
    assert MovedModule(name='abc', old='abc').__dict__ == {
        'name': 'abc', 'old': 'abc', 'new': 'abc'}
    assert MovedModule(name='abc', new='xyz').__dict__ == {
        'name': 'abc', 'old': 'abc', 'new': 'xyz'}

# Generated at 2022-06-23 23:04:00.912252
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attributes = []
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    moved_attributes.append(ma)
    if ma.name != "name" or ma.new_mod != "new_mod" or \
       ma.old_mod != "old_mod" or \
       ma.new_attr != "new_attr" or ma.old_attr != "old_attr":
        print("Unit test for constructor of class MovedAttribute failed.")


# Generated at 2022-06-23 23:04:01.488524
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass

# Generated at 2022-06-23 23:04:04.190648
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == {'name': 'cStringIO',
                                                                                  'new_mod': 'io',
                                                                                  'new_attr': 'StringIO'}



# Generated at 2022-06-23 23:04:09.598268
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("a","b")
    MovedModule("a","b","c")
    MovedModule("a","b","c","d")
    with pytest.raises(TypeError):
        MovedModule("a","b","c","d","e")

# Generated at 2022-06-23 23:04:11.201031
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule.__init__.__doc__ is not None

# Generated at 2022-06-23 23:04:15.531637
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_example = MovedModule('example', 'examples')
    assert moved_module_example.name == 'example'
    assert moved_module_example.new == 'example'
    assert moved_module_example.old == 'examples'


# Generated at 2022-06-23 23:04:19.138184
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    input = 'cStringIO'
    actual = MovedAttribute(input, 'cStringIO', 'io', 'StringIO')
    expected = MovedAttribute(input, 'cStringIO', 'io', 'StringIO')
    assert(actual==expected)


# Generated at 2022-06-23 23:04:21.129984
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test the SixMovesTransformer class.
    """
    from .utils import check_code_changes
    check_code_changes(SixMovesTransformer)

# Generated at 2022-06-23 23:04:22.214405
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer

# Generated at 2022-06-23 23:04:24.015400
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("test", "Test")
    assert m.name == "test"
    assert m.new == "test"

    m = MovedModule("test", "Test", "test_new")
    assert m.name == "test"
    assert m.new == "test_new"


# Generated at 2022-06-23 23:04:32.916420
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_obj = MovedModule("name", "old")
    try:
        assert(test_obj.name == "name")
        assert(test_obj.old == "old")
    except AssertionError:
        print("Failed constructor test for MovedModule")
    test_obj = MovedModule("name", "old", "new")
    try:
        assert(test_obj.name == "name")
        assert(test_obj.old == "old")
        assert(test_obj.new == "new")
    except AssertionError:
        print("Failed constructor test for MovedModule")


# Generated at 2022-06-23 23:04:41.404213
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:04:46.637146
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    tmp_MovedAttribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert tmp_MovedAttribute.name == "cStringIO"
    assert tmp_MovedAttribute.new_mod == "io"
    assert tmp_MovedAttribute.new_attr == "StringIO"


# Generated at 2022-06-23 23:04:49.730992
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case = MovedModule("StringIO", "StringIO", "io")
    assert test_case.name == "StringIO"
    assert test_case.old == "StringIO"
    assert test_case.new == "io"


# Generated at 2022-06-23 23:04:54.079992
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(MovedModule('name', 'old_name')) == 'move name from old_name'
    assert str(MovedModule('name', 'old_name', 'new_name')) == 'move name from old_name to new_name'
    assert str(MovedModule('name', 'name')) == 'move name from name'
    assert str(MovedModule('name', 'name', 'name')) == 'move name from name to name'

# Generated at 2022-06-23 23:04:55.108574
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:04.664432
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert len(transformer.rewrites) == 49
    assert transformer.rewrites[0] == ('builtins.cStringIO', 'six.moves.cStringIO')
    assert transformer.rewrites[6] == ('builtins.intern', 'six.moves.intern')
    assert transformer.rewrites[8] == ('builtins.range', 'six.moves.range')
    assert transformer.rewrites[10] == ('shlex.quote', 'six.moves.shlex_quote')
    assert transformer.rewrites[11] == ('builtins.StringIO', 'six.moves.StringIO')
    assert transformer.rewrites[12] == ('builtins.UserDict', 'six.moves.UserDict')

# Generated at 2022-06-23 23:05:10.063153
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('new', 'old')
    assert mm.name == 'new'
    assert mm.new == 'new'
    assert mm.old == 'old'
    mm2 = MovedModule('new2', 'old2', 'new_name')
    assert mm2.name == 'new2'
    assert mm2.new == 'new_name'
    assert mm2.old == 'old2'

# Generated at 2022-06-23 23:05:13.201742
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test if it's a subclass of BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    # Test if it's an instance of BaseImportRewrite
    assert isinstance(SixMovesTransformer(), BaseImportRewrite)

# Generated at 2022-06-23 23:05:16.781470
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    return moved_module


# Generated at 2022-06-23 23:05:21.768863
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'name'
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'old_attr'


# Generated at 2022-06-23 23:05:26.161243
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=global-variable-not-assigned
    global _moved_attributes, _urllib_parse_moved_attributes
    # pylint: enable=global-variable-not-assigned
    with patch('six.moves._moved_attributes', _moved_attributes), patch('six.moves._urllib_parse_moved_attributes', _urllib_parse_moved_attributes):
        assert SixMovesTransformer.rewrites() == _get_rewrites()

# Generated at 2022-06-23 23:05:36.012507
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for constructor without attributes
    old_mod = "a.old"
    new_mod = "a.new"
    old_attr = "old_attr"
    new_attr = "new_attr"
    name = "name"
    move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert move.name == name
    assert move.old_mod == old_mod
    assert move.new_mod == new_mod
    assert move.old_attr == old_attr
    assert move.new_attr == new_attr
    # Test for constructor with attributes
    move = MovedAttribute(name, old_mod, new_mod, old_attr)
    assert move.name == name
    assert move.old_mod == old_mod

# Generated at 2022-06-23 23:05:37.230658
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == moved_module.new
    assert moved_module.new == "name"


# Generated at 2022-06-23 23:05:41.516192
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'urllib.parse.urlparse' in [k for k, v in SixMovesTransformer.rewrites]
    assert 'urllib.error.URLError' in [k for k, v in SixMovesTransformer.rewrites]
    assert 'urllib.request.urlretrieve' in [k for k, v in SixMovesTransformer.rewrites]
    assert 'urllib.response.addbase' in [k for k, v in SixMovesTransformer.rewrites]
    assert 'urllib.robotparser.RobotFileParser' in [k for k, v in SixMovesTransformer.rewrites]
    assert 'urllib.request.urlopen' in [k for k, v in SixMovesTransformer.rewrites]

# Generated at 2022-06-23 23:05:45.438320
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('abc', 'abc')
    assert MovedModule('abc', 'abc', 'abc')
    assert MovedModule('abc', 'x', 'y') == MovedModule('abc', 'y', 'x')


# Generated at 2022-06-23 23:05:56.589170
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for module
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == 'builtins'
    assert moved_module.new == 'builtins'
    assert moved_module.prefix == ''

    moved_module = MovedModule("foo", "bar")
    assert moved_module.name == 'foo'
    assert moved_module.new == 'bar'
    assert moved_module.prefix == ''

    # Test for function
    moved_attribute = MovedAttribute('foo', 'bar', 'baz')
    assert moved_attribute.name == 'foo'
    assert moved_attribute.new_mod == 'baz'
    assert moved_attribute.new_attr == 'foo'
    assert moved_attribute.prefix == ''


# Generated at 2022-06-23 23:06:07.775022
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:15.736284
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:26.589635
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """MovedAttribute constructor requires several arguments.
    If the last parameter is not specified, the name of the parameter
    will become the new attribute name. Otherwise, the new attribute
    name will be the last parameter"""
    ma1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma1.name == "cStringIO"
    assert ma1.new_mod == "io"
    assert ma1.new_attr == "StringIO"

    ma2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma2.name == "cStringIO"
    assert ma2.new_mod == "io"
    assert ma2.new_attr == "cStringIO"

# Generated at 2022-06-23 23:06:31.946339
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("abstract_classes", "abc", "abc").name == "abstract_classes"
    assert MovedModule("abstract_classes", "abc", "abc").new == "abc"
    assert MovedModule("abstract_classes", "abc").name == "abstract_classes"
    assert MovedModule("abstract_classes", "abc").new == "abstract_classes"

# Generated at 2022-06-23 23:06:41.139541
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..pgen2.parse import ParseError
    from ..fixes import sixmoves

    s = """
import urllib, urllib2
import six.moves.urllib.robotparser
from six.moves.urllib.request import urlopen
"""

    before = sixmoves.SixMovesTransformer(s)
    assert before.node.type == syms.file_input

    try:
        after = sixmoves.SixMovesTransformer(s, target=('2', '8'))
        assert False, '2.8 cannot import six.moves'
    except ParseError:
        pass
    pass

# Generated at 2022-06-23 23:06:48.567563
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import operator
    import six
    assert SixMovesTransformer.rewrites[0] == (six.moves.map, 'six.moves.map')
    assert SixMovesTransformer.rewrites[1] == (six.moves.http_cookiejar, 'six.moves.http_cookiejar')
    assert SixMovesTransformer.rewrites[2] == (six.moves.urllib.parse, 'six.moves.urllib_parse')
    assert SixMovesTransformer.rewrites[3] == (six.moves.urllib.parse.ParseResult, 'six.moves.urllib_parse.ParseResult')

# Generated at 2022-06-23 23:06:53.032740
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sut = nuit.sixmoves.SixMovesTransformer()
    assert sut, 'Created an instance of a class SixMovesTransformer'
    #assert sut.rewrites is not None and len(sut.rewrites) > 0, 'Created an instance of a class SixMovesTransformer'

# Generated at 2022-06-23 23:06:58.620683
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Empty constructor
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"
    # Constructor that doesn't fill in new attr
    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"
    # Constructor that doesn't fill in new mod
    m = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "cStringIO"
   

# Generated at 2022-06-23 23:07:00.098532
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer() # noqa: F841

# Generated at 2022-06-23 23:07:03.116509
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("tkinter", "Tkinter")
    assert m.name == "tkinter"
    assert m.new == "tkinter"


# Generated at 2022-06-23 23:07:08.819592
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attributes = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_attributes.name == "cStringIO"
    assert move_attributes.new_mod == "io"
    assert move_attributes.new_attr == "StringIO"

# Generated at 2022-06-23 23:07:14.168523
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

# Generated at 2022-06-23 23:07:23.345765
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:07:33.273956
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'StringIO'

    ma = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'cStringIO'

    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'new_StringIO')
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'new_StringIO'



# Generated at 2022-06-23 23:07:33.936351
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

# Generated at 2022-06-23 23:07:37.245292
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:07:41.488683
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('module_name', 'from_module', 'to_module') == {
               'name': 'module_name',
               'old': 'from_module',
               'new': 'to_module'
           }


# Generated at 2022-06-23 23:07:43.704961
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:07:47.435818
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("abc", "def") == MovedModule("abc", "def")
    assert not MovedModule("abc", "def") != MovedModule("abc", "def")


# Generated at 2022-06-23 23:07:51.465475
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert not hasattr(ma, "old_mod")
    assert not hasattr(ma, "old_attr")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"


# Generated at 2022-06-23 23:08:01.338085
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").__dict__ == {
        'name': "name",
        'old_mod': "old_mod",
        'new_mod': "new_mod",
        'old_attr': None,
        'new_attr': "name",
    }
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").__dict__ == {
        'name': "name",
        'old_mod': "old_mod",
        'new_mod': "new_mod",
        'old_attr': "old_attr",
        'new_attr': "new_attr",
    }

# Generated at 2022-06-23 23:08:04.896356
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule('name')
    with pytest.raises(TypeError):
        MovedModule('name', 'old', 'new', 'extras')
    assert MovedModule('name', 'old', 'new')

# Generated at 2022-06-23 23:08:07.844835
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule
    assert obj.__init__('name', 'old') == None
    assert obj.__init__('name', 'old', 'new') == None
    assert obj.__init__('name', 'old', None) == None
    assert obj.__init__('name', 'old', None) == None


# Generated at 2022-06-23 23:08:12.136664
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_movedattribute = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert test_movedattribute.name == 'cStringIO'
    assert test_movedattribute.new_mod == 'io'
    assert test_movedattribute.new_attr == 'StringIO'


# Generated at 2022-06-23 23:08:18.698190
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert(MovedAttribute("cStringIO", "cStringIO", "io").name \
           == "cStringIO")
    assert(MovedAttribute("cStringIO", "cStringIO", "io").new_mod \
           == "io")
    assert(MovedAttribute("cStringIO", "cStringIO", "io").new_attr \
           == "cStringIO")
    assert(MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name \
           == "filter")
    assert(MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod \
           == "builtins")

# Generated at 2022-06-23 23:08:23.778116
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm =  MovedModule('test1', 'test2')
    assert mm.name == 'test1'
    assert mm.new == 'test2'
    mm =  MovedModule('test1', 'test2', 'test3')
    assert mm.name == 'test1'
    assert mm.new == 'test3'


# Generated at 2022-06-23 23:08:34.289552
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:35.947018
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:08:47.015552
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO2")
    assert move.new_attr == "StringIO2"
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO2")

# Generated at 2022-06-23 23:08:48.127978
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:08:59.650090
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    # Test all arguments
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    # Test new_attr None
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", None)
    assert a.name == "cStringIO"
    assert a.new_mod == "io"

# Generated at 2022-06-23 23:09:01.647204
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('module', 'old') == MovedModule('module', 'old')


# Generated at 2022-06-23 23:09:09.813770
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:09:20.222764
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            assert(move in _moved_attributes)
    # Test the constructor
    smt = SixMovesTransformer()
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                new_path = 'six.moves{}.{}'.format(prefix, move.name)
                assert(smt.rewrites[path] == new_path)
            elif isinstance(move, MovedModule):
                path = move.new
                new_path = 'six.moves{}.{}'.format(prefix, move.name)