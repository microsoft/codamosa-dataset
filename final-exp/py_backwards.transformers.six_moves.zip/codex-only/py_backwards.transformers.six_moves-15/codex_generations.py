

# Generated at 2022-06-23 22:59:12.791126
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, list)
    assert len(SixMovesTransformer.rewrites) == 75

if __name__ == "__main__":
    test_SixMovesTransformer()

# Generated at 2022-06-23 22:59:15.851781
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'

# Generated at 2022-06-23 22:59:21.284490
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'name'


# Generated at 2022-06-23 22:59:26.905558
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.old_mod == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.old_attr == "StringIO"
    assert moved_attribute.new_attr == "cStringIO"



# Generated at 2022-06-23 22:59:28.874456
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')

# Generated at 2022-06-23 22:59:29.892937
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()

# Generated at 2022-06-23 22:59:34.987856
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from py2to3.fixes.six import MovedModule
    mm = MovedModule(name='a', old='old')
    assert mm.name == 'a'
    assert (mm.new == mm.name)
    mm = MovedModule(name='a', old='old', new='new')
    assert mm.name == 'a'
    assert mm.new == 'new'

# Generated at 2022-06-23 22:59:39.666551
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    from mypy.traverser import Traverser
    from mypy.types import TypeVisitor

    t = Traverser()
    t.visit_module()
    _ = SixMovesTransformer(t)
    _ = TypeVisitor()



# Generated at 2022-06-23 22:59:45.185997
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "cStringIO"
    old_mod = "cStringIO"
    new_mod = "io"
    old_attr = "StringIO"
    new_attr = None
    object_MovedAttribute=MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert object_MovedAttribute.name == name


# Generated at 2022-06-23 22:59:49.236066
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Passing in no arguements
    assert MovedModule("name", "old") == MovedModule("name", "old")

    # Passing in 3 arguements
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")

# Generated at 2022-06-23 22:59:59.520843
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:01.852609
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None).rewrites == _get_rewrites()
    assert 'six' in SixMovesTransformer.dependencies

# Generated at 2022-06-23 23:00:10.490946
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
   

# Generated at 2022-06-23 23:00:20.518032
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:30.761851
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('dummy1', 'old1', 'new1')
    assert m.name == 'dummy1'
    assert m.new_mod == 'new1'
    assert m.new_attr == 'dummy1'

    m = MovedAttribute('dummy1', 'old1', 'new1', 'old1')
    assert m.name == 'dummy1'
    assert m.new_mod == 'new1'
    assert m.new_attr == 'old1'

    m = MovedAttribute('dummy1', 'old1', 'new1', 'old1', 'new2')
    assert m.name == 'dummy1'
    assert m.new_mod == 'new1'
    assert m.new_attr == 'new2'



# Generated at 2022-06-23 23:00:36.003081
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.old == "__builtin__"
    assert moved_module.new == "builtins"

    moved_module = MovedModule("builtins", "__builtin__", "__builtin2__")
    assert moved_module.name == "builtins"
    assert moved_module.old == "__builtin__"
    assert moved_module.new == "__builtin2__"

# Generated at 2022-06-23 23:00:38.723374
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 164
    assert ('urllib.parse.urlsplit', 'six.moves.urllib.urlsplit') in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:00:45.687119
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'Foo').name == 'foo'
    assert MovedModule('foo', 'Foo').new == 'foo'
    assert MovedModule('foo', 'Foo', 'bar').new == 'bar'
    assert MovedModule(name='foo', old='Foo').name == 'foo'
    assert MovedModule('foo', new='Foo').name == 'foo'
    assert MovedModule(name='foo', new='Foo').name == 'foo'


# Generated at 2022-06-23 23:00:47.603275
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test a string on the SixMovesTransformer
    test = SixMovesTransformer()
    assert test.description == "Replaces moved modules with ones from `six.moves`."
    test.rewrites
    test.dependencies


if __name__ == "__main__":
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:00:52.316401
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    src = "from six.moves.cStringIO import StringIO"
    tree = ast.parse(src)
    n = SixMovesTransformer(tree)
    n.visit(tree)
    src1 = "from six.moves import StringIO"
    assert astunparse.unparse(tree) == src1

# Generated at 2022-06-23 23:00:53.354194
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _get_rewrites()

# Generated at 2022-06-23 23:00:59.986732
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("parse", "urllib")
    assert move.name == "parse"
    assert move.new == "parse"
    assert move.old == "urllib"

    move = MovedModule("parse", "urllib", "urlparse")
    assert move.name == "parse"
    assert move.new == "urlparse"
    assert move.old == "urllib"


# Generated at 2022-06-23 23:01:10.045537
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test if SixMovesTransformer class is there or not
    assert 'SixMovesTransformer' in globals()

    # Test if SixMovesTransformer class is proper subclass of BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseImportRewrite)

    # Test constructor of SixMovesTransformer
    assert SixMovesTransformer.target == (2, 7)

# Generated at 2022-06-23 23:01:20.978325
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io", old_attr="StringIO")
    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "StringIO"
    item = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io")
    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "cStringIO"
    item = MovedAttribute(name="cStringIO", new_mod="io")
    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "cStringIO"

# Unit

# Generated at 2022-06-23 23:01:24.305567
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert isinstance(t.rewrites, list)
    assert len(t.rewrites) == 81
    assert t.dependencies == ['six']

# Generated at 2022-06-23 23:01:26.016271
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(isinstance(MovedModule("builtins", "__builtin__"), MovedModule))


# Generated at 2022-06-23 23:01:27.273102
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:01:34.299935
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite, RewritePredicate
    from .six import six_moves_transformer

    assert six_moves_transformer.__class__ == SixMovesTransformer
    assert issubclass(six_moves_transformer.__class__, BaseImportRewrite)
    assert six_moves_transformer.rewrites == dict(_get_rewrites())
    assert six_moves_transformer.dependencies == ["six"]
    assert callable(six_moves_transformer.predicate)
    assert isinstance(six_moves_transformer.predicate, RewritePredicate)
    assert six_moves_transformer.target == (2, 7)

# Generated at 2022-06-23 23:01:40.522242
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    from libcst._nodes.module import Module
    from libcst._nodes.expression import Name
    from libcst._nodes.functiondef import SimpleStatementLine
    from libcst._nodes.importfrom import ImportFrom
    from libcst._nodes.importasname import ImportAsName
    from libcst._nodes.assign import Assign
    from libcst._nodes.assigntarget import (
        Name as AssignName,
        Tuple as AssignTuple,
        List as AssignList
    )
    from libcst._nodes.base import (
        Comment,
        EmptyLine,
    )
    from libcst.metadata import MetadataWrapper
    from libcst._visitors import NoopVisitor

# Generated at 2022-06-23 23:01:48.490088
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert (c.name == "cStringIO")
    assert (c.new_mod == "io")
    assert (c.new_attr == "StringIO")

    c = MovedAttribute("cStringIO", "cStringIO", "io")
    assert (c.name == "cStringIO")
    assert (c.new_mod == "io")
    assert (c.new_attr == "cStringIO")

    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert (c.name == "cStringIO")
    assert (c.new_mod == "io")
    assert (c.new_attr == "StringIO")



# Generated at 2022-06-23 23:01:51.518616
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('move_name', 'old_name')
    assert moved_module.name == 'move_name'
    assert moved_module.new == 'move_name'
    moved_module1 = MovedModule('move_name1', 'old_name1', 'new_name')
    assert moved_module1.name == 'move_name1'
    assert moved_module1.old == 'old_name1'
    assert moved_module1.new == 'new_name'


# Generated at 2022-06-23 23:01:58.742610
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sample_code = '''
    import six.moves
    import six.moves.urllib.parse as urlparse
    from six.moves import urllib_parse
    from six.moves import urllib_parse as urlparse
    from six.moves.urllib.parse import urlparse
    import six.moves.urllib.parse
    '''
    code = ast.parse(sample_code)
    transformer = SixMovesTransformer()
    transformer.visit(code)
    expected = '''
    import six.moves
    import urllib.parse as urlparse
    from urllib.parse import urlparse as urlparse
    from urllib.parse import urlparse
    import urllib.parse
    '''
    expected = expected.strip()
    actual = astunparse

# Generated at 2022-06-23 23:02:04.258833
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-23 23:02:05.376552
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:02:07.949562
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from .moves.urllib_parse import urlsplit
    assert urlsplit

# Generated at 2022-06-23 23:02:11.793532
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old_name")
    assert mod.name == "name"
    assert mod.new == "name"
    mod = MovedModule("name", "old_name", "new_name")
    assert mod.new == "new_name"

# Generated at 2022-06-23 23:02:18.530151
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test', 'old') == MovedModule('test', 'old')
    assert MovedModule('test', 'old', 'new') == MovedModule('test', 'old')
    assert MovedModule('test', 'old') != MovedModule('test2', 'old')
    assert MovedModule('test', 'old') != MovedModule('test', 'old2')
    assert MovedModule('test', 'old', 'new') != MovedModule('test2', 'old', 'new')


# Generated at 2022-06-23 23:02:21.301785
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import sys
    sys.modules['MovedModule'] = MovedModule('moved','used','new')
    assert sys.modules['MovedModule'] is not None
    del sys.modules['MovedModule']

# Generated at 2022-06-23 23:02:26.696328
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('foo', 'bar')
    assert move.new == 'foo'
    assert move.name == 'bar'
    move = MovedModule('foo', 'bar', 'baz')
    assert move.new == 'foo'
    assert move.name == 'bar'
    move = MovedModule('foo', 'bar', 'baz')
    assert move.new == 'foo'
    assert move.name == 'bar'
    move = MovedModule('foo', 'bar', 'baz')
    assert move.name == 'bar'
    assert move.new == 'foo'


# Generated at 2022-06-23 23:02:38.015770
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute("one", "old", "new", "old_attr")
    assert mv.name == "one"
    assert mv.new_mod == "new"
    assert mv.new_attr == "old_attr"
    mv2 = MovedAttribute("one", "old", "new", "old_attr", "new_attr")
    assert mv2.name == "one"
    assert mv2.new_mod == "new"
    assert mv2.new_attr == "new_attr"
    mv3 = MovedAttribute("one", "old", "new")
    assert mv3.name == "one"
    assert mv3.new_mod == "new"
    assert mv3.new_attr == "one"

# Generated at 2022-06-23 23:02:41.934224
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"

# Unit tests for the constructor of class MovedAttribute

# Generated at 2022-06-23 23:02:46.259696
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert m.name == "name"
    assert m.new_mod == "new_mod"
    assert m.new_attr == "new_attr"

# Generated at 2022-06-23 23:02:47.890428
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_SixMovesTransformer.__doc__
    SixMovesTransformer

# Generated at 2022-06-23 23:02:51.051830
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import fixer_base, patcomp, pytree
    import lib2to3

    six_moves_transformer = SixMovesTransformer(fixer_base.FixerBase(),
                                                patcomp,
                                                pytree,
                                                lib2to3)
    assert six_moves_transformer

# Generated at 2022-06-23 23:02:56.790623
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'name'

    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'


# Generated at 2022-06-23 23:03:08.395010
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:03:12.565731
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-23 23:03:13.376070
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:03:23.687053
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert x.name == "cStringIO"
    assert x.new_mod == "io"
    assert x.new_attr == "StringIO"

    y = MovedAttribute("six", "six", "six", "six")
    assert y.name == "six"
    assert y.new_mod == "six"
    assert y.new_attr == "six"

    z = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert z.name == "filter"
    assert z.new_mod == "builtins"
    assert z.new_attr == "filter"



# Generated at 2022-06-23 23:03:27.564234
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(MovedModule('module', 'mod')) == 'MovedModule(module=module, old=mod, new=module)'
    assert str(MovedModule('x', 'y', 'z')) == 'MovedModule(module=x, old=y, new=z)'

# Generated at 2022-06-23 23:03:33.234664
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('foo', 'bar', 'baz', 'quux', 'xyzzy')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'xyzzy'
    move2 = MovedAttribute('foo', 'bar', 'baz')
    assert move2.name == 'foo'
    assert move2.new_mod == 'baz'
    assert move2.new_attr == 'foo'
    move3 = MovedAttribute('foo', 'bar', 'baz', 'quux')
    assert move3.name == 'foo'
    assert move3.new_mod == 'baz'
    assert move3.new_attr == 'quux'
    move4 = MovedAttribute('foo', 'bar', None)

# Generated at 2022-06-23 23:03:35.717669
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    o = SixMovesTransformer()
    assert o.rewrites == dict(rewrites)

# Generated at 2022-06-23 23:03:39.344278
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert len(transformer.rewrites) == 124, 'Expect to have 124 rewrites (got {})'\
        .format(len(transformer.rewrites))

# Generated at 2022-06-23 23:03:42.872873
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("winreg", "_winreg")
    assert move.name == "winreg"
    assert move.old == "_winreg"
    assert move.new == "winreg"


# Generated at 2022-06-23 23:03:47.352423
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attrib = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attrib.name == 'name'
    assert attrib.new_mod == 'new_mod'
    assert attrib.new_attr == 'new_attr'


# Generated at 2022-06-23 23:03:51.337572
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")

    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-23 23:04:01.471865
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..cookies.six_moves import SixMovesTransformer


# Generated at 2022-06-23 23:04:03.394039
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) == 8
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 23:04:09.476527
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert next(iter(SixMovesTransformer.rewrites)) == ('configparser.ConfigParser',
                                                        'six.moves.configparser')
    assert next(iter(SixMovesTransformer.rewrites)) == ('queue.Queue',
                                                        'six.moves.queue')
    assert next(iter(SixMovesTransformer.rewrites)) == ('urllib.parse',
                                                        'six.moves.urllib.parse')
    assert next(iter(SixMovesTransformer.rewrites)) == ('urllib.error',
                                                        'six.moves.urllib.error')
    assert next(iter(SixMovesTransformer.rewrites)) == ('urllib.request',
                                                        'six.moves.urllib.request')

# Generated at 2022-06-23 23:04:19.923788
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-23 23:04:24.774058
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-23 23:04:27.659179
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites[0] == ('xmlrpc.client.ServerProxy', 'six.moves.xmlrpc_client.ServerProxy')

# Generated at 2022-06-23 23:04:32.625767
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_name = 'module'
    old_name = 'old'
    new_name = 'new'
    mm = MovedModule(module_name, old_name, new_name)
    ret = mm.__dict__
    assert ret == {'name': 'module', 'old': 'old', 'new': 'new'}


# Generated at 2022-06-23 23:04:40.901973
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.name == "name"

    ma = MovedAttribute("name", "old_mod", "new_mod", old_attr="old_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.name == "name"

    ma = MovedAttribute("name", "old_mod", "new_mod")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "name"


# Generated at 2022-06-23 23:04:44.505380
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "new"


# Generated at 2022-06-23 23:04:46.538099
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert rewrites == SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:04:50.839375
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.new == "builtins"

    move = MovedModule("builtins", "__builtin__", "builtins")
    assert move.name == "builtins"
    assert move.new == "builtins"


# Generated at 2022-06-23 23:04:52.748318
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.rewrites is _get_rewrites()
    assert st.dependencies == ['six']

# Generated at 2022-06-23 23:04:56.121969
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # type: ignore
    assert len(_get_rewrites()) == len(set(_get_rewrites()))


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-23 23:05:02.515844
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('a_name', 'an_old', 'a_new')
    assert mod.name == 'a_name'
    assert mod.old == 'an_old'
    assert mod.new == 'a_new'

    mod = MovedModule('a_name', 'an_old')
    assert mod.name == 'a_name'
    assert mod.old == 'an_old'
    assert mod.new == 'a_name'


# Generated at 2022-06-23 23:05:09.041349
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule(name = 'name', old = 'old')
    assert mm1.name == 'name'
    assert mm1.new == 'name'
    assert mm1.old == 'old'
    mm2 = MovedModule(name = 'name', old = 'old', new = 'new')
    assert mm2.name == 'name'
    assert mm2.new == 'new'
    assert mm2.old == 'old'

# Generated at 2022-06-23 23:05:10.896287
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _rewrites = SixMovesTransformer.rewrites
    assert len(_rewrites) > 0

# Generated at 2022-06-23 23:05:17.600718
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") == MovedAttribute(
        "name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr") == MovedAttribute(
        "name", "old_mod", "new_mod", "old_attr")
    assert MovedAttribute("name", "old_mod", "new_mod", new_attr="new_attr") == MovedAttribute(
        "name", "old_mod", "new_mod", new_attr="new_attr")

# Generated at 2022-06-23 23:05:24.074828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    y = MovedModule('name', 'old', 'new')
    assert y.name == 'name'
    assert y.old == 'old'
    assert y.new == 'new'
    y = MovedModule('name', 'old')
    assert y.name == 'name'
    assert y.old == 'old'
    assert y.new == 'old'

# Generated at 2022-06-23 23:05:33.226764
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"

    obj = MovedAttribute("name", "old_mod", "new_mod")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "name"

    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "old_attr"



# Generated at 2022-06-23 23:05:43.644117
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.old == "__builtin__"
    assert module.new == "builtins"

    module = MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread")
    assert module.name == "_dummy_thread"
    assert module.old == "dummy_thread"
    assert module.new == "_dummy_thread"

    module = MovedModule("builtins", "__builtin__", "builtins")
    assert module.name == "builtins"
    assert module.old == "__builtin__"
    assert module.new == "builtins"



# Generated at 2022-06-23 23:05:48.818142
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                expected = 'six.moves{}.{}'.format(prefix, move.name)
            elif isinstance(move, MovedModule):
                path = move.new
                expected = 'six.moves{}.{}'.format(prefix, move.name)
            assert SixMovesTransformer.rewrites[path] == expected

# Generated at 2022-06-23 23:05:54.505770
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:57.644841
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'name'

# Generated at 2022-06-23 23:05:59.541319
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("foo", "foobar", "foobaz", "bar", "baz")
    assert attribute.name == "foo"
    assert attribute.new_mod == "foobaz"
    assert attribute.new_attr == "baz"


# Generated at 2022-06-23 23:06:06.368464
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert (MovedModule('a', "b", "c").name == 'a')
    assert (MovedModule('a', "b", "c").old == "b")
    assert (MovedModule('a', "b", "c").new == "c")
    assert (MovedModule('a', "b").name == 'a')
    assert (MovedModule('a', "b").old == "b")
    assert (MovedModule('a', "b").new == "a")


# Generated at 2022-06-23 23:06:10.240379
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert movedattribute.name == "cStringIO"
    assert movedattribute.new_mod == "cStringIO"
    assert movedattribute.new_attr == "StringIO"


# Generated at 2022-06-23 23:06:20.729278
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'

    assert MovedAttribute('a', 'b', 'c').name == 'a'
    assert MovedAttribute('a', 'b', 'c').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c').new_attr == 'a'

    assert MovedAttribute('a', 'b', 'c', 'd').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd').new_mod == 'c'
    assert MovedAttribute

# Generated at 2022-06-23 23:06:22.836779
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=unused-variable
    transformer = SixMovesTransformer

# Generated at 2022-06-23 23:06:23.516161
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

# Generated at 2022-06-23 23:06:26.370514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule("BaseHTTPServer", "BaseHTTPServer", "http.server")
    assert mm1.new == "http.server"
    assert mm1.name == "BaseHTTPServer"
    mm2 = MovedModule("CGIHTTPServer", "CGIHTTPServer")
    assert mm2.new == "CGIHTTPServer"

# Generated at 2022-06-23 23:06:30.492797
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"



# Generated at 2022-06-23 23:06:37.293480
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"
    mm = MovedModule("name")
    assert mm.name == "name"
    assert mm.old is None
    assert mm.new == "name"


# Generated at 2022-06-23 23:06:45.000706
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('name', 'old_mod', 'new_mod')
    assert a.name == 'name'
    assert a.new_mod == 'new_mod'
    assert a.new_attr == 'name'
    b = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert b.new_attr == 'old_attr'
    c = MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr')
    assert c.new_attr == 'new_attr'

# Generated at 2022-06-23 23:06:46.824780
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transform = SixMovesTransformer()
    assert isinstance(transform, BaseImportRewrite)


# Generated at 2022-06-23 23:06:53.681926
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    original = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    new = MovedAttribute("cStringIO", "cStringIO", "io")
    assert original.name == new.name == "cStringIO"
    assert original.new_mod == new.new_mod == "io"
    assert original.new_attr == "StringIO"
    assert new.new_attr == "cStringIO"

# Generated at 2022-06-23 23:06:58.838800
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == (
        len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) +
        len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) +
        len(_urllib_robotparser_moved_attributes))

# Generated at 2022-06-23 23:07:01.686296
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    mm = MovedModule('builtins', '__builtin__')
    assert mm.new == 'builtins'
    assert mm.name == 'builtins'

# Generated at 2022-06-23 23:07:13.940206
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("StringIO", "cStringIO", "io")
    assert attribute.name == "StringIO"
    assert attribute.old_mod == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.old_attr == None
    assert attribute.new_attr == "StringIO"

    attribute = MovedAttribute("StringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert attribute.name == "StringIO"
    assert attribute.old_mod == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.old_attr == "StringIO"
    assert attribute.new_attr == "StringIO"

    attribute = MovedAttribute("StringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert attribute

# Generated at 2022-06-23 23:07:16.470210
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "a.b")
    assert mod.name == "name"
    assert mod.new == "name"
    assert mod.old == "a.b"

# Generated at 2022-06-23 23:07:25.851688
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that `SixMovesTransformer` has been constructed properly."""

# Generated at 2022-06-23 23:07:26.760841
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert set(_get_rewrites()) == set(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:07:29.960488
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("test_module", "old_module", "new_module")
    assert x.name == "test_module"
    assert x.old == "old_module"
    assert x.new == "new_module"


# Generated at 2022-06-23 23:07:40.017581
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:07:45.764641
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that constructor of class SixMovesTransformer works correctly."""
    obj = SixMovesTransformer()
    assert obj.target == (2, 7)
    assert obj.rewrites == list((k, 'six.moves' + v) for k, v in _get_rewrites())
    assert obj.dependencies == ['six']


# Generated at 2022-06-23 23:07:49.424141
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo").name == "foo"
    assert MovedModule("foo").new == "foo"
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").new == "bar"

# Generated at 2022-06-23 23:07:51.396273
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Unit test for constructor of class SixMovesTransformer."""
    # The following statements should not generate any exception
    SixMovesTransformer()

# Generated at 2022-06-23 23:07:59.724081
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedAttribute = MovedAttribute('foo', 'old', 'new', 'old_attr', 'new_attr')
    assert movedAttribute.name == 'foo'
    assert movedAttribute.new_mod == 'new'
    assert movedAttribute.old_attr == 'old_attr'
    assert movedAttribute.new_attr == 'new_attr'

    movedAttributeWithNoneAttr = MovedAttribute('foo', 'old', 'new')
    assert movedAttributeWithNoneAttr.name == 'foo'
    assert movedAttributeWithNoneAttr.new_mod == 'new'
    assert movedAttributeWithNoneAttr.old_attr is None
    assert movedAttributeWithNoneAttr.new_attr == 'foo'

# Generated at 2022-06-23 23:08:00.785713
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:08:06.422162
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"


# Generated at 2022-06-23 23:08:12.831173
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.__class__.__name__ == 'SixMovesTransformer'
    assert transformer.__class__.__mro__ == (SixMovesTransformer,
                                             BaseImportRewrite,
                                             object)
    assert (transformer.__class__.__module__,
            transformer.__class__.__name__) == ('backports.six.moves',
                                                'SixMovesTransformer')


# Tests for method _get_rewrites of class SixMovesTransformer

# Generated at 2022-06-23 23:08:16.350789
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"

    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"

# Generated at 2022-06-23 23:08:20.929815
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert (move.name, move.new_mod, move.new_attr) == ("cStringIO", "cStringIO", "StringIO")

# Generated at 2022-06-23 23:08:24.717499
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites()[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert _get_rewrites()[-1] == ('html.entities', 'six.moves.html_entities')

# Generated at 2022-06-23 23:08:31.247014
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('builtins', '__builtin__')
    assert move.name == 'builtins'
    assert move.new == 'builtins'
    assert move.old == '__builtin__'
    move = MovedModule('builtins', '__builtin__', 'six.moves')
    assert move.name == 'builtins'
    assert move.new == 'six.moves'
    assert move.old == '__builtin__'

# Generated at 2022-06-23 23:08:38.203770
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("foo", "bar", "baz")
    assert(move.name == "foo")
    assert(move.new == "baz")
    assert(move.old == "bar")

    move = MovedModule("foo", "bar")
    assert(move.name == "foo")
    assert(move.new == "foo")
    assert(move.old == "bar")

    move = MovedModule("foo")
    assert(move.name == "foo")
    assert(move.new == "foo")
    assert(move.old == "foo")

# Generated at 2022-06-23 23:08:41.035372
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule('name', 'old', 'new')
    assert movedModule.name == 'name'
    assert movedModule.old == 'old'
    assert movedModule.new == 'new'

# Generated at 2022-06-23 23:08:44.934347
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.old == '__builtin__'
    assert moved_module.new == 'builtins'



# Generated at 2022-06-23 23:08:54.043084
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old', 'new') != MovedModule('name2', 'old2', 'new2')
    assert MovedModule('name', 'old2', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old', 'new2') == MovedModule('name', 'old', 'new')
    assert str(MovedModule('name', 'old', 'new')) == 'MovedModule(name, old, new)'




# Generated at 2022-06-23 23:09:03.754731
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("foo", "bar", "baz")
    assert a.name == "foo"
    assert a.new_mod == "baz"
    assert a.new_attr == "foo"

    a = MovedAttribute("foo", "bar", "baz", "qux", "quux")
    assert a.name == "foo"
    assert a.new_mod == "baz"
    assert a.new_attr == "quux"

    a = MovedAttribute("foo", "bar", "baz", "qux")
    assert a.name == "foo"
    assert a.new_mod == "baz"
    assert a.new_attr == "qux"


# Generated at 2022-06-23 23:09:14.104994
# Unit test for constructor of class MovedAttribute