

# Generated at 2022-06-23 22:59:24.004030
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") \
        == MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") \
        != MovedAttribute("cStringIO", "cStringIO", "io", "StringIO2")

    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") \
        != MovedAttribute("cStringIO2", "cStringIO", "io", "StringIO")

    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") \
        != MovedAttribute("cStringIO", "cStringIO2", "io", "StringIO")


# Generated at 2022-06-23 22:59:25.381526
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('hello', 'there')  # type: ignore

# Generated at 2022-06-23 22:59:27.805435
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.new == 'new'

# Generated at 2022-06-23 22:59:36.054736
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('foo', 'bar', 'baz')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'foo'

    move = MovedAttribute('foo', 'bar', 'baz', 'foo', 'baz')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'baz'

    move = MovedAttribute('foo', 'bar', 'baz', 'spam', 'eggs')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'eggs'

    move = MovedAttribute('foo', 'bar', 'baz', old_attr='spam')

# Generated at 2022-06-23 22:59:47.368664
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr='StringIO', new_attr=None)
    ma2 = MovedAttribute(name='filter', old_mod='itertools', new_mod='builtins', old_attr='ifilter', new_attr='filter')
    ma3 = MovedAttribute(name='filterfalse', old_mod='itertools', new_mod='itertools', old_attr='ifilterfalse', new_attr='filterfalse')
    ma4 = MovedAttribute(name='input', old_mod='__builtin__', new_mod='builtins', old_attr='raw_input', new_attr='input')

# Generated at 2022-06-23 22:59:52.582981
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"

# Generated at 2022-06-23 22:59:56.017410
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("name", "mod", "new_mod", "old_attr", "new_attr")
    assert moved.name == 'name'
    assert moved.new_attr == 'new_attr'



# Generated at 2022-06-23 23:00:01.902429
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("f", "a", "b", "c", "d").new_attr == "d"
    assert MovedAttribute("f", "a", "b", "c", "f").new_attr == "f"
    assert MovedAttribute("f", "a", "b", "f", "d").new_attr == "f"
    assert MovedAttribute("f", "a", "b").new_attr == "f"

# Generated at 2022-06-23 23:00:03.014611
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule('name', 'old', 'new')
    assert movedmodule.name == 'name'
    assert movedmodule.new == 'new'

# Generated at 2022-06-23 23:00:08.756686
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("TestModule")
    assert test_module.name == "TestModule"
    assert test_module.new == "TestModule"
    test_module = MovedModule("TestModule", "old")
    assert test_module.name == "TestModule"
    assert test_module.new == "TestModule"
    test_module = MovedModule("TestModule", "old", "new")
    assert test_module.name == "TestModule"
    assert test_module.new == "new"

# Generated at 2022-06-23 23:00:18.872577
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test1 = MovedAttribute("name", "old_mod", "new_mod")
    assert test1.name == "name"
    assert test1.new_mod == "new_mod"
    assert test1.new_attr == "name"
    
    test2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert test2.name == "name"
    assert test2.new_mod == "new_mod"
    assert test2.new_attr == "old_attr"
    
    test3 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert test3.name == "name"
    assert test3.new_mod == "new_mod"

# Generated at 2022-06-23 23:00:21.688006
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-23 23:00:27.227918
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    module = MovedAttribute("UserString", "UserString", "collections", new_attr="UserString")
    assert module.name == "UserString"
    assert module.old_mod == "UserString"
    assert module.new_mod == "collections"
    assert module.new_attr == "UserString"



# Generated at 2022-06-23 23:00:32.679815
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try_mod = MovedModule("http_cookiejar", "cookielib", "http.cookiejar")
    assert try_mod.name == "http_cookiejar"
    assert try_mod.old == "cookielib"
    assert try_mod.new == "http.cookiejar"
    try_mod = MovedModule("configparser", "ConfigParser")
    assert try_mod.name == "configparser"
    assert try_mod.old == "ConfigParser"
    assert try_mod.new == "configparser"
    try_mod = MovedModule("tkinter_dialog", "Dialog", "tkinter.dialog")
    assert try_mod.name == "tkinter_dialog"
    assert try_mod.old == "Dialog"
    assert try_mod.new == "tkinter.dialog"

# Unit

# Generated at 2022-06-23 23:00:42.285449
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") == \
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != \
        MovedAttribute("StringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != \
        MovedAttribute("cStringIO", "cSringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != \
        MovedAttribute("cStringIO", "cStringIO", "i0", "StringIO")

# Generated at 2022-06-23 23:00:45.686737
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'

# Generated at 2022-06-23 23:00:47.925130
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Unit test for constructor of class SixMovesTransformer"""
    SixMovesTransformer()

# Generated at 2022-06-23 23:00:50.096765
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()
    

# get_regexps

# Generated at 2022-06-23 23:00:51.169235
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()
    assert obj.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:00:55.471147
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, tuple)
    assert all(isinstance(_, tuple) for _ in SixMovesTransformer.rewrites)
    assert all(isinstance(_[0], str) and isinstance(_[1], str) for _ in SixMovesTransformer.rewrites)



# Generated at 2022-06-23 23:01:06.677203
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    MovedAttribute('cStringIO', 'cStringIO', 'io', old_attr='StringIO')
    MovedAttribute('cStringIO', 'cStringIO', 'io', new_attr='StringIO')
    # New attr default is name
    MovedAttribute('cStringIO', 'cStringIO', 'io')
    # New attr default is old_attr if set
    MovedAttribute('cStringIO', 'cStringIO', 'io', old_attr='StringIO')
    # New module default is name
    MovedAttribute('cStringIO', 'cStringIO', None)


# Generated at 2022-06-23 23:01:11.920654
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('a', 'b')
    assert mm.name == 'a'
    assert mm.old == 'b'
    assert mm.new == 'a'

    mm = MovedModule('a', 'b', 'c')
    assert mm.name == 'a'
    assert mm.old == 'b'
    assert mm.new == 'c'

# Generated at 2022-06-23 23:01:19.595298
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    actual = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert actual.name == "cStringIO"
    assert actual.new_mod == "io"
    assert actual.new_attr == "StringIO"
    actual = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    assert actual.name == "range"
    assert actual.new_mod == "builtins"
    assert actual.new_attr == "range"



# Generated at 2022-06-23 23:01:20.261188
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str(SixMovesTransformer)

# Generated at 2022-06-23 23:01:29.579760
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from PyUpgrade.tests.test_utils import get_test_input_path
    from PyUpgrade.upgrader.utils.helpers import read_file
    from PyUpgrade.upgrader.utils import get_parser_from_data, format_code

    path = get_test_input_path('sixmoves.py')
    data = read_file(path)
    parser = get_parser_from_data(data)
    new_parser = SixMovesTransformer().visit(parser)
    new_data = format_code(new_parser)

# Generated at 2022-06-23 23:01:38.431073
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # valid parameter list
    MovedModule("name", "old", "new")
    # no optional parameter
    MovedModule("name", "old")
    # invalid parameter list
    with pytest.raises(TypeError):
        MovedModule("name", "old", "new", "other")
    # missing mandatory parameter
    with pytest.raises(TypeError):
        MovedModule("name")
    # missing mandatory parameter
    with pytest.raises(TypeError):
        MovedModule()
    # extra mandatory parameter
    with pytest.raises(TypeError):
        MovedModule("name", "old", "new", "other", "other")


# Generated at 2022-06-23 23:01:42.856592
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("hello","hello")
    assert m.name == "hello"
    assert m.new == "hello"
    m = MovedModule("hello","world")
    assert m.name == "hello"
    assert m.new == "world"

# Generated at 2022-06-23 23:01:50.373411
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def check():
        transformer = SixMovesTransformer()

# Generated at 2022-06-23 23:01:53.011001
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m_module = MovedModule("123", "456")
    assert m_module.name == "123"
    assert m_module.old == "456"
    assert m_module.new == "123"


# Generated at 2022-06-23 23:02:02.074411
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:11.213653
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"

    attr = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "cStringIO"
    assert attr.new_attr == "StringIO"

    attr = Moved

# Generated at 2022-06-23 23:02:16.312537
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("foo", "bar", "baz")
    assert moved_module.name == "foo"
    assert moved_module.new == "baz"
    assert moved_module.old == "bar"
    assert moved_module.__repr__() == "<MovedModule: foo ('bar'->'baz')>"


# Generated at 2022-06-23 23:02:19.101208
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('configparser', 'ConfigParser')
    assert m.name == 'configparser'
    assert m.old == 'ConfigParser'
    assert m.new == 'configparser'
    return m


# Generated at 2022-06-23 23:02:20.488117
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    result = list(_get_rewrites())
    assert result == SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:02:21.431006
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:02:33.024378
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    from .base import BaseImportRewrite
    from .six_moves import SixMovesTransformer

    BaseImportRewrite._check_rewrite("six.moves.queue", "Queue", rewriting_tool=SixMovesTransformer())
    BaseImportRewrite._check_rewrite("six.moves.urllib_parse", "six.moves.urllib_parse", rewriting_tool=SixMovesTransformer())
    BaseImportRewrite._check_rewrite("six.moves.urllib_error", "six.moves.urllib_error", rewriting_tool=SixMovesTransformer())
    BaseImportRewrite._check_rewrite("six.moves.urllib_request", "six.moves.urllib_request", rewriting_tool=SixMovesTransformer())
    BaseImportRew

# Generated at 2022-06-23 23:02:44.416874
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:46.635912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_attr == "StringIO"
    assert ma.new_mod == "io"


# Generated at 2022-06-23 23:02:51.045774
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """A test of the constructor of SixMovesTransformer"""
    tr = SixMovesTransformer()
    assert tr.target == (2, 7)
    assert tr.rewrites == _get_rewrites()
    assert tr.dependencies == ['six']


# Unit tests for class SixMovesTransformer


# Generated at 2022-06-23 23:02:52.098249
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 63

# Generated at 2022-06-23 23:03:04.482741
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_attr1 = MovedModule('test', 'mod1')
    assert moved_attr1.name == 'mod1'
    assert moved_attr1.new == 'mod1'
    moved_attr2 = MovedModule('test', 'mod1', 'mod2')
    assert moved_attr2.name == 'mod2'
    assert moved_attr2.new == 'mod2'
    moved_attr3 = MovedModule('test', 'mod1', None)
    assert moved_attr3.name == 'mod1'
    assert moved_attr3.new == 'mod1'
    moved_attr4 = MovedModule('test', None, 'mod2')
    assert moved_attr4.name == 'mod2'
    assert moved_attr4.new == 'mod2'

# Generated at 2022-06-23 23:03:09.910440
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__", "something").new == "something"
    assert MovedModule("builtins", "__builtin__", "something").name == "builtins"

# Generated at 2022-06-23 23:03:18.244885
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    an_attr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert an_attr.name == "filter"
    assert an_attr.new_attr == "filter"
    assert an_attr.new_mod == "builtins"

    another_attr = MovedAttribute("filter", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert another_attr.name == "filter"
    assert another_attr.new_attr == "filterfalse"
    assert another_attr.new_mod == "itertools"

    yet_another_attr = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert yet_another_attr.name == "input"

# Generated at 2022-06-23 23:03:22.190024
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:26.680464
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute = MovedAttribute('foo', 'bar', 'baz', 'qux', 'quux')
    assert test_MovedAttribute.name == 'foo'
    assert test_MovedAttribute.new_mod == 'baz'
    assert test_MovedAttribute.new_attr == 'quux'

# Generated at 2022-06-23 23:03:31.203627
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=expression-not-assigned
    MovedAttribute("name", "old_mod", "new").name == "name"
    MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    MovedAttribute("name", "old_mod", "new_mod", "old_attr").name == "name"
    MovedAttribute("name", "old_mod", "new_mod", None, "new_attr").name == "name"
    MovedAttribute("name", "old_mod", None).name == "name"

# Generated at 2022-06-23 23:03:32.064898
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer(None)

# Generated at 2022-06-23 23:03:39.216065
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:03:44.862350
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('test', 'newtest', 'newtest')
    assert MovedAttribute('test', 'newtest', 'newtest', 'test1', 'test1')
    assert MovedAttribute('test', 'newtest', 'newtest', 'test1')
    assert MovedAttribute('test', 'newtest', 'newtest', new_attr='test1')


# Generated at 2022-06-23 23:03:48.970119
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('module', 'module_old')
    assert module.name == 'module'
    assert module.new == 'module'
    module = MovedModule('module', 'module_old', 'module_new')
    assert module.name == 'module'
    assert module.new == 'module_new'

# Generated at 2022-06-23 23:03:52.079383
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("collections", "collections") == MovedModule("collections", "collections", "collections")
    assert MovedModule("any", "any") == MovedModule("any", "any", "any")
    assert MovedModule("new", "old") == MovedModule("new", "old", "new")



# Generated at 2022-06-23 23:03:54.483869
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import six_moves
    assert six_moves.SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:03:59.160055
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("reprlib", "repr")
    assert module.name == "reprlib"
    assert module.new == "reprlib"
    assert module.old == "repr"
    # without old argument
    module = MovedModule("reprlib")
    assert module.name == "reprlib"
    assert module.new == "reprlib"
    assert module.old == "reprlib"
    # with new argument
    module = MovedModule("reprlib", "repr", "repr")
    assert module.name == "reprlib"
    assert module.new == "repr"
    assert module.old == "repr"


# Generated at 2022-06-23 23:04:03.117206
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-23 23:04:08.751739
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar", "baz").name == "foo"
    assert MovedModule("foo", "bar", "baz").old == "bar"
    assert MovedModule("foo", "bar", "baz").new == "baz"

    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").old == "bar"
    assert MovedModule("foo", "bar").new == "foo"

    assert MovedModule("foo").name == "foo"
    assert MovedModule("foo").old == "foo"
    assert MovedModule("foo").new == "foo"



# Generated at 2022-06-23 23:04:13.697119
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-23 23:04:18.284905
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Unit test for ``SixMovesTransformer``.
    """
    transformer = SixMovesTransformer()
    assert len(transformer.rewrites) == 66
    assert transformer.rewrites[0][0] == 'dbm.gnu'
    assert transformer.rewrites[0][1] == "six.moves.dbm_gnu"

# Generated at 2022-06-23 23:04:21.453291
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test constructor
    assert _moved_attributes[0].name == "cStringIO"
    assert _moved_attributes[0].new_mod == "io"
    assert _moved_attributes[0].new_attr == "StringIO"


# Generated at 2022-06-23 23:04:27.557246
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('A', 'B')
    assert m.name == 'A'
    assert m.old == 'B'
    assert m.new == 'B'
    m = MovedModule('A', 'B', 'C')
    assert m.name == 'A'
    assert m.old == 'B'
    assert m.new == 'C'


# Generated at 2022-06-23 23:04:34.039569
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                yield (path, 'six.moves{}.{}'.format(prefix, move.name))
            elif isinstance(move, MovedModule):
                yield (move.new, 'six.moves{}.{}'.format(prefix, move.name))

# Generated at 2022-06-23 23:04:35.565246
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert ('' in SixMovesTransformer.rewrites) == True

# Generated at 2022-06-23 23:04:37.902683
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('new','old')
    assert module.name == 'new'
    assert module.new == 'new'
    assert module.old == 'old'


# Generated at 2022-06-23 23:04:48.315855
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    input_code = '''
import sys
from six import StringIO
from six.moves import StringIO

import six.moves.urllib.parse
import six.moves.urllib.request
import six.moves.urllib.parse

import six
import six.moves
'''
    expected_output_code = '''
import sys
from six import StringIO
from six.moves import StringIO

import six.moves.urllib_parse
import six.moves.urllib_request
import six.moves.urllib_parse

import six
import six.moves
'''
    SixMovesTransformer.test_transform_snippet(input_code, expected_output_code)

# Generated at 2022-06-23 23:04:54.685826
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    before = """
        import itertools
        import os

        a = itertools.ifilter()
        b = os.getcwdu()
    """
    after = """
        from six.moves import itertools, os

        a = itertools.filter()
        b = os.getcwd()
    """
    transformer = SixMovesTransformer()
    result = transformer.visit(ast.parse(before))
    # We need to remove the `__future__` import because it is added after
    # parsing.
    result.body.pop(0)
    assert ast.dump(ast.parse(after)) == ast.dump(result)

# Generated at 2022-06-23 23:04:56.301388
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) > 0

# Generated at 2022-06-23 23:05:01.987416
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert(MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'cStringIO')
    assert(MovedAttribute('range', '__builtin__', 'builtins', 'xrange', 'range').new_attr == 'range')
    assert(MovedAttribute('reduce', '__builtin__', 'functools').new_attr == 'reduce')


# Generated at 2022-06-23 23:05:04.730958
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move1.name =="cStringIO"
    assert move1.new_mod == "io"
    assert move1.new_attr == "StringIO"


# Generated at 2022-06-23 23:05:08.903760
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert movedattr.name == "name"
    assert movedattr.new_mod == "new_mod"
    assert movedattr.new_attr == "new_attr"

# Generated at 2022-06-23 23:05:17.637888
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('new_module', 'old_module') == MovedModule('new_module', 'old_module')
    assert MovedModule('new_module', 'old_module') != MovedModule('new_module', 'old_module2')
    assert MovedModule('new_module2', 'old_module') != MovedModule('new_module', 'old_module')
    assert MovedModule('new_module', 'old_module') != MovedModule('new_module', 'old_module', 'new_module2')
    assert MovedModule('new_module2', 'old_module', 'new_module') == MovedModule('new_module', 'old_module', 'new_module2')

# Generated at 2022-06-23 23:05:21.850833
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    assert mm.old == 'old'


# Generated at 2022-06-23 23:05:23.778033
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"


# Generated at 2022-06-23 23:05:27.504761
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_input_module_name = 'test'
    test_input_old_module_path = 'testpath'
    test_input_new_module_path = 'new_testpath'
    test_move_module = MovedModule(test_input_module_name, test_input_old_module_path, test_input_new_module_path)
    assert test_move_module.name == test_input_module_name
    assert test_move_module.new == test_input_new_module_path


# Generated at 2022-06-23 23:05:31.991078
# Unit test for constructor of class MovedModule
def test_MovedModule():
    print("------- test_MovedModule")
    mm = MovedModule("new", "old")
    assert mm.new == "new"
    assert mm.name == "new"
    assert mm.old == "old"

    mm = MovedModule("new", "old", "extra")
    assert mm.new == "new"
    assert mm.name == "new"
    assert mm.old == "old"

# Generated at 2022-06-23 23:05:40.035335
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'cStringIO'
    old_mod = 'cStringIO'
    new_mod = 'io'
    old_attr = 'StringIO'
    new_attr = None
    obj = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert obj.name == 'cStringIO'
    assert obj.new_mod == 'io'
    assert obj.new_attr == 'StringIO'


# Generated at 2022-06-23 23:05:44.313800
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"


# Generated at 2022-06-23 23:05:49.796374
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"

    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-23 23:05:53.135528
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('hello', 'bye', 'goodbye')
    assert mm.name == 'hello'
    assert mm.old == 'bye'
    assert mm.new == 'goodbye'

    mm = MovedModule('hello', 'bye')
    assert mm.name == 'hello'
    assert mm.old == 'bye'
    assert mm.new == 'hello'

# Generated at 2022-06-23 23:05:54.804489
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(MovedModule("tkinter","Tkinter")) == "MovedModule(name='tkinter', old='Tkinter', new='tkinter')"

# Generated at 2022-06-23 23:05:55.804330
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0

# Generated at 2022-06-23 23:06:00.013710
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("module1", "module2")
    assert m.name == "module1"
    assert m.old == "module2"
    assert m.new == "module1"



# Generated at 2022-06-23 23:06:04.647467
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute('attr_name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attr.name == 'attr_name'
    assert moved_attr.new_mod == 'new_mod'
    assert moved_attr.new_attr == 'new_attr'

# Generated at 2022-06-23 23:06:11.642070
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    assert MovedModule('dbm_gnu', 'gdbm').new == 'dbm.gnu'
    assert MovedModule('dbm_gnu', 'gdbm').name == 'dbm_gnu'
    assert MovedModule('dbm_gnu', 'gdbm').old == 'gdbm'


# Generated at 2022-06-23 23:06:15.665700
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"


# Generated at 2022-06-23 23:06:18.857751
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "old"

# Generated at 2022-06-23 23:06:21.786601
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__")
    assert MovedModule("tkinter", "Tkinter")

# Generated at 2022-06-23 23:06:27.267794
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_ma = MovedAttribute("test_name", "test_old_mod", "test_new_mod", "test_old_attr", "test_new_attr")
    assert test_ma.name == "test_name"
    assert test_ma.new_mod == "test_new_mod"
    assert test_ma.new_attr == "test_new_attr"



# Generated at 2022-06-23 23:06:37.455143
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old_mod', 'new_mod')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'name'

    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'

    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'old_attr'


# Generated at 2022-06-23 23:06:39.096506
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert 'six' in transformer.dependencies

# Generated at 2022-06-23 23:06:43.897890
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    string = 'cStringIO'
    new_mod = 'cStringIO'
    new_attr = 'StringIO'
    attr = MovedAttribute(string, new_mod, new_attr)
    assert attr.name == attr.new_attr == 'cStringIO'
    assert attr.new_mod == 'io'


# Generated at 2022-06-23 23:06:54.668883
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.target == (2, 7)

# Generated at 2022-06-23 23:07:00.255439
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert [
        ('some_package.some_module.some_variable',
         'six.moves.some_variable'),
        ('some_package.some_module.other_variable',
         'six.moves.other_variable'),
        ('some_package.some_module.some_function',
         'six.moves.some_function')
    ] == sorted(SixMovesTransformer._get_rewrites())

# Generated at 2022-06-23 23:07:04.850276
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:07:07.211404
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar').name == 'foo'



# Generated at 2022-06-23 23:07:12.075277
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"

# Generated at 2022-06-23 23:07:17.467690
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").old == "__builtin__"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__", "__builtins__").new == "__builtins__"


# Generated at 2022-06-23 23:07:19.191441
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer('six')
    assert t.rewrites == SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:07:20.161446
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:07:24.405152
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test MovedModule constructor.

    Note: MovedModule constructor is for testing, and should not be used
    for importing modules.
    """
    from_module = "abc"
    to_module = "def"
    move_test = MovedModule(from_module, from_module, to_module)
    assert move_test.name == from_module
    assert move_test.new == to_module

# Generated at 2022-06-23 23:07:27.195013
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer.rewrites) == _get_rewrites()



# Generated at 2022-06-23 23:07:30.620990
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    instance = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert instance.name == "cStringIO"
    assert instance.new_mod == "io"
    assert instance.new_attr == "StringIO"


# Generated at 2022-06-23 23:07:40.367070
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"

    assert MovedModule("UserDict", "UserDict").name == "UserDict"
    assert MovedModule("UserDict", "UserDict").new == "collections"

    assert MovedModule("UserList", "UserList", "collections").name == "UserList"
    assert MovedModule("UserList", "UserList", "collections").new == "collections"

    assert MovedModule("UserString", "UserString", "collections").name == "UserString"
    assert MovedModule("UserString", "UserString", "collections").new == "collections"


# Generated at 2022-06-23 23:07:51.766858
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libmodernize.fixes import fix_six_moves
    from libmodernize.main import parse_args, _get_fixes, _get_fixes_from_name
    from libmodernize.fixes import FixerError

    # Make sure it's listed in the module doc string:
    assert fix_six_moves.__name__ in fix_six_moves.__doc__.split('\n')[0]

    # Make sure it's listed in the command line arguments
    assert "fix_six_moves" in ' '.join(parse_args(['--list-fixes']).get_description().split('\n')[3:])

    # Can't get it through get_fixers (private method)
    with raises(FixerError):
        _get_fixes("fix_six_moves")

    # But that's OK,

# Generated at 2022-06-23 23:08:02.520689
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a = """# This is a comment
import sys
import six
import notsix.moves
from six.moves import map
from six.moves import zip
import six.moves.urllib.parse
import six.moves.urllib.error
import six.moves.urllib.request
import six.moves.urllib.response
import six.moves.urllib.robotparser
from six.moves.urllib.parse import quote_plus
import six.moves.urllib_parse

"""
    collection = ImportCollection()
    assert collection.count_modules() == 0
    SixMovesTransformer.transform(a, collection)
    assert collection.count_modules() == 1
    assert 'six.moves' in collection.modules

# Generated at 2022-06-23 23:08:09.089609
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "").new_attr == "cStringIO"


# Generated at 2022-06-23 23:08:15.545115
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test moved modules with different new and old names
    assert ('os', 'six.moves.os') in SixMovesTransformer.rewrites
    assert ('tkinter', 'six.moves.tkinter') in SixMovesTransformer.rewrites
    assert ('queue', 'six.moves.queue') in SixMovesTransformer.rewrites

    # test moved modules with same new and old names
    assert ('builtins', 'six.moves.builtins') in SixMovesTransformer.rewrites
    assert ('configparser', 'six.moves.configparser') in SixMovesTransformer.rewrites

    # test moved modules to a different module
    assert ('urllib', 'six.moves.urllib') in SixMovesTransformer.rewrites

    # test moved attributes

# Generated at 2022-06-23 23:08:23.467138
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'



# Generated at 2022-06-23 23:08:31.680221
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert transformer.rewrites[path] == ('six.moves{}.{}'.format(prefix, move.name))
            elif isinstance(move, MovedModule):
                assert transformer.rewrites[move.new] == ('six.moves{}.{}'.format(prefix, move.name))

# Generated at 2022-06-23 23:08:39.985723
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six
    my_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert my_moved_attribute.name == "cStringIO"
    assert my_moved_attribute.new_mod == "io"
    assert my_moved_attribute.new_attr == "StringIO"

    my_moved_attribute_2 = MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
    assert my_moved_attribute_2.name == 'getcwdb'
    assert my_moved_attribute_2.new_mod == 'os'
    assert my_moved_attribute_2.new_attr == 'getcwd'


# Generated at 2022-06-23 23:08:41.370214
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for line, expected in _get_rewrites():
        assert line == expected

# Generated at 2022-06-23 23:08:46.105195
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert type(move) == MovedAttribute
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"



# Generated at 2022-06-23 23:08:52.600416
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule("name1", "old1")
    assert m1.name == "name1"
    assert m1.old == "old1"
    assert m1.new == "name1"
    m2 = MovedModule("name2", "old2", "new2")
    assert m2.name == "name2"
    assert m2.old == "old2"
    assert m2.new == "new2"

# Generated at 2022-06-23 23:09:03.755343
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert MovedAttribute("intern", "__builtin__", "sys")
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map")
    assert MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-23 23:09:04.740599
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites())

# Generated at 2022-06-23 23:09:08.557448
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("foo", "bar")
    assert module.name == "foo"
    assert module.new == "foo"
    assert module.old == "bar"
    module = MovedModule("foo", "bar", "baz")
    assert module.name == "foo"
    assert module.new == "baz"
    assert module.old == "bar"

# Generated at 2022-06-23 23:09:19.518468
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", None, None, None).name == "name"
    assert MovedAttribute("name", "old_mod", None, None, None).new_mod == "name"
    assert MovedAttribute("name", "old_mod", None, None, None).new_attr == "name"

    assert MovedAttribute("name", "old_mod", "new_mod", None, None).name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", None, None).new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", None, None).new_attr == "name"

    assert MovedAttribute("name", "old_mod", None, "old_attr", None).name == "name"