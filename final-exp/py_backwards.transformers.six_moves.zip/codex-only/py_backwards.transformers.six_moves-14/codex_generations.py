

# Generated at 2022-06-23 22:59:17.193022
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('at', 'at', 'at')
    MovedModule('at', 'at')
    MovedModule('at', 'at', 'at')


# Generated at 2022-06-23 22:59:20.693078
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test constructor of class SixMovesTransformer.
    """
    transformer = SixMovesTransformer(None)
    assert transformer._rewrites_map == collections.defaultdict(list)


# Generated at 2022-06-23 22:59:25.527149
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import six

    six_moves_module = sys.modules['six.moves']
    for _, module_name in _get_rewrites():
        assert hasattr(six_moves_module, module_name)

    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 22:59:29.858525
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') ==\
           MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')

# Unit testing for constructor of class MovedModule

# Generated at 2022-06-23 22:59:33.458773
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").__dict__ == {"name": "name", "old": "old", "new": "name"}
    assert MovedModule("name", "old", "new").__dict__ == {"name": "name", "old": "old", "new": "new"}


# Generated at 2022-06-23 22:59:43.104186
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule()
        assert False
    except TypeError:
        assert True
    m1 = MovedModule('name', 'old')
    assert m1.name == 'name'
    assert m1.old == 'old'
    assert m1.new == 'name'
    m2 = MovedModule('name', 'old', 'new')
    assert m1.name == 'name'
    assert m1.old == 'old'
    assert m1.new == 'new'
    m3 = MovedModule('name')
    assert m3.name == 'name'
    assert m3.old == 'name'
    assert m3.new == 'name'


# Generated at 2022-06-23 22:59:52.430072
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert (path, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer.rewrites
                
if __name__ == '__main__': 
    test_SixMovesTransformer()

# Generated at 2022-06-23 22:59:55.864697
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer.rewrites)[:3] == [('builtins.filter', 'six.moves.filter'), ('builtins.input', 'six.moves.input'), ('builtins.range', 'six.moves.range')]

# Generated at 2022-06-23 22:59:58.119050
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = list(_get_rewrites())
    actual_rewrites = SixMovesTransformer.rewrites
    assert actual_rewrites == rewrites

# Generated at 2022-06-23 23:00:02.000116
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule('test', 'test')
    assert test.name == 'test'
    assert test.new == 'test'

    test = MovedModule('test', 'test', 'test2')
    assert test.name == 'test'
    assert test.new == 'test2'

# Generated at 2022-06-23 23:00:03.051500
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str(SixMovesTransformer)

# Generated at 2022-06-23 23:00:04.520666
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("some_name", "some_old", "some_new")

    assert moved_module.name == "some_name"
    assert moved_module.new == "some_new"

# Generated at 2022-06-23 23:00:06.452526
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) == 106
    assert len(transformer.dependencies) == 1
    assert transformer.dependencies[0] == 'six'

# Generated at 2022-06-23 23:00:14.038615
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b", "c").new == "c"
    assert MovedModule("a", "b", "c").name == "a"

    assert MovedModule("a", "b").new == "a"
    assert MovedModule("a", "b").name == "a"

    assert MovedModule("a", "b", "c", "d").new == "c"
    assert MovedModule("a", "b", "c", "d").name == "a"

    with pytest.raises(TypeError):
        MovedModule("a", "b", c=4)

    with pytest.raises(TypeError):
        MovedModule("a", "b", "c", d=4)



# Generated at 2022-06-23 23:00:18.272823
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__', 'foo').new == 'foo'
    asser

# Generated at 2022-06-23 23:00:28.584608
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("myX", "myY", "myZ")
    assert x.name == "myX"
    assert x.new_mod == "myZ"
    assert x.new_attr == "myX"
    x = MovedAttribute("MovedAttribute", "MovedModule", "six.moves.MovedModule")
    assert x.name == "MovedAttribute"
    assert x.new_mod == "six.moves.MovedModule"
    assert x.new_attr == "MovedAttribute"
    x = MovedAttribute("MovedAttribute", "MovedModule", "six.moves.MovedModule", "six_attr")
    assert x.name == "MovedAttribute"
    assert x.new_mod == "six.moves.MovedModule"

# Generated at 2022-06-23 23:00:35.915570
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Test constructor of class MovedAttribute."""
    obj = MovedAttribute('foo', 'bar', 'baz')
    assert obj.name == 'foo'
    assert obj.new_mod == 'baz'
    assert obj.new_attr == 'foo'

    obj = MovedAttribute('foo', 'bar', 'baz', 'old')
    assert obj.name == 'foo'
    assert obj.new_mod == 'baz'
    assert obj.new_attr == 'old'

    obj = MovedAttribute('foo', 'bar', 'baz', 'old', 'new')
    assert obj.name == 'foo'
    assert obj.new_mod == 'baz'
    assert obj.new_attr == 'new'

    obj = MovedAttribute('foo', 'bar', None, 'old', 'new')
   

# Generated at 2022-06-23 23:00:41.910438
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from pprint import pprint # type: ignore
    from lib2to3 import refactor # type: ignore
    fixer = SixMovesTransformer(refactor)
    print("class SixMovesTransformer:")
    pprint(fixer.rewrites)
    rewrites = list(fixer.rewrites.keys())
    rewrites.sort()
    print("list(fixer.rewrites.keys()):")
    pprint(rewrites)

# Generated at 2022-06-23 23:00:50.470408
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert repr(MovedModule('abc', 'abc')) == "MovedModule('abc', 'abc')"
    assert repr(MovedModule('abc', 'xyz')) == "MovedModule('abc', 'xyz')"
    assert repr(MovedModule('abc', 'xyz', 'qwerty')) == "MovedModule('abc', 'xyz', 'qwerty')"
    assert repr(MovedModule('abc', 'abc', 'qwerty')) == "MovedModule('abc', 'abc', 'qwerty')"



# Generated at 2022-06-23 23:00:53.907551
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # success
    MovedModule("name", "old", "new")
    MovedModule("name", "old")
    MovedModule("name", "old", None)
    # failure
    try:
        MovedModule("name", "old", "new", None)
        assert False
    except:
        pass


# Generated at 2022-06-23 23:01:03.661189
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('abc', 'xyz', '123')
    assert m.name == 'abc'
    assert m.new_mod == '123'
    assert m.new_attr == 'abc'
    m = MovedAttribute('abc', 'xyz', '123', 'def')
    assert m.name == 'abc'
    assert m.new_mod == '123'
    assert m.new_attr == 'def'
    m = MovedAttribute('abc', 'xyz', '123', 'def', 'ghi')
    assert m.name == 'abc'
    assert m.new_mod == '123'
    assert m.new_attr == 'ghi'

# Generated at 2022-06-23 23:01:08.578609
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"


# Tests of class MovedAttribute

# Generated at 2022-06-23 23:01:19.544874
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test1.name == "cStringIO"
    assert test1.new_mod == "io"
    assert test1.new_attr == "StringIO"

    test2 = MovedAttribute("cStringIO", "cStringIO", "io", "String")
    assert test2.name == "cStringIO"
    assert test2.new_mod == "io"
    assert test2.new_attr == "String"

    test3 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert test3.name == "cStringIO"
    assert test3.new_mod == "io"
    assert test3.new_attr == "cStringIO"

# Generated at 2022-06-23 23:01:28.993765
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Call the constructor with name set to "math" and new set to "math", the
    # old parameter is None by default.  Get the value of old using the
    # get_old() method.
    obj = MovedModule("math", "math")
    assert obj.name == 'math'
    assert obj.new == 'math'
    assert obj.old is None

    # Call the constructor with name set to "_winreg" and new set to "winreg",
    # the old parameter is "_winreg" by default.  Get the value of new using
    # the get_new() method.
    obj = MovedModule("_winreg")
    assert obj.name == '_winreg'
    assert obj.new == 'winreg'
    assert obj.old == '_winreg'


# Generated at 2022-06-23 23:01:31.638563
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('foo', 'bar', 'baz')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'foo'



# Generated at 2022-06-23 23:01:42.933753
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # No new, new is just a name of the old attribute
    m = MovedAttribute("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    assert m.new_mod == m.new
    assert m.new_attr == "name"

    # new_attr, new_mod
    m = MovedAttribute("name", "old", "new_mod", "new_attr")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new_mod"
    assert m.new_mod == m.new
    assert m.new_attr == "new_attr"

    # old_attr, new_mod

# Generated at 2022-06-23 23:01:48.616694
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule('modulename')
    with pytest.raises(TypeError):
        MovedModule('modulename', 'modulename', 'oldname', 'newname')

    assert MovedModule('modulename', 'oldname') == MovedModule('modulename', 'oldname', 'modulename')
    assert MovedModule('modulename', 'oldname', 'newname') == MovedModule('modulename', 'oldname', 'newname')


# Generated at 2022-06-23 23:01:52.113211
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("queue", "Queue")
    assert mm.name == "queue"
    assert mm.new == "queue"
    assert mm.old == "Queue"
    mm = MovedModule("queue", "Queue", "queue")
    assert mm.name == "queue"
    assert mm.new == "queue"
    assert mm.old == "Queue"

# Generated at 2022-06-23 23:01:55.630190
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser", "cp").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "cp").new == "cp"
    assert MovedModule("configparser", "ConfigParser", "cp").old == "ConfigParser"


# Generated at 2022-06-23 23:02:00.183214
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    class_name = 'SixMovesTransformer'
    obj = SixMovesTransformer()
    assert(obj.target == (2, 7))
    assert(obj.rewrites == _get_rewrites())
    assert(obj.dependencies == ['six'])

# Generated at 2022-06-23 23:02:05.036401
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    class TestMovedAttribute(MovedAttribute):
        def __init__(self, *args):
            MovedAttribute.__init__(self, *args)

    m = TestMovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert m.name == "name"
    assert m.new_mod == "new"
    assert m.new_attr == "new_attr"

    m = TestMovedAttribute("name", "old", "new", "old_attr", None)
    assert m.name == "name"
    assert m.new_mod == "new"
    assert m.new_attr == "old_attr"

    m = TestMovedAttribute("name", "old", "new", None, None)
    assert m.name == "name"
    assert m.new_

# Generated at 2022-06-23 23:02:12.431401
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:16.306827
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('a', 'b')
    assert m.name == 'a'
    assert m.new == 'b'

    m = MovedModule('a', 'b', 'c')
    assert m.name == 'a'
    assert m.new == 'c'

# Generated at 2022-06-23 23:02:24.715112
# Unit test for constructor of class MovedModule
def test_MovedModule():
    one = MovedModule("builtins", "__builtin__")
    two = MovedModule("configparser", "ConfigParser")
    three = MovedModule("tkinter", "Tkinter")
    four = MovedModule("urllib_parse", __name__ + ".moves.urllib_parse", "urllib.parse")

    assert one.name == "builtins"
    assert one.new == "__builtin__"
    assert two.name == "configparser"
    assert two.new == "ConfigParser"
    assert three.name == "tkinter"
    assert three.new == "Tkinter"
    assert four.name == "urllib_parse"
    assert four.new == "urllib.parse"



# Generated at 2022-06-23 23:02:28.290167
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('test_module', 'test_old', 'test_new')
    assert module.name == 'test_module'
    assert module.old == 'test_old'
    assert module.new == 'test_new'


# Generated at 2022-06-23 23:02:33.399451
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod',
                          'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'



# Generated at 2022-06-23 23:02:44.781336
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').name == 'filter'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == 'builtins'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'

# Generated at 2022-06-23 23:02:46.263042
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'foo_old', 'foo_new').new == 'foo_new'
    assert MovedModule('foo', 'foo_old').new == 'foo'

# Generated at 2022-06-23 23:02:48.098913
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('foo', 'bar', 'baz')
    assert moved_module.name == 'foo'
    assert moved_module.old == 'bar'
    assert moved_module.new == 'baz'

# Generated at 2022-06-23 23:02:51.730250
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "StringIO"


# Generated at 2022-06-23 23:02:55.939532
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

    move = MovedAttribute("filter", "itertools", "builtins")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"

# Generated at 2022-06-23 23:02:59.661071
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "old")
    assert obj.name == "name"
    assert obj.new == "name"
    assert obj.old == "old"

    obj = MovedModule("name", "old", "new")
    assert obj.name == "name"
    assert obj.new == "new"
    assert obj.old == "old"

    obj = MovedModule("name", None, "new")
    assert obj.name == "name"
    assert obj.new == "new"
    assert obj.old == "name"



# Generated at 2022-06-23 23:03:04.902704
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("builtins", "__builtin__")
    assert a.name == "builtins"
    assert a.new == "builtins"

    b = MovedModule("builtins", "__builtin__", "__builtins__")
    assert b.name == "builtins"
    assert b.new == "__builtins__"

# Generated at 2022-06-23 23:03:08.094216
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    expected = ('six.moves.range', 'range')
    result = (SixMovesTransformer.rewrites[3][0], SixMovesTransformer.rewrites[3][1][15:])
    assert expected == result

# Generated at 2022-06-23 23:03:13.644024
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    m = SixMovesTransformer()
    # assert that SixMovesTransformer.rewrites is a generator
    assert not isinstance(m.rewrites, list)
    # assert that all rewrites are valid
    for new, old in m.rewrites:
        p1, p2 = new.split('.'), old.split('.')
        m1 = __import__(p1[0])
        for x in p1[1:]:
            m1 = getattr(m1, x)
        m2 = __import__(p2[0])
        for x in p2[1:]:
            m2 = getattr(m2, x)
        assert m1 is m2

# Generated at 2022-06-23 23:03:16.169532
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Direct call to constructor is not allowed
    with pytest.raises(NameError):
        SixMovesTransformer()

# Generated at 2022-06-23 23:03:18.555937
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("queue", "Queue")
    assert mod.name == "queue"
    assert mod.new == "Queue"


# Generated at 2022-06-23 23:03:22.033370
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert hasattr(t, 'target')
    assert hasattr(t, 'rewrites')
    assert hasattr(t, 'dependencies')


# Generated at 2022-06-23 23:03:31.613922
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("aaaa", "bbbb") == MovedModule("aaaa", "bbbb")
    assert MovedModule("aaaa", "bbbb") != MovedModule("aaaa", "bbbb", "cccc")
    assert MovedModule("aaaa", "bbbb") != MovedModule("aaaa", "dddd")
    assert MovedModule("aaaa", "bbbb") != MovedModule("eeee", "bbbb")
    assert MovedModule("aaaa", "bbbb") != MovedModule("aaaa", "bbbb", "eeee")
    assert MovedModule("aaaa", "bbbb") != MovedModule("aaaa", "dddd", "eeee")
    assert MovedModule("aaaa", "bbbb") != MovedModule("eeee", "bbbb", "eeee")

# Generated at 2022-06-23 23:03:33.902945
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sys.version_info = (2, 7)
    # add six to sys.modules
    import six
    sys.modules['six'] = six

    importer = SixMovesTransformer()

# Generated at 2022-06-23 23:03:45.666263
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    out = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert out.name == "name"
    assert out.new_mod == "new_mod"
    assert out.new_attr == "new_attr"
    out = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert out.name == "name"
    assert out.new_mod == "new_mod"
    assert out.new_attr == "old_attr"
    out = MovedAttribute("name", "old_mod", "new_mod")
    assert out.name == "name"
    assert out.new_mod == "new_mod"
    assert out.new_attr == "name"

# Generated at 2022-06-23 23:03:46.775309
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("name", "old", "new")

# Generated at 2022-06-23 23:03:49.779692
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'StringIO'


# Generated at 2022-06-23 23:03:56.892780
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_1 = MovedModule("builtins", "__builtin__")
    assert moved_module_1.name == "builtins"
    assert moved_module_1.old == "__builtin__"
    assert moved_module_1.new == "builtins"

    moved_module_2 = MovedModule("copyreg", "copy_reg")
    assert moved_module_2.name == "copyreg"
    assert moved_module_2.old == "copy_reg"
    assert moved_module_2.new == "copyreg"

    moved_module_3 = MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert moved_module_3.name == "dbm_gnu"
    assert moved_module_3.old == "gdbm"
    assert moved_

# Generated at 2022-06-23 23:04:03.529601
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('tkinter', 'Tkinter').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter').new == 'tkinter'


# Generated at 2022-06-23 23:04:07.351067
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('test', 'original', 'new')
    assert attr.name == 'test'
    assert attr.new_mod == 'new'
    assert attr.new_attr == 'test'

    attr = MovedAttribute('test', 'original', 'new', 'old_name', 'new_name')
    assert attr.name == 'test'
    assert attr.new_mod == 'new'
    assert attr.new_attr == 'new_name'

# Generated at 2022-06-23 23:04:17.479105
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    try:
        import six
    except ImportError:
        e = sys.exc_info()[1]
        pytest.skip('could not import six: %s' % (e,))

    # check if six.moves is really available
    try:
        six.moves
    except AttributeError:
        e = sys.exc_info()[1]
        pytest.skip('six.moves is not available: %s' % (e,))

    # check if all rewrites available
    for module_name in six.moves.__all__:
        assert module_name in six.moves.__dict__, module_name

# Generated at 2022-06-23 23:04:22.168805
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-23 23:04:23.884365
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .moves.urllib_parse import quote
    from .moves.urllib_error import URLError

    assert quote
    assert URLError

# Generated at 2022-06-23 23:04:27.658904
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("foo", "a", "b", "c", "d")
    assert attribute.name == "foo"
    assert attribute.new_mod == "b"
    assert attribute.new_attr == "d"


# Generated at 2022-06-23 23:04:34.203838
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').__dict__ == {'name': 'builtins', 'old': '__builtin__', 'new': 'builtins'}
    assert MovedModule('configparser', 'ConfigParser').__dict__ == {'name': 'configparser', 'old': 'ConfigParser', 'new': 'configparser'}
    assert MovedModule('copyreg', 'copy_reg').__dict__ == {'name': 'copyreg', 'old': 'copy_reg', 'new': 'copyreg'}
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu').__dict__ == {'name': 'dbm_gnu', 'old': 'gdbm', 'new': 'dbm.gnu'}

# Generated at 2022-06-23 23:04:36.129063
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute(name='foo', old_mod='bar', new_mod='baz')
    assert attr.name == 'foo'
    assert attr.new_mod == 'baz'
    assert attr.new_attr == 'foo'

# Generated at 2022-06-23 23:04:38.042973
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer().rewrites



# Generated at 2022-06-23 23:04:43.945348
# Unit test for constructor of class MovedModule
def test_MovedModule():
    def test_a():
        assert MovedModule('name', 'old').name == 'name'
        assert MovedModule('name', 'old').new == 'name'
        assert MovedModule('name', 'old', 'new').name == 'name'
        assert MovedModule('name', 'old', 'new').new == 'new'
    test_a()



# Generated at 2022-06-23 23:04:48.662723
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = _moved_attributes[0]
    assert item.name == "cStringIO"
    assert item.old_mod == "cStringIO"
    assert item.new_mod == "io"
    assert item.old_attr == "StringIO"
    assert item.new_attr == "StringIO"


# Generated at 2022-06-23 23:04:59.020041
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():  # pylint: disable=unused-variable,redefined-outer-name,invalid-name
    move = MovedAttribute(name='name',
                          old_mod='old_mod',
                          new_mod='new_mod',
                          old_attr='old_attr',
                          new_attr='new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'
    #
    move = MovedAttribute(name='name', old_mod='old_mod')
    assert move.name == 'name'
    assert move.new_mod == 'name'
    assert move.new_attr == 'name'
    #

# Generated at 2022-06-23 23:05:06.546557
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('a', 'b', 'c').name == 'a'
    assert MovedModule('a', 'b', 'c').old == 'b'
    assert MovedModule('a', 'b', 'c').new == 'c'
    assert MovedModule('a', 'b').name == 'a'
    assert MovedModule('a', 'b').old == 'b'
    assert MovedModule('a', 'b').new == 'a'
    assert MovedModule('a').name == 'a'
    assert MovedModule('a').old == 'a'
    assert MovedModule('a').new == 'a'
    assert MovedModule(name='a', old='b', new='c').name == 'a'

# Generated at 2022-06-23 23:05:08.334164
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for class SixMovesTransformer
    """
    transformer = SixMovesTransformer()
    assert transformer

# Generated at 2022-06-23 23:05:10.164500
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(2, 7)
    assert len(t.rewrites) > 0


# Generated at 2022-06-23 23:05:17.190877
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"


# Generated at 2022-06-23 23:05:22.044100
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'oldmod', 'newmod', 'oldatt', 'newatt').name == 'name'
    assert MovedAttribute(None, 'oldmod', 'newmod', None, None).name == None


# Generated at 2022-06-23 23:05:32.172869
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:37.717379
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

# Generated at 2022-06-23 23:05:40.449962
# Unit test for constructor of class MovedModule
def test_MovedModule():
    M = MovedModule("name", "old", "new")
    assert M.name == "name"
    assert M.new == "new"


# Generated at 2022-06-23 23:05:42.982758
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("UserString", "UserString", "collections")
    assert mm.name == mm.new == "UserString"

# Generated at 2022-06-23 23:05:49.382859
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys

    if sys.version_info[:2] != (2, 7):
        return
    else:
        print("Running SixMovesTransformer unit tests")

    _test_private_methods(SixMovesTransformer)
    _test_futures_import_rewrite(SixMovesTransformer, _get_rewrites())

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:05:53.226224
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("builtins", "__builtin__")
    assert m.name == "builtins"
    assert m.new == "builtins"
    assert m.old == "__builtin__"


# Generated at 2022-06-23 23:05:56.402820
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        import six
    except ImportError:
        pytest.skip("Six not installed.")
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']


# Generated at 2022-06-23 23:06:00.298695
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # type: () -> None
    """Unit test for constructor of class SixMovesTransformer."""
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:06.449376
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old', 'new')
    assert move.name == 'name'
    assert move.new_mod == 'new'
    assert move.new_attr == 'name'
    move2 = MovedAttribute('name', 'old', 'new', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new'
    assert move.new_attr == 'new_attr'


# Generated at 2022-06-23 23:06:09.312669
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.target == (2, 7)
    assert 'six.moves' in st.dependencies
    assert st.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:12.982427
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"



# Generated at 2022-06-23 23:06:15.709445
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.target == (2, 7)
    assert st.rewrites == _get_rewrites()
    assert st.dependencies == ['six']


# Generated at 2022-06-23 23:06:24.958167
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old').new == 'name'

# Generated at 2022-06-23 23:06:26.447078
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=unused-variable
    _ = SixMovesTransformer

# Generated at 2022-06-23 23:06:36.870195
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('mod', 'oldmod', 'newmod', 'oldattr', 'newattr')
    assert attr.name == 'mod'
    assert attr.new_mod == 'newmod'
    assert attr.new_attr == 'newattr'
    attr = MovedAttribute('mod', 'oldmod', 'newmod', 'oldattr')
    assert attr.name == 'mod'
    assert attr.new_mod == 'newmod'
    assert attr.new_attr == 'oldattr'
    attr = MovedAttribute('mod', 'oldmod', 'newmod')
    assert attr.name == 'mod'
    assert attr.new_mod == 'newmod'
    assert attr.new_attr == 'mod'
    attr = MovedAttribute('mod', 'oldmod')

# Generated at 2022-06-23 23:06:46.953491
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("dummy name", "dummy old_mod", "dummy new_mod",
                        "dummy old_attr", "dummy new_attr")
    assert ma.name == "dummy name"
    assert ma.new_mod == "dummy new_mod"
    assert ma.new_attr == "dummy new_attr"

    ma = MovedAttribute("dummy name", "dummy old_mod", "dummy new_mod",
                        "dummy old_attr")
    assert ma.name == "dummy name"
    assert ma.new_mod == "dummy new_mod"
    assert ma.new_attr == "dummy old_attr"

    ma = MovedAttribute("dummy name", "dummy old_mod", "dummy new_mod")

# Generated at 2022-06-23 23:06:49.194044
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute()



# Generated at 2022-06-23 23:06:58.408041
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
   

# Generated at 2022-06-23 23:07:03.063122
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) >= 20
    assert len(SixMovesTransformer.dependencies) == 1
    for path, new_path in SixMovesTransformer.rewrites:
        assert isinstance(path, str)
        assert isinstance(new_path, str)

# Generated at 2022-06-23 23:07:10.632318
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name', "name"
    assert MovedModule('name', 'old').old == 'old', "old"
    assert MovedModule('name', 'old').new == 'name', "new"
    assert MovedModule('name', 'old', 'new').new == 'new', "new(specified)"
    # all the attributes are public, therefore no exception is raised


# Generated at 2022-06-23 23:07:17.741348
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new_module = MovedModule("random", "random")
    assert new_module.name == "random"
    assert new_module.new == "random"

    new_module = MovedModule("random", "ran", "random")
    assert new_module.name == "random"
    assert new_module.new == "random"

    new_module = MovedModule("random", "ran", "random")
    assert new_module.name == "random"
    assert new_module.new == "random"


# Generated at 2022-06-23 23:07:23.916370
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert(m.name == "name")
    assert(m.old == "old")
    assert(m.new == "new")
    m = MovedModule("name", "old")
    assert(m.name == "name")
    assert(m.old == "old")
    assert(m.new == "name")
    # raises no exception
    MovedModule("name", "old", "new")
    # raises no exception
    MovedModule("name", "old")


# Generated at 2022-06-23 23:07:30.660682
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"


# Generated at 2022-06-23 23:07:37.507096
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:07:42.784267
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("name1", "old1", "new1")
    assert x.name == "name1"
    assert x.new == "new1"

    y = MovedModule("name2", "old2")
    assert y.name == "name2"
    assert y.new == "name2"

# Generated at 2022-06-23 23:07:44.159792
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    No unit tests
    """
    pass

# Generated at 2022-06-23 23:07:47.435304
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 23:07:50.503043
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"



# Generated at 2022-06-23 23:08:00.180827
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    print(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"))
    print(MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter"))
    print(MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse"))
    print(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input"))
    print(MovedAttribute("intern", "__builtin__", "sys"))
    print(MovedAttribute("map", "itertools", "builtins", "imap", "map"))
    print(MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd"))

# Generated at 2022-06-23 23:08:11.354351
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:14.676639
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("mod_a", "mod_b")
    assert mm.name == "mod_a"
    assert mm.new == "mod_a"

    mm = MovedModule("mod_a", "mod_b", "mod_c")
    assert mm.name == "mod_a"
    assert mm.new == "mod_c"



# Generated at 2022-06-23 23:08:20.628955
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # test case for the constructor of MovedModule class
    data = MovedModule('name1', 'old1', 'new1')
    # check the attributes for the instance of the class
    assert data.name == 'name1'
    assert data.old == 'old1'
    assert data.new == 'new1'
    data = MovedModule('name2','old2')
    # check the attributes for the instance of the class
    assert data.name == 'name2'
    assert data.old == 'old2'
    assert data.new == 'name2'
    assert isinstance(data, MovedModule)
    assert repr(data) == 'MovedModule(name=name2, old=old2, new=name2)'


# Generated at 2022-06-23 23:08:26.111961
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert isinstance(transformer, BaseImportRewrite)
    assert isinstance(transformer.rewrites, list)
    assert transformer.dependencies == ['six']
    assert transformer.__doc__ == "Replaces moved modules with ones from `six.moves`."



# Generated at 2022-06-23 23:08:27.263907
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old", "name")

# Generated at 2022-06-23 23:08:32.503623
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert path in SixMovesTransformer.rewrites


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:08:35.417452
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("foo", "bar", "baz")
    assert move.name == "foo"
    assert move.new == "baz"


# Generated at 2022-06-23 23:08:40.630356
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('a', 'b', 'c')
    assert a.name == 'a'
    assert a.old == 'b'
    assert a.new == 'c'

    b = MovedModule('a', 'b')
    assert b.name == 'a'
    assert b.old == 'b'
    assert b.new == 'a'

# Generated at 2022-06-23 23:08:44.506328
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mod = MovedAttribute('name', 'old_mod', 'new_mod')
    assert mod.name == 'name'
    assert mod.new_mod == 'new_mod'
    assert mod.new_attr == 'name'



# Generated at 2022-06-23 23:08:49.825211
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old')
    assert module.name == 'name'
    assert module.old == 'old'
    assert module.new == 'name'

    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.old == 'old'
    assert module.new == 'new'

# Generated at 2022-06-23 23:08:54.768183
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"



# Generated at 2022-06-23 23:09:05.385967
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # noqa
    import six.moves
    from .base import BaseImportRewrite

    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    assert isinstance(SixMovesTransformer, type)
    assert SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert SixMovesTransformer.__doc__.strip() == SixMovesTransformer.__init__.__doc__.strip()
    assert SixMovesTransformer.target == (2, 7)

    def test_rewrites():
        for prefix, moves in prefixed_moves:
            for move in moves:
                if isinstance(move, MovedAttribute):
                    path = '{}.{}'.format(move.new_mod, move.new_attr)

# Generated at 2022-06-23 23:09:09.268814
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("test", "old", "new")
    assert attr.name == "test"
    assert attr.new_mod == "new"
    assert attr.new_attr == "test"


# Generated at 2022-06-23 23:09:16.552872
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("foo", "oldmod", "newmod")
    assert attr.name == "foo"
    assert attr.new_mod == "newmod"
    assert attr.new_attr == "foo"

    attr = MovedAttribute("foo", "oldmod", "newmod", "oldattr")
    assert attr.name == "foo"
    assert attr.new_mod == "newmod"
    assert attr.new_attr == "oldattr"
