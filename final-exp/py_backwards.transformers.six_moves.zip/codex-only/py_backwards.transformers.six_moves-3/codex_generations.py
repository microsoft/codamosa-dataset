

# Generated at 2022-06-23 22:59:12.791056
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute("StringIO", "StringIO", "io")
    assert moved_attr.name == "StringIO"
    assert moved_attr.new_mod == "io"
    assert moved_attr.new_attr == "StringIO"

# Generated at 2022-06-23 22:59:21.088445
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=unused-variable
    # pylint: disable=invalid-name
    MovedModule_name = "foo"
    MovedModule_old = "bar"
    MovedModule_new = "baz"
    MovedModule_3arguments = MovedModule(MovedModule_name, MovedModule_old, MovedModule_new)
    MovedModule_2arguments = MovedModule(MovedModule_name, MovedModule_old)
    MovedModule_1argument = MovedModule(MovedModule_name)
    # pylint: enable=unused-variable
    # pylint: enable=invalid-name

# Generated at 2022-06-23 22:59:28.922205
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # test1: object has three attributes: name, old, new
    move1 = MovedModule('move1', 'old1')
    assert move1.name == 'move1'
    assert move1.old == 'old1'
    assert move1.new == 'move1'
    # test2: object has three attributes: name, old, new
    move2 = MovedModule('move2', 'old2', 'new2')
    assert move2.name == 'move2'
    assert move2.old == 'old2'
    assert move2.new == 'new2'


# Generated at 2022-06-23 22:59:32.205565
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Simple test of SixMovesTransformer constructor."""
    # pylint: disable=protected-access
    _get_rewrites()
    _moved_attributes[0]
    assert True  # did not crash


# Generated at 2022-06-23 22:59:35.726547
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'

# Generated at 2022-06-23 22:59:44.112549
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import _test_generic_import_transformer
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.target == (2, 7)
    assert len(six_moves_transformer.rewrites) == 57
    assert len(six_moves_transformer.dependencies) == 1
    assert six_moves_transformer.dependencies[0] == 'six'
    _test_generic_import_transformer.check_import_rewrite(six_moves_transformer, _get_rewrites())

# Generated at 2022-06-23 22:59:49.386946
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('a', 'b')
    assert move.name == 'a'
    assert move.old == 'b'
    assert move.new == move.name == 'a'

    move = MovedModule('a', 'b', 'c')
    assert move.name == 'a'
    assert move.old == 'b'
    assert move.new == 'c'

# Generated at 2022-06-23 22:59:53.326505
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for test_name, test_val in _get_rewrites():
        assert test_name in SixMovesTransformer.rewrites
        assert test_val in SixMovesTransformer.rewrites.values()
    assert 'six' in SixMovesTransformer.dependencies

# Generated at 2022-06-23 22:59:57.966728
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-23 23:00:01.860370
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"



# Generated at 2022-06-23 23:00:10.535122
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # cStringIO, cStringIO, io, StringIO
    t = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert t.name == "cStringIO"
    assert t.new_mod == "io"
    assert t.new_attr == "StringIO"

    # filter, itertools, builtins, ifilter, filter
    t = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert t.name == "filter"
    assert t.new_mod == "builtins"
    assert t.new_attr == "filter"

    # filterfalse, itertools, itertools, ifilterfalse, filterfalse

# Generated at 2022-06-23 23:00:20.234502
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name","old_mod","new_mod")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "name"

    obj = MovedAttribute("name","old_mod","new_mod","old_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "old_attr"
    
    obj = MovedAttribute("name","old_mod","new_mod","old_attr","new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"


# Generated at 2022-06-23 23:00:26.127699
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("Test", "Test_old").__dict__ == {'name': "Test", 'old': "Test_old", 'new': "Test"}
    assert MovedModule("Test2", "Test2_old", "Test2_new").__dict__ == {'name': "Test2", 'old': "Test2_old", 'new': "Test2_new"}


# Generated at 2022-06-23 23:00:33.138712
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo", "bar", "baz", "qux", "quux").name == "foo"
    assert MovedAttribute("foo", "bar", "baz", "qux", "quux").new_mod == "baz"
    assert MovedAttribute("foo", "bar", "baz", "qux", "quux").new_attr == "quux"
    assert MovedAttribute("foo", "bar", "baz").new_attr == "foo"
    assert MovedAttribute("foo", "bar", "baz", "qux").new_attr == "qux"

# Generated at 2022-06-23 23:00:42.814368
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', None, 'old_attr', 'new_attr').new_mod == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', None, None).new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', None).new

# Generated at 2022-06-23 23:00:45.468879
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('mymodule','mymodule','mymodule_new')
    assert obj.name == 'mymodule' and obj.new == 'mymodule_new'


# Generated at 2022-06-23 23:00:47.368472
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()


# Generated at 2022-06-23 23:00:58.890344
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:02.994312
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert(move.name == "cStringIO")
    assert(move.new_mod == "io")
    assert(move.new_attr == "StringIO")


# Generated at 2022-06-23 23:01:08.980477
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_obj = MovedAttribute("name", "old_mod", "new_mod")
    assert test_obj.name == 'name'
    assert test_obj.new_mod == 'new_mod'
    assert test_obj.new_attr == 'name'
    try:
        test_obj = MovedAttribute("name", "old_mod")
    except TypeError:
        pass
    else:
        assert False, "should raise TypeError"



# Generated at 2022-06-23 23:01:19.977279
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'
    move = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert move.name == 'filter'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'filter'
    move = MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    assert move.name == 'filterfalse'
    assert move.new_mod == 'itertools'
    assert move.new_attr == 'filterfalse'

# Generated at 2022-06-23 23:01:29.359766
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # This is a very basic test. It is not intended to be an extensive test.
    import unittest
    import astroid

    class TestSixMovesTransformer(unittest.TestCase):
        def setUp(self):
            self.t = SixMovesTransformer()
            self.module = astroid.parse(r"""
                import ConfigParser
                import Tix

                def read_config_file(config_file_name):
                    config_parser = ConfigParser.ConfigParser()
                    config_parser.read(config_file_name)
                    return config_parser

                def get_pil_image(image_file_name):
                    from PIL import Image
                    image = Image.open(image_file_name)
                    return image
                """)

        def test_transform_moved_modules(self):
            config

# Generated at 2022-06-23 23:01:40.469411
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    # It seems that 'itertools' is not rewritten to 'six.moves.itertools'
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").name == "input"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_mod == "builtins"

# Generated at 2022-06-23 23:01:48.461176
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-23 23:01:51.284606
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    testmove = MovedAttribute("test", "test1", "test2", "test3", "test4")
    assert testmove.name == "test"
    assert testmove.new_mod == "test2"
    assert testmove.new_attr == "test4"


# Generated at 2022-06-23 23:01:56.338230
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', None)
    MovedAttribute('name', 'old_mod', 'new_mod', None, 'new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', None, None)
    MovedAttribute('name', 'old_mod', None, None, None)



# Generated at 2022-06-23 23:02:07.329078
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:02:17.860398
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test1 = MovedModule("module1", "module2", "module3")
    assert test1.name == "module1", \
        "Constructor of MovedModule: test1 failed"
    assert test1.old == "module2", \
        "Constructor of MovedModule: test2 failed"
    assert test1.new == "module3", \
        "Constructor of MovedModule: test3 failed"

    test2 = MovedModule("module1", "module2")
    assert test2.name == "module1", \
        "Constructor of MovedModule: test4 failed"
    assert test2.old == "module2", \
        "Constructor of MovedModule: test5 failed"
    assert test2.new == "module1", \
        "Constructor of MovedModule: test6 failed"




# Generated at 2022-06-23 23:02:23.258296
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a = MovedAttribute("cStringIO", "cStringIO", "io")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "cStringIO"

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-23 23:02:24.294065
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for _ in SixMovesTransformer._get_rewrites():
        pass

# Generated at 2022-06-23 23:02:25.033511
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()

# Generated at 2022-06-23 23:02:36.438402
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Check that all the modules are imported properly
    module_name = 'urllib.parse'
    mod = __import__(module_name, globals(), locals(),
                     [], 0)
    assert mod.quote == urllib_parse.quote
    assert mod.quote_plus == urllib_parse.quote_plus
    assert mod.unquote == urllib_parse.unquote
    assert mod.unquote_plus == urllib_parse.unquote_plus
    assert mod.unquote_to_bytes == urllib_parse.unquote_to_bytes
    assert mod.urlencode == urllib_parse.urlencode
    assert mod.splitquery == urllib_parse.splitquery
    assert mod.splittag == urllib_parse.splittag
    assert mod.splituser == ur

# Generated at 2022-06-23 23:02:43.649445
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"


# Generated at 2022-06-23 23:02:50.599432
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=invalid-name
    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'new'

    obj = MovedModule('name', 'old')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'name'

    # pylint: enable=invalid-name


# Generated at 2022-06-23 23:02:55.664348
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert x.name == "cStringIO"
    assert x.new_mod == "io"
    assert x.new_attr == "StringIO"
    assert x.name == "cStringIO"
    x = MovedAttribute("cStringIO", "cStringIO", "io")
    assert x.name == "cStringIO"
    assert x.new_mod == "io"
    assert x.new_attr == "cStringIO"


# Generated at 2022-06-23 23:03:07.699081
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:03:12.246746
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys

    sys.modules['six'] = None
    from lib2to3.fixes.fix_six_moves import SixMovesTransformer
    t = SixMovesTransformer(None)
    assert t.check_deps() is False
    sys.modules['six'] = lambda: None
    assert t.check_deps() is True

# Generated at 2022-06-23 23:03:14.504038
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("Test", "test.modul", "test.modul")
    assert isinstance(obj, MovedAttribute)
    assert obj.name == "Test"


# Generated at 2022-06-23 23:03:20.527366
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"


# Generated at 2022-06-23 23:03:24.882045
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('foo', 'foo')
    assert m.name == m.new == 'foo'

    m = MovedModule('foo', 'foo', 'bar')
    assert m.name == 'foo'
    assert m.new == 'bar'



# Generated at 2022-06-23 23:03:26.011241
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert not list(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:03:27.505119
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert instance.rewrites == _get_rewrites()
    assert instance.dependencies == ['six']


# Generated at 2022-06-23 23:03:30.055324
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'


# Generated at 2022-06-23 23:03:30.989726
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for path, replacement in _get_rewrites():
        assert path and replacement

# Generated at 2022-06-23 23:03:32.477569
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 23:03:35.517169
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert movedattribute.name == "cStringIO"
    assert movedattribute.new_mod == "io"
    assert movedattribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:38.720113
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("name", "old", "new")
    assert move.name == "name"
    assert move.old == "old"
    assert move.new == "new"

# Generated at 2022-06-23 23:03:40.991366
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')


# Generated at 2022-06-23 23:03:49.595690
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import _six_moves
    transformer = SixMovesTransformer()
    expected_rewrites = set()
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                expected_rewrites.add(('{}.{}'.format(move.new_mod, move.new_attr), 'six.moves{}.{}'.format(prefix, move.name)))
            elif isinstance(move, MovedModule):
                expected_rewrites.add((move.new, 'six.moves{}.{}'.format(prefix, move.name)))

    assert transformer.rewrites == expected_rewrites

# Generated at 2022-06-23 23:03:51.260930
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("test", "test1", "test2")
    assert test.name == "test"
    assert test.new == "test2"


# Generated at 2022-06-23 23:03:54.379438
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute('test', 'old', 'new')
    assert item.name == 'test'
    assert item.new_mod == 'new'
    assert item.new_attr == 'test'


# Generated at 2022-06-23 23:03:57.012881
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.new == 'new'


# Generated at 2022-06-23 23:04:01.189830
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _moved_attributes[-1].name
    del _moved_attributes[-1]
    global _get_rewrites
    _get_rewrites = _get_rewrites()
    assert len(SixMovesTransformer.rewrites) == len(set(SixMovesTransformer.rewrites))

# Generated at 2022-06-23 23:04:04.776610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'StringIO'

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-23 23:04:07.785046
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()



# Generated at 2022-06-23 23:04:18.935182
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item1 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert item1.name == 'cStringIO'
    assert item1.new_mod == 'io'
    assert item1.old_attr == 'StringIO'
    assert item1.new_attr == 'StringIO'

    item2 = MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map')
    assert item2.name == 'map'
    assert item2.new_mod == 'builtins'
    assert item2.old_attr == 'imap'
    assert item2.new_attr == 'map'

    item3 = MovedAttribute('intern', '__builtin__', 'sys')
    assert item3.name == 'intern'

# Generated at 2022-06-23 23:04:28.173904
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('socket', 'socket').name == 'socket'
    assert MovedModule('socket', 'socket').new == 'socket'
    assert MovedModule('socket', '_socket', 'socket').name == 'socket'
    assert MovedModule('socket', '_socket', 'socket').new == 'socket'
    assert MovedModule('socket', 'socket', '_socket').name == 'socket'
    assert MovedModule('socket', 'socket', '_socket').new == '_socket'
    assert MovedModule('socket', '_socket').name == 'socket'
    assert MovedModule('socket', '_socket').new == '_socket'


# Generated at 2022-06-23 23:04:38.225160
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:04:42.750014
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('name', 'mod_old', 'mod_new', 'old_attr', 'new_attr')
    assert obj.name == 'name'
    assert obj.new_mod == 'mod_new'
    assert obj.new_attr == 'new_attr'



# Generated at 2022-06-23 23:04:43.997758
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer is not None

# Generated at 2022-06-23 23:04:46.442633
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sut = SixMovesTransformer(None)
    assert sut.rewrites == _get_rewrites()



# Generated at 2022-06-23 23:04:54.475053
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('test', '', None, None, None)
    assert isinstance(a, MovedAttribute)
    assert a.name == 'test'
    assert a.new_mod == 'test'
    assert a.new_attr == 'test'

    b = MovedAttribute('test', '', None, 'old')
    assert b.name == 'test'
    assert b.new_mod == 'test'
    assert b.new_attr == 'old'

    c = MovedAttribute('test', '', None, 'old', 'new')
    assert c.name == 'test'
    assert c.new_mod == 'test'
    assert c.new_attr == 'new'

    d = MovedAttribute('test', 'a', 'b', None, None)
    assert d.name == 'test'


# Generated at 2022-06-23 23:04:57.926115
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    item = SixMovesTransformer()
    assert item.target == (2, 7)
    assert item.rewrites == _get_rewrites()
    assert item.dependencies == ['six']

# Generated at 2022-06-23 23:05:05.917443
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    res = dict(_get_rewrites())

# Generated at 2022-06-23 23:05:15.747418
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:23.737752
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 23:05:33.068844
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'
    assert MovedAttribute('a', 'b', 'c').name == 'a'
    assert MovedAttribute('a', 'b', 'c').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c').new_attr == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd').new_mod == 'c'
    assert MovedAttribute

# Generated at 2022-06-23 23:05:38.291351
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes + _urllib_parse_moved_attributes + _urllib_error_moved_attributes + _urllib_request_moved_attributes + _urllib_response_moved_attributes) == len(_get_rewrites())

# Generated at 2022-06-23 23:05:42.874960
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    asserter = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert asserter.name == "name"
    assert asserter.new_mod == "new_mod"
    assert asserter.new_attr == "new_attr"


# Generated at 2022-06-23 23:05:44.470149
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer())
    # Should not raise Exception
    pass

# Generated at 2022-06-23 23:05:45.878904
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:05:51.101531
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_1 = MovedModule('builtins', '__builtin__')
    moved_module_2 = MovedModule('copyreg', 'copy_reg', 'copyreg')
    moved_module_3 = MovedModule('queue', 'Queue')

    assert moved_module_1.name == 'builtins'
    assert moved_module_1.new == 'builtins'

    assert moved_module_2.name == 'copyreg'
    assert moved_module_2.new == 'copyreg'

    assert moved_module_3.name == 'queue'
    assert moved_module_3.new == 'Queue'


# Generated at 2022-06-23 23:05:55.342110
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for modules in prefixed_moves:
        for move in modules[1]:
            if isinstance(move, MovedAttribute):
                MovedAttribute(move.name, move.old_mod, move.new_mod, move.old_attr, move.new_attr)

# Generated at 2022-06-23 23:06:06.549847
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:11.681254
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"


# Generated at 2022-06-23 23:06:23.551777
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:34.397832
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute_case1 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    test_MovedAttribute_case2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    test_MovedAttribute_case3 = MovedAttribute("name", "old_mod", "new_mod")
    assert test_MovedAttribute_case1.name == "name"
    assert test_MovedAttribute_case1.new_mod == "new_mod"
    assert test_MovedAttribute_case1.new_attr == "new_attr"
    assert test_MovedAttribute_case2.name == "name"
    assert test_MovedAttribute_case2.new_mod == "new_mod"
    assert test_Moved

# Generated at 2022-06-23 23:06:45.270779
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    assert len(SixMovesTransformer.rewrites) == 48
    rewrites = set(SixMovesTransformer.rewrites)

    # Testing `itertools.ifilter` and `itertools.ifilterfalse`
    assert ('itertools.ifilter', 'six.moves.filter') in rewrites
    assert ('itertools.ifilterfalse', 'six.moves.filterfalse') in rewrites

    # Testing `builtins.xrange`
    assert ('builtins.xrange', 'six.moves.range') in rewrites

    # Testing `_winreg`
    assert ('_winreg', 'six.moves.winreg') in rewrites

    # Testing `email.MIMEBase`

# Generated at 2022-06-23 23:06:54.577629
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer({})
    assert transformer.dependencies == ['six']
    assert len(transformer.rewrites) == 71
    assert transformer.rewrites[0] == ('builtins.filter', 'six.moves.filter')
    assert transformer.rewrites[1] == ('builtins.input', 'six.moves.input')
    assert transformer.rewrites[2] == ('builtins.map', 'six.moves.map')
    assert transformer.rewrites[3] == ('builtins.range', 'six.moves.range')
    assert transformer.rewrites[4] == ('builtins.zip', 'six.moves.zip')

# Generated at 2022-06-23 23:06:57.042438
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule("name", "old")
    assert test_moved_module.name == "name"
    assert test_moved_module.new == "name"


# Generated at 2022-06-23 23:07:00.464481
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("new_mod", "old_mod", "old_attr", "new_attr")
    assert attr.old_mod == "old_mod"
    assert attr.new_mod == "new_mod"
    assert attr.old_attr == "old_attr"
    assert attr.new_attr == "new_attr"


# Generated at 2022-06-23 23:07:11.211311
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute('a', 'x', 'y', 'z')
    assert x.name == 'a'
    assert x.new_mod == 'y'
    assert x.new_attr == 'z'

    x = MovedAttribute('a', 'x', 'y', 'z', 'p')
    assert x.name == 'a'
    assert x.new_mod == 'y'
    assert x.new_attr == 'p'

    x = MovedAttribute('a', 'x', 'y', new_attr='p')
    assert x.name == 'a'
    assert x.new_mod == 'y'
    assert x.new_attr == 'p'

# Generated at 2022-06-23 23:07:14.980804
# Unit test for constructor of class MovedModule
def test_MovedModule():
    attr = MovedModule('name', 'old', 'new')
    assert attr.name == 'name'
    assert attr.new == 'new'
    attr2 = MovedModule('name', 'old')
    assert attr2.name == 'name'
    assert attr2.new == 'old'



# Generated at 2022-06-23 23:07:18.518794
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from_mod = 'foo'
    to_mod = 'bar'
    m = MovedModule(from_mod, from_mod, to_mod)
    assert m.name == from_mod
    assert m.new == to_mod

# Generated at 2022-06-23 23:07:29.123073
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c1 = MovedAttribute("attr", "old_mod", "new_mod")
    assert c1.name == "attr"
    assert c1.old_mod is None
    assert c1.new_mod == "new_mod"
    assert c1.old_attr is None
    assert c1.new_attr == "attr"
    c2 = MovedAttribute("attr", "old_mod", "new_mod", "old_attr", "new_attr")
    assert c2.name == "attr"
    assert c2.old_mod is None
    assert c2.new_mod == "new_mod"
    assert c2.old_attr is None
    assert c2.new_attr == "new_attr"

# Generated at 2022-06-23 23:07:32.246987
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert ('urllib.robotparser.RobotFileParser', 'six.moves.urllib_robotparser.RobotFileParser') in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:07:38.566555
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('str', 'str') == MovedModule('str', 'str')
    assert MovedModule('unicode', 'str') != MovedModule('str', 'str')
    assert MovedModule('str', 'str') != MovedModule('str', 'unicode')
    assert MovedModule('str', 'str', 'unicode') != MovedModule('str', 'str')
    assert MovedModule('str', 'str') == MovedModule('str', 'str', 'str')


# Generated at 2022-06-23 23:07:50.689159
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    from ..base import RewriteImports
    from ..convert import ConvertVisitor
    import sys

    sys.path.append('.')
    sys.modules['six'] = None
    expected = {
        'six': {
            'moves': {
                'queue': None,
                'reload_module': None,
                'urllib': {
                    'error': {},
                    'parse': {},
                    'request': {},
                    'response': {},
                    'robotparser': {},
                }
            }
        }
    }
    SixMovesTransformer(RewriteImports(ConvertVisitor.RewriteInfo(None, None, None))).visit(expected)

# Generated at 2022-06-23 23:08:00.430560
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr_name = 'StringIO'
    module_name = 'io'
    old_mod_name = 'StringIO'
    old_attribute_name = 'StringIO'
    moved = MovedAttribute(attr_name, old_mod_name, module_name)
    assert moved.name == attr_name
    assert moved.new_mod == module_name
    assert moved.new_attr == old_attribute_name
    old_mod_name = 'cStringIO'
    old_attribute_name = 'StringIO'
    moved = MovedAttribute(attr_name, old_mod_name, module_name)
    assert moved.name == attr_name
    assert moved.new_mod == module_name
    assert moved.new_attr == old_attribute_name


# Generated at 2022-06-23 23:08:03.970972
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:08:06.275873
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:08:15.067754
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'old_mod', 'new_mod', 'old_attr', 'new_attr').__dict__ == {'name': 'foo', 'old_mod': 'old_mod', 'new_mod': 'new_mod', 'old_attr': 'old_attr', 'new_attr': 'new_attr'}
    assert MovedAttribute('foo', 'old_mod', 'new_mod').__dict__ == {'name': 'foo', 'old_mod': 'old_mod', 'new_mod': 'new_mod', 'old_attr': None, 'new_attr': 'foo'}

# Generated at 2022-06-23 23:08:22.295838
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_att = MovedAttribute(name='c', old_mod='Old', new_mod='New', old_attr='o', new_attr='n')
    assert moved_att.name == 'c'
    assert moved_att.old_mod is None
    assert moved_att.new_mod == 'New'
    assert moved_att.old_attr is None
    assert moved_att.new_attr == 'n'



# Generated at 2022-06-23 23:08:24.909213
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_urllib_parse_moved_attributes) == 30


if __name__ == '__main__':
    # Test
    from idlelib.idle_test.htest import run
    run(SixMovesTransformer)

# Generated at 2022-06-23 23:08:35.220759
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert (MovedAttribute('name', 'oldmod', 'newmod', 'oldattr', 'newattr').name
            == 'name')
    assert (MovedAttribute('name', 'oldmod', 'newmod', 'oldattr', 'newattr').new_mod
            == 'newmod')
    assert (MovedAttribute('name', 'oldmod', 'newmod', 'oldattr', 'newattr').new_attr
            == 'newattr')
    assert (MovedAttribute('name', 'oldmod', 'newmod', 'oldattr', 'newattr').old_attr
            == 'oldattr')
    assert (MovedAttribute('name', 'oldmod', 'newmod').name == 'name')
    assert (MovedAttribute('name', 'oldmod', 'newmod').new_mod ==  'newmod')

# Generated at 2022-06-23 23:08:36.498311
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:40.823392
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert set(SixMovesTransformer.rewrites) == set(
        [('collections.UserDict', 'six.moves.UserDict'),
         ('subprocess.getoutput', 'six.moves.getoutput'),
         ('subprocess.getstatusoutput', 'six.moves.getstatusoutput'),
         ('builtins.input', 'six.moves.input'),
         ('subprocess.Popen', 'subprocess.Popen')])

# Generated at 2022-06-23 23:08:42.063018
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 126

# Generated at 2022-06-23 23:08:43.134668
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert tuple(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:08:54.658528
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)

# Generated at 2022-06-23 23:09:05.306267
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"
    b = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert b.new_mod == "builtins"
    assert b.new_attr == "filter"
    c = MovedAttribute("intern", "__builtin__", "sys")
    assert c.name == "intern"
    assert c.new_mod == "sys"
    assert c.new_attr == "intern"
    d = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-23 23:09:09.904753
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
