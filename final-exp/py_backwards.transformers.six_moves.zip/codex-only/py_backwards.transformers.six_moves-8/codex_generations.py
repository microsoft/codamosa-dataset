

# Generated at 2022-06-23 22:59:20.097086
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'

# Generated at 2022-06-23 22:59:30.224946
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()
    assert obj.target == (2, 7)

# Generated at 2022-06-23 22:59:37.667408
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from sourceinfo import SourceInfo
    from importlib import util
    import sys
    import pathlib
    import importlib.machinery

    src_paths = (str(pathlib.Path(__file__).resolve().parent.parent / 'src'),)
    src_paths = list(map(str, src_paths))
    for path in src_paths:
        sys.path.insert(0, path)

    from typeguard import typechecked
    from callable_usage import SixMovesTransformer, _urllib_parse_moved_attributes, _urllib_error_moved_attributes

    # unit test:
    src_path = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-23 22:59:47.835033
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("test", "test1", "test2")
    assert move.name == "test"
    assert move.new_mod == "test2"
    assert move.new_attr == "test"
    move = MovedAttribute("test", "test1", "test2", "test3")
    assert move.name == "test"
    assert move.new_mod == "test2"
    assert move.new_attr == "test3"
    move = MovedAttribute("test", "test1", "test2", "test3", "test4")
    assert move.name == "test"
    assert move.new_mod == "test2"
    assert move.new_attr == "test4"


# Generated at 2022-06-23 22:59:51.837366
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.__class__.__name__ == 'SixMovesTransformer'
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 22:59:52.873576
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    return bool(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 22:59:54.311222
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()

# Generated at 2022-06-23 23:00:04.520283
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert [i for i in SixMovesTransformer.rewrites if 'six.moves.urllib_parse.urlparse' in i]
    assert [i for i in SixMovesTransformer.rewrites if 'six.moves.urllib_parse.quote' in i]
    assert [i for i in SixMovesTransformer.rewrites if 'six.moves.urllib_parse.unquote' in i]
    assert [i for i in SixMovesTransformer.rewrites if 'six.moves.urllib_parse.unquote_to_bytes' in i]
    assert [i for i in SixMovesTransformer.rewrites if 'six.moves.urllib_parse.urlencode' in i]

# Generated at 2022-06-23 23:00:05.207970
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.__doc__

# Generated at 2022-06-23 23:00:12.239969
# Unit test for constructor of class MovedModule

# Generated at 2022-06-23 23:00:16.591247
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.new == "new"

    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"

# Generated at 2022-06-23 23:00:20.987422
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("builtins", "__builtin__")
    assert a.name == "builtins"
    assert a.new == "builtins"

    b = MovedModule("getcwdb", "os", "os")
    assert b.name == "getcwdb"
    assert b.new == "getcwdb"



# Generated at 2022-06-23 23:00:21.832893
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer(): # noqa
    SixMovesTransformer()

# Generated at 2022-06-23 23:00:22.633786
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:00:30.708651
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    rewrites = transformer.rewrites
    assert len(rewrites) > 50
    i = 0
    for rewrite in rewrites:
        (path, replace) = rewrite
        if path == '__builtin__.range':
            assert replace == 'six.moves.range'
            i += 1
        if path == 'urllib.robotparser.RobotFileParser':
            assert replace == 'six.moves.urllib.robotparser.RobotFileParser'
            i += 1
    assert i == 2

# Generated at 2022-06-23 23:00:37.138332
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('x', 'y', 'z')
    assert m.name == 'x'
    assert m.new_mod == 'z'
    assert m.new_attr == 'x'
    m = MovedAttribute('x', 'y', 'z', 'a', 'b')
    assert m.name == 'x'
    assert m.new_mod == 'z'
    assert m.new_attr == 'b'
    m = MovedAttribute('x', 'y', 'z', 'a')
    assert m.name == 'x'
    assert m.new_mod == 'z'
    assert m.new_attr == 'a'

# Generated at 2022-06-23 23:00:42.682684
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO") == \
           MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO") == \
           MovedAttribute("cStringIO", "cStringIO", "io")



# Generated at 2022-06-23 23:00:54.222385
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:05.230197
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert ma.name == 'cStringIO'
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'StringIO'

    ma = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert ma.name == 'filter'
    assert ma.new_mod == 'builtins'
    assert ma.new_attr == 'filter'

    ma = MovedAttribute('reload_module', '__builtin__', 'imp', 'reload')
    assert ma.name == 'reload_module'
    assert ma.new_mod == 'imp'
    assert ma.new_attr == 'reload'

# Generated at 2022-06-23 23:01:13.043326
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.tokenize import generate_tokens
    from lib2to3.pytree import Leaf, Node, type_repr
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.patcomp import PatternCompiler
    import libcst as cst

    s = """from six.moves.cStringIO import StringIO\nfrom six.moves import queue"""
    tokens = generate_tokens(s.__class__(s))
    t = tokens.next()
    leaf = Leaf(t)
    node = Node(syms.import_from, [leaf])
    node2 = Node(syms.import_from, [leaf])
    node3 = Node(syms.import_from, [leaf])

    converter = SixMovesTrans

# Generated at 2022-06-23 23:01:18.264516
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from future.tests.base import CodeHandler
    handler = CodeHandler(None)
    t = SixMovesTransformer(handler)
    assert t.target == (2, 7)
    assert list(t.rewrites) == _get_rewrites()

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:01:22.486447
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Tests for instantiation of class MovedModule."""
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    assert moved_module.old == "__builtin__"
    moved_module = MovedModule("configparser", "ConfigParser", new="configparser")
    assert moved_module.name == "configparser"
    assert moved_module.new == "configparser"
    assert moved_module.old == "ConfigParser"


# Generated at 2022-06-23 23:01:24.973733
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six' in SixMovesTransformer.dependencies
    assert SixMovesTransformer.target == (2, 7)
    assert len(SixMovesTransformer.rewrites) == 61

# Generated at 2022-06-23 23:01:33.526707
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from astroid import test_utils
    from astroid import nodes
    from astroid import builder
    builder = builder.AstroidBuilder()

# Generated at 2022-06-23 23:01:36.501954
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule("name")
        MovedModule("name", "old", "new", "extra")

# Generated at 2022-06-23 23:01:38.242753
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for pair in _get_rewrites():
        if pair in SixMovesTransformer.rewrites:
            pass

# Generated at 2022-06-23 23:01:42.673788
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    f = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert f.name == "cStringIO"
    assert f.new_mod == "io"
    assert f.new_attr == "StringIO"



# Generated at 2022-06-23 23:01:49.658774
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:54.340728
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    filename = os.path.join(os.path.dirname(__file__), 'six_moves.txt')
    with open(filename, 'r') as f:
        data = six.text_type(f.read())
    transformer = SixMovesTransformer()
    result = transformer.run_pipeline(data)
    assert isinstance(result, six.text_type)
    assert "import six\n" in result
    assert "six.moves" in result

# Generated at 2022-06-23 23:02:00.594218
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # a class MovedModule is created.
    moved_module = MovedModule('six', '__builtin__')
    # The type of instance moved_module is MovedModule.
    assert type(moved_module) == MovedModule
    # The name of instance moved_module is 'six'.
    assert moved_module.name == 'six'
    # The old of instance moved_module is '__builtin__'.
    assert moved_module.old == '__builtin__'


# Generated at 2022-06-23 23:02:04.151719
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()

    assert instance.target == (2, 7)
    assert instance.dependencies == ['six']
    assert instance.rewrites != {}

# Generated at 2022-06-23 23:02:08.114860
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "cStringIO"
    assert ma.old_attr == None
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:02:18.437194
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'bar', 'baz') == MovedAttribute('foo', 'bar', 'baz')
    assert MovedAttribute('foo', 'bar', 'baz') != MovedAttribute('spam', 'bar', 'baz')
    assert MovedAttribute('foo', 'bar', 'baz') != MovedAttribute('foo', 'spam', 'baz')
    assert MovedAttribute('foo', 'bar', 'baz') != MovedAttribute('foo', 'bar', 'spam')
    assert MovedAttribute('foo', 'bar', 'baz') != MovedAttribute('foo', 'bar', 'baz', 'spam')
    assert MovedAttribute('foo', 'bar', 'baz') != MovedAttribute('foo', 'bar', 'baz', 'spam', 'eggs')


# Generated at 2022-06-23 23:02:21.914411
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) > 0
    # We have to assert that the module is present in sys.modules
    SixMovesTransformer.rewrites
    # Now we can assert it is cached
    assert SixMovesTransformer.rewrites is None

# Generated at 2022-06-23 23:02:33.659914
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert set(SixMovesTransformer.dependencies) == set(['six'])

    rewrites = set(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:02:39.939925
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name" and moved_attribute.new_mod == "new_mod" and \
        moved_attribute.old_mod == "old_mod" and moved_attribute.new_attr == "new_attr" and \
        moved_attribute.old_attr == "old_attr"



# Generated at 2022-06-23 23:02:51.090937
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:02:54.566282
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 58
    assert ('numpy.core.multiarray.dtype', 'six.moves.builtins.type') in SixMovesTransformer.rewrites


# Generated at 2022-06-23 23:02:58.838026
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule('sys', 'sys', 'sys')
    assert movedModule.name == 'sys'
    assert movedModule.old == 'sys'
    assert movedModule.new == 'sys'

# Generated at 2022-06-23 23:03:09.917493
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:03:12.340876
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    cls = SixMovesTransformer
    assert cls.target == (2, 7)
    assert len(cls.rewrites) == 25
    assert cls.dependencies == ['six']

# Generated at 2022-06-23 23:03:16.686092
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('a','a','a','a','a')
    MovedAttribute('a','a','a','a',None)
    MovedAttribute('a','a','a',None,None)
    MovedAttribute('a','a',None,None,None)
    MovedAttribute('a','a',None,None,'a')

# Generated at 2022-06-23 23:03:19.216540
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, list)
    assert len(SixMovesTransformer.rewrites) > 0

# Generated at 2022-06-23 23:03:22.676667
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert ma.name == "filter"
    assert ma.new_mod == "builtins"
    assert ma.new_attr == "filter"
    ma = MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
    assert ma.name == "getcwdb"
    assert ma.new_mod == "os"
    assert ma.new_attr == "getcwdb"


# Generated at 2022-06-23 23:03:32.064983
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').name == 'filter'
    assert MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse').name == 'filterfalse'
    assert MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input').name == 'input'
    assert MovedAttribute('intern', '__builtin__', 'sys').name == 'intern'
    assert MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map').name == 'map'

# Generated at 2022-06-23 23:03:36.859451
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'

# Generated at 2022-06-23 23:03:38.028504
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()


# Generated at 2022-06-23 23:03:42.473092
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import_rewriter = SixMovesTransformer()
    assert(import_rewriter.target == (2, 7))
    for x in _get_rewrites():
        assert (x in import_rewriter.rewrites)
    assert (import_rewriter.dependencies == ['six'])

# Generated at 2022-06-23 23:03:45.342173
# Unit test for constructor of class MovedModule
def test_MovedModule():  # noqa: D103
    assert MovedModule("builtins", "__builtin__") == \
        MovedModule("builtins", "__builtin__")

# Generated at 2022-06-23 23:03:47.984794
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libmodernize.fixes.six_moves import SixMovesTransformer as UUT
    assert list(UUT().rewrites) == list(SixMovesTransformer().rewrites)

# Generated at 2022-06-23 23:03:55.471454
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'StringIO'
    m = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert m.name == 'filter'
    assert m.new_mod == 'builtins'
    assert m.new_attr == 'filter'
    m = MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    assert m.name == 'input'
    assert m.new_mod == 'builtins'
    assert m.new_attr == 'input'

# Generated at 2022-06-23 23:04:04.852564
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_attr == "name"

# Generated at 2022-06-23 23:04:16.858899
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("new_attr", "old", "new")
    assert moved.name == "new_attr"
    assert moved.new_mod == "new"
    assert moved.new_attr == "new_attr"
    moved = MovedAttribute("new_attr", "old", "new", "old_attr")
    assert moved.name == "new_attr"
    assert moved.new_mod == "new"
    assert moved.new_attr == "old_attr"
    moved = MovedAttribute("new_attr", "old", "new", "old_attr", "new_attr")
    assert moved.name == "new_attr"
    assert moved.new_mod == "new"
    assert moved.new_attr == "new_attr"


# Generated at 2022-06-23 23:04:21.309321
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('name', 'old_value')
    assert move.name == 'name'
    assert move.new == 'name'
    assert move.old == 'old_value'

    move = MovedModule('name', 'old_value', 'new_value')
    assert move.name == 'name'
    assert move.new == 'new_value'
    assert move.old == 'old_value'


# Generated at 2022-06-23 23:04:24.785394
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    d = {'a':  2, 'b': 3}
    for k, v in d.items():
        assert SixMovesTransformer.rewrites[k] == v

# Generated at 2022-06-23 23:04:29.083428
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").new_attr == "filterfalse"

# Generated at 2022-06-23 23:04:33.054317
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"


# Generated at 2022-06-23 23:04:35.699417
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('user_list', 'UserList')
    assert moved_module.name == 'user_list'
    assert moved_module.new == 'UserList'

# Generated at 2022-06-23 23:04:38.918717
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.__dict__ == {"name": "name", "old": "old", "new": "new"}
    assert str(module) == 'MovedModule("name", "old", "new")'


# Generated at 2022-06-23 23:04:43.112687
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("tkinter", "Tkinter")
    assert moved_module.name == "tkinter"
    assert moved_module.new == "tkinter"
    assert moved_module.old == "Tkinter"


# Generated at 2022-06-23 23:04:47.299946
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = SixMovesTransformer.rewrites
    assert 'six.moves.urllib.parse.quote' in rewrites
    assert rewrites['six.moves.urllib.parse.quote'] == 'six.moves.urllib.quote'

# Generated at 2022-06-23 23:04:51.182423
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(name='name', old='old', new='new').name == 'name'
    assert MovedModule(name='name', old='old', new='new').old == 'old'
    assert MovedModule(name='name', old='old', new='new').new == 'new'

# Generated at 2022-06-23 23:05:01.436129
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod").old_mod == "old_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod").name == "name"
    assert MovedAttribute("name", "old_mod").old_mod == "old_mod"
    assert MovedAttribute("name", "old_mod").new_mod == "name"
    assert MovedAttribute("name").name == "name"
    assert MovedAttribute("name").old_mod == "name"
    assert MovedAttribute("name").new_mod == "name"

# Generated at 2022-06-23 23:05:05.151558
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = [MovedModule("name", "old1", "new1"),
             MovedModule("name2", "old2")]
    assert len(moves) == 2
    assert moves[0].name == "name"
    assert moves[0].old == "old1"
    assert moves[0].new == "new1"
    assert moves[1].name == "name2"
    assert moves[1].old == "old2"
    assert moves[1].new == "name2"

# Generated at 2022-06-23 23:05:08.191415
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('a', 'b', 'c')
    assert a.name == 'a'
    assert a.new_mod == 'c'
    assert a.new_attr == 'a'


# Generated at 2022-06-23 23:05:13.519843
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("test_moved_module", "test_old").name == "test_moved_module"
    assert MovedModule("test_moved_module", "test_old").new == "test_moved_module"

    assert MovedModule("test_moved_module", "test_old", "test_new").name == "test_moved_module"
    assert MovedModule("test_moved_module", "test_old", "test_new").new == "test_new"


# Generated at 2022-06-23 23:05:22.202450
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Basic test:
    m = MovedAttribute("name", "old_mod", "new_mod")
    assert m.name == "name"
    assert m.new_mod == "new_mod"
    assert m.new_attr == "name"

    # When there is no new module:
    m = MovedAttribute("name", None, None)
    assert m.new_mod == "name"

    # When there is a new but not an old attribute:
    m = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    assert m.new_attr == "new_attr"

    # When there are both a new and an old attribute:
    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert m.new_attr

# Generated at 2022-06-23 23:05:27.270843
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("os", "io").name == "os"
    assert MovedModule("os", "io").new == 'os'
    assert MovedModule("os", "io", "io2").new == 'io2'
    assert MovedModule("os", "io", new="io2").new == 'io2'

# Generated at 2022-06-23 23:05:30.498664
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('x','1','2','3','4')
    assert ma.name == 'x'
    assert ma.new_mod == '1'
    assert ma.new_attr == '3'


# Generated at 2022-06-23 23:05:42.442221
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of SixMovesTransformer."""
    assert "io.StringIO" in SixMovesTransformer.rewrites
    assert "builtins.filter" in SixMovesTransformer.rewrites
    assert "itertools.filterfalse" in SixMovesTransformer.rewrites
    assert "builtins.input" in SixMovesTransformer.rewrites
    assert "sys.intern" in SixMovesTransformer.rewrites
    assert "builtins.map" in SixMovesTransformer.rewrites
    assert "os.getcwdb" in SixMovesTransformer.rewrites
    assert "os.getcwd" in SixMovesTransformer.rewrites
    assert "subprocess.getstatusoutput" in SixMovesTransformer.rewrites
    assert "subprocess.getoutput" in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:05:53.720751
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:04.652181
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr='StringIO', new_attr=None)
    assert ma.name == 'cStringIO'
    assert ma.new_attr == 'StringIO'
    assert ma.new_mod == 'io'

    ma = MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr='StringIO', new_attr='foo')
    assert ma.name == 'cStringIO'
    assert ma.new_attr == 'foo'
    assert ma.new_mod == 'io'

    ma = MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr=None, new_attr='foo')

# Generated at 2022-06-23 23:06:11.660460
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    import six
    six_moves = six.moves
    assert six_moves.StringIO == six_moves.cStringIO.StringIO
    assert six_moves.StringIO is six_moves.cStringIO.StringIO
    assert six_moves.izip is six_moves.zip
    assert six_moves.izip_longest is six_moves.zip_longest

    assert six.moves.urllib.parse.quote == six.moves.urllib.quote
    assert six.moves.urllib.parse.quote_plus == six.moves.urllib.quote_plus
    assert six.moves.urllib.parse.unquote == six.moves.urllib.unquote
    assert six.moves.urllib.parse.unquote_

# Generated at 2022-06-23 23:06:23.504850
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", None)
    assert ma is not None
    assert ma.name == "cStringIO"
    assert ma.new_mod is None
    assert ma.new_attr is None
    ma = MovedAttribute("StringIO", "cStringIO", "io", "StringIO")
    assert ma is not None
    assert ma.name == "StringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    ma = MovedAttribute("StringIO", "cStringIO", "io", "StringIO", "new_StringIO")
    assert ma is not None
    assert ma.name == "StringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "new_StringIO"
   

# Generated at 2022-06-23 23:06:26.872877
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    from .six_moves import SixMovesTransformer
    assert isinstance(SixMovesTransformer, type)
    assert issubclass(SixMovesTransformer, BaseImportRewrite)


# Generated at 2022-06-23 23:06:37.190709
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import inspect
    import six
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert inspect.ismodule(six.moves)
                assert isinstance(six.moves, six.types.ModuleType)
                assert hasattr(six.moves, move.name)
                assert isinstance(getattr(six.moves, move.name), object)
            elif isinstance(move, MovedModule):
                assert inspect.ismodule(six.moves)
                assert isinstance(six.moves, six.types.ModuleType)
                assert hasattr(six.moves, move.name)

# Generated at 2022-06-23 23:06:41.394989
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("attr", "foo", "bar")
    assert attr.name == "attr"
    assert attr.new_mod == "bar"
    assert attr.new_attr == "attr"

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-23 23:06:44.774103
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "mod", "newmod", "oldattr", "newattr").__dict__ == \
        {"name":"name", "new_mod":"newmod", "new_attr":"newattr"}


# Generated at 2022-06-23 23:06:54.578451
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("module-name", "old-module-name",
                         "new-module-name")
    assert module.name == "module-name"
    assert module.old == "old-module-name"
    assert module.new == "new-module-name"

    module = MovedModule("module-name", "old-module-name")
    assert module.name == "module-name"
    assert module.old == "old-module-name"
    assert module.new == "module-name"

    module = MovedModule("module-name")
    assert module.name == "module-name"
    assert module.old == "module-name"
    assert module.new == "module-name"

# Generated at 2022-06-23 23:07:05.573835
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert str(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")) == "MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')"
    assert str(MovedAttribute("cStringIO", "cStringIO", None, "StringIO")) == "MovedAttribute('cStringIO', 'cStringIO', 'cStringIO', 'StringIO')"
    assert str(MovedAttribute("cStringIO", "cStringIO", None, "StringIO", "stringio")) == "MovedAttribute('cStringIO', 'cStringIO', 'cStringIO', 'StringIO', 'stringio')"
    assert str(MovedAttribute("cStringIO", "cStringIO", "io")) == "MovedAttribute('cStringIO', 'cStringIO', 'io')"

# Generated at 2022-06-23 23:07:08.927428
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert isinstance(rewrites, list)


__all__ = [SixMovesTransformer]

# Generated at 2022-06-23 23:07:11.970604
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert list(transformer.rewrites) == _get_rewrites()

# Generated at 2022-06-23 23:07:16.002948
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"



# Generated at 2022-06-23 23:07:24.422154
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    MovedAttribute("reload_module", "__builtin__", "imp", "reload")

# Generated at 2022-06-23 23:07:27.575806
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('configparser', 'ConfigParser')
    assert MovedModule('configparser', 'ConfigParser', 'configparser')


# Generated at 2022-06-23 23:07:31.817275
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('foo', 'bar')
    assert x.name == 'foo'
    assert x.old == 'bar'
    assert x.new == 'foo'
    x = MovedModule('foo', 'bar', 'baz')
    assert x.name == 'foo'
    assert x.old == 'bar'
    assert x.new == 'baz'

# Generated at 2022-06-23 23:07:35.410195
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert isinstance(mm, MovedModule)
    assert mm.name == 'name' and mm.old == 'old' and mm.new == 'new'


# Generated at 2022-06-23 23:07:42.648561
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old", "new")
    assert move.name == "name"
    assert move.new_mod == "new"
    assert move.new_attr == "name"

    move = MovedAttribute("name", "old", "new", "old_attr")
    assert move.name == "name"
    assert move.new_mod == "new"
    assert move.new_attr == "old_attr"

    move = MovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-23 23:07:47.062638
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:07:54.269026
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six

    assert six.moves.queue is Queue
    assert six.moves.dbm.gnu is dbm_gnu
    assert six.moves.urllib.request is urllib.request
    assert six.moves.urllib.request.build_opener is build_opener
    assert six.moves.urllib.parse.quote is quote
    assert six.moves.urllib.parse.quote_plus is quote_plus
    assert six.moves.urllib.response.addbase is addbase
    assert six.moves.urllib.robotparser.RobotFileParser is RobotFileParser

# Generated at 2022-06-23 23:08:03.144690
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule('foo', 'foo')
    mm1 = MovedModule('foo', 'foo', 'bar')
    assert 'foo' == mm1.name
    assert 'foo' == mm1.old
    assert 'bar' == mm1.new
    mm2 = MovedModule('foo', old='bar')
    assert 'foo' == mm2.name
    assert 'bar' == mm2.old
    assert 'foo' == mm2.new

# Generated at 2022-06-23 23:08:08.528727
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert path in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                assert move.new in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:08:15.856570
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name", "mod", "new_mod")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "name"
    obj = MovedAttribute("name", "mod", "new_mod", "attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "attr"
    obj = MovedAttribute("name", "mod", "new_mod", "attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "mod"
    assert obj.new_attr == "new_attr"

# Generated at 2022-06-23 23:08:28.131057
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """
    Test the constructor of class MovedAttribute.
    """
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "old_attr"
    ma = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"


# Generated at 2022-06-23 23:08:32.959893
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-23 23:08:35.449439
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("tkinter", "Tkinter", "tkinter")
    assert mm.name == "tkinter"
    assert mm.new == "tkinter"


# Generated at 2022-06-23 23:08:39.559197
# Unit test for constructor of class MovedModule
def test_MovedModule():
    temp_MovedModule = MovedModule("ABC", "DEF")
    assert temp_MovedModule.name == "ABC"
    assert temp_MovedModule.old == "DEF"
    assert temp_MovedModule.new == "ABC"


# Generated at 2022-06-23 23:08:50.479727
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..tests.test_transforms.transform_support import TransformerTestCase
    from ..transforms.fix_six_moves import SixMovesTransformer
    # Fake prefix for six.moves.urllib
    sixmoves_prefix = '.urllib'
    name = 'six'
    # Rewrites for six.moves.urllib

# Generated at 2022-06-23 23:08:54.938099
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("module", "old", "new")
    assert mod.name == "module"
    assert mod.new == "new"
    mod = MovedModule("module", "old")
    assert mod.name == "module"
    assert mod.new == "old"

# Generated at 2022-06-23 23:09:02.606704
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'old', 'new').name == 'foo'
    assert MovedAttribute('foo', 'old', 'new').new_mod == 'new'
    assert MovedAttribute('foo', 'old', 'new').new_attr == 'foo'
    assert MovedAttribute('foo', 'old', 'new', 'old_attr').new_attr == 'old_attr'
    assert MovedAttribute('foo', 'old', 'new', new_attr='new_attr').new_attr == 'new_attr'


# Generated at 2022-06-23 23:09:10.305751
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar') == MovedModule('foo', 'bar')
    assert MovedModule('foo', 'bar', 'baz') == MovedModule('foo', 'bar', 'baz')
    assert MovedModule('foo', None) == MovedModule('foo', 'foo')
    assert MovedModule('foo', None, 'baz') == MovedModule('foo', 'foo', 'baz')
    assert MovedModule('foo', 'bar') != MovedModule('foo', 'baz')
    assert MovedModule('foo', 'bar') != MovedModule('baz', 'bar')
    assert MovedModule('foo', 'bar', 'baz') != MovedModule('foo', 'bar', None)

# Generated at 2022-06-23 23:09:12.842010
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("test", "test")

    assert test.name == "test"
    assert test.new == "test"


# Generated at 2022-06-23 23:09:19.558255
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    t = SixMovesTransformer({})
    assert t.rewrites == _get_rewrites()

    # Check that list of rewrites does not contain dublicates
    temp = []
    for from_, to in t.rewrites:
        assert (from_, to) not in temp, '{} has dublicates: {}'.format(t.__class__.__name__, from_)
        temp.append((from_, to))
