

# Generated at 2022-06-23 22:59:16.609987
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

# Generated at 2022-06-23 22:59:18.620773
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    target = SixMovesTransformer(None)
    assert target.rewrites

# Generated at 2022-06-23 22:59:20.617632
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import _test_generic_import_transformer
    _test_generic_import_transformer(SixMovesTransformer)

# Generated at 2022-06-23 22:59:26.261001
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('abcd', 'efgh', 'ijkl')
    assert module.name == 'abcd'
    assert module.old == 'efgh'
    assert module.new == 'ijkl'

    module = MovedModule('abcd', 'efgh')
    assert module.name == 'abcd'
    assert module.old == 'efgh'
    assert module.new == 'abcd'


# Generated at 2022-06-23 22:59:27.903467
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-23 22:59:36.120891
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 22:59:38.264361
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')

# Generated at 2022-06-23 22:59:49.324555
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from types import ModuleType
    from lib2to3.fixer_base import BaseFix
    from libmodernize.fixes.fix_six_moves import SixMovesTransformer

    assert isinstance(SixMovesTransformer, type)
    assert issubclass(SixMovesTransformer, BaseFix)
    assert isinstance(SixMovesTransformer('', ''), BaseFix)
    assert SixMovesTransformer.name == "SixMovesTransformer"
    assert SixMovesTransformer.aliases == ()
    assert SixMovesTransformer.is_default
    assert not SixMovesTransformer.run_order == 3
    assert SixMovesTransformer.target == (2, 7)

    moves = SixMovesTransformer('', '')
    assert isinstance(moves, BaseFix)

# Generated at 2022-06-23 22:59:54.073985
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(MovedModule('a', 'b', 'c').new == 'c')
    assert(MovedModule('x', 'y').name == 'x')
    assert(MovedModule('x', 'y').new == 'x')
    assert(MovedModule('x', 'y').name == 'x')


# Generated at 2022-06-23 22:59:57.518021
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:00:05.920065
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(prefixed_moves) == 6
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert (path, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer.rewrites
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:00:07.843677
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert rewrites[0] == ('builtins.input', 'six.moves.input')
    assert rewrites[1] == ('builtins.range', 'six.moves.range')

# Generated at 2022-06-23 23:00:11.224401
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert t.dependencies == ['six']
    # rewrites is too big to test

# Generated at 2022-06-23 23:00:12.553835
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 184

# Generated at 2022-06-23 23:00:17.209271
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six_moves_transformer
    import six
    transformer = six_moves_transformer.SixMovesTransformer()
    assert transformer.from_ns == 'six'
    assert transformer.to_ns == 'six'
    assert transformer.dependencies == ['six']
    assert isinstance(transformer, six_moves_transformer.BaseImportRewrite)

# Generated at 2022-06-23 23:00:24.976005
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:29.407594
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 84


# Manual test for method rewrite of class SixMovesTransformer
if __name__ == "__main__":
    import sys
    # this test is not executed from here, but from file ../../test/test_transformers.py

    sys.exit(1)

# Generated at 2022-06-23 23:00:35.139182
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Without old_attr
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

    # With old_attr
    move2 = MovedAttribute("reload_module", "__builtin__", "importlib", "reload")
    assert move2.name == "reload_module"
    assert move2.new_mod == "importlib"
    assert move2.new_attr == "reload"


# Generated at 2022-06-23 23:00:43.303829
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from . import base
    a = MovedModule("tkinter", "Tkinter")
    assert a.name == "tkinter"
    assert a.new == "tkinter"
    a = MovedModule("tkinter", "Tkinter", "tkinter")
    assert a.name == "tkinter"
    assert a.new == "tkinter"
    a = MovedModule("tkinter_simpledialog", "SimpleDialog", "tkinter.simpledialog")
    assert a.name == "tkinter_simpledialog"
    assert a.new == "tkinter.simpledialog"


# Generated at 2022-06-23 23:00:50.044309
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Unit test for constructor of class SixMovesTransformer."""
    expected_result = {
        'functools.reduce': 'six.moves.reduce',
        'robotparser': 'six.moves.urllib_robotparser.robotparser',
        'subprocess.getoutput': 'six.moves.getoutput'
    }
    assert SixMovesTransformer().rewrites == expected_result

# Generated at 2022-06-23 23:00:54.762348
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    six_MovedAttribute = MovedAttribute('name', 'old_mod', 'new_mod',
                                        'old_attr', 'new_attr')
    assert six_MovedAttribute.name == 'name'
    assert six_MovedAttribute.new_mod == 'new_mod'
    assert six_MovedAttribute.new_attr == 'new_attr'

# Generated at 2022-06-23 23:00:59.436726
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test constructor of class MovedModule"""
    test_obj = MovedModule("name", "old", "new")
    assert test_obj.name == "name"
    assert test_obj.old == "old"
    assert test_obj.new == "new"


# Generated at 2022-06-23 23:01:09.605145
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').old_mod == 'old_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').old_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr').old_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr').new_attr == 'old_attr'
   

# Generated at 2022-06-23 23:01:13.597734
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # GIVEN
    name = 'name'
    old = 'old'

    # WHEN
    mm = MovedModule(name, old)

    # THEN
    assert mm.name == name
    assert mm.old == old
    assert mm.new == name



# Generated at 2022-06-23 23:01:24.214593
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == "new_attr"
    moved = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == "old_attr"
    moved = MovedAttribute("name", "old_mod", "new_mod")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == "name"

# Generated at 2022-06-23 23:01:26.234592
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(AssertionError):
        MovedModule("name", "old_module", "new_module", "extra_parameter")

# Generated at 2022-06-23 23:01:28.828264
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    assert BaseImportRewrite in SixMovesTransformer.__bases__
    assert SixMovesTransformer.target == (2, 7)


# Generated at 2022-06-23 23:01:32.073270
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('assert_raises', 'unittest', 'unittest')
    assert ma.name == 'assert_raises'
    assert ma.new_mod == 'unittest'
    assert ma.new_attr == 'assert_raises'

# Generated at 2022-06-23 23:01:38.798892
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "cStringIO"

    assert MovedAttribute("cStringIO", "cStringIO", None, "StringIO").name == "cStringIO"

# Generated at 2022-06-23 23:01:40.955468
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer.rewrites) != []

# Generated at 2022-06-23 23:01:48.074896
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'cStringIO'
    old_mod = 'cStringIO'
    new_mod = 'io'
    old_attr = 'StringIO'
    new_attr = 'StringIO'
    movedAttribute = MovedAttribute(name, old_mod, new_mod)
    assert movedAttribute.name == 'cStringIO'
    assert movedAttribute.new_mod == 'io'
    assert movedAttribute.new_attr == 'cStringIO'
    movedAttribute = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert movedAttribute.new_attr == 'StringIO'
    movedAttribute = MovedAttribute(name, old_mod, new_mod, old_attr)
    assert movedAttribute.new_attr == 'StringIO'

# Generated at 2022-06-23 23:01:51.890334
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrite = SixMovesTransformer().rewrites
    assert (
        len(rewrite) ==
        len(_moved_attributes) +
        len(_urllib_parse_moved_attributes) +
        len(_urllib_error_moved_attributes) +
        len(_urllib_request_moved_attributes) +
        len(_urllib_response_moved_attributes) +
        len(_urllib_robotparser_moved_attributes)
    )

# Generated at 2022-06-23 23:01:55.743848
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'


# Generated at 2022-06-23 23:02:00.183202
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert (ma.name == "cStringIO")
    assert (ma.new_mod == "io")
    assert (ma.new_attr == "StringIO")

# Generated at 2022-06-23 23:02:04.986608
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.new == 'baz'

    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.new == 'foo'

# Generated at 2022-06-23 23:02:11.211838
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'name'
    old_mod = 'old_mod'
    new_mod = 'new_mod'
    old_attr = 'old_attr'
    new_attr = 'new_attr'
    test_move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert test_move.name == name
    assert test_move.old_mod == old_mod
    assert test_move.new_mod == new_mod
    assert test_move.old_attr == old_attr
    assert test_move.new_attr == new_attr



# Generated at 2022-06-23 23:02:16.261989
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 116
    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)
    assert sorted(SixMovesTransformer.rewrites) == sorted(_get_rewrites())
    assert SixMovesTransformer.dependencies == ['six']
    assert SixMovesTransformer.python_version == (2, 7)

# Generated at 2022-06-23 23:02:18.577537
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import register_transformer
    from .transforms.sixmoves import SixMovesTransformer
    register_transformer(SixMovesTransformer)

# Generated at 2022-06-23 23:02:27.218271
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('tkinter', 'Tkinter').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter').new == 'tkinter'
    assert MovedModule('tkinter_dialog', 'Dialog', 'tkinter.dialog').name == 'tkinter_dialog'
    assert MovedModule('tkinter_dialog', 'Dialog', 'tkinter.dialog').new == 'tkinter.dialog'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:02:32.227392
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_mod = MovedModule("moved_modname", "old_modname", "new_modname")
    assert moved_mod.name == "moved_modname"
    assert moved_mod.old == "old_modname"
    assert moved_mod.new == "new_modname"



# Generated at 2022-06-23 23:02:35.552551
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'new'



# Generated at 2022-06-23 23:02:46.702813
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'

    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').name == 'filter'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == 'builtins'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'


# Generated at 2022-06-23 23:02:48.355246
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule('name', 'old', 'new')
    assert movedmodule.name == 'name'
    assert movedmodule.old == 'old'
    assert movedmodule.new == 'new'


# Generated at 2022-06-23 23:02:52.307190
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_attr == "StringIO"
    assert moved_attribute.new_mod == "io"


# Generated at 2022-06-23 23:02:54.653597
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("test_attr", "test_mod1", "test_mod2")

# Generated at 2022-06-23 23:03:01.553845
# Unit test for constructor of class MovedModule
def test_MovedModule():
    actual = MovedModule('foo', 'bar')
    assert actual.name == 'foo'
    assert actual.old == 'bar'
    assert actual.new == 'foo'

    actual2 = MovedModule('foo', 'bar', 'baz')
    assert actual2.name == 'foo'
    assert actual2.old == 'bar'
    assert actual2.new == 'baz'


# Generated at 2022-06-23 23:03:10.064460
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert isinstance(instance, SixMovesTransformer)
    assert hasattr(instance, "dependencies")
    assert isinstance(instance.dependencies, list)
    assert hasattr(instance, "rewrites")
    assert isinstance(instance.rewrites, dict)
    assert hasattr(instance, "target")
    assert isinstance(instance.target, tuple)
    assert hasattr(instance, "transform")
    assert callable(instance.transform)
    assert hasattr(instance, "init")
    assert callable(instance.init)


# Generated at 2022-06-23 23:03:18.338824
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 123
    assert ('getcwd', 'six.moves.os.getcwdu') in SixMovesTransformer.rewrites # type:ignore
    assert ('range', 'six.moves.builtins.range') in SixMovesTransformer.rewrites # type:ignore
    assert ('os.getcwd', 'six.moves.os.getcwdu') in SixMovesTransformer.rewrites # type:ignore
    assert ('__builtin__.range', 'six.moves.builtins.range') not in SixMovesTransformer.rewrites # type:ignore
    assert ('six.moves.urllib.parse', 'six.moves.urllib_parse') in SixMovesTransformer.rewrites # type:ignore

# Generated at 2022-06-23 23:03:24.882070
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"

    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"

    assert MovedModule("name").name == "name"
    assert MovedModule("name").new == "name"


# Generated at 2022-06-23 23:03:28.198139
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:29.178786
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:03:34.552378
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('winreg', '_winreg').name == 'winreg'
    assert MovedModule('winreg', '_winreg').new == 'winreg'
    assert MovedModule('email_mime_base', 'email.MIMEBase', 'email.mime.base').name == 'email_mime_base'
    assert MovedModule('email_mime_base', 'email.MIMEBase', 'email.mime.base').new == 'email.mime.base'


# Generated at 2022-06-23 23:03:36.248886
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 35

# Generated at 2022-06-23 23:03:39.479209
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

# Generated at 2022-06-23 23:03:43.128783
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("StringIO", "StringIO", "io", "StringIO").old_attr == "StringIO"
    assert MovedAttribute("StringIO", "StringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("StringIO", "StringIO", "io").new_attr == "StringIO"


# Generated at 2022-06-23 23:03:52.828017
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

    moved_attribute_2 = MovedAttribute("cStringIO", "cStringIO", "io", old_attr = "StringIO")
    assert moved_attribute_2.name == "cStringIO"
    assert moved_attribute_2.new_mod == "io"
    assert moved_attribute_2.new_attr == "StringIO"

    moved_attribute_3 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute_3.name == "cStringIO"
    assert moved_attribute_3.new

# Generated at 2022-06-23 23:03:54.488420
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_SixMovesTransformer.__wrapped__()


# Generated at 2022-06-23 23:04:00.853211
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"
    move = MovedAttribute("zip", "itertools", "builtins", "izip", "zip")
    assert move.name == "zip"
    assert move.new_mod == "builtins"
    assert move.new_attr == "zip"

# Generated at 2022-06-23 23:04:02.606114
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('re', 're', 're').__dict__ == {'name': 're', 'old': 're', 'new': 're'}

# Generated at 2022-06-23 23:04:05.892496
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("X", "Y").name == "X"
    assert MovedModule("X", "Y").new == "X"
    assert MovedModule("X", "Y", "Z").name == "X"
    assert MovedModule("X", "Y", "Z").new == "Z"


# Generated at 2022-06-23 23:04:10.418296
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').__dict__ == {'name': 'name', 'old_mod': 'old_mod',
                                                                    'new_mod': 'new_mod'}



# Generated at 2022-06-23 23:04:20.561041
# Unit test for constructor of class MovedModule

# Generated at 2022-06-23 23:04:32.130118
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute('attr','mod','','')
    assert attribute.name == 'attr'
    assert attribute.new_mod == 'mod'
    assert attribute.new_attr == 'attr'

    attribute2 = MovedAttribute('attr2','mod2','','new_attr2')
    assert attribute2.name == 'attr2'
    assert attribute2.new_mod == 'mod2'
    assert attribute2.new_attr == 'new_attr2'

    attribute3 = MovedAttribute('attr3','mod3','new_mod3')
    assert attribute3.name == 'attr3'
    assert attribute3.new_mod == 'new_mod3'
    assert attribute3.new_attr == 'attr3'

    attribute4 = MovedAttribute('attr4','mod4','new_mod4','attr4')

# Generated at 2022-06-23 23:04:40.530327
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert a2.name == "cStringIO"
    assert a2.new_mod == "io"
    assert a2.new_attr == a2.name

    a3 = MovedAttribute("cStringIO", "cStringIO")
    assert a3.name == "cStringIO"
    assert a3.new_mod == "cStringIO"
    assert a3.new_attr == a3.name


# Generated at 2022-06-23 23:04:49.954728
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    first = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    second = MovedAttribute("cStringIO", "cStringIO", "io")
    assert first.name == "cStringIO"
    assert first == second
    assert first.new_mod == "io"
    assert first.new_attr == "StringIO"
    assert second.new_attr == "cStringIO"
    assert first.__repr__() == "MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')"
    assert second.__repr__() == "MovedAttribute('cStringIO', 'cStringIO', 'io')"


# Generated at 2022-06-23 23:04:51.627723
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves' == SixMovesTransformer._get_rewrites()[0][1]

# Generated at 2022-06-23 23:04:58.244373
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.' in SixMovesTransformer.rewrites['io.StringIO']
    assert 'six.moves.' in SixMovesTransformer.rewrites['shlex.quote']
    assert 'six.moves.' in SixMovesTransformer.rewrites['shlex.quote']
    assert 'six.moves.' in SixMovesTransformer.rewrites['six.moves.urllib_parse.ParseResult']

# Unit tests for SixMovesTransformer

# Generated at 2022-06-23 23:05:05.853988
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformed = SixMovesTransformer('''\
from urllib.parse import urlparse
from urllib2 import urlopen
from urllib import parse
from urllib import request
from urllib import response
from urllib import robotparser
from robotparser import RobotFileParser
''')
    assert transformed == '''\
from six.moves.urllib_parse import urlparse
from six.moves.urllib.request import urlopen
from six.moves import urllib_parse as parse
from six.moves import urllib_request as request
from six.moves import urllib_response as response
from six.moves import urllib_robotparser as robotparser
from six.moves.urllib_robotparser import RobotFileParser
'''

# Generated at 2022-06-23 23:05:07.388388
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert repr(_get_rewrites()) == repr(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:05:08.427577
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None)

# Generated at 2022-06-23 23:05:14.608624
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "foo").new_attr == "foo"


# Generated at 2022-06-23 23:05:19.250362
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def assert_pairs_match(pairs1, pairs2):
        for pair in pairs1:
            assert pair in pairs2
            pairs2.remove(pair)
            assert pairs2 != []
    assert_pairs_match(SixMovesTransformer.rewrites,
                       list(_get_rewrites()))

# Generated at 2022-06-23 23:05:21.820878
# Unit test for constructor of class MovedModule
def test_MovedModule():
    testModule = MovedModule("testModule", "test", "test")
    assert testModule.name == "testModule"
    assert testModule.new == "test"
    assert testModule.old == "test"


# Generated at 2022-06-23 23:05:27.838993
# Unit test for constructor of class MovedModule
def test_MovedModule():
  assert MovedModule("moved_module", "unmoved_module").name == "moved_module"
  assert MovedModule("moved_module", "unmoved_module").new == "moved_module"
  assert MovedModule("moved_module", "unmoved_module", "new_module").new == "new_module"


# Generated at 2022-06-23 23:05:29.578868
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert set([p[0] for p in _get_rewrites()]) == set(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:05:31.689285
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import types
    assert(isinstance(SixMovesTransformer(''), types.ModuleType))

# Generated at 2022-06-23 23:05:32.313126
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer(): pass

# Generated at 2022-06-23 23:05:37.018225
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("foo", "mod", "new")
    assert m.name == "foo"
    assert m.old == "mod"
    assert m.new == "new"


# Generated at 2022-06-23 23:05:40.589430
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert (('sys.maxsize', 'six.moves.intern') in
            transformer.rewrites)
    assert transformer.dependencies == ['six']

# Generated at 2022-06-23 23:05:51.880424
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "name"
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_

# Generated at 2022-06-23 23:05:56.100710
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("urllib.parse", __name__ + ".moves.urllib_parse", "urllib.parse")
    assert x.name == "urllib.parse"
    assert x.new == "urllib.parse"


# Generated at 2022-06-23 23:06:05.863049
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:07.635576
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test SixMovesTransformer() constructor."""
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:09.491210
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    assert sys.version_info[:2] == SixMovesTransformer.target
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:15.251323
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == \
           MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter') == \
           MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse') == \
           MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')

# Generated at 2022-06-23 23:06:17.100733
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # -> test not needed: prefixed_moves is a global variable.
    pass



# Generated at 2022-06-23 23:06:27.425561
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test case for new_attr is None
    test_move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert test_move.name == 'cStringIO'
    assert test_move.new_mod == 'io'
    assert test_move.new_attr == 'cStringIO'

    # Test case for new_attr is not None
    test_move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'CStringIO')
    assert test_move.name == 'cStringIO'
    assert test_move.new_mod == 'io'
    assert test_move.new_attr == 'CStringIO'

# Generated at 2022-06-23 23:06:37.568734
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import types
    import ast

    assert isinstance(SixMovesTransformer.rewrites, types.GeneratorType)
    SixMovesTransformer.rewrites = tuple(SixMovesTransformer.rewrites)
    assert isinstance(SixMovesTransformer.rewrites, tuple)

    # Check that check_six() does not report error for the 'six' module.
    check_six = six.__getattribute__(six.create_bound_method(SixMovesTransformer.check_six, SixMovesTransformer))
    try:
        check_six()
    except SystemExit as e:
        assert e.code == 0

    # Check that the list of rewrites is correct.

# Generated at 2022-06-23 23:06:42.957591
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_obj = MovedAttribute(
        name="cStringIO", old_mod="cStringIO", new_mod="io",
        old_attr="StringIO", new_attr="StringIO")
    assert move_obj.name == "cStringIO"
    assert move_obj.new_mod == "io"
    assert move_obj.new_attr == "StringIO"



# Generated at 2022-06-23 23:06:49.540218
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('six', 'six')
    assert mm.name == 'six'
    assert mm.new == 'six'
    mm = MovedModule('six', 'six', 'six')
    assert mm.name == 'six'
    assert mm.new == 'six'
    mm = MovedModule('six', 'six', '7')
    assert mm.name == 'six'
    assert mm.new == '7'



# Generated at 2022-06-23 23:06:50.998386
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites()

# Generated at 2022-06-23 23:06:56.256475
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """This is a test for SixMovesTransformer.
    It checks if the rewrites in the constructor are correct
    """
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                expected = 'six.moves{}.{}'.format(prefix, move.name)
            elif isinstance(move, MovedModule):
                path = move.new
                expected = 'six.moves{}.{}'.format(prefix, move.name)
            assert (path, expected) in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:07:01.534918
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    from six.moves import html_parser
    from .moves.urllib import request

    assert sys.version_info.major == 2
    assert 'six' in sys.modules
    
    assert SixMovesTransformer.check_dependencies()
    assert SixMovesTransformer.check_target()

    assert html_parser
    assert request

# Generated at 2022-06-23 23:07:04.299047
# Unit test for constructor of class MovedModule
def test_MovedModule():
    for mm in _moved_attributes:
        if not isinstance(mm, MovedModule):
            continue
        assert mm.name == mm.new

# Generated at 2022-06-23 23:07:11.212953
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("a", "b", "c")
    assert test.name == "a"
    assert test.old == "b"
    assert test.new == "c"
    test1 = MovedModule("a", "b")
    assert test1.new == "a"
    test2 = MovedModule("a", "b", None)
    assert test2.new == "a"

# Generated at 2022-06-23 23:07:16.328769
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma1.name == 'cStringIO'
    assert ma1.new_mod == 'io'
    assert ma1.new_attr == 'StringIO'

    ma2 = MovedAttribute("cStringIO", None, None, 'StringIO')
    assert ma2.name == 'cStringIO'
    assert ma2.new_mod == 'cStringIO'
    assert ma2.new_attr == 'StringIO'

# Generated at 2022-06-23 23:07:17.979618
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    module.name
    module.old
    module.new



# Generated at 2022-06-23 23:07:20.705112
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('test_name', 'test_old')
    assert moved_module.name == 'test_name'
    assert moved_module.new == 'test_name'


# Generated at 2022-06-23 23:07:29.955508
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("str", "str", "str").new_mod == "str"
    assert MovedAttribute("str", None, None).new_mod == "str"
    assert MovedAttribute("str", "str", None).new_mod == "str"
    assert MovedAttribute("str", "str", "str", "c", "a").new_attr == "a"
    assert MovedAttribute("str", "str", "str", "c").new_attr == "c"
    assert MovedAttribute("str", "str", None, "c").new_attr == "c"
    assert MovedAttribute("str", "str", None).new_attr == "str"



# Generated at 2022-06-23 23:07:39.977869
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

# Generated at 2022-06-23 23:07:42.144494
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)

    assert len(transformer.rewrites) == 58

# Generated at 2022-06-23 23:07:49.815575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("builtins", "__builtin__")
    assertEquals(a.name, "builtins")
    assertEquals(a.old, "__builtin__")
    assertEquals(a.new, "builtins")

    b = MovedModule("builtins", "__builtin__", "builtins")
    assertEquals(b.name, "builtins")
    assertEquals(b.old, "__builtin__")
    assertEquals(b.new, "builtins")

# Generated at 2022-06-23 23:07:54.937317
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'
    moved_module = MovedModule("name", "old")
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'name'


# Generated at 2022-06-23 23:07:59.876733
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-23 23:08:04.696310
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old", "name")
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")



# Generated at 2022-06-23 23:08:13.990174
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six
    MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    MovedAttribute('intern', '__builtin__', 'sys')
    MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map')
    MovedAttribute('getcwd', 'os', 'os', 'getcwdu', 'getcwd')

# Generated at 2022-06-23 23:08:19.310132
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-23 23:08:23.931830
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None)
    assert t.target == (2, 7)
    assert len(t.rewrites) == len(_get_rewrites())
    for rewrite in t.rewrites:
        assert rewrite in _get_rewrites()
    assert t.dependencies == ['six']

# Generated at 2022-06-23 23:08:34.424428
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__") == MovedModule("builtins", "__builtin__")
    assert MovedModule("configparser", "ConfigParser") == MovedModule("configparser", "ConfigParser")
    assert MovedModule("copyreg", "copy_reg") == MovedModule("copyreg", "copy_reg")
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu") == MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread") == MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread")

# Generated at 2022-06-23 23:08:39.957030
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_module = MovedModule("name", "old")
    assert a_module.name == "name"
    assert a_module.old == "old"
    assert a_module.new == "name"
    b_module = MovedModule("name", "old", "new")
    assert b_module.name == "name"
    assert b_module.old == "old"
    assert b_module.new == "new"



# Generated at 2022-06-23 23:08:45.375632
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.old == "old"
    assert a.new == "new"

    b = MovedModule("name")
    assert b.name == "name"
    assert b.old == "name"
    assert b.new == "name"



# Generated at 2022-06-23 23:08:46.454066
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-23 23:08:50.697313
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import sys
    import six
    if sys.version_info[0:2] < (2, 7):
        assert sys.modules['urllib'] == six.moves.urllib
    else:
        assert six.moves.urllib is None

# Generated at 2022-06-23 23:08:58.653624
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..tools import assert_equal
    class Dummy(Exception): pass
    try:
        raise Dummy('here')
    except Dummy as e:
        tb = e.__traceback__

    rt = RewriterTool.from_individual_transforms(SixMovesTransformer())
    assert_equal(rt.rewrite_file('subprocess', tb), 'six.moves.subprocess')
    assert_equal(rt.rewrite_file('subprocess.call', tb), 'six.moves.subprocess.call')

# Generated at 2022-06-23 23:09:03.935252
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute(
        "cStringIO", "cStringIO", "io", "StringIO")
    assert test_moved_attribute.name == "cStringIO"
    assert test_moved_attribute.new_mod == "io"
    assert test_moved_attribute.new_attr == "StringIO"



# Generated at 2022-06-23 23:09:11.091009
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:09:18.173870
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.old == "__builtin__"
    assert module.new == "builtins"

    module = MovedModule("builtins", "__builtin__", "six.moves.builtins")
    assert module.name == "builtins"
    assert module.old == "__builtin__"
    assert module.new == "six.moves.builtins"
