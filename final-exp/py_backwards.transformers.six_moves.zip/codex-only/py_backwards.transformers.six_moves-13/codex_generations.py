

# Generated at 2022-06-23 22:59:25.433732
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 22:59:34.588830
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod")
    assert (ma.name == "name")
    assert (ma.new_mod == "name")
    assert (ma.new_attr == "name")

    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert (ma.name == "name")
    assert (ma.new_mod == "name")
    assert (ma.new_attr == "old_attr")

    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert (ma.name == "name")
    assert (ma.new_mod == "name")
    assert (ma.new_attr == "new_attr")

    ma = MovedAttribute("name")

# Generated at 2022-06-23 22:59:36.151879
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("math", "math", "math")
    assert mm.name == "math"
    assert mm.new == "math"

# Generated at 2022-06-23 22:59:40.274644
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    foo = MovedAttribute("foo", "bar", "baz", "quux", "quux-quux")
    assert foo.name == "foo"
    assert foo.new_mod == "baz"
    assert foo.new_attr == "quux-quux"
    foo = MovedAttribute("foo", "bar", "baz", "quux")
    assert foo.new_attr == "quux"
    foo = MovedAttribute("foo", "bar", "baz")
    assert foo.new_attr == "foo"


# Generated at 2022-06-23 22:59:44.267699
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_mod = MovedModule('name', 'old', 'new')
    assert moved_mod.name == 'name'
    assert moved_mod.old == 'old'
    assert moved_mod.new == 'new'


# Generated at 2022-06-23 22:59:54.813562
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 22:59:58.652729
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.fixes import Fix
    from libfuturize.fixes.sixmoves import SixMovesTransformer
    assert Fix.__subclasshook__(SixMovesTransformer)
    _get_rewrites()  # includes an eager(...) that is hard to test otherwise

# Generated at 2022-06-23 23:00:08.208676
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer('six.moves')
    assert transformer.dependencies == ['six']
    assert transformer.rewrites == SixMovesTransformer.rewrites   # look at the class
    transformer = SixMovesTransformer('six.moves', dependencies=['six'], rewrites=_get_rewrites)
    assert transformer.dependencies == ['six']
    assert transformer.rewrites == SixMovesTransformer.rewrites   # look at the class
    transformer = SixMovesTransformer('six.moves', dependencies=['six'], rewrites=None)
    assert transformer.dependencies == ['six']
    assert transformer.rewrites == _get_rewrites()   # look at the class
    transformer = SixMovesTransformer('six.moves', dependencies=None, rewrites=_get_rewrites)


# Generated at 2022-06-23 23:00:10.149402
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 125

# Generated at 2022-06-23 23:00:14.254954
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("test", "old", "new")
    assert test_module.name == "test"
    assert test_module.new == "new"
    assert test_module.old == "old"



# Generated at 2022-06-23 23:00:16.679283
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = [MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")]
    assert test == _moved_attributes[0:1]


# Generated at 2022-06-23 23:00:19.506553
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule("math", "math")
    assert test_moved_module.name == "math"
    assert test_moved_module.new == "math"

# Generated at 2022-06-23 23:00:22.241132
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
	x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
	assert x.name == "cStringIO"
	assert x.new_mod == "io"
	assert x.new_attr == "StringIO"

# Generated at 2022-06-23 23:00:28.298809
# Unit test for constructor of class MovedModule
def test_MovedModule():
    result = MovedModule("name", "old", "new")
    assert result.name == "name"
    assert result.old == "old"
    assert result.new == "new"
    result = MovedModule("name", "old")
    assert result.name == "name"
    assert result.old == "old"
    assert result.new == "name"

# Generated at 2022-06-23 23:00:30.498828
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_object = MovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert test_object.name == "name"
    assert test_object.new_mod == "new"
    assert test_object.new_attr == "new_attr"


# Generated at 2022-06-23 23:00:31.404410
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer._get_rewrites() == tuple(_get_rewrites())

# Generated at 2022-06-23 23:00:33.943209
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Assert it contains all attributes in _get_rewrites()
    assert list(_get_rewrites()) == SixMovesTransformer.rewrites
    # Assert it has the right dependencies
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:00:36.780715
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "dbm_gnu"
    old = "gdbm"
    new = "dbm.gnu"
    assert new == MovedModule(name, old, new).new


# Generated at 2022-06-23 23:00:47.874752
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute("name", "old_mod", "new_mod")
    assert move1.name == "name"
    assert move1.new_mod == "new_mod"
    assert move1.new_attr == "name"
    move2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move2.name == "name"
    assert move2.new_mod == "new_mod"
    assert move2.new_attr == "new_attr"
    move3 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert move3.name == "name"
    assert move3.new_mod == "new_mod"
    assert move3.new_attr == "old_attr"


# Generated at 2022-06-23 23:00:51.297969
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-23 23:00:57.552943
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # The constructor should configure the rewrites object
    # as a list of tuples ordered by the first item of the tuple.
    smt = SixMovesTransformer()
    prev_rewrite_from = ''
    for rewrite_from, rewrite_to in smt.rewrites:
        assert(prev_rewrite_from <= rewrite_from)
        prev_rewrite_from = rewrite_from


# Generated at 2022-06-23 23:00:58.639348
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:01:08.901894
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("a", "b", "c", "f", "g")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "g"

    a = MovedAttribute("a", "b", "c", "f")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "f"

    a = MovedAttribute("a", "b", "c")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "a"

    a = MovedAttribute("a", "b")
    assert a.name == "a"
    assert a.new_mod == "a"
    assert a.new

# Generated at 2022-06-23 23:01:11.764787
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.new == "new"


# Generated at 2022-06-23 23:01:15.240362
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('name', 'old', 'new')
    assert x.name == 'name'
    assert x.old == 'old'
    assert x.new == 'new'


# Generated at 2022-06-23 23:01:17.260448
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test', 'old') == MovedModule('test', 'old', 'test')

# Generated at 2022-06-23 23:01:23.081525
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)
    assert (
        '{}.{}'.format('functools', 'reduce')
        in SixMovesTransformer.rewrites)
    assert '{}.{}'.format('tkinter', 'tkinter') not in SixMovesTransformer.rewrites
    assert '{}.{}'.format('tkinter', 'dnd') in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:01:25.501514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test for constructor of class MovedModule"""
    with pytest.raises(AssertionError):
        MovedModule("a","b","c","d")

# Generated at 2022-06-23 23:01:35.578966
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.dependencies == ["six"]

# Generated at 2022-06-23 23:01:38.855835
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('configparser', 'ConfigParser')
    assert moved_module.name == 'configparser'
    assert moved_module.old == 'ConfigParser'
    assert moved_module.new == 'configparser'


# Generated at 2022-06-23 23:01:41.002489
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    stt = SixMovesTransformer()
    assert stt.rewrites

# Generated at 2022-06-23 23:01:44.258702
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr is None


# Generated at 2022-06-23 23:01:47.023776
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"


# Generated at 2022-06-23 23:01:54.304908
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new"
    assert moved_attribute.new_attr == "new_attr"

    moved_attribute = MovedAttribute("name", "old", "new", "old_attr", None)
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new"
    assert moved_attribute.new_attr == "old_attr"

    moved_attribute = MovedAttribute("name", "old", "new", None, "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new"

# Generated at 2022-06-23 23:02:01.357717
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m_a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m_a.name == "cStringIO"
    assert m_a.new_mod == "io"
    assert m_a.new_attr == "StringIO"
    assert m_a.__str__() == "[cStringIO, cStringIO, io, StringIO, None]"
    assert m_a.__repr__() == "[cStringIO, cStringIO, io, StringIO, None]"



# Generated at 2022-06-23 23:02:04.570273
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """This is a unit test for the constructor of class SixMovesTransformer."""
    # This test is designed to make sure that the class can be instantiated.
    assert SixMovesTransformer()

# Generated at 2022-06-23 23:02:06.288211
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    r = SixMovesTransformer()
    assert r.dependencies == ['six']



# Generated at 2022-06-23 23:02:16.891072
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # We should be able to construct a MovedAttribute using the default 'new_attr'
    # which is the same as 'name'.
    a1 = MovedAttribute("name", "old_mod", "new_mod")
    assert a1.name == "name"
    assert a1.old_mod == "old_mod"
    assert a1.new_mod == "new_mod"
    assert a1.new_attr == "name"
    assert a1.old_attr is None
    assert str(a1) == "MovedAttribute(name='name', old_mod='old_mod', new_mod='new_mod')"

    # We should be able to construct a MovedAttribute when 'new_attr' is also passed in.

# Generated at 2022-06-23 23:02:19.863797
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    for k, v in transformer.rewrites.items():
        assert k in six.moves.__dict__
        assert v in six.moves.__dict__



# Generated at 2022-06-23 23:02:30.992356
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from favor.refactor.reporter import Reporter
    from favor.refactor.source import Source
    assert len(SixMovesTransformer.rewrites) > 0
    mock_source = Source('import pandas')
    mock_reporter = Reporter(mock_source, [], [], [])
    mock_fixer = SixMovesTransformer(mock_reporter)
    assert 'six.moves' in str(mock_fixer)
    assert 'pandas' in str(mock_fixer)
    assert 'six.moves.urllib_robotparser' in str(mock_fixer)
    assert mock_fixer.source == mock_source
    assert mock_fixer.reporter == mock_reporter
    assert mock_fixer.globals is None

# Generated at 2022-06-23 23:02:36.433252
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'

# Generated at 2022-06-23 23:02:40.537484
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert (move.name == "name")
    assert (move.new_mod == "new_mod")
    assert (move.new_attr == "new_attr")

# Generated at 2022-06-23 23:02:51.563468
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:03:03.323000
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert(len(SixMovesTransformer.rewrites) == len(_moved_attributes) - 1 + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes))
    assert(list(SixMovesTransformer.rewrites)[0] == ('io.StringIO', 'six.moves.cStringIO'))
    assert(list(SixMovesTransformer.rewrites)[-1] == ('urllib.robotparser.RobotFileParser', 'six.moves.urllib_robotparser.RobotFileParser'))

# Generated at 2022-06-23 23:03:09.625658
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "range"
    old_mod = "__builtin__"
    new_mod = "builtins"
    old_attr = "xrange"
    new_attr = "range"
    move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert move.name == name
    assert move.new_mod == new_mod
    assert move.new_attr == new_attr


# Generated at 2022-06-23 23:03:15.789431
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(AssertionError):
        MovedModule(None, None)

    moved_module = MovedModule('hello', 'old')
    assert moved_module.name == 'hello'
    assert moved_module.old == 'old'
    assert moved_module.new == 'old'

    moved_module = MovedModule('hello', 'old', 'new')
    assert moved_module.name == 'hello'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'


# Generated at 2022-06-23 23:03:24.830630
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod') == MovedAttribute('name', 'old_mod', 'new_mod')
    assert MovedAttribute('name', 'old_mod', 'new_mod') != MovedAttribute('name1', 'old_mod', 'new_mod')
    assert MovedAttribute('name', 'old_mod', 'new_mod') != MovedAttribute('name', 'old_mod1', 'new_mod')
    assert MovedAttribute('name', 'old_mod', 'new_mod') != MovedAttribute('name', 'old_mod', 'new_mod1')



# Generated at 2022-06-23 23:03:26.866410
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    for import_from, import_to in transformer.rewrites:
        assert import_to.startswith('six.moves')
        assert set(import_from.split('.')).issubset(set(import_to.split('.')))

# Generated at 2022-06-23 23:03:35.226693
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites[0] == ('builtins.filter', 'six.moves.filter')
    assert transformer.dependencies == ['six']

if __name__ == '__main__':
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.abspath('..'))

    class TestCase(unittest.TestCase):
        def test_get_rewrites(self):
            rewrites = _get_rewrites()
            assert rewrites[0] == ('builtins.filter', 'six.moves.filter')
            assert rewrites[1] == ('builtins.filterfalse', 'six.moves.filterfalse')


# Generated at 2022-06-23 23:03:46.839773
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == dict(_get_rewrites())

# Test for SixMovesTransformer.transform

# Generated at 2022-06-23 23:03:54.463579
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test of the SixMovesTransformer constructor.
    """

# Generated at 2022-06-23 23:03:59.836958
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('herp', 'derp', 'derp')
    assert m.__dict__ == {'name': 'herp', 'old': 'derp', 'new': 'derp'}

    m = MovedModule('herp', 'derp')
    assert m.__dict__ == {'name': 'herp', 'old': 'derp', 'new': 'herp'}


# Generated at 2022-06-23 23:04:02.691071
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.parse import ParseError
    x = SixMovesTransformer()
    try:
        x.pattern
    except ParseError:
        return False
    return True

# Generated at 2022-06-23 23:04:03.513669
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 118

# Generated at 2022-06-23 23:04:10.234102
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert (a1.name is a1.new_attr is a1.new_mod is "cStringIO")

    a2 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert (a2.name == a2.old_attr == "filter")
    assert (a2.old_mod == a2.new_mod == "builtins")
    assert (a2.new_attr == "ifilter")

    a3 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert (a3.old_attr is a3.new_attr is "input")

# Generated at 2022-06-23 23:04:15.885762
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("alabala", "alabala")
    assert module.name == "alabala"
    assert module.new == "alabala"
    module = MovedModule("alabala", "alabala", "alabala2")
    assert module.name == "alabala"
    assert module.new == "alabala2"

# Generated at 2022-06-23 23:04:20.347827
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

# Generated at 2022-06-23 23:04:31.873296
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import os

    if sys.version_info[0] == 2 and sys.version_info[1] == 7:
        if 'six' not in sys.modules:
            six = __import__('six')
        else:
            six = sys.modules['six']

        if 'six.moves' not in sys.modules:
            six_moves = __import__('six.moves')
        else:
            six_moves = sys.modules['six.moves']

        if 'six.moves.urllib' not in sys.modules:
            six_urllib = __import__('six.moves.urllib')
        else:
            six_urllib = sys.modules['six.moves.urllib']


# Generated at 2022-06-23 23:04:36.477462
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    assert moved_module.old == "__builtin__"
    moved_module = MovedModule("cPickle", "cPickle", "pickle")
    assert moved_module.name == "cPickle"
    assert moved_module.new == "pickle"
    assert moved_module.old == "cPickle"


# Generated at 2022-06-23 23:04:43.783808
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"
    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"
    move = MovedAttribute("filter", "itertools", "builtins")

# Generated at 2022-06-23 23:04:44.906397
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer(None)

# Generated at 2022-06-23 23:04:48.705036
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'foo'
    old = 'bar'
    new = 'baz'
    mm = MovedModule(name, old, new)
    assert mm.name == name
    assert mm.new == new
    assert mm.old == old


# Generated at 2022-06-23 23:04:59.019065
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    from .six_moves import SixMovesTransformer
    from .six_moves import _get_rewrites

    # Tests for a class inheriting from BaseImportRewrite
#	print("type(SixMovesTransformer) =", type(SixMovesTransformer))
    assert issubclass(SixMovesTransformer, BaseImportRewrite)

    # Unit test for _get_rewrites()
#	print("SixMovesTransformer.rewrites =", SixMovesTransformer.rewrites, "\n")
    assert SixMovesTransformer.rewrites == _get_rewrites()
#	print("_get_rewrites() =", _get_rewrites(), "\n")
#	print("type(_get_rewrites()) =", type(_get_rewrites()), "\n")
#	

# Generated at 2022-06-23 23:04:59.667120
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:04.177050
# Unit test for constructor of class MovedModule
def test_MovedModule():
    normal_module_move = MovedModule("test", "oldtest")
    assert "test" == normal_module_move.name
    assert "oldtest" == normal_module_move.old
    assert "test" == normal_module_move.new
    module_move_wo_new = MovedModule("test", "oldtest", None)
    assert None is module_move_wo_new.new
    # With a new value in the call, the new value is set
    module_move_w_new = MovedModule("test", "oldtest", "newtest")
    assert "newtest" == module_move_w_new.new



# Generated at 2022-06-23 23:05:11.997147
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from .mytest import MyTest
    mytest = MyTest(MovedAttribute, 'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    mytest.constructor()
    mytest.constructor('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    mytest.constructor('name', 'old_mod', 'new_mod', old_attr='old_attr', new_attr='new_attr')
    mytest.constructor('name', 'old_mod', 'new_mod', new_attr='new_attr')
    mytest.constructor('name', 'old_mod', 'new_mod')
    mytest.constructor('name', 'old_mod')
    mytest.constructor('name')


# Generated at 2022-06-23 23:05:14.934168
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("moved", "src").name == "moved"
    assert MovedModule("moved", "src").new == "moved"
    assert MovedModule("moved", "src", "dst").name == "moved"
    assert MovedModule("moved", "src", "dst").new == "dst"

# Generated at 2022-06-23 23:05:19.302015
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # TODO
    assert MovedModule("a", "b")
    assert MovedModule("a", "b", "c")
    # TODO write the unit test for the MovedAttribute class
    assert MovedAttribute("a", "b", "c")

# Generated at 2022-06-23 23:05:24.805870
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"



# Generated at 2022-06-23 23:05:33.617300
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:43.904529
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'StringIO'

    ma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma.name == "cStringIO"
    assert ma.new_mod == 'io'
    assert ma.new_attr == 'cStringIO'

    ma = MovedAttribute("cStringIO", "cStringIO", None)
    assert ma.name == "cStringIO"
    assert ma.new_mod == 'cStringIO'
    assert ma.new_attr == 'cStringIO'

# Generated at 2022-06-23 23:05:46.093149
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    m = SixMovesTransformer()
    assert len(m.rewrites) == len(_get_rewrites())

# Generated at 2022-06-23 23:05:47.042469
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.UserString' in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:05:58.092610
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert hasattr(SixMovesTransformer, '__annotations__'), "SixMovesTransformer should have type annotations"
    assert hasattr(SixMovesTransformer, 'target'), "SixMovesTransformer should have attribute 'target'"
    # test_SixMovesTransformer_target_type
    assert isinstance(SixMovesTransformer.target, tuple), "SixMovesTransformer.target should be a tuple"
    # test_SixMovesTransformer_rewrites_exists
    assert hasattr(SixMovesTransformer, 'rewrites'), "SixMovesTransformer should have attribute 'rewrites'"
    # test_SixMovesTransformer_rewrites_type
    assert isinstance(SixMovesTransformer.rewrites, dict), "SixMovesTransformer.rewrites should be a dict"
    # test_SixMovesTransformer

# Generated at 2022-06-23 23:06:00.927146
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("foo", "bar", "foobar")
    assert module.name == "foo"
    assert module.new == "foobar"


# Generated at 2022-06-23 23:06:05.238437
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("new", "old").name == "new"
    assert MovedModule("new", "old").new == "new"
    assert MovedModule("name", "new", "old").name == "name"
    assert MovedModule("name", "new", "old").new == "new"

# Generated at 2022-06-23 23:06:08.873402
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_example = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_example.name == "cStringIO"
    assert move_example.new_mod == "io"
    assert move_example.new_attr == "StringIO"

# Generated at 2022-06-23 23:06:16.468701
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:25.314190
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attr.name == 'cStringIO'
    assert moved_attr.new_mod == 'io'
    assert moved_attr.new_attr == 'StringIO'
    
    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attr.name == 'cStringIO'
    assert moved_attr.new_mod == 'io'
    assert moved_attr.new_attr == 'cStringIO'


# Generated at 2022-06-23 23:06:26.402419
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer(None, None)

# Generated at 2022-06-23 23:06:36.834706
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("filter", "itertools", "itertools").new_mod == "itertools"
    assert MovedAttribute("filter", "itertools", "builtins").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins").new_attr == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "ifilter"
    assert MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO").new

# Generated at 2022-06-23 23:06:40.225680
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    passed = True
    try:
        MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    except:
        passed = False
    assert passed



# Generated at 2022-06-23 23:06:48.993969
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    assert MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    assert MovedAttribute('intern', '__builtin__', 'sys')
    assert MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map')
    assert MovedAttribute('getcwd', 'os', 'os', 'getcwdu', 'getcwd')

# Generated at 2022-06-23 23:06:56.470890
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule('foo', 'bar')
    assert test_module.name == 'foo'
    assert test_module.old == 'bar'
    assert test_module.new == 'foo'

    test_module = MovedModule('foo', 'bar', 'baz')
    assert test_module.name == 'foo'
    assert test_module.old == 'bar'
    assert test_module.new == 'baz'

    # with pytest.raises(TypeError):
    #     MovedModule('foo', 'bar', 'baz', 'x')


# Generated at 2022-06-23 23:07:08.505044
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("xrange", "__builtin__", "builtins", "xrange", "range")
    assert item.name == "xrange"
    assert item.new_mod == "builtins"
    assert item.new_attr == "range"
    item = MovedAttribute("xrange", "__builtin__", "builtins")
    assert item.name == "xrange"
    assert item.new_mod == "builtins"
    assert item.new_attr == "xrange"
    item = MovedAttribute("xrange", "__builtin__", "builtins", "xrange", None)
    assert item.name == "xrange"
    assert item.new_mod == "builtins"
    assert item.new_attr == "xrange"

# Generated at 2022-06-23 23:07:10.632493
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import_ = BaseImportRewrite(target=(2,7))
    assert import_.target == (2,7)

# Generated at 2022-06-23 23:07:13.741454
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']



# Generated at 2022-06-23 23:07:16.288872
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("abc", "abc", "abc")
    assert moved_module.name == "abc"
    assert moved_module.new == "abc"



# Generated at 2022-06-23 23:07:24.918509
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("foo", "old_mod", "new_mod",
            old_attr="old_attr", new_attr="new_attr")
    assert move.name == "foo"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"

    move = MovedAttribute("foo", "old_mod", "new_mod")
    assert move.name == "foo"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "foo"

    move = MovedAttribute("foo", "old_mod", "new_mod",
            old_attr="old_attr")
    assert move.name == "foo"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "old_attr"

# Generated at 2022-06-23 23:07:27.443732
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"


# Generated at 2022-06-23 23:07:29.257209
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for path, rewrite in _get_rewrites():
        assert SixMovesTransformer.rewrites[path] == rewrite

# Generated at 2022-06-23 23:07:31.755423
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert instance.target == (2, 7)
    assert instance.dependencies == ['six']

# Generated at 2022-06-23 23:07:41.173615
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves
    six.moves.builtins
    six.moves.configparser
    six.moves.copyreg
    six.moves.dbm_gnu
    six.moves._dummy_thread
    six.moves.http_cookiejar
    six.moves.http_cookies
    six.moves.html_entities
    six.moves.html_parser
    six.moves.http_client
    six.moves.email_mime_base
    six.moves.email_mime_image
    six.moves.email_mime_multipart
    six.moves.email_mime_nonmultipart
    six.moves.email_mime_text
    six.moves.BaseHTTPServer
    six.moves

# Generated at 2022-06-23 23:07:43.815017
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module = MovedModule('queue', 'Queue')
    assert move_module.name == 'queue'
    assert move_module.new == 'queue'

# Generated at 2022-06-23 23:07:48.767776
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movemod = MovedModule("math", "math")
    assert movemod.name == "math"
    assert movemod.new == "math"
    movemod = MovedModule("math", "math", "numpy")
    assert movemod.name == "math"
    assert movemod.new == "numpy"

# Generated at 2022-06-23 23:07:49.516876
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:07:53.138866
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_mm = MovedModule("winreg", "_winreg")
    assert len(test_mm.__dict__) == 3
    assert (test_mm.name == "winreg")
    assert (test_mm.old == "_winreg")
    assert (test_mm.new == "winreg")

# Generated at 2022-06-23 23:07:57.485061
# Unit test for constructor of class MovedModule
def test_MovedModule():
    expected_name = "name"
    expected_old = "old"
    expected_new = "new"

    mm = MovedModule(expected_name, expected_old, expected_new)

    assert mm.name == expected_name
    assert mm.new == expected_new

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:08:02.521455
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").old == "__builtin__"
    assert MovedModule("builtins", "__builtin__").new == "builtins"

# Generated at 2022-06-23 23:08:07.794065
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    name = "six.moves.cStringIO"
    module = "six.moves"
    obj = "cStringIO"
    moved_obj = "StringIO"
    other_module = "io"
    test = SixMovesTransformer(name, module, obj, moved_obj, other_module)
    assert test is not None


# Generated at 2022-06-23 23:08:10.291479
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule.__name__ == 'MovedModule'
    MovedModule('name', 'old', 'new')
    MovedModule('name', 'old')

# Generated at 2022-06-23 23:08:16.317807
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'name'

    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-23 23:08:27.810250
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_list = MovedAttribute('f', 'a', 'b')
    assert test_list.name == 'f'
    assert test_list.new_mod == 'a'
    assert test_list.new_attr == 'f'
    test_list = MovedAttribute('f', 'a', 'b', 'c', 'd')
    assert test_list.name == 'f'
    assert test_list.new_mod == 'b'
    assert test_list.new_attr == 'd'
    test_list = MovedAttribute('f', 'a', 'b', 'c')
    assert test_list.name == 'f'
    assert test_list.new_mod == 'b'
    assert test_list.new_attr == 'c'



# Generated at 2022-06-23 23:08:35.772042
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('builtins', '__builtin__')
    MovedModule('configparser', 'ConfigParser')
    MovedModule('copyreg', 'copy_reg')
    MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    MovedModule('http_cookiejar', 'cookielib', 'http.cookiejar')
    MovedModule('http_cookies', 'Cookie', 'http.cookies')
    MovedModule('html_entities', 'htmlentitydefs', 'html.entities')
    MovedModule('html_parser', 'HTMLParser', 'html.parser')
    MovedModule('http_client', 'httplib', 'http.client')

# Generated at 2022-06-23 23:08:41.132224
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

# Generated at 2022-06-23 23:08:51.022543
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test that, for any move in prefixed_moves, a Rewrite object is created
    for _, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert (path, 'six.moves.{}'.format(move.name)) in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves.{}'.format(move.name)) in SixMovesTransformer.rewrites

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:08:56.807533
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'foo'

    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'baz'

# Generated at 2022-06-23 23:09:02.709794
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import types
    SixMovesTransformer.dependencies = []
    SixMovesTransformer.rewrites = []
    s = SixMovesTransformer()
    assert isinstance(s, BaseImportRewrite)
    assert isinstance(s.dependencies, list)
    assert isinstance(s.rewrites, list)
    assert isinstance(s.target, tuple)
    assert s.target == (2, 7)

# Generated at 2022-06-23 23:09:07.326292
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("module", "oldmodule")
    assert m.name == 'module'
    assert m.old == 'oldmodule'
    assert m.new == 'module'

    m = MovedModule("module", "oldmodule", "newmodule")
    assert m.name == 'module'
    assert m.old == 'oldmodule'
    assert m.new == 'newmodule'



# Generated at 2022-06-23 23:09:11.934533
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("name", "old_mod", "new_mod")
    assert x.name == "name"
    assert x.new_mod == "new_mod"
    assert x.new_attr == "name"
    assert x



# Generated at 2022-06-23 23:09:14.400547
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("name", "old")
    assert move.name == "name"
    assert move.new == "name"


# Generated at 2022-06-23 23:09:19.758250
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('foo', 'bar', None)
    assert ma.name == 'foo'
    assert ma.new_mod == 'foo'
    assert ma.new_attr == 'foo'

    # Ensure that the 'foo' module is in the list of rewrites.
    assert 'foo.foo' in [first for (first, second) in SixMovesTransformer.rewrites]
