

# Generated at 2022-06-23 22:59:18.595724
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('test_MovedModule', 'tmm1', 'tmm2')
    assert mm.name == 'test_MovedModule'
    assert mm.new == 'tmm2'
    mm = MovedModule('test_MovedModule', 'tmm1')
    assert mm.name == 'test_MovedModule'
    assert mm.new == 'tmm1'

# Generated at 2022-06-23 22:59:23.910434
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old")
    assert module.name == "name"
    assert module.new == "name"
    assert module.old == "old"
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.new == "new"
    assert module.old == "old"


# Generated at 2022-06-23 22:59:29.761358
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins', \
        'Value of name is not equal to the name of module'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser', \
        'Value of new is not equal to the name of module'
    assert MovedModule('socketserver', 'SocketServer').old == 'SocketServer', \
        'Value of old is not equal to the name of module'

# Generated at 2022-06-23 22:59:32.425768
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert "name" in m.name
    assert "old" in m.old
    assert "new" in m.new


# Generated at 2022-06-23 22:59:39.202886
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'
    # SixMovesTransformer.rewrites test
    assert _get_rewrites()[0] == ('tkinter.__init__', 'six.moves.tkinter')


# Generated at 2022-06-23 22:59:50.177672
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MA = MovedAttribute
    assert MA("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MA("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MA("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MA("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MA("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MA("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"
    assert MA("filter", "itertools", "builtins").new_attr == "filter"
    assert MA

# Generated at 2022-06-23 22:59:53.672094
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('xxx', 'yyy', 'zzz')
    assert obj.name == 'xxx'
    assert obj.new_mod == 'zzz'
    assert obj.new_attr == 'xxx'



# Generated at 2022-06-23 22:59:58.699583
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer({'six': 'six'})
    assert(x.rewrites == list(SixMovesTransformer._get_rewrites()))
    assert(x.target == SixMovesTransformer.target)
    assert(x.dependencies == SixMovesTransformer.dependencies)
    assert(x.dependency_sources == {})

# Generated at 2022-06-23 23:00:08.247565
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for name, old_mod, new_mod
    item = MovedAttribute("cStringIO", "cStringIO", "io")
    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "cStringIO"
    # Test for old_attr, new_attr
    item = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "BytesIO")
    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "BytesIO"
    # Test for None values
    item = MovedAttribute("cStringIO", None, None)
    assert item.name == "cStringIO"
    assert item.new_mod == "cStringIO"
   

# Generated at 2022-06-23 23:00:10.128292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    paths = _get_rewrites()
    for path in paths:
        print(path)


if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:00:18.834107
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('socketserver', 'SocketServer')
    assert mm.name == 'socketserver'
    assert mm.old == 'SocketServer'
    assert mm.new == 'socketserver'

    mm = MovedModule('socketserver', 'SocketServer', 'socketserver')
    assert mm.name == 'socketserver'
    assert mm.old == 'SocketServer'
    assert mm.new == 'socketserver'

    mm = MovedModule('socketserver', 'SocketServer', 'socket')
    assert mm.name == 'socketserver'
    assert mm.old == 'SocketServer'
    assert mm.new == 'socket'

# Generated at 2022-06-23 23:00:25.496305
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_cases = [
        ('a','b'),
        ('a','a','a'),
        ('a','b','b'),
        ('a','b','c'),
        ('a','b','a'),
        ('a','b','c','d')
    ]

    for (name, old, new) in test_cases:
        test_case = MovedModule(name, old, new)
        assert test_case.name == name
        assert test_case.new == new
        assert test_case.old == old

# Generated at 2022-06-23 23:00:29.803909
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-23 23:00:30.445188
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 317

# Generated at 2022-06-23 23:00:33.714612
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_obj.name == "cStringIO"
    assert test_obj.new_mod == "cStringIO"
    assert test_obj.new_attr == "StringIO"


# Generated at 2022-06-23 23:00:43.528450
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mod = MovedAttribute('', '', '')
    assert mod.name == ''
    assert mod.new_mod == ''
    assert mod.new_attr == ''

    mod = MovedAttribute('name', 'old_mod', 'new_mod')
    assert mod.name == 'name'
    assert mod.new_mod == 'new_mod'
    assert mod.new_attr == 'name'

    mod = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert mod.name == 'name'
    assert mod.new_mod == 'new_mod'
    assert mod.new_attr == 'new_attr'

    mod = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert mod.name == 'name'

# Generated at 2022-06-23 23:00:55.176656
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, object)
    assert isinstance(SixMovesTransformer, type)
    # SixMovesTransformer is the constructor of class SixMovesTransformer
    assert isinstance(SixMovesTransformer, type)
    # base class for SixMovesTransformer is BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    # instantiate the SixMovesTransformer class
    assert isinstance(SixMovesTransformer(), SixMovesTransformer)
    # target of SixMovesTransformer is (2, 7)
    assert SixMovesTransformer.target == (2, 7)
    # length of rewrites of SixMovesTransformer is 153
    assert len(SixMovesTransformer.rewrites)== 153
    # dependencies of SixMovesTransformer is ['

# Generated at 2022-06-23 23:01:00.642675
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute(
        'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-23 23:01:10.552839
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:14.511794
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("configparser", "ConfigParser")
    assert moved_module.name == "configparser"
    assert moved_module.old == "ConfigParser"
    assert moved_module.new == "configparser"

# Generated at 2022-06-23 23:01:16.047859
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 84

# Generated at 2022-06-23 23:01:23.177944
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # First signature
    testcase = MovedAttribute("cStringIO", "cStringIO", "io")
    assert testcase.name == "cStringIO"
    assert testcase.new_mod == "io"
    assert testcase.new_attr == "StringIO"
    # Second signature
    testcase = MovedAttribute("range", "xrange", "builtins", "xrange", "range")
    assert testcase.name == "range"
    assert testcase.new_mod == "builtins"
    assert testcase.new_attr == "range"

# Generated at 2022-06-23 23:01:25.840560
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('name', 'old')
    assert mod.name == 'name'
    assert mod.old == 'old'
    assert mod.new == 'name'


# Generated at 2022-06-23 23:01:29.684996
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"



# Generated at 2022-06-23 23:01:40.859634
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:01:42.060390
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) == 49
    assert len(SixMovesTransformer.rewrites) == 49

# Generated at 2022-06-23 23:01:45.792135
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    assert mm.old == 'old'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'
    assert mm.old == 'old'

# Generated at 2022-06-23 23:01:46.826002
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(list(_get_rewrites())) == 47

# Generated at 2022-06-23 23:01:49.542900
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import types
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert isinstance(attr, types.ModuleType)
    assert attr.__name__ == "cStringIO"
    assert attr.__doc__ is None


# Generated at 2022-06-23 23:01:57.013014
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("a", "b", "c", "d", "e")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "e"
    a = MovedAttribute("a", "b", "c")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "a"
    a = MovedAttribute("a", "b", "c", "d")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "d"
    a = MovedAttribute("a", "b")
    assert a.name == "a"
    assert a.new_mod == "a"
    assert a.new

# Generated at 2022-06-23 23:02:02.398523
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedMod = MovedModule('name', 'old', 'new')
    assert MovedMod.name == 'name'
    assert MovedMod.new == 'new'
    MovedMod = MovedModule('name', 'old')
    assert MovedMod.name == 'name'
    assert MovedMod.new == 'name'

# Generated at 2022-06-23 23:02:11.390661
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-23 23:02:14.848410
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MA = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MA.name == "cStringIO"
    assert MA.new_mod == "io"
    assert MA.new_attr == "StringIO"

# Generated at 2022-06-23 23:02:24.061184
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2 import driver
    from lib2to3.fixer_util import Newline

    # testing constructor
    test_logger = logging.getLogger()
    test_logger = SixMovesTransformer(test_logger)

    assert isinstance(test_logger, SixMovesTransformer)
    assert test_logger._logger == test_logger
    assert test_logger.tree == {}
    assert test_logger.dependencies == ['six']
    assert test_logger.target == (2, 7)
    assert test_logger._fix_suppressed
    assert test_logger.driver is None
    assert test_logger._visited is None
    assert test_logger._dep_stack is None

# Generated at 2022-06-23 23:02:33.086104
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'mymod', 'newmod', 'old_foo', 'foo').name == 'foo'
    assert MovedAttribute('foo', 'mymod', 'newmod', 'old_foo', 'foo').new_attr == 'foo'
    assert MovedAttribute('foo', 'mymod', 'newmod', 'old_foo').new_attr == 'old_foo'
    assert MovedAttribute('foo', 'mymod', 'newmod', None, 'bar').new_attr == 'bar'
    assert MovedAttribute('foo', 'mymod', 'newmod', None, None).new_attr == 'foo'

# Generated at 2022-06-23 23:02:41.987131
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('foo', 'foo', None, old_attr='baz')
    MovedAttribute('foo', 'bar', None, old_attr='baz', new_attr='baz')
    MovedAttribute('foo', 'bar', None, new_attr='baz')
    MovedAttribute('foo', 'bar', None)
    MovedAttribute('foo', 'foo', 'bar')
    MovedAttribute('foo', 'foo', 'bar', old_attr='baz', new_attr='baz')
    MovedAttribute('foo', 'foo', 'bar', new_attr='baz')
    MovedAttribute('foo', 'foo', 'bar')

# Generated at 2022-06-23 23:02:45.453038
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "old", "new")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "new"


# Generated at 2022-06-23 23:02:54.656493
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import os
    import six.moves
    import six.moves.urllib.parse
    import six.moves.urllib.error
    import six.moves.urllib.request
    import six.moves.urllib.response
    import six.moves.urllib.robotparser
    assert sys.modules['six.moves'] is six.moves
    assert sys.modules['six.moves.urllib.parse'] is six.moves.urllib.parse
    assert sys.modules['six.moves.urllib.error'] is six.moves.urllib.error
    assert sys.modules['six.moves.urllib.request'] is six.moves.urllib.request

# Generated at 2022-06-23 23:03:07.002207
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "cStringIO"

    moved_attribute = MovedAttribute("cStringIO", "cStringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "cStringIO"
    assert moved_attribute.new_attr == "cStringIO"

# Generated at 2022-06-23 23:03:11.219313
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute(
        "cStringIO",
        "cStringIO",
        "io",
        "StringIO",
        "StringIO")

    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:19.077963
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma1.name == 'name'
    assert ma1.new_mod == 'new_mod'
    assert ma1.new_attr == 'name'

    ma2 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma2.name == 'name'
    assert ma2.new_mod == 'new_mod'
    assert ma2.new_attr == 'new_attr'

    ma3 = MovedAttribute('name', 'old_mod')
    assert ma3.name == 'name'
    assert ma3.new_mod == 'name'
    assert ma3.new_attr == 'name'

    ma4 = MovedAttribute('name')
    assert ma

# Generated at 2022-06-23 23:03:22.087460
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Make sure SixMovesTransformer's rewrites are constructed properly."""
    assert set(SixMovesTransformer.rewrites) == set(_get_rewrites())

# Generated at 2022-06-23 23:03:22.803778
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass

# Generated at 2022-06-23 23:03:26.821689
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attr.name == "cStringIO"
    assert moved_attr.new_mod == "io"
    assert moved_attr.new_attr == "cStringIO"



# Generated at 2022-06-23 23:03:29.221706
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    trans = SixMovesTransformer(None, None)
    assert trans.target == (2, 7)
    assert len(trans.rewrites) == len(_get_rewrites())

# Generated at 2022-06-23 23:03:31.042808
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        move = MovedAttribute()

get_rewrites_list = _get_rewrites()

# Generated at 2022-06-23 23:03:41.724347
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"

    obj = MovedAttribute("name", "old_mod", None, "old_attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "name"
    assert obj.new_attr == "new_attr"

    obj = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "old_attr"


# Generated at 2022-06-23 23:03:45.200380
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name="queue", old="Queue")
    assert moved_module.new == "queue"
    assert moved_module.old == "Queue"

    moved_module = MovedModule(name="queue", old="Queue", new="not_queue")
    assert moved_module.new == "not_queue"
    assert moved_module.old == "Queue"


# Generated at 2022-06-23 23:03:47.490385
# Unit test for constructor of class MovedModule
def test_MovedModule():
    tm = MovedModule("testmodule", "testmodule")
    assert tm.name == ("testmodule",)


# Generated at 2022-06-23 23:03:55.062370
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.main import main
    from lib2to3.tests import support
    fixer = SixMovesTransformer
    for test in fixer.tests:
        test.options['print_function'] = True
    do_test = support.do_test
    fixer.tests.clear()
    print('Tests removed from SixMovesTransformer')
    do_test(SixMovesTransformer, """\
import cStringIO
Print('passed cStringIO test')
""", """\
import six.moves.cStringIO
Print('passed cStringIO test')
""")

# Generated at 2022-06-23 23:04:04.550607
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('copyreg', 'copy_reg').name == 'copyreg'
    assert MovedModule('copyreg', 'copy_reg').new == 'copyreg'
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu').name == 'dbm_gnu'
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu').new == 'dbm.gnu'

# Generated at 2022-06-23 23:04:13.084729
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('foo', 'bar', 'baz')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'foo'

    move = MovedAttribute('foo', 'bar', 'baz', 'qux', 'quux')
    assert move.name == 'foo'
    assert move.new_mod == 'baz'
    assert move.new_attr == 'quux'

# Generated at 2022-06-23 23:04:15.481155
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer
    assert SixMovesTransformer.rewrites
    assert len(SixMovesTransformer.rewrites) == 57

# Generated at 2022-06-23 23:04:19.734292
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('queue', 'Queue')
    assert moved_module.name == 'queue'
    assert moved_module.new == 'queue'

    moved_module = MovedModule('random', 'whrandom')
    assert moved_module.name == 'random'
    assert moved_module.new == 'whrandom'


# Generated at 2022-06-23 23:04:24.492793
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").new == "foo"
    assert MovedModule("foo", "bar", "baz").name == "foo"
    assert MovedModule("foo", "bar", "baz").new == "baz"

# Generated at 2022-06-23 23:04:28.223715
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "cStringIO"


# Generated at 2022-06-23 23:04:30.039229
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) > 1

# Generated at 2022-06-23 23:04:35.413833
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert(mm.name == 'name')
    assert(mm.old == 'old')
    assert(mm.new == 'new')

    mm = MovedModule('name', 'old')
    assert(mm.name == 'name')
    assert(mm.old == 'old')
    assert(mm.new == 'name')


# Generated at 2022-06-23 23:04:36.751680
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 21

# Generated at 2022-06-23 23:04:46.300504
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from .sixmoves import MovedAttribute
    import six
    # Test for method name with no spaces
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"
    # Test for method name with spaces
    b = MovedAttribute("cStringIO", "cStringIO", "io", "String IO")
    assert b.name == "cStringIO"
    assert b.new_mod == "io"
    assert b.new_attr == "String IO"

# Generated at 2022-06-23 23:04:48.439487
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for path, six_path in _get_rewrites():
        assert SixMovesTransformer.trans(path) == six_path

# Generated at 2022-06-23 23:04:50.997108
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("pathlib", "pathlib")
    assert moved_module.name == "pathlib"
    assert moved_module.new == "pathlib"

# Generated at 2022-06-23 23:05:01.278983
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser.ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser.ConfigParser").new == "configparser.ConfigParser"
    assert MovedModule("winreg", "_winreg").name == "winreg"
    assert MovedModule("winreg", "_winreg").new == "winreg"
    assert MovedModule("winreg", "_winreg", "winreg._winreg").name == "winreg"
    assert MovedModule("winreg", "_winreg", "winreg._winreg").new == "winreg._winreg"


# Generated at 2022-06-23 23:05:03.235931
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer(None, (2, 7)).rewrites) == list(SixMovesTransformer.rewrites)
    assert SixMovesTransformer(None, (2, 7)).dependencies == SixMovesTransformer.dependencies

# Generated at 2022-06-23 23:05:04.568963
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:05:12.480978
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test', 'test').name == 'test'
    assert MovedModule('test', 'test').old == 'test'
    assert MovedModule('test', 'test').new == 'test'
    assert MovedModule('test', 'test1', 'test2').new == 'test2'
    assert MovedModule('tst', 'tst1', 'tst2').name == 'tst'
    assert MovedModule('tst', 'tst1', 'tst2').old == 'tst1'
    assert MovedModule('tst', 'tst1', 'tst2').new == 'tst2'

# Generated at 2022-06-23 23:05:13.949936
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"



# Generated at 2022-06-23 23:05:22.564212
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:05:30.573856
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # This function tests that the constructor of class SixMovesTransformer
    # works as expected.
    # Create the class
    importlib_name_mangling = True
    transformer = SixMovesTransformer(importlib_name_mangling)
    # Get expected values
    expected_rewrites = _get_rewrites()
    expected_importlib_name_mangling = importlib_name_mangling
    # Test
    assert transformer.rewrites == expected_rewrites
    assert transformer.importlib_name_mangling \
           == expected_importlib_name_mangling

# Generated at 2022-06-23 23:05:33.326484
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old', 'new', 'oldattr', 'newattr')
    assert move.name == 'name'
    assert move.new_mod == 'new'
    assert move.new_attr == 'newattr'
    assert str(move) == "<MovedAttribute: six.moves.name>"

# Generated at 2022-06-23 23:05:36.338571
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    t = SixMovesTransformer()
    # TODO: write proper unit tests

# Generated at 2022-06-23 23:05:41.077849
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('a','b','c','d','e')
    assert ma.name == "a"
    assert ma.new_mod == "b"
    assert ma.new_attr == "c"
    assert ma.old_attr == "d"
    assert ma.old_mod == "e"


# Generated at 2022-06-23 23:05:44.098182
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name','old','new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'

# Generated at 2022-06-23 23:05:45.880159
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']


# Generated at 2022-06-23 23:05:49.854228
# Unit test for constructor of class MovedModule
def test_MovedModule():
    line = "MovedModule('_winreg', '_winreg')"
    module = MovedModule("_winreg", "_winreg")
    assert module.name == "_winreg", repr(module.name)
    assert module.old == "_winreg", repr(module.old)
    assert module.new == "_winreg", repr(module.new)
    assert str(module) == line, repr(str(module))
    assert repr(module) == line, repr(repr(module))

# Generated at 2022-06-23 23:05:52.941632
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=unused-variable
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'



# Generated at 2022-06-23 23:05:53.736350
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert bool(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:05:56.362473
# Unit test for constructor of class MovedModule
def test_MovedModule():
    foo = MovedModule("foo", "old_foo", "new_foo")
    assert foo.name == "foo"
    assert foo.old == "old_foo"
    assert foo.new == "new_foo"

# Generated at 2022-06-23 23:06:02.430548
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("shlex_quote", "pipes", "shlex", "quote")
    expected = ('shlex_quote', 'pipes', 'shlex', 'quote', 'shlex_quote')
    assert test.name == expected[0]
    assert test.new_mod == expected[2]
    assert test.new_attr == expected[0]



# Generated at 2022-06-23 23:06:06.774883
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('a', 'b', 'c')
    MovedAttribute('a', 'b', 'c', old_attr='d', new_attr='e')
    MovedAttribute('a', 'b', 'c', new_attr='e')

# Unit tests for SixMovesTransformer:

# Generated at 2022-06-23 23:06:15.052644
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import check_rewriter

    # Ensure there are no duplicates
    seen_names = {}
    for path, name in SixMovesTransformer.rewrites:
        if path.startswith('.'):
            continue
        if path in seen_names:
            raise AssertionError("Duplicate rewrite for {} ({})".format(path, name))
        seen_names[path] = name

    def assert_rewrite(name, rewrite):
        assert SixMovesTransformer.rewrites[name] == rewrite

    assert_rewrite("cStringIO", "six.moves.cStringIO")
    assert_rewrite("cgi", "six.moves.cgi")
    assert_rewrite("configparser", "six.moves.configparser")

# Generated at 2022-06-23 23:06:20.881906
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('name', 'old')
    assert move.name == 'name'
    assert move.old == 'old'
    assert move.new == 'name'
    move = MovedModule('name', 'old', 'new')
    assert move.name == 'name'
    assert move.old == 'old'
    assert move.new == 'new'


# Generated at 2022-06-23 23:06:31.991845
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

    attr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert attr.name == "filter"
    assert attr.new_mod == "builtins"
    assert attr.new_attr == "filter"

    attr = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    assert attr.name == "getcwd"
    assert attr.new_mod == "os"

# Generated at 2022-06-23 23:06:38.182945
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old')
    assert MovedModule('name', 'old') != MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old') != 'name'


# Generated at 2022-06-23 23:06:43.457202
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("foo", "a", "b")
    assert m.name == "foo"
    assert m.old == "a"
    assert m.new == "b"
    m = MovedModule("foo", "a")
    assert m.name == "foo"
    assert m.old == "a"
    assert m.new == "foo"

# Generated at 2022-06-23 23:06:45.854279
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 23:06:49.491747
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'


# Generated at 2022-06-23 23:06:58.635831
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import astor.codegen
    transformer = SixMovesTransformer.from_module('six')
    result = transformer.transform_file(__file__)
    output = astor.codegen.to_source(result)
    result = transformer.finalize_module(result)

# Generated at 2022-06-23 23:07:03.754283
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves
    print(six.moves.urllib.parse)
    t = SixMovesTransformer()
    print(t.rewrites)
    for path, replacement in t.rewrites:
        print(path, replacement)

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:07:09.034411
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'

# Generated at 2022-06-23 23:07:10.739008
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()



# Generated at 2022-06-23 23:07:20.664266
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import tempfile, shutil
    from .. import main, run
    from ..testing import assert_diffs
    td = tempfile.mkdtemp()

# Generated at 2022-06-23 23:07:22.495791
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.dependencies == ['six']
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:07:23.419988
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()

# Generated at 2022-06-23 23:07:33.337912
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__", "builtins")
    assert move.name == "builtins"
    assert move.new == "builtins"
    assert move.old == "__builtin__"
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.new == "builtins"
    assert move.old == "__builtin__"
    move = MovedModule("builtins", "__builtin__", "builtins")
    assert move.name == "builtins"
    assert move.new == "builtins"
    assert move.old == "__builtin__"
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"

# Generated at 2022-06-23 23:07:42.070022
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=unused-variable
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-23 23:07:51.209558
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"


# Generated at 2022-06-23 23:07:54.163252
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.new == 'new'

# Generated at 2022-06-23 23:08:06.004343
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from six.moves import urllib
    from six.moves.urllib.error import URLError
    from six.moves.urllib.parse import ParseResult
    from six.moves.urllib.request import urlopen

    assert isinstance(urllib.request, urllib.request.request)
    assert isinstance(urllib.error, urllib.error.error)
    assert isinstance(urllib.parse, urllib.parse.parse)
    assert isinstance(ParseResult, urllib.parse.ResultBase)
    assert isinstance(URLError, urllib.error.URLError)
    assert isinstance(urlopen, type(urllib.request.urlopen))

# Generated at 2022-06-23 23:08:10.702564
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"
    assert m.old == "old"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    assert m.old == "old"


# Generated at 2022-06-23 23:08:12.467095
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("some_module", "old_name")
    assert module.name == "some_module"
    assert module.new == "old_name"

# Generated at 2022-06-23 23:08:13.476972
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('test', 'test.old', 'test.new')

# Generated at 2022-06-23 23:08:21.553257
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_mod1 = MovedModule(name="testModule", old="testModule2", new="testModule3")
    assert moved_mod1.name == "testModule"
    assert moved_mod1.old == "testModule2"
    assert moved_mod1.new == "testModule3"

    # Sets new to None, should set new to name
    moved_mod2 = MovedModule(name="testModule2")
    assert moved_mod2.name == "testModule2"
    assert moved_mod2.new == "testModule2"
    assert moved_mod2.old == "testModule2"

# Generated at 2022-06-23 23:08:23.226216
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert sorted(_get_rewrites()) == sorted(SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:08:25.212986
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the SixMovesTransformer"""
    tester = SixMovesTransformer()

# Generated at 2022-06-23 23:08:27.093555
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert len(s.rewrites) > 0
    assert all(isinstance(rewrite, tuple) and len(rewrite) == 2
               for rewrite in s.rewrites)

# Generated at 2022-06-23 23:08:30.750032
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert len(st.rewrites) == len(_get_rewrites())
    assert st.target == (2, 7)
    assert st.dependencies == ['six']


# Generated at 2022-06-23 23:08:32.267800
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tr = SixMovesTransformer('')
    assert tr.rewrites

# Generated at 2022-06-23 23:08:42.997004
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:08:45.571405
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test SixMovesTransformer constructor."""
    transformer = SixMovesTransformer()
    assert transformer.dependencies == ["six"]

# Generated at 2022-06-23 23:08:57.042376
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """ Test the constructor of the class SixMovesTransformer.
    """
    transformer = SixMovesTransformer()
    assert transformer.dependencies == ['six'], \
        'This should be the dependencies of the class SixMovesTransformer'
    assert transformer.target == (2, 7), \
        'This should be the target of the class SixMovesTransformer'
    assert transformer.module_level == 0, \
        'This should be the level of the class SixMovesTransformer'


# Generated at 2022-06-23 23:09:01.590552
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_attr == "StringIO"
    assert move.new_mod == "io"
    assert move.old_attr == "StringIO"

# Generated at 2022-06-23 23:09:06.251820
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _get_rewrites()
    _get_rewrites()  # check that cache works, so this call has no effect
    t = SixMovesTransformer()
    assert t.rewrites == _get_rewrites()
    assert set(t.dependencies) == {'six'}
    assert t.target == (2, 7)
    assert t.name == 'six_moves'

# Generated at 2022-06-23 23:09:12.098698
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.old_mod == "cStringIO"
    assert obj.old_attr == "StringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"



# Generated at 2022-06-23 23:09:16.119154
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _test_SixMovesTransformer = SixMovesTransformer
    # pylint: disable=unused-variable
    # This is an unused variable to trigger initialization of _get_rewrites
    _get_rewrites()
    _test_SixMovesTransformer = None