

# Generated at 2022-06-23 22:59:21.323767
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("foo", "bar")
    assert move.name == "foo"
    assert move.new_mod == "bar"
    assert move.new_attr == "foo"
    move = MovedAttribute("foo", "bar", new_attr="baz")
    assert move.new_attr == "baz"
    move = MovedAttribute("foo", "bar", old_attr="baz")
    assert move.new_attr == "baz"
    move = MovedAttribute("foo", "bar", old_attr="baz", new_attr="buz")
    assert move.new_attr == "buz"

# Generated at 2022-06-23 22:59:23.490813
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"


# Generated at 2022-06-23 22:59:31.486480
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                rewrite = 'six.moves{}.{}'.format(prefix, move.name)
                assert path in SixMovesTransformer.rewrites
                assert rewrite == SixMovesTransformer.rewrites[path]
            elif isinstance(move, MovedModule):
                assert move.new in SixMovesTransformer.rewrites
                assert move.new == SixMovesTransformer.rewrites[move.new]

# Generated at 2022-06-23 22:59:37.339853
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    A = MovedAttribute("A", "B", "C", "D", "E")
    assert A.name == "A"
    assert A.new_mod == "C"
    assert A.new_attr == "E"
    B = MovedAttribute("B", "C", "D")
    assert B.name == "B"
    assert B.new_mod == "D"
    assert B.new_attr == "B"
    C = MovedAttribute("C", "D", "E")
    assert C.name == "C"
    assert C.new_mod == "E"
    assert C.new_attr == "C"



# Generated at 2022-06-23 22:59:48.262231
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    # Check if move is actually renamed
    assert ('six.moves.urllib.parse.ParseResult',
            'six.moves.urllib.parse.ParseResult') in SixMovesTransformer.rewrites
    assert ('six.moves.urllib.error.URLError',
            'six.moves.urllib.error.URLError') in SixMovesTransformer.rewrites

    # Check if other moves are renamed
    assert ('six.moves.cStringIO.StringIO',
            'six.moves.StringIO') in SixMovesTransformer.rewrites
    assert ('six.moves.tkinter.Tkinter',
            'six.moves.Tkinter') in SixMovesTransformer.rewrites

    # Check if dependencies is modified

# Generated at 2022-06-23 22:59:52.236281
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'StringIO'



# Generated at 2022-06-23 22:59:57.269494
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.rewrites[0][0] == 'configparser.ConfigParser'
    assert s.rewrites[0][1] == "six.moves.configparser"
    assert s.rewrites[1][0] == 'copyreg.copy_reg'
    assert s.rewrites[1][1] == "six.moves.copyreg"

# Generated at 2022-06-23 23:00:01.015387
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.old == "__builtin__"
    assert moved_module.new == "builtins"


# Generated at 2022-06-23 23:00:10.022982
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__')
    assert MovedModule('configparser', 'ConfigParser')
    assert MovedModule('copyreg', 'copy_reg')
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    assert MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    assert MovedModule('http_cookiejar', 'cookielib', 'http.cookiejar')
    assert MovedModule('http_cookies', 'Cookie', 'http.cookies')
    assert MovedModule('html_entities', 'htmlentitydefs', 'html.entities')
    assert MovedModule('html_parser', 'HTMLParser', 'html.parser')

# Generated at 2022-06-23 23:00:14.870547
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("foo", "bar")
    assert mod.new == "foo"
    assert mod.name == "bar"
    mod = MovedModule("foo", "bar", "baz")
    assert mod.new == "foo"
    assert mod.name == "baz"


# Generated at 2022-06-23 23:00:23.339360
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of class SixMovesTransformer"""
    transformer = SixMovesTransformer('six_moves', None)

# Generated at 2022-06-23 23:00:25.812339
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('abc', 'abc')
    assert mm.name == 'abc'
    assert mm.new == 'abc'



# Generated at 2022-06-23 23:00:34.477389
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("unquote", "urllib", "urllib.parse", "unquote_to_bytes", "unquote_to_bytes").name == "unquote"
    assert MovedAttribute("unquote", "urllib", "urllib.parse", "unquote_to_bytes", "unquote_to_bytes").old_mod == "urllib"
    assert MovedAttribute("unquote", "urllib", "urllib.parse", "unquote_to_bytes", "unquote_to_bytes").new_mod == "urllib.parse"
    assert MovedAttribute("unquote", "urllib", "urllib.parse", "unquote_to_bytes", "unquote_to_bytes").old_attr == "unquote_to_bytes"

# Generated at 2022-06-23 23:00:44.416313
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:00:45.578198
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:00:50.255216
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    move1 = MovedModule("math", "math")
    move2 = MovedAttribute("math", "math", "six.moves")
    assert (SixMovesTransformer.rewrites.get("math", "") == 'six.moves.math')

# Generated at 2022-06-23 23:00:54.234673
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"

# Generated at 2022-06-23 23:01:00.538650
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six.moves.urllib.parse
    import six.moves.urllib.error
    import six.moves.urllib.request
    assert six.moves.urllib.parse.ParseResult is not None
    assert six.moves.urllib.error.URLError is not None
    assert six.moves.urllib.request.urlopen is not None

# Generated at 2022-06-23 23:01:04.761123
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_attribute.name == "cStringIO"
    assert move_attribute.new_mod == "io"
    assert move_attribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:01:08.060487
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("foo", old_mod="bar", new_mod="baz")
    assert attribute.name == "foo"
    assert attribute.new_mod == "baz"
    assert attribute.new_attr == "foo"


# Generated at 2022-06-23 23:01:14.724894
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert m.name == "name"
    assert m.old_mod == "old_mod"
    assert m.new_mod == "new_mod"
    assert m.old_attr == "old_attr"
    assert m.new_attr == "new_attr"


# Generated at 2022-06-23 23:01:19.594338
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_tuple = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert test_tuple.name == 'cStringIO'
    assert test_tuple.new_mod == 'io'
    assert test_tuple.new_attr == 'StringIO'



# Generated at 2022-06-23 23:01:22.202332
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old')
    assert MovedModule('name', 'old') != MovedModule('name', 'old', 'new')

# Generated at 2022-06-23 23:01:26.100203
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) == 65
    assert len(prefixed_moves) == 6
    assert len(_get_rewrites()) == 80 + 65 + 6
    assert len(SixMovesTransformer.rewrites) == 80 + 65 + 6


transformers = [SixMovesTransformer]

# Generated at 2022-06-23 23:01:28.426091
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        SixMovesTransformer()

if __name__ == "__main__":
    test_SixMovesTransformer()

# Generated at 2022-06-23 23:01:30.119879
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)



# Generated at 2022-06-23 23:01:37.409616
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m1 = MovedAttribute("a1", "mod1", "mod2")
    m2 = MovedAttribute("a2", "mod1", "mod2", "old_attr_name")
    m3 = MovedAttribute("a3", "mod1", "mod2", old_attr="old_attr_name")
    m4 = MovedAttribute("a4", "mod1", "mod2", new_attr="new_attr_name")
    m5 = MovedAttribute("a5", "mod1", "mod2", old_attr="old_attr_name", new_attr="new_attr_name")
    m6 = MovedAttribute("a6", "mod1", "mod2", "old_attr_name", "new_attr_name")

    assert m1.name == "a1"
    assert m1.new

# Generated at 2022-06-23 23:01:43.295723
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer('foo')
    # pylint: disable=protected-access
    assert t.rewrites is not _get_rewrites()
    assert isinstance(t.rewrites, dict)
    assert t.dependencies == ['six']
    assert t.target == (2, 7)
    assert not hasattr(t, 'name')
    # pylint: enable=protected-access

# Generated at 2022-06-23 23:01:44.422551
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None).rewrites == _get_rewrites()

# Generated at 2022-06-23 23:01:46.890039
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("winreg", "_winreg").__dict__ == {
        "name": "winreg",
        "old": "_winreg",
        "new": "winreg",
    }

# Generated at 2022-06-23 23:01:54.149397
# Unit test for constructor of class MovedModule

# Generated at 2022-06-23 23:01:54.943147
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("builtins", "__builtin__")

# Generated at 2022-06-23 23:01:57.782474
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module1 = MovedModule("testmod", "testmod.old")
    module2 = MovedModule("testmod", "testmod.old", "testmod.new")
    assert module1.name == module2.name
    assert module1.new == module2.old
    assert module1.new == "testmod"
    assert module2.new == "testmod.new"


# Generated at 2022-06-23 23:02:02.288241
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    t = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert t.name == "cStringIO"
    assert t.new_mod == "io"
    assert t.new_attr == "StringIO"



# Generated at 2022-06-23 23:02:11.330851
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Unit test for constructor of class MovedModule"""
    moved_module = MovedModule("MovedModule1")
    assert moved_module.name == "MovedModule1"
    assert moved_module.new == "MovedModule1"

    moved_module = MovedModule("MovedModule2", "MovedModule2")
    assert moved_module.name == "MovedModule2"
    assert moved_module.new == "MovedModule2"

    moved_module = MovedModule("MovedModule3", "MovedModule3", "MovedModule3")
    assert moved_module.name == "MovedModule3"
    assert moved_module.new == "MovedModule3"

    moved_module = MovedModule("MovedModule4", "OldMovedModule4", "NewMovedModule4")
    assert moved_

# Generated at 2022-06-23 23:02:21.391000
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "old_attr"


# Generated at 2022-06-23 23:02:26.586483
# Unit test for constructor of class MovedModule
def test_MovedModule():
    old = 'os'
    new = '_os'
    name = 'os'
    moveModule = MovedModule(name, old, new)
    assert moveModule.old == old, "Should be " + old
    assert moveModule.new == new, "Should be " + new
    assert moveModule.name == name, "Should be " + name

# Generated at 2022-06-23 23:02:37.925600
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # type: () -> None
    assert len(SixMovesTransformer.rewrites) >= 46
    assert len([k for k, v in SixMovesTransformer.rewrites if k.startswith('urllib')]) == 43
    assert ('six.moves.urllib_parse.urlencode', 'six.moves.urllib.urlencode') \
        in SixMovesTransformer.rewrites
    assert ('six.moves.urllib_error.URLError', 'six.moves.urllib2.URLError') \
        in SixMovesTransformer.rewrites
    assert ('six.moves.urllib_request.urlretrieve', 'six.moves.urllib.urlretrieve') \
        in SixMovesTransformer.rewrites

# Generated at 2022-06-23 23:02:42.238339
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('a', 'b', 'c')
    assert a.name == 'a'
    assert a.new == 'c'
    b = MovedModule('a', 'b')
    assert b.new == 'a'


# Generated at 2022-06-23 23:02:47.112394
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute('foo', 'bar', 'baz')

    assert x.name == 'foo'
    assert x.new_mod == 'baz'
    assert x.new_attr == 'foo'

    assert str(x) == "MovedAttribute('foo', 'bar', 'baz')"

# Generated at 2022-06-23 23:02:50.277218
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('builtins', '__builtin__')
    assert(move.name == 'builtins')
    assert(move.old == '__builtin__')
    assert(move.new == 'builtins')

# Generated at 2022-06-23 23:02:52.309738
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test that you can instantiate SixMovesTransformer.
    """
    st = SixMovesTransformer()


# vim:et:ts=4:sw=4:tw=80:

# Generated at 2022-06-23 23:02:54.707069
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')

# Generated at 2022-06-23 23:03:07.050446
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """__init__"""
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"

# Generated at 2022-06-23 23:03:08.092030
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer())

# Generated at 2022-06-23 23:03:10.744898
# Unit test for constructor of class MovedModule
def test_MovedModule():
    if len(sys.argv) > 1 and sys.argv[1] == "dummy":
        test_MovedModule()


print("2.7")

# Generated at 2022-06-23 23:03:11.785464
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:03:19.370345
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    def using_wrong_params():
        MovedAttribute('zip', 5, 'range', 'izip', 'zip')

    def using_wrong_params2():
        MovedAttribute('zip', [], 'range', 'izip')

    def using_wrong_params3():
        MovedAttribute('zip', 'range', 'izip')

    with pytest.raises(TypeError) as excinfo:
        using_wrong_params()
    with pytest.raises(TypeError) as excinfo:
        using_wrong_params2()
    with pytest.raises(TypeError) as excinfo:
        using_wrong_params3()

    def using_wrong_params4():
        MovedAttribute('zip', 'range', 5, 'izip')


# Generated at 2022-06-23 23:03:27.381553
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'

    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'

    assert MovedModule('configparser', 'ConfigParser', 'new_configparser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser', 'new_configparser').new == 'new_configparser'

# Generated at 2022-06-23 23:03:28.375941
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert not list(_get_rewrites()) == []

# Generated at 2022-06-23 23:03:30.989550
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites[-2][1] == 'six.moves.urllib.robotparser.RobotFileParser'
    assert SixMovesTransformer.rewrites[-1][1] == 'six.moves.urllib_robotparser.RobotFileParser'

# Generated at 2022-06-23 23:03:34.173168
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_attribute.name == "cStringIO"
    assert move_attribute.new_mod == "io"
    assert move_attribute.new_attr == "StringIO"

# Generated at 2022-06-23 23:03:41.827903
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = [MovedModule("builtins", "__builtin__"),MovedModule("tkinter_simpledialog", "SimpleDialog",
                "tkinter.simpledialog")]
    assert moves[0].name == "builtins"
    assert moves[0].new == "builtins"
    assert moves[1].name == "tkinter_simpledialog"
    assert moves[1].new == "tkinter.simpledialog"


# Generated at 2022-06-23 23:03:46.359375
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'


# Generated at 2022-06-23 23:03:52.278714
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'

    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-23 23:03:53.311885
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer() is not None

# Generated at 2022-06-23 23:03:56.204287
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 139


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 23:04:05.392629
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..transforms.sixmoves import SixMovesTransformer
    from ..utils.helpers import eager
    from ..utils.rewrite import ImportRewrite
    from . import BaseImportRewrite
    from ..utils.helpers import TransformerInfo
    from ..parser.python_parser import PythonSymbols
    from ..utils.helpers import get_virtual_module
    # Test the class variables
    assert SixMovesTransformer.target == (2, 7)
    assert isinstance(SixMovesTransformer.rewrites, tuple)
    assert len(SixMovesTransformer.rewrites) == 56
    assert isinstance(SixMovesTransformer.rewrites[0], tuple)
    assert isinstance(SixMovesTransformer.rewrites[0], ImportRewrite)
    assert isinstance(SixMovesTransformer.dependencies, tuple)

# Generated at 2022-06-23 23:04:14.579794
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MM=MovedModule("builtins","__builtin__")
    assert MM.name=="builtins"
    assert MM.new=="builtins"
    MM=MovedModule("builtins","__builtin__","builtins",)
    assert MM.name=="builtins"
    assert MM.new=="builtins"
    MM=MovedModule("_dummy_thread","dummy_thread","_dummy_thread")
    assert MM.name=="_dummy_thread"
    assert MM.new=="_dummy_thread"



# Generated at 2022-06-23 23:04:22.796798
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import_six = '\n'.join(['import six']*10)
    import_sixmoves = '\n'.join(
        ['import six.moves{}.{}'.format(prefix, move.name) for prefix, moves in prefixed_moves for move in moves])
    assert '\n'.join(SixMovesTransformer.rewrites) == '\n'.join([x[0] for x in _get_rewrites()])
    assert SixMovesTransformer.check_requirements() is True

# Generated at 2022-06-23 23:04:25.149446
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    data = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert data.name == "cStringIO"
    assert data.new_mod == "io"
    assert data.new_attr == "StringIO"



# Generated at 2022-06-23 23:04:29.983578
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"


# Generated at 2022-06-23 23:04:39.297865
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").name == "filterfalse"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").new_mod == "itertools"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").new_attr == "filterfalse"

# Generated at 2022-06-23 23:04:47.206500
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert not hasattr(MovedModule('name', 'old'), 'attr')


# Generated at 2022-06-23 23:04:50.426059
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute(name="a", old_mod="b", new_mod="c")
    assert ma.name == "a"
    assert ma.new_mod == "c"
    assert ma.new_attr == "a"

# Generated at 2022-06-23 23:05:00.732778
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('foo_bar', 'oldmod', None)
    assert m.name == 'foo_bar'
    assert m.new_mod == 'foo_bar'
    assert m.new_attr == 'foo_bar'

    m = MovedAttribute('foo_bar', 'oldmod', 'newmod')
    assert m.name == 'foo_bar'
    assert m.new_mod == 'newmod'
    assert m.new_attr == 'foo_bar'

    m = MovedAttribute('foo_bar', 'oldmod', None, old_attr='oldattr')
    assert m.name == 'foo_bar'
    assert m.new_mod == 'foo_bar'
    assert m.new_attr == 'oldattr'


# Generated at 2022-06-23 23:05:01.613433
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer._get_rewrites() is not None

# Generated at 2022-06-23 23:05:03.643862
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

# Generated at 2022-06-23 23:05:06.906930
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('test_name', 'test_old', 'test_new')
    assert module.name == 'test_name'
    assert module.old == 'test_old'
    assert module.new == 'test_new'


# Generated at 2022-06-23 23:05:16.772598
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("foo", "bar", "baz", "x", "y")
    assert attr.name == "foo"
    assert attr.new_mod == "baz"
    assert attr.new_attr == "y"

    attr = MovedAttribute("foo", "bar", "baz", "x", None)
    assert attr.name == "foo"
    assert attr.new_mod == "baz"
    assert attr.new_attr == "x"

    attr = MovedAttribute("foo", "bar", "baz", None, "y")
    assert attr.name == "foo"
    assert attr.new_mod == "baz"
    assert attr.new_attr == "y"


# Generated at 2022-06-23 23:05:20.532077
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import construct_rewrites
    from . import sixmoves as sm
    r = construct_rewrites(sm)
    assert len(r) == len(SixMovesTransformer.rewrites)
    for x, y in zip(r, SixMovesTransformer.rewrites):
        assert x == y


# Generated at 2022-06-23 23:05:21.899476
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-23 23:05:26.207085
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_a = MovedAttribute('a', 'b', 'c')
    assert moved_a.name == 'a'
    assert moved_a.new_mod == 'c'
    assert moved_a.new_attr == 'a'

# Generated at 2022-06-23 23:05:31.999330
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("http_cookies", "Cookie", "http.cookies")
    assert mod.__dict__ == {'name': 'http_cookies', 'old': 'Cookie',
                            'new': 'http.cookies'}
    mod = MovedModule("http_cookies", "Cookie")
    assert mod.__dict__ == {'name': 'http_cookies', 'old': 'Cookie',
                            'new': 'http_cookies'}


# Generated at 2022-06-23 23:05:41.120106
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test input is a string
    try:
        test_moved_module = MovedModule("string", "old")
    except Exception:
        assert False, "constructing a MovedModule with a string should be valid"
    else:
        assert True

    # Test input is a MovedModule
    try:
        test_moved_module = MovedModule(MovedModule("string", "old"), "old")
    except Exception:
        assert False, "constructing a MovedModule with a MovedModule should be valid"
    else:
        assert True


# Generated at 2022-06-23 23:05:43.712158
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for rewrite in _get_rewrites():
        assert rewrite in SixMovesTransformer.rewrites, \
            "Objects do not match"

# Generated at 2022-06-23 23:05:50.718675
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import struct

    class DummyTransformer(SixMovesTransformer):
        def _get_rewrites(self):
            return {
                "cStringIO": six.moves.cStringIO,
                "struct.calcsize": struct.calcsize,
                "sys.path": sys.path,
                "sys.getdefaultencoding": sys.getdefaultencoding,
            }

        def setup_begin(self, context):
            self.cStringIO = six.moves.cStringIO
            self.calcsize = struct.calcsize
            self.path = sys.path
            self.getdefaultencoding = sys.getdefaultencoding

    dummy_transformer = DummyTransformer(six)
    assert dummy_transformer.cStringIO is six.moves.cString

# Generated at 2022-06-23 23:05:56.262693
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == exp.unreachable

if __name__ == "__main__":
    # Run the unit tests
    loc = locals()
    for key in list(loc.keys()):
        if key.startswith("test_"):
            print(key)
            if callable(loc[key]):
                loc[key]()

# Generated at 2022-06-23 23:05:58.796930
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites() == _get_rewrites()

# Generated at 2022-06-23 23:06:02.989704
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from itertools import filterfalse
    assert SixMovesTransformer().rewrites
    assert SixMovesTransformer().dependencies == ['six']
    assert SixMovesTransformer().target == (2, 7)
    assert SixMovesTransformer().import_direct(filterfalse) == 'filterfalse'

# Generated at 2022-06-23 23:06:03.912531
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-23 23:06:05.705009
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old')



# Generated at 2022-06-23 23:06:14.298833
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:06:25.846093
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-23 23:06:27.646590
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = SixMovesTransformer()
    assert rewrites.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:06:29.759454
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _rewrites = _get_rewrites()
    SixMovesTransformer.rewrites = _rewrites

# Generated at 2022-06-23 23:06:33.266352
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Given
    given_code = "six.moves.dbm.gnu"

    # When
    six_moves_transformer = SixMovesTransformer()
    result = six_moves_transformer.run(given_code)

    # Then
    assert result == "dbm.gnu"

# Generated at 2022-06-23 23:06:39.317848
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 207
    assert SixMovesTransformer.rewrites[0] == ('builtins.cStringIO', 'six.moves.cStringIO')
    assert SixMovesTransformer.rewrites[206] == ('urllib.robotparser.RobotFileParser',
                                                 'six.moves.urllib.robotparser.RobotFileParser')

# Generated at 2022-06-23 23:06:48.502704
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('xrange', '__builtin__', 'builtins', 'xrange', 'range').name == 'xrange'
    assert MovedAttribute('xrange', '__builtin__', 'builtins', 'xrange', 'range').old_mod == '__builtin__'
    assert MovedAttribute('xrange', '__builtin__', 'builtins', 'xrange', 'range').new_mod == 'builtins'
    assert MovedAttribute('xrange', '__builtin__', 'builtins', 'xrange', 'range').old_attr == 'xrange'
    assert MovedAttribute('xrange', '__builtin__', 'builtins', 'xrange', 'range').new_attr

# Generated at 2022-06-23 23:06:51.863848
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('foo', 'bar')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'foo'
    assert moved_module.old == 'bar'

# Generated at 2022-06-23 23:07:00.463616
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, type)
    assert SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert SixMovesTransformer.dependencies == ['six']
    assert SixMovesTransformer.__doc__ == 'Replaces moved modules with ones from `six.moves`.'
    assert SixMovesTransformer.target == (2, 7)
    assert isinstance(SixMovesTransformer.rewrites, set)

# Generated at 2022-06-23 23:07:06.360485
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"


# Generated at 2022-06-23 23:07:17.378414
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves
    import six.moves.urllib.parse
    assert six.moves.urllib.parse.quote is six.moves._urllib_parse_moved_attributes[0].func
    rewrites = _get_rewrites()
    for path, new_path in rewrites:
        module, attr = path.split('.')
        if attr == 'quote':
            assert getattr(six.moves.urllib.parse, 'quote') is six.moves._urllib_parse_moved_attributes[0].func, "rewrites:{}, path:{}, new_path: {}".format(rewrites, path, new_path)
    assert True, "Tests finished"

# Generated at 2022-06-23 23:07:22.109752
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test constructor of class SixMovesTransformer with inputs:
    # target = (2, 7), dependencies = ['six']
    target_input = (2, 7)
    dependencies_input = ['six']

    smt = SixMovesTransformer(target=target_input, dependencies=dependencies_input)
    assert smt.target == target_input
    assert smt.dependencies == dependencies_input

# Generated at 2022-06-23 23:07:28.154892
# Unit test for constructor of class MovedModule
def test_MovedModule():
    one = MovedModule("name", "old")
    assert one.name == "name"
    assert one.new == "name"
    assert one.old == "old"

    two = MovedModule("name", "old", "new")
    assert two.name == "name"
    assert two.new == "new"
    assert two.old == "old"


# Generated at 2022-06-23 23:07:29.213089
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()


# Generated at 2022-06-23 23:07:31.337975
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert not len(SixMovesTransformer.rewrites)
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-23 23:07:34.023933
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-23 23:07:38.732344
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('', '').name == ''
    assert MovedModule('', '').new == ''
    assert MovedModule('foo', 'bar').name == 'foo'
    assert MovedModule('foo', 'bar').new == 'bar'
    assert MovedModule('foo').name == 'foo'
    assert MovedModule('foo').new == 'foo'

# Generated at 2022-06-23 23:07:50.822243
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .helper import run_test_program
    from . import helper

    test_text = '''
    from six.moves import _dummy_thread
    import _dummy_thread

    import six

    from six.moves import myexception
    raise myexception

    from six.moves.urllib_parse import urlsplit
    urlsplit()

    from six.moves.urllib_error import URLError
    URLError()
    '''


# Generated at 2022-06-23 23:08:00.586457
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert isinstance(t.rewrites, dict)
    assert 'six.moves' in t.dependencies


# Generated at 2022-06-23 23:08:11.756738
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import six
    from pathlib import Path
    from .test_utils import transform, write_file
    from .utils import ImportVisitor
    from .test_utils import (
        compare_ast,
        get_test_data_path,
        )
    from ..six import StringIO

    def is_present(mod_name, moves):
        for move in moves:
            if move.name == mod_name:
                return True
        return False

    if StringIO is not six.StringIO:
        six_moves_attributes = _moved_attributes + _urllib_parse_moved_attributes + \
                               _urllib_error_moved_attributes + _urllib_request_moved_attributes + \
                               _urllib_response_moved_attributes

# Generated at 2022-06-23 23:08:12.529967
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('builtins', '__builtin__')

# Generated at 2022-06-23 23:08:18.698105
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'mod', 'newmod', 'attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'mod', 'newmod', 'attr', 'new_attr').new_mod == 'newmod'
    assert MovedAttribute('name', 'mod', 'newmod', 'attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'newmod', 'newmod', 'attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'newmod', 'newmod', 'attr').new_attr == 'attr'
    assert MovedAttribute('name', 'newmod', 'newmod').new_attr == 'name'

# Generated at 2022-06-23 23:08:22.258706
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('abc', 'a', 'b').name == 'abc'
    assert MovedAttribute('abc', 'a', 'b').new_mod == 'b'
    assert MovedAttribute('abc', 'a', 'b').new_attr == 'abc'
    assert MovedAttribute('abc', 'a', 'b', 'c', 'd').new_attr == 'd'
    assert MovedAttribute('abc', 'a', 'b', 'c').new_attr == 'c'

# Generated at 2022-06-23 23:08:24.664274
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('a')
    a = MovedModule('a', 'b')
    a = MovedModule('a', 'b', 'c')

# Generated at 2022-06-23 23:08:27.451223
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    for path, replacement in transformer.rewrites:
        assert path in transformer.rewrite_map
        assert transformer.rewrite_map[path] == replacement

# Generated at 2022-06-23 23:08:32.724196
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('name', 'old', 'new')
    assert mod.name == 'name'
    assert mod.old == 'old'
    assert mod.new == 'new'
    mod = MovedModule('name', 'old')
    assert mod.name == 'name'
    assert mod.old == 'old'
    assert mod.new == 'name'

# Generated at 2022-06-23 23:08:38.740863
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_pgen2.test_tokenize import whitespaces
    assert whitespaces(SixMovesTransformer.__doc__) == 0

    # Make sure the namespace of `urllib.parse` is handled specially
    for prefix in ['.urllib.parse', '.urllib.error', '.urllib.request', '.urllib.response', '.urllib.robotparser']:
        assert any(r[1].startswith('six.moves{}'.format(prefix)) for r in SixMovesTransformer.rewrites)

# Generated at 2022-06-23 23:08:49.324840
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO" , "io")
    MovedAttribute("filter", "itertools", "builtins")
    MovedAttribute("input", "__builtin__", "builtins")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins")
    MovedAttribute("getcwd", "os", "os")
    MovedAttribute("getcwdb", "os", "os")
    MovedAttribute("getstatusoutput", "commands", "subprocess")
    MovedAttribute("getoutput", "commands", "subprocess")
    MovedAttribute("range", "__builtin__", "builtins")
    MovedAttribute("reload_module", "__builtin__", "imp")

# Generated at 2022-06-23 23:09:00.897698
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "StringIO"
    attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "cStringIO"
    attribute = MovedAttribute("cStringIO", "cStringIO", "io", "cStringIO", "cStringIO")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "cStringIO"

# Generated at 2022-06-23 23:09:03.348728
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=not-an-iterable
    assert len(SixMovesTransformer._get_rewrites()) == 488

# Generated at 2022-06-23 23:09:03.953750
# Unit test for constructor of class MovedModule

# Generated at 2022-06-23 23:09:04.900450
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-23 23:09:11.824857
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name, old, new = 'name', 'old', 'new'
    assert MovedModule(name, old, new).name == 'name'
    assert MovedModule(name, old, new).new == 'new'
    assert MovedModule(name, old).name == 'name'
    assert MovedModule(name, old).new == 'name'
    assert MovedModule(name).name == 'name'
    assert MovedModule(name).new == 'name'


# Generated at 2022-06-23 23:09:16.263320
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("attr1", "mod1", "mod2")
    assert a.name == "attr1"
    assert a.old_mod == "mod1"
    assert a.new_mod == "mod2"
    assert a.new_attr == "attr1"

