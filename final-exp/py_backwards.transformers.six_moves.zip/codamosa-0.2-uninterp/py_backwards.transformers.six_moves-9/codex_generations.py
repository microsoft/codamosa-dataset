

# Generated at 2022-06-18 00:19:41.160247
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__", "__builtin__").new == "__builtin__"
    assert MovedModule("builtins", "__builtin__", "__builtin__").new == "__builtin__"
    assert MovedModule("builtins", "__builtin__", "__builtin__").name == "builtins"


# Generated at 2022-06-18 00:19:50.826417
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').old_attr == 'StringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').new_mod == 'io'

# Generated at 2022-06-18 00:20:02.201964
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:20:11.539895
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:20:22.614262
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.token import NAME, OP
    from lib2to3.pytree import Leaf
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.fixer_util import Name, Attr, Call, ArgList, Dot
    from lib2to3.fixer_util import Comma, String, Number, Newline
    from lib2to3.fixer_util import token
    from lib2to3.fixer_util import syms as fixer_syms
    from lib2to3.fixer_util import Node
    from lib2to3.fixer_util import touch_import_top
    from lib2to3.fixer_util import find_root
    from lib2to3.fixer_util import find_binding

# Generated at 2022-06-18 00:20:34.182601
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO").name == "cStringIO"
    assert MovedAttribute

# Generated at 2022-06-18 00:20:39.982165
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:20:41.320745
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:20:52.989518
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:21:03.015161
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.token import NAME
    from lib2to3.fixer_util import Name
    from lib2to3.fixer_util import String
    from lib2to3.fixer_util import syms
    from lib2to3.fixer_util import token
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pytree import Leaf
    from lib2to3.pytree import Node
    from lib2to3.pytree import type_repr
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pgen2 import token
    from lib2to3.pgen2.token import NAME
    from lib2to3.pgen2.token import OP

# Generated at 2022-06-18 00:21:09.210855
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'name'
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'


# Generated at 2022-06-18 00:21:16.382443
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:21:22.646710
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'

    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'

# Generated at 2022-06-18 00:21:30.893071
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:21:43.272109
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:21:51.914738
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old", "new2")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old2", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old2", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old2", "new2")

# Generated at 2022-06-18 00:21:58.346318
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:22:05.763000
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'



# Generated at 2022-06-18 00:22:07.358495
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:22:19.880529
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:22:33.219234
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:22:40.588451
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:22:50.571580
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:22:51.913422
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:22:56.981957
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:22:59.521990
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:23:06.393712
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)

# Generated at 2022-06-18 00:23:11.941186
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-18 00:23:17.697288
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(prefixed_moves) * (len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes))

# Generated at 2022-06-18 00:23:28.020759
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO").name == "cStringIO"
    assert MovedAttribute

# Generated at 2022-06-18 00:23:43.211380
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:23:50.909843
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old", "new2")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old2", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old2", "new2")

# Generated at 2022-06-18 00:23:53.206163
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:24:03.651930
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old", "new2")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old2", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old", "new")
    assert MovedModule("name", "old") == MovedModule("name", "old")
    assert MovedModule("name", "old") != MovedModule("name2", "old")
    assert MovedModule("name") == MovedModule("name")
    assert MovedModule("name") != MovedModule("name2")


# Generated at 2022-06-18 00:24:06.575852
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:24:10.123023
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-18 00:24:22.343891
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"


# Generated at 2022-06-18 00:24:27.420960
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-18 00:24:28.903063
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:24:36.613883
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:24:58.353981
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:25:10.755437
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:25:12.209536
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:25:20.787833
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:25:30.789348
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-18 00:25:41.983880
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:25:54.368334
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:26:04.655063
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:26:16.228635
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:26:17.692168
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:26:52.396824
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:26:53.665374
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:26:56.729702
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"


# Generated at 2022-06-18 00:26:59.989377
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-18 00:27:06.079353
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:27:07.356978
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:27:09.131100
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:27:19.310816
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:27:28.985442
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:27:40.148782
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:28:38.908406
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-18 00:28:44.135231
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:28:55.397234
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-18 00:28:59.541180
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"

# Generated at 2022-06-18 00:29:04.772217
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-18 00:29:15.038304
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:29:18.111481
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:29:25.781383
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:29:34.051811
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"