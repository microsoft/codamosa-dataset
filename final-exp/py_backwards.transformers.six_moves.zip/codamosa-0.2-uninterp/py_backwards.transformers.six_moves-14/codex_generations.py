

# Generated at 2022-06-18 00:19:37.786883
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)
    assert SixMovesTransformer.dependencies == ['six']
    assert SixMovesTransformer.target == (2, 7)

# Generated at 2022-06-18 00:19:43.284707
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:19:49.325742
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"


# Generated at 2022-06-18 00:19:51.219818
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)

# Generated at 2022-06-18 00:19:56.317107
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-18 00:20:06.949093
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:20:18.584748
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "newStringIO").name

# Generated at 2022-06-18 00:20:19.893922
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:20:21.195695
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:20:27.243128
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__', '__builtin__').new == '__builtin__'


# Generated at 2022-06-18 00:20:41.924206
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", None).name == "cStringIO"
    assert M

# Generated at 2022-06-18 00:20:53.076205
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == {'name': 'cStringIO', 'new_mod': 'io', 'new_attr': 'StringIO'}
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").__dict__ == {'name': 'filter', 'new_mod': 'builtins', 'new_attr': 'filter'}
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").__dict__ == {'name': 'filterfalse', 'new_mod': 'itertools', 'new_attr': 'filterfalse'}
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").__dict

# Generated at 2022-06-18 00:21:03.588922
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:21:04.988112
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:21:12.314644
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:21:23.222498
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:21:24.497866
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:21:27.637471
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-18 00:21:34.806366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:21:36.318372
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:21:51.013247
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'

# Generated at 2022-06-18 00:21:55.906766
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:22:04.190281
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:22:13.099777
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').name == 'filter'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == 'builtins'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'

# Generated at 2022-06-18 00:22:24.713909
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:22:27.568151
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:22:33.841740
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-18 00:22:35.744120
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:22:46.236682
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:22:56.562569
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old", "new2")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old2", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old2", "new2")
    assert MovedModule("name", "old", "new") != MovedModule("name2", "old2", "new")

# Generated at 2022-06-18 00:23:17.229643
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.tokenize import generate_tokens
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pytree import Leaf, Node
    from lib2to3.fixer_util import Name, Call, Comma, ArgList, String
    from lib2to3.fixer_util import LParen, RParen
    from lib2to3.fixer_util import token

    # Test that the constructor of class SixMovesTransformer works as expected
    # by creating a SixMovesTransformer object and checking that the rewrites
    # attribute is set correctly.
    #
    # The constructor of class SixMovesTransformer calls the eager function
    # _get_rewrites to set the rewrites attribute. The _get_rewrites function
    # returns a

# Generated at 2022-06-18 00:23:27.856070
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:23:31.280015
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:23:33.375236
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:23:42.904112
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:23:48.369135
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").old == "old"


# Generated at 2022-06-18 00:23:54.495346
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:23:56.023405
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:24:02.209130
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:24:07.353865
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:24:19.161761
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:24:26.847065
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:24:28.389972
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:24:39.348097
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_mod == 'old_mod'

# Generated at 2022-06-18 00:24:41.449753
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-18 00:24:52.983238
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:24:57.353309
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-18 00:25:09.897499
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:25:15.545235
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:25:22.782444
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-18 00:25:52.211851
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-18 00:25:53.704354
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:25:59.778226
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"

    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

# Generated at 2022-06-18 00:26:03.957940
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:26:15.611563
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:26:17.111720
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:26:18.442326
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-18 00:26:27.068599
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'old', 'new2')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'old2', 'new')
    assert MovedModule('name', 'old', 'new') != MovedModule('name2', 'old', 'new')
    assert MovedModule('name', 'old', 'new') != MovedModule('name2', 'old2', 'new')

# Generated at 2022-06-18 00:26:37.163763
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO").name == "cStringIO"
    assert MovedAttribute

# Generated at 2022-06-18 00:26:50.069117
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:27:49.829493
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-18 00:27:54.054675
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:28:05.742770
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-18 00:28:17.481819
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").name == "copyreg"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").name == "dbm_gnu"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").new == "dbm.gnu"

# Generated at 2022-06-18 00:28:20.803330
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:28:31.447594
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').name == 'filter'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == 'builtins'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'

# Generated at 2022-06-18 00:28:39.079496
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"


# Generated at 2022-06-18 00:28:44.291439
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-18 00:28:50.330776
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"


# Generated at 2022-06-18 00:29:00.191131
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"