

# Generated at 2022-06-21 17:57:18.117887
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_mod == 'builtins'
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'
    assert MovedAttribute('zip', 'itertools', 'builtins', 'izip', 'zip').new_mod == 'builtins'

# Generated at 2022-06-21 17:57:25.153409
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.fixes.fix_imports import FixImports
    from libmodernize.fixes.fix_six_moves import SixMovesTransformer

    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert ('six.moves{}.{}'.format(prefix, move.name), path) in FixImports.explicit, path
            elif isinstance(move, MovedModule):
                assert ('six.moves{}.{}'.format(prefix, move.name), move.new) in FixImports.explicit, move.new

# Generated at 2022-06-21 17:57:36.188366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('test1', 'test2', 'test3')
    assert m.name == 'test1'
    assert m.new_mod == 'test3'
    assert m.new_attr == 'test1'
    m = MovedAttribute('test1', 'test2', 'test3', 'test4')
    assert m.name == 'test1'
    assert m.new_mod == 'test3'
    assert m.new_attr == 'test4'
    m = MovedAttribute('test1', 'test2', 'test3', new_attr='test4')
    assert m.name == 'test1'
    assert m.new_mod == 'test3'
    assert m.new_attr == 'test4'

# Generated at 2022-06-21 17:57:40.697593
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "a", "b")
    assert obj.name == "name"
    assert obj.new == "b"
    obj = MovedModule("name", "a")
    assert obj.new == "name"

# Generated at 2022-06-21 17:57:46.524395
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # This is a hack, but it works:
    from six import moves

    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedModule):
                assert hasattr(moves, move.name), (
                    "SixMovesTransformer cannot import six.moves.{}"
                    "".format(move.name)
                )

# Generated at 2022-06-21 17:57:47.863338
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("os.path", "ntpath", "posixpath")

# Generated at 2022-06-21 17:57:50.944590
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = 'MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")'
    assert eval(moved_attribute).__repr__() == moved_attribute


# Generated at 2022-06-21 17:57:54.697011
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("TestName", "TestOld", "TestNew")
    assert moved_module.name == 'TestName'
    assert moved_module.new == 'TestNew'


# Generated at 2022-06-21 17:58:04.197695
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("test", "test_mod", None).name == "test"
    assert MovedAttribute("test", "test_mod", None).new_mod == "test"
    assert MovedAttribute("test", "test_mod", None).new_attr == "test"
    assert MovedAttribute("test", "test_mod", None, None, "new_attr").new_attr == "new_attr"
    assert MovedAttribute("test", "test_mod", None, "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("test", "test_mod", None, "old_attr", "new_attr").name == "test"
    assert MovedAttribute("test", "test_mod", None, "old_attr", "new_attr").new_mod == "test"
   

# Generated at 2022-06-21 17:58:07.822562
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer is not None

# Generated at 2022-06-21 17:58:12.947357
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('newname', 'oldname', 'oldname')
    print(mm.new)
    print(mm.name)
    print(mm)

# Generated at 2022-06-21 17:58:14.916268
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert repr(SixMovesTransformer).startswith('SixMovesTransformer(')

# Generated at 2022-06-21 17:58:22.733252
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == 'cStringIO'
    assert obj.new_mod == 'cStringIO'
    assert obj.new_attr == 'StringIO'

    obj = MovedAttribute("cStringIO", "cStringIO", "io")
    assert obj.name == 'cStringIO'
    assert obj.new_mod == 'cStringIO'
    assert obj.new_attr == 'cStringIO'

    obj = MovedAttribute("cStringIO", "cStringIO", None, new_attr="StringIO")
    assert obj.name == 'cStringIO'
    assert obj.new_mod == 'cStringIO'
    assert obj.new_attr == 'StringIO'


# Generated at 2022-06-21 17:58:24.346488
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites

# Generated at 2022-06-21 17:58:25.302245
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t is not None

# Unit tests for code copied from six

# Generated at 2022-06-21 17:58:29.689616
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod_test = MovedModule('test', 'old', 'new')
    assert mod_test.name == 'test'
    assert mod_test.new == 'new'
    mod_test2 = MovedModule('test2', 'old2')
    assert mod_test2.name == 'test2'
    assert mod_test2.new == 'test2'


# Generated at 2022-06-21 17:58:39.414400
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test the main constructor
    mod = MovedModule('fname', 'old', 'new')
    assert mod.name == 'fname'
    assert mod.old == 'old'
    assert mod.new == 'new'

    mod = MovedModule('fname', 'old')
    assert mod.name == 'fname'
    assert mod.old == 'old'
    assert mod.new == 'fname'

    mod = MovedModule('fname')
    assert mod.name == 'fname'
    assert mod.old == 'fname'
    assert mod.new == 'fname'


# Generated at 2022-06-21 17:58:41.350897
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new = MovedModule("new", "old")
    assert new.name == "new"
    assert new.old == "old"
    assert new.new == "new"



# Generated at 2022-06-21 17:58:42.640565
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites() == SixMovesTransformer.rewrites

# Generated at 2022-06-21 17:58:45.297473
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("abc","abc_old")
    assert mm.name == "abc"
    assert mm.new == "abc"
    assert mm.old == "abc_old"


# Generated at 2022-06-21 17:58:58.192537
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test simple source, same name
    assert MovedModule("simple", "simple").new == "simple"
    assert MovedModule("simple", "simple").name == "simple"

    # Test simple source, different name
    assert MovedModule("different", "simple").new == "different"
    assert MovedModule("different", "simple").name == "simple"

    # Test container source and name, different name
    assert MovedModule(
        "different", "container.simple").new == "container.different"
    assert MovedModule(
        "different", "container.simple").name == "container.simple"

    # Test subcontainer source and name, different name
    assert MovedModule(
        "different", "container.subcontainer.simple").new == "container.subcontainer.different"

# Generated at 2022-06-21 17:59:03.697672
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("obj", "old", "new")
    assert moved_module.name == "obj"
    assert moved_module.new == "new"
    moved_module2 = MovedModule("obj2", "old")
    assert moved_module2.name == "obj2"
    assert moved_module2.new == "obj2"


# Generated at 2022-06-21 17:59:16.048546
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint:disable=unused-variable
    # pylint:disable=pointless-string-statement
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                if move.new_mod == 'os':
                    move.new_mod = 'os.path'
                if move.new_mod == 'tkinter.dialog':
                    # FIXME: Need to add the following line to get the
                    # case working:
                    #    "import six.moves.tkinter_dialog"
                    #
                    # This is not done in move_imports in order to avoid
                    # "import six" to be placed before "import os", which
                    # is wrong since six must be imported after os.
                    continue

# Generated at 2022-06-21 17:59:23.293354
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                if prefix == '':
                    yield check_py27, path, 'import six.moves\n{} = six.moves.{}'.format(move.name, move.name)
                else:
                    yield check_py27, path, 'import six.moves{}\n{} = six.moves{}.{}'.format(prefix, move.name, prefix, move.name)

# Generated at 2022-06-21 17:59:34.641457
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests SixMovesTransformer."""

# Generated at 2022-06-21 17:59:45.532782
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test default values
    # type: ignore
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    # type: ignore
    assert MovedAttribute('name', 'old_mod', 'new_mod').old_mod is None
    # type: ignore
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'name'
    # type: ignore
    assert MovedAttribute('name', 'old_mod', 'new_mod').old_attr is None
    # type: ignore
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'

    # Test if specified values are set
    # type: ignore

# Generated at 2022-06-21 17:59:56.652300
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert isinstance(MovedAttribute('__init__', 'test_case1', 'test_case2'), MovedAttribute)
    assert isinstance(MovedAttribute('__init__', 'test_case1', 'test_case2', 'test_case3'), MovedAttribute)
    assert isinstance(MovedAttribute('__init__', 'test_case1', 'test_case2', 'test_case3', 'test_case4'), MovedAttribute)
    assert isinstance(MovedAttribute('__init__', 'test_case1', None, 'test_case3', 'test_case4'), MovedAttribute)
    assert isinstance(MovedAttribute('__init__', 'test_case1', None, None, 'test_case4'), MovedAttribute)


# Generated at 2022-06-21 18:00:07.788817
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"

    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert move.new_attr == "old_attr"

    move = MovedAttribute("name", "old_mod", "new_mod")
    assert move.new_attr == "name"

    move = MovedAttribute("name", "old_mod")
    assert move.new_mod == "name"
    assert move.new_attr == "name"



# Generated at 2022-06-21 18:00:09.100872
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:00:20.433863
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    import libfuturize.fixes.six_moves.moves as libmoves
    assert six.moves.__name__ == 'libfuturize.fixes.six_moves.moves'
    assert libmoves.__name__ == 'libfuturize.fixes.six_moves.moves'
    assert six.moves.__package__ == 'libfuturize.fixes.six_moves'
    assert libmoves.__package__ == 'libfuturize.fixes.six_moves'
    assert six.moves.__path__ == [
        '/Users/jrf/p/libfuturize/libfuturize/fixes/six_moves']

# Generated at 2022-06-21 18:00:28.669972
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

# Generated at 2022-06-21 18:00:40.863368
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:44.348763
# Unit test for constructor of class MovedModule
def test_MovedModule():
    original_code = "from six.moves import urllib"
    expected_code = "import six.moves.urllib"
    tester = SixMovesTransformer()
    canonical_code = tester.canonicalize(original_code)
    assert canonical_code == expected_code

# Generated at 2022-06-21 18:00:51.604080
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:53.065962
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    res = SixMovesTransformer()
    assert res
    assert res.target == (2, 7)
    assert res.rewrites == _get_rewrites()
    assert res.dependencies == ['six']

# Generated at 2022-06-21 18:00:54.686580
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer({})
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 18:01:00.824290
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests basic operation"""
    # pylint: disable=missing-docstring
    code = """
from six.moves import input
from six.moves.cPickle import dump
from six.moves.email_mime_multipart import MIMEMultipart
from six.moves.html_parser import HTMLParser


from six.moves.urllib.request import urlopen
from six.moves.urllib.parse import urlsplit
from six.moves.urllib.error import URLError
"""

# Generated at 2022-06-21 18:01:01.948959
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("test", "a", "b", "d", "e")

# Generated at 2022-06-21 18:01:06.395465
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ca = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ca.name == "cStringIO"
    assert ca.new_mod == "io"
    assert ca.new_attr == "StringIO"



# Generated at 2022-06-21 18:01:14.001113
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves.urllib.parse
    assert six.moves.urllib.parse.quote == six.quote
    transformer = SixMovesTransformer({}, [])
    assert transformer.rewrites['urllib.parse.quote'] == 'six.moves.quote'
    assert transformer.rewrites['urllib.request.urlopen'] == 'six.moves.urllib.request.urlopen'

# Generated at 2022-06-21 18:01:31.178795
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    module = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert module.name == "cStringIO"
    assert module.new_mod == "io"
    assert module.new_attr == "StringIO"

    module = MovedAttribute("cStringIO", "cStringIO", "io")
    assert module.name == "cStringIO"
    assert module.new_mod == "io"
    assert module.new_attr == "cStringIO"

    module = MovedAttribute("cStringIO", "cStringIO", None)
    assert module.name == "cStringIO"
    assert module.new_mod == "cStringIO"
    assert module.new_attr == "cStringIO"


# Generated at 2022-06-21 18:01:38.531598
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("tkinter", "Tkinter")
    assert moved_module.name == "tkinter"
    assert moved_module.old == "Tkinter"
    assert moved_module.new == "tkinter"

    moved_module = MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert moved_module.name == "dbm_gnu"
    assert moved_module.old == "gdbm"
    assert moved_module.new == "dbm.gnu"


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:01:43.846063
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import astor
    code = "import six; print(six.moves.urllib); print(six.moves.urllib.parse); print(six.moves.urllib.parse.parse_qs)"
    code = astor.to_source(astor.code_to_ast(code))
    expected_code = "import six; print(six.moves.urllib.parse); print(six.moves.urllib.parse); print(six.moves.urllib.parse.parse_qs)"
    SixMovesTransformer(code).results() == expected_code

# Generated at 2022-06-21 18:01:55.015247
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()
    assert x.target == (2, 7)

# Generated at 2022-06-21 18:01:58.461947
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for attr in _moved_attributes:
        assert 'six.moves.{}'.format(attr.name) in SixMovesTransformer.rewrites

# Generated at 2022-06-21 18:02:05.318604
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert attribute.name == 'cStringIO'
    assert attribute.new_mod == 'io'
    assert attribute.new_attr == 'StringIO'
    # Should not test the last one here. Let it be tested in
    # test_mapping_of_six_moves_attributes() below.



# Generated at 2022-06-21 18:02:07.563315
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:02:09.874828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.new == "name"

# Generated at 2022-06-21 18:02:21.050617
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-21 18:02:28.235728
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.target == (2, 7)
    assert len(SixMovesTransformer.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)
    assert len(SixMovesTransformer.dependencies) == 1

# Generated at 2022-06-21 18:02:43.875042
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', None).new == 'name'
    assert MovedModule('name', 'old').old == 'old'


# Generated at 2022-06-21 18:02:50.808010
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"


# Generated at 2022-06-21 18:02:59.881594
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'

    move = MovedAttribute('name', 'old_mod', None)
    assert move.name == 'name'
    assert move.new_mod == 'name'
    assert move.new_attr == 'name'

    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'old_attr'


# Generated at 2022-06-21 18:03:03.938339
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("configparser", "ConfigParser")
    assert move.name == "configparser"
    assert move.new == "configparser"
    assert move.old == "ConfigParser"

# Generated at 2022-06-21 18:03:06.553740
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    converter = SixMovesTransformer()
    assert converter.target == (2, 7)
    assert converter.dependencies == ['six']

# Generated at 2022-06-21 18:03:15.283705
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__init__("cStringIO", "cStringIO", "io", "StringIO") == None 
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").__init__("filter", "itertools", "builtins", "ifilter", "filter") == None
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").__init__("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse") == None

# Generated at 2022-06-21 18:03:17.788356
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    SixMovesTransformer.__init__(SixMovesTransformer)

# Generated at 2022-06-21 18:03:19.329713
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0

# Generated at 2022-06-21 18:03:21.202602
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == 'cStringIO'
    assert a.new_mod == 'io'
    assert a.new_attr == 'StringIO'

# Generated at 2022-06-21 18:03:32.954180
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    tma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert tma.name == "cStringIO"
    assert tma.new_mod == "cStringIO"
    assert tma.new_attr == "StringIO"
    tma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert tma.name == "cStringIO"
    assert tma.new_mod == "cStringIO"
    assert tma.new_attr == "cStringIO"
    tma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")
    assert tma.name == "cStringIO"
    assert tma.new_mod == "cStringIO"

# Generated at 2022-06-21 18:04:03.833625
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("parse_qs", "urlparse", "urllib.parse")
    assert item.name == "parse_qs"
    assert item.old_mod is None
    assert item.old_attr is None
    assert item.new_mod == "urllib.parse"
    assert item.new_attr == "parse_qs"


# Generated at 2022-06-21 18:04:06.019537
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import py2to3.fixes.fix_imports
    assert 'SixMovesTransformer' in py2to3.fixes.fix_imports.__all__

# Generated at 2022-06-21 18:04:11.129987
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"



# Generated at 2022-06-21 18:04:22.618012
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import astor
    
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']
    assert len(transformer.rewrites) == 65


# Generated at 2022-06-21 18:04:26.733248
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'


# Generated at 2022-06-21 18:04:38.651804
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import ast
    from ..migrations import SixMovesTransformer
    from ..utils.helpers import eager
    from .base import BaseImportRewrite


# Generated at 2022-06-21 18:04:50.167206
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(2, 7)

# Generated at 2022-06-21 18:04:57.972943
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("moved", "old", "new").name == 'moved'
    assert MovedAttribute("moved", "old", "new").new_mod == 'new'
    assert MovedAttribute("moved", "old", "new").new_attr == 'moved'
    assert MovedAttribute("moved", "old", "new", "old_attr").name == 'moved'
    assert MovedAttribute("moved", "old", "new", "old_attr").new_mod == 'new'
    assert MovedAttribute("moved", "old", "new", "old_attr").new_attr == 'old_attr'
    assert MovedAttribute("moved", "old", "new", "old_attr", "new_attr").name == 'moved'

# Generated at 2022-06-21 18:04:59.269698
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    check_comment(SixMovesTransformer.rewrites)
    assert SixMovesTransformer.rewrites == list(_get_rewrites())

# Generated at 2022-06-21 18:05:00.784699
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert t.dependencies == ['six']
    assert t.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:06:11.708384
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").name == "filterfalse"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").name == "input"
    assert MovedAttribute("intern", "__builtin__", "sys").name == "intern"
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map").name == "map"

# Generated at 2022-06-21 18:06:13.096143
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')

# Generated at 2022-06-21 18:06:18.204315
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"


# Generated at 2022-06-21 18:06:26.929823
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule(name='test_name', old='test_old', new='test_new')
    assert mm.name is 'test_name'
    assert mm.old is 'test_old'
    assert mm.new is 'test_new'

    mm = MovedModule(name='test_name', old='test_old')
    assert mm.name is 'test_name'
    assert mm.old is 'test_old'
    assert mm.new is 'test_name'

    mm = MovedModule(name='test_name')
    assert mm.name is 'test_name'
    assert mm.old is 'test_name'
    assert mm.new is 'test_name'



# Generated at 2022-06-21 18:06:34.836060
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites)  == len(_moved_attributes) + len(_urllib_parse_moved_attributes) \
                                                + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) \
                                                + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)



# Generated at 2022-06-21 18:06:36.629639
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.new == 'builtins'


# Generated at 2022-06-21 18:06:38.906385
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")

# Generated at 2022-06-21 18:06:48.786799
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("a", "b", "c")
    assert a.name == "a"
    assert a.new_mod == "a"
    assert a.new_attr == "a"
    a = MovedAttribute("a", "b", "c", "d")
    assert a.name == "a"
    assert a.new_mod == "a"
    assert a.new_attr == "d"
    a = MovedAttribute("a", "b", "c", "d", "e")
    assert a.name == "a"
    assert a.new_mod == "a"
    assert a.new_attr == "e"

# Generated at 2022-06-21 18:06:52.527662
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("TestMove", "__builtin__", "builtins")

    assert module.name == "TestMove"
    assert module.old == "__builtin__"
    assert module.new == "builtins"



# Generated at 2022-06-21 18:06:55.707426
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert list(t.rewrites)[:3] == [
        ('io.StringIO', 'six.moves.StringIO'),
        ('builtins.filter', 'six.moves.filter'),
        ('builtins.map', 'six.moves.map')
    ]