

# Generated at 2022-06-21 17:57:01.545660
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Unit test for constructor of class SixMovesTransformer."""
    transforms = [SixMovesTransformer]
    return transforms

# Generated at 2022-06-21 17:57:05.153354
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('foo.bar', 'fub.baz')
    assert m.name == 'foo.bar'
    assert m.new == 'foo.bar'
    assert m.old == 'fub.baz'

# Generated at 2022-06-21 17:57:08.579171
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert isinstance(instance, BaseImportRewrite)
    assert SixMovesTransformer.target[0] == 2
    assert SixMovesTransformer.target[1] == 7
    assert len(SixMovesTransformer.rewrites) == 69

# Generated at 2022-06-21 17:57:15.647727
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    if sys.version_info.major > 2:
        return

    t = SixMovesTransformer('')
    assert 'six.moves.builtins' in t.rewrites.values(), 'all moved items must be mapped'
    assert 'six.moves.http.cookies' in t.rewrites.values(), 'all moved items must be mapped'

# Generated at 2022-06-21 17:57:25.043674
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # level of indentation = 1
    code = "from six.moves import xrange"
    assert SixMovesTransformer.is_applicable(code)
    assert SixMovesTransformer.is_applicable(code, python_version=[2, 7])
    assert not SixMovesTransformer.is_applicable(code, python_version=[2, 6])
    assert code in SixMovesTransformer.applicable_codes(python_version=[2, 7])
    assert not SixMovesTransformer.applicable_codes(python_version=[2, 6])


# Generated at 2022-06-21 17:57:33.693683
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"


# Generated at 2022-06-21 17:57:37.534856
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule('foo')
    MovedModule('foo', 'bar')
    MovedModule('foo', 'bar', 'baz')

# Generated at 2022-06-21 17:57:42.344713
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("name", "old", "new")
    assert test_module.name == "name"
    assert test_module.old == "old"
    assert test_module.new == "new"



# Generated at 2022-06-21 17:57:49.852967
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils import get_ast

# Generated at 2022-06-21 17:57:52.442780
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.old == 'old'
    assert module.new == 'new'


# Generated at 2022-06-21 17:58:03.849423
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pygram import python_symbols as syms
    from libmodernize.fixes.fix_six_moves import SixMovesTransformer
    from lib2to3.pgen2 import token
    internal_node = six.next(SixMovesTransformer.depending_nodes(syms.power))
    name = internal_node.children[1].value
    assert name == 'six'
    import_node = internal_node.children[3]
    assert import_node.type == token.NAME and import_node.value == 'moves'
    names = import_node.children[2].children
    names_list = [name.children[0].value for name in names]
    assert 'cStringIO' in names_list
    assert 'filter' in names_list
    assert 'StringIO' in names

# Generated at 2022-06-21 17:58:08.895753
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites[0] == ('builtins.StringIO', 'six.moves.cStringIO.StringIO')

transformer = SixMovesTransformer

# Generated at 2022-06-21 17:58:14.954345
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("name", "old")
    assert move.name == "name"
    assert move.old == "old"
    assert move.new == "name"
    move = MovedModule("name", "old", "new")
    assert move.name == "name"
    assert move.old == "old"
    assert move.new == "new"


# Generated at 2022-06-21 17:58:27.645954
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", None).new_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", None).name == "cStringIO"
    # Check for the automatic name copy when the new attribute
    # is not specified.

# Generated at 2022-06-21 17:58:33.374299
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

# Generated at 2022-06-21 17:58:43.640825
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo").name == "foo"
    assert MovedAttribute("foo").new_mod == "foo"
    assert MovedAttribute("foo").new_attr == "foo"

    assert MovedAttribute("foo", "bar", "baz").name == "foo"
    assert MovedAttribute("foo", "bar", "baz").new_mod == "baz"
    assert MovedAttribute("foo", "bar", "baz").new_attr == "foo"

    assert MovedAttribute("foo", "bar", "baz", "attr").name == "foo"
    assert MovedAttribute("foo", "bar", "baz", "attr").new_mod == "baz"
    assert MovedAttribute("foo", "bar", "baz", "attr").new_attr == "attr"


# Generated at 2022-06-21 17:58:52.028034
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:04.887266
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Function to test SixMovesTransformer."""
    # Arrange

# Generated at 2022-06-21 17:59:17.059784
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "ReallyStringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "ReallyStringIO"


# Generated at 2022-06-21 17:59:29.975788
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 99
    assert (
        sorted(SixMovesTransformer.rewrites)[0:3] ==
        [('urllib.error.ContentTooShortError', 'six.moves.urllib.content_too_short_error'),
         ('urllib.error.HTTPError', 'six.moves.urllib.http_error'),
         ('urllib.error.URLError', 'six.moves.urllib.url_error')]
    )

# Generated at 2022-06-21 17:59:45.166107
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'bar', 'baz').__dict__ == {'name': 'foo', 'old_mod': 'bar',
                                                            'new_mod': 'baz', 'old_attr': None, 'new_attr': 'foo'}

    assert MovedAttribute('foo', 'bar', 'baz', 'qux').__dict__ == {'name': 'foo', 'old_mod': 'bar',
                                                                   'new_mod': 'baz', 'old_attr': 'qux', 'new_attr': 'qux'}


# Generated at 2022-06-21 17:59:56.727223
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") == MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") != MovedAttribute("name", "old_mod2", "new_mod", "old_attr", "new_attr")
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr") != MovedAttribute("name2", "old_mod", "new_mod", "old_attr", "new_attr")

# Generated at 2022-06-21 18:00:08.457957
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('foo', 'baz', 'bar')
    assert attr.name == 'foo'
    assert attr.new_mod == 'bar'
    assert attr.new_attr == 'foo'

    attr = MovedAttribute('foo', 'baz', 'bar', 'foo', 'bar')
    assert attr.name == 'foo'
    assert attr.new_mod == 'bar'
    assert attr.new_attr == 'bar'

    attr = MovedAttribute('foo', 'baz', 'bar', 'foo2')
    assert attr.name == 'foo'
    assert attr.new_mod == 'bar'
    assert attr.new_attr == 'foo2'


# Generated at 2022-06-21 18:00:14.748811
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("abc", "old")
    assert m.name == "abc"
    assert m.old == "old"
    assert m.new == "abc"
    m = MovedModule("abc", "old", "new")
    assert m.name == "abc"
    assert m.old == "old"
    assert m.new == "new"



# Generated at 2022-06-21 18:00:24.748461
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("builtins", "__builtin__")
    MovedModule("configparser", "ConfigParser")
    MovedModule("copyreg", "copy_reg")
    MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread")
    MovedModule("http_cookiejar", "cookielib", "http.cookiejar")
    MovedModule("http_cookies", "Cookie", "http.cookies")
    MovedModule("html_entities", "htmlentitydefs", "html.entities")
    MovedModule("html_parser", "HTMLParser", "html.parser")
    MovedModule("http_client", "httplib", "http.client")

# Generated at 2022-06-21 18:00:32.813850
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # Test with a normal constructor (input: new_name, old_name)
    assert MovedModule("new_name", "old_name").name == "new_name"
    assert MovedModule("new_name", "old_name").new == "new_name"

    # Test with a constructor with 2nd argument None
    # (input: old_name, new_name=None)
    assert MovedModule("old_name").name == "old_name"
    assert MovedModule("old_name").new == "old_name"

    # Test with a constructor with 2nd argument not None
    # (input: old_name, new_name=not_none)
    assert MovedModule("old_name", "new_name").name == "old_name"
    assert MovedModule("old_name", "new_name").new

# Generated at 2022-06-21 18:00:37.471447
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mod = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mod.name == "cStringIO"
    assert mod.new_mod == "io"
    assert mod.new_attr == "StringIO"

# Generated at 2022-06-21 18:00:47.755189
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("abc", "abc") == MovedModule("abc", "abc")
    assert MovedModule("abc", "abc", "xyz") == MovedModule("abc", "abc", "xyz")
    assert MovedModule("abc", "xyz", "xyz") == MovedModule("abc", "xyz", "xyz")
    assert MovedModule("xyz", "abc", "xyz") == MovedModule("xyz", "abc", "xyz")
    assert MovedModule("xyz", "abc") == MovedModule("xyz", "abc", "xyz")
    assert MovedModule("abc", "abc", None) == MovedModule("abc", "abc")
    assert MovedModule("abc", "abc", "") == MovedModule("abc", "abc")

# Generated at 2022-06-21 18:00:53.899188
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "cStringIO"
    old_mod = "cStringIO"
    new_mod = "io"
    old_attr = "StringIO"
    new_attr = None
    move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert move.name == name
    assert move.new_mod == new_mod
    assert move.new_attr == old_attr

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 18:00:58.471817
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old')
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old') != MovedModule('xxx', 'old')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'old', 'xxx')
    assert MovedModule('name', 'old', None) == MovedModule('name', 'old')

# Generated at 2022-06-21 18:01:12.635802
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # type: () -> None
    """Test constructor of class MovedModule"""
    move = MovedModule("qwerty", "aaaaa")
    assert move.name == "qwerty"
    assert move.new == "aaaaa"
    move = MovedModule("ertty", "bbbbb", "cccc")
    assert move.name == "ertty"
    assert move.new == "cccc"



# Generated at 2022-06-21 18:01:20.518086
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_module", "new_module")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_module"
    assert moved_attribute.new_attr == "name"
    moved_attribute = MovedAttribute("name", "old_module", "new_module", "old_attr")
    assert moved_attribute.new_attr == "old_attr"
    moved_attribute = MovedAttribute("name", "old_module", "new_module", None, "new_attr")
    assert moved_attribute.new_attr == "new_attr"
    moved_attribute = MovedAttribute("name", "old_module", "new_module", "old_attr", "new_attr")
    assert moved_attribute.new_attr == "new_attr"

# Generated at 2022-06-21 18:01:25.302290
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(MovedModule('builtins', '__builtin__'))
    assert(MovedModule('builtins', '__builtin__', 'builtins'))
    assert(MovedModule('builtins', '__builtin__', 'builtins'))



# Generated at 2022-06-21 18:01:27.639916
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == 'name'
    assert m.new == 'name'


# Generated at 2022-06-21 18:01:33.779126
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new  == 'new'
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new  == 'old'
    mm = MovedModule('name')
    assert mm.name == 'name'
    assert mm.new  == 'name'



# Generated at 2022-06-21 18:01:37.996292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import six_moves as module
    assert module.SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert module.SixMovesTransformer.__doc__ == SixMovesTransformer.__doc__
    assert module.SixMovesTransformer.target == (2, 7)

# Generated at 2022-06-21 18:01:40.377235
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("foo", "bar")
    assert m.name == "foo"
    assert m.new == "foo"
    assert m.old == "bar"


# Generated at 2022-06-21 18:01:53.136729
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import os
    import time
    import unittest.mock as mock

    from _pytest.monkeypatch import MonkeyPatch
    from mypy_boto3_builder.import_helpers.import_rewrites.six_moves import SixMovesTransformer
    from mypy_boto3_builder.import_helpers.import_rewrites.base import BaseImportRewrite

    x = SixMovesTransformer()
    assert isinstance(x, BaseImportRewrite)
    assert x.rewrites == _get_rewrites()
    assert x.dependencies == ['six']
    assert x.target == (2, 7)

    # Test __init__.__dict__
    assert hasattr(x, 'target')
    assert hasattr(x, 'rewrites')
    assert hasattr(x, 'dependencies')



# Generated at 2022-06-21 18:01:59.096288
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.new == 'foo'
    assert mm.old == 'bar'

    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.new == 'baz'
    assert mm.old == 'bar'



# Generated at 2022-06-21 18:02:11.429520
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod",
                          "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod",
                          "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod",
                          "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod",
                          "old_attr", "new_attr").old_mod == "old_mod"

# Generated at 2022-06-21 18:02:27.037914
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test 1: new = None
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'

    # Test 2: new = newname
    assert MovedModule('name', 'old', 'newname').name == 'name'
    assert MovedModule('name', 'old', 'newname').new == 'newname'



# Generated at 2022-06-21 18:02:40.283888
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test SixMovesTransformer's constructor"""

    transformer = SixMovesTransformer(None)

# Generated at 2022-06-21 18:02:44.813376
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old")
    assert module.name == "name"
    assert module.new == "name"
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.new == "new"


# Generated at 2022-06-21 18:02:51.425546
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    mod = SixMovesTransformer()
    assert isinstance(mod, BaseImportRewrite)
    assert mod.rewrites == list(_get_rewrites())
    assert mod.dependencies == ['six']
    assert mod.target == (2, 7)


# Generated at 2022-06-21 18:02:54.323937
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    assert six.moves.tkinter == Tkinter
    assert six.moves.tkinter.dialog == tkinter.dialog



# Generated at 2022-06-21 18:02:56.498925
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule("name", "old", "new")
    assert movedModule.name == "name"
    assert movedModule.old == "old"
    assert movedModule.new == "new"

# Generated at 2022-06-21 18:03:08.459516
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", None).new_attr == "old_attr"
    assert MovedAttribute("name", "old_mod", None, None, None).new_mod == "name"
    assert MovedAttribute("name", "old_mod", None, None, None).new_attr == "name"

# Generated at 2022-06-21 18:03:11.306726
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("module_name", "old", "new")
    assert mod.name == "module_name"
    assert mod.old == "old"
    assert mod.new == "new"


# Generated at 2022-06-21 18:03:12.282009
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.getstatusoutput' in dir(SixMovesTransformer)

# Generated at 2022-06-21 18:03:24.285209
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:03:51.501699
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=unused-variable, expression-not-assigned
    SixMovesTransformer


# Generated at 2022-06-21 18:03:53.043705
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == list(_get_rewrites())

# Generated at 2022-06-21 18:03:58.262714
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(name="n1", old="o1") == MovedModule(name="n1", old="o1", new="n1")
    assert MovedModule(name="n1", old="o1", new="n2") == MovedModule(name="n1", old="o1", new="n2")

# Generated at 2022-06-21 18:04:03.335289
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b").name == "a"
    assert MovedModule("a", "b").new == "a"
    assert MovedModule("a", "b", "c").new == "c"
    assert MovedModule("a", "b", "c").name == "a"
    assert MovedModule("a", "b", "c").old == "b"


# Generated at 2022-06-21 18:04:09.425122
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    actual = MovedAttribute("a", "b", "c")
    expected = MovedAttribute("a", "b", "c", None, None)
    assert actual == expected
    actual = MovedAttribute("a", "b")
    expected = MovedAttribute("a", "b", "a", None, None)
    assert actual == expected
    actual = MovedAttribute("a", "b", "c", "d")
    expected = MovedAttribute("a", "b", "c", "d", "d")
    assert actual == expected
    actual = MovedAttribute("a", "b", "c", "d", "e")
    expected = MovedAttribute("a", "b", "c", "d", "e")
    assert actual == expected


# Generated at 2022-06-21 18:04:21.362334
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..tests.utils import target_from
    from ..exceptions import UnsupportedPythonVersion
    from ..refactor import RefactoringTool

    # Assert that constructor for SixMovesTransformer fails
    # with an exception if a target version is smaller
    # than 2.7
    with pytest.raises(UnsupportedPythonVersion):
        trans = SixMovesTransformer(target_from(('2', '6', '0')))

    # Assert that constructor for SixMovesTransformer fails
    # with an exception if a target version is greater
    # than 3.0
    with pytest.raises(UnsupportedPythonVersion):
        trans = SixMovesTransformer(target_from(('3', '1', '0')))

    # Assert that constructor for SixMovesTransformer does not
    # raise an exception if a target version

# Generated at 2022-06-21 18:04:24.419049
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-21 18:04:30.098314
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=invalid-name
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'
    mm = MovedModule('name')
    assert mm.name == 'name'
    assert mm.old == 'name'
    assert mm.new == 'name'


# Generated at 2022-06-21 18:04:35.000551
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('attribute', 'module').name == 'attribute'
    assert MovedModule('attribute', 'module').new == 'attribute'

    assert MovedModule('attribute', 'module', 'new').name == 'attribute'
    assert MovedModule('attribute', 'module', 'new').new == 'new'



# Generated at 2022-06-21 18:04:40.353769
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mv.name == "cStringIO"
    assert mv.new_mod == "io"
    assert mv.new_attr == "StringIO"
    mv = MovedAttribute("intern", "__builtin__", "sys")
    assert mv.name == "intern"
    assert mv.new_mod == "sys"
    assert mv.new_attr == "intern"



# Generated at 2022-06-21 18:05:43.330791
# Unit test for constructor of class MovedModule
def test_MovedModule():
        assert MovedModule("builtins", "__builtin__").name == "builtins"
        assert MovedModule("builtins", "__builtin__").new == "builtins"
        assert MovedModule("builtins", "__builtin__", "builtins").name == "builtins"
        assert MovedModule("builtins", "__builtin__", "builtins").new == "builtins"



# Generated at 2022-06-21 18:05:45.651919
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == sum(len(moves) for prefix, moves in prefixed_moves)

# Generated at 2022-06-21 18:05:48.694501
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("configparser", "ConfigParser")
    assert moved_module.name == "configparser"
    assert moved_module.new == "configparser"



# Generated at 2022-06-21 18:05:51.065991
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    to_test = str(SixMovesTransformer.rewrites) == str(_get_rewrites())
    assert to_test

# Generated at 2022-06-21 18:05:59.226926
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", None)
    assert move.name == "cStringIO"
    assert move.new_mod == "cStringIO"
    assert move.new_attr == "cStringIO"


# Generated at 2022-06-21 18:06:01.481877
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'


# Generated at 2022-06-21 18:06:11.553834
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("subprocess", "subprocess", "subprocess")
    assert moved_module.name == "subprocess"
    assert moved_module.new == "subprocess"
    moved_module = MovedModule("subprocess", "subprocess")
    assert moved_module.name == "subprocess"
    assert moved_module.new == "subprocess"
    moved_module = MovedModule("subprocess", "subprocess", "subprocess.foo")
    assert moved_module.name == "subprocess"
    assert moved_module.new == "subprocess.foo"


# Generated at 2022-06-21 18:06:23.199748
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO') != MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO1')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO') != MovedAttribute('cStringIO', 'cStringIO', 'io1', 'StringIO', 'StringIO')

# Generated at 2022-06-21 18:06:27.140511
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert SixMovesTransformer.rewrites[-1] == ('urllib.robotparser.RobotFileParser',
                                                'six.moves.urllib.robotparser.RobotFileParser')

# Generated at 2022-06-21 18:06:30.889431
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MODULE_NAME = "bm"
    module = MovedModule(MODULE_NAME, "a", "b")
    assert module.name == MODULE_NAME
    assert module.new == "b"

