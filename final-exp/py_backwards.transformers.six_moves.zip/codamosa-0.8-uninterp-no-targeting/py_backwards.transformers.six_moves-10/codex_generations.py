

# Generated at 2022-06-21 17:57:07.091252
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod")
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'name'


# Generated at 2022-06-21 17:57:14.261354
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")

# Generated at 2022-06-21 17:57:19.532812
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == "new_attr"

# Generated at 2022-06-21 17:57:22.586588
# Unit test for constructor of class MovedModule
def test_MovedModule():
    lst = MovedModule('test', 'a', 'b')
    assert lst.name == 'test'
    assert lst.new == 'b'
    assert lst.old == 'a'



# Generated at 2022-06-21 17:57:26.671594
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moved_module = MovedModule('six', 'old', 'new')
    assert six_moved_module.name == 'six'
    assert six_moved_module.new == 'new'


# Generated at 2022-06-21 17:57:31.819743
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'


# Generated at 2022-06-21 17:57:37.769789
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("x", "y", "z")
    assert move.new_attr == "x"
    assert move.name == "x"
    assert move.new_mod == "z"

    move = MovedAttribute("a", "b", "c", "d", "e")
    assert move.new_attr == "e"
    assert move.name == "a"
    assert move.new_mod == "c"

# Generated at 2022-06-21 17:57:42.344991
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("module", "oldmodule", "newmodule")
    assert moved_module.name == "module"
    assert moved_module.old == "oldmodule"
    assert moved_module.new == "newmodule"


# Generated at 2022-06-21 17:57:46.948612
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'name'
    old = 'old'
    new = 'new'
    moved_module = MovedModule(name, old, new)
    assert moved_module.name == name
    assert moved_module.new == new
    assert moved_module.old == old

# Generated at 2022-06-21 17:57:59.076091
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    # Case 1: default constructor
    # Case 2: constructor with only name
    # Case 3: constructor with name and old_mod
    # Case 4: constructor with name, old_mod and new_mod
    # Case 5: constructor with name, old_mod, new_mod and old_attr
    # Case 6: constructor with all variables
    test_cases = [MovedAttribute(),
                  MovedAttribute('abc'),
                  MovedAttribute('abc', 'old_mod'),
                  MovedAttribute('abc', 'old_mod', 'new_mod'),
                  MovedAttribute('abc', 'old_mod', 'new_mod', 'old_attr'),
                  MovedAttribute('abc', 'old_mod', 'new_mod', 'old_attr', 'new_attr')]

    # Case 1: default constructor
    # Case 2: constructor with only name


# Generated at 2022-06-21 17:58:03.308573
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    _assert_valid_rewrites(t)

# Generated at 2022-06-21 17:58:11.908209
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = [MovedModule('test_module', 'old', 'new'),
             MovedModule('test_module', 'old')]
    assert moves[0].name == 'test_module'
    assert moves[0].old == 'old'
    assert moves[0].new == 'new'
    assert moves[1].name == 'test_module'
    assert moves[1].old == 'old'
    assert moves[1].new == 'test_module'



# Generated at 2022-06-21 17:58:14.918514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name")
    assert moved_module.name == "name"
    assert moved_module.new == "name"
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"



# Generated at 2022-06-21 17:58:19.884735
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("foo", "bar", "baz")
    assert attr.name == "foo"
    assert attr.new_mod == "bar"
    assert attr.new_attr == "foo"



# Generated at 2022-06-21 17:58:22.257039
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old", "name")  # type: ignore



# Generated at 2022-06-21 17:58:28.934462
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer._get_rewrites()) == \
           (len(_moved_attributes) +
            len(_urllib_error_moved_attributes) +
            len(_urllib_parse_moved_attributes) +
            len(_urllib_request_moved_attributes) +
            len(_urllib_response_moved_attributes) +
            len(_urllib_robotparser_moved_attributes))

# Generated at 2022-06-21 17:58:34.887170
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert SixMovesTransformer.target == (2, 7)
    assert isinstance(SixMovesTransformer.rewrites, types.GeneratorType)
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-21 17:58:38.591887
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    actual = MovedAttribute('test', 'a', 'b')
    assert actual.name == 'test'
    assert actual.new_mod == 'b'
    assert actual.new_attr == 'test'


# Generated at 2022-06-21 17:58:41.445043
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import base
    from . import utils
    from . import sixmovestransformer

    assert base.ImportRewrite is not None
    assert utils.helpers is not None
    assert sixmovestransformer.SixMovesTransformer is not None

# Generated at 2022-06-21 17:58:44.463272
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    assert moved_module.old == "__builtin__"

# Generated at 2022-06-21 17:58:48.828107
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Type check
    t = SixMovesTransformer()  # type: SixMovesTransformer



# Generated at 2022-06-21 17:59:01.033633
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'

    m = MovedAttribute('name', 'old_mod', None, 'old_attr', None)
    assert m.name == 'name'
    assert m.new_mod == 'name'
    assert m.new_attr == 'name'

    m = MovedAttribute('name', 'old_mod', 'new_mod', None, None)
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'name'

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 17:59:03.023678
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 428
    SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-21 17:59:05.171093
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("cStringIO", "cstringio")
    assert "cStringIO" == mod.name
    assert "cstringio" == mod.new
    mod = MovedModule("cStringIO", "cstringio", "newName")
    assert "cStringIO" == mod.name
    assert "newName" == mod.new

# Generated at 2022-06-21 17:59:17.328098
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # simple cases
    assert MovedAttribute('name', 'mod', 'newmod').new_mod == 'newmod'
    assert MovedAttribute('name', 'mod', 'newmod').new_attr == 'name'
    assert MovedAttribute('name', 'mod', 'newmod', 'attr').new_attr == 'attr'
    assert MovedAttribute('name', 'mod', 'newmod', 'attr', 'newattr').new_attr == 'newattr'
    assert MovedAttribute('name', 'mod', None, 'attr', 'newattr').new_mod == 'name'
    # case where new_attr should default to old_attr
    assert MovedAttribute('name', 'mod', 'newmod', 'attr').new_attr == 'attr'
    assert MovedAttribute('name', 'mod', 'newmod', 'attr', None).new_

# Generated at 2022-06-21 17:59:30.280865
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-21 17:59:32.473575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "tkinter_dialog"
    old = "Dialog"
    new = "tkinter.dialog"

    mm = MovedModule(name, old, new)
    assert mm.name == name
    assert mm.old == old
    assert mm.new == new



# Generated at 2022-06-21 17:59:44.176765
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    for key, value in _get_rewrites():
        # Check that the moved modules are correct
        # We expected a module in the `six.moves` package or a specific
        # module in the `six` package
        try:
            assert (key == 'six.StringIO' and value == 'six.moves.StringIO')
            assert getattr(six, value.split('.')[-1]) is not None
        except AttributeError:
            assert hasattr(six.moves, value.split('.')[-1]), (
                'AttributeError: module \'six.moves\' has no attribute \'{0}\''.format(value.split('.')[-1]))

# Generated at 2022-06-21 17:59:50.093539
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('modname', 'old', 'new').__dict__ == {'name': 'modname', 'new': 'new', 'old': 'old'}
    assert MovedModule('modname', 'old').__dict__ == {'name': 'modname', 'new': 'modname', 'old': 'old'}

# Generated at 2022-06-21 17:59:59.113263
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with mock.patch('__builtin__.open') as m:
        m.side_effect = lambda *args: StringIO('')
        m.return_value.__enter__ = lambda s: s
        m.return_value.__exit__ = lambda s, *a: s.close()
        assert SixMovesTransformer('/path/to/py') is not None

# Generated at 2022-06-21 18:00:09.724854
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"


# Generated at 2022-06-21 18:00:20.797052
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils.helpers import eager
    from .base import BaseImportRewrite

    # Special class for handling six moves:
    class MovedAttribute:
        def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
            self.name = name
            if new_mod is None:
                new_mod = name
            self.new_mod = new_mod
            if new_attr is None:
                if old_attr is None:
                    new_attr = name
                else:
                    new_attr = old_attr
            self.new_attr = new_attr


    class MovedModule:
        def __init__(self, name, old, new=None):
            self.name = name
            if new is None:
                new = name
            self.new

# Generated at 2022-06-21 18:00:21.993697
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert repr(SixMovesTransformer) == '2.7'

# Generated at 2022-06-21 18:00:24.110600
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for move in _get_rewrites():
        assert move in SixMovesTransformer.rewrites


# Generated at 2022-06-21 18:00:27.700450
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-21 18:00:39.941247
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:42.950698
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Test moved attribute (we get name and new values)"""
    move_attribute = MovedAttribute('move', 'oldmod', 'newmod')
    assert move_attribute.name == 'move'

# Generated at 2022-06-21 18:00:44.509289
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for move in _moved_attributes:
        assert(isinstance(move, MovedAttribute))


# Generated at 2022-06-21 18:00:47.805055
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-21 18:00:54.532236
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'

    attr = MovedAttribute("cStringIO", "cStringIO")
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'cStringIO'
    assert attr.new_attr == 'cStringIO'


# Generated at 2022-06-21 18:01:17.697306
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:01:22.183361
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t
    assert t.target == (2, 7)
    assert len(t.rewrites) == 289
    assert t.dependencies == ['six']

# Generated at 2022-06-21 18:01:25.978657
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name='os', old='OLD', new='NEW')
    assert moved_module.name == 'os'
    assert moved_module.old == 'OLD'
    assert moved_module.new == 'NEW'


# Generated at 2022-06-21 18:01:29.252983
# Unit test for constructor of class MovedModule
def test_MovedModule():
    o = MovedModule('name', 'old')
    assert o.name == 'name'
    assert o.old == 'old'
    assert o.new == 'name'


# Generated at 2022-06-21 18:01:30.346202
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-21 18:01:35.540162
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('name', 'old', 'new')
    assert move.name == 'name'
    assert move.old == 'old'
    assert move.new == 'new'
    move = MovedModule('name', 'old')
    assert move.name == 'name'
    assert move.old == 'old'
    assert move.new == 'name'


# Generated at 2022-06-21 18:01:41.747175
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("test", "test_old", None).name == "test"
    assert MovedModule("test", "test_old", None).old == "test_old"
    assert MovedModule("test", "test_old", None).new == "test"

    assert MovedModule("test", "test_old", "test_new").name == "test"
    assert MovedModule("test", "test_old", "test_new").old == "test_old"
    assert MovedModule("test", "test_old", "test_new").new == "test_new"


# Generated at 2022-06-21 18:01:45.833453
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
  t = SixMovesTransformer()
  assert t.target == (2, 7)
  assert t.dependencies == ['six']

# Generated at 2022-06-21 18:01:50.362008
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('name', 'src')
    assert move.name == 'name'
    assert move.new == 'name'

    move = MovedModule('name', 'src', 'dest')
    assert move.name == 'name'
    assert move.new == 'dest'



# Generated at 2022-06-21 18:01:52.560971
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    s = MovedAttribute("s", "old_mod", "new_mod", "old_attr", "new_attr")
    assert s.name == "s"
    assert s.new_mod == "new_mod"
    assert s.new_attr == "new_attr"

# Generated at 2022-06-21 18:02:17.895803
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.tkinter_filedialog' == SixMovesTransformer.rewrites['tkinter.filedialog']

# Generated at 2022-06-21 18:02:21.303616
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("abc", "abc", "abc")
    assert ma.name == 'abc'
    assert ma.new_mod == 'abc'
    assert ma.new_attr == 'abc'

# Generated at 2022-06-21 18:02:30.530567
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import six
    _six_moves = sys.modules['six.moves'] = MockSixMovesModule()
    s = SixMovesTransformer()
    s.transform_atom('urllib.parse', 'parse')
    assert _six_moves.parses == ['parse']
    _six_moves.reset()

    s.transform_atom('urllib.error', 'error')
    assert _six_moves.errors == ['error']
    _six_moves.reset()

    s.transform_atom('urllib.request', 'request')
    assert _six_moves.requests == ['request']
    _six_moves.reset()

    s.transform_atom('urllib.response', 'response')
    assert _six_moves.responses == ['response']

# Generated at 2022-06-21 18:02:33.818416
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        test = MovedModule(__name__, __name__)
        assert test.name == __name__
        assert test.new == __name__
    except:
        assert False

# Generated at 2022-06-21 18:02:41.186217
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name" and moved_module.old == "old" and moved_module.new == "name"
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name" and moved_module.old == "old" and moved_module.new == "new"


# Generated at 2022-06-21 18:02:45.523564
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert instance.target == (2, 7)
    assert instance.dependencies == ['six']

    assert len(instance.rewrites) == 53
    assert instance.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert instance.rewrites[1] == ('builtins.ifilter', 'six.moves.filter')
    assert instance.rewrites[2] == ('itertools.ifilterfalse', 'six.moves.filterfalse')
    assert instance.rewrites[3] == ('builtins.raw_input', 'six.moves.input')
    assert instance.rewrites[4] == ('sys.intern', 'six.moves.intern')

# Generated at 2022-06-21 18:02:57.776409
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__") == MovedModule("builtins", "__builtin__")
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__", "__builtin__") == \
           MovedModule("builtins", "__builtin__")
    assert MovedModule("builtins", "__builtin__", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__", "__builtin__").new == "builtins"

# Generated at 2022-06-21 18:02:59.036456
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer('2.7')
    assert transformer.rewrites != []

# Generated at 2022-06-21 18:03:02.272228
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    if sys.version_info >= (2, 7):
        return
    else:
        assert isinstance(SixMovesTransformer.rewrites, list)

# Generated at 2022-06-21 18:03:08.080226
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute("foo", "bar", "baz")
    move2 = MovedAttribute("foo", "bar", "baz", "old", "new")
    assert move1.name == "foo"
    assert move1.new_mod == "baz"
    assert move1.new_attr == "foo"
    assert move2.new_attr == "new"

# Generated at 2022-06-21 18:04:05.284559
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Verify attribute/module name, old/new module and old/new name
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.old_mod == "cStringIO"
    assert a.new_mod == "io"
    assert a.old_attr == "StringIO"
    assert a.new_attr == "StringIO"

    # Verify new module and new name if old module and old name are not
    # provided
    a = MovedAttribute("input", "__builtin__", "builtins")
    assert a.name == "input"
    assert a.old_mod == "__builtin__"
    assert a.new_mod == "builtins"
    assert a.old_attr == "input"

# Generated at 2022-06-21 18:04:09.091218
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("test", "old", "new")
    assert move.name == "test"
    assert move.old == "old"
    assert move.new == "new"

# Generated at 2022-06-21 18:04:17.948155
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'aa', 'bb').name == 'a'
    assert MovedAttribute('a', 'aa', 'bb').new_mod == 'bb'
    assert MovedAttribute('a', 'aa', 'bb').new_attr == 'a'
    assert MovedAttribute('a', 'aa', 'bb', 'cc').new_attr == 'cc'
    assert MovedAttribute('a', 'aa', 'bb', 'cc', 'dd').new_attr == 'dd'
    assert MovedAttribute('a', 'aa').new_mod == 'a'


# Generated at 2022-06-21 18:04:21.663400
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").new == "new"

# Generated at 2022-06-21 18:04:29.684991
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:04:38.752103
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    expected = MovedAttribute('foo', 'foo', 'foo')
    assert expected.name == 'foo'
    assert expected.new_mod == 'foo'
    assert expected.new_attr == 'foo'
    expected = MovedAttribute('foo', 'foo', 'bar', 'baz')
    assert expected.name == 'foo'
    assert expected.new_mod == 'foo'
    assert expected.new_attr == 'baz'
    expected = MovedAttribute('foo', 'bar', 'baz', 'foo', 'qux')
    assert expected.name == 'foo'
    assert expected.new_mod == 'bar'
    assert expected.new_attr == 'qux'


# Generated at 2022-06-21 18:04:47.688587
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import unittest

    class TestMovedModule(unittest.TestCase):
        def test_MovedModule(self):
            mm = MovedModule("name", "old")
            self.assertEqual(mm.name, "name")
            self.assertEqual(mm.new, "name")

            mm = MovedModule("name", "old", "new")
            self.assertEqual(mm.name, "name")
            self.assertEqual(mm.new, "new")

    unittest.main()

# Generated at 2022-06-21 18:04:51.985495
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"
    mm = MovedModule("name2", "old2", "new2")
    assert mm.name == "name2"
    assert mm.new == "new2"

# Generated at 2022-06-21 18:04:52.979516
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer(): assert SixMovesTransformer # See if it is defined.

# Generated at 2022-06-21 18:04:56.934783
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('foo', 'bar')
    assert moved.name == 'foo'
    assert moved.old == 'bar'
    assert moved.new == 'foo'

    moved = MovedModule('foo', 'bar', 'baz')
    assert moved.name == 'foo'
    assert moved.old == 'bar'
    assert moved.new == 'baz'



# Generated at 2022-06-21 18:06:46.889570
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("tkinter", "Tkinter", "tkinter") == MovedModule("tkinter", "Tkinter", "tkinter")
    assert MovedModule("tkinter", "Tkinter") == MovedModule("tkinter", "Tkinter")


# Generated at 2022-06-21 18:06:55.799281
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..transforms import SixMovesTransformer as cls
    from ..utils.helpers import eager
    import textwrap
    im = textwrap.dedent("""
        import time
        from time import time
        from time import time as t
        from time import time as t, sleep
        from time import (time, sleep)
        from time import (sleep, time)
        """)
    im2 = textwrap.dedent("""
        import time
        from six.moves import time
        from six.moves import time as t
        from six.moves import time as t, sleep
        from six.moves import (time, sleep)
        from six.moves import (sleep, time)
        """)
    assert str(cls(im)) == im2

# Generated at 2022-06-21 18:07:05.846501
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of SixMovesTransformer"""