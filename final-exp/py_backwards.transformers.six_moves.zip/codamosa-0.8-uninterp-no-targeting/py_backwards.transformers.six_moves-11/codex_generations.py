

# Generated at 2022-06-21 17:57:12.517515
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"


# Generated at 2022-06-21 17:57:17.606775
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old", "new")
    assert move.name == 'name'
    assert move.new_mod == 'new'
    assert move.new_attr == 'name'
    assert move.__str__() == "name->new.name"
    assert repr(move) == "MovedAttribute(name, old, new)"


# Generated at 2022-06-21 17:57:28.686967
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    im = MovedAttribute('foo', 'bar', 'baz')
    assert im.name == 'foo'
    assert im.new_mod == 'baz'
    assert im.new_attr == 'foo'
    im = MovedAttribute('foo', 'bar', 'baz', 'spam')
    assert im.name == 'foo'
    assert im.new_mod == 'baz'
    assert im.new_attr == 'spam'
    im = MovedAttribute('foo', 'bar', 'baz', new_attr='spam')
    assert im.name == 'foo'
    assert im.new_mod == 'baz'
    assert im.new_attr == 'spam'

# Generated at 2022-06-21 17:57:31.109834
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for constructor of class SixMovesTransformer."""
    t = SixMovesTransformer()
    assert isinstance(t, SixMovesTransformer)

# Generated at 2022-06-21 17:57:41.308390
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "newstringio")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "newstringio"

    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute

# Generated at 2022-06-21 17:57:42.482518
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Make sure constructor works
    SixMovesTransformer()

# Generated at 2022-06-21 17:57:52.558389
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites is not _get_rewrites()


if __name__ == '__main__':
    # simple test code
    t = SixMovesTransformer('six.moves.urllib_parse', {})
    assert t.is_from_six()
    assert t.get_from_name() == 'six.moves.urllib_parse'
    assert t.get_from_names() == [from_name(x) for x in t.get_names()]

    t = SixMovesTransformer('six.moves.urllib_error', {})
    assert t.is_from_six()
    assert t.get_from_name() == 'six.moves.urllib_error'

# Generated at 2022-06-21 17:58:02.867828
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:15.550225
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # type: () -> None
    attribute = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert attribute.name == 'cStringIO'
    assert attribute.new_mod == 'io'
    assert attribute.new_attr == 'StringIO'

    attribute_2 = MovedAttribute('something', 'something', 'something')
    assert attribute_2.name == attribute_2.new_attr == 'something'
    assert attribute_2.new_mod == 'something'

    attribute_3 = MovedAttribute('something', 'something', 'something', 'something_else', 'something_new')
    assert attribute_3.name == attribute_3.new_attr == 'something_new'
    assert attribute_3.new_mod == 'something'

# Generated at 2022-06-21 17:58:20.874998
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "cStringIO"


# Generated at 2022-06-21 17:58:31.352329
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:38.947145
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # this test is here because we don't yet have a tests
    # directory, and thus a better place to put it
    assert MovedModule(name='a1', old='b1').__dict__ == {'name': 'a1', 'old': 'b1', 'new': 'a1'}
    assert MovedModule(name='a2', old='b2', new='c2').__dict__ == {'name': 'a2', 'old': 'b2', 'new': 'c2'}


# Generated at 2022-06-21 17:58:41.249703
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule('foo')
    assert m1.name == 'foo'
    m2 = MovedModule('bar', 'old', 'new')
    assert m2.name == 'bar'

# Generated at 2022-06-21 17:58:42.954445
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.old == "old"
    assert mod.new == "new"



# Generated at 2022-06-21 17:58:46.238366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", None, "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", old_attr=None, new_attr="StringIO")

# Generated at 2022-06-21 17:58:47.808166
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "old", "new")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "new"



# Generated at 2022-06-21 17:58:59.691755
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:11.679394
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the constructor of SixMovesTransformer.

    This is a bad test as it relies on the source code of six.
    """
    from .utils import template_lines

    from .lint import LintRule
    from . import fixer_base
    from . import patcomp
    from . import fixer_util

    trans = SixMovesTransformer()
    source = template_lines('six.moves.urllib.parse.quote_plus',
                            'from six import moves')
    expected_source = template_lines('from six.moves import urllib.parse',
                                     'urllib.parse.quote_plus',
                                     'from six import moves')
    with trans.file_context(source) as test_context:
        trans.transform(test_context)
        assert test_context.source_lines

# Generated at 2022-06-21 17:59:17.239020
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test constructor of SixMovesTransformer.
    """
    six_moves_transformer = SixMovesTransformer(target_version=(2.7,))
    assert six_moves_transformer.target == (2, 7)
    assert six_moves_transformer.dependencies == ['six']

# Unit tests for SixMovesTransformer.transform

# Generated at 2022-06-21 17:59:24.629222
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "cStringIO"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.new_attr == "cStringIO"


# Generated at 2022-06-21 17:59:32.764831
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('tkinter', 'Tkinter') == MovedModule('tkinter', 'Tkinter')
    assert MovedModule('tkinter', 'Tkinter') != MovedModule('xxx', 'Tkinter')
    assert MovedModule('tkinter', 'Tkinter') != MovedModule('tkinter', 'XXX')


# Generated at 2022-06-21 17:59:34.818169
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer(): pass

# Generated at 2022-06-21 17:59:40.692871
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedMod = MovedModule("abc", "abc")
    assert movedMod.name == "abc"
    assert movedMod.new == "abc"
    movedMod = MovedModule("abc", "abc", "def")
    assert movedMod.name == "abc"
    assert movedMod.new == "def"


# Generated at 2022-06-21 17:59:43.965257
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute('test', 'test_old', 'test_new')
    assert attribute.name == 'test'
    assert attribute.new_mod == 'test_new'
    assert attribute.new_attr == 'test'

# Generated at 2022-06-21 17:59:48.104558
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    result = list(SixMovesTransformer._get_rewrites())
    for (old, new) in result:
        assert old in new, "Failed on {} -> {}".format(old, new)

# Generated at 2022-06-21 17:59:58.120438
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:05.678328
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("name", "old_mod", "new_mod",
                          "old_attr", "new_attr")
    assert test.name == "name"
    assert test.old_mod == "old_mod"
    assert test.new_mod == "new_mod"
    assert test.old_attr == "old_attr"
    assert test.new_attr == "new_attr"



# Generated at 2022-06-21 18:00:09.277196
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    # Cannot test anything because assertions in BaseImportRewrite do not pass.
    # Yet for now assume it works.


# Generated at 2022-06-21 18:00:10.140520
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = list(_get_rewrites())
    assert SixMovesTransformer.rewrites == rewrites

# Generated at 2022-06-21 18:00:21.108957
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO",
                       new_attr="some")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO",
                       new_attr="some", old_attr="some")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO",
                       new_attr=None)
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO",
                       new_attr=None, old_attr="some")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO",
                       new_attr=None, old_attr=None)

# Generated at 2022-06-21 18:00:30.730632
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('foo', 'bar')
    assert mod.name == 'foo'
    assert mod.old == 'bar'
    assert mod.new == 'foo'
    mod = MovedModule('foo', 'bar', 'bar')
    assert mod.name == 'foo'
    assert mod.old == 'bar'
    assert mod.new == 'bar'
    mod = MovedModule('foo', 'bar', 'baz')
    assert mod.name == 'foo'
    assert mod.old == 'bar'
    assert mod.new == 'baz'

# Generated at 2022-06-21 18:00:35.142362
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.dependencies == ['six']
    assert isinstance(SixMovesTransformer.rewrites, dict)
    assert len(SixMovesTransformer.rewrites) > 6

# Generated at 2022-06-21 18:00:41.852851
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('a', 'b', 'c')
    assert ma.name == 'a'
    assert ma.new_mod == 'c'
    assert ma.new_attr == 'a'
    ma = MovedAttribute('a', 'b', 'c', 'd', 'e')
    assert ma.name == 'a'
    assert ma.new_mod == 'c'
    assert ma.new_attr == 'e'

# Generated at 2022-06-21 18:00:44.390126
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("a", "b", "c")
    assert move.name == "a"
    assert move.new_mod == "c"
    assert move.new_attr == "a"

# Generated at 2022-06-21 18:00:46.868831
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer
    assert transformer.rewrites is not _get_rewrites()
    assert _get_rewrites()
    assert transformer.rewrites
    assert 'six' in transformer.dependencies

# Generated at 2022-06-21 18:00:49.134687
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new = MovedModule('conf', 'ConfigParser', 'configparser')
    assert new.name == 'conf'
    assert new.old == 'ConfigParser'
    assert new.new == 'configparser'


# Generated at 2022-06-21 18:00:53.898944
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test.name == 'cStringIO'
    assert test.new_mod == 'io'
    assert test.new_attr == 'StringIO'
    test = MovedAttribute("cStringIO", "cStringIO", "io")
    assert test.new_attr == 'cStringIO'


# Generated at 2022-06-21 18:00:55.275248
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    transformer.visit_ImportFrom(None)
    transformer.visit_Import(None)
    print(transformer.rewrites)

# Generated at 2022-06-21 18:00:56.105322
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    cls = SixMovesTransformer
    assert len(cls.rewrites) >= 42

# Generated at 2022-06-21 18:01:00.246950
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'name'

    m = MovedModule('new_name', 'old_name', 'new_name')
    assert m.name == 'new_name'
    assert m.old == 'old_name'
    assert m.new == 'new_name'


# Generated at 2022-06-21 18:01:17.214088
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', None, 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', None, None, 'new_attr').new_attr == 'new_attr'


# Generated at 2022-06-21 18:01:29.504940
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(Exception):
        MovedAttribute("cStringIO", "cStringIO")
    with pytest.raises(Exception):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", None)
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-21 18:01:41.025180
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of class SixMovesTransformer."""
    xformer = SixMovesTransformer()
    assert(xformer.target == (2, 7))

# Generated at 2022-06-21 18:01:53.989801
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import TransformerTester
    expected_output = '''
import openerp
import six.moves.urllib.parse
import six.moves.urllib.error
import six.moves.urllib.request
import six.moves.urllib.response
import six.moves.urllib.robotparser
import six.moves.urllib.parse

# Use new modules
six.moves.urllib.parse.ParseResult
six.moves.urllib.error.URLError
six.moves.urllib.request.Request
six.moves.urllib.response.addbase
six.moves.urllib.robotparser.RobotFileParser
'''

# Generated at 2022-06-21 18:01:56.615743
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.new == "new"
    assert mm.old == "old"

# Generated at 2022-06-21 18:02:09.583466
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'mod', None, 'old_attr', 'new_attr').new_mod == 'name'
    assert MovedAttribute('name', 'mod', None, 'old_attr', 'new_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'mod', None, None, 'new_attr').new_attr == 'name'

# Unit

# Generated at 2022-06-21 18:02:20.949421
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    def _test_parameters(name, old_mod, new_mod, old_attr, new_attr):
        if old_mod is None:
            old_mod = name
        if new_mod is None:
            new_mod = name
        if new_attr is None:
            if old_attr is None:
                new_attr = name
            else:
                new_attr = old_attr

        return name, old_mod, new_mod, old_attr, new_attr

    # Test that class remembers parameters correctly
    name, old_mod, new_mod, old_attr, new_attr = \
        _test_parameters('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')

# Generated at 2022-06-21 18:02:25.344678
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"


# Generated at 2022-06-21 18:02:27.708213
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert len(t.rewrites) == 118
    assert t.dependencies == ['six']

# Generated at 2022-06-21 18:02:30.405254
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("os", "sys")
    assert module.name == "os"
    assert module.new == "os"

    module = MovedModule("re", "regex")
    assert module.name == "re"
    assert module.new == "regex"

# Generated at 2022-06-21 18:02:47.018975
# Unit test for constructor of class MovedModule
def test_MovedModule():

    assert(MovedModule('u', 'urlparse', 'urllib.parse').name == 'u')
    assert(MovedModule('u', 'urlparse', 'urllib.parse').old == 'urlparse')
    assert(MovedModule('u', 'urlparse', 'urllib.parse').new == 'urllib.parse')


# Generated at 2022-06-21 18:02:54.818841
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves.urllib.parse
    from contextlib import suppress
    from .base import BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    assert SixMovesTransformer.dependencies == ['six']
    assert hasattr(six, 'moves')
    assert hasattr(six.moves, 'urllib')
    assert hasattr(six.moves.urllib, 'parse')
    assert hasattr(six.moves.urllib, 'error')
    assert hasattr(six.moves.urllib, 'request')
    assert hasattr(six.moves.urllib, 'response')
    assert hasattr(six.moves.urllib, 'robotparser')

# Generated at 2022-06-21 18:03:04.447115
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test if the class SixMovesTransformer is equivalent to the expected output.

    We create an instance of the class SixMovesTransformer, and then use the helper function
    `get_rewrites_list` to get the `rewrites` attribute as a list of tuples and compare it to the expected
    output.

    """
    actual = SixMovesTransformer()
    assert set(actual.rewrites) == set(_get_rewrites()), "Actual output: {}".format(actual.rewrites)
    assert actual.target == (2, 7), "Actual output: {}".format(actual.target)
    assert actual.dependencies == ['six'], "Actual output: {}".format(actual.dependencies)

# Generated at 2022-06-21 18:03:12.279000
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").name == "copyreg"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").name == "dbm_gnu"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").new == "dbm.gnu"

# Generated at 2022-06-21 18:03:24.302115
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "name"

    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "old_attr"

    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"


# Generated at 2022-06-21 18:03:26.323154
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert rewrites == SixMovesTransformer.rewrites

# Generated at 2022-06-21 18:03:37.978184
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for key in _moved_attributes:
        assert isinstance(key, MovedAttribute)
    for key in _urllib_parse_moved_attributes:
        assert isinstance(key, MovedAttribute)
    for key in _urllib_error_moved_attributes:
        assert isinstance(key, MovedAttribute)
    for key in _urllib_request_moved_attributes:
        assert isinstance(key, MovedAttribute)
    for key in _urllib_response_moved_attributes:
        assert isinstance(key, MovedAttribute)
    for key in _urllib_robotparser_moved_attributes:
        assert isinstance(key, MovedAttribute)

# Generated at 2022-06-21 18:03:39.600485
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name","old","new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"


# Generated at 2022-06-21 18:03:42.297418
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule('cpickle', 'cPickle')
    assert movedModule.name == 'cpickle'
    assert movedModule.new == 'cPickle'



# Generated at 2022-06-21 18:03:43.790127
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 157

# Generated at 2022-06-21 18:04:10.670878
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:04:13.293345
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("http_client", "httplib", "http.client")


# Generated at 2022-06-21 18:04:23.949139
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
        move = MovedAttribute('test', 'old', 'new')
        assert move.name == 'test'
        assert move.new_mod == 'new'
        assert move.new_attr == 'test'

        move = MovedAttribute('test', 'old', 'new', 'old_attr')
        assert move.name == 'test'
        assert move.new_mod == 'new'
        assert move.new_attr == 'old_attr'

        move = MovedAttribute('test', 'old', 'new', new_attr='new_attr')
        assert move.name == 'test'
        assert move.new_mod == 'new'
        assert move.new_attr == 'new_attr'
        
        move = MovedAttribute('test', 'old', 'new', 'old_attr', 'new_attr')

# Generated at 2022-06-21 18:04:25.882979
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule('abc', 'original')
    except:
        assert False
    assert str(MovedModule('abc', 'original')) == "MovedModule(name='abc', " \
                                                   "old='original', " \
                                                   "new='abc')"

# Generated at 2022-06-21 18:04:27.490200
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    from_value = 'from six.moves import input, urllib.request'
    result = instance.transform_module(from_value)
    assert 'from six.moves import input, urllib' == result

# Generated at 2022-06-21 18:04:32.667400
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-21 18:04:35.136643
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute('attr', 'old', 'new', 'old_attr', 'new_attr', 'foo')

# Generated at 2022-06-21 18:04:38.450610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"

# Generated at 2022-06-21 18:04:41.453000
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert repr(SixMovesTransformer) == 'SixMovesTransformer()'


# Generated at 2022-06-21 18:04:49.003127
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test the MovedModule constructor."""
    assert MovedModule('abc', old='abc', new='abc').new == 'abc'
    assert MovedModule('abc', 'old', 'new').new == 'new'
    assert MovedModule('abc', 'old').new == 'abc'
    assert MovedModule('abc', None, 'new').new == 'new'
    assert MovedModule('abc', None, None).new == 'abc'
    assert MovedModule('abc', None).new == 'abc'


# Generated at 2022-06-21 18:05:47.986367
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.new == move.name


# Generated at 2022-06-21 18:05:53.137462
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')

    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-21 18:06:05.290874
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old", "new", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old", "new", "old_attr", "new_attr").old_attr == "old_attr"
    assert MovedAttribute("name", "old", "new", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old", "new", "old_attr", "new_attr").new_mod == "new"
    assert MovedAttribute("name", "old", "new").old_attr == "name"
    assert MovedAttribute("name", "old", "new").new_attr == "name"
    assert MovedAttribute("name", "old", "new").new_mod == "new"
    assert M

# Generated at 2022-06-21 18:06:15.892491
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:06:26.289000
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:06:38.728470
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils import _get_module_lines
    _SixMovesTransformer = SixMovesTransformer()
    lines = _get_module_lines(_SixMovesTransformer)
    assert lines[lines.index('rewrites = _get_rewrites()') - 2] == '@eager', lines[lines.index('rewrites = _get_rewrites()') - 2]
    assert lines[lines.index('rewrites = _get_rewrites()') - 1] == 'def _get_rewrites():', lines[lines.index('rewrites = _get_rewrites()') - 1]
    assert '    ' + lines[lines.index('rewrites = _get_rewrites()')] == '    for prefix, moves in prefixed_moves:', lines[lines.index('rewrites = _get_rewrites()')]
   

# Generated at 2022-06-21 18:06:48.279715
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_1 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute_1.name == "cStringIO"
    assert moved_attribute_1.new_mod == "io"
    assert moved_attribute_1.new_attr == "cStringIO"

    moved_attribute_2 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert moved_attribute_2.name == "filter"
    assert moved_attribute_2.new_mod == "builtins"
    assert moved_attribute_2.new_attr == "filter"


# Generated at 2022-06-21 18:06:56.759480
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("name", "old_mod", "new_mod")
    assert m.name == "name"
    assert m.new_mod == "new_mod"
    assert m.new_attr == "name"

    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert m.new_attr == "old_attr"

    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert m.new_attr == "new_attr"

    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-21 18:07:06.385889
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'
    assert MovedAttribute('a', 'b').name == 'a'
    assert MovedAttribute('a', 'b').new_mod == 'a'
    assert MovedAttribute('a', 'b').new_attr == 'a'
    assert MovedAttribute('a', 'a').name == 'a'
    assert MovedAttribute('a', 'a').new_mod == 'a'
    assert MovedAttribute('a', 'a').new_attr == 'a'