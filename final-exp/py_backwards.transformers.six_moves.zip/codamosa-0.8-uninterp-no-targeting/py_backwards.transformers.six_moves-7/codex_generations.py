

# Generated at 2022-06-21 17:57:05.778240
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    b = SixMovesTransformer('', '', '', '')
    assert b

# Generated at 2022-06-21 17:57:07.276874
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 17:57:14.332105
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 17:57:15.818880
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule("builtins", "__builtin__"), MovedModule)

# Generated at 2022-06-21 17:57:28.641813
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import pycodestyle
    import unittest
    from .utils import check_constructor_test_results
    from .utils import check_class_constructor_test_results

    #######################################################################
    # class SixMovesTransformer(BaseImportRewrite)

    class TestSixMovesTransformer(unittest.TestCase):
        def test_SixMovesTransformer(self):
            # Test case:
            # SixMovesTransformer
            check_class_constructor_test_results(
                self,
                SixMovesTransformer,
                [],
                {'dependencies': {'six'}, 'target': (2, 7)},
                {})

# Generated at 2022-06-21 17:57:31.111396
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseImportRewrite)


# Generated at 2022-06-21 17:57:42.389482
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"

    obj = MovedAttribute("filter", "itertools", "builtins")
    assert obj.name == "filter"
    assert obj.new_mod == "builtins"
    assert obj.new_attr == "filter"

    obj = MovedAttribute("filter", "itertools", "builtins", "filter")
    assert obj.name == "filter"
    assert obj.new_mod == "builtins"
    assert obj.new_attr == "filter"

    # No value for new_attr

# Generated at 2022-06-21 17:57:51.202081
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_attr.name == "cStringIO"
    assert test_attr.new_mod == "io"
    assert test_attr.new_attr == "StringIO"
    # Test default values for new_attr
    test_attr2 = MovedAttribute("UserString", "UserString", "collections")
    assert test_attr2.new_attr == "UserString"
    test_attr3 = MovedAttribute("zip", "itertools", "builtins", "izip", "zip")
    assert test_attr3.new_attr == "zip"


# Generated at 2022-06-21 17:57:55.402343
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert c.name == "cStringIO"
    assert c.new_mod == "io"
    assert c.new_attr == "StringIO"

# Generated at 2022-06-21 17:58:00.283085
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("a", "b")
    assert a.name == 'a'
    assert a.new == 'a'
    assert a.old == 'b'
    b = MovedModule("b", "a", "c")
    assert b.name == 'b'
    assert b.new == 'c'
    assert b.old == 'a'

# Generated at 2022-06-21 17:58:14.763215
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == {
        'name': 'cStringIO',
        'new_attr': 'StringIO',
        'new_mod': 'io'
    }
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "Stuff").__dict__ == {
        'name': 'cStringIO',
        'new_attr': 'Stuff',
        'new_mod': 'io'
    }

    assert MovedAttribute("cStringIO", "cStringIO", None, "StringIO").__dict__ == {
        'name': 'cStringIO',
        'new_attr': 'cStringIO',
        'new_mod': 'cStringIO'
    }


# Generated at 2022-06-21 17:58:22.631050
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:26.761993
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(_name_="shutil", _old_="shutil", _new_="shutil")
    assert moved_module.name == "shutil"
    assert moved_module.new == "shutil"

# Generated at 2022-06-21 17:58:31.612788
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert (s.target == (2, 7))
    assert_equal(len(s.rewrites), len(_moved_attributes))
    assert (s.dependencies == ['six'])

# Generated at 2022-06-21 17:58:35.968583
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.__dict__ == {"name": "cStringIO",
                           "new_mod": "io",
                           "new_attr": "StringIO"}



# Generated at 2022-06-21 17:58:39.833744
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module = MovedModule('name', 'old')
    assert move_module.name == 'name'
    assert move_module.old == 'old'
    assert move_module.new == 'name'


# Generated at 2022-06-21 17:58:46.922582
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "cStringIO"



# Generated at 2022-06-21 17:58:58.421136
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import sys
    import six
    import doctrans.utils
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedModule):
                if move.new.startswith('.'):
                    new_mod = move.new[1:]
                else:
                    new_mod = move.new
                try:
                    module = __import__(new_mod, globals(), locals(), [], 0)
                except (AttributeError, ImportError):
                    continue
                new_module = sys.modules[new_mod]
                assert new_module.__name__ == new_mod
                if not doctrans.utils.is_py3k():
                    original = getattr(six.moves.__name__, move.name)
                    assert new_module is original

# Generated at 2022-06-21 17:59:02.249880
# Unit test for constructor of class MovedModule
def test_MovedModule():

    moved_module = MovedModule("configparser", "ConfigParser")

    assert moved_module.name == "configparser"
    assert moved_module.old == "ConfigParser"
    assert moved_module.new == "configparser"


# Generated at 2022-06-21 17:59:08.005484
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'configparser'
    old = 'ConfigParser'
    new = 'configparser'

    assert MovedModule(name, old, new).name == 'configparser'
    assert MovedModule(name, old, new).old == 'ConfigParser'
    assert MovedModule(name, old, new).new == 'configparser'



# Generated at 2022-06-21 17:59:12.370157
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-21 17:59:16.743629
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("from", "to", "from2")
    assert moved_attribute.name == "from"
    assert moved_attribute.new_mod == "from2"
    assert moved_attribute.new_attr == "from"


# Generated at 2022-06-21 17:59:20.063160
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('winreg', '_winreg')
    assert m.name == 'winreg'
    assert m.new == 'winreg'


# Generated at 2022-06-21 17:59:30.761777
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "cStringIO"
    
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.new_attr == "StringIO"
    
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="str")
    assert moved_attribute.new_attr == "str"
    

# Generated at 2022-06-21 17:59:35.039200
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'Foo').name == 'foo'
    assert MovedModule('foo', 'Foo').new == 'foo'
    assert MovedModule('foo', 'Foo', 'bar').new == 'bar'


# Generated at 2022-06-21 17:59:45.744965
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moves = [MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"),
             MovedAttribute("cStringIO", "cStringIO", "io"),
             MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO"),
             MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO"),
             MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="StringIO"),
             MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")]
    for move in moves:
        assert move.name == "cStringIO"
        assert move.new_mod == "io"
        assert move.new_attr == "StringIO"

# Generated at 2022-06-21 17:59:57.079483
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO").new_attr == "cStringIO"
    assert M

# Generated at 2022-06-21 18:00:08.552171
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:20.114287
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 18:00:23.072789
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new_module = MovedModule("new_module", "old_module")
    assert new_module.name == "new_module"
    assert new_module.new == "new_module"


# Generated at 2022-06-21 18:00:41.070875
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert a.name == "name"
    assert a.new_mod == "new_mod"
    assert a.new_attr == "new_attr"

    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert a.name == "name"
    assert a.new_mod == "new_mod"
    assert a.new_attr == "old_attr"

    a = MovedAttribute("name", "old_mod", "new_mod")
    assert a.name == "name"
    assert a.new_mod == "new_mod"
    assert a.new_attr == "name"


# Generated at 2022-06-21 18:00:43.256122
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("itool", "spam", "eggs")
    assert m.name == "itool"
    assert m.new == "eggs"



# Generated at 2022-06-21 18:00:45.119413
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("module_name", "old_name", "new_name")
    assert MovedModule("module_name", "old_name")

# Generated at 2022-06-21 18:00:48.445761
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    It is very important that the rewrites are eagerly evaluated
    and not just a lazy generator expression. Without that,
    the rules for "moves" can't be added before __version__ is
    fixed.
    """
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:00:56.974407
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "StringIO"

    attribute = MovedAttribute("map", "itertools", "builtins", "imap", "map")
    assert attribute.name == "map"
    assert attribute.new_mod == "builtins"
    assert attribute.new_attr == "map"

    attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attribute.name == "cStringIO"
    assert attribute.new_mod == "io"
    assert attribute.new_attr == "cStringIO"



# Generated at 2022-06-21 18:01:01.030140
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import inspect
    assert inspect.isclass(MovedAttribute)
    assert MovedAttribute.__init__.__code__.co_argcount == 1
    assert MovedAttribute.__init__.__code__.co_varnames == ('self', 'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')

# Generated at 2022-06-21 18:01:13.269684
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.parse import ParseError
    from .test_transformer import create_source
    import unittest
    import textwrap
    import sys

    class TestReplaceMoves(unittest.TestCase):
        maxDiff = None
        transform = SixMovesTransformer()
        transform.wrap_errors = True
        cache = {}

        def assert_transform(self, before, after):
            tree = create_source(before, self.transform, self.cache)
            self.assertEqual(textwrap.dedent(after), tree)

        def test_import(self):
            before = """
            import optparse

            print optparse.OptionParser is not None
            """

# Generated at 2022-06-21 18:01:19.410714
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule(1)
    with pytest.raises(TypeError):
        MovedModule('name')
    with pytest.raises(TypeError):
        MovedModule('name', 'old')
    working_example = MovedModule('name', 'old', 'new')
    assert working_example.name == 'name'
    assert working_example.old == 'old'
    assert working_example.new == 'new'


# Generated at 2022-06-21 18:01:30.858846
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "cStringIO"
    assert MovedAttribute("reduce", "__builtin__", "functools").name == "reduce"
    assert MovedAttribute("reduce", "__builtin__", "functools").new_mod == "functools"
    assert MovedAttribute("reduce", "__builtin__", "functools").new_attr == "reduce"


# Generated at 2022-06-21 18:01:32.657008
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(AssertionError):
        MovedModule('name', 'old')



# Generated at 2022-06-21 18:01:41.869908
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("random", "random")
    assert module.name == "random"
    assert module.new == "random"

    module = MovedModule("random", "random", "builtins")
    assert module.name == "random"
    assert module.new == "builtins"


# Generated at 2022-06-21 18:01:48.489636
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_moved_attribute.name == "cStringIO"
    assert test_moved_attribute.new_mod == "io"
    assert test_moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-21 18:01:51.274876
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__").name == "builtins"

# Generated at 2022-06-21 18:02:03.395155
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # type: () -> None
    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert c.name == "cStringIO"
    assert c.new_mod == "io"
    assert c.new_attr == "StringIO"
    c = MovedAttribute("cStringIO", "cStringIO", "io")
    assert c.name == "cStringIO"
    assert c.new_mod == "io"
    assert c.new_attr == "cStringIO"
    c = MovedAttribute("cStringIO", "cStringIO", "io", None, "StringIO")
    assert c.name == "cStringIO"
    assert c.new_mod == "io"
    assert c.new_attr == "StringIO"

# Generated at 2022-06-21 18:02:15.631990
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer([], {})

# Generated at 2022-06-21 18:02:19.664639
# Unit test for constructor of class MovedModule
def test_MovedModule():
    prefix = 'package'
    name = 'module'
    old = 'original'
    new = 'new'
    move = MovedModule(name, old, new)
    assert move.name == name
    assert move.new == '{}.{}'.format(prefix, new)

# Generated at 2022-06-21 18:02:24.122412
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Just test that SixMovesTransformer contructs properly
    SixMovesTransformer()


if __name__ == '__main__':
    # Unit test
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 18:02:26.713550
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("module", "old", "new")
    assert module.name == "module"
    assert module.new == "new"



# Generated at 2022-06-21 18:02:30.923263
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule1 = MovedModule('module1', 'module1_old', 'module2')
    assert MovedModule1.name == 'module1'
    assert MovedModule1.new == 'module2'
    MovedModule2 = MovedModule('module3', 'module3_old')
    assert MovedModule2.name == 'module3'
    assert MovedModule2.new == 'module3'


# Generated at 2022-06-21 18:02:32.500996
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:02:50.914959
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("test", "old", "new", "old_attr", "new_attr")
    assert x.name == "test"
    assert x.new_mod == "new"
    assert x.new_attr == "new_attr"

# Generated at 2022-06-21 18:03:00.292891
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import sys
    import six
    import os

    assert six.moves.cStringIO is sys.modules["six.moves.cStringIO"]
    assert six.moves.filter is sys.modules["six.moves.filter"]
    assert six.moves.filterfalse is sys.modules["six.moves.filterfalse"]
    assert six.moves.input is sys.modules["six.moves.input"]
    assert six.moves.intern is sys.modules["six.moves.intern"]
    assert six.moves.map is sys.modules["six.moves.map"]
    assert six.moves.getcwd is os.getcwdu
    assert six.moves.getcwdb is os.getcwd

# Generated at 2022-06-21 18:03:08.849047
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    expected = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    returned = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert expected.name == returned.name
    assert expected.old_mod == returned.old_mod
    assert expected.new_mod == returned.new_mod
    assert expected.old_attr == returned.old_attr
    assert expected.new_attr == returned.new_attr


# Generated at 2022-06-21 18:03:14.202943
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old')
    assert moved_module.name == 'name'
    assert moved_module.new == 'name'
    assert moved_module.new == moved_module.name
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.new == 'new'
    assert moved_module.new != moved_module.name


# Generated at 2022-06-21 18:03:26.334221
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

    moved_module = MovedModule("name_test", "old_test", None)
    assert moved_module.name == "name_test"
    assert moved_module.old == "old_test"
    assert moved_module.new == "name_test"

    moved_module = MovedModule("name_test1", "old_test1", "None")
    assert moved_module.name == "name_test1"
    assert moved_module.old == "old_test1"
    assert moved_module.new == "None"


# Generated at 2022-06-21 18:03:27.214842
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b") == MovedModule("a", "b")


# Generated at 2022-06-21 18:03:30.794808
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    m = SixMovesTransformer(None)
    assert len(m.rewrites) == len(_get_rewrites())
    for rewrite in m.rewrites:
        assert rewrite in _get_rewrites()

# Generated at 2022-06-21 18:03:43.509261
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    result = SixMovesTransformer._get_rewrites()

    assert ('six.moves.urllib.parse.urlencode', 'six.moves.urllib.urlencode') in result
    assert ('six.moves.urllib.parse.unquote', 'six.moves.urllib.unquote') in result
    assert ('six.moves.urllib.parse.unquote_plus', 'six.moves.urllib.unquote_plus') in result
    assert ('six.moves.urllib.parse.urlopen', 'six.moves.urllib.urlopen') in result
    assert ('six.moves.urllib.parse.urljoin', 'six.moves.urllib.urljoin') in result

# Generated at 2022-06-21 18:03:50.463014
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr', new_attr='new_attr').new_attr == 'old_attr'
    
# Test for

# Generated at 2022-06-21 18:03:52.545778
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(list(SixMovesTransformer((2, 7))
                    .rewrites)) == len(_get_rewrites())

# Generated at 2022-06-21 18:04:08.478563
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MM = MovedModule("name", "old")
    assert MM.name == "name"
    assert MM.old == "old"
    assert MM.new == "name"



# Generated at 2022-06-21 18:04:09.607322
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:04:19.842056
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("x", "a.b", "c.d")
    assert ma.name == "x"
    assert ma.new_mod == "c.d"
    assert ma.new_attr == "x"
    ma = MovedAttribute("x", "a.b", "c.d", "y")
    assert ma.new_attr == "y"
    ma = MovedAttribute("x", "a.b", "c.d", "y", "z")
    assert ma.new_attr == "z"
    ma = MovedAttribute("x", "a.b", "c.d", new_attr="z")
    assert ma.new_attr == "z"

# Generated at 2022-06-21 18:04:28.351357
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = SixMovesTransformer.rewrites
    assert rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert rewrites[1] == ('builtins.filter', 'six.moves.filter')
    assert rewrites[2] == ('itertools.filterfalse', 'six.moves.filterfalse')
    assert rewrites[3] == ('builtins.input', 'six.moves.input')
    assert rewrites[4] == ('sys.intern', 'six.moves.intern')
    assert rewrites[5] == ('builtins.map', 'six.moves.map')
    assert rewrites[6] == ('os.getcwd', 'six.moves.getcwd')

# Generated at 2022-06-21 18:04:33.685534
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module1 = MovedModule("configparser", "ConfigParser")
    moved_module2 = MovedModule("configparser", "ConfigParser", "configparser")
    moved_module3 = MovedModule("configparser", "ConfigParser", None)

    assert moved_module1.name == "configparser"
    assert moved_module1.old == "ConfigParser"
    assert moved_module1.new == "configparser"

    assert moved_module2.name == "configparser"
    assert moved_module2.old == "ConfigParser"
    assert moved_module2.new == "configparser"

    assert moved_module3.name == "configparser"
    assert moved_module3.old == "ConfigParser"
    assert moved_module3.new == "configparser"


# Generated at 2022-06-21 18:04:36.366822
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('Testing', 'Salam', 'alikom')
    assert mm.name == 'Testing'
    assert mm.new == 'alikom'

# Generated at 2022-06-21 18:04:48.963608
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # default __init__
    m = MovedAttribute('name', 'mod', 'new_mod')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'name'

    # 2-arg __init__
    m = MovedAttribute('name', 'mod')
    assert m.name == 'name'
    assert m.new_mod == 'name'
    assert m.new_attr == 'name'

    # 3-arg __init__
    m = MovedAttribute('name', 'mod', 'new_mod', 'attr')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'attr'

    # 4-arg __init__

# Generated at 2022-06-21 18:04:54.336062
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b").name == "a"
    assert MovedModule("a", "b").old == "b"
    assert MovedModule("a", "b").new == "a"

    assert MovedModule("a", "b", "c").name == "a"
    assert MovedModule("a", "b", "c").old == "b"
    assert MovedModule("a", "b", "c").new == "c"

# Generated at 2022-06-21 18:04:55.445814
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites()) == SixMovesTransformer.rewrites

# Generated at 2022-06-21 18:05:00.734741
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:05:32.969054
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute('foo', 'bar', 'baz', 'fob', 'foz')
    assert moved.name == 'foo'
    assert moved.new_mod == 'baz'
    assert moved.new_attr == 'foz'



# Generated at 2022-06-21 18:05:41.462839
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import test_base
    from . import test_sixmoves

    transformer = SixMovesTransformer()

    source = test_base.source_from_test_case(test_sixmoves.SixMovesTestCase())
    expected = test_base.source_from_test_case(test_sixmoves.SixMovesTestCaseFixed())

    result = transformer.transform_source(source)

    assert result == expected

    # test that priority is set
    # This transformer should be low priority:
    assert transformer.priority < 0

# Generated at 2022-06-21 18:05:48.665747
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod",
                          "old_attr", "new_attr") == \
        MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert MovedAttribute("name", "old_mod", None, None, None) == \
        MovedAttribute("name", "old_mod", "name")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") == \
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")


# Generated at 2022-06-21 18:05:51.005574
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:05:52.228359
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None)

# Generated at 2022-06-21 18:05:58.146445
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.old_mod is None
    assert a.new_mod == "io"
    assert a.old_attr == "StringIO"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-21 18:06:05.086879
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("test", "test.old")
    assert moved_module.name == "test"
    assert moved_module.new == "test"
    assert moved_module.old == "test.old"
    moved_module = MovedModule("test", "test.old", "test.new")
    assert moved_module.name == "test"
    assert moved_module.new == "test.new"
    assert moved_module.old == "test.old"

# Generated at 2022-06-21 18:06:15.762425
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('attr1', 'module1', 'module2')
    assert attr.name == 'attr1'
    assert attr.new_mod == 'module2'
    assert attr.new_attr == 'attr1'

    attr = MovedAttribute('attr2', 'module1', 'module2', 'attr3')
    assert attr.name == 'attr2'
    assert attr.new_mod == 'module2'
    assert attr.new_attr == 'attr3'

    attr = MovedAttribute('attr3', 'module1', 'module2', old_attr='attr4')
    assert attr.name == 'attr3'
    assert attr.new_mod == 'module2'
    assert attr.new_attr == 'attr4'


# Generated at 2022-06-21 18:06:18.257247
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_import_rewrite import import_rewrite_test_helper
    import_rewrite_test_helper(SixMovesTransformer)

# Generated at 2022-06-21 18:06:22.065135
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    sys.version_info = (2, 7)
    t = SixMovesTransformer()
    assert t.name == 'sixmoves'
    assert all(t.dependencies)
    assert t.rewrites == _get_rewrites()