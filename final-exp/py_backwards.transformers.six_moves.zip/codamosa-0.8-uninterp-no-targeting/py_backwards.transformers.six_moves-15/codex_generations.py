

# Generated at 2022-06-21 17:57:12.246235
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("func", "mod", "newmod", "old_func", "new_func")
    assert obj.name == "func"
    assert obj.new_mod == "newmod"
    assert obj.new_attr == "new_func"


# Generated at 2022-06-21 17:57:21.462755
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "filter"

    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse").new_attr \
        == 'ifilterfalse'

    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input").new_attr \
        == 'raw_input'




# Generated at 2022-06-21 17:57:32.212293
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name  == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod  == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr  == 'e'
    assert MovedAttribute('new', 'old', None).new_mod  == 'new'
    assert MovedAttribute('new', 'old', None).new_attr  == 'new'
    assert MovedAttribute('new', 'old', None, old_attr='old').new_attr  == 'old'


# Generated at 2022-06-21 17:57:42.242597
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert (m.name == "cStringIO")
    assert (m.old_mod == "cStringIO")
    assert (m.new_mod == "io")
    assert (m.old_attr == "StringIO")
    assert (m.new_attr == "StringIO")
    m = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert (m.name == "input")
    assert (m.old_mod == "__builtin__")
    assert (m.new_mod == "builtins")
    assert (m.old_attr == "raw_input")
    assert (m.new_attr == "input")

# Generated at 2022-06-21 17:57:47.175391
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'new_attr'

# Generated at 2022-06-21 17:57:55.616249
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Tests constructor of class MovedAttribute"""
    #pylint: disable=unused-variable,unused-argument,expression-not-assigned,singleton-comparison
    #
    # Test passing all arguments
    moved_attribute_ = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute_.name == "name"
    assert moved_attribute_.new_mod == "new_mod"
    assert moved_attribute_.new_attr == "new_attr"
    #
    # Test passing 3 arguments
    moved_attribute_ = MovedAttribute("name", "old_mod", "new_mod")
    assert moved_attribute_.name == "name"
    assert moved_attribute_.new_mod == "new_mod"
    assert moved_attribute_.new

# Generated at 2022-06-21 17:58:04.949284
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    constructor = MovedAttribute
    
    assert constructor("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert constructor("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    
    assert constructor("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert constructor("name", "old_mod", "new_mod", "old_attr", "new_attr").old_mod == "old_mod"
    assert constructor("name", "old_mod", "new_mod", "old_attr", "new_attr").old_attr == "old_attr"
    

# Generated at 2022-06-21 17:58:15.459828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("os", "os")
    assert moved_module.name == "os"
    assert moved_module.new == "os"

    moved_module = MovedModule("os", "six.moves.os", "os")
    assert moved_module.name == "os"
    assert moved_module.new == "os"

    moved_module = MovedModule("os", "six.moves.os", "os")
    assert moved_module.name == "os"
    assert moved_module.new == "os"


# Generated at 2022-06-21 17:58:24.356228
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) == 89
    assert len(_urllib_parse_moved_attributes) == 25
    assert len(_urllib_error_moved_attributes) == 3
    assert len(_urllib_request_moved_attributes) == 27
    assert len(_urllib_response_moved_attributes) == 4
    assert len(_urllib_robotparser_moved_attributes) == 1

    assert len(_get_rewrites()) == 148



# Generated at 2022-06-21 17:58:29.131985
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'name'

    b = MovedModule('name', 'old', 'new')
    assert b.name == 'name'
    assert b.old == 'old'
    assert b.new == 'new'

# Generated at 2022-06-21 17:58:40.982849
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'


# Generated at 2022-06-21 17:58:45.648320
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    assert SixMovesTransformer.target == (2, 7)
    assert hasattr(SixMovesTransformer, 'rewrites')
    assert hasattr(SixMovesTransformer, 'dependencies')
    assert SixMovesTransformer.dependencies == ['six']


if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-21 17:58:47.788512
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("foo", "bar")
    assert mm.name == "foo"
    assert mm.new == "foo"
    mm = MovedModule("foo", "bar", "baz")
    assert mm.name == "foo"
    assert mm.new == "baz"



# Generated at 2022-06-21 17:58:52.177036
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test', 'test_old').name == 'test'
    assert MovedModule('test', 'test_old').new == 'test'
    assert MovedModule('test', 'test_old', 'test_new').name == 'test'
    assert MovedModule('test', 'test_old', 'test_new').new == 'test_new'

# Generated at 2022-06-21 17:59:05.072100
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:09.727763
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    source_code = "import six.moves.filter"
    tree = ast.parse(source_code)
    rewrite = SixMovesTransformer()
    rewrite(tree)
    assert isinstance(rewrite, SixMovesTransformer)

# Generated at 2022-06-21 17:59:12.214075
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 53
    assert len(SixMovesTransformer.rewrites[:4]) == 4

# Generated at 2022-06-21 17:59:21.478864
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("build_opener", "urllib2", "urllib.request") == MovedModule("build_opener", "urllib2", "urllib.request")
    assert MovedModule("build_opener", "urllib2", "urllib.request") != MovedModule("build_opener", "urllib2", "urllib.response")
    assert MovedModule("build_opener", "urllib2", "urllib.request") != MovedModule("build_opener", "urllib2")
    assert MovedModule("build_opener", "urllib2") != MovedModule("build_opener", "urllib")
    assert MovedModule("build_opener", "urllib") != "foo"


# Generated at 2022-06-21 17:59:28.024154
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("builtins", "__builtin__")
    assert mod.name == "builtins"
    assert mod.new == "builtins"
    mod = MovedModule("configparser", "ConfigParser")
    assert mod.name == "configparser"
    assert mod.new == "configparser"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 17:59:37.510443
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('builtins', '__builtin__')
    MovedModule('configparser', 'ConfigParser')
    MovedModule('copyreg', 'copy_reg')
    MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    MovedModule('http_cookiejar', 'cookielib', 'http.cookiejar')
    MovedModule('http_cookies', 'Cookie', 'http.cookies')
    MovedModule('html_entities', 'htmlentitydefs', 'html.entities')
    MovedModule('html_parser', 'HTMLParser', 'html.parser')
    MovedModule('http_client', 'httplib', 'http.client')

# Generated at 2022-06-21 17:59:42.002797
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites


# Generated at 2022-06-21 17:59:44.054282
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer(), BaseImportRewrite)
    assert isinstance(SixMovesTransformer().rewrites, set)

# Generated at 2022-06-21 17:59:53.705310
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("winreg", "_winreg")
    assert m.name == "winreg"
    assert m.old == "_winreg"
    assert m.new == "winreg"

    m2 = MovedModule("blah", "foo", "bar")
    assert m2.name == "blah"
    assert m2.old == "foo"
    assert m2.new == "bar"

    m3 = MovedModule("blah", "foo")
    assert m3.name == "blah"
    assert m3.old == "foo"
    assert m3.new == "blah"

# Generated at 2022-06-21 17:59:55.886924
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('name', 'old')
    assert mod.name == 'name'
    assert mod.new == 'name'



# Generated at 2022-06-21 18:00:07.830086
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert isinstance(MovedAttribute('name', 'old_mod', 'new_mod'), MovedAttribute)
    assert isinstance(MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr'), MovedAttribute)
    assert isinstance(MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr'), MovedAttribute)
    assert isinstance(MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr'), MovedAttribute)
    assert isinstance(MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr'), MovedAttribute)

# Generated at 2022-06-21 18:00:15.463854
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    idx = 0
    for move in _moved_attributes:
        if move.old_attr is not None:
            idx += 1
            m = MovedAttribute(move.name, move.old_mod, move.new_mod,
                               move.old_attr, move.new_attr)
            assert m.name == move.name
            assert m.new_mod == move.new_mod
            assert m.new_attr == move.new_attr


# Generated at 2022-06-21 18:00:25.377043
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name","old_mod","new_mod")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "name"
    obj = MovedAttribute("name","old_mod","new_mod","old_attr","new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"
    obj = MovedAttribute("name","old_mod")
    assert obj.name == "name"
    assert obj.new_mod == "name"
    assert obj.new_attr == "name"
    obj = MovedAttribute("name","old_mod",new_attr="new_attr")
    assert obj.name == "name"
   

# Generated at 2022-06-21 18:00:28.451441
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('module', 'source')
    assert mm.name == 'module'
    assert mm.new == 'module'
    assert mm.old == 'source'



# Generated at 2022-06-21 18:00:31.365773
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # the source code is almost identical to the one in the BaseImportRewrite
    # class, except for one extra command.
    assert hasattr(SixMovesTransformer, '__init__')
    assert hasattr(SixMovesTransformer, '__call__')

# Generated at 2022-06-21 18:00:38.583761
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=no-name-in-module
    import lib2to3.refactor as refactor
    # pylint: enable=no-name-in-module
    changes = refactor.get_fixers_from_package(refactor.fixers)
    assert changes[-1].__class__.__name__ == 'SixMovesTransformer'

# Generated at 2022-06-21 18:00:49.567758
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('foo', 'bar', 'baz')
    assert a.name == 'foo'
    assert a.new_mod == 'baz'
    assert a.new_attr == 'foo'
    a = MovedAttribute('foo', 'bar', None)
    assert a.name == 'foo'
    assert a.new_mod == 'foo'
    assert a.new_attr == 'foo'
    a = MovedAttribute('foo', 'bar', 'baz', 'spam')
    assert a.name == 'foo'
    assert a.new_mod == 'baz'
    assert a.new_attr == 'spam'
    a = MovedAttribute('foo', 'bar', 'baz', 'spam', 'bacon')
    assert a.name == 'foo'
    assert a.new_

# Generated at 2022-06-21 18:00:57.681729
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:01:00.994678
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    i = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert i.name == "cStringIO"
    assert i.new_mod == "io"
    assert i.new_attr == "StringIO"


# Generated at 2022-06-21 18:01:05.127761
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"

    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"

# Generated at 2022-06-21 18:01:11.091514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"

    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"

# Generated at 2022-06-21 18:01:19.727912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    testMove = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert testMove.name == "cStringIO"
    assert testMove.new_mod == "io"
    assert testMove.new_attr == "StringIO"
    testMove = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert testMove.name == "filter"
    assert testMove.new_mod == "builtins"
    assert testMove.new_attr == "filter"
    testMove = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert testMove.name == "filterfalse"
    assert testMove.new_mod == "itertools"

# Generated at 2022-06-21 18:01:27.054913
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils.helpers import eager

    '''
        This test is intended to ensure that that
        SixMovesTransformer has correct number of rewrites.
        Note that if the number of rewrites should change,
        the test will still pass and the
        number of rewrites should simply be changed in the
        assertion.
    '''

    @eager
    def all_rewrites():
        old_modules = set()
        new_modules = set()
        for prefix, moves in prefixed_moves:
            for move in moves:
                if isinstance(move, MovedModule):
                    old_modules.add('six.moves{}.{}'.format(prefix, move.name))
                    new_modules.add(move.new)

# Generated at 2022-06-21 18:01:32.657301
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule("shutil", "shut", "moved")
    assert t.name == "shutil"
    assert t.old == "shut"
    assert t.new == "moved"
    t = MovedModule("shutil", "shut")
    assert t.name == "shutil"
    assert t.old == "shut"
    assert t.new == "shutil"

# Generated at 2022-06-21 18:01:39.260458
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert test_MovedAttribute.name == 'name'
    assert test_MovedAttribute.new_attr == 'new_attr'
    assert test_MovedAttribute.new_mod == 'new_mod'
    # test default value of arguments old_mod and new_mod are the same


# Generated at 2022-06-21 18:01:40.390155
# Unit test for constructor of class MovedModule
def test_MovedModule():
    print(MovedModule("tkinter", "Tkinter"))


# Generated at 2022-06-21 18:01:57.085752
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'StringIO'

    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'cStringIO'

    m = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert m.name == 'cStringIO'
    assert m.new_mod == 'cStringIO'
    assert m.new_attr == 'StringIO'

    m = MovedAttribute("cStringIO", "cStringIO", None)

# Generated at 2022-06-21 18:02:03.442872
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('tkinter', 'Tkinter')
    assert moved_module.name == 'tkinter'
    assert moved_module.old == 'Tkinter'
    assert moved_module.new == 'tkinter'
    assert repr(moved_module) == 'MovedModule(tkinter, Tkinter)'

# Generated at 2022-06-21 18:02:09.531828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'name'

    b = MovedModule('name', 'old', 'new')
    assert b.name == 'name'
    assert b.old == 'old'
    assert b.new == 'new'


# Generated at 2022-06-21 18:02:13.256855
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule()
    except TypeError as e:
        assert str(e) == "__init__() missing 3 required positional arguments: 'name', 'old', and 'new'"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:02:24.121730
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute('abc', 'cur', 'new')
    assert x.name == 'abc'
    assert x.new_mod == 'new'
    assert x.new_attr == 'abc'
    x = MovedAttribute('abc', 'cur', 'new', new_attr='new_attr')
    assert x.name == 'abc'
    assert x.new_mod == 'new'
    assert x.new_attr == 'new_attr'
    x = MovedAttribute('abc', 'cur', 'new', 'old_attr', 'new_attr')
    assert x.name == 'abc'
    assert x.new_mod == 'new'
    assert x.new_attr == 'new_attr'


# Generated at 2022-06-21 18:02:27.719552
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule = MovedModule('module', 'old', 'new')
    assert MovedModule.name == 'module'
    assert MovedModule.new == 'new'
    MovedModule = MovedModule('module', 'old')
    assert MovedModule.new == 'old'

# Generated at 2022-06-21 18:02:34.376817
# Unit test for constructor of class MovedModule
def test_MovedModule():
    o = MovedModule("x", "y")
    assert o.name == "x"
    assert o.old == "y"
    assert o.new == "x"
    o = MovedModule("x", "y", "z")
    assert o.name == "x"
    assert o.old == "y"
    assert o.new == "z"

# Generated at 2022-06-21 18:02:39.036814
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert a.name == 'cStringIO'
    assert a.new_mod == 'io'
    assert a.new_attr == 'StringIO'

# Generated at 2022-06-21 18:02:48.396279
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'
    move2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert move2.name == 'name'
    assert move2.new_mod == 'new_mod'
    assert move2.new_attr == 'old_attr'
    move3 = MovedAttribute("name", "old_mod", "new_mod")
    assert move3.name == 'name'
    assert move3.new_mod == 'name'
    assert move3.new_attr == 'name'

# Generated at 2022-06-21 18:02:53.859481
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule("os", "os")
    assert moved.name == "os"
    assert moved.new == "os"
    moved = MovedModule("test", "test")
    assert moved.name == "test"
    assert moved.new == "test"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:03:12.069018
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_object = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert test_object.name == "name"
    assert test_object.old_mod == "old_mod"
    assert test_object.new_mod == "new_mod"
    assert test_object.old_attr == "old_attr"
    assert test_object.new_attr == "new_attr"


# Generated at 2022-06-21 18:03:15.744535
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case = MovedModule("test_case", "urllib", "six.moves.urllib")
    assert test_case.name == "test_case"
    assert test_case.new == "urllib"



# Generated at 2022-06-21 18:03:21.743939
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(AssertionError):
        MovedAttribute("cStringIO", "cStringIO", None)
        MovedAttribute("cStringIO", "cStringIO", None, old_attr="StringIO")
        MovedAttribute("cStringIO", "cStringIO", None, old_attr="StringIO",
                       new_attr=None)

# Generated at 2022-06-21 18:03:27.378555
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("http_cookiejar", "cookielib", "http.cookiejar")
    assert test.name == 'http_cookiejar'
    assert test.new_mod == 'http.cookiejar'
    assert test.new_attr == 'http_cookiejar'

    test = MovedAttribute("http_cookiejar", "cookielib", "http.cookiejar", "CookieJar")
    assert test.name == 'http_cookiejar'
    assert test.new_mod == 'http.cookiejar'
    assert test.new_attr == 'CookieJar'

    test = MovedAttribute("http_cookiejar", "cookielib", "http.cookiejar", "CookieJar", "CookieJar2")
    assert test.name == 'http_cookiejar'

# Generated at 2022-06-21 18:03:31.931361
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-21 18:03:36.850162
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-21 18:03:41.862221
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attribute.name == 'name'
    assert attribute.new_mod == 'new_mod'
    assert attribute.new_attr == 'new_attr'

# Unit tests for rewrites

# Generated at 2022-06-21 18:03:49.727168
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'StringIO'

    m2 = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert m2.name == 'filter'
    assert m2.new_mod == 'builtins'
    assert m2.new_attr == 'filter'

    m3 = MovedAttribute('range', '__builtin__', 'builtins', 'xrange', 'range')
    assert m3.name == 'range'
    assert m3.new_mod == 'builtins'
    assert m3.new_attr == 'range'

    m4 = Moved

# Generated at 2022-06-21 18:04:01.079826
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.old_mod == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.old_attr == 'StringIO'
    assert move.new_attr == 'StringIO'

    move = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert move.name == 'input'
    assert move.old_mod == '__builtin__'
    assert move.new_mod == 'builtins'
    assert move.old_attr == 'raw_input'
    assert move.new_attr == 'input'


# Generated at 2022-06-21 18:04:08.639318
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:04:39.147783
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module1 = MovedModule('test_builtins', '__builtin__')
    assert module1.name == 'test_builtins'
    assert module1.new == 'test_builtins'

    module2 = MovedModule('test_builtins', '__builtin__', 'builtins')
    assert module2.name == 'test_builtins'
    assert module2.new == 'builtins'



# Generated at 2022-06-21 18:04:42.603349
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import test_constructor_exists_and_callable
    test_constructor_exists_and_callable(SixMovesTransformer)

# Generated at 2022-06-21 18:04:48.716973
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io", old_attr="StringIO", new_attr="StringIO")
    assert obj.name == "cStringIO"
    assert obj.old_mod == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.old_attr == "StringIO"
    assert obj.new_attr == "StringIO"

# Generated at 2022-06-21 18:04:51.371684
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
	x = MovedAttribute("a","b","c","d","e")
	assert x.name == "a", "Failed to create MovedAttribute"


# Generated at 2022-06-21 18:04:53.435241
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("foo", "foo", "bar")
    assert module.name == "foo"
    assert module.old == "foo"
    assert module.new == "bar"



# Generated at 2022-06-21 18:04:58.479853
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import_name = "cStringIO"
    old_module = "cStringIO"
    new_module = "io"
    old_attr = "StringIO"
    new_attr = "StringIO"
    result_moved_attribute = MovedAttribute(import_name, old_module, new_module, old_attr, new_attr)
    assert result_moved_attribute.name == import_name
    assert result_moved_attribute.new_mod == new_module
    assert result_moved_attribute.new_attr == new_attr


# Generated at 2022-06-21 18:05:03.832445
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "name"
    assert moved_attribute.__str__() == \
        "MovedAttribute(name='name', old_mod='old_mod', new_mod='new_mod', old_attr=None, new_attr='name')"

    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"

# Generated at 2022-06-21 18:05:09.907479
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("tkinter", "Tkinter", "tkinter")
    assert m.name == "tkinter"
    assert m.old == "Tkinter"
    assert m.new == "tkinter"

    n = MovedModule("tkinter", "Tkinter")
    assert n.name == "tkinter"
    assert n.old == "Tkinter"
    assert n.new == "tkinter"



# Generated at 2022-06-21 18:05:12.522624
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites()) == SixMovesTransformer.rewrites
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-21 18:05:24.514952
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(name='cStringIO',
                          old_mod='cStringIO',
                          new_mod='io',
                          old_attr='StringIO',
                          new_attr=None)
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'
    #
    move = MovedAttribute(name='getoutput',
                          old_mod='commands',
                          new_mod='subprocess',
                          old_attr=None,
                          new_attr=None)
    assert move.name == 'getoutput'
    assert move.new_mod == 'subprocess'
    assert move.new_attr == 'getoutput'
    #

# Generated at 2022-06-21 18:06:21.747968
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-21 18:06:22.615806
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        _ = MovedAttribute('foo')  # missing argument: old_mod

# Generated at 2022-06-21 18:06:30.183442
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").old

# Generated at 2022-06-21 18:06:31.758277
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites() == SixMovesTransformer.rewrites

# Generated at 2022-06-21 18:06:39.764574
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('Name', 'Old', 'New').name == 'Name'
    assert MovedModule('Name', 'Old').name == 'Name'
    assert MovedModule('Name', 'Old').old == 'Old'
    assert MovedModule('Name', 'Old').new == 'Name'
    assert MovedModule('Name', 'Old', 'New').old == 'Old'
    assert MovedModule('Name', 'Old', 'New').new == 'New'



# Generated at 2022-06-21 18:06:42.363800
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Constructor of MovedModule"""
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.new == "new"

# Generated at 2022-06-21 18:06:45.719065
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) == 61

# Generated at 2022-06-21 18:06:47.704239
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('name', 'old')
    MovedModule('name', 'old', 'new')

# Generated at 2022-06-21 18:06:49.081981
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests SixMovesTransformer constructor"""
    assert SixMovesTransformer()

# Generated at 2022-06-21 18:06:51.034064
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule('asdf')