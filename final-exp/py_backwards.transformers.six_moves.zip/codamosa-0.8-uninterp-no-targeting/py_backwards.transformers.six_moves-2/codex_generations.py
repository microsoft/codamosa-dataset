

# Generated at 2022-06-21 17:57:04.393446
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('a', 'b')
    assert m.name == 'a'
    assert m.new == 'b'

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 17:57:07.297301
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("builtins", "__builtin__")
    assert mm.name == 'builtins'
    assert mm.new == 'builtins'
    assert mm.old == '__builtin__'

# Generated at 2022-06-21 17:57:14.372587
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:57:26.672243
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').__dict__ == {'name': 'cStringIO', 'new_mod': 'io', 'new_attr': 'StringIO'}
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').__dict__ == {'name': 'filter', 'new_mod': 'builtins', 'new_attr': 'filter'}
    assert MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse').__dict__ == {'name': 'filterfalse', 'new_mod': 'itertools', 'new_attr': 'filterfalse'}
    assert MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input').__dict

# Generated at 2022-06-21 17:57:35.901528
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from six.moves.urllib.parse import SplitResult
    assert SplitResult

    # Move attribute from urllib to urllib.parse
    assert unquote_plus == quote_plus

    # Make sure that moves is not imported when not used
    try:
        # Module __future__ cannot be imported by this script
        import __future__
        assert False
    except ImportError:
        pass

    # Move module from urllib to urllib.request
    from six.moves.urllib import request
    assert request

    # Move module from urllib to urllib.response
    from six.moves.urllib import response
    assert response

    # Move module from urllib to urllib.parse
    from six.moves.urllib import parse
    assert parse

    # Move module from urll

# Generated at 2022-06-21 17:57:39.425857
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name_module', 'old_module')
    assert moved_module.name == 'name_module'
    assert moved_module.old == 'old_module'
    assert moved_module.new == 'name_module'


# Generated at 2022-06-21 17:57:47.560514
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("b","a","c")
    assert a.name == "b"
    assert a.new_mod == "c"
    assert a.new_attr == "b"
    a = MovedAttribute("b","a","c","d","e")
    assert a.name == "b"
    assert a.new_mod == "c"
    assert a.new_attr == "e"
    a = MovedAttribute("b","a","c","e")
    assert a.name == "b"
    assert a.new_mod == "c"
    assert a.new_attr == "e"


# Generated at 2022-06-21 17:57:49.978755
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('TestModule','moves')
    assert a.name == 'TestModule'
    assert a.new == 'moves'


# Generated at 2022-06-21 17:57:57.735851
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.old_mod == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.old_attr == "StringIO"
    assert attr.new_attr == "cStringIO"

    attr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert attr.name == "filter"
    assert attr.old_mod == "itertools"
    assert attr.new_mod == "builtins"
    assert attr.old_attr == 'ifilter'
    assert attr.new_attr == 'filter'


# Generated at 2022-06-21 17:58:01.249151
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-21 17:58:10.674287
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("tkinter", "Tkinter")
    assert move.name == "tkinter"
    assert move.old == "Tkinter"
    assert move.new == "tkinter"
    move = MovedModule("tkinter", "Tkinter", "something_else")
    assert move.name == "tkinter"
    assert move.old == "Tkinter"
    assert move.new == "something_else"

# Generated at 2022-06-21 17:58:16.311381
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'


# Generated at 2022-06-21 17:58:28.291220
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("asdf", "old_mod", "new_mod").name == "asdf"
    assert MovedAttribute("asdf", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("asdf", "old_mod", "new_mod").new_attr == "asdf"

    assert MovedAttribute("asdf", "old_mod", "new_mod",
                          "old_attr", "new_attr").new_attr == "new_attr"

    assert MovedAttribute("asdf", "old_mod", None).new_mod == "asdf"
    assert MovedAttribute("asdf", "old_mod", None).new_attr == "asdf"


# Generated at 2022-06-21 17:58:39.876350
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('foo', 'bar', 'baz', 'bam', 'bap')
    assert m.name == 'foo'
    assert m.new_mod == 'baz'
    assert m.new_attr == 'bap'

    m = MovedAttribute('foo', 'bar', 'baz', 'bam')
    assert m.name == 'foo'
    assert m.new_mod == 'baz'
    assert m.new_attr == 'bam'

    m = MovedAttribute('foo', 'bar', 'baz')
    assert m.name == 'foo'
    assert m.new_mod == 'baz'
    assert m.new_attr == 'foo'


# Generated at 2022-06-21 17:58:46.115704
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("parse_qs", "urlparse", "urllib.parse")
    assert move.name == "parse_qs"
    assert move.new_mod == "urllib.parse"
    assert move.new_attr == "parse_qs"



# Generated at 2022-06-21 17:58:46.937841
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')

# Generated at 2022-06-21 17:58:48.159477
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == set(_get_rewrites())

# Generated at 2022-06-21 17:58:50.058843
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.dependencies) == 1
    assert SixMovesTransformer(None, None).target == (2, 7)

# Generated at 2022-06-21 17:59:02.618910
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a = MovedAttribute("filter", "itertools", None, "ifilter", "filter")
    assert a.name == "filter"
    assert a.new_mod == "filter"
    assert a.new_attr == "ifilter"

    a = MovedAttribute("filter", "itertools", None, "ifilter")
    assert a.name == "filter"
    assert a.new_mod == "filter"
    assert a.new_attr == "ifilter"

    a = MovedAttribute("filter", "itertools", None)

# Generated at 2022-06-21 17:59:05.948527
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert (path, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer().rewrites
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer().rewrites

# Generated at 2022-06-21 17:59:10.663030
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites[0] in _get_rewrites()

# Generated at 2022-06-21 17:59:15.782684
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "oldname")
    assert m.name == "name"
    assert m.new == "name"
    assert m.old == "oldname"

    m = MovedModule("name", "oldname", "newname")
    assert m.name == "name"
    assert m.new == "newname"
    assert m.old == "oldname"



# Generated at 2022-06-21 17:59:21.676650
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import io
    import collections
    import subprocess
    import queue
    import tkinter
    import requests
    import urllib
    import urllib.robotparser
    import urllib.request
    import urllib.request
    six_moves = SixMovesTransformer()
    print(six_moves)


# Generated at 2022-06-21 17:59:33.635678
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test the constructor of MovedAttribute
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"
    # Test constructor without new_attr
    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"
    # Test constructor without old_attr and new_attr
    m = MovedAttribute("cStringIO", "cStringIO", "io", old_attr=None)
    assert m.name == "cStringIO"

# Generated at 2022-06-21 17:59:38.203699
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert len(t.rewrites) == len(_get_rewrites())
    # It is very unlikely that the number changes, but would be a bad sign if it did.
    assert len(t.rewrites) == 115

# Generated at 2022-06-21 17:59:45.048896
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert str(MovedModule('name', 'old', 'new')) == "MovedModule('name', 'old', 'new')"
    assert str(MovedModule('name', 'old')) == "MovedModule('name', 'old')"
    assert str(MovedModule('name', 'old', None)) == "MovedModule('name', 'old', None)"


# Generated at 2022-06-21 17:59:49.129105
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("foo", "bar", "baz")
    assert obj.name == "foo"
    assert obj.new_mod == "baz"
    assert obj.new_attr == "foo"

# Generated at 2022-06-21 17:59:58.634860
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    rewrites = transformer.rewrites

# Generated at 2022-06-21 18:00:00.983073
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(_moved_attributes) + len(_urllib_parse_moved_attributes)

if __name__ == "__main__":
    import sys
    SixMovesTransformer().rewrite_file(sys.argv[1])

# Generated at 2022-06-21 18:00:03.071612
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("a", "b", "c")
    assert moved_module.name == "a"  # target: line 123
    assert moved_module.old == "b"  # target: line 124
    assert moved_module.new == "c"  # target: line 125


# Generated at 2022-06-21 18:00:13.345338
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert 'six.moves' in instance.rewrites
    assert 'ConfigParser' in instance.rewrites
    assert instance.target == (2, 7)
    assert instance.dependencies == ['six']

# Generated at 2022-06-21 18:00:18.111057
# Unit test for constructor of class MovedModule

# Generated at 2022-06-21 18:00:28.290111
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('a', 'b', 'c')

    assert move.name == 'a'
    assert move.new_mod == 'c'
    assert move.new_attr == 'a'

    move = MovedAttribute('a', 'b', 'c', 'd')

    assert move.name == 'a'
    assert move.new_mod == 'c'
    assert move.new_attr == 'd'

    move = MovedAttribute('a', 'b', 'c', 'd', 'e')

    assert move.name == 'a'
    assert move.new_mod == 'c'
    assert move.new_attr == 'e'

    move = MovedAttribute('a', 'b', None, 'd', 'e')

    assert move.name == 'a'

# Generated at 2022-06-21 18:00:31.222697
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"
    

# Generated at 2022-06-21 18:00:37.031467
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mva = MovedAttribute('some_name', 'old_module', 'new_module')
    assert mva.name == 'some_name'
    assert mva.new_mod == 'new_module'
    assert mva.new_attr == 'some_name'


# Generated at 2022-06-21 18:00:38.314569
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:00:42.480818
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for moves in prefixed_moves:
        for move in moves[1]:
            if isinstance(move, MovedAttribute):
                for k, v in move.__dict__.items():
                    assert getattr(move, k) == v

# Generated at 2022-06-21 18:00:50.267838
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    ma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma.new_mod == "io"
    assert ma.new_attr == "cStringIO"
    ma = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIOnew")
    assert ma.new_attr == "StringIOnew"
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIOnew")
    assert ma.new_attr == "StringIOnew"


# Unit

# Generated at 2022-06-21 18:00:51.301745
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) > 0

# Generated at 2022-06-21 18:00:56.176414
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                if move.new_mod.startswith('__builtin__'):
                    module = "builtins"
                else:
                    module = move.new_mod
                path = '{}.{}'.format(module, move.new_attr)
                path_six = 'six.moves{}.{}'.format(prefix, move.name)
                assert SixMovesTransformer.rewrites[path] == path_six
            elif isinstance(move, MovedModule):
                module = move.new
                module_six = 'six.moves{}.{}'.format(prefix, move.name)
                assert SixMovesTransformer.rewrites[module] == module_six

# Generated at 2022-06-21 18:01:18.873520
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # six 1.14.0
    cStringIO_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert cStringIO_attr.name == "cStringIO"
    assert cStringIO_attr.new_mod == "io"
    assert cStringIO_attr.new_attr == "StringIO"

    # six 1.14.0
    filter_attr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert filter_attr.name == "filter"
    assert filter_attr.new_mod == "builtins"
    assert filter_attr.new_attr == "filter"

    # six 1.14.0

# Generated at 2022-06-21 18:01:22.655320
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("test", "test", "test2")
    assert module.name == "test"
    assert module.new == "test2"

# Generated at 2022-06-21 18:01:28.728794
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('test_name', 'test_old_mod', 'test_new_mod', 'test_old_attr', 'test_new_attr')
    assert moved_attribute.name == 'test_name'
    assert moved_attribute.new_mod == 'test_new_mod'
    assert moved_attribute.new_attr == 'test_new_attr'


# Generated at 2022-06-21 18:01:29.778876
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:01:30.813420
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:01:33.686400
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six.moves
    assert six.moves.cStringIO is six.moves.io.StringIO

# Generated at 2022-06-21 18:01:38.530447
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moved_module = MovedModule("urnllib", "_urllib")
    assert six_moved_module.name == "urnllib"
    assert six_moved_module.old == "_urllib"
    assert six_moved_module.new == "urnllib"


# Just checking that we got the number of moves we expect from six

# Generated at 2022-06-21 18:01:40.843597
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module = MovedModule("module_name", "old_location", "new_location")
    assert move_module.name == "module_name"
    assert move_module.new == "new_location"



# Generated at 2022-06-21 18:01:46.824140
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("urllib_parse", "urlparse", "urllib.parse")
    assert ma.name == "urllib_parse"
    assert ma.new_mod == "urllib.parse"
    assert ma.new_attr == "urllib_parse"

# Generated at 2022-06-21 18:01:58.412807
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m1 = MovedAttribute('m1', 'spam', 'eggs')
    assert m1.name == 'm1'
    assert m1.new_mod == 'eggs'
    assert m1.new_attr == 'm1'

    m2 = MovedAttribute('m2', 'spam', 'eggs', 'bacon')
    assert m2.name == 'm2'
    assert m2.new_mod == 'eggs'
    assert m2.new_attr == 'bacon'

    m3 = MovedAttribute('m3', 'spam', 'eggs', 'bacon', 'ham')
    assert m3.name == 'm3'
    assert m3.new_mod == 'eggs'
    assert m3.new_attr == 'ham'



# Generated at 2022-06-21 18:02:31.128562
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_attr == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").new_attr == "old_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", new_attr="new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", None).new_mod == "name"

# Generated at 2022-06-21 18:02:33.518132
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import test_BaseImportRewrite
    test_BaseImportRewrite(SixMovesTransformer, 'six.moves')

# Generated at 2022-06-21 18:02:45.742061
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.configparser' == SixMovesTransformer.rewrites['ConfigParser']
    assert 'six.moves.http_cookies' == SixMovesTransformer.rewrites['Cookie']
    assert 'six.moves.urllib.parse' == SixMovesTransformer.rewrites['urllib.parse']
    assert 'six.moves.urllib.error' == SixMovesTransformer.rewrites['urllib.error']
    assert 'six.moves.urllib.request' == SixMovesTransformer.rewrites['urllib.request']
    assert 'six.moves.urllib.response' == SixMovesTransformer.rewrites['urllib.response']

# Generated at 2022-06-21 18:02:47.370825
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('spam', 'bacon', 'eggs', 'sausage', 'beans').name == 'spam'

# Generated at 2022-06-21 18:02:55.604848
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("name", "old")
    assert x.name == "name"
    assert x.new == "name"
    assert x.old == "old"
    x = MovedModule("name", "old", "new")
    assert x.name == "name"
    assert x.new == "new"
    assert x.old == "old"
    z = [x for x in prefixed_moves if x[0] == '']
    assert z[0][1][1] == x



# Generated at 2022-06-21 18:03:02.097688
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer(): # type: () -> None
    t = SixMovesTransformer(None)
    assert t.rewrites[0] == ('__builtin__.filter', 'six.moves.filter')
    assert t.rewrites[-1] == ('urllib.robotparser.RobotFileParser',
                              'six.moves.urllib.robotparser.RobotFileParser')
    assert t.dependencies == ['six']

# Generated at 2022-06-21 18:03:03.377448
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    m = SixMovesTransformer()

# Generated at 2022-06-21 18:03:13.517079
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.type == 'six'
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 18:03:24.628980
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    moved_module = MovedModule("builtins", "__builtin__", "six.moves.builtins")
    assert moved_module.name == "builtins"
    assert moved_module.new == "six.moves.builtins"
    moved_module = MovedModule("builtins", "__builtin__", six_moves_builtins="six.moves.builtins")
    assert moved_module.name == "builtins"
    assert moved_module.new == "six.moves.builtins"

# Generated at 2022-06-21 18:03:30.316577
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"
    assert repr(m) == "MovedAttribute(name='cStringIO', new_mod='io', new_attr='StringIO')"

# Generated at 2022-06-21 18:04:23.133656
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"


# Generated at 2022-06-21 18:04:24.378930
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t is not None

# Generated at 2022-06-21 18:04:26.502018
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    import io, io.StringIO
    assert six.StringIO is io.StringIO
    assert six.moves.cStringIO is io.StringIO


# Generated at 2022-06-21 18:04:29.548398
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
        move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
        assert move.name == "cStringIO"

        assert move.new_mod == "io"

        assert move.new_attr == "StringIO"

#Unit test for constructor of class MovedModule

# Generated at 2022-06-21 18:04:39.482155
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Ensures that name, new_mod and new_attr are all set properly.
    new_attr defaults to new_mod.name if unspecified, or new_attr defaults to name if old_attr is
    unspecified."""
    move = MovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert move.name == "name" and move.new_mod == "new" and move.new_attr == "new_attr"
    move = MovedAttribute("name", "old", "new", "old_attr")
    assert move.name == "name" and move.new_mod == "new" and move.new_attr == "old_attr"
    move = MovedAttribute("name", "old", "new")
    assert move.name == "name" and move.new_mod == "new"

# Generated at 2022-06-21 18:04:47.030747
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """
    Test case for MovedModule 
    """
    obj = MovedModule("name", "old", "new")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "new"
    
    obj = MovedModule("name", "old")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "name"


# Generated at 2022-06-21 18:04:53.235027
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

# Generated at 2022-06-21 18:04:59.684794
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:05:03.936819
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr1 = MovedAttribute('name1', 'old_mod1', 'new_mod1', 'old_attr1', 'new_attr1')
    assert attr1.name == 'name1'
    assert attr1.new_mod == 'new_mod1'
    assert attr1.new_attr == 'new_attr1'
    attr2 = MovedAttribute('name2', 'old_mod2', 'new_mod2', 'old_attr2')
    assert attr2.name == 'name2'
    assert attr2.new_mod == 'new_mod2'
    assert attr2.new_attr == 'old_attr2'
    attr3 = MovedAttribute('name3', 'old_mod3', 'new_mod3')
    assert attr3.name == 'name3'

# Generated at 2022-06-21 18:05:09.201942
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"