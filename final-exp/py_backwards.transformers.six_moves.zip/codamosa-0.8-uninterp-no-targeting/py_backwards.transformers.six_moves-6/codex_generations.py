

# Generated at 2022-06-21 17:57:18.116492
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").name == "filterfalse"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").new_mod == "itertools"

# Generated at 2022-06-21 17:57:21.944341
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'
    mm = MovedModule("name", "old", "new")
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'


# Generated at 2022-06-21 17:57:34.422192
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:57:45.282543
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    b = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    c = MovedAttribute("name", "old_mod", "new_mod")
    d = MovedAttribute("name", "old_mod")
    e = MovedAttribute("name")

    assert a.name == 'name'
    assert a.old_mod == 'old_mod'
    assert a.new_mod == 'new_mod'
    assert a.old_attr == 'old_attr'
    assert a.new_attr == 'new_attr'

    assert b.name == 'name'
    assert b.old_mod == 'old_mod'

# Generated at 2022-06-21 17:57:54.053045
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:00.428362
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'

    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', None).name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', None).new_mod == 'new_mod'

# Generated at 2022-06-21 17:58:01.699292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 17:58:04.415309
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer
    assert len(s.rewrites) == 30
    assert s.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')

# Generated at 2022-06-21 17:58:11.970183
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # At least the constructor must do not break
    MovedModule("name", "old", "new")
    # And we need at least a trivial test
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").new == "new"

# Generated at 2022-06-21 17:58:20.638352
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert_equal(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name, "cStringIO")
    assert_equal(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod, "io")
    assert_equal(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr, "StringIO")
    assert_equal(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_mod, "builtins")
    assert_equal(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_attr, "input")

# Generated at 2022-06-21 17:58:24.855919
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("queue", "Queue")


# Generated at 2022-06-21 17:58:37.118522
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:39.655305
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("builtins", "__builtin__")
    assert a.name == "builtins"
    assert a.new == "builtins"
    assert a.old == "__builtin__"

# Generated at 2022-06-21 17:58:43.256738
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("BaseHandler", "urllib2", "urllib.request")
    assert moved_attribute.name == "BaseHandler"
    assert moved_attribute.new_mod == "urllib.request"
    assert moved_attribute.new_attr == "BaseHandler"

# Generated at 2022-06-21 17:58:44.881100
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for no exceptions in constructor
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-21 17:58:46.887663
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) == 46
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 17:58:51.842775
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = list(_get_rewrites())
    assert rewrites[0] == ('builtins.filter', 'six.moves.filter')
    assert rewrites[1] == ('builtins.range', 'six.moves.range')
    assert rewrites[-1] == ('urllib.robotparser.RobotFileParser', 'six.moves.urllib.robotparser.RobotFileParser')

# Generated at 2022-06-21 17:58:57.702534
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("test", "mod1", "mod2", "attr1", "attr2")
    assert ma.name == "test"
    assert ma.new_mod == "mod2"
    assert ma.new_attr == "attr2"


# Generated at 2022-06-21 17:59:02.410785
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-21 17:59:03.898527
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == dict(_get_rewrites())

# Generated at 2022-06-21 17:59:11.554657
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(SixMovesTransformer.rewrites)

# Generated at 2022-06-21 17:59:21.108939
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"


# Generated at 2022-06-21 17:59:30.031814
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import add_future_import

    code = '''
        from six.moves import cStringIO
        from six.moves import xrange
    '''

    t = SixMovesTransformer(add_future_import(code, '__future__'))
    nt.assert_equal(t.rewrites, {
        'six.moves.cStringIO': 'io.StringIO',
        'six.moves.xrange': 'range',
    })
    nt.assert_equal(t.dependencies, ['six'])

# Generated at 2022-06-21 17:59:38.598791
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'module', 'newmodule', 'bar').name == 'foo'
    assert MovedAttribute('foo', 'module', 'newmodule', 'bar').new_attr == 'bar'
    assert MovedAttribute('foo', 'module', 'newmodule', 'bar').new_mod == 'newmodule'
    assert MovedAttribute('foo', 'module', 'newmodule', old_attr='bar').new_attr == 'bar'
    assert MovedAttribute('foo', 'module', 'newmodule', old_attr='bar').new_mod == 'newmodule'
    assert MovedAttribute('foo', 'module', 'newmodule').name == 'foo'
    assert MovedAttribute('foo', 'module', 'newmodule', new_attr='bar').new_attr == 'bar'

# Generated at 2022-06-21 17:59:42.394961
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('test_1', 'test_2', 'test_3')
    assert module.name == 'test_1'
    assert module.old == 'test_2'
    assert module.new == 'test_3'



# Generated at 2022-06-21 17:59:55.720836
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=unsubscriptable-object,unsubscriptable-object
    # This is tricky: we have a class with a constructor that does work,
    # and we want to test the constructor.
    # This could be achieved with a simple subclass, but that doesn't work here,
    # because we are dealing with class attributes.
    # The dynamic attribute creation in the constructor has to be copied,
    # and this can be done by subclassing. But then we get a different
    # __dict__, so we copy the attribute in constructors, too.
    class TestSixMovesTransformer(SixMovesTransformer):
        # pylint: disable=too-few-public-methods
        def __init__(self):
            # pylint: disable=attribute-defined-outside-init
            super().__init__()
           

# Generated at 2022-06-21 18:00:02.418185
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"



# Generated at 2022-06-21 18:00:05.569857
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('f', 'old', 'new')
    assert ma.name == 'f'
    assert ma.new_mod == 'new'
    assert ma.new_attr == 'f'

# Generated at 2022-06-21 18:00:16.765094
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("x", "y", "z")
    assert attribute.name == "x"
    assert attribute.new_mod == "y"
    assert attribute.new_attr == "x"

    attribute = MovedAttribute("a", "b", "c", "d", "e")
    assert attribute.name == "a"
    assert attribute.new_mod == "b"
    assert attribute.new_attr == "d"

    attribute = MovedAttribute("a", "b", "c", "d")
    assert attribute.new_attr == "d"

    attribute = MovedAttribute("a", "b", "c", new_attr="e")
    assert attribute.new_attr == "e"

# Generated at 2022-06-21 18:00:19.895866
# Unit test for constructor of class MovedModule
def test_MovedModule():
    cmd=MovedModule("name", "old", "new")
    assert(cmd.name == "name")
    assert(cmd.old == "old")
    assert(cmd.new == "new")

# Generated at 2022-06-21 18:00:29.456911
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.new == "new"


# Generated at 2022-06-21 18:00:33.905752
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('zzz', 'aa', 'bb', 'cc', 'dd')
    assert move.name == 'zzz'
    assert move.new_mod == 'bb'
    assert move.new_attr == 'dd'



# Generated at 2022-06-21 18:00:36.243576
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('foo', 'bar')
    assert mod.name == 'foo'
    assert mod.old == 'bar'
    assert mod.new == 'foo'
    mod = MovedModule('foo', 'bar', 'baz')
    assert mod.name == 'foo'
    assert mod.old == 'bar'
    assert mod.new == 'baz'

# Generated at 2022-06-21 18:00:42.482140
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"



# Generated at 2022-06-21 18:00:52.769498
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst._nodes.tests.base import CSTNodeTest
    from libcst.matchers import Attribute, Call, Name, Param, SimpleString
    from libcst.metadata import MetadataWrapper
    from libcst.helpers import get_metadata
    from libcst.codemod import Context, CodemodContext, CodemodTest
    from libcst.codemod.commands.add_import import AddImportCommand
    from libcst.codemod.commands.remove_import import RemoveImportCommand
    from libcst.codemod.visitors.base import NoopVisitor
    from libcst.codemod.visitors.base import ContextAwareTransformer

    moves = prefixed_moves[0][1]

# Generated at 2022-06-21 18:00:54.360969
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("package", "old", "new")
    assert m.name == "package"
    assert m.old == "old"
    assert m.new == "new"



# Generated at 2022-06-21 18:01:00.633813
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:01:04.636532
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'new').name == 'name'
    assert MovedModule('name', 'new').new == 'new'

    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-21 18:01:16.459457
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('intern', 'builtins')
    assert m.name == 'intern'
    assert m.new_mod == 'builtins'
    assert m.new_attr == 'intern'

    m1 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert m1.name == 'cStringIO'
    assert m1.new_mod == 'io'
    assert m1.new_attr == 'StringIO'

    m2 = MovedAttribute('cStringIO', 'cStringIO', 'io', new_attr='StringIO')
    assert m2 == m1

    m3 = MovedAttribute('cStringIO', 'cStringIO', 'io', old_attr='StringIO')
    assert m3 == m1

# Generated at 2022-06-21 18:01:18.018223
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(prefixed_moves) - 1


# Generated at 2022-06-21 18:01:36.899584
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"


# Generated at 2022-06-21 18:01:38.309496
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that this class can successfully be constructed."""
    SixMovesTransformer()

# Generated at 2022-06-21 18:01:38.878169
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer(): pass

# Generated at 2022-06-21 18:01:45.007835
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'
    move = MovedAttribute("cStringIO", "cStringIO", "io", new_attr='cStringIO')
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'


# Generated at 2022-06-21 18:01:48.757557
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert (('os.getcwdu', 'six.moves.getcwd') in transformer.rewrites)
    assert 'six' in transformer.dependencies

# Generated at 2022-06-21 18:01:50.257648
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 116

# Generated at 2022-06-21 18:01:52.662774
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.winreg' == SixMovesTransformer(_get_rewrites())[1]['_winreg']

# Generated at 2022-06-21 18:01:58.651770
# Unit test for constructor of class MovedModule
def test_MovedModule():
    inputs = [
        (MovedModule("builtins", "__builtin__"),
         MovedModule("builtins", "__builtin__")),
        (MovedModule("configparser", "ConfigParser"),
         MovedModule("configparser", "ConfigParser", "configparser")),
    ]

    for input, desired_output in inputs:
        assert input == desired_output

# Generated at 2022-06-21 18:02:07.926048
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.new_attr == "StringIO"
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute.new_attr == "cStringIO"
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="StringIO_new")
    assert moved_attribute.new_attr == "StringIO_new"


# Generated at 2022-06-21 18:02:09.391731
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) > 100

# Generated at 2022-06-21 18:02:41.835906
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io') == MovedAttribute('cStringIO', 'cStringIO', 'io', 'cStringIO')


# Generated at 2022-06-21 18:02:47.628543
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("module", "oldmodule", "newmodule")
    assert m.name == "module"
    assert m.new == "newmodule"
    m = MovedModule("module2", "oldmodule2", "newmodule2")
    assert m.name == "module2"
    assert m.new == "newmodule2"
    m = MovedModule("module3", "oldmodule3")
    assert m.name == "module3"
    assert m.new == "module3"


# Generated at 2022-06-21 18:02:49.333476
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:02:55.218503
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test normal constructor
    transformer = SixMovesTransformer(None)
    assert transformer.target == (2, 7)
    assert transformer.module_import_rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']
    # Test constructor with target
    transformer = SixMovesTransformer(None, target=(1, 0))
    assert transformer.target == (1, 0)

# Generated at 2022-06-21 18:03:06.609824
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    b = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert b.name == "filter"
    assert b.new_mod == "builtins"
    assert b.new_attr == "filter"

    c = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert c.name == "input"
    assert c.new_mod == "builtins"
    assert c.new_attr == "input"


# Generated at 2022-06-21 18:03:08.796049
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"



# Generated at 2022-06-21 18:03:12.967901
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.new == 'bar'

    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.new == 'baz'


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:03:25.362461
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transform = SixMovesTransformer()
    assert six_moves_transform.dependencies == ['six']
    assert six_moves_transform.target == (2, 7)

    result = set()
    for val in six_moves_transform.rewrites:
        result.add(val[0])
        result.add(val[1])


# Generated at 2022-06-21 18:03:37.217398
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_cases = [
        (
            'filter', 'itertools', 'builtins',
            ('filter', 'itertools', 'builtins', None, None),
        ),
        (
            'filter', 'itertools', 'builtins', 'ifilter',
            ('filter', 'itertools', 'builtins', 'ifilter', None),
        ),
        (
            'getcwd', 'os', 'os', 'getcwdu',
            ('getcwd', 'os', 'os', 'getcwdu', None),
        ),
    ]
    for arg_list, expected in test_cases:
        ma = MovedAttribute(*arg_list)
        assert ma.__dict__ == expected


# Generated at 2022-06-21 18:03:38.836035
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:04:35.914679
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.import_rewrites == _get_rewrites()

# Generated at 2022-06-21 18:04:45.103034
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Recall that this class is a one-liner, so all we have to do is
    # check that the right things get assigned to 'new' and 'name'
    # attributes.
    obj = MovedModule('foo', 'bar')
    assert obj.new == 'foo'
    assert obj.name == 'bar'
    obj2 = MovedModule('foo', 'bar', 'baz')
    assert obj2.new == 'baz'
    assert obj2.name == 'foo'


# Generated at 2022-06-21 18:04:52.915504
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test for constructor of MovedModule class

    See python/cpython/Lib/test/test_six.py
    """
    from textwrap import dedent
    from .helpers import get_syntax_error
    moved = MovedModule("name", "old", "new")
    assert moved.name is "name"
    assert moved.old is "old"
    assert moved.new is "new"
    moved = MovedModule("name", "old")
    assert moved.name is "name"
    assert moved.old is "old"
    assert moved.new is "name"
    with get_syntax_error() as gets_syntax_error:
        exec(dedent("""
        moved = MovedModule("name", "old", new="new")
        """))

# Generated at 2022-06-21 18:04:59.540112
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:05:03.666145
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-21 18:05:14.909963
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()


if __name__ == '__main__':
    # Unit test
    from translating.misc import set_options
    set_options(verbose=True)
    from translating.parsing import parse
    from translating.converting import print_python_code
    test_program = '\n'.join(('from six.moves import xrange',
                              'from six.moves.tkinter_tix import Tix',
                              'from six.moves.urllib.parse import urlparse'))
    print(test_program)
    print('\n==>\n')
    tree = parse(test_program)
    print_python_code(tree)
    result = SixMovesTransformer().visit(tree)
    print_python_code(result)

# Generated at 2022-06-21 18:05:18.348149
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        SixMovesTransformer()
    except:
        assert False, 'Failed to instantiate SixMovesTransformer'


# Generated at 2022-06-21 18:05:28.256720
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:05:31.937638
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert(module.name == "name")
    assert(module.old == "old")
    assert(module.new == "new")


# Generated at 2022-06-21 18:05:39.618634
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites[0][0] == 'io.StringIO'
    assert SixMovesTransformer.rewrites[0][1] == 'six.moves.cStringIO'
    assert SixMovesTransformer.rewrites[-1][0] == 'urllib.robotparser.RobotFileParser'
    assert SixMovesTransformer.rewrites[-1][1] == 'six.moves.urllib.robotparser.RobotFileParser'