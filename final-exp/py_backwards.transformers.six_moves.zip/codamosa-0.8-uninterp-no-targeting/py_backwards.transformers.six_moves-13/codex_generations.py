

# Generated at 2022-06-21 17:56:59.650473
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites == set(_get_rewrites())

# Generated at 2022-06-21 17:57:04.477102
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-21 17:57:07.718983
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')



# Generated at 2022-06-21 17:57:10.026577
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None, None)
    for k, v in _get_rewrites():
        assert t.rewrites[k] == v
    assert t.dependencies == ['six']

# Generated at 2022-06-21 17:57:17.872322
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod1 = MovedModule("mod1", "oldmod1")
    assert mod1.name == "mod1"
    assert mod1.old == "oldmod1"
    assert mod1.new == "mod1"
    mod2 = MovedModule("mod2", "oldmod2", "newmod2")
    assert mod2.name == "mod2"
    assert mod2.old == "oldmod2"
    assert mod2.new == "newmod2"

# Generated at 2022-06-21 17:57:21.962962
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('x', 'y', 'z').name == 'x'
    assert MovedModule('x', 'y', 'z').new == 'z'
    assert MovedModule('x', 'y').name == 'x'
    assert MovedModule('x', 'y').new == 'x'
    assert MovedModule('x').name == 'x'
    assert MovedModule('x').new == 'x'

# Generated at 2022-06-21 17:57:25.212456
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mp = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert mp.name == "name"
    assert mp.new_mod == "new_mod"
    assert mp.new_attr == "new_attr"


# Generated at 2022-06-21 17:57:26.325159
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _test_six_moves_transformer(SixMovesTransformer)


# Generated at 2022-06-21 17:57:28.578664
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, frozenset)

# Generated at 2022-06-21 17:57:31.110401
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("new_mod", "old_mod", "").old_mod == "old_mod"


# Generated at 2022-06-21 17:57:44.116978
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer({})

# Generated at 2022-06-21 17:57:53.191535
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:01.483853
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert [
        ('builtins.input', 'six.moves.input'),
        ('builtins.intern', 'six.moves.intern'),
    ] == rewrites[0:2]
    assert [
        ('http.client.HTTPDefaultErrorHandler', 'six.moves.urllib.request.HTTPDefaultErrorHandler'),
        ('http.client.HTTPRedirectHandler', 'six.moves.urllib.request.HTTPRedirectHandler'),
    ] == rewrites[-4:-2]

# Generated at 2022-06-21 17:58:06.275224
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pyi_builder = six_moves_transformer(2.7)

# Generated at 2022-06-21 17:58:13.693387
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Check that the test is running in the right version of Python
    assert sys.version_info <= (2, 7)

    # Test the class constructor
    try:
        SixMovesTransformer()
    except:
        assert False, "Unexpected failure of SixMovesTransformer constructor"

    # Test that the code is running in the expected Python version
    assert sys.version_info <= (2, 7)


# Generated at 2022-06-21 17:58:17.469912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr = MovedAttribute("string_io", "cStringIO", "io", "StringIO")
    assert moved_attr.name == "string_io"
    assert moved_attr.new_mod == "io"
    assert moved_attr.new_attr == "StringIO"


# Generated at 2022-06-21 17:58:24.620772
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("myattr", "mymod", "newmod")
    assert isinstance(m, MovedAttribute)
    assert m.name == "myattr"
    assert m.new_mod == "newmod"
    assert m.new_attr == "myattr"
    assert m.old_mod == "mymod"
    assert m.old_attr == "myattr"


# Generated at 2022-06-21 17:58:27.784705
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('name', 'old', 'new')
    assert mod.name == 'name'
    assert mod.old == 'old'
    assert mod.new == 'new'


# Generated at 2022-06-21 17:58:33.959938
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"


# Generated at 2022-06-21 17:58:37.239105
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule("test_MovedModule", "test1", "test2")
    assert movedModule.name == "test_MovedModule"
    assert movedModule.old == "test1"
    assert movedModule.new == "test2"


# Generated at 2022-06-21 17:58:42.381008
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("a", "b", "c").name == "a"
    assert MovedAttribute("a", "b").name == "a"


# Generated at 2022-06-21 17:58:45.380563
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("sample", "sample_old", "sample_new", "old", "new")

    assert move.name == "sample"
    assert move.new_mod == "sample_new"
    assert move.new_attr == "new"

# Generated at 2022-06-21 17:58:49.319435
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("builtins", "__builtin__")
    assert mm.name == "builtins"
    assert mm.new == "builtins"
    mm = MovedModule("http_cookies", "Cookie", "http.cookies")
    assert mm.name == "http_cookies"
    assert mm.new == "http.cookies"



# Generated at 2022-06-21 17:58:50.897983
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    if sys.version_info < (3, 5):
        pass
    else:
        SixMovesTransformer()

# Generated at 2022-06-21 17:59:03.652956
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 17:59:08.961545
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    loader = SourceLoader('unittest')
    transformer = SixMovesTransformer(loader)
    assert transformer.loader is loader
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']
    assert transformer.rewrites == _get_rewrites()


# Generated at 2022-06-21 17:59:15.097945
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert a.name == "name", a.name
    assert a.new_mod == "new_mod", a.new_mod
    assert a.new_attr == "new_attr", a.new_attr

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 17:59:18.214658
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('random', '_random')

    assert moved_module.name is not None
    assert moved_module.new == '_random'
    assert moved_module.name == 'random'


# Generated at 2022-06-21 17:59:30.711290
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:38.933400
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_obj = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert test_obj.name == 'cStringIO'
    assert test_obj.new_mod == 'io'
    assert test_obj.new_attr == 'cStringIO'
    test_obj = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert test_obj.name == 'filter'
    assert test_obj.new_mod == 'builtins'
    assert test_obj.new_attr == 'filter'
    test_obj = MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    assert test_obj.name == 'filterfalse'
    assert test_obj.new_mod == 'itertools'
   

# Generated at 2022-06-21 17:59:54.537542
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma1.name == "cStringIO"
    assert ma1.new_mod == "cStringIO"
    assert ma1.new_attr == "StringIO"
    ma2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma2.new_attr == "cStringIO"
    ma3 = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="stringio")
    assert ma3.new_attr == "stringio"


# Generated at 2022-06-21 18:00:04.522303
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", None, None, None)
    assert a.name == "cStringIO"
    assert a.new_mod == "cStringIO"
    assert a.new_attr == "cStringIO"

    a = MovedAttribute("cStringIO", "cStringIO", "io", None, None)
    assert a.new_mod == "io"
    assert a.new_attr == "cStringIO"

    a = MovedAttribute("cStringIO", "cStringIO", None, None, "StringIO")
    assert a.new_attr == "StringIO"


# Generated at 2022-06-21 18:00:08.981274
# Unit test for constructor of class MovedModule
def test_MovedModule():
    'Test that constructor of class MovedModule works'
    assert MovedModule('mod', 'six.moves.mod') != MovedModule('mod', 'mod')



# Generated at 2022-06-21 18:00:20.351322
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=unused-variable
    normal_rewrite1 = (
        'urllib.parse',
        'six.moves.urllib_parse'
    )
    normal_rewrite2 = (
        'urllib.parse.ParseResult',
        'six.moves.urllib_parse.ParseResult'
    )
    normal_rewrite3 = (
        'urllib.parse.quote',
        'six.moves.urllib_parse.quote'
    )
    normal_rewrite4 = (
        'urllib.error',
        'six.moves.urllib_error'
    )

# Generated at 2022-06-21 18:00:26.087444
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(AttributeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    with pytest.raises(AttributeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "hello")
    with pytest.raises(AttributeError):
        MovedAttribute("cStringIO", "cStringIO", "io", new_attr = "hello")

# Generated at 2022-06-21 18:00:29.610712
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for the constructor of the class SixMovesTransformer"""

# Generated at 2022-06-21 18:00:32.399668
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import checks
    from . import six_moves
    assert checks.check_class(six_moves.SixMovesTransformer)


# Generated at 2022-06-21 18:00:35.695930
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old")
    assert mod.name == "name"
    assert mod.new == "name"



# Generated at 2022-06-21 18:00:38.258645
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:00:40.373338
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass
 

# Generated at 2022-06-21 18:00:52.776223
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # Test for attributes that have been defined
    expected = MovedModule("builtins", "__builtin__")
    assert expected.name == "builtins"
    assert expected.new == "builtins"

    # Test for missing old name
    expected = MovedModule("builtins", None)
    assert expected.name == "builtins"
    assert expected.new == "builtins"

    # Test for missing new name
    expected = MovedModule("builtins", "__builtin__", None)
    assert expected.name == "builtins"
    assert expected.new == "builtins"

    # Test for missing both old and new name
    expected = MovedModule("builtins", None, None)
    assert expected.name == "builtins"
    assert expected.new == "builtins"



# Generated at 2022-06-21 18:00:58.148427
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') == \
        MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') != \
        MovedAttribute('name2', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') != \
        MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr2')

# Generated at 2022-06-21 18:01:08.198018
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils.py2to3 import TEST_DATA_DIR
    from ..utils.helpers import run_test_module
    import sys

    sample_fname = str(TEST_DATA_DIR / 'six_sample.py')

    sys.argv = [
        sys.argv[0],
        sample_fname,
        '--target', '27',
        '--dependencies', 'six',
    ]

    return_value = run_test_module(SixMovesTransformer(), sys.argv)
    assert return_value.exit_code == 0
    assert return_value.stdout == ''

# Generated at 2022-06-21 18:01:17.096039
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert (path, 'six.moves{}.{}'.format(prefix, move.name) in SixMovesTransformer.rewrites)
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves{}.{}'.format(prefix, move.name) in SixMovesTransformer.rewrites)

# Generated at 2022-06-21 18:01:29.344155
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test: simple case
    attr = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert(attr.name == 'cStringIO')
    assert(attr.new_mod == 'io')
    assert(attr.new_attr == 'cStringIO')
    # Test: when old_attr is not None
    attr = MovedAttribute('StringIO', 'cStringIO', 'io', 'StringIO')
    assert(attr.name == 'StringIO')
    assert(attr.new_mod == 'io')
    assert(attr.new_attr == 'StringIO')
    # Test: when new_attr is not None
    attr = MovedAttribute('StringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert(attr.name == 'StringIO')

# Generated at 2022-06-21 18:01:30.441890
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer is not None

# Generated at 2022-06-21 18:01:37.750478
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

# Generated at 2022-06-21 18:01:39.300038
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert instance is not None

test_SixMovesTransformer()

# Generated at 2022-06-21 18:01:43.685868
# Unit test for constructor of class MovedModule
def test_MovedModule():
    s = MovedModule("name", "old_module", "new_module")
    assert s.name == "name"
    assert s.old == "old_module"
    assert s.new == "new_module"

# Generated at 2022-06-21 18:01:53.567170
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Only test attribute moves, since module moves can be tested with just
    # the prefixes in prefixed_moves.
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                real_name = 'six.moves{}.{}'.format(prefix, move.name)
                rewritten_name = '{}.{}'.format(move.new_mod, move.new_attr)
                # Test the class constructor
                stmt = SixMovesTransformer(real_name, 'six.moves{}'.format(prefix))
                assert(stmt.rewrites == [(rewritten_name, real_name)])



# Generated at 2022-06-21 18:02:07.564814
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(AssertionError):
        MovedModule('name', 'old', 'new', 'too many')



# Generated at 2022-06-21 18:02:11.599921
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"


# Generated at 2022-06-21 18:02:19.270763
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('os', 'os', 'os2').name == 'os'
    assert MovedModule('os', 'os', 'os2').old == 'os'
    assert MovedModule('os', 'os', 'os2').new == 'os2'
    assert MovedModule('os', 'os').name == 'os'
    assert MovedModule('os', 'os').old == 'os'
    assert MovedModule('os', 'os').new == 'os'


# Generated at 2022-06-21 18:02:20.744618
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer.rewrites)

# Generated at 2022-06-21 18:02:23.966529
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old_name', 'new_name')
    assert m.name == 'name'
    assert m.new == 'new_name'



# Generated at 2022-06-21 18:02:31.712741
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from .six_moves import MovedModule
    assert MovedModule("xmllib", "xmllib") == MovedModule("xmllib", "xmllib")
    assert MovedModule("xmllib", "xmllib", "xml.sax.expatreader") == MovedModule("xmllib", "xmllib", "xml.sax.expatreader")
    assert MovedModule("xmllib", "xmllib") != MovedModule("xmllib", "xmllib", "xml.sax.expatreader")
    assert MovedModule("xmllib", "xmllib") != MovedModule("xmllib2", "xmllib2")
    assert MovedModule("xmllib", "xmllib") != M

# Generated at 2022-06-21 18:02:36.606375
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("a", "b")
    assert moved_module.name == "a"
    assert moved_module.old == "b"
    assert moved_module.new == "a"


# Generated at 2022-06-21 18:02:46.986953
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mod1 = MovedAttribute("test", "test_mod1", "test_mod2", "old_attr", "new_attr")
    mod2 = MovedAttribute("test", "test_mod1", "test_mod2", "old_attr")
    mod3 = MovedAttribute("test", "test_mod1", "test_mod2")
    mod4 = MovedAttribute("test", "test_mod1")

    assert mod1.name == "test"
    assert mod1.new_mod == "test_mod2"
    assert mod1.new_attr == "new_attr"

    assert mod2.name == "test"
    assert mod2.new_mod == "test_mod2"
    assert mod2.new_attr == "old_attr"

    assert mod3.name == "test"
    assert mod

# Generated at 2022-06-21 18:02:54.979026
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == "StringIO"


# Generated at 2022-06-21 18:02:57.971225
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('name', 'old')
    assert moved.name == 'name'
    assert moved.old == 'old'
    assert moved.new == 'name'



# Generated at 2022-06-21 18:03:27.087171
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("test", "t")
    assert moved_module.name == "test", moved_module.name
    assert moved_module.new == "test", moved_module.new

    moved_module = MovedModule("test", "t", "t2")
    assert moved_module.name == "test", moved_module.name
    assert moved_module.new == "t2", moved_module.new



# Generated at 2022-06-21 18:03:37.977317
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule("name1", "old1", "new1")
    assert mm1.name == "name1"
    assert mm1.new == "new1"
    assert mm1.old == "old1"

    mm2 = MovedModule("name2", "old2")
    assert mm2.name == "name2"
    assert mm2.new == "name2"
    assert mm2.old == "old2"

    mm3 = MovedModule("name3")
    assert mm3.name == "name3"
    assert mm3.new == "name3"
    assert mm3.old == "name3"



# Generated at 2022-06-21 18:03:42.049488
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("move","old","new","oattr","nattr")
    assert test.name == "move"
    assert test.new_mod == "new"
    assert test.new_attr == "nattr"


# Generated at 2022-06-21 18:03:49.824218
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"


# Generated at 2022-06-21 18:03:55.760394
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("name", "old")
    assert x.name == "name"
    assert x.old == "old"
    assert x.new == "name"
    x = MovedModule("name", "old", "new")
    assert x.name == "name"
    assert x.old == "old"
    assert x.new == "new"


# Generated at 2022-06-21 18:04:01.081589
# Unit test for constructor of class MovedModule
def test_MovedModule():
    instance = MovedModule('name', 'old', 'new')
    assert instance.name == 'name'
    assert instance.new == 'new'
    assert instance.old == 'old'
    instance = MovedModule('name', 'old')
    assert instance.name == 'name'
    assert instance.new == 'name'
    assert instance.old == 'old'


# Generated at 2022-06-21 18:04:07.421096
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("foo", "a", "b")
    assert moved_module.name == "foo"
    assert moved_module.old == "a"
    assert moved_module.new == "b"

    moved_module = MovedModule("bar", "b")
    assert moved_module.name == "bar"
    assert moved_module.old == "b"
    assert moved_module.new == "bar"



# Generated at 2022-06-21 18:04:12.631826
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_attr"


# Generated at 2022-06-21 18:04:23.389320
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # type: () -> None
    moved_attr = MovedAttribute(
        name='name',
        old_mod='old_mod',
        new_mod='new_mod',
        old_attr='old_attr',
        new_attr='new_attr')
    assert moved_attr.name == 'name'
    assert moved_attr.new_mod == 'new_mod'
    assert moved_attr.new_attr == 'new_attr'
    # Omitting old_attr should result in the attribute having the same name as the
    # module, just like new_attr
    moved_attr2 = MovedAttribute(
        name='name', old_mod='old_mod', new_mod='new_mod')
    assert moved_attr2.name == 'name'
    assert moved_attr2.new_mod == 'new_mod'

# Generated at 2022-06-21 18:04:25.862358
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('testname', 'test1', 'test2')
    assert mm.name == 'testname'
    assert mm.new == 'test2'
    mm = MovedModule('testname', 'test1')
    assert mm.name == 'testname'
    assert mm.new == 'testname'

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:05:24.180657
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'foo'

    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'baz'



# Generated at 2022-06-21 18:05:31.421518
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:05:43.972762
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import unittest
    import six.moves.urllib
    import six.moves.urllib.request
    import six.moves.urllib.parse
    import six.moves.urllib.error
    import six

    class TestSixMovesTransformer(unittest.TestCase):
        def test_move_modules(self):
            transformer = SixMovesTransformer()

            self.assertEqual(transformer.rewrites["urllib.request"], "six.moves.urllib.request")
            self.assertEqual(transformer.rewrites["urllib.parse"], "six.moves.urllib.parse")
            self.assertEqual(transformer.rewrites["urllib.error"], "six.moves.urllib.error")
            self.assertE

# Generated at 2022-06-21 18:05:48.259439
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("test_mm", "old_mod")
    assert mm.name == "test_mm"
    assert mm.new == "old_mod"
    mm = MovedModule("test_mm", "old_mod", "new_mod")
    assert mm.name == "test_mm"
    assert mm.new == "new_mod"


# Generated at 2022-06-21 18:05:53.867280
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute(
        'cStringIO',
        'cStringIO',
        'io',
        'StringIO',
        new_attr='cStringIO'
    )
    assert (ma.name, ma.new_mod, ma.new_attr) == ('cStringIO', 'io', 'cStringIO')



# Generated at 2022-06-21 18:06:06.054726
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-21 18:06:14.900106
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Checks whether the constructor of class SixMovesTransformer produces the
    correct rewrites.
    """
    t = SixMovesTransformer()
    test_pairs = [
        ('reduce', 'six.moves.reduce'),
        ('StringIO', 'six.moves.cStringIO.StringIO'),
        ('Queue', 'six.moves.queue'),
        ('robotparser', 'six.moves.urllib.robotparser'),
    ]
    for original, rewritten in test_pairs:
        assert t.rewrites[original] == rewritten


# Synthetic test case for class SixMovesTransformer

# Generated at 2022-06-21 18:06:25.641638
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError) as e_info:
        MovedModule("test1")
        assert str(e_info.value) == "__init__() missing 2 required positional arguments: 'old' and 'new'"
    with pytest.raises(TypeError) as e_info:
        MovedModule("test2", "old")
        assert str(e_info.value) == "__init__() missing 1 required positional argument: 'new'"
    m1 = MovedModule("test3", "old", "new")
    assert m1.name == "test3"
    assert m1.old == "old"
    assert m1.new == "new"
    m2 = MovedModule("test4", "old5")
    assert m2.name == "test4"

# Generated at 2022-06-21 18:06:28.520839
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Tests case: import moved modules
    assert set(SixMovesTransformer().rewrites) == set(_get_rewrites())



# Generated at 2022-06-21 18:06:40.445758
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # noqa
    from . import six_moves
    from .six import PY3, PY26

    def normalize(import_):
        if PY3:
            return import_.strip()
        elif PY26:
            return import_.replace('urllib', 'urllib2')
        else:
            return import_
