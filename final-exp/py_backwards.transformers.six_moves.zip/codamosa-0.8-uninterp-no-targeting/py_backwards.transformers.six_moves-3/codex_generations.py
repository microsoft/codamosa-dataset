

# Generated at 2022-06-21 17:57:18.073709
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-21 17:57:22.021697
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-21 17:57:34.473909
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:57:45.329056
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("input", "__builtin__", "builtins").new_attr == "input"
    assert MovedAttribute("input", "__builtin__", "builtins", 'raw_input').new_attr == "input"
    assert MovedAttribute("input", "__builtin__", "builtins", 'raw_input', 'input').new_attr == "input"
    assert MovedAttribute("input", "__builtin__", "builtins", 'raw_input', 'input').old_attr == "raw_input"
    assert MovedAttribute("input", "__builtin__", "builtins", old_attr='raw_input', new_attr='input').new_attr == "input"

# Generated at 2022-06-21 17:57:54.078351
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert str(attr) == "cStringIO: from cStringIO import StringIO as cStringIO to io.StringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert str(attr) == "cStringIO: from cStringIO import StringIO as cStringIO to io.cStringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert str(attr) == "cStringIO: from cStringIO import cStringIO to io.cStringIO"
    attr = MovedAttribute("intern", "__builtin__", "sys")

# Generated at 2022-06-21 17:58:00.452658
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    def check(name, old_mod, new_mod, old_attr, new_attr):
        move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
        assert move.name == name
        assert move.new_mod == new_mod
        assert move.new_attr == new_attr
    check('name', 'old', 'new', 'old_attr', 'new_attr')
    check('name', 'old', 'new', None, None)
    check('name', 'old', None, None, None)
    check('name', 'old', None, 'old_attr', 'new_attr')
    check('name', 'old', 'new', 'old_attr', None)
    check('name', 'old', 'new', None, 'new_attr')


# Generated at 2022-06-21 17:58:04.872507
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('aaa', 'bbb').name == 'aaa'
    assert MovedModule('aaa', 'bbb').new == 'aaa'

    assert MovedModule('aaa', 'bbb', 'ccc').name == 'aaa'
    assert MovedModule('aaa', 'bbb', 'ccc').new == 'ccc'


# Unit tests for constructor of MovedAttribute

# Generated at 2022-06-21 17:58:15.046152
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # Assert the constructor sets the name
    assert MovedModule('foo', 'bar').name == 'foo'

    # Assert the constructor sets the old name
    assert MovedModule('foo', 'bar').old == 'bar'

    # Assert the constructor sets the new name
    assert MovedModule('foo', 'bar', 'baz').new == 'baz'

    # Assert the constructor sets the old name
    # as the new name if new name is not provided
    assert MovedModule('foo', 'bar').new == 'foo'

# Generated at 2022-06-21 17:58:22.781622
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:31.639408
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import six

    # Test the constructor of class SixMovesTransformer
    try:
        six_moves_transformer = SixMovesTransformer()
    except BaseException as e:
        print("SixMovesTransformer:", e)
        assert False

    # Test the method of class SixMovesTransformer
    try:
        template = "import {0}"
        globals_ = globals()
        for path, new_path in six_moves_transformer.rewrites:
            execute = template.format(path)
            six_moves_transformer.visit_ImportFrom(ast.parse(execute), None)
            if new_path in globals_:
                assert True
            else:
                assert False
    except BaseException as e:
        print("SixMovesTransformer:", e)


# Generated at 2022-06-21 17:58:41.830573
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()

# Generated at 2022-06-21 17:58:43.126129
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-21 17:58:48.458207
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("filter", "itertools", "builtins").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter").old_attr == "ifilter"
    assert MovedAttribute("filter", "itertools", "builtins", None, "filter").new_attr == "filter"


# Generated at 2022-06-21 17:58:52.177074
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar').name == 'foo'
    assert MovedModule('foo', 'bar').old == 'bar'
    assert MovedModule('foo', 'bar').new == 'foo'
    assert MovedModule('foo', 'bar', 'baz').new == 'baz'



# Generated at 2022-06-21 17:59:04.684071
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("abc", "abc1", "abc2")
    assert x.name == "abc"
    assert x.old == "abc1"
    assert x.new == "abc2"
    x = MovedModule("def")
    assert x.name == "def"
    assert x.old == "def"
    assert x.new == "def"
    x = MovedModule("def", "def1")
    assert x.name == "def"
    assert x.old == "def1"
    assert x.new == "def"
    x = MovedModule("def", new="def2")
    assert x.name == "def"
    assert x.old == "def"
    assert x.new == "def2"



# Generated at 2022-06-21 17:59:06.124781
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the constructor of SixMovesTransformer"""
    SixMovesTransformer()

# Generated at 2022-06-21 17:59:14.070496
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name1", "old1")
    assert m.name == "name1"
    assert m.old == "old1"
    assert m.new == "name1"

    m = MovedModule("name1", "old1", "new1")
    assert m.name == "name1"
    assert m.old == "old1"
    assert m.new == "new1"



# Generated at 2022-06-21 17:59:22.178853
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:30.079361
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('foo', 'bar')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'foo'
    assert moved_module.old == 'bar'

    moved_module = MovedModule('foo', 'bar', 'baz')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'baz'
    assert moved_module.old == 'bar'



# Generated at 2022-06-21 17:59:34.101466
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.new == "new"
    mod = MovedModule("name", "old")
    assert mod.name == "name"
    assert mod.new == "name"


# Generated at 2022-06-21 17:59:39.719806
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 17:59:42.676583
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old_mod", "new_mod")
    assert mm.name == "name"
    assert mm.new == "new_mod"


# Generated at 2022-06-21 17:59:52.050367
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Check if all paths in SixMovesTransformer.rewrites are also in
    # _get_rewrites().
    for path, _ in SixMovesTransformer.rewrites:
        assert any(x[0] == path for x in _get_rewrites())


if __name__ == '__main__':
    import sys
    import six

    print(SixMovesTransformer().transform_file(sys.argv[1]))
    for key in dir(six.moves):
        print(key)

# Generated at 2022-06-21 17:59:56.975002
# Unit test for constructor of class MovedModule
def test_MovedModule():
    attrib_name = 'name'
    attrib_old = 'old'
    attrib_new = 'new'

    move = MovedModule(attrib_name, attrib_old, attrib_new)
    assert move.name == attrib_name
    assert move.old == attrib_old
    assert move.new == attrib_new


# Generated at 2022-06-21 18:00:08.293842
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("six", "six", "six").to_dict() == {"name": "six"}
    assert MovedAttribute("six", "six", "six", "six", "six").to_dict() == {"name": "six"}
    assert MovedAttribute("six", "six", "six",
                          "six").to_dict() == {"name": "six", "new_attr": "six"}
    assert MovedAttribute("six", "six", "six",
                          None, "six").to_dict() == {"name": "six", "new_attr": "six"}
    assert MovedAttribute("six", "six", "six",
                          None, None).to_dict() == {"name": "six", "new_attr": "six"}


# Generated at 2022-06-21 18:00:11.929342
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.config == {}
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:00:13.596109
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(TypeError):
        SixMovesTransformer()

# Generated at 2022-06-21 18:00:23.771919
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"


# Generated at 2022-06-21 18:00:25.763472
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    if sys.version_info < (2, 7):
        # TODO: why is this test skipped here?
        # This looks strange, as it is only a simple import check.
        #: :type: SixMovesTransformer
        trans = SixMovesTransformer()  # noqa
        print(trans)

# Generated at 2022-06-21 18:00:27.657265
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule("test_module", "old_module"), MovedModule)


# Generated at 2022-06-21 18:00:37.723917
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-21 18:00:42.992229
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    if sys.version_info < (3, 6) and sys.version_info >= (3, 0):
        attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
        assert attr.name == "cStringIO"
        assert attr.new_mod == "io"
        assert attr.new_attr == "StringIO"
    else:
        pass

# Generated at 2022-06-21 18:00:50.692157
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("test", "mod", "test_new")
    assert move.new_mod == "test_new"
    assert move.new_attr == "test"
    move = MovedAttribute("test", "mod", "test_new", attr_new="new_attr")
    assert move.new_mod == "test_new"
    assert move.new_attr == "new_attr"
    move = MovedAttribute("test", "mod", "test_new", "old_attr")
    assert move.new_mod == "test_new"
    assert move.new_attr == "old_attr"
    move = MovedAttribute("test", "mod", "test_new", "old_attr", "new_attr")
    assert move.new_mod == "test_new"
    assert move.new_attr

# Generated at 2022-06-21 18:00:52.280124
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('test', 'a', 'b')
    assert a.name == 'test' and a.new_mod == 'b' and a.new_attr == 'test'

# Generated at 2022-06-21 18:00:57.389972
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:59.484399
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == dict(_get_rewrites())

if __name__ == '__main__':
    # Test code
    test_SixMovesTransformer()

# Generated at 2022-06-21 18:01:07.016846
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Test constructor of MovedAttribute."""
    move1 = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert move1.name == 'cStringIO'
    assert move1.new_mod == 'io'
    assert move1.new_attr == 'cStringIO'

    move2 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move2.name == 'cStringIO'
    assert move2.new_mod == 'io'
    assert move2.new_attr == 'StringIO'

# Generated at 2022-06-21 18:01:08.581171
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer() #type: ignore
    assert x


# Generated at 2022-06-21 18:01:11.726940
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert sorted(_get_rewrites()) == sorted(SixMovesTransformer.rewrites)

# Generated at 2022-06-21 18:01:18.160568
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    expected_rewrites = {
        'builtins.input': 'six.moves.input',
        'builtins.map': 'six.moves.map',
        'builtins.range': 'six.moves.range',
        'builtins.filter': 'six.moves.filter',
        'builtins.zip': 'six.moves.zip',
        'builtins.getcwd': 'six.moves.getcwd',
    }
    transformer = SixMovesTransformer()
    assert transformer.rewrites == expected_rewrites

# Generated at 2022-06-21 18:01:31.937659
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        MovedAttribute("foo", "bar", "baz")
    except:
        print("Failed to create object")


# Generated at 2022-06-21 18:01:38.771335
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('test', 'bla', 'ble')
    assert a.name == 'test'
    assert a.new_mod == 'ble'
    assert a.new_attr == 'test'

    b = MovedAttribute('test', 'bla', 'ble', 'foo')
    assert b.name == 'test'
    assert b.new_attr == 'foo'

    c = MovedAttribute('test', 'bla', 'ble', new_attr='bar')
    assert c.new_attr == 'bar'



# Generated at 2022-06-21 18:01:45.134211
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:01:48.490302
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute('test', 'old', 'new')
    assert test.name == 'test'
    assert test.new_mod == 'new'
    assert test.new_attr == 'test'

# Generated at 2022-06-21 18:01:49.848804
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"

# Generated at 2022-06-21 18:01:56.030207
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'

    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-21 18:02:00.988446
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-21 18:02:06.594254
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar', 'baz') == MovedModule('foo', 'bar', 'baz')
    assert MovedModule('foo', 'bar') == MovedModule('foo', 'bar')
    assert MovedModule('foo', 'bar').__repr__() == "MovedModule('foo', 'bar')"


# Generated at 2022-06-21 18:02:13.741483
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'name'

    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'



# Generated at 2022-06-21 18:02:17.022930
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.new == "__builtin__"


# Generated at 2022-06-21 18:02:45.987575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    assert m.old == "old"

    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"
    assert m.old == "old"


# Generated at 2022-06-21 18:02:49.918635
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("foo", "bar")
    assert module.name == "foo"
    assert module.new == "bar"



# Generated at 2022-06-21 18:02:55.682283
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_name = 'email'
    old_name = 'email.MIMEText'
    new_name = 'email.mime.text'
    move1 = MovedModule(module_name, old_name, new_name)
    assert move1.name == module_name
    assert move1.old == old_name
    assert move1.new == new_name


# Generated at 2022-06-21 18:02:59.246130
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Instantiate the class
    transformer = SixMovesTransformer()

    # Verify that instance variables are correct
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 18:03:05.367902
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("a", "b")
    assert a.name == "a"
    assert a.old == "b"
    assert a.new == "a"
    a = MovedModule("a", "b", "c")
    assert a.name == "a"
    assert a.old == "b"
    assert a.new == "c"

# Generated at 2022-06-21 18:03:07.511472
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old")



# Generated at 2022-06-21 18:03:10.806860
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # GIVEN
    # WHEN
    six_moves_transformer = SixMovesTransformer()
    # THEN
    assert six_moves_transformer.rewrites
    assert six_moves_transformer.dependencies

# Generated at 2022-06-21 18:03:12.840389
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(name='old', old='old', new='new')
    assert MovedModule(name='name', old='old')
    assert MovedModule(name='name')

# Generated at 2022-06-21 18:03:25.225967
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert (MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr
            == "StringIO")
    assert (MovedAttribute("cStringIO", "cStringIO",
                           "io", old_attr="StringIO").new_attr == "StringIO")
    assert (MovedAttribute("cStringIO", "cStringIO",
                           "io", new_attr="StringIO").new_attr == "StringIO")
    assert (MovedAttribute("cStringIO", "cStringIO",
                           "io", old_attr="StringIO", new_attr="StringIO").new_attr ==
            "StringIO")
    assert (MovedAttribute("filter", "itertools", "builtins", "ifilter",
                           "filter").new_attr == "filter")

# Unit tests for

# Generated at 2022-06-21 18:03:37.922479
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    mb = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert mb.name == "filter"
    assert mb.new_mod == "builtins"
    assert mb.new_attr == "filter"
    mc = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    assert mc.name == "range"
    assert mc.new_mod == "builtins"
    assert mc.new_attr == "range"

# Generated at 2022-06-21 18:04:32.585567
# Unit test for constructor of class MovedModule
def test_MovedModule():
    b = MovedModule("builtins", "__builtin__")
    assert b.name == "builtins"
    assert b.old == "__builtin__"
    assert b.new == "builtins"

    b = MovedModule("builtins", "__builtin__", "foo")
    assert b.name == "builtins"
    assert b.old == "__builtin__"
    assert b.new == "foo"

    b = MovedModule("builtins", "foo", "__builtin__")
    assert b.name == "builtins"
    assert b.old == "foo"
    assert b.new == "__builtin__"


# Generated at 2022-06-21 18:04:39.073167
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    files = {'six': '', 'six.moves': ''}
    transform = SixMovesTransformer(files)
    result = set(('six', 'six.moves', 'six.moves.urllib', 'six.moves.urllib.parse',
                  'six.moves.urllib.error', 'six.moves.urllib.request',
                  'six.moves.urllib.response', 'six.moves.urllib.robotparser'))
    assert result == transform.dependencies

# Generated at 2022-06-21 18:04:50.312074
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from six import moves
    assert moves.input is moves.builtins.input
    def test(name, old_mod, new_mod, old_attr=None, new_attr=None):
        move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
        assert move.name == name
        assert move.new_mod == new_mod
        if new_attr is None:
            new_attr = name if old_attr is None else old_attr
        assert move.new_mod == new_mod
        assert move.new_attr == new_attr
    test("cStringIO", "cStringIO", "io", "StringIO")
    test("filter", "itertools", "builtins", "ifilter", "filter")

# Generated at 2022-06-21 18:04:52.703076
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    The function is used to test SixMovesTransformer class
    """
    # Verify SixMovesTransformer has no error
    SixMovesTransformer()

# Generated at 2022-06-21 18:04:59.407290
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod')
    MovedAttribute('name', 'old_mod', 'new_mod', None, None)
    MovedAttribute('name', 'old_mod', 'new_mod', None)
    MovedAttribute('name', 'old_mod', 'new_mod', None, 'new_attr')
    MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', None)


# Generated at 2022-06-21 18:05:03.584135
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'

# Generated at 2022-06-21 18:05:09.340862
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old", "new").name == "name"
    # Default value for new
    assert MovedModule("name", "old").new == "name"


# Generated at 2022-06-21 18:05:21.728327
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'old'
    mm = MovedModule('name')
    assert mm.name == 'name'
    assert mm.old is None
    assert mm.new == 'name'
    with pytest.raises(TypeError) as excinfo:
        mm = MovedModule(1)
        assert 'name must be a string' in str(excinfo.value)
        mm = MovedModule('name', 1)

# Generated at 2022-06-21 18:05:22.867542
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:05:27.428681
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_object = MovedAttribute('StringIO', 'cStringIO', 'io', 'StringIO')
    if test_object.name == 'StringIO' \
            and test_object.new_mod == 'io' \
            and test_object.new_attr == 'StringIO':
        return 0
    else:
        return 1
