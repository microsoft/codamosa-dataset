

# Generated at 2022-06-21 17:57:07.874247
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.target_set == {(2, 7)}
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 17:57:19.678862
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 56
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                path_move = '{}.{}'.format(move.new_mod, move.name)
                assert path in SixMovesTransformer.rewrites
                assert SixMovesTransformer.rewrites[path] == 'six.moves{}.{}'.format(prefix, path_move)
            elif isinstance(move, MovedModule):
                assert move.new in SixMovesTransformer.rewrites

# Generated at 2022-06-21 17:57:23.814564
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'

# Generated at 2022-06-21 17:57:25.169793
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites

# Generated at 2022-06-21 17:57:28.793119
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    smt = SixMovesTransformer()
    assert(smt.rewrites == {'pickle.cPickle': 'six.moves.cPickle'})

# Generated at 2022-06-21 17:57:39.636848
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class Foo:
        pass
    moved = MovedModule("a", "A")
    assert moved.name == "a"
    assert moved.new == "a"
    assert moved.old is None
    moved = MovedModule("a", "A", "B")
    assert moved.name == "a"
    assert moved.new == "B"
    assert moved.old == "A"
    moved = MovedModule("a", Foo(), Foo)
    assert moved.name == "a"
    assert moved.new == "Foo"
    assert moved.old is None
    moved = MovedModule("a", Foo(), "B")
    assert moved.name == "a"
    assert moved.new == "B"
    assert moved.old is None
    moved = MovedModule("a", "A", Foo())
    assert moved

# Generated at 2022-06-21 17:57:40.919278
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 17:57:45.654627
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute('foo', 'bar', 'baz', 'qux', 'quux')
    assert item.name == 'foo'
    assert item.new_mod == 'baz'
    assert item.new_attr == 'quux'


# Generated at 2022-06-21 17:57:53.724961
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    isinstance(SixMovesTransformer, type)
    isinstance(SixMovesTransformer(), SixMovesTransformer)
    from six import moves
    from six.moves import urllib
    from six.moves.urllib.parse import urlparse
    from six.moves.urllib.error import URLError
    from six.moves.urllib.request import urlopen, urlretrieve

    moves.map(lambda x: x + 1, [1, 2, 3])
    urllib.parse.urlsplit('http://www.python.org/')
    URLError('oops')
    urlopen('http://www.python.org/')
    urlretrieve('http://www.python.org/')

# Generated at 2022-06-21 17:57:55.766158
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 42

# Generated at 2022-06-21 17:58:01.419798
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("MovedMod", "OldMod")
    assert mm.name == "MovedMod"
    assert mm.new == "MovedMod"
    mm = MovedModule("MovedMod", "OldMod", "NewMod")
    assert mm.name == "MovedMod"
    assert mm.new == "NewMod"

# Generated at 2022-06-21 17:58:03.537290
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old')
    assert module.name == 'name'
    assert module.new == 'name'
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.new == 'new'


# Generated at 2022-06-21 17:58:16.198763
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Default params
    try:
        MovedAttribute("cStringIO", "cStringIO", "io")
    except Exception as err:
        assert False, "MovedAttribute() raised Exception: " + str(err)

    # Specified params
    try:
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    except Exception as err:
        assert False, "MovedAttribute() raised Exception: " + str(err)

    # Specified params and with name = old_attr
    try:
        MovedAttribute("StringIO", "cStringIO", "io", "StringIO", "StringIO")
    except Exception as err:
        assert False, "MovedAttribute() raised Exception: " + str(err)



# Generated at 2022-06-21 17:58:28.210468
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:40.824990
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves.urllib.parse
    import six.moves.urllib.error

    # test 1
    ast = parse("import six.moves.urllib.parse as urlparse")
    t = SixMovesTransformer()
    t.visit(ast)
    assert ast.body[0].value.id == 'urllib.parse'
    assert ast == parse("import urllib.parse as urlparse")

    # test 2
    ast = parse("from six.moves import urllib.parse as urlparse")
    t = SixMovesTransformer()
    t.visit(ast)
    assert ast.body[0].names[0].name == 'urllib.parse'
    assert ast == parse("from urllib import parse as urlparse")

    # test

# Generated at 2022-06-21 17:58:42.423687
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer(None, None)
    assert st is not None


# Generated at 2022-06-21 17:58:43.727711
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t is not None

# Generated at 2022-06-21 17:58:47.058692
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test Rewriter initialization.
    """
    transformer = SixMovesTransformer()
    #pytest.set_trace()
    expected = set(['six'] +
                   [name for path, name in _get_rewrites()])
    actual = transformer.dependencies
    assert actual == expected

# Generated at 2022-06-21 17:58:58.595948
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:10.559929
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_var1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO");
    assert test_var1.name == "cStringIO"
    assert test_var1.new_mod == "cStringIO"
    assert test_var1.new_attr == "StringIO"
    test_var2 = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO");
    assert test_var2.name == "cStringIO"
    assert test_var2.new_mod == "cStringIO"
    assert test_var2.new_attr == "StringIO"
    test_var3 = MovedAttribute("cStringIO", "cStringIO", "io");
    assert test_var3.name == "cStringIO"
    assert test_var3.new

# Generated at 2022-06-21 17:59:18.545041
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ca = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ca.name == "cStringIO"
    assert ca.new_mod == "io"
    assert ca.new_attr == "StringIO"
    nca = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert nca == ca



# Generated at 2022-06-21 17:59:30.811304
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test = SixMovesTransformer
    assert test.dependencies == ['six']

# Generated at 2022-06-21 17:59:36.358095
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "oldname")
    assert mod.name == "name"
    assert mod.new == "name"
    assert mod.old == "oldname"
    assert str(mod) == "MovedModule(name=%r, old=%r, new=%r)" % ("name", "oldname", "name")

# Generated at 2022-06-21 17:59:41.207439
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('module_name', 'old_name', 'new_name')
    assert moved_module.name == 'module_name'
    assert moved_module.old == 'old_name'
    assert moved_module.new == 'new_name'

    moved_module = MovedModule('module_name', 'old_name')
    assert moved_module.name == 'module_name'
    assert moved_module.old == 'old_name'
    assert moved_module.new == 'module_name'


# Generated at 2022-06-21 17:59:46.679054
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("tkinter", "Tkinter").name == "tkinter"
    assert MovedModule("b0rken_module", "b0rken", "b0rken").name == "b0rken_module"
    assert MovedModule("b0rken_module", "b0rken", "b0rken").new == "b0rken_module"
    assert MovedModule("__foo__", "__foo__").new == "__foo__"


# Generated at 2022-06-21 17:59:54.016709
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO').new_attr == 'StringIO'



# Generated at 2022-06-21 17:59:58.337909
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('foo', 'bar')
    assert module.name == 'foo'
    assert module.new == 'foo'
    module = MovedModule('bar', 'baz', 'qux')
    assert module.name == 'bar'
    assert module.new == 'qux'
    moves = [module]
    assert _get_rewrites() == [('qux', 'six.moves.bar')]

# Generated at 2022-06-21 18:00:09.254782
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:13.753773
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _, rewrites = list(_get_rewrites())[0]
    from_to = rewrites.split(' -> ')
    assert set(SixMovesTransformer.rewrites[0]) == set(from_to)


# Generated at 2022-06-21 18:00:15.671435
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:00:30.800912
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:36.109150
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('test', 'old', 'new', 'old_attr', 'new_attr')
    assert attr.name == 'test'
    assert attr.new_mod == 'new'
    assert attr.new_attr == 'new_attr'


# Generated at 2022-06-21 18:00:40.730698
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("foo", "bar")
    assert move.name == "foo"
    assert move.new == move.name
    move = MovedModule("foo", "bar", "baz")
    assert move.new == "baz"



# Generated at 2022-06-21 18:00:45.522109
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('tkinter', 'Tkinter')
    assert module.name == 'tkinter'
    assert module.old == 'Tkinter'
    assert module.new == 'tkinter'
    module = MovedModule('tkinter', 'Tkinter', 'tkinter.ttk')
    assert module.name == 'tkinter'
    assert module.old == 'Tkinter'
    assert module.new == 'tkinter.ttk'

# Generated at 2022-06-21 18:00:47.507489
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'


# Generated at 2022-06-21 18:00:56.594813
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=C0103
    assert MovedAttribute('name', 'old', 'new').name == 'name'
    assert MovedAttribute('name', 'old', 'new').new_mod == 'new'
    assert MovedAttribute('name', 'old', 'new').new_attr == 'name'
    assert MovedAttribute('name', 'old', 'new', 'old_attr').name == 'name'
    assert MovedAttribute('name', 'old', 'new', 'old_attr').new_mod == 'new'
    assert MovedAttribute('name', 'old', 'new', 'old_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'old', 'new', 'old_attr', 'new_attr').name == 'name'

# Generated at 2022-06-21 18:01:00.522022
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moves = [MovedModule("builtins", "__builtin__"),
                  MovedModule("configparser", "ConfigParser"),
                  MovedModule("copyreg", "copy_reg")]
    for move in test_moves:
        if isinstance(move, MovedModule):
            assert move.new == move.name
test_MovedModule()

# Generated at 2022-06-21 18:01:09.368576
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute(name="a", old_mod="b", new_mod="c")
    assert attr.name == "a"
    assert attr.new_mod == "c"
    assert attr.new_attr == "a"

    attr = MovedAttribute(name="a", old_mod="b", new_mod="c",
                          old_attr="d", new_attr="e")
    assert attr.name == "a"
    assert attr.new_mod == "c"
    assert attr.new_attr == "e"

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 18:01:15.026288
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_moved_attribute.name == "cStringIO"
    assert test_moved_attribute.new_mod == "io"
    assert test_moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-21 18:01:16.459172
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass
# vim:ts=4 sts=4 sw=4 et

# Generated at 2022-06-21 18:01:38.247573
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:01:41.207149
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites[0] == ('ConfigParser', 'six.moves.configparser')
    assert SixMovesTransformer.rewrites[-1] == ('urllib.robotparser', 'six.moves.urllib.robotparser')

# Generated at 2022-06-21 18:01:54.093242
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == 'io'
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == 'StringIO'
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == 'io'
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", None).name == 'cStringIO'
    assert M

# Generated at 2022-06-21 18:02:06.810172
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute(name='MovedAttribute', old_mod='old', new_mod='new').name == 'MovedAttribute'
    assert MovedAttribute(name='MovedAttribute', old_mod='old', new_mod='new').new_mod == 'new'
    assert MovedAttribute(name='MovedAttribute', old_mod='old', new_mod='new').new_attr == 'MovedAttribute'
    assert MovedAttribute(name='MovedAttribute', old_mod='old', new_mod='new', old_attr='old_attr', new_attr='new_attr').old_attr == 'old_attr'
    assert MovedAttribute(name='MovedAttribute', old_mod='old', new_mod='new', old_attr='old_attr', new_attr='new_attr').new_attr == 'new_attr'
   

# Generated at 2022-06-21 18:02:08.738969
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert rewrites == SixMovesTransformer.rewrites

# Generated at 2022-06-21 18:02:18.288289
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('a', 'b', 'c', 'd', 'e')
    assert move.name == 'a'
    assert move.new_mod == 'c'
    assert move.new_attr == 'e'
    move = MovedAttribute('a', 'b', 'c')
    assert move.name == 'a'
    assert move.new_mod == 'c'
    assert move.new_attr == 'a'
    move = MovedAttribute('a', 'b', 'c', 'd')
    assert move.name == 'a'
    assert move.new_mod == 'c'
    assert move.new_attr == 'd'


# Generated at 2022-06-21 18:02:28.738906
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for SixMovesTransformer"""
    # Check that each rewrite is in rewrites
    for prefix, moves in prefixed_moves:
        for move in moves:
            # Make sure all these attributes are set
            move.old_mod
            move.old_attr
            move.new_mod
            move.new_attr
            move.name
            if isinstance(move, MovedAttribute):
                assert 'six.moves{}.{}'.format(prefix, move.name) in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                assert 'six.moves{}.{}'.format(prefix, move.name) in SixMovesTransformer.rewrites

    # Check that there is no duplicate in rewrites
    assert len(SixMovesTransformer.rewrites) == len

# Generated at 2022-06-21 18:02:41.931055
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('name', 'old_mod', 'new_mod')
    assert obj.name == 'name', 'MovedAttribute(name, old_mod, new_mod) : name incorrect'
    assert obj.new_mod == 'new_mod', 'MovedAttribute(name, old_mod, new_mod) : new_mod incorrect'
    assert obj.new_attr == 'name', 'MovedAttribute(name, old_mod, new_mod) : new_attr incorrect'

    obj = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert obj.name == 'name', 'MovedAttribute(name, old_mod, new_mod, old_attr, new_attr) : name incorrect'

# Generated at 2022-06-21 18:02:49.565511
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", new_attr="cStringIO").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", new_attr="cStringIO").new_attr == "cStringIO"

# Generated at 2022-06-21 18:02:59.214363
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst._six import PY36
    from libcst.metadata import PositionProvider
    from libcst.metadata.wrapper import ModuleMetadataWrapper
    if PY36:
        from libcst.testing.utils import UnitTest
        import unittest

        class SixMovesTransformerTest(UnitTest):
            TRANSFORMER = SixMovesTransformer


# Generated at 2022-06-21 18:03:32.037341
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("base", "base", "test")
    assert x.name == "base"
    assert x.new_mod == "test"
    assert x.new_attr == "base"
    x = MovedAttribute("base", "base", "test", "old", "new")
    assert x.name == "base"
    assert x.new_mod == "test"
    assert x.new_attr == "new"
    x = MovedAttribute("base", "base", "test", "old")
    assert x.name == "base"
    assert x.new_mod == "test"
    assert x.new_attr == "old"

# Generated at 2022-06-21 18:03:34.226900
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    check_transformer(SixMovesTransformer)

# Generated at 2022-06-21 18:03:36.803218
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("name", "old")
    assert move.name == "name"
    assert move.old == "old"
    assert move.new == "name"

    move = MovedModule("name", "old", "new")
    assert move.name == "name"
    assert move.old == "old"
    assert move.new == "new"



# Generated at 2022-06-21 18:03:47.353417
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import io
    import types
    import unittest
    import unittest.mock

    sys.path.insert(0, '')

    from .base import BaseImportRewrite
    from .base import ExtractInfoVisitor
    from lib2to3 import fixer_base
    from lib2to3 import fixer_util
    from lib2to3 import pygram
    from lib2to3 import pytree

    from .base import BaseImportRewrite
    from .base2 import ExtractInfo
    from .base2 import ExtractInfoVisitor

    from .six_moves import SixMovesTransformer


    class TempUtility:
        def __init__(self):
            self.was_called = False



# Generated at 2022-06-21 18:03:55.760188
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.name == 'six-moves-transformer'
    assert st.description == textwrap.dedent(SixMovesTransformer.__doc__).strip()
    assert st.dependencies == ['six']
    assert (('urllib.parse.urlsplit', 'six.moves.urllib.urlsplit')
            in st.rewrites)
    assert (('urllib.parse.urlsplit', 'six.moves.urllib.urlsplit')
            in _get_rewrites())

# Generated at 2022-06-21 18:04:05.648162
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=protected-access
    assert getattr(SixMovesTransformer, 'rewrites', None) is not None
    c = SixMovesTransformer.__new__(SixMovesTransformer)
    c.__init__()
    assert getattr(c, 'rewrites', None) is not None
    assert getattr(c, 'rewrites_re', None) is not None
    assert getattr(c, 'target', None) is not None
    assert getattr(c, 'dependencies', None) is not None
    assert isinstance(c.rewrites, list)
    assert isinstance(c.target, tuple)
    assert isinstance(c.dependencies, list)
    assert isinstance(c.rewrites_re, re._pattern_type)

# Generated at 2022-06-21 18:04:18.277570
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('name', 'old_mod', 'new_mod')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'name'

    attr = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'new_attr'

    attr = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'old_attr'



# Generated at 2022-06-21 18:04:20.468518
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Type check
    t = SixMovesTransformer(None)
    assert isinstance(t, SixMovesTransformer)

# Generated at 2022-06-21 18:04:28.803413
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3 import pygram
    from lib2to3.pgen2 import token
    from lib2to3.fixer_util import Name, String, Number, import_stmt, syms
    from lib2to3.fixer_base import BaseFix, Token, Attr
    import lib2to3.fixer_util
    import re
    import sys


    class SixMovesTransformer(BaseFix):
        BM_compatible = True
        PATTERN = """
        import_name< 'import' (dotted_as_names< any* > |
                               import_as_name< any* >) >
        """
        run_order = 6

        def transform(self, node, results):
            names = []

# Generated at 2022-06-21 18:04:35.230674
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"



# Generated at 2022-06-21 18:05:31.243633
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:05:43.933285
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("name", "old_mod", "new_mod", None, None).new_attr == "name"
    assert MovedAttribute("name", "old_mod", None, None, None).new_attr == "name"
   

# Generated at 2022-06-21 18:05:47.938125
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-21 18:06:00.412418
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from ..preprocessing.docformatter import process_docstring
    import inspect
    import six.moves
    for attr in _moved_attributes:
        if isinstance(attr, MovedAttribute):
            if attr.new_attr == attr.name:
                assert hasattr(six.moves, attr.name)
            else:
                assert getattr(six.moves, attr.name) is getattr(six.moves, attr.new_mod, attr.new_attr)
        elif isinstance(attr, MovedModule):
            if attr.name == attr.new:
                assert hasattr(six.moves, attr.name)

# Generated at 2022-06-21 18:06:04.058633
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("configparser", "ConfigParser")
    assert mm.name == "configparser"
    assert mm.old == "ConfigParser"
    assert mm.new == "configparser"



# Generated at 2022-06-21 18:06:15.004197
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import six
    from .sixmoves import SixMovesTransformer
    from ..utils.helpers import eager

    t = SixMovesTransformer(sys.argv)
    results = [m for m in t.rewrites]
    assert len(results) == len(_get_rewrites())
    assert results[0][1] == 'six.moves.cStringIO'
    assert results[1][1] == 'six.moves.filter'
    assert results[2][1] == 'six.moves.filterfalse'
    assert results[3][1] == 'six.moves.input'
    assert results[4][1] == 'six.moves.intern'
    assert results[5][1] == 'six.moves.map'

# Generated at 2022-06-21 18:06:23.217803
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) == 35
    assert len(_urllib_parse_moved_attributes) == 26
    assert len(_urllib_error_moved_attributes) == 3
    assert len(_urllib_request_moved_attributes) == 39
    assert len(_urllib_response_moved_attributes) == 4
    assert len(_urllib_robotparser_moved_attributes) == 1
    assert len(prefixed_moves) == 6
    assert len(SixMovesTransformer().rewrites) == 104

# Generated at 2022-06-21 18:06:26.288848
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_object = MovedModule("name", "old", "new")
    assert test_object.name == "name"
    assert test_object.old == "old"
    assert test_object.new == "new"



# Generated at 2022-06-21 18:06:29.147344
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attribute.name == 'name'
    assert attribute.new_mod == 'new_mod'
    assert attribute.new_attr == 'new_attr'



# Generated at 2022-06-21 18:06:34.455454
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"


# Unit tests for constructor of class MovedModule