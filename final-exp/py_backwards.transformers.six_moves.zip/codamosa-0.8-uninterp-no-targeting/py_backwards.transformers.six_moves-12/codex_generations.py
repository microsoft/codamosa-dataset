

# Generated at 2022-06-21 17:57:06.419044
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name = "tkinter", 
                          old = "Tkinter", 
                          new = "tkinter")

    assert moved_module.name == "tkinter"
    assert moved_module.old == "Tkinter"
    assert moved_module.new == "tkinter"



# Generated at 2022-06-21 17:57:07.391935
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 17:57:19.093711
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    '''
    Test the SixMovesTransformer class.
    '''
    f_input = """
import six
import six.moves.urllib.request
import six.moves.urllib.parse
import six.moves.urllib.error
import six.moves.urllib.response
import six.moves.urllib.robotparser
import six.moves.urllib.parse.urlparse
import six.moves.urllib.error.URLError
"""

# Generated at 2022-06-21 17:57:19.730528
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

# Generated at 2022-06-21 17:57:21.561638
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert transformer.rewrites and transformer.dependencies

# Generated at 2022-06-21 17:57:26.519213
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("TestName", "TestOldMod", "TestNewMod", "TestOldAttr", "TestNewAttr")
    assert ma.name == "TestName"
    assert ma.new_mod == "TestNewMod"
    assert ma.new_attr == "TestNewAttr"


# Generated at 2022-06-21 17:57:35.467324
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("queue", "Queue")
    assert moved_module.name == "queue"
    assert moved_module.new == "queue"

    moved_module = MovedModule("queue", "Queue", "queues")
    assert moved_module.name == "queue"
    assert moved_module.new == "queues"

    moved_module = MovedModule("queue", "Queue", "six.moves.queues")
    assert moved_module.name == "queue"
    assert moved_module.new == "six.moves.queues"



# Generated at 2022-06-21 17:57:41.441824
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that all 'six.moves' imports in this module have a corresponding entry in the rewrites of the SixMovesTransformer"""
    six_moves_names = _get_rewrites()
    for _, six_moves_name in six_moves_names:
        assert six_moves_name in globals(), \
            "Found six.moves import in module {} but it is not handled in the rewrites of SixMovesTransformer".format(__name__)

# Generated at 2022-06-21 17:57:47.223616
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.old == "old"
    assert mod.new == "new"

    mod = MovedModule("name", "old")
    assert mod.name == "name"
    assert mod.old == "old"
    assert mod.new == "name"

# Generated at 2022-06-21 17:57:48.600190
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert sorted(SixMovesTransformer.rewrites) == sorted(_get_rewrites())

# Generated at 2022-06-21 17:57:57.227596
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a_moved_attribute.name == "cStringIO"
    assert a_moved_attribute.old_mod == "cStringIO"
    assert a_moved_attribute.new_mod == "io"
    assert a_moved_attribute.old_attr == "StringIO"
    assert a_moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-21 17:58:01.777145
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    from .base import ImportNodeReplacement
    node_replacements = list(SixMovesTransformer().find_replacements(__file__, sys.argv))
    assert len(node_replacements) == len(SixMovesTransformer.rewrites)
    for node_replacement in node_replacements:
        assert isinstance(node_replacement, ImportNodeReplacement)

# Generated at 2022-06-21 17:58:13.055228
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old', 'new')
    assert ma.name == 'name'
    assert ma.old_mod is None
    assert ma.new_mod == 'new'
    assert ma.old_attr is None
    assert ma.new_attr == 'name'

    ma2 = MovedAttribute('name', 'old', 'new', 'old2', 'new2')
    assert ma2.name == 'name'
    assert ma2.old_mod is None
    assert ma2.new_mod == 'new'
    assert ma2.old_attr == 'old2'
    assert ma2.new_attr == 'new2'


# Generated at 2022-06-21 17:58:17.618342
# Unit test for constructor of class MovedModule
def test_MovedModule():
    testmodule = MovedModule("testmodule", "testmodule")
    assert testmodule.name == "testmodule"
    assert testmodule.new == "testmodule"
    testmodule = MovedModule("testmodule", "testmodule", "testmodule2")
    assert testmodule.name == "testmodule"
    assert testmodule.new == "testmodule2"


# Generated at 2022-06-21 17:58:26.468767
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("name", "old_mod", "new_mod")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "name"

    obj = MovedAttribute("name", "old_mod", "new_mod", "old_name", "new_name")
    assert obj.name == "name"
    assert obj.new_mod == "new_mod"
    assert obj.new_attr == "new_name"


# Generated at 2022-06-21 17:58:31.612778
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("arbit", "arbit").name == "arbit"
    assert MovedModule("arbit", "arbit").new == "arbit"
    assert MovedModule("arbit", "arbit", "").new == ""



# Generated at 2022-06-21 17:58:34.515390
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.new == "new"
    assert mod.old == "old"

# Generated at 2022-06-21 17:58:42.306903
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 17:58:50.642522
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute('test', 'old', 'new', 'old_attr', 'new_attr')
    assert test.name == 'test'
    assert test.old_mod == 'old'
    assert test.new_mod == 'new'
    assert test.old_attr == 'old_attr'
    assert test.new_attr == 'new_attr'
    test = MovedAttribute('test', 'old', 'new', 'old_attr')
    assert test.name == 'test'
    assert test.old_mod == 'old'
    assert test.new_mod == 'new'
    assert test.old_attr == 'old_attr'
    assert test.new_attr == 'old_attr'
    test = MovedAttribute('test', 'old', 'new')
    assert test.name == 'test'

# Generated at 2022-06-21 17:58:51.983815
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 17:59:01.413075
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO").new_attr == "cStringIO"

# Generated at 2022-06-21 17:59:03.408248
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    sys.modules['six'] = 1
    transformer = SixMovesTransformer()
    assert transformer
    assert transformer.rewrites
    assert len(transformer.rewrites) > 0
    assert transformer.is_enabled(2, 7)
    assert transformer.get_dependencies() == ['six']

# Generated at 2022-06-21 17:59:07.706492
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:11.468233
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old", "name")
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")

# Generated at 2022-06-21 17:59:13.001279
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:59:18.878689
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(name='foo', old_mod='old.mod', new_mod='new.mod',
                          old_attr='old_attr', new_attr='new_attr')
    assert move.name == 'foo'
    assert move.new_mod == 'new.mod'
    assert move.new_attr == 'new_attr'

# Generated at 2022-06-21 17:59:20.812450
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.source, transformer.target == ((2, 7), (3, 0))

# Generated at 2022-06-21 17:59:26.495349
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.new == 'baz'
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.new == 'foo'


# Generated at 2022-06-21 17:59:36.432702
# Unit test for constructor of class MovedModule

# Generated at 2022-06-21 17:59:46.466286
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..rewrites import RewriteImports
    from ..utils.helpers import signature
    from .six_moves import SixMovesTransformer

    for name, obj in vars(RewriteImports).items():
        if name == '__module__':
            continue
        if isinstance(obj, type) and issubclass(obj, _BaseRewrite):
            if obj.__name__.endswith('Transformer'):
                if obj.__name__ == 'SixMovesTransformer':
                    get_transformer = obj
                # add assert to check that class is well tested
                assert getattr(obj, 'rewrites', []), \
                       '{} not tested'.format(obj)

# Generated at 2022-06-21 18:00:00.014918
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-21 18:00:04.558230
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__', '__builtin__').new == '__builtin__'
    assert MovedModule('builtins', '__builtin__').new == '__builtin__'
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('configparser', 'ConfigParser', 'configparser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser', 'configparser').new == 'configparser'


# Generated at 2022-06-21 18:00:17.640944
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-21 18:00:18.262423
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer

# Generated at 2022-06-21 18:00:23.766789
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_modules = [
        MovedModule("BaseHTTPServer", "BaseHTTPServer", "http.server"),
        MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server"),
        MovedModule("SimpleHTTPServer", "SimpleHTTPServer", "http.server")
    ]
    for module in moved_modules:
        assert module.name == module.new
    return moved_modules

# Generated at 2022-06-21 18:00:29.945812
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    transformer = SixMovesTransformer()

    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']
    assert transformer.rewrites[0] == ('sys.intern', 'six.moves.intern')
    assert transformer.rewrites[1] == ('sys.range', 'six.moves.range')
    assert transformer.rewrites[-1] == ('.urllib.robotparser.RobotFileParser', 'six.moves.urllib_robotparser.RobotFileParser')

# Generated at 2022-06-21 18:00:37.155916
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert c.name == 'name', "Name of MovedAttribute is incorrect"
    assert c.new_mod == 'new_mod', "New module of MovedAttribute is incorrect"
    assert c.new_attr == 'new_attr', "New attribute of MovedAttribute is incorrect"


# Generated at 2022-06-21 18:00:43.572209
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"


# Generated at 2022-06-21 18:00:48.517051
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("test_mod", "old_mod")
    assert move.name == 'test_mod'
    assert move.new == 'test_mod'
    assert move.old == 'old_mod'

    move = MovedModule("test_mod", "old_mod", "new_mod")
    assert move.name == 'test_mod'
    assert move.new == 'new_mod'
    assert move.old == 'old_mod'



# Generated at 2022-06-21 18:00:57.274662
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    code = """
from __future__ import absolute_import, division, print_function, unicode_literals
from future.builtins import *
from future import standard_library
from future.utils import python_2_unicode_compatible
from future.types.newobject import newobject

import six
from six.moves import urllib, range, input, filter, map, zip
from six.moves.urllib.parse import urlencode
"""
    tree = ast.parse(code)
    transformer = SixMovesTransformer()
    assert transformer.count_rewrites(tree) == 5
    transformer.run(tree)

    # Test against original code (will raise SyntaxError if it doesn't work)
    exec(compile(tree, filename='<ast>', mode='exec'))


# Test that we can find the following example

# Generated at 2022-06-21 18:01:13.603717
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule('ntpath', 'ntpath', 'ntpath')
    assert movedmodule.name == 'ntpath'
    assert movedmodule.old == 'ntpath'
    assert movedmodule.new == 'ntpath'

# Generated at 2022-06-21 18:01:16.660782
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class_name = MovedModule('builtins', '__builtin__')
    assert class_name.name == 'builtins'
    assert class_name.new == 'builtins'

# Generated at 2022-06-21 18:01:21.789041
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"



# Generated at 2022-06-21 18:01:32.657932
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert item1.name == "cStringIO"
    assert item1.new_mod == "io"
    assert item1.new_attr == "StringIO"

    item2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert item2.name == "cStringIO"
    assert item2.new_mod == "io"
    assert item2.new_attr == "cStringIO"

    item3 = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert item3.name == "cStringIO"
    assert item3.new_mod == "cStringIO"
    assert item3.new_attr == "StringIO"

    item4 = Moved

# Generated at 2022-06-21 18:01:37.655415
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attr = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert move_attr.name == 'name'
    assert move_attr.new_mod == 'new_mod'
    assert move_attr.new_attr == 'new_attr'


# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 18:01:44.496550
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("pathlib", "pathlib", "pathlib2")
    assert mod.name == "pathlib"
    assert mod.old == "pathlib"
    assert mod.new == "pathlib2"
    mod = MovedModule("pathlib")
    assert mod.name == "pathlib"
    assert mod.old == "pathlib"
    assert mod.new == "pathlib"
    mod = MovedModule("pathlib", "pathlib2")
    assert mod.name == "pathlib"
    assert mod.old == "pathlib2"
    assert mod.new == "pathlib"
    mod = MovedModule("pathlib", "pathlib2", "pathlib3")
    assert mod.name == "pathlib"
    assert mod.old == "pathlib2"

# Generated at 2022-06-21 18:01:47.748431
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'

# Generated at 2022-06-21 18:01:59.186613
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:02:01.395023
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-21 18:02:03.348314
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old")
    a = MovedModule("name", "old", "new")

# Generated at 2022-06-21 18:02:32.905983
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    import pytree
    import astroid
    from astroid import MANAGER
    from python_ta.transforms.type_inference_visitor import TypeInferenceVisitor
    from python_ta.transforms.type_annotate import TypeAnnotateVisitor
    if sys.version_info >= (3, 0):
        from six.moves.collection_abc import (
            Iterable, Iterator, Collection, Mapping)
    else:
        from collections import (
            Iterable, Iterator, Collection, Mapping)

    import_from_node = astroid.extract_node("""
    from six.moves.collections_abc import Iterable, Iterator, Collection, Mapping""")

    name_node = import_from_node.names[0][0]
    six_module_

# Generated at 2022-06-21 18:02:38.943549
# Unit test for constructor of class MovedModule
def test_MovedModule():
  is_equal = True
  for prefix, moves in prefixed_moves:
    for move in moves:
      if isinstance(move, MovedModule):
        is_equal = is_equal and ((move.new == move.name) or (move.new == '{}.{}'.format(prefix, move.name)))
  assert is_equal

# Generated at 2022-06-21 18:02:42.692470
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('mod1', 'old1', 'new1')
    assert mm.name == 'mod1'
    assert mm.old == 'old1'
    assert mm.new == 'new1'

# Generated at 2022-06-21 18:02:45.949560
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-21 18:02:57.818794
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = SixMovesTransformer._get_rewrites()
    assert ('__builtin__.StringIO', 'six.moves.cStringIO') in rewrites
    assert ('__builtin__.StringIO', 'six.moves.cStringIO') in rewrites
    assert ('__builtin__.intern', 'six.moves.intern') in rewrites
    assert ('__builtin__.file', 'six.moves.StringIO') in rewrites
    assert ('__builtin__.open', 'six.moves.builtins.open') in rewrites
    assert ('__builtin__.raw_input', 'six.moves.builtins.input') in rewrites
    assert ('__builtin__.reduce', 'six.moves.reduce') in rewrites

# Generated at 2022-06-21 18:03:00.467486
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule("name", "old", "new")
    assert movedModule.name == "name"
    assert movedModule.old == "old"
    assert movedModule.new == "new"

# Generated at 2022-06-21 18:03:07.023849
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    original = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert (original.name == "cStringIO" and
            original.old_mod == "cStringIO" and
            original.new_mod == "io" and
            original.old_attr == "StringIO" and
            original.new_attr == "StringIO")

# Generated at 2022-06-21 18:03:10.761895
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'

    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'name'

# Generated at 2022-06-21 18:03:12.747517
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert not s.do_process_imports
    assert not s.do_remove_imports

# Generated at 2022-06-21 18:03:16.083194
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    assert six.MovedModule('x', 'y')
    assert six.MovedModule('x', 'y', 'z')
    assert six.MovedModule('x', 'y', new = 'z')
    assert six.MovedModule('x', old='y', new='z')
    assert six.MovedModule('x', old='y')

# Generated at 2022-06-21 18:04:05.207288
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_test = MovedModule("test1", "test2", "test3")
    assert moved_module_test.name=="test1"
    assert moved_module_test.old=="test2"
    assert moved_module_test.new=="test3"

# Generated at 2022-06-21 18:04:10.742621
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c').__dict__ == {
        'name': 'a', 'old_mod': 'b', 'new_mod': 'c', 'old_attr': None, 'new_attr': 'a'}
    assert MovedAttribute('a', 'b', 'c', 'd').__dict__ == {
        'name': 'a', 'old_mod': 'b', 'new_mod': 'c', 'old_attr': 'd', 'new_attr': 'd'}
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').__dict__ == {
        'name': 'a', 'old_mod': 'b', 'new_mod': 'c', 'old_attr': 'd', 'new_attr': 'e'}


# Generated at 2022-06-21 18:04:16.614417
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("http_cookiejar", "cookielib", "http.cookiejar")
    assert moved_attribute.name == "http_cookiejar"
    assert moved_attribute.new_mod == "http.cookiejar"
    assert moved_attribute.new_attr == "http_cookiejar"


# Generated at 2022-06-21 18:04:21.923819
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c = MovedAttribute("cStringIO", "cStringIO", "io", "String", "StringIO")
    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    c = MovedAttribute("cStringIO", "cStringIO", "io")
    c = MovedAttribute("cStringIO", "cStringIO", None)

# Generated at 2022-06-21 18:04:26.502811
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # GIVEN
    move = MovedModule("tokenize", "tokenize")
    # WHEN
    # THEN
    assert move.name == "tokenize"
    assert move.new == "tokenize"
    # WHEN
    move = MovedModule("tokenize", "tokenize", "token")
    # THEN
    assert move.name == "tokenize"
    assert move.new == "token"


# Generated at 2022-06-21 18:04:36.967478
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test constructor of class SixMovesTransformer
    transformer = SixMovesTransformer()

    # Test inherited functions
    assert transformer.get_module_name() == 'six.moves'
    assert transformer.add_module_insertion() == 'import six.moves'
    assert transformer.add_future_import() == ''
    assert transformer.add_import_insertion() == ''
    assert transformer.is_already_imported() == False
    assert transformer.is_module_already_imported() == False
    assert transformer.is_future_module_already_imported() == False

# Test functions of class SixMovesTransformer

# Generated at 2022-06-21 18:04:38.576706
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass



# Generated at 2022-06-21 18:04:42.664151
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_mod = MovedModule('string', 'libstring')
    assert moved_mod.name == 'string'
    assert moved_mod.new == 'string'



# Generated at 2022-06-21 18:04:47.015462
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar', 'baz')
    assert MovedModule('foo', 'bar', 'bar')
    assert MovedModule('foo', 'bar', 'baz')
    assert MovedModule('foo', 'bar')



# Generated at 2022-06-21 18:04:54.114389
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sys.modules['six'] = __import__('six')
    sys.modules['moves'] = __import__('six.moves')
    importlib.invalidate_caches()
    instance = SixMovesTransformer()

# Generated at 2022-06-21 18:06:49.368805
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, type)
    assert not SixMovesTransformer.__dict__['__package__']
    assert SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert SixMovesTransformer.__doc__ == __doc__
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.dependencies == ['six']
    assert len(SixMovesTransformer.rewrites) == 90

# Generated at 2022-06-21 18:06:52.913880
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-21 18:06:55.458625
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("tkinter", "Tkinter")
    assert moved_module.name == "tkinter"
    assert moved_module.old == "Tkinter"
    assert moved_module.new == "tkinter"


# Generated at 2022-06-21 18:07:05.660558
# Unit test for constructor of class SixMovesTransformer