

# Generated at 2022-06-21 17:57:09.820836
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("bar", "foo").name == "bar"
    assert MovedAttribute("bar", "foo").new_mod == "foo"
    assert MovedAttribute("bar", "foo").new_attr == "bar"


# See https://bitbucket.org/brettcannon/six/src/tip/tests/test_six.py
# for tests of the code copied from six.

# Generated at 2022-06-21 17:57:17.092221
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("getoutput", "commands", "subprocess")
    assert move.name == "getoutput"
    assert move.new_mod == "subprocess"
    assert move.new_attr == "getoutput"

    move = MovedAttribute("getoutput", "commands", "subprocess", "no", "yes")
    assert move.new_attr == "yes"


# Generated at 2022-06-21 17:57:29.766845
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert not MovedAttribute(
        "cStringIO", "cStringIO", "io", "StringIO").new_attr == "cStringIO"
    assert MovedAttribute(
        "cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute(
        "cStringIO", "cStringIO", "io", old_attr="StringIO").new_attr == "StringIO"
    assert MovedAttribute(
        "cStringIO", "cStringIO", "io", new_attr="StringIO").new_attr == "StringIO"
    assert MovedAttribute(
        "cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="StringIO").new_attr == "StringIO"

# Generated at 2022-06-21 17:57:30.882863
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()

# Generated at 2022-06-21 17:57:35.433736
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('foo', 'bar')
    assert m.new == 'foo' and m.name == 'bar'
    m = MovedModule('foo', 'bar', 'baz')
    assert m.new == 'foo' and m.name == 'baz'


# Generated at 2022-06-21 17:57:39.704468
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # type: () -> None
    moved = MovedModule("name", "old")
    assert moved.name == "name"
    assert moved.new == "name"

    moved = MovedModule("name", "old", "new")
    assert moved.name == "name"
    assert moved.new == "new"


# Generated at 2022-06-21 17:57:41.308939
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 17:57:46.434606
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # pylint: disable=W0612
    """Test `SixMovesTransformer`.

    Note:
        This function is used as a unit test for the `SixMovesTransformer` class.
        `SixMovesTransformer` is the constructor for the `SixMovesTransformer`
        class.
    """
    assert True

# Generated at 2022-06-21 17:57:48.508252
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("abc", "abc")
    # remove newline for precision in error string
    assert str(a) == repr(a)



# Generated at 2022-06-21 17:57:51.535374
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"

# Generated at 2022-06-21 17:57:56.552696
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    rewrites = transformer.rewrites
    assert('range.range' in rewrites)
    assert('range.xrange' in rewrites)

# Generated at 2022-06-21 17:58:05.032285
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod',
                          'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod').new_mod == 'name'


# Generated at 2022-06-21 17:58:15.862417
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # In `six`, the element MovedModule("builtins", "__builtin__")
    # will be initialized as
    #   MovedModule("builtins", "__builtin__", "builtins")
    # It is not what we want, because we want to get the correct
    # original module name. Thus we write a test case.
    result = MovedModule("tkinter_tix", "Tix", "Tix")
    print(result)
    assert result.name == "tkinter_tix"
    assert result.new == "Tix"
    assert result.old == "Tix"


# Generated at 2022-06-21 17:58:20.081337
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mov = MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server")
    assert mov.name == "CGIHTTPServer"
    assert mov.new == "http.server"

# Generated at 2022-06-21 17:58:23.852198
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("queue", "Queue")
    assert moved_module.name == 'queue'
    assert moved_module.new == 'queue'
    assert moved_module.old == 'Queue'



# Generated at 2022-06-21 17:58:27.489950
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod")
    assert attr.name == 'name'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'name'

# Generated at 2022-06-21 17:58:40.339688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("cStringIO", "cStringIO", None).name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", None).new_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", None).new_attr == "cStringIO"

    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert M

# Generated at 2022-06-21 17:58:48.707179
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("a", "A", "B") == MovedAttribute("a", "A", "B", "a", "a")
    assert MovedAttribute("a", "A", "B", "b") == MovedAttribute("a", "A", "B", "b", "b")
    assert MovedAttribute("a", "A", "B", None, "c") == MovedAttribute("a", "A", "B", None, "c")
    assert MovedAttribute("a", "A", "B", "b", "c") == MovedAttribute("a", "A", "B", "b", "c")
    x = MovedAttribute("a", "A", "B", "c", "d")
    assert x.name == "a"
    assert x.new_mod == "B"
    assert x.new_

# Generated at 2022-06-21 17:58:55.415885
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert movedattribute.name == "cStringIO"
    assert movedattribute.new_mod == "cStringIO"
    assert movedattribute.new_attr == None
    movedattribute = MovedAttribute("input", "__builtin__", "builtins")
    assert movedattribute.new_mod == "builtins"
    assert movedattribute.new_attr == None


# Generated at 2022-06-21 17:59:07.615364
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:15.631368
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__', new='builtins').new == 'builtins'
    assert MovedModule('builtins', '__builtin__', new=None).new == 'builtins'

# Generated at 2022-06-21 17:59:18.718662
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_mod = MovedModule("tkinter", "Tkinter")
    assert(move_mod.name == "tkinter")
    assert(move_mod.new == move_mod.name)
    assert(move_mod.old == "Tkinter")

# Generated at 2022-06-21 17:59:24.568301
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == {'name': 'cStringIO', 'new_mod': 'io', 'new_attr': 'StringIO'}


# Generated at 2022-06-21 17:59:29.521163
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('cStringIO','cStringIO','io', 'StringIO')
    assert moved_attribute.name == 'cStringIO'
    assert moved_attribute.new_mod == 'io'
    assert moved_attribute.new_attr == 'StringIO'


# Generated at 2022-06-21 17:59:34.392787
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # code: MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    attribute = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert attribute.name == 'cStringIO'
    assert attribute.new_mod == 'io'
    assert attribute.new_attr == 'StringIO'


# Generated at 2022-06-21 17:59:35.647080
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # coverage: ignore
    SixMovesTransformer()

# Generated at 2022-06-21 17:59:45.850504
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    s = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert s.name == 'cStringIO'
    assert s.new_mod == 'io'
    assert s.new_attr == 'StringIO'
    s = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="strIO")
    assert s.name == 'cStringIO'
    assert s.new_mod == 'io'
    assert s.new_attr == 'strIO'
    s = MovedAttribute("cStringIO", "cStringIO", "io")
    assert s.name == 'cStringIO'
    assert s.new_mod == 'io'
    assert s.new_attr == 'cStringIO'

# Generated at 2022-06-21 17:59:54.439936
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "cStringIO"
    old_mod = "cStringIO"
    new_mod = "io"
    old_attr = "StringIO"
    new_attr = "StringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")

    assert m.name == name
    assert m.old_mod == old_mod
    assert m.new_mod == new_mod
    assert m.old_attr == old_attr
    assert m.new_attr == new_attr

# Generated at 2022-06-21 18:00:06.406702
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("name", "oldmod", "newmod")
    assert m.name == "name"
    assert m.new_mod == "newmod"
    assert m.new_attr == "name"

    m = MovedAttribute("name2", "oldmod2", "newmod2", "oldattr", "newattr")
    assert m.name == "name2"
    assert m.new_mod == "newmod2"
    assert m.new_attr == "newattr"
    m = MovedAttribute("name3", "oldmod2", "newmod2", "oldattr")
    assert m.name == "name3"
    assert m.new_mod == "newmod2"
    assert m.new_attr == "oldattr"


# Generated at 2022-06-21 18:00:18.082286
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test empty constructor, no arguments
    assert MovedModule(name='foo', old='bar') == MovedModule(name='foo', old='bar')
    # Test second argument (new module) is optional
    assert MovedModule(name='foo', old='bar') == MovedModule(name='foo', old='bar', new='bar')
    # Test wrong number of arguments
    with pytest.raises(TypeError):
        MovedModule()  # type: ignore
    with pytest.raises(TypeError):
        MovedModule(name='foo', old='bar', new='baz', extra='meh')  # type: ignore
    # Test non-string arguments
    with pytest.raises(TypeError):
        MovedModule(name=1, old='bar', new='baz')  # type: ignore

# Generated at 2022-06-21 18:00:23.123212
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:00:31.366902
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test if MovedModule works as expected
    moved_module_instance = MovedModule("name", "old", "new")
    assert moved_module_instance.name == "name"
    assert moved_module_instance.new == "new"

    # Test if MovedModule works if only the name is provided
    moved_module_instance = MovedModule("name", "name")
    assert moved_module_instance.name == "name"
    assert moved_module_instance.new == "name"

    # Test if MovedModule works if only the name is provided
    moved_module_instance = MovedModule("name", "old")
    assert moved_module_instance.name == "name"
    assert moved_module_instance.new == "name"

# Generated at 2022-06-21 18:00:40.454123
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('name', 'old_mod', 'new_mod')
    assert a.name == 'name'
    assert a.new_mod == 'new_mod'
    assert a.new_attr == 'name'
    a = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert a.name == 'name'
    assert a.new_mod == 'new_mod'
    assert a.new_attr == 'new_attr'

# Generated at 2022-06-21 18:00:42.983239
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("a", "b", "c")
    assert ma.name == "a"
    assert ma.new_mod == "c"
    assert ma.new_attr == "a"



# Generated at 2022-06-21 18:00:46.149222
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("queue", "Queue")
    assert mm.name == "queue"
    assert mm.new == "queue"
    mm = MovedModule("queue", "Queue", "newQueue")
    assert mm.name == "queue"
    assert mm.new == "newQueue"

# Generated at 2022-06-21 18:00:55.240756
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:56.433003
# Unit test for constructor of class MovedModule
def test_MovedModule():
    s = MovedModule('name', 'old')
    assert s.name == 'name'
    assert s.new == 'name'



# Generated at 2022-06-21 18:00:57.463033
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test the constructor of class SixMovesTransformer
    SixMovesTransformer()

# Generated at 2022-06-21 18:00:59.006785
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert sorted(SixMovesTransformer().rewrites) == sorted(rewrite for rewrite, target in _get_rewrites())

# Generated at 2022-06-21 18:01:05.341170
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # type: () -> None
    assert MovedModule('_thread', 'thread', '_thread').name == '_thread'
    assert MovedModule('_thread', 'thread', '_thread').new == '_thread'
    assert MovedModule('some_weird_name', 'some_weird_former_name').name == 'some_weird_name'
    assert MovedModule('some_weird_name', 'some_weird_former_name').new == 'some_weird_name'


# Generated at 2022-06-21 18:01:14.797120
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "StringIO"

# Generated at 2022-06-21 18:01:27.457793
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    assert not hasattr(sys, 'moves')
    SixMovesTransformer()
    assert hasattr(sys, 'moves')
    assert hasattr(sys.moves, 'builtins')
    assert hasattr(sys.moves, 'cPickle')
    assert hasattr(sys.moves, 'urllib')
    assert hasattr(sys.moves, 'urllib')
    assert hasattr(sys.moves, 'urllib.parse')
    assert hasattr(sys.moves, 'urllib.request')
    assert hasattr(sys.moves, 'urllib.response')
    assert hasattr(sys.moves, 'urllib.robotparser')
    assert hasattr(sys.moves, 'urllib.error')

# Generated at 2022-06-21 18:01:38.003484
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_move_attribute_1 = MovedAttribute(name="filter", old_mod="itertools", new_mod="builtins",
                                           old_attr="ifilter", new_attr="filter")
    test_move_attribute_2 = MovedAttribute(name="filterfalse", old_mod="itertools", new_mod="itertools",
                                           old_attr="ifilterfalse", new_attr="filterfalse")
    test_move_attribute_3 = MovedAttribute(name="input", old_mod="__builtin__", new_mod="builtins",
                                           old_attr="raw_input", new_attr="input")
    test_move_attribute_4 = MovedAttribute(name="intern", old_mod="__builtin__", new_mod="sys")
    test_move_attribute_5

# Generated at 2022-06-21 18:01:38.719517
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()
    assert x.dependencies == ['six']

# Generated at 2022-06-21 18:01:42.630083
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('foo', 'foo')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'foo'

    moved_module = MovedModule('foo', 'foo', 'bar')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'bar'


# Unit tests for the constructor of the class MovedAttribute

# Generated at 2022-06-21 18:01:45.473547
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    passes = SixMovesTransformer()
    for _, _ in passes.rewrites:
        pass
    assert True

# Generated at 2022-06-21 18:01:56.384254
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.target == (2, 7)
    assert isinstance(st.rewrites, list)

# Generated at 2022-06-21 18:02:01.344271
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mytest = MovedAttribute('name','old','new','old_attr','new_attr')
    mytest = MovedAttribute('name','old','new','old_attr')
    mytest = MovedAttribute('name','old','new')

# Generated at 2022-06-21 18:02:02.875926
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None)



# Generated at 2022-06-21 18:02:08.542818
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule('queue', 'Queue')
    assert movedmodule.name == 'queue'
    assert movedmodule.new == 'queue'

    movedmodule = MovedModule('queue', 'Queue', 'collections')
    assert movedmodule.name == 'queue'
    assert movedmodule.new == 'collections'


# Generated at 2022-06-21 18:02:22.550479
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites()) == []

# Generated at 2022-06-21 18:02:26.758220
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'name'

# Generated at 2022-06-21 18:02:33.174614
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:02:35.947068
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('new', 'old') == MovedModule('new', 'old')

# Generated at 2022-06-21 18:02:37.845975
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute
    MovedModule
    assert len(_moved_attributes) == len(_get_rewrites())

# Generated at 2022-06-21 18:02:47.734834
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute("X", "from_mod", "to_mod")
    assert attribute.name == "X"
    assert attribute.new_mod == "to_mod"
    assert attribute.new_attr == "X"

    attribute = MovedAttribute("X", "from_mod", "to_mod", "from_attr")
    assert attribute.name == "X"
    assert attribute.new_mod == "to_mod"
    assert attribute.new_attr == "from_attr"

    attribute = MovedAttribute("X", "from_mod", "to_mod", "from_attr", "to_attr")
    assert attribute.name == "X"
    assert attribute.new_mod == "to_mod"
    assert attribute.new_attr == "to_attr"


# Generated at 2022-06-21 18:02:57.504589
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Should be valid
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    # Should be valid
    MovedAttribute("cStringIO", "cStringIO", "io")
    # Should not be valid
    try:
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
        assert False, "Should not have succeeded"
    except TypeError:
        pass
    # Should not be valid
    try:
        MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO")
        assert False, "Should not have succeeded"
    except TypeError:
        pass



# Generated at 2022-06-21 18:02:58.439358
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('a', 'b', 'c')

# Generated at 2022-06-21 18:03:04.762364
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("abc", "def")
    assert mm.name == "abc"
    assert mm.old == "def"
    assert mm.new == "abc"
    mm = MovedModule("abc", "def", "ghi")
    assert mm.name == "abc"
    assert mm.old == "def"
    assert mm.new == "ghi"


# Generated at 2022-06-21 18:03:11.531587
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_config = {'six': (1, 11, 0)}
    t = SixMovesTransformer(config=test_config)
    assert t.config == test_config
    assert t.dependencies == ['six']
    assert t.target == (2, 7)
    assert len(t.rewrites) == len(_get_rewrites())
    for i in range(len(t.rewrites)):
        assert t.rewrites[i] == _get_rewrites()[i]



# Generated at 2022-06-21 18:03:41.344373
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_name = "builtins"
    old_location = "__builtin__"
    new_location = "builtins"
    module = MovedModule(module_name, old_location, new_location)
    assert module.name == module_name
    assert module.new == new_location

# Generated at 2022-06-21 18:03:45.387346
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name='tkinter', old='Tkinter', new='tkinter')
    assert moved_module.name == 'tkinter'
    assert moved_module.old == 'Tkinter'
    assert moved_module.new == 'tkinter'



# Generated at 2022-06-21 18:03:55.671038
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_sixmoves import test_sixmoves
    from .utils import test_utils
    from .test_helpers import test_helpers
    import unittest
    import lib2to3.refactor

    class TestSixMovesTransformer(unittest.TestCase):
        def test_constructor(self):
            """Ensure that the constructor works correctly."""
            pass

    suite = unittest.TestSuite([unittest.makeSuite(TestSixMovesTransformer, 'test')])
    runner = unittest.TextTestRunner()
    result = runner.run(suite)

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-21 18:04:05.581176
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:04:13.040406
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    '''
    def __init__(self, target=(3, 0)):
        super(SixMovesTransformer, self).__init__()

        self.target = target
        self.rewrites = self._get_rewrites()
    '''
    # Same as:
    # SixMovesTransformer()
    transformer = SixMovesTransformer(target=(2, 7))

    return transformer


# Generated at 2022-06-21 18:04:17.756711
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('mod', 'old').name == 'mod'
    assert MovedModule('mod', 'old').new == 'old'
    assert MovedModule('mod', 'old', 'new').new == 'new'
    assert MovedModule('mod', 'old', 'new').name == 'mod'

# Generated at 2022-06-21 18:04:20.784736
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"


# Generated at 2022-06-21 18:04:29.036782
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:04:31.202318
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = list(_get_rewrites())
    assert len(rewrites) == 81


six_moves_transformer = SixMovesTransformer()

# Generated at 2022-06-21 18:04:34.994241
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"

# Generated at 2022-06-21 18:05:38.973653
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule("name1","old1","new1")
    mm2 = MovedModule("name2","old2")
    assert mm1.name == "name1"
    assert mm1.new == "new1"
    assert mm2.name == "name2"
    assert mm2.new == "name2"

# Generated at 2022-06-21 18:05:42.735161
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins","__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "__builtin__"


# Generated at 2022-06-21 18:05:45.807831
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer({1: 'six'})
    # TODO: Test with node_factory
    assert t.nf is None
    assert t.dependencies == ['six']

# Generated at 2022-06-21 18:05:58.043445
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("hello", "hello")
    assert moved_module.name == "hello"
    assert moved_module.new == "hello"
    assert moved_module.old is None

    moved_module = MovedModule("hello", "hello", "bye")
    assert moved_module.name == "hello"
    assert moved_module.new == "bye"
    assert moved_module.old is None

    moved_module = MovedModule("hello", "bye")
    assert moved_module.name == "hello"
    assert moved_module.new == "hello"
    assert moved_module.old == "bye"

    moved_module = MovedModule("hello", "bye", "hello")
    assert moved_module.name == "hello"
    assert moved_module.new == "hello"
    assert moved_module

# Generated at 2022-06-21 18:06:00.838891
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("foo", "bar")
    assert m.name == "foo"
    assert m.new_mod == "foo"
    assert m.new_attr == "foo"

# Generated at 2022-06-21 18:06:13.113332
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 18:06:21.717363
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("Str", "abc", "efg", "XYZ", "PQR")
    assert m.name == "Str"
    assert m.new_mod == "efg"
    assert m.new_attr == "PQR"
    m = MovedAttribute("Str", "abc", "efg")
    assert m.new_attr == "Str"
    m = MovedAttribute("Str", "abc", "efg", "XYZ")
    assert m.new_attr == "XYZ"


# Generated at 2022-06-21 18:06:25.948504
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(MovedModule("os", "os").__dict__ == {"name": "os", "old": "os", "new": "os"})
    assert(MovedModule("os", "os", "os2").__dict__ == {"name": "os", "old": "os", "new": "os2"})


# Generated at 2022-06-21 18:06:27.033150
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 18:06:34.183323
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("foo", "bar", "baz")
    assert mod.name == "foo"
    assert mod.old == "bar"
    assert mod.new == "baz"
    mod = MovedModule("foo", "bar")
    assert mod.name == "foo"
    assert mod.old == "bar"
    assert mod.new == "foo"
