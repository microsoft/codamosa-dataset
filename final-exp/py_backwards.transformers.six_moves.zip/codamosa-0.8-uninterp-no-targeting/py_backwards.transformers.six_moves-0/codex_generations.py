

# Generated at 2022-06-21 17:57:05.842739
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    sixMovedAttribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert sixMovedAttribute.name == "cStringIO"
    assert sixMovedAttribute.new_mod == "io"
    assert sixMovedAttribute.new_attr == "StringIO"

# Generated at 2022-06-21 17:57:18.073465
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 17:57:22.435977
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-21 17:57:27.720872
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-21 17:57:38.555278
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None).dependencies == ['six']
    assert len(SixMovesTransformer(None).rewrites) == 98
    assert (SixMovesTransformer(None).rewrites[0][0] ==
            ".urllib.request.CacheFTPHandler")
    assert (SixMovesTransformer(None).rewrites[0][1] ==
            "six.moves.urllib_request.CacheFTPHandler")
    assert (SixMovesTransformer(None).rewrites[1][0] ==
            "urllib.robotparser.RobotFileParser")
    assert (SixMovesTransformer(None).rewrites[1][1] ==
            "six.moves.urllib_robotparser.RobotFileParser")

# Generated at 2022-06-21 17:57:44.116451
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'b'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'



# Generated at 2022-06-21 17:57:55.488222
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)

# Generated at 2022-06-21 17:57:59.615074
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.shlex_quote' in SixMovesTransformer.rewrites
    assert 'six.moves.urllib.error.URLError' in SixMovesTransformer.rewrites
    assert 'six.moves.urllib.response.addbase' in SixMovesTransformer.rewrites

# Generated at 2022-06-21 17:58:01.920863
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.target == (2, 7)
    assert len(st.rewrites) > 0
    assert st.dependencies == ['six']

# Generated at 2022-06-21 17:58:14.963323
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Tests rewrites, transformations and dependencies of SixMovesTransformer
    """

# Generated at 2022-06-21 17:58:28.330661
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test the general constructor for MovedModule
    assert MovedModule('copyreg', 'copy_reg').name == 'copyreg'
    assert MovedModule('copyreg', 'copy_reg').new == 'copyreg'
    assert MovedModule('winreg', '_winreg').name == 'winreg'

    # Test the constructor for MovedModule with specific parameter new
    assert MovedModule('copyreg', 'copy_reg', 'copy').name == 'copyreg'
    assert MovedModule('copyreg', 'copy_reg', 'copy').new == 'copy'

    # Test the constructor for MovedModule with new parameter
    assert MovedModule('copyreg', 'copy_reg', new='copy').name == 'copyreg'
    assert MovedModule('copyreg', 'copy_reg', new='copy').new == 'copy'

# Generated at 2022-06-21 17:58:31.386271
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites() == list(SixMovesTransformer.rewrites)

# Generated at 2022-06-21 17:58:34.768510
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule('name', 'old', 'new')
    assert movedmodule.name == 'name'
    assert movedmodule.old == 'old'
    assert movedmodule.new == 'new'


# Generated at 2022-06-21 17:58:38.695213
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("__builtin__", "__builtin__").name == "__builtin__"
    assert MovedModule("basehttp", "BaseHTTPServer", "http.server").name == "basehttp"
    assert MovedModule("basehttp", "BaseHTTPServer", "http.server").new == "http.server"
    pass

# Generated at 2022-06-21 17:58:47.236030
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("I", "I", "I")
    assert ma.name == "I"
    assert ma.new_mod == "I"
    assert ma.new_attr == "I"
    ma = MovedAttribute("I", "I", "I", "I", "I")
    assert ma.name == "I"
    assert ma.new_mod == "I"
    assert ma.new_attr == "I"
    ma = MovedAttribute("I", "I", "I", "We", "We")
    assert ma.name == "I"
    assert ma.new_mod == "I"
    assert ma.new_attr == "We"
    ma = MovedAttribute("I", "I", "I", "We")
    assert ma.name == "I"

# Generated at 2022-06-21 17:58:58.820040
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    if sys.version_info < (3, 3):
        # https://github.com/modernistik/python-modernize/issues/112
        # SixMovesTransformer.rewrites is the only class variable that cannot
        # be processed by the test function (test_collections_2_function_set)
        assert "six" in SixMovesTransformer.dependencies
        assert len(SixMovesTransformer.rewrites) == 124
        assert SixMovesTransformer.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO.StringIO')
        assert SixMovesTransformer.rewrites[123] == ('urllib.robotparser.RobotFileParser', 'six.moves.urllib.robotparser.RobotFileParser')

# Generated at 2022-06-21 17:59:10.895507
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:59:20.690387
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import ast
    import logging

    logging.basicConfig(level=logging.DEBUG)

    t = SixMovesTransformer(sys.version_info, debug=True)
    t.rewrites = [('re', 're'),
                  ('collections', 'collections'),
                  ('shlex', 'shlex'),
                  ('moves.urllib_parse', 'urllib.parse'),
                  ('moves.urllib_error', 'urllib.error'),
                  ('moves.urllib_request', 'urllib.request'),
                  ('moves.urllib_response', 'urllib.response'),
                  ('moves.urllib_robotparser', 'urllib.robotparser')]

# Generated at 2022-06-21 17:59:23.162934
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites
    assert transformer.dependencies

# Generated at 2022-06-21 17:59:28.138819
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("test", "old.mod", "new.mod", "old.attr", "new.attr")
    assert move.name == "test"
    assert move.new_mod == "new.mod"
    assert move.new_attr == "new.attr"

# Generated at 2022-06-21 17:59:35.931620
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test __init__()
    s = SixMovesTransformer()
    assert s.dependencies == ['six']
    assert s.rewrites == _get_rewrites()
    assert s.target == (2, 7)


# Unit tests for the real SixMovesTransformer methods

# Generated at 2022-06-21 17:59:46.272743
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('foo', 'old', 'new')
    assert a.name == 'foo'
    assert a.new_mod == 'new'
    assert a.new_attr == 'foo'
    a = MovedAttribute('foo', 'old', 'new', 'old_attr', 'new_attr')
    assert a.name == 'foo'
    assert a.new_mod == 'new'
    assert a.new_attr == 'new_attr'
    a = MovedAttribute('foo', 'old', 'new', 'old_attr')
    assert a.name == 'foo'
    assert a.new_mod == 'new'
    assert a.new_attr == 'old_attr'
    a = MovedAttribute('foo', 'old', 'new', new_attr='new_attr')

# Generated at 2022-06-21 17:59:53.593596
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # without prefix
    check_transform('from six.moves.cStringIO import StringIO',
                    'from cStringIO import StringIO')

    # with prefix
    check_transform('from six.moves.urllib.parse import urlparse',
                    'from urlparse import urlparse')

    # not a six moved module, check it doesn't apply
    check_transform('from urlparse import urlparse',
                    'from urlparse import urlparse')

# Generated at 2022-06-21 18:00:01.888679
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule("name", "old", "new")
    assert m1.name == "name"
    assert m1.new == "new"
    assert isinstance(m1, MovedModule)

    m2 = MovedModule("name", "old")
    assert m2.name == "name"
    assert m2.new == "name"
    assert isinstance(m2, MovedModule)



# Generated at 2022-06-21 18:00:06.736744
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").new == "new"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:00:11.655522
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    assert issubclass(SixMovesTransformer, BaseImportRewrite)
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.rewrites
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-21 18:00:13.345356
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.old == "old"
    assert a.new == "new"



# Generated at 2022-06-21 18:00:23.547362
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:26.671161
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import rewrites_imports_test
    obj = SixMovesTransformer()
    assert isinstance(obj, rewrites_imports_test.RewriteImportsHelpers)


# Generated at 2022-06-21 18:00:30.235342
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("xrange", "__builtin__", "builtins", "xrange", "range")
    assert moved_attribute.name == "xrange"
    assert moved_attribute.new_mod == "builtins"
    assert moved_attribute.new_attr == "range"


# Generated at 2022-06-21 18:00:46.890964
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.filter' == SixMovesTransformer.rewrites['builtins.filter']
    assert 'six.moves.urllib_parse.parse_qs' == SixMovesTransformer.rewrites['urllib.parse.parse_qs']
    assert 'six.moves.urllib_error.URLError' == SixMovesTransformer.rewrites['urllib.error.URLError']
    assert 'six.moves.urllib_request.urlopen' == SixMovesTransformer.rewrites['urllib.request.urlopen']
    assert 'six.moves.urllib_response.addbase' == SixMovesTransformer.rewrites['urllib.response.addbase']

# Generated at 2022-06-21 18:00:50.074909
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("mod", "old", "new")
    assert module.name == "mod"
    assert module.old == "old"
    assert module.new == "new"

# Generated at 2022-06-21 18:00:58.007692
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert isinstance(t, BaseImportRewrite)
    assert t.target == (2, 7)
    assert len(t.dependencies) == 1
    assert t.dependencies == ['six']
    assert len(t.rewrites) == 102

# Generated at 2022-06-21 18:01:01.256365
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert a.name == "name"
    assert a.new_mod == "new_mod"
    assert a.new_attr == "new_attr"

# Generated at 2022-06-21 18:01:02.674864
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer(None, None)
    assert st.dependencies == ['six']

# Generated at 2022-06-21 18:01:07.823390
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name=="cStringIO"
    assert move.new_mod=="io"
    assert move.new_attr=="StringIO"


# Unit tests for SixMovesTransformer

# Generated at 2022-06-21 18:01:14.566626
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("builtins", "__builtin__")
    assert mm.name == 'builtins'
    assert mm.new == 'builtins'
    assert mm.old is None

    mm = MovedModule("configparser", "ConfigParser")
    assert mm.name == 'configparser'
    assert mm.new == 'configparser'
    assert mm.old == 'ConfigParser'

# Generated at 2022-06-21 18:01:19.691115
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "cStringIO"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-21 18:01:29.504500
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # special case: no old attr name
    moved = MovedAttribute("name", "old_mod", "new_mod")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == "name"
    # normal case: old and new attr names given
    moved = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == "new_attr"

# Generated at 2022-06-21 18:01:39.358318
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'bar', 'baz').name == 'foo'
    assert MovedAttribute(name='foo', old_mod='bar', new_mod='baz').name == 'foo'
    assert MovedAttribute('foo', 'bar', 'baz').new_mod == 'baz'
    assert MovedAttribute('foo', 'bar').new_mod == 'foo'
    assert MovedAttribute('foo', 'bar', 'baz', 'frob').new_attr == 'frob'
    assert MovedAttribute('foo', 'bar', 'baz').new_attr == 'foo'
    assert MovedAttribute('foo', 'bar', 'baz', 'frob').new_attr == 'frob'

# Generated at 2022-06-21 18:01:54.682707
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert not isinstance(MovedModule("abc", "abc"), MovedModule)
    assert isinstance(MovedModule("abc", "abc", "xyz"), MovedModule)
    assert not isinstance(MovedModule("abc", "abc", "xyz"), bool)

# Generated at 2022-06-21 18:02:02.103444
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('aa', 'bb', 'cc').name == 'aa'
    assert MovedModule('aa', 'bb', 'cc').old == 'bb'
    assert MovedModule('aa', 'bb', 'cc').new == 'cc'
    assert MovedModule('aa', 'bb').name == 'aa'
    assert MovedModule('aa', 'bb').old == 'bb'
    assert MovedModule('aa', 'bb').new == 'aa'

# Generated at 2022-06-21 18:02:08.237923
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == "cStringIO"
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == "io"
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == "StringIO"

# Generated at 2022-06-21 18:02:15.425312
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("test", "old", "new")
    assert a.name == "test"
    assert a.new_mod == "new"
    assert a.new_attr == "test"
    a = MovedAttribute("test", "old", "new", "old_attr", "new_attr")
    assert a.name == "test"
    assert a.new_mod == "new"
    assert a.new_attr == "new_attr"

# Generated at 2022-06-21 18:02:26.410130
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m1.name == "cStringIO"
    assert m1.new_mod == "cStringIO"
    assert m1.new_attr == "StringIO"
    m2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m2.name == "cStringIO"
    assert m2.new_mod == "io"
    assert m2.new_attr == "cStringIO"
    m3 = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="NewStringIO")
    assert m3.name == "cStringIO"
    assert m3.new_mod == "io"
    assert m3.new_attr == "NewStringIO"


# Generated at 2022-06-21 18:02:33.359916
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b", "c").name == "a"
    assert MovedModule("a", "b", "c").old == "b"
    assert MovedModule("a", "b", "c").new == "c"
    assert MovedModule("a", "b").name == "a"
    assert MovedModule("a", "b").old == "b"
    assert MovedModule("a", "b").new == "a"


# Generated at 2022-06-21 18:02:45.634298
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('builtins', '__builtin__')
    MovedModule('configparser', 'ConfigParser')
    MovedModule('copyreg', 'copy_reg')
    MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    MovedModule('http_cookiejar', 'cookielib', 'http.cookiejar')
    MovedModule('http_cookies', 'Cookie', 'http.cookies')
    MovedModule('html_entities', 'htmlentitydefs', 'html.entities')
    MovedModule('html_parser', 'HTMLParser', 'html.parser')
    MovedModule('http_client', 'httplib', 'http.client')

# Generated at 2022-06-21 18:02:55.410328
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys

    # Check that all the module names are in sys.modules
    for _, module in SixMovesTransformer.rewrites:
        assert module in sys.modules, "Missing module {}".format(module)

    # Check that the 'six.moves' modules actually have the desired
    # attributes.
    for _, module in SixMovesTransformer.rewrites:
        assert hasattr(sys.modules[module], module.split('.')[-1]), "Module {} has no attribute {}".format(module, module.split('.')[-1])

# Generated at 2022-06-21 18:03:03.196840
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

    mm = MovedModule("name")
    assert mm.name == "name"
    assert mm.old == "name"
    assert mm.new == "name"


# Generated at 2022-06-21 18:03:07.614247
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('tkinter_ttk', 'ttk', 'tkinter.ttk').new == 'tkinter.ttk'
    assert MovedModule('tkinter_ttk', 'ttk', 'tkinter.ttk').name == 'tkinter_ttk'


# Generated at 2022-06-21 18:03:34.673840
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # type: () -> None
    instance = SixMovesTransformer()
    assert isinstance(instance, SixMovesTransformer)



# Generated at 2022-06-21 18:03:41.257736
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert test_moved_attribute.name == "name"
    assert test_moved_attribute.new_mod == "new_mod"
    assert test_moved_attribute.new_attr == "new_attr"

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 18:03:46.873059
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("x", "y", "z")
    assert x.name == 'x'
    assert x.new_mod == 'z'
    assert x.new_attr == 'x'

    x = MovedAttribute("x", "y", "z", "a", "b")
    assert x.name == 'x'
    assert x.new_mod == 'z'
    assert x.new_attr == 'b'


# Generated at 2022-06-21 18:03:54.703533
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests for SixMovesTransformer"""
    from lib2to3 import refactor
    refactoring = refactor.RefactoringTool(['-w'], {'print': True})
    from libmodernize.fixes.fix_six_moves import SixMovesTransformer
    fixer = SixMovesTransformer(refactoring)
    assert sorted(fixer.rewrites) == sorted(_get_rewrites())
    # TODO: add a check for fixer.dependencies == ['six']

# Generated at 2022-06-21 18:03:56.951119
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("abc", "xyz", "abc") == MovedModule("abc", "xyz")

# Generated at 2022-06-21 18:04:03.379069
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"

# Generated at 2022-06-21 18:04:15.444188
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case = [MovedModule("builtins", "__builtin__"),
                 MovedModule("configparser","ConfigParser"),
                 MovedModule("copyreg", "copy_reg"),
                 MovedModule("dbm_gnu","gdbm", "dbm.gnu"),
                 MovedModule("_dummy_thread","dummy_thread", "_dummy_thread")]

    assertMovedModule(test_case, "builtins", "__builtin__", "builtins")
    assertMovedModule(test_case, "configparser", "ConfigParser", "configparser")
    assertMovedModule(test_case, "copyreg", "copy_reg", "copyreg")
    assertMovedModule(test_case, "dbm_gnu", "gdbm", "dbm.gnu")

# Generated at 2022-06-21 18:04:18.359050
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.new == 'builtins'
    assert moved_module.name == 'builtins'

# Generated at 2022-06-21 18:04:27.586838
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:04:28.422250
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('winreg', '_winreg')

# Generated at 2022-06-21 18:05:25.394777
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test2 = MovedModule("abc", "abc", "abc")
    assert test2.name == 'abc'
    assert test2.new == 'abc'



# Generated at 2022-06-21 18:05:31.033151
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('test_module', 'test_old', 'test_new')
    assert moved_module.name == 'test_module'
    assert moved_module.new == 'test_new'


# Generated at 2022-06-21 18:05:43.932991
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("input", "__builtin__", "builtins")
    assert moved_attribute.name == "input"
    assert moved_attribute.new_mod == "builtins"
    assert moved_attribute.new_attr == "input"

    moved_attribute = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert moved_attribute.name == "input"
    assert moved_attribute.new_mod == "builtins"
    assert moved_attribute.new_attr == "input"

    moved_attribute = MovedAttribute("input", "__builtin__", "builtins", old_attr="raw_input")
    assert moved_attribute.name == "input"
    assert moved_attribute.new_mod == "builtins"
    assert moved_attribute.new_

# Generated at 2022-06-21 18:05:47.493496
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-21 18:05:51.615885
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert repr(MovedModule("name", "name")) == "MovedModule('name', 'name')"
    assert repr(MovedModule("name", "old", "new")) == "MovedModule('name', 'old', 'new')"


# Generated at 2022-06-21 18:05:53.765881
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule("builtins", "__builtin__"), MovedModule)



# Generated at 2022-06-21 18:06:05.796056
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """
    Check that it is possible to construct a MovedAttribute object
    """
    move = MovedAttribute("foo", "foo", None)
    assert move.name == "foo"
    assert move.new_mod == "foo"
    assert move.new_attr == "foo"

    move = MovedAttribute("foo", "bar", "baz")
    assert move.name == "foo"
    assert move.new_mod == "bar"
    assert move.new_attr == "baz"

    move = MovedAttribute("foo", "bar", "baz", "spam")
    assert move.name == "foo"
    assert move.new_mod == "bar"
    assert move.new_attr == "spam"


# Generated at 2022-06-21 18:06:11.907359
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("queue", "Queue").__dict__ == {'name': "queue", 'old': "Queue", 'new': "queue"}
    assert MovedModule("tkinter", "Tkinter").__dict__ == {'name': "tkinter", 'old': "Tkinter", 'new': "tkinter"}


# Generated at 2022-06-21 18:06:18.154501
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('name', 'old')
    assert x.name == 'name', 'name should be name'
    assert x.new == 'name', 'new should be name'
    x = MovedModule('name', 'old', 'new')
    assert x.name == 'name', 'name should be name'
    assert x.new == 'new', 'new should be new'


# Generated at 2022-06-21 18:06:20.678947
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__') == MovedModule('builtins', '__builtin__')
