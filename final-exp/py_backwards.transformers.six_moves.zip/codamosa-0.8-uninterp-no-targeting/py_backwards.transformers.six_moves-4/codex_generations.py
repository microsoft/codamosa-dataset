

# Generated at 2022-06-21 17:57:10.649839
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute(
        "foo", "bar", "baz").__dict__ == \
        {'name': 'foo', 'new_mod': 'baz', 'new_attr': 'foo'}
    assert MovedAttribute(
        "foo", "bar", "baz", old_attr="foo1").__dict__ == \
        {'name': 'foo', 'new_mod': 'baz', 'new_attr': 'foo1'}
    assert MovedAttribute(
        "foo", "bar", "baz", new_attr="foo1").__dict__ == \
        {'name': 'foo', 'new_mod': 'baz', 'new_attr': 'foo1'}

# Generated at 2022-06-21 17:57:13.530726
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  assert(MovedAttribute('name','old_mod','new_mod').name == 'name')
  assert(MovedAttribute('name','old_mod','new_mod').new_mod == 'new_mod')
  assert(MovedAttribute('name','old_mod','new_mod').new_attr == 'name')

# Generated at 2022-06-21 17:57:14.475265
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert(SixMovesTransformer().rewrites == _get_rewrites())

# Generated at 2022-06-21 17:57:20.354611
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # MovedModule(name, old, new=None)
    mod1 = MovedModule('mod1', 'oldmod', 'newmod')
    mod2 = MovedModule('mod2', 'oldmod')
    assert(mod2.name == 'mod2', mod2.old == 'oldmod', mod2.new == 'mod2')

# Generated at 2022-06-21 17:57:24.776848
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.new == "new"
    b = MovedModule("name", "old")
    assert b.new == "name"


# Generated at 2022-06-21 17:57:26.993774
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("test", "old")
    assert test.name == "test"
    assert test.new == "test"
    test = MovedModule("test", "old", "new")
    assert test.name == "test"
    assert test.new == "new"

# Generated at 2022-06-21 17:57:32.506453
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    # pylint: disable=protected-access
    assert moved_attribute.name == "filterfalse"
    assert moved_attribute.new_mod == "itertools"
    assert moved_attribute.new_attr == "filterfalse"
    assert moved_attribute._old_mod == "itertools"
    assert moved_attribute._old_attr == "ifilterfalse"


# Generated at 2022-06-21 17:57:36.435257
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr",  "new_attr")
    assert m.name == "name"
    assert m.new_mod == "new_mod"
    assert m.new_attr == "new_attr"

# Generated at 2022-06-21 17:57:47.338481
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test the :class:`SixMovesTransformer` class
    """

    code = """
    import os.path
    import sys
    from os.path import relpath
    from configparser import RawConfigParser
    from time import time, monotonic
    from xml.etree.ElementTree import iterparse
    """


# Generated at 2022-06-21 17:57:49.764666
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.new == "new"

# Generated at 2022-06-21 17:58:01.737507
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("argv", "sys", "sys")
    assert m.name == "argv"
    assert m.new_mod == "sys"
    assert m.new_attr == "argv"

    m = MovedAttribute("argv", None, None, old_attr="argv", new_attr="argv")
    assert m.name == "argv"
    assert m.new_mod == "argv"
    assert m.new_attr == "argv"

    m = MovedAttribute("argv", None, None, old_attr="argv")
    assert m.name == "argv"
    assert m.new_mod == "argv"
    assert m.new_attr == "argv"

    m = MovedAttribute("argv", None, None)

# Generated at 2022-06-21 17:58:09.782031
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    # name is necessary
    with pytest.raises(TypeError):
        MovedModule(old='test')
    # all of these should work
    MovedModule('test')
    MovedModule('test', 'old')
    MovedModule('test', 'old', 'new')
    MovedModule('test', new='new')
    MovedModule('test', 'old', 'new')

# Generated at 2022-06-21 17:58:11.908015
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer.rewrites)
    print(dict(SixMovesTransformer.rewrites))

# Generated at 2022-06-21 17:58:16.552420
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "old"
    assert m.old_mod is None
    assert m.new_mod is None
    assert m.old_attr is None
    assert m.new_attr is None



# Generated at 2022-06-21 17:58:20.661732
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

# Generated at 2022-06-21 17:58:24.833382
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sl = SixMovesTransformer()
    assert sl.target == (2, 7)
    assert len(sl.rewrites) == len(_moved_attributes)
    assert len(sl.dependencies) == 1



# Generated at 2022-06-21 17:58:27.593797
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 17:58:31.051330
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import six_moves
    six_moves.SixMovesTransformer()

# Generated at 2022-06-21 17:58:34.434701
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    class SixMovesTransformerTest(SixMovesTransformer):
        """Replaces moved modules with ones from `six.moves`."""
    assert SixMovesTransformerTest.rewrites == _get_rewrites()

# Generated at 2022-06-21 17:58:41.350609
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old", "new").name == "name"
    assert MovedAttribute("name", "old", None).name == "name"
    assert MovedAttribute("name", "old", None).new_mod == "name"
    assert MovedAttribute("name", "old", None).new_attr == "name"
    assert MovedAttribute("name", "old", "new").new_attr == "name"
    assert MovedAttribute("name", "old", None, "old_attr").new_attr == "old_attr"
    assert MovedAttribute("name", "old", None, None, "new_attr").new_attr == "new_attr"

# Generated at 2022-06-21 17:58:46.257436
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('mod', 'old').name == 'mod'
    assert MovedModule('mod', 'old').new == 'old'
    assert MovedModule('mod', 'old', 'new').new == 'new'
    assert MovedModule('mod', 'old', 'new').name == 'mod'


# Generated at 2022-06-21 17:58:50.016676
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module1 = MovedModule("name", "old", "new")
    module2 = MovedModule("name", "old")
    assert module1.name == module2.name
    assert module1.old == module2.old
    assert module1.new == "new"
    assert module2.new == "name"


# Generated at 2022-06-21 17:59:02.566443
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert len(_moved_attributes) == 56
    assert _moved_attributes[0].name == "cStringIO"
    assert _moved_attributes[1].name == 'filter'
    assert _moved_attributes[2].name == 'filterfalse'
    assert _moved_attributes[3].name == 'input'
    assert _moved_attributes[4].name == 'intern'
    assert _moved_attributes[5].name == 'map'
    assert _moved_attributes[6].name == 'getcwd'
    assert _moved_attributes[7].name == 'getcwdb'
    assert _moved_attributes[8].name == 'getstatusoutput'
    assert _moved_attributes[9].name == 'getoutput'
    assert _moved

# Generated at 2022-06-21 17:59:15.004283
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=protected-access
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

    attr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert attr.name == "filter"
    assert attr.new_mod == "builtins"
    assert attr.new_attr == "filter"

    attr = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert attr.name == "input"
    assert attr.new_mod == "builtins"

# Generated at 2022-06-21 17:59:22.662994
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    import six.moves
    rewrites = transformer.rewrites
    assert any(r[1] == 'six.moves' for r in rewrites)
    assert any(r[1] == 'six.moves.urllib_parse' for r in rewrites)
    assert any(r[1] == 'six.moves.urllib_error' for r in rewrites)
    assert any(r[1] == 'six.moves.urllib' for r in rewrites)
    assert any(r[1] == 'six.moves.urllib_parse.urlparse' for r in rewrites)

# Generated at 2022-06-21 17:59:27.301189
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule('fakemodule', 'fakefrommodule', 'faketomodule')

    assert(movedmodule.name == 'fakemodule')
    assert(movedmodule.new == 'faketomodule')

# Generated at 2022-06-21 17:59:31.579054
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    assert move.name == "range"
    assert move.new_mod == "builtins"
    assert move.new_attr == "range"


# Generated at 2022-06-21 17:59:37.725319
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer(target=(2, 7),
                            rewrites=(('str1', 'str2'), ('str3', 'str4')))
    assert s.target == (2, 7)
    assert s.rewrites == (('str1', 'str2'), ('str3', 'str4'))

# Generated at 2022-06-21 17:59:47.160535
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert path in SixMovesTransformer.rewrites, path
                assert 'six.moves{}.{}'.format(prefix, move.name) in SixMovesTransformer.rewrites[path], 'six.moves.{}'.format(move.name)
            elif isinstance(move, MovedModule):
                assert move.new in SixMovesTransformer.rewrites, move.new

# Generated at 2022-06-21 17:59:48.585316
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-21 17:59:52.975387
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule("builtins")

# Generated at 2022-06-21 17:59:59.385739
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('a', 'b', 'c')
    assert a.name == 'a'
    assert a.new_mod == 'c'
    assert a.new_attr == 'a'
    b = MovedAttribute('a', 'b', 'c', 'd')
    assert b.name == 'a'
    assert b.new_mod == 'c'
    assert b.new_attr == 'd'
    c = MovedAttribute('a', 'b', 'c', 'd', 'e')
    assert c.name == 'a'
    assert c.new_mod == 'c'
    assert c.new_attr == 'e'

# Generated at 2022-06-21 18:00:09.281734
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-21 18:00:12.991957
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a = MovedAttribute("filter", "itertools", "builtins", None, "filter")
    assert a.name == "filter"
    assert a.new_mod == "builtins"
    assert a.new_attr == "filter"


# Generated at 2022-06-21 18:00:23.234668
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("name", "old", "new")
    assert move.name == "name"
    assert move.new == "new"

    move = MovedModule("name", "old")
    assert move.name == "name"
    assert move.new == "name"

    move = MovedModule("name")
    assert move.name == "name"
    assert move.new == "name"

    move = MovedModule("name", None, "new")
    assert move.name == "name"
    assert move.new == "new"

    move = MovedModule("name", None, None)
    assert move.name == "name"
    assert move.new == "name"

    move = MovedModule("name", "old", None)
    assert move.name == "name"

# Generated at 2022-06-21 18:00:31.179804
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_transforms import compare_transform
    compare_transform(SixMovesTransformer, '''
from six.moves.urllib.parse import urlparse
from six.moves.urllib.error import URLError
from six.moves.urllib.request import urlopen
from six.moves.urllib.response import addinfo
from six.moves.urllib.robotparser import RobotFileParser
import six.moves.urllib.robotparser
import six.moves.urllib.request
import six.moves.urllib.response
import six.moves.urllib.error
import six.moves.urllib.parse
''')

# Generated at 2022-06-21 18:00:37.905272
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("test", "old_module", "new_module")
    assert a.name == "test"
    assert a.old_mod == "old_module"
    assert a.new_mod == "new_module"
    assert a.old_attr == "test"
    assert a.new_attr == "test"



# Generated at 2022-06-21 18:00:43.661520
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()
    assert x.target == (2, 7)
    assert len(x.dependencies) == 1
    assert x.dependencies[0] == 'six'
    assert len(x.rewrites) == len(_get_rewrites())
    for rw in x.rewrites:
        assert rw in _get_rewrites()

# Generated at 2022-06-21 18:00:49.664409
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute(name='name', old_mod='old_mod', new_mod='new_mod', old_attr='old_attr')
    assert (test.name, test.new_mod, test.new_attr) == ('name', 'new_mod', 'old_attr')

    test = MovedAttribute(name='name', old_mod='old_mod', new_mod='new_mod', old_attr='old_attr', new_attr='new_attr')
    assert (test.name, test.new_mod, test.new_attr) == ('name', 'new_mod', 'new_attr')

# Generated at 2022-06-21 18:00:54.949758
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"


# Generated at 2022-06-21 18:01:06.085184
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                rewrites = '{}: six.moves{}.{}'.format(path, prefix, move.name)
                assert rewrites in str(SixMovesTransformer.rewrites)
            elif isinstance(move, MovedModule):
                rewrites = '{}: six.moves{}.{}'.format(move.new, prefix, move.name)
                assert rewrites in str(SixMovesTransformer.rewrites)

# Generated at 2022-06-21 18:01:17.732691
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('test', 'a', 'b').name == 'test'
    assert MovedAttribute('test', 'a', 'b').new_mod == 'b'
    assert MovedAttribute('test', 'a', 'b').new_attr == 'test'
    assert MovedAttribute('test', 'a', 'b', old_attr='old', new_attr='new').new_attr == 'new'
    assert MovedAttribute('test', 'a', 'b', old_attr='old', new_attr='new').name == 'test'
    assert MovedAttribute('test', 'a', 'b', old_attr='old', new_attr='new').new_mod == 'b'
    assert MovedAttribute('test', 'a', 'b', old_attr='old', new_attr='new').new_attr == 'new'
   

# Generated at 2022-06-21 18:01:19.692585
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer('2.7')
    assert t.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:01:22.911449
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:01:29.780545
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_name = "module_name"
    old = "old"
    new = "new"
    m = MovedModule(module_name, old)
    assert m.name == module_name
    assert m.old == old
    assert m.new == module_name
    m = MovedModule(module_name, old, new)
    assert m.name == module_name
    assert m.old == old
    assert m.new == new


# Generated at 2022-06-21 18:01:32.032381
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert {('urllib.parse', 'six.moves.urllib.parse')} <= set(SixMovesTransformer.rewrites)

# Generated at 2022-06-21 18:01:41.178106
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import re
    import six

    class MovedAttribute(six.MovedAttribute):
        pass

    class MovedModule(six.MovedModule):
        pass


# Generated at 2022-06-21 18:01:52.662126
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("winreg", "_winreg")
    assert move.name == "winreg"
    assert move.new == "winreg"
    assert move.old == "_winreg"
    assert str(move) == "MovedModule(name='winreg', old='_winreg', new='winreg')"

    move = MovedModule("winreg", "_winreg", "winreg2")
    assert move.name == "winreg"
    assert move.new == "winreg2"
    assert move.old == "_winreg"
    assert str(move) == "MovedModule(name='winreg', old='_winreg', new='winreg2')"



# Generated at 2022-06-21 18:01:55.568426
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert t.dependencies == ['six']
    first_rewrite = next(iter(t.rewrites))
    assert first_rewrite[0] == 'urllib.parse.ParseResult'
    assert first_rewrite[1] == 'six.moves.urllib_parse.ParseResult'
    assert len(t.rewrites) == 61

# Generated at 2022-06-21 18:02:08.443798
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:02:14.045413
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'name'

# Generated at 2022-06-21 18:02:25.623624
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'name'

    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'old_attr'

    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'


# Generated at 2022-06-21 18:02:32.595407
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:02:45.081099
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mattr = MovedAttribute("name", "old_mod", "new_mod")
    assert mattr.name == "name"
    assert mattr.new_mod == "new_mod"
    assert mattr.new_attr == "name"
    mattr = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert mattr.name == "name"
    assert mattr.new_mod == "new_mod"
    assert mattr.new_attr == "old_attr"
    mattr = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    assert mattr.name == "name"
    assert mattr.new_mod == "new_mod"
    assert mattr.new_attr == "new_attr"
    mattr

# Generated at 2022-06-21 18:02:53.262649
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pytree import Leaf
    from libfuturize.fixes.sixmoves import SixMovesTransformer
    source = 'asyncio.selector_events'
    node = Leaf(0, source, prefix='')
    transformer = SixMovesTransformer(None)
    assert transformer.match(node) == (source, 'six.moves.selector_events')

# Generated at 2022-06-21 18:02:56.338040
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six' in SixMovesTransformer.dependencies
    assert len(SixMovesTransformer.dependencies) == 1

    assert len(SixMovesTransformer.rewrites) == 85


# Generated at 2022-06-21 18:03:05.532827
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("a", "b", "c").name == "a"
    assert MovedAttribute("a", "b", "c").new_mod == "c"
    assert MovedAttribute("a", "b", "c", "d").new_attr == "d"
    assert MovedAttribute("a", "b", "c", new_attr="d").new_attr == "d"
    assert MovedAttribute("a", "b", "c", old_attr="d").new_attr == "d"
    assert MovedAttribute("a", "b", "c").new_attr == "a"




# Generated at 2022-06-21 18:03:14.813551
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test the usual way of constructing an MovedAttribute
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "cStringIO"
    assert move.new_attr == "StringIO"

    # Test the usual new_attr is the same as old_attr
    move = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    assert move.name == "range"
    assert move.new_mod == "builtins"
    assert move.new_attr == "range"

    # Test new_mod is the same as name
    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")

# Generated at 2022-06-21 18:03:26.511276
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('foo', 'bar', 'baz', 'old_foo', 'new_foo')
    assert ma.name == 'foo'
    assert ma.new_mod == 'baz'
    assert ma.new_attr == 'new_foo'

    ma = MovedAttribute('foo', 'bar', 'baz', 'old_foo', None)
    assert ma.name == 'foo'
    assert ma.new_mod == 'baz'
    assert ma.new_attr == 'old_foo'

    ma = MovedAttribute('foo', 'bar', 'baz')
    assert ma.name == 'foo'
    assert ma.new_mod == 'baz'
    assert ma.new_attr == 'foo'

# Generated at 2022-06-21 18:03:31.827359
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute(name="filter", old_mod="itertools", new_mod="builtins", old_attr="ifilter", new_attr="filter")
    assert moved_attribute.name == "filter"
    assert moved_attribute.new_mod == "builtins"
    assert moved_attribute.new_attr == "filter"

# Generated at 2022-06-21 18:03:38.442087
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

# Generated at 2022-06-21 18:03:41.721267
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("builtins","__builtin__")
    assert mod.name == "builtins"
    assert mod.new == "builtins"



# Generated at 2022-06-21 18:03:45.105132
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("test", "old", "new")
    assert test_module.name == "test"
    assert test_module.old == "old"
    assert test_module.new == "new"

# Generated at 2022-06-21 18:03:47.641361
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'

# Generated at 2022-06-21 18:03:52.651626
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Arrange
    # Act

    # Assert
    assert MovedModule('builtins', '__builtin__') == MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__') != MovedModule('builtins', '__builtin_')


# Generated at 2022-06-21 18:03:55.084407
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None)
    assert t.rewrites == _get_rewrites()


# Generated at 2022-06-21 18:04:05.128351
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

# Generated at 2022-06-21 18:04:06.295612
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer

# Generated at 2022-06-21 18:04:14.325902
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """
    >>> MovedAttribute('nom', 'old', 'new')
    <six.MovedAttribute object at ...>
    >>> old_attr = MovedAttribute('nom', 'old', 'new', 'old_attr')
    >>> old_attr.old_attr
    'old_attr'
    >>> new_attr = MovedAttribute('nom', 'old', 'new', 'old_attr', 'new_attr')
    >>> new_attr.new_attr
    'new_attr'
    """


# Generated at 2022-06-21 18:04:17.048118
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-21 18:04:39.257724
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m1.name == "cStringIO"
    assert m1.new_mod == "io"
    assert m1.new_attr == "StringIO"

    m2 = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    assert m2.name == "getcwd"
    assert m2.new_mod == "os"
    assert m2.new_attr == "getcwd"

    m3 = MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
    assert m3.name == "getcwdb"
    assert m3.new_mod == "os"

# Generated at 2022-06-21 18:04:44.559765
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("a", "b")
    assert a.name == "a"
    assert a.new == "a"
    a = MovedModule("a", "b", "c")
    assert a.name == "a"
    assert a.new == "c"

# Generated at 2022-06-21 18:04:49.043672
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute(name='name', old_mod='old', new_mod='new', old_attr='oldattr', new_attr='newattr')
    assert attr.name == 'name'
    assert attr.new_mod == 'new'
    assert attr.new_attr == 'newattr'



# Generated at 2022-06-21 18:04:57.373999
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__', '__builtin__').new == '__builtin__'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('configparser', 'ConfigParser', 'configparser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser', 'configparser').new == 'configparser'


# Generated at 2022-06-21 18:04:58.622768
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of class SixMovesTransformer."""
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:05:01.201721
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.new == "builtins"

    module = MovedModule("configparser", "ConfigParser", "configparser")
    assert module.name == "configparser"
    assert module.new == "configparser"


# Generated at 2022-06-21 18:05:06.130673
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.new == "new"
    mod = MovedModule("name", "old")
    assert mod.name == "name"
    assert mod.new == "name"


# Generated at 2022-06-21 18:05:11.568432
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('new_name', 'old_module', 'new_module', 'old_attr', 'new_attr')
    expected = 'MovedAttribute(name="new_name", old_mod="old_module", new_mod="new_module", old_attr="old_attr", new_attr="new_attr")'
    assert str(attr) == expected


# Generated at 2022-06-21 18:05:14.246867
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()  # type: ignore[no-untyped-call]

# Generated at 2022-06-21 18:05:25.924898
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test if moved modules are replaced with ones from `six.moves`"""
    # Create a test file and rewrite moved modules
    test_file = 'test_file.py'
    six_transformer = SixMovesTransformer()
    six_transformer.rewrite_file(test_file)
    # Read rewritten file
    with open(test_file, 'r') as f:
        rewritten_code = f.read()
    # Check if all moved modules were replaced with ones from `six.moves`
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert 'from six.moves{} import {}'.format(prefix, move.name)

# Generated at 2022-06-21 18:06:02.314680
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_mod = MovedModule('module_name', 'old_name', 'new_name')
    assert moved_mod.name == 'module_name'
    assert moved_mod.old == 'old_name'
    assert moved_mod.new == 'new_name'

    moved_mod = MovedModule('module_name', 'old_name')
    assert moved_mod.name == 'module_name'
    assert moved_mod.old == 'old_name'
    assert moved_mod.new == 'module_name'

    moved_mod = MovedModule('module_name')
    assert moved_mod.name == 'module_name'
    assert moved_mod.old == 'module_name'
    assert moved_mod.new == 'module_name'




# Generated at 2022-06-21 18:06:12.835488
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "oldmod", "newmod")
    assert attr.__dict__ == {'name': "name", 'old_mod': "oldmod",
                             'new_mod': "newmod", 'old_attr': "name",
                             'new_attr': "name"}

    attr = MovedAttribute("name", "oldmod", "newmod", "oldattr", "newattr")
    assert attr.__dict__ == {'name': "name", 'old_mod': "oldmod",
                             'new_mod': "newmod", 'old_attr': "oldattr",
                             'new_attr': "newattr"}

# Generated at 2022-06-21 18:06:18.307717
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('cStringIO', 'cStringIO', 'io',
                            old_attr='StringIO', new_attr='StringIO')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'


# Generated at 2022-06-21 18:06:27.805234
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m1 = MovedAttribute('cStringIO', None, None, 'StringIO')
    assert m1.name == 'cStringIO'
    assert m1.new_mod == 'cStringIO'
    assert m1.new_attr == 'StringIO'

    m2 = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert m2.name == 'filter'
    assert m2.new_mod == 'builtins'
    assert m2.new_attr == 'filter'

    m3 = MovedAttribute('intern', '__builtin__', 'sys')
    assert m3.name == 'intern'
    assert m3.new_mod == 'sys'
    assert m1.new_attr == 'StringIO'



# Generated at 2022-06-21 18:06:34.655845
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "quote"
    old_mod = "urllib"
    new_mod = "urllib.parse"
    old_attr = None
    new_attr = None
    move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert move.name == name
    assert move.new_mod == new_mod
    assert move.new_attr == new_attr

# Generated at 2022-06-21 18:06:39.928601
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("example", "old_mod", "new_mod")
    assert x.name == "example"
    assert x.old_mod is None
    assert x.new_mod == "new_mod"
    assert x.old_attr is None
    assert x.new_attr == "example"

    x = MovedAttribute("example", "old_mod", "new_mod", "old_attr")
    assert x.name == "example"
    assert x.old_mod == "old_mod"
    assert x.new_mod == "new_mod"
    assert x.old_attr == "old_attr"
    assert x.new_attr == "old_attr"

    x = MovedAttribute("example", "old_mod", "new_mod", "old_attr", "new_attr")

# Generated at 2022-06-21 18:06:45.199807
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer().rewrites) == len(set(_get_rewrites()))


if __name__ == '__main__':
    # Simulate command-line usage.
    from lib2to3.main import main
    main("lib2to3.fixes.fix_six_moves")

# Generated at 2022-06-21 18:06:53.558976
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert len(t.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) \
        + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) \
        + len(_urllib_response_moved_attributes)
    assert ('http.server', 'six.moves.BaseHTTPServer') in t.rewrites
    assert ('urllib.parse.unquote', 'six.moves.urllib_parse.unquote') in t.rewrites

# Generated at 2022-06-21 18:06:59.472693
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('foo', 'a', 'b', 'c', 'd')
    assert a.name == 'foo'
    assert a.new_mod == 'b'
    assert a.new_attr == 'c'
    assert a.old_attr == 'd'

    b = MovedAttribute('foo', 'a', 'b', 'c', None)
    assert b.name == 'foo'
    assert b.new_mod == 'b'
    assert b.new_attr == 'c'
    assert b.old_attr == 'foo'

    c = MovedAttribute('foo', 'a', 'b', None, None)
    assert c.name == 'foo'
    assert c.new_mod == 'b'
    assert c.new_attr == 'foo'