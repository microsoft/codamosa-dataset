

# Generated at 2022-06-21 17:57:08.883774
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # test removed references to module names
    test_text = """
import six
six.moves.urllib.urlopen
import math, six.moves.urllib.request
"""
    expected_output = """
import six
six.moves.urllib.request.urlopen
import math, six.moves.urllib.request
"""
    output = SixMovesTransformer(None).transform_string(test_text)
    assert expected_output == output

# Generated at 2022-06-21 17:57:14.163062
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('foo', 'a', 'b', 'c', 'd')
    assert ma.name == 'foo'
    assert ma.new_mod == 'b'
    assert ma.new_attr == 'd'



# Generated at 2022-06-21 17:57:23.310759
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test initial values:
    attr = MovedAttribute("name", "old_mod", "new_mod")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "name"
    # Test initialization with provided attribute name:
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert attr.new_attr == "old_attr"
    # Test initialization with None/None for new module name:
    attr = MovedAttribute("name", "old_mod", None, "old_attr", "new_attr")
    assert attr.new_mod == "name"
    assert attr.new_attr == "new_attr"
    # Test initialization with None for new attribute name:

# Generated at 2022-06-21 17:57:30.044843
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    cstringio_move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert cstringio_move.name == "cStringIO"
    assert cstringio_move.new_mod == "io"
    assert cstringio_move.new_attr == "StringIO"

    # Test constructor with no new_attr
    filter_move = MovedAttribute("filter", "itertools", "builtins", "ifilter")
    assert filter_move.name == "filter"
    assert filter_move.new_mod == "builtins"
    assert filter_move.new_attr == "filter"

    # Test constructor with no old_attr or new_attr
    intern_move = MovedAttribute("intern", "__builtin__", "sys")

# Generated at 2022-06-21 17:57:40.407374
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod',
                          'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod',
                          'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod',
                          'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'

# Generated at 2022-06-21 17:57:41.893651
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert_equal(SixMovesTransformer.rewrites, list(_get_rewrites()))

# Generated at 2022-06-21 17:57:49.553417
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    imports = set(transformer.imports)
    assert 'six.moves' in imports
    aliases = set(transformer.aliases)
    assert 'shutil' not in aliases
    from_modules = set(transformer.from_modules)
    assert 'six.moves.urllib' not in from_modules
    assert 'six.moves.urllib.request' in from_modules

if __name__ == "__main__":
    test_SixMovesTransformer()

# Generated at 2022-06-21 17:57:55.652178
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("tkinter", "Tkinter").name == "tkinter"
    assert MovedModule("tkinter","Tkinter").new == "tkinter"
    assert MovedModule("tkinter","Tkinter","tkinter.tkinter").name == "tkinter"
    assert MovedModule("tkinter","Tkinter","tkinter.tkinter").new == "tkinter.tkinter"

# Generated at 2022-06-21 17:58:00.106537
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(name="a", old_mod="old_mod", new_mod="new_mod", old_attr="old_attr", new_attr="new_attr")
    assert move.name == "a"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-21 17:58:12.601466
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").name == "copyreg"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").name == "dbm_gnu"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").new == "dbm.gnu"

# Generated at 2022-06-21 17:58:28.086472
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 17:58:35.159849
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test.name == "cStringIO"
    assert test.new_mod == "io"
    assert test.new_attr == "StringIO"

    test = MovedAttribute("cStringIO", "cStringIO", "io")
    assert test.new_attr == "cStringIO"

# Generated at 2022-06-21 17:58:37.744729
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("test", "old")
    assert mm.name == "test"
    assert mm.old == "old"
    assert mm.new == "test"


# Generated at 2022-06-21 17:58:41.317340
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(name="builtins", old="__builtin__", new="builtins") == MovedModule(name="builtins", old="__builtin__")
    assert MovedModule(name="configparser", old="ConfigParser") == MovedModule(name="configparser", old="ConfigParser", new="configparser")


# Generated at 2022-06-21 17:58:49.692421
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('m', 'o', 'n').__dict__ == {'name': 'm', 'new_mod': 'n', 'new_attr': 'm'}
    assert MovedAttribute('m', 'o', 'n', 'a').__dict__ == {'name': 'm', 'new_mod': 'n', 'new_attr': 'a'}
    assert MovedAttribute('m', 'o', 'n', 'a').__dict__ == {'name': 'm', 'new_mod': 'n', 'new_attr': 'a'}
    assert MovedAttribute('m', 'o', 'n', None, 'a').__dict__ == {'name': 'm', 'new_mod': 'n', 'new_attr': 'a'}


# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 17:58:51.663756
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO','cStringIO','io','StringIO').new_attr == 'StringIO'


# Generated at 2022-06-21 17:58:56.855568
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar').name == 'foo'
    assert MovedModule('foo', 'bar').new == 'foo'
    assert MovedModule('foo', 'bar', 'quux').new == 'quux'


# Generated at 2022-06-21 17:59:08.910166
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    f = MovedAttribute("name", "mod1", "mod2")
    assert f.name == "name"
    assert f.new_mod == "mod2"
    assert f.new_attr == "name"

    f = MovedAttribute("name", "mod1", "mod2", "attr1")
    assert f.name == "name"
    assert f.new_mod == "mod2"
    assert f.new_attr == "attr1"

    f = MovedAttribute("name", "mod1", "mod2", new_attr="attr2")
    assert f.name == "name"
    assert f.new_mod == "mod2"
    assert f.new_attr == "attr2"

    f = MovedAttribute("name", "mod1", "mod2", "attr1", "attr2")
   

# Generated at 2022-06-21 17:59:19.561405
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys

    try:
        from typing import List
    except ImportError:
        pass

    if sys.version_info >= (3, 6):
        from typing import Dict

    _is_py_36 = sys.version_info[:2] >= (3, 6)

    _six_moves_attributes = []

    def get_moves_attributes(moves):
        for move in moves:
            if isinstance(move, MovedAttribute):
                if _is_py_36:
                    yield '{}.{}'.format(move.new_mod, move.new_attr), 'six.moves.{}'.format(move.name)
                else:
                    _six_moves_attributes.append('six.moves.{}'.format(move.name))

# Generated at 2022-06-21 17:59:31.876667
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert(MovedAttribute("cStringIO", "cStringIO",
                          "io", "StringIO").new_attr == "StringIO")
    assert(MovedAttribute("cStringIO", "cStringIO", "io",
                          old_attr="StringIO").new_attr == "StringIO")
    assert(MovedAttribute(
        "cStringIO", "cStringIO", "io").new_attr == "cStringIO")
    assert(MovedAttribute("cStringIO", "cStringIO", "io",
                          "StringIO", "new_attr").new_attr == "new_attr")
    assert(MovedAttribute("cStringIO", "cStringIO", "io",
                          "StringIO", new_attr="new_attr").new_attr == "new_attr")



# Generated at 2022-06-21 17:59:40.535682
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()


if __name__ == '__main__':
    # Test this module by running all of the doctests it contains.
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 17:59:42.097693
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule
    assert moved_module.__init__.__doc__ == "Initialize self.  See help(type(self)) for accurate signature."


# Generated at 2022-06-21 17:59:46.463792
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mmodule = MovedModule("foo", "bar")
    assert mmodule.name == "foo"
    assert mmodule.old == "bar"
    assert mmodule.new == "foo"
    mmodule = MovedModule("foo", "bar", "baz")
    assert mmodule.name == "foo"
    assert mmodule.old == "bar"
    assert mmodule.new == "baz"

# Generated at 2022-06-21 17:59:55.393534
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_moved_attribute.name == "cStringIO"
    assert test_moved_attribute.new_mod == "io"
    assert test_moved_attribute.new_attr == "StringIO"

    test_moved_attribute_new_attr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert test_moved_attribute_new_attr.new_attr == "filter"


# Generated at 2022-06-21 18:00:03.564520
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for the SixMovesTransformer."""
    from .. import _py2to3 as py2to3, utils
    transformer = py2to3.SixMovesTransformer()
    for rewrite in transformer.rewrites:
        assert isinstance(rewrite, tuple)
        assert isinstance(rewrite[0], str)
        assert isinstance(rewrite[1], str)
        assert rewrite[1] == utils.importable_name(rewrite[1])

# Generated at 2022-06-21 18:00:08.736797
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Checks if SixMovesTransformer has correct constructor.

    It's enough if class has the following components:
    - target
    - rewrites
    - dependencies
    """
    assert SixMovesTransformer.target == (2, 7)
    assert isinstance(SixMovesTransformer.rewrites, tuple)
    assert isinstance(SixMovesTransformer.dependencies, tuple)
    assert 'six' in SixMovesTransformer.dependencies

# Generated at 2022-06-21 18:00:13.698793
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("test_module", "old_module", "new_module")
    assert moved_module.name == "test_module"
    assert moved_module.old == "old_module"
    assert moved_module.new == "new_module"


# Generated at 2022-06-21 18:00:19.717884
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # One can see at http://www.python.org/dev/peps/pep-3108/
    # that range is not a moved module, it is a moved attribute
    # of the builtins module.
    MM = MovedModule('range', 'builtins', 'itertools')
    assert MM.name == 'range'
    assert MM.old == 'builtins'
    assert MM.new == 'itertools'


# Generated at 2022-06-21 18:00:29.415495
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute('test', 'pesho', 'gosho')
    assert test.name == 'test'
    assert test.new_mod == 'gosho'
    assert test.new_attr == 'test'

    test = MovedAttribute('test', 'pesho', 'gosho', 'pesho_attr', 'gosho_attr')
    assert test.name == 'test'
    assert test.new_mod == 'gosho'
    assert test.new_attr == 'gosho_attr'

    test = MovedAttribute('test', 'pesho', 'gosho', new_attr='gosho_attr')
    assert test.name == 'test'
    assert test.new_mod == 'gosho'
    assert test.new_attr == 'gosho_attr'

# Generated at 2022-06-21 18:00:41.600886
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:00:54.570258
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    test_rewrites = [
        (".urllib.parse.urlparse", "six.moves.urllib_parse.urlparse"),
        ("input", "six.moves.input")
    ]
    assert len(test_rewrites) == len(t.rewrites)
    for i, j in zip(test_rewrites, t.rewrites):
        assert i[0] == j[0]
        assert i[1] == j[1]

# Generated at 2022-06-21 18:00:58.924912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("foo", "bar", "baz")
    assert move.name == "foo"
    assert move.new_mod == "baz"
    assert move.new_attr == "foo"

    move = MovedAttribute("foo", "bar", "baz", "qux", "quux")
    assert move.name == "foo"
    assert move.new_mod == "baz"
    assert move.new_attr == "quux"


# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 18:01:03.444803
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils.helpers import eager
    from .base import BaseImportRewrite

    @eager
    def _get_rewrites():
        for i in range(1):
            yield (i, 'i')

    class TestingSixMovesTransformer(BaseImportRewrite):
        target = (2, 7)
        rewrites = _get_rewrites()
        dependencies = ['six']

    for i in range(1):
        assert next(TestingSixMovesTransformer.rewrites) == (i, 'i')
    TestingSixMovesTransformer.rewrites = None

    # It should not raise an error
    TestingSixMovesTransformer.rewrites
    # It should run without errors
    TestingSixMovesTransformer('')

# Generated at 2022-06-21 18:01:04.966184
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, type)

# Generated at 2022-06-21 18:01:13.313697
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"

    obj = MovedAttribute("intern", "__builtin__", "sys")
    assert obj.name == "intern"
    assert obj.new_mod == "sys"
    assert obj.new_attr == "intern"

# Generated at 2022-06-21 18:01:17.617118
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("builtins", "__builtin__")
    assert mm.name == "builtins"
    assert mm.new == "builtins"
    mm = MovedModule("builtins", "__builtin__", "builtins")
    assert mm.name == "builtins"
    assert mm.new == "builtins"


# Generated at 2022-06-21 18:01:29.913434
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").__dict__ == {"name": "name", "old_mod": "old_mod", "new_mod": "new_mod", "old_attr": None, "new_attr": "name"}
    assert MovedAttribute("name", "old_mod", "new_mod", old_attr="old_attr").__dict__ == {"name": "name", "old_mod": "old_mod", "new_mod": "new_mod", "old_attr": "old_attr", "new_attr": "old_attr"}

# Generated at 2022-06-21 18:01:33.945713
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("name", "old", "new")
    assert test.name == "name"
    assert test.old == "old"
    assert test.new == "new"


# Generated at 2022-06-21 18:01:36.716012
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.target == (2, 7)
    assert s.rewrites == _get_rewrites()
    assert s.dependencies == ['six']

# Generated at 2022-06-21 18:01:44.122779
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    l = list(_get_rewrites())
    assert l[0][0] == 'cStringIO.StringIO'
    assert l[0][1] == 'six.moves.cStringIO'
    assert l[1][0] == 'builtins.filter'
    assert l[1][1] == 'six.moves.filter'
    assert l[2][0] == 'itertools.filterfalse'
    assert l[2][1] == 'six.moves.filterfalse'
    assert l[3][0] == 'builtins.input'
    assert l[3][1] == 'six.moves.input'
    assert l[4][0] == 'sys.intern'
    assert l[4][1] == 'six.moves.intern'

# Generated at 2022-06-21 18:01:54.143326
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('foo', 'old', 'new')
    assert move.name == 'foo'
    assert move.new_mod == 'new'
    assert move.new_attr == 'foo'


# Generated at 2022-06-21 18:01:58.751123
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar")
    assert MovedModule("foo", "bar", "baz")
    assert MovedModule("foo", "bar", new="baz")
    assert MovedModule("foo", "bar", "bar.baz")



# Generated at 2022-06-21 18:02:11.079216
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    g = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert g.name == "cStringIO"
    assert g.new_mod == "io"
    assert g.new_attr == "StringIO"

    g = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    assert g.name == "range"
    assert g.new_mod == "builtins"
    assert g.new_attr == "range"

    g = MovedAttribute("reload_module", "__builtin__", "imp", "reload")
    assert g.name == "reload_module"
    assert g.new_mod == "imp"
    assert g.new_attr == "reload"



# Generated at 2022-06-21 18:02:18.199609
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import pytest


# Generated at 2022-06-21 18:02:26.409087
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class TestMovedModule(MovedModule):
        def __init__(self, name, old, new=None):
            super(TestMovedModule, self).__init__(name, old, new)

    t = TestMovedModule('foo', 'bar')
    assert t.name == 'foo' and t.old == 'bar' and t.new == 'foo'
    t = TestMovedModule('foo', 'bar', 'baz')
    assert t.name == 'foo' and t.old == 'bar' and t.new == 'baz'



# Generated at 2022-06-21 18:02:29.404092
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("parse_qs", "urlparse", "urllib.parse")
    assert ma.name == "parse_qs"
    assert ma.new_mod == "urllib.parse"
    assert ma.new_attr == "parse_qs"

    ma = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert ma.name == "input"
    assert ma.new_mod == "builtins"
    assert ma.new_attr == "input"


# Generated at 2022-06-21 18:02:42.641848
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "a", "b").name == "cStringIO"
    assert MovedAttribute("cStringIO", "a", "b").new_mod == "b"
    assert MovedAttribute("cStringIO", "a", "b").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "a", "b", "c", "d").name == "cStringIO"
    assert MovedAttribute("cStringIO", "a", "b", "c", "d").new_mod == "b"
    assert MovedAttribute("cStringIO", "a", "b", "c", "d").new_attr == "d"
    assert MovedAttribute("cStringIO", "a", "b", "c").name == "cStringIO"

# Generated at 2022-06-21 18:02:47.553759
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # SixMovesTransformer() should contain all renames of six.moves
    s = SixMovesTransformer()
    # Check if all rewrites are in the transformer.
    for rewrite in _get_rewrites():
        try:
            assert rewrite in s.rewrites
        except AssertionError:
            print(rewrite)
            raise
    # Check if there are more rewrites in the transformer.
    # This is handled by the eager decorator

# Generated at 2022-06-21 18:02:58.286520
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-21 18:03:03.576519
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj_1 = MovedModule('name', 'old')
    assert obj_1.name == 'name'
    assert obj_1.new == 'name'
    obj_2 = MovedModule('name', 'old', 'new')
    assert obj_2.name == 'name'
    assert obj_2.new == 'new'



# Generated at 2022-06-21 18:03:11.971344
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 110

# Generated at 2022-06-21 18:03:23.651929
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"
    # __init__ should use defaults for some of the properties if they are not specified
    attr2 = MovedAttribute("name", "old_mod", "new_mod")
    assert attr2.name == "name"
    assert attr2.new_mod == "new_mod"
    assert attr2.new_attr == "name"
    attr3 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert attr3.name == "name"
    assert attr3

# Generated at 2022-06-21 18:03:26.955264
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.old == 'old'
    assert m.new == 'new'


# Generated at 2022-06-21 18:03:37.054032
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("foo", "bar", "baz")
    assert a.name == "foo"
    assert a.new_mod == "baz"
    assert a.new_attr == "foo"
    a = MovedAttribute("foo", "bar", "baz",
                       new_attr="foobar")
    assert a.new_attr == "foobar"
    a = MovedAttribute("foo", "bar", "baz",
                       old_attr="quux",
                       new_attr="foobar")
    assert a.new_attr == "foobar"


# Generated at 2022-06-21 18:03:47.511636
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    code = '''
    import urlparse
    import urllib
    import urllib2

    try:
        import _winreg
    except ImportError:
        pass

    try:
        import ConfigParser
    except ImportError:
        pass

    from urllib import quote_plus
    from urllib import unquote_plus
    from urllib import unquote
    from urllib import unquote_to_bytes
    from urllib import splitquery
    from urllib import splittag
    from urllib import splituser
    from urllib import splitvalue
    from urllib import uses_fragment, uses_netloc
    from urllib import uses_params, uses_query, uses_relative
    '''
    t = SixMovesTransformer()
    new_src = t.transform_

# Generated at 2022-06-21 18:03:52.892617
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute(name="input", old_mod="__builtin__", new_mod="builtins", old_attr="raw_input", new_attr="input")
    assert obj.name == "input"
    assert obj.new_mod == "builtins"
    assert obj.new_attr == "input"



# Generated at 2022-06-21 18:03:54.810157
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test_arg', 'test_old')

# Generated at 2022-06-21 18:03:59.047968
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_MovedModule = MovedModule("name", "old", "new")
    assert test_MovedModule.name == "name"
    assert test_MovedModule.old == "old"
    assert test_MovedModule.new == "new"


# Generated at 2022-06-21 18:04:03.421327
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attributes = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attributes.name == "cStringIO"
    assert attributes.old_mod == "cStringIO"
    assert attributes.new_mod == "io"
    assert attributes.old_attr == "StringIO"


# Generated at 2022-06-21 18:04:10.719735
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"



# Generated at 2022-06-21 18:04:26.970808
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('test', 'old', 'new')
    assert ma.name == 'test'
    assert ma.new_mod == 'test'
    assert ma.new_attr == 'test'

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-21 18:04:35.231079
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"
    m = MovedAttribute("filter", "itertools", "builtins")
    assert m.name == "filter"
    assert m.new_mod == "builtins"
    assert m.new_attr == "filter"

# Generated at 2022-06-21 18:04:42.416810
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    r = SixMovesTransformer.rewrites

    assert ('six.moves', 'six.moves') not in r
    assert ('six.moves', 'six.moves.urllib_parse') not in r
    assert ('six.moves.urllib_parse', 'six.moves.urllib_parse') in r
    assert ('six.moves.urllib_error', 'six.moves.urllib_error') in r
    assert ('six.moves', 'six.moves.urllib_error') not in r
    assert ('six.moves.urllib_parse', 'six.moves') not in r
    assert ('six.moves.urllib_parse.urlparse', 'six.moves.urllib_parse.parse_qs') in r

# Generated at 2022-06-21 18:04:51.732901
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("biolib", "string")
    assert mm.name == "biolib"
    assert mm.new == "biolib"
    assert mm.old == "string"

    mm = MovedModule("string", "biolib", "string")
    assert mm.name == "string"
    assert mm.new == "string"
    assert mm.old == "biolib"

    mma = MovedAttribute("biolib", "string", "biolib")
    assert mma.name == "biolib"
    assert mma.new_mod == "biolib"
    assert mma.new_attr == "biolib"
    assert mma.old_mod == "string"
    assert mma.old_attr == None


# Generated at 2022-06-21 18:04:55.182647
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move_attribute.name == "name"
    assert move_attribute.new_mod == "new_mod"
    assert move_attribute.new_attr == "new_attr"

# Generated at 2022-06-21 18:04:57.708419
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute(name='foo', old_mod='old_mod', new_mod='new_mod',
                                 old_attr='old_attr', new_attr='new_attr')
    assert obj.name == 'foo'
    assert obj.new_mod == 'new_mod'
    assert obj.new_attr == 'new_attr'


# Generated at 2022-06-21 18:05:00.302161
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("subprocess", "subprocess")
    assert move.name == "subprocess"
    assert move.new == "subprocess"

    move = MovedModule("subprocess", "subprocess", "subprocess")
    assert move.name == "subprocess"
    assert move.new == "subprocess"



# Generated at 2022-06-21 18:05:02.482618
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites == _get_rewrites()

# Generated at 2022-06-21 18:05:05.451942
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None)
    assert t.rewrites == _get_rewrites()
    assert t.dependencies == ['six']

# Generated at 2022-06-21 18:05:08.838629
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    c2 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")



# Generated at 2022-06-21 18:05:44.281329
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None, None)
    new_rewrites = {}
    for k, v in transformer.rewrites.items():
        new_rewrites[k] = v
    assert new_rewrites == _get_rewrites()

# Generated at 2022-06-21 18:05:52.228937
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from importlib import machinery
    from .. import main
    loader = machinery.SourceFileLoader
    mod = loader('six_moves_transformer', 'six_moves_transformer.py').load_module()
    class MyError(Exception): pass
    with pytest.raises(MyError):
        main.main(('six_moves_transformer',),
                  trusted_modules=('six', 'six_moves_transformer',),
                  error_handler=MyError,
                  transformers=(mod.SixMovesTransformer,))

# Generated at 2022-06-21 18:05:57.704824
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # python3 rewrites = <function _get_rewrites.<locals>.<lambda> at 0x7fb05282e158>
    assert 'six.moves.urllib.parse.urlparse' in \
        [key for key, value in SixMovesTransformer.rewrites.items()]

# Generated at 2022-06-21 18:06:09.584045
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def test_cases(code, target=None):
        if target is None:
            target = (2, 7)
        transformer = SixMovesTransformer(target)
        return transformer.transform_single(code).strip()

    assert test_cases(
        'import six.moves.urllib.request') == 'import six.moves.urllib.request'
    assert test_cases(
        'import six.moves.urllib.request\nimport six') == 'import six\nimport six.moves.urllib.request'
    assert test_cases(
        'from six.moves.urllib.request import urlopen') == 'from six.moves.urllib.request import urlopen'

# Generated at 2022-06-21 18:06:11.332926
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass  # pragma: nocover

# Generated at 2022-06-21 18:06:15.342134
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("name", "old", "new")
    assert x.name == "name"
    assert x.new == "new"
    assert x.old == "old"
    x = MovedModule("name", "old")
    assert x.name == "name"
    assert x.new == "name"
    assert x.old == "old"

# Generated at 2022-06-21 18:06:25.868321
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    tup = ('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    cases = [
        ('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr'),
        ('name', 'old_mod', 'new_mod', None, 'new_attr'),
        ('name', 'old_mod', 'new_mod', 'old_attr', None),
        ('name', 'old_mod', 'new_mod', None, None),
        ('name', 'old_mod', None, None, None),
        ('name', 'old_mod', None, 'old_attr', None),
    ]
    for x in cases:
        move = MovedAttribute(*x)
        assert getattr(move, tup[0]) == x[0]

# Generated at 2022-06-21 18:06:30.659277
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('urlparse', 'six.moves.urllib_parse').__dict__ == {'name': 'urlparse', 'new': 'urlparse', 'old': 'six.moves.urllib_parse'}
    assert MovedModule('name', 'old').__dict__ == {'name': 'name', 'new': 'name', 'old': 'old'}
    assert MovedModule('name', 'old', 'new').__dict__ == {'name': 'name', 'new': 'new', 'old': 'old'}



# Generated at 2022-06-21 18:06:37.236574
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-21 18:06:42.036585
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('test', 'some_mod', 'some_other_mod')
    assert obj.name == 'test'
    assert obj.new_mod == 'some_other_mod'
    assert obj.new_attr == 'test'
    assert obj.old_attr is None
