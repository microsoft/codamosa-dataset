

# Generated at 2022-06-25 22:31:08.720457
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = ''
    old = ''
    new = ''
    moved_module_0 = MovedModule(name, old, new)


# Generated at 2022-06-25 22:31:10.604018
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('name', 'old', 'new')
    MovedModule('name', 'old')


# Generated at 2022-06-25 22:31:13.020499
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("builtins", "__builtin__")
    assert moved_module_0.new == "builtins"


# Generated at 2022-06-25 22:31:15.471481
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:18.207225
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:21.073854
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        with pytest.raises(NameError):
            result = MovedAttribute()
    except NameError as exception_1:
        assert True
    else:
        assert False


# Generated at 2022-06-25 22:31:30.086878
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    _test_MovedAttribute = MovedAttribute("test_name", "test_old_mod", "test_new_mod", "test_old_attr", "test_new_attr")
    assert isinstance(_test_MovedAttribute, MovedAttribute)
    assert _test_MovedAttribute.name == "test_name"
    assert _test_MovedAttribute.old_mod == "test_old_mod"
    assert _test_MovedAttribute.new_mod == "test_new_mod"
    assert _test_MovedAttribute.old_attr == "test_old_attr"
    assert _test_MovedAttribute.new_attr == "test_new_attr"


# Generated at 2022-06-25 22:31:36.897681
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_0 = "typed_ast._ast3"
    a_s_t_0 = module_0.AST()
    class_name = "SixMovesTransformer"
    ClassName = class_name
    class_name_0 = ClassName
    ClassName_0 = str(class_name_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)



# Generated at 2022-06-25 22:31:38.772077
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("UserDict", "UserDict", "collections")


# Generated at 2022-06-25 22:31:41.326327
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Valid case, no args
    foo_0 = MovedModule()
    # Valid case, args
    foo_1 = MovedModule('bar', 'baz')


# Generated at 2022-06-25 22:31:43.959190
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()
    assert moved_module_0.name == None
    assert moved_module_0.new == None

# Generated at 2022-06-25 22:31:45.989180
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    argument_0 = None
    instance = SixMovesTransformer(argument_0)
    assert isinstance(instance, SixMovesTransformer)


# Generated at 2022-06-25 22:31:53.559514
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..tests.fixtures import make_test_case
    from .. import base
    import sys

    class SixMovesTransformerSubclass(SixMovesTransformer):
        pass

    for test_case in make_test_case([SixMovesTransformer, SixMovesTransformerSubclass]):
        assert test_case.old_code.startswith('from __future__ import')
        assert test_case.new_code.startswith('from __future__ import')
        if 'six' not in test_case.new_code:
            assert 'six\n' in test_case.new_code
        if 'six' in test_case.new_code:
            assert 'six\n' not in test_case.new_code
        if 'six' not in sys.modules:
            assert 'six\n' in test

# Generated at 2022-06-25 22:31:55.267502
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()


# Generated at 2022-06-25 22:31:59.215587
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("a", "b", "c", "d", "e")
    assert moved_attribute_0.name == "a"
    assert moved_attribute_0.new_mod == "c"
    assert moved_attribute_0.new_attr == "e"


# Generated at 2022-06-25 22:32:00.518286
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule() is None


# Generated at 2022-06-25 22:32:06.542044
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert isinstance(test_case_0, MovedAttribute) is True
    assert moved_attribute_0.name is None
    assert moved_attribute_0.new_mod is None
    assert moved_attribute_0.new_attr is None


# Generated at 2022-06-25 22:32:11.992280
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert moved_attribute_0.name == None
    assert moved_attribute_0.new_mod == None
    moved_attribute_1 = MovedAttribute('1', '2', '3', '4', '5')
    assert moved_attribute_1.new_mod == '3'
    assert moved_attribute_1.name == '1'


# Generated at 2022-06-25 22:32:15.026932
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_1 = MovedAttribute()
    assert isinstance(moved_attribute_1, MovedAttribute)


# Generated at 2022-06-25 22:32:16.631260
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:32:19.738301
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()


# Generated at 2022-06-25 22:32:21.742937
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().target == (2, 7)
    assert SixMovesTransformer().dependencies == ['six']

# Generated at 2022-06-25 22:32:31.720501
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()
    moved_module_1 = MovedModule(name='name_0', old='old_0')
    moved_module_2 = MovedModule(name='name_1', old='old_1')
    moved_module_3 = MovedModule(name='name_2', old='old_2')
    assert moved_module_0.name == ''
    assert moved_module_2.name == 'name_1'
    assert moved_module_3.name == 'name_2'
    assert moved_module_1.old == 'old_0'
    assert moved_module_3.old == 'old_2'
    assert moved_module_0.new == ''
    assert moved_module_1.new == 'old_0'

# Generated at 2022-06-25 22:32:33.539534
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with raises(TypeError):
        moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:32:36.481758
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().transforms == _get_rewrites()
    assert SixMovesTransformer().dependencies == ['six']


# Generated at 2022-06-25 22:32:39.068402
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name="name", old="old", new="new")
    assert moved_module.__class__.__name__ == "MovedModule"



# Generated at 2022-06-25 22:32:50.693323
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from jedi._compatibility import use_metaclass
    from jedi.evaluate.cache import evaluator_method_cache
    from jedi.evaluate.helpers import FakeName
    from jedi.evaluate import compiled
    from jedi.parser import tree
    from jedi.parser import tokenize

    class PropagationMixin:
        def __init__(self, evaluator=None):
            self._evaluator = evaluator

    class ClassMixin:
        @evaluator_method_cache()
        def execute_evaluated(self):
            # This method is only used in compiled objects.
            return FakeName(None, 'Tuple')


# Generated at 2022-06-25 22:32:58.544907
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Instantiating MovedAttribute with various parameters
    moved_attribute_0 = MovedAttribute(name='name', old_mod='old_mod', new_mod='new_mod', old_attr='old_attr', new_attr='new_attr')
    # Accessing attributes
    assert moved_attribute_0.name == 'name'
    assert moved_attribute_0.new_mod == 'new_mod'
    assert moved_attribute_0.new_attr == 'new_attr'
    # Assigning attributes
    moved_attribute_0.name = 'str'
    moved_attribute_0.new_mod = 'str'
    moved_attribute_0.new_attr = 'str'
    # Testing for constructor errors

# Generated at 2022-06-25 22:33:08.024557
# Unit test for constructor of class MovedModule
def test_MovedModule():
    passed = True
    module_0 = MovedModule("mod_0", "new_0")
    module_1 = MovedModule("mod_1", "new_1")
    module_2 = MovedModule("mod_2", "new_2")
    module_3 = MovedModule("mod_3", "new_3")
    assert module_0.name == "mod_0"
    assert module_0.new == "new_0"
    assert module_1.name == "mod_1"
    assert module_1.new == "new_1"
    assert module_2.name == "mod_2"
    assert module_2.new == "new_2"
    assert module_3.name == "mod_3"
    assert module_3.new == "new_3"

# Generated at 2022-06-25 22:33:10.644777
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        SixMovesTransformer()
    except:
        assert False, "Could not create instance of SixMovesTransformer"

# Generated at 2022-06-25 22:33:21.392127
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '\n'
    str_1 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_1,)
    int_0 = None
    moved_module_0 = MovedModule(str_0, int_0)
    list_0 = [str_1]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)


# Generated at 2022-06-25 22:33:30.015038
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '3RO%!be-?7VuHr6$h*V'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)


# Generated at 2022-06-25 22:33:40.254845
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    int_0 = None
    six_moves_transformer_0 = SixMovesTransformer(int_0)

# Generated at 2022-06-25 22:33:49.528533
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    str_2 = '*qz7Z,1$+#1'
    str_3 = '*qz7Z,1$+#1'
    int_1

# Generated at 2022-06-25 22:33:50.363380
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()


# Generated at 2022-06-25 22:33:55.216068
# Unit test for constructor of class MovedModule
def test_MovedModule():
    arg1 = object()
    arg2 = object()
    arg3 = object()

    test_MovedModule_0 = MovedModule(arg1, arg2)
    assert test_MovedModule_0.name == arg1
    assert test_MovedModule_0.old == arg2
    assert test_MovedModule_0.new == arg2

    test_MovedModule_1 = MovedModule(arg1, arg2, arg3)
    assert test_MovedModule_1.name == arg1
    assert test_MovedModule_1.old == arg2
    assert test_MovedModule_1.new == arg3

# Generated at 2022-06-25 22:33:58.267326
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case = inspect.getfile(inspect.currentframe())
    test_case_0()
    assert os.path.basename(test_case) == 'test_six_moves.py'


# Generated at 2022-06-25 22:34:00.816437
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sixmovestransformer_obj = SixMovesTransformer()
    test_case_0()
    assert sixmovestransformer_obj is not None


# Generated at 2022-06-25 22:34:10.977194
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'TZ@48G<2ExA=,r'
    tuple_0 = (str_0,)
    str_1 = '\a'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    assert moved_attribute_0.new_mod == str_0
    assert moved_attribute_0.name == moved_module_0
    assert moved_attribute_0.new_mod == tuple_0


# Generated at 2022-06-25 22:34:12.572251
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_1 = '2'
    assert callable(SixMovesTransformer)


# Generated at 2022-06-25 22:34:26.976415
# Unit test for constructor of class MovedModule

# Generated at 2022-06-25 22:34:36.420988
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:34:37.807739
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:34:46.150886
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_0, int_0)
    list_0 = [moved_module_0, moved_module_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_attribute_1 = MovedAttribute(moved_module_0, list_0, a_s_t_0)


# Generated at 2022-06-25 22:34:56.856607
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'o\x7f\x1c\x1d\x1d\x1c\x1e'
    tuple_0 = (str_0,)
    str_1 = '<F\x06\x06\x06\x06\x06'
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, int_0, str_1)
    str_2 = '\x1d\x1c\x1e\x1d\x1d\x1e#'
    str_3 = '\x1d\x1c\x1e\x1d\x1d\x1e#'
    int_1 = None
    moved_attribute_1 = MovedAttribute(str_2, str_3, int_1)
    str

# Generated at 2022-06-25 22:35:04.982732
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'T(T`M9,_|H*>c'
    float_0 = float(0.0)
    moved_module_0 = MovedModule(float_0, str_0)
    moved_attribute_0 = MovedAttribute(float_0, str_0, moved_module_0)
    six_moves_transformer_0 = SixMovesTransformer(float_0, moved_module_0, moved_attribute_0)
    moved_attribute_1 = MovedAttribute(float_0, moved_module_0, six_moves_transformer_0)


# Generated at 2022-06-25 22:35:16.116375
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    assert moved_module_0.new == int_0
    assert moved_module_0.name == str_1
    assert moved_module_1.new == moved_attribute_

# Generated at 2022-06-25 22:35:26.258690
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    assert str(moved_module_1.name) == 'None'
    assert not hasattr(moved_module_1, 'new')



# Generated at 2022-06-25 22:35:28.039005
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    r = 0
    test_SixMovesTransformer_0 = SixMovesTransformer()



# Generated at 2022-06-25 22:35:31.195431
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '\n'
    int_0 = None
    test_MovedModule_0 = MovedModule(str_0, int_0)
    assert isinstance(test_MovedModule_0, MovedModule)


# Generated at 2022-06-25 22:35:47.606815
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_0, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    str_1 = None
    int_1 = None
    moved_module_1 = MovedModule(str_1, int_1)
    list_1 = [moved_module_1, str_0]
    a_s_t_1 = None
    moved_attribute_1 = MovedAttribute(moved_module_1, list_1, a_s_t_1)

# Generated at 2022-06-25 22:35:57.535709
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import ast
    import unittest

    class TestRewriteSixMovesVisitor(unittest.TestCase):
        def _run_test(self, code, expected):
            tree = ast.parse(code)
            code = compile(tree, '', 'exec')
            globals = {}
            expected = globals.copy()
            exec(expected, expected)
            SixMovesTransformer.visit(tree)
            echo_code = compile(tree, '', 'exec')
            echo_globals = {}
            exec(echo_code, echo_globals)
            self.assertEqual(globals, echo_globals, code)
            self.assertEqual(expected, echo_globals, code)

        def test_six_rewrites(self):
            from six.moves import configparser

# Generated at 2022-06-25 22:36:02.841744
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    assert moved_attribute_0


# Generated at 2022-06-25 22:36:11.971797
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'sk^vG@fQA(b6#Zg6CH'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)


# Generated at 2022-06-25 22:36:14.590463
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        test_case_0()
    except Exception:
        pass
        # go to next test


# Generated at 2022-06-25 22:36:21.797404
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'jn'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    transformer = SixMovesTransformer()


# Generated at 2022-06-25 22:36:23.513593
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None

    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:36:32.847546
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    assert moved_attribute_0.name == moved_module_0
    assert moved_attribute_0.new_mod == list_0
    assert moved_attribute_0.old_attr is None
    assert moved_attribute_0.new_attr is None

# Generated at 2022-06-25 22:36:40.217125
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '\n'
    str_1 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_1,)
    int_0 = None
    moved_module_0 = MovedModule(str_0, int_0)
    moved_attribute_0 = MovedAttribute(moved_module_0, tuple_0, moved_module_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)


# Generated at 2022-06-25 22:36:50.718467
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-25 22:37:13.511067
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    int_1 = None
    six_moves_transformer_0 = SixMovesTransformer(moved_attribute_0)
    int_1 = None
    six_

# Generated at 2022-06-25 22:37:20.424214
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    set_0 = set()
    dict_0 = dict()
    int_0 = None
    test_case_0()
    six_moves_transformer_0 = SixMovesTransformer(set_0, dict_0, int_0)
    str_0 = 'shl#qj\r(Zz'
    str_1 = 'Rd$j#:Qu2'
    str_2 = '8Fv)4{G\x0e'
    str_3 = 'NtjK\t'
    str_4 = '@Dh'
    str_5 = 'P,Z2!FN'
    str_6 = '\r'
    str_7 = '#J}'
    str_8 = 'sF6|'
    str_9 = 'xy,\r'
   

# Generated at 2022-06-25 22:37:31.524762
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = '6'
    tuple_0 = (str_0,)
    str_1 = 'p4tnFnV7(u#nk'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    list_1 = [moved_module_1, moved_module_0]
    moved_module_2 = MovedModule(list_1, moved_attribute_0)

# Generated at 2022-06-25 22:37:41.360984
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    assert moved_attribute_0.name is moved_module_0
    assert moved_attribute_0.new_mod is list_0
    assert moved_attribute_0.new_attr is None


# Generated at 2022-06-25 22:37:50.257144
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test assertions
    try:
        str_0 = 'X8Mk7r)3b2u.7V#v*'
        tuple_0 = (str_0,)
        str_1 = '\n'
        int_0 = None
        moved_module_0 = MovedModule(str_1, int_0)
        list_0 = [moved_module_0, str_0]
        a_s_t_0 = None
        moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
        moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    except Exception:
        assert False



# Generated at 2022-06-25 22:37:59.293397
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    test_SixMovesTransformer = SixMovesTransformer('six.moves')
    assert test_SixMovesTransformer.target == (2, 7)

# Generated at 2022-06-25 22:38:08.790176
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'k3WX+v%<Jx(jK?.QMwI'
    tuple_0 = ()
    moved_attribute_0 = MovedAttribute(str_0, tuple_0)
    sixmovestransformer_0 = SixMovesTransformer(moved_attribute_0)
    assert sixmovestransformer_0.dependencies == ['six']
    assert sixmovestransformer_0.target[0] == 2
    assert sixmovestransformer_0.rewrites[0][0] == 'os.getcwd'
    assert sixmovestransformer_0.rewrites[0][1] == 'six.moves.os.getcwdu'

# Generated at 2022-06-25 22:38:09.949196
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule('', ''), MovedModule)


# Generated at 2022-06-25 22:38:16.664528
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'Dy,B&[q13#/AzXhxT#T'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)



# Generated at 2022-06-25 22:38:25.526036
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '6_1\\fD`\\'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    try:
        moved_module_2 = MovedModule(tuple_0, moved_attribute_0)
    except TypeError:
        pass


# Generated at 2022-06-25 22:38:55.242688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(None, None, None, None, None)
    assert isinstance(moved_attribute_0, MovedAttribute)


# Generated at 2022-06-25 22:38:57.419869
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_2 = 'DC'
    int_1 = None
    moved_module_2 = MovedModule(str_2, int_1)



# Generated at 2022-06-25 22:39:02.778337
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '6zA2LF@mi'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(tuple_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)


# Generated at 2022-06-25 22:39:05.422322
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert isinstance(instance, SixMovesTransformer)


# Generated at 2022-06-25 22:39:13.035375
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_0, int_0)
    list_0 = [str_0, int_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, moved_module_0, list_0, a_s_t_0) # TypeError: __init__() takes at most 3 arguments (5 given)
    assert_equal(moved_attribute_0.getName(), None) # AttributeError: 'NoneType' object has no attribute 'getName'


# Generated at 2022-06-25 22:39:24.326601
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'Fzf)vD!W@,x(1#uRy7T'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    list_1 = list(moved_module_1)

# Generated at 2022-06-25 22:39:32.466236
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)

# Generated at 2022-06-25 22:39:39.849612
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'O8#Yr(bF#,(xA9d^7r'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)


# Generated at 2022-06-25 22:39:50.305387
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  str_0 = 'O8#Yr(bF#,(xA9d^7r'
  tuple_0 = (str_0,)
  str_1 = '\n'
  int_0 = None
  moved_module_0 = MovedModule(str_1, int_0)
  list_0 = [moved_module_0, str_0]
  a_s_t_0 = None
  moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
  str_2 = 'O8#Yr(bF#,(xA9d^7r'
  tuple_1 = []
  str_3 = '\n'
  moved_module_1 = MovedModule(str_3, str_3)
  a

# Generated at 2022-06-25 22:39:55.289660
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_0, int_0)
    assert moved_module_0.name == str_0
    assert moved_module_0.new == str_0
    tuple_0 = ('',)
    moved_module_0 = MovedModule(tuple_0, tuple_0)
    assert moved_module_0.name == tuple_0
    assert moved_module_0.new == tuple_0


# Generated at 2022-06-25 22:41:08.806189
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = '\n'
    tuple_0 = (str_0,)
    str_1 = '\n'
    int_0 = None
    moved_module_0 = MovedModule(str_1, int_0)
    list_0 = [moved_module_0, str_0]
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, list_0, a_s_t_0)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    pass