

# Generated at 2022-06-25 22:31:15.562766
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moves_list = []

    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                moves_list.append(move)

    assert len(moves_list) == 37

# Generated at 2022-06-25 22:31:19.063512
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    file_path = "/var/log/syslog"
    source_code = "import six.moves.urllib.parse"
    six_moves_transformer = SixMovesTransformer(file_path, source_code)


# Generated at 2022-06-25 22:31:22.435137
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = dict
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    assert moved_module_0.name == dict_0
    assert moved_module_0.new == dict_0



# Generated at 2022-06-25 22:31:25.096784
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = "xyzzy"
    list_0 = [str_0, str_0]
    moved_module_0 = MovedModule(str_0, list_0, list_0)


# Generated at 2022-06-25 22:31:33.703054
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_0 = 302.16
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    # Verify that the constructor doesn't raise an exception
    try:
        moved_attribute_0 = MovedAttribute(float_0, dict_0, dict_0)
    except Exception as e:
        print(e)
        assert False
    # Verify that the constructor doesn't raise an exception
    try:
        moved_attribute_1 = MovedAttribute(float_0, dict_0, dict_0)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 22:31:36.182897
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('test_name', 'test_old', 'test_new')

# Generated at 2022-06-25 22:31:38.223357
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("", "", "")


# Generated at 2022-06-25 22:31:39.697360
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(" ", " ", " ")


# Generated at 2022-06-25 22:31:43.746328
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_0 = 302.16
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    moved_attribute_0 = MovedAttribute(float_0, dict_0, dict_0)


# Generated at 2022-06-25 22:31:50.565063
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        float_0 = 302.16
        dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
        moved_attribute_0 = MovedAttribute(float_0, dict_0, dict_0)
        dict_1 = {float_0: float_0, float_0: float_0, float_0: float_0}
        moved_module_0 = MovedModule(float_0, dict_1, dict_1)
        six_moves_transformer_0 = SixMovesTransformer()
        _get_rewrites()
    except Exception as excep:
        print(excep)

# Generated at 2022-06-25 22:31:56.615506
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        str_0 = "1"
        assert isinstance(SixMovesTransformer(str_0), BaseImportRewrite)
    except Exception:
        print("Error while testing SixMovesTransformer")
        raise


# Generated at 2022-06-25 22:32:04.827279
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    str_0 = six_moves_transformer_0.description
    str_1 = "Replaces moved modules with ones from `six.moves`."
    assert str_0 == str_1
    str_2 = six_moves_transformer_0.name
    str_3 = 'sixmoves'
    assert str_2 == str_3

# Generated at 2022-06-25 22:32:08.600344
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Declarations
    str_0 = "test"
    str_1 = "'os"
    str_2 = "test"
    str_3 = "'os"
    # Setup
    # Exercise

    # Verify
    assert str_0 == str_1


# Generated at 2022-06-25 22:32:13.173902
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = "0"
    str_1 = "1"
    moved_attribute_0 = MovedAttribute(str_0,
                                       str_1,
                                       str_0,
                                       str_0,
                                       str_1)


# Generated at 2022-06-25 22:32:16.780770
# Unit test for constructor of class MovedModule
def test_MovedModule():
    string_0 = 'abc'
    moved_module_0 = MovedModule(string_0, string_0, string_0)
    assert moved_module_0 != None


# Generated at 2022-06-25 22:32:28.001176
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_attribute_0 = MovedAttribute('foo', 'foo', 'foo')
    moved_attribute_1 = MovedAttribute('foo', None, 'foo')
    moved_attribute_2 = MovedAttribute('foo', 'foo', None)
    moved_attribute_3 = MovedAttribute('foo', 'foo', 'foo', 'bar', 'baz')
    moved_attribute_4 = MovedAttribute('foo', 'foo', 'foo', 'bar', None)
    moved_module_0 = MovedModule('foo', 'foo')
    moved_module_1 = MovedModule('foo', 'foo', 'bar')
    prefixed_moves_0 = [('', [moved_attribute_0, moved_module_0])]

# Generated at 2022-06-25 22:32:29.193620
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:32:30.644486
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()


# Generated at 2022-06-25 22:32:32.652412
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert six_moves_transformer_0

# Generated at 2022-06-25 22:32:38.731595
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_attribute_1 = MovedAttribute('io', 'six', None, None, None)
    # Invoke constructor of class SixMovesTransformer
    six_moves_transformer_0 = SixMovesTransformer(moved_attribute_1, moved_attribute_1, moved_attribute_1, moved_attribute_1, moved_attribute_1)
    assert six_moves_transformer_0 is not None

# Generated at 2022-06-25 22:32:44.026584
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule('name', 'old', 'new')
    assert(test_moved_module.name == 'name')
    assert(test_moved_module.new == 'new')


# Generated at 2022-06-25 22:32:54.657779
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def testmethod_0():
        name_0 = ''
        six_moves_transformer_0 = SixMovesTransformer(name_0)

        name_0 = 'abc'
        six_moves_transformer_0 = SixMovesTransformer(name_0)

    def testmethod_1():
        name_0 = ''
        six_moves_transformer_0 = SixMovesTransformer(name_0)

        six_moves_transformer_0 = SixMovesTransformer()

    def testmethod_2():
        six_moves_transformer_0 = SixMovesTransformer()

        six_moves_transformer_0 = SixMovesTransformer()

    def testmethod_3():
        name_0 = 'abc'
        six_moves_transformer_0 = SixMovesTrans

# Generated at 2022-06-25 22:32:58.323150
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_1 = SixMovesTransformer()
    assert isinstance(six_moves_transformer_1,SixMovesTransformer)


# Generated at 2022-06-25 22:33:05.306955
# Unit test for constructor of class MovedModule
def test_MovedModule():
    testClass = MovedModule("name", "old", "new")
    assert testClass.name is "name"
    assert testClass.old is "old"
    assert testClass.new is "new"
    testClass.name = "Newname"
    testClass.old = "Old"
    testClass.new = "New"
    assert testClass.name is "Newname"
    assert testClass.old is "Old"
    assert testClass.new is "New"


# Generated at 2022-06-25 22:33:17.340912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert moved_attribute.__init__('cStringIO', 'cStringIO', 'io', 'StringIO') == None
    assert moved_attribute.name == 'cStringIO'
    assert moved_attribute.old_mod == 'cStringIO'
    assert moved_attribute.new_mod == 'io'
    assert moved_attribute.old_attr == 'StringIO'
    assert moved_attribute.new_attr == None
    moved_attribute = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert moved_attribute.name == 'filter'
    assert moved_attribute.old_mod == 'itertools'
    assert moved_attribute.new_mod == 'builtins'
   

# Generated at 2022-06-25 22:33:18.351341
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer() is not None


# Generated at 2022-06-25 22:33:19.416968
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass


# Generated at 2022-06-25 22:33:20.785571
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old")


# Generated at 2022-06-25 22:33:23.475890
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer is not None


# Generated at 2022-06-25 22:33:33.422990
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Case 1. MovedModule(name, old, new)
    moved_module_0 = MovedModule('name', 'old', 'new')
    assert (moved_module_0.name == 'name')
    assert (moved_module_0.old == 'old')
    assert (moved_module_0.new == 'new')

    # Case 2. MovedModule(name, old)
    moved_module_1 = MovedModule('name', 'old')
    assert (moved_module_1.name == 'name')
    assert (moved_module_1.old == 'old')
    assert (moved_module_1.new == 'name')


# Generated at 2022-06-25 22:33:45.171294
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = -2433
    six_moves_transformer_0 = SixMovesTransformer(int_0)
    int_1 = -924
    six_moves_transformer_1 = SixMovesTransformer(int_1)
    int_2 = -924
    str_0 = 'tkinter_colorchooser'
    int_3 = 1679
    str_1 = 'tkinter_colorchooser'
    int_4 = -2566
    six_moves_transformer_2 = SixMovesTransformer(int_4)
    float_0 = 88.43
    str_2 = 'tkinter_colorchooser'
    int_5 = 2482
    str_3 = 'tkinter_colorchooser'
    str_4 = 'tkinter_colorchooser'
    int

# Generated at 2022-06-25 22:33:53.147143
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    set_0 = {float_0, float_0, float_0, float_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_0, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_0, str_1: float_0}

# Generated at 2022-06-25 22:34:04.765980
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 0
    float_0 = 0.0
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_0, int_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_0, str_1: float_0}
    moved_attribute_1 = MovedAttribute(int_1, a_s_t_0, float_0, dict_0, str_0)
    str_2 = 'tkinter_colorchooser'
    str_3 = 'OSAA3EA]?x\\g'

# Generated at 2022-06-25 22:34:11.298081
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_module_0 = MovedModule('tkinter_colorchooser', 'a_s_t_0', 'six_moves_transformer_0')

    result = moved_module_0.name
    assert result == 'tkinter_colorchooser'

    result = moved_module_0.old
    assert result == 'a_s_t_0'

    result = moved_module_0.new
    assert result == 'six_moves_transformer_0'


# Generated at 2022-06-25 22:34:13.745021
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    with pytest.raises(TypeError):
        SixMovesTransformer(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 22:34:17.906488
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_list = [int, str, float]
    for arg0 in a_list:
        for arg1 in a_list:
            for arg2 in a_list:
                for arg3 in a_list:
                    for arg4 in a_list:
                        try:
                            MovedAttribute(arg0, arg1, arg2, arg3, arg4)
                        except TypeError:
                            pass


# Generated at 2022-06-25 22:34:30.483215
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(2962, -2530.0, a_s_t_0)
    set_0 = {-2530.0, -2530.0, a_s_t_0, 2962}
    moved_attribute_1 = MovedAttribute(-1244, six_moves_transformer_0, -2530.0)
    dict_0 = {'tkinter_colorchooser': a_s_t_0, 'OSAA3EA]?x\\g': -2530.0}

# Generated at 2022-06-25 22:34:43.213603
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1

# Generated at 2022-06-25 22:34:54.441646
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert (not hasattr(six_moves_transformer_0, "ratio"))
    assert (not hasattr(six_moves_transformer_0, "x"))
    assert (not hasattr(six_moves_transformer_0, "y"))
    assert (not hasattr(six_moves_transformer_0, "a"))
    assert (not hasattr(six_moves_transformer_0, "z"))
    assert (not hasattr(six_moves_transformer_0, "d"))


# Generated at 2022-06-25 22:35:04.893669
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = -1315
    str_0 = '__main__'
    float_0 = -2795.0
    a_s_t_0 = AST()
    dict_0 = {}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_0, dict_0)
    a_s_t_1 = AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_1)
    set_0 = {float_0, float_0, six_moves_transformer_0, int_0}
    moved_attribute_1 = MovedAttribute(str_0, float_0, a_s_t_1, set_0)


# Generated at 2022-06-25 22:35:09.678882
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule_0 = MovedModule('UserDict', 'UserDict', 'collections')


# Generated at 2022-06-25 22:35:20.830074
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1

# Generated at 2022-06-25 22:35:27.563126
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 5
    float_0 = -6872.59
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(int_0, six_moves_transformer_0, float_0)
    assert (moved_attribute_0.name == int_0)
    assert (moved_attribute_0.new_mod == six_moves_transformer_0)
    assert (moved_attribute_0.new_attr == float_0)


# Generated at 2022-06-25 22:35:37.329888
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -4165
    str_0 = 'l$\'W8{'
    str_1 = '_'
    six_moves_transformer_0 = SixMovesTransformer(str_1)
    six_moves_transformer_0 = SixMovesTransformer(six_moves_transformer_0)
    str_2 = 'tksimpledialog'
    six_moves_transformer_1 = SixMovesTransformer(str_2)
    six_moves_transformer_1 = SixMovesTransformer(six_moves_transformer_1)
    float_0 = -0.005254922594458967
    six_moves_transformer_2 = SixMovesTransformer(float_0)
    six_moves_transformer_2 = SixMoves

# Generated at 2022-06-25 22:35:42.497431
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.ast == a_s_t_0


# Generated at 2022-06-25 22:35:43.863315
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()


# Generated at 2022-06-25 22:35:52.128957
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # a new object of MovedModule is created and assigned to variable m1
    m1 = MovedModule(14, 'tkinter_font', 'tkinter.font')

    # check if the object m1 is of type MovedModule
    assert isinstance(m1, MovedModule)

    # check if the object m1 is not of type MovedAttribute
    assert not isinstance(m1, MovedAttribute)

    # check if the class MovedModule is a subclass of object
    assert issubclass(MovedModule, object)

    # check if the class MovedModule is not a subclass of MovedAttribute
    assert not issubclass(MovedModule, MovedAttribute)



# Generated at 2022-06-25 22:35:53.826328
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert True


# Generated at 2022-06-25 22:35:58.502914
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:36:01.915061
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule(-2962.0, 'ltC&', None)
    assert obj.name == -2962.0
    assert obj.new == 'ltC&'


# Generated at 2022-06-25 22:36:16.594175
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {1:2, 3:4, 5:6}
    # Test 1: Constructor with no arguments
    try:
        move = MovedAttribute()
    except TypeError:
        assert True
    # Test 2: Constructor with one argument
    try:
        move = MovedAttribute('ti')
    except TypeError:
        assert True
    # Test 3: Constructor with two arguments
    try:
        move = MovedAttribute(1, 'vim')
    except TypeError:
        assert True
    # Test 4: Constructor with three arguments
    try:
        move = MovedAttribute(1, 'vim', 99)
    except TypeError:
        assert True
    # Test 5: Constructor with four arguments

# Generated at 2022-06-25 22:36:19.774449
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -33
    six_moves_transformer_0 = SixMovesTransformer(int_0)
    str_0 = 'Tix'
    str_1 = 'six.moves.tkinter_tix'
    moved_module_0 = MovedModule(str_0, six_moves_transformer_0, str_1)

# Generated at 2022-06-25 22:36:29.208449
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Constructor Test for MovedAttribute"""
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    assert moved_attribute_0.name == int_0
    assert moved_attribute_0.old_mod == float_0
    assert moved_attribute_0.new_mod == a_s_t_1

# Generated at 2022-06-25 22:36:33.849052
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = 0
    str_0 = 'MovedAttribute'
    moved_attribute_0 = MovedAttribute(int_0, int_0, int_0, str_0)
    str_1 = 'moved_module_0'
    moved_module_0 = MovedModule(int_0, moved_attribute_0, str_1)



# Generated at 2022-06-25 22:36:35.258360
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()



# Generated at 2022-06-25 22:36:36.940471
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute


# Generated at 2022-06-25 22:36:46.832226
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'J*a(`k\xDC1}'
    str_1 = 'email_mime_base'
    str_2 = '_thread'
    moved_module_0 = MovedModule(str_0, a_s_t_1, str_1)
    moved_module_1 = MovedModule(str_2, a_s_t_1)
    int_0 = 1534
    dict_0 = {str_2: float_0, float_0: a_s_t_1, str_1: int_0}
    moved_attribute_0 = MovedAttribute('queue', a_s_t_1, moved_attribute_1, dict_0, moved_module_1)


# Generated at 2022-06-25 22:36:56.155144
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1

# Generated at 2022-06-25 22:37:01.703276
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'urllib_robotparser'
    str_1 = 'urllib.robotparser'
    float_0 = -76.0
    float_1 = -10.0
    moved_module_0 = MovedModule(str_0, float_0, float_1)


# Generated at 2022-06-25 22:37:06.006481
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:37:17.217450
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert 0 == 1

# Generated at 2022-06-25 22:37:21.552810
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_2 = 5048
    str_2 = 'Y'
    float_1 = 0.960380375346926
    str_3 = 'u`\'\\^B7jYT'
    moved_attribute_2 = MovedAttribute(int_2, float_1, str_2, str_3)


# Generated at 2022-06-25 22:37:32.484425
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = -59
    float_0 = 2242.197
    str_0 = '`)7;d5a^f'
    str_1 = 'os'
    str_2 = 'H~^wc<>:V\x02\x1e'
    dict_0 = {str_0: float_0}
    dict_1 = {str_0: float_0}
    dict_2 = {str_1: dict_0, str_2: dict_1}
    dict_3 = {str_0: float_0}
    dict_4 = {str_0: float_0}
    dict_5 = {str_1: dict_3, str_2: dict_4}
    dict_6 = {str_0: float_0}

# Generated at 2022-06-25 22:37:39.874806
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -6114
    int_1 = -3
    str_0 = 'tkinter_colorchooser'
    dict_0 = {int_0: float, float: str_0}
    moved_module_0 = MovedModule(float, dict_0, int_1)
    str_1 = 'tkinter_colorchooser'
    dict_1 = {int_1: int_0, int_0: str_1}
    moved_module_1 = MovedModule(str_0, dict_1)


# Generated at 2022-06-25 22:37:45.002350
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_0, str_1: float_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_0, dict_0)

# Generated at 2022-06-25 22:37:51.575937
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.dependencies == ['six']
    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.rewrites == _get_rewrites()


# Generated at 2022-06-25 22:37:52.460337
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass


# Generated at 2022-06-25 22:38:02.644645
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1

# Generated at 2022-06-25 22:38:10.849534
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1

# Generated at 2022-06-25 22:38:12.322873
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test instance void MovedModule(String, String)
    test_case_0()


# Generated at 2022-06-25 22:38:42.859177
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -2646
    float_0 = -12.0
    str_0 = '{'
    str_1 = ')'
    int_1 = 3284
    moved_module_0 = MovedModule(int_0, str_0, float_0, str_1, int_1)


# Generated at 2022-06-25 22:38:45.310426
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        moved_module_0 = MovedModule(str_0, moved_attribute_0)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-25 22:38:50.440171
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1 = MovedAttribute(int_1, six_moves_transformer_0, float_0, dict_0, str_0)


# Generated at 2022-06-25 22:38:58.428722
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = 2962
    float_0 = -2530.0
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    set_0 = {float_0, float_0, a_s_t_1, int_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
    int_1 = -1244
    str_0 = 'tkinter_colorchooser'
    str_1 = 'OSAA3EA]?x\\g'
    dict_0 = {str_0: a_s_t_1, str_1: float_0}
    moved_attribute_1

# Generated at 2022-06-25 22:39:07.369841
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -1776
    int_1 = -2285
    str_0 = 'tkinter_colorchooser'
    str_1 = 'tkinter_dnd'
    moved_module_0 = MovedModule(str_1, str_0, int_1)
    assert(moved_module_0.name == str_1 and moved_module_0.old == str_0 and moved_module_0.new == int_1)
    moved_module_0 = MovedModule(int_0, int_0)
    assert(moved_module_0.name == int_0 and moved_module_0.old == int_0 and moved_module_0.new == int_0)


# Generated at 2022-06-25 22:39:17.165758
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
	int_0 = 2962
	float_0 = -2530.0
	a_s_t_0 = None
	six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
	a_s_t_1 = None
	set_0 = {float_0, float_0, a_s_t_1, int_0}
	moved_attribute_0 = MovedAttribute(int_0, float_0, a_s_t_1, set_0)
	assert moved_attribute_0.name == int_0
	assert moved_attribute_0.old_mod == float_0
	assert moved_attribute_0.new_mod == a_s_t_1
	assert moved_attribute_0.old_attr == set_0
	assert moved_attribute_

# Generated at 2022-06-25 22:39:28.143276
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 2836
    float_0 = -2179.0
    str_0 = 'tkinter_dnd'
    str_1 = '2'
    six_moves_transformer_0 = SixMovesTransformer(str_0)
    a_s_t_0 = None
    set_0 = {a_s_t_0, int_0, str_1, float_0, a_s_t_0}
    moved_attribute_0 = MovedAttribute(int_0, float_0, six_moves_transformer_0, set_0)

    assert (moved_attribute_0.name == int_0)
    assert (moved_attribute_0.new_mod == float_0)

# Generated at 2022-06-25 22:39:30.875347
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 is not None


# Generated at 2022-06-25 22:39:41.479867
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = 2728
    str_0 = 'py_compile'
    six_moves_transformer_0 = SixMovesTransformer(int_0)
    dict_0 = {int_0: str_0}
    six_moves_transformer_0.rewrites = dict_0
    int_1 = -3220
    float_0 = 4851.0
    float_1 = -1224.0
    a_s_t_0 = None
    moved_module_0 = MovedModule(int_1, float_0, float_1)
    int_2 = -5443
    int_3 = -1777
    str_1 = 'Builtins'
    str_2 = 'tkinter_simpledialog'
    a_s_t_1 = None
    moved_attribute_

# Generated at 2022-06-25 22:39:51.257145
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = -44
    float_0 = -541.0
    str_0 = 'tkinter'
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = None
    six_moves_transformer_1 = SixMovesTransformer.__new__(SixMovesTransformer)
    six_moves_transformer_1.six_moves_transformer_0 = a_s_t_1
    six_moves_transformer_1.six_moves_transformer_1 = a_s_t_0
    six_moves_transformer_1.six_moves_transformer_2 = float_0

# Generated at 2022-06-25 22:40:50.784079
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute(1, 2, 3, 4)


# Generated at 2022-06-25 22:40:57.756423
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # Check argument call
    float_0 = -2530.0
    int_0 = 2962
    str_0 = 'tkinter_colorchooser'
    moved_module_0 = MovedModule(float_0, str_0, int_0)
    dict_0 = {str_0: float_0, float_0: float_0}
    moved_module_0 = MovedModule(str_0, int_0, dict_0)

    # Check nb of args call
    moved_module_1 = MovedModule(int_0, int_0)



# Generated at 2022-06-25 22:41:01.128655
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -1773
    float_0 = 8565.0
    moved_module_0 = MovedModule(float_0, int_0)
    assert(moved_module_0.name == float_0)
    assert(moved_module_0.new == int_0)


# Generated at 2022-06-25 22:41:03.211480
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moves_transformer_0 = SixMovesTransformer()
    assert six_moves_transformer_0.rewrites == _get_rewrites()

# Generated at 2022-06-25 22:41:11.078116
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = -2530
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = -2530.0
    moved_module_0 = MovedModule(int_0, a_s_t_0, six_moves_transformer_0)
    str_0 = 'tkinter_colorchooser'
    int_1 = 2962
    moved_module_1 = MovedModule(str_0, six_moves_transformer_0, int_1)
    moved_attribute_0 = MovedAttribute(int_0, six_moves_transformer_0, moved_module_0, a_s_t_0, moved_module_1)
