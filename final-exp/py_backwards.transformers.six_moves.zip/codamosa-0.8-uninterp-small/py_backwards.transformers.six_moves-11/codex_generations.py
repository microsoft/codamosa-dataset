

# Generated at 2022-06-25 22:31:16.125149
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Constructor tests
    movedmodule_0 = MovedModule('module_name', 'old_module_name')

    movedmodule_0.__init__('module_name', 'old_module_name_0')
    movedmodule_0.__init__('module_name_0', 'old_module_name')
    movedmodule_0.__init__('module_name', 'old_module_name')
    movedmodule_0.__init__('module_name_0', 'old_module_name_0')


# Generated at 2022-06-25 22:31:21.708968
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_name = "module_name"
    old_module = "old_module"
    new_module = "new_module"
    moved_module = MovedModule(module_name, old_module, new_module)
    assert moved_module.name == "module_name"
    assert moved_module.old == "old_module"
    assert moved_module.new == "new_module"


# Generated at 2022-06-25 22:31:24.591148
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute_0 is not None


# Generated at 2022-06-25 22:31:36.087970
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("_thread", "thread", "_thread")
    MovedModule("builtins", "__builtin__")
    MovedModule("configparser", "ConfigParser")
    MovedModule("copyreg", "copy_reg")
    MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread")
    MovedModule("http_cookiejar", "cookielib", "http.cookiejar")
    MovedModule("http_cookies", "Cookie", "http.cookies")
    MovedModule("html_entities", "htmlentitydefs", "html.entities")
    MovedModule("html_parser", "HTMLParser", "html.parser")

# Generated at 2022-06-25 22:31:37.572989
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule_0 = MovedModule(None, None, None)


# Generated at 2022-06-25 22:31:42.128565
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "mod", "new_mod", "old", "new")
    assert ((moved_attribute_0.name == "name") and (moved_attribute_0.new_mod == "new_mod") \
        and (moved_attribute_0.new_attr == "new"))


# Generated at 2022-06-25 22:31:45.989079
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server")
    assert moved_module_0.name == "CGIHTTPServer"
    assert moved_module_0.new == "http.server"


# Generated at 2022-06-25 22:31:46.649893
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:31:49.673391
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
assert isinstance(six_moves_transformer_0, SixMovesTransformer)



# Generated at 2022-06-25 22:31:51.537300
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(name = "builtins", old = "__builtin__")


# Generated at 2022-06-25 22:32:06.204793
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedAttribute("name", "old", "new").name == "name"
    assert MovedAttribute("name", "old", "new").old_mod == "old"
    assert MovedAttribute("name", "old", "new").new_mod == "new"
    assert MovedAttribute("name", "old", "new").old_attr == "name"
    assert MovedAttribute("name", "old", "new").new_attr == "name"
    assert MovedAttribute("name", "old", "new", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old", "new", "old_attr", "new_attr").old_mod == "old"

# Generated at 2022-06-25 22:32:11.215547
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attr_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    print(move_attr_0.name)
    print(move_attr_0.new_mod)
    print(move_attr_0.new_attr)


# Generated at 2022-06-25 22:32:18.833532
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    try:
        six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    except UnboundLocalError as e:
        print('UnboundLocalError:', e)
    except NameError as e:
        print('NameError:', e)
    except TypeError as e:
        print('TypeError:', e)


# Generated at 2022-06-25 22:32:24.088567
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = "test_name"
    old_0 = "test_old"
    new_0 = "test_new"
    moved_module_0 = MovedModule(name_0, old_0, new_0)
    assert moved_module_0.name == name_0
    assert moved_module_0.new == new_0


# Generated at 2022-06-25 22:32:27.515249
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = MovedModule(a_s_t_1, a_s_t_2, a_s_t_3)


# Generated at 2022-06-25 22:32:30.601302
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    test_case_0()

create_test_case_from_actual(test_SixMovesTransformer)

# Generated at 2022-06-25 22:32:34.500452
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert a.name == 'cStringIO'
    assert a.new_mod == 'io'
    assert a.new_attr == 'StringIO'



# Generated at 2022-06-25 22:32:36.717308
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert not 'test_MovedModule' in globals()


# Generated at 2022-06-25 22:32:38.916410
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:32:41.949667
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    
    assert moved_attribute_0.name == 'cStringIO'
    assert moved_attribute_0.new_mod == 'io'
    assert moved_attribute_0.new_attr == 'StringIO'



# Generated at 2022-06-25 22:32:51.044717
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old")
    assert moved_module_0.name == "name"
    assert moved_module_0.new == "name"
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == "name"
    assert moved_module_0.new == "new"


# Generated at 2022-06-25 22:32:53.323699
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:32:56.781817
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert moved_attribute_0.name == 'cStringIO'
    assert moved_attribute_0.new_mod == 'cStringIO'
    assert moved_attribute_0.new_attr == 'StringIO'


# Generated at 2022-06-25 22:33:04.299819
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('__main__', None, None)
    assert moved_attribute_0.name == '__main__'
    moved_attribute_1 = MovedAttribute('__main__', None, None, 'StringIO')
    assert moved_attribute_1.old_attr == 'StringIO'
    moved_attribute_2 = MovedAttribute('__main__', None, None, None, 'input')
    assert moved_attribute_2.new_attr == 'input'


# Generated at 2022-06-25 22:33:11.788590
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    test_SixMovesTransformer_0 = SixMovesTransformer(a_s_t_0)
    assert(isinstance(test_SixMovesTransformer_0, SixMovesTransformer))
    assert(test_SixMovesTransformer_0.target == (2, 7))
    assert(test_SixMovesTransformer_0.rewrites != [])
    assert(test_SixMovesTransformer_0.dependencies == ['six'])


# Generated at 2022-06-25 22:33:17.499721
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_m_a_0 = None
    a_m_a_1 = None
    a_m_a_2 = None

    # Test constructor of MovedAttribute
    a_m_a_3 = MovedAttribute(a_m_a_0, a_m_a_1, a_m_a_2)


# Generated at 2022-06-25 22:33:24.396325
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.dependencies == ['six']
    assert six_moves_transformer_0.app_state == a_s_t_0


# Generated at 2022-06-25 22:33:29.103054
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"



# Generated at 2022-06-25 22:33:35.768828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.__init__ == MovedModule.__init__
    assert moved_module_0.__init__.__globals__ == MovedModule.__init__.__globals__
    assert moved_module_0.__init__.__code__ == MovedModule.__init__.__code__
    assert moved_module_0.__init__ != MovedModule.__init__


# Generated at 2022-06-25 22:33:39.216485
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    s_m_t_0 = SixMovesTransformer(a_s_t_0)
    assert s_m_t_0 is not None

# Generated at 2022-06-25 22:33:48.069171
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "builtins"
    old = "__builtin__"
    mm = MovedModule(name, old)
    assert mm.name == name
    assert mm.old == old
    assert mm.new == name


# Generated at 2022-06-25 22:33:50.907611
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_1 = None
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)


# Generated at 2022-06-25 22:33:55.698865
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"



# Generated at 2022-06-25 22:34:06.272662
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    moved_attribute = MovedAttribute(
        "urllib.request", "urllib2", "urllib.request")
    assert moved_attribute.name == "urllib.request"
    assert moved_attribute.new_mod == "urllib.request"
    assert moved_attribute.new_attr == "urllib.request"

    moved_attribute = MovedAttribute(
        "urllib.request", "urllib2", "urllib.request", "urllib2", "urllib.request")
    assert moved_attribute.name == "urllib.request"
    assert moved_attribute.new_mod == "urllib.request"
    assert moved_attribute.new_attr == "urllib2"



# Generated at 2022-06-25 22:34:09.660924
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "name"
    old = "old"
    new = "new"
    mm = MovedModule(name, old, new)
    assert mm.name == name
    assert mm.new == new


# Generated at 2022-06-25 22:34:13.430929
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.transformations == [six_moves_transformer_0.moves_transform]


# Generated at 2022-06-25 22:34:18.622901
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # to check whether the MovedModule raises an AttributeError when the new parameter is missing
    try:
        moved_module_0 = MovedModule('name', 'old')
    except AttributeError:
        pass
    # to check the value assigned to the name variable
    moved_module_1 = MovedModule('name', 'old', 'new')
    assert moved_module_1.name == 'name'


# Generated at 2022-06-25 22:34:24.328265
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(name='name_p', old='old_p', new='new_p').name == 'name_p'
    assert MovedModule(name='name_p', old='old_p', new='new_p').old == 'old_p'
    assert MovedModule(name='name_p', old='old_p', new='new_p').new == 'new_p'


# Generated at 2022-06-25 22:34:30.123600
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('x', 'y')
    assert moved_module_0.name == 'x'
    assert moved_module_0.old == 'y'
    assert moved_module_0.new == 'x'


# Generated at 2022-06-25 22:34:34.265230
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

test_case_0()
test_SixMovesTransformer()

# Generated at 2022-06-25 22:34:56.194780
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_arg1 = "name"
    moved_module_arg2 = "old"
    moved_module_arg3 = "new"
    moved_module_arg4 = None
    moved_module_obj0 = MovedModule(moved_module_arg1, moved_module_arg2, moved_module_arg3)
    assert moved_module_obj0 is not None
    assert moved_module_obj0.name is not None
    assert moved_module_obj0.new is not None
    assert moved_module_obj0.old is not None
    assert moved_module_obj0.old is not None
    assert moved_module_obj0.old == "old"
    moved_module_obj1 = MovedModule(moved_module_arg1, moved_module_arg2, moved_module_arg4)


# Generated at 2022-06-25 22:34:58.742952
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:35:00.950467
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    six_moves_transformer_0 = SixMovesTransformer(sys)



# Generated at 2022-06-25 22:35:02.062593
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case_MovedModule_0()


# Generated at 2022-06-25 22:35:06.420316
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('foo', 'bar', 'baz', 'quux', 'quux')
    assert moved_attribute_0.name == 'foo'
    assert moved_attribute_0.new_mod == 'baz'
    assert moved_attribute_0.new_attr == 'quux'


# Generated at 2022-06-25 22:35:09.561649
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:13.328278
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    assert SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:16.838340
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    from .six_moves import SixMovesTransformer
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:35:18.980095
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io",
                                       "StringIO")

# Generated at 2022-06-25 22:35:26.410810
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = "test_name"
    old_0 = "test_old"
    new_0 = "test_new"
    moved_module_0 = MovedModule(name_0, old_0, new_0)
    name_1 = moved_module_0.name
    assert(name_1 == name_0)
    old_1 = moved_module_0.old
    assert(old_1 == old_0)
    new_1 = moved_module_0.new
    assert(new_1 == new_0)


# Generated at 2022-06-25 22:35:52.133861
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


if __name__ == '__main__':
    import sys
    sys.exit(unittest.main())

# Generated at 2022-06-25 22:35:54.824505
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    return

# Generated at 2022-06-25 22:35:56.920534
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:04.156274
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_0 = ASTNode(1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    assert six_moves_transformer_0.nodes() == a_s_t_0.nodes()

# Generated at 2022-06-25 22:36:08.363768
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert (six_moves_transformer_0.target == (2, 7))


# Generated at 2022-06-25 22:36:16.051128
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_moved_module_0 = MovedModule("modules", "old_modules")
    assert a_moved_module_0.name == "modules"
    assert a_moved_module_0.old == "old_modules"
    assert a_moved_module_0.new == "modules"
    a_moved_module_1 = MovedModule("modules", "old_modules", "new_modules")
    assert a_moved_module_1.name == "modules"
    assert a_moved_module_1.old == "old_modules"
    assert a_moved_module_1.new == "new_modules"


# Generated at 2022-06-25 22:36:18.685032
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:36:21.028667
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module_0 = MovedModule("name", "old", "new")
    assert move_module_0.name == "name"
    assert move_module_0.new == "new"



# Generated at 2022-06-25 22:36:24.551173
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute_0 = MovedAttribute(0, 0)
    MovedAttribute_1 = MovedAttribute(0, 0, 0, 0)
    MovedAttribute_2 = MovedAttribute(0, 0, 0, 0, 0)
    

# Generated at 2022-06-25 22:36:33.934074
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule0 = MovedModule('name', 'old', 'new')
    assert MovedModule0.name == 'name'
    assert MovedModule0.old == 'old'
    assert MovedModule0.new == 'new'
    MovedModule1 = MovedModule('name', 'old')
    assert MovedModule1.name == 'name'
    assert MovedModule1.old == 'old'
    assert MovedModule1.new == 'name'
    MovedModule2 = MovedModule('name', 'old', None)
    assert MovedModule2.name == 'name'
    assert MovedModule2.old == 'old'
    assert MovedModule2.new == 'name'
    MovedModule3 = MovedModule('name', 'old', '')

# Generated at 2022-06-25 22:37:21.051317
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("builtins", "__builtin__")


# Generated at 2022-06-25 22:37:22.058587
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()


# Generated at 2022-06-25 22:37:24.673752
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = None
    assert MovedModule(a_s_t_0, None)


# Generated at 2022-06-25 22:37:27.449948
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:37:29.290301
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module_0 = MovedModule('name', 'old', 'new')


# Generated at 2022-06-25 22:37:30.989613
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('builtins', '__builtin__', None)


# Generated at 2022-06-25 22:37:35.106229
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'


# Generated at 2022-06-25 22:37:42.062800
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    net_path_0 = 'a_s_t'
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0, net_path_0)
    assert six_moves_transformer_0.source_to_target_map == None
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.dependencies == ['six']
    assert six_moves_transformer_0.net_path == 'a_s_t'


# Generated at 2022-06-25 22:37:47.530136
# Unit test for constructor of class MovedModule
def test_MovedModule():
    code_unit = MovedModule("foo", "bar.baz")
    assert code_unit.name == "foo"
    assert code_unit.new == "foo"
    code_unit1 = MovedModule("foo", "bar.baz", "qux.quux")
    assert code_unit1.name == "foo"
    assert code_unit1.new == "qux.quux"


# Generated at 2022-06-25 22:37:50.004162
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)



# Generated at 2022-06-25 22:39:30.876541
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule('builtins', '__builtin__'), MovedModule)
    assert hasattr(MovedModule('builtins', '__builtin__'), 'name')
    assert hasattr(MovedModule('builtins', '__builtin__'), 'old')
    assert hasattr(MovedModule('builtins', '__builtin__'), 'new')


# Generated at 2022-06-25 22:39:32.106102
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

test_SixMovesTransformer()


# Generated at 2022-06-25 22:39:36.488335
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test type of all arguments
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

    # Test return type of constructor
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:39:39.418876
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # No error - it is just a constructor
    moved_attribute_0 = MovedAttribute('~', '~', '~', '~', '~')


# Generated at 2022-06-25 22:39:42.536162
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = None
    moved_module_0 = MovedModule("foo", "bar")
    assert moved_module_0.name == "foo"

# Generated at 2022-06-25 22:39:47.273976
# Unit test for constructor of class MovedModule
def test_MovedModule():
    global _moved_attributes
    a = _moved_attributes[35]
    assert type(a) == MovedModule
    assert a.name == 'BaseHTTPServer'
    assert a.old == 'BaseHTTPServer'
    assert a.new == 'http.server'


# Generated at 2022-06-25 22:39:49.904553
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = ''
    old_0 = ''
    new_0 = ''
    moved_module_0 = MovedModule(name_0, old_0, new_0)


# Generated at 2022-06-25 22:39:53.981329
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute_0 = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io", old_attr="StringIO", new_attr="StringIO")
    assert movedattribute_0.name == "cStringIO"
    assert movedattribute_0.new_mod == "io"
    assert movedattribute_0.new_attr == "StringIO"


# Generated at 2022-06-25 22:39:55.996140
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:39:58.683439
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        test_case_0()
    except:
        print("Cannot test function: ", sys._getframe().f_code.co_name)

test_SixMovesTransformer()