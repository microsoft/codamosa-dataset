

# Generated at 2022-06-25 22:31:13.972688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bytes_0 = b'\xdfd'
    str_0 = None
    moved_attribute_0 = MovedAttribute(bytes_0, str_0)


# Generated at 2022-06-25 22:31:23.721386
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '{z\x1c\x0f\r\x0f\xfa\x1b\x15h|g\t\x16\x10\x7f\x0f\x7fl\x1b\x15\x1a\x7f\x0f\x7f\x10\x1a\x0f'
    str_1 = '*f\x11z\x0f\x0fk\x1b\x15h|g\t\x16\x10\x7f\x0f\x7fl\x1b\x15\x1a\x7f\x0f\x7f\x10\x1a\x0f'

# Generated at 2022-06-25 22:31:33.370565
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # **Note:** These tests are not re-run under 3.x
    import sys
    if sys.version_info[0] >= 3:
        return
    str_0 = None
    str_1 = None
    int_0 = 4
    bytes_0 = b'\x15\x0e\xd8\x26\x85\xbf\xdd5\x11\x1e'
    str_2 = None
    str_3 = None
    obj = MovedAttribute(str_0, str_1, int_0, bytes_0, str_2, str_3)
    assert obj.name is not None
    assert obj.new_mod is not None
    assert obj.new_attr is not None


# Generated at 2022-06-25 22:31:43.091044
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    bytes_0 = b'6\x178\xce:\x06\xca\x94'
    str_0 = None
    moved_attribute_0 = MovedAttribute(bytes_0, str_0, str_0, str_0, str_0)
    bytes_1 = b'$N\x9b\x1c\xbe/\xab,'
    str_1 = None
    moved_module_0 = MovedModule(bytes_1, str_1)
    # Test for constructor of class SixMovesTransformer
    six_moves_transformer_0 = SixMovesTransformer(moved_attribute_0, moved_module_0)



# Generated at 2022-06-25 22:31:45.801563
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = None
    str_1 = '\x945\xaf5\x82\x81\t@\xcd3'
    str_2 = None
    str_3 = 'r\x13\x88\xfbA\n\x19\xe6'
    moved_attribute_0 = MovedAttribute(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 22:31:47.634331
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = None
    moved_module_0 = MovedModule(str_0, str_0)
    assert isinstance(SixMovesTransformer(), BaseImportRewrite)


# Generated at 2022-06-25 22:31:51.311872
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError) as excinfo:
        MovedModule(b'foo', 'bar')
    assert 'bytes' in str(excinfo.value)
    #assert False # TODO: implement your test here



# Generated at 2022-06-25 22:31:56.666876
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bytes_1 = b'6\x178\xce:\x06\xca\x94'
    str_1 = None
    moved_module_0 = MovedModule(bytes_1, str_1)
    assert isinstance(moved_module_0, MovedModule)


# Generated at 2022-06-25 22:32:09.890166
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    # Create a MovedAttribute object
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    moved_attribute_2 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    moved_attribute_3 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    moved_attribute_4 = MovedAttribute("intern", "__builtin__", "sys")
    moved_attribute_5 = MovedAttribute("map", "itertools", "builtins", "imap", "map")

# Generated at 2022-06-25 22:32:12.754514
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test with string and bytes

    assert isinstance(SixMovesTransformer.rewrites, tuple)
    assert len(SixMovesTransformer.rewrites) == 31



# Generated at 2022-06-25 22:32:25.784159
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    global str_0
    global bytes_0
    assertion_type = type(str_0)
    bytes_0 = b'my_string'
    str_0 = bytes_0.decode('latin-1')
    str_1 = str_0
    str_0 = 'my_string'
    assert isinstance(str_0, str)
    str_1 = (str_0 + str_0)
    str_0 = bytes_0.decode('latin-1')
    str_0 = bytes_0.decode('latin-1')
    str_0 = bytes_0.decode('latin-1')
    str_0 = str_0.split('_')[0]
    str_0 = bytes_0.decode('latin-1')

# Generated at 2022-06-25 22:32:31.784193
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # MovedModule()
    testcase_MovedModule_0 = MovedModule('builtins', '__builtin__')


# Generated at 2022-06-25 22:32:32.839008
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_MovedModule_0()


# Generated at 2022-06-25 22:32:40.373660
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    def f():
        a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
        assert a.name == "name"
        assert a.new_mod == "new_mod"
        assert a.new_attr == "new_attr"
    try:
        f()
    except:
        assert False, "FAILED: test_MovedAttribute"
    else:
        assert True, "PASSED: test_MovedAttribute"

test_MovedAttribute.unit = True


# Generated at 2022-06-25 22:32:51.219958
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('b', 'd', 'c')
    # noinspection PyArgumentList
    assert MovedAttribute(b='b', new_attr=None, new_mod='c', name='b', old_mod='d', old_attr=None)
    assert MovedAttribute(b='b', new_attr=None, new_mod='c', old_attr=None)
    assert MovedAttribute('b', old_mod='d', old_attr=None)
    assert MovedAttribute('b', old_attr=None)
    assert MovedAttribute('b', old_attr=None, new_attr=None)
    assert MovedAttribute('b', new_attr=None)
    assert MovedAttribute('b')
    assert MovedAttribute(b=None)


# Generated at 2022-06-25 22:32:53.193488
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with patch('sys.version_info', new=(3, 5)):
        SixMovesTransformer()


# Generated at 2022-06-25 22:32:54.658494
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sixMovesTransformer = SixMovesTransformer()

# Generated at 2022-06-25 22:32:58.335580
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        assert isinstance(SixMovesTransformer, object)
    except AssertionError as e:
        print('Caught unexpected exception')


# Generated at 2022-06-25 22:33:07.899144
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule_0 = MovedModule('', '', )
    list_0 = [movedmodule_0, ]
    list_1 = [_moved_attributes, list_0]
    prefixed_moves.append(tuple(list_1))

# Generated at 2022-06-25 22:33:10.540376
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(target=(2, 7), rewrites=_get_rewrites(), dependencies=['six'])


# Generated at 2022-06-25 22:33:14.018455
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_obj0 = MovedModule('ab', 'cd', 'ef')


# Generated at 2022-06-25 22:33:20.877916
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = 'name_0'
    old_mod_0 = 'old_mod_0'
    old_attr_0 = 'old_attr_0'
    new_mod_0 = 'new_mod_0'
    new_attr_0 = 'new_attr_0'
    test_0_0 = MovedAttribute(name_0, old_mod_0, new_mod_0, old_attr_0, new_attr_0)


# Generated at 2022-06-25 22:33:25.111573
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    source = "print(string.ascii_lowercase)"
    expected = "import six\nprint(six.moves.string.ascii_lowercase)"
    result = SixMovesTransformer().process_code(source)
    assert result == expected


# Generated at 2022-06-25 22:33:32.308514
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """
    Test the constructor of class MovedAttribute
    """
    name = 'cStringIO'
    old_mod = 'cStringIO'
    new_attr = None
    new_mod = 'io'
    old_attr = 'StringIO'
    obj = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert obj.new_mod == 'io'
    assert obj.new_attr == 'cStringIO'


# Generated at 2022-06-25 22:33:37.375914
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer(sys.maxsize)
    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.dependencies == ['six']


# Generated at 2022-06-25 22:33:40.013624
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("test", "test")
    assert mod.name == "test"
    assert mod.new == "test"


# Generated at 2022-06-25 22:33:49.342593
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    # ^^ check that it is a SixMovesTransformer

    assert six_moves_transformer_0.target == (2, 7)
    # ^^ check that target is (2, 7)


# Generated at 2022-06-25 22:33:58.835771
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module1 = MovedModule("builtins", "__builtin__")
    assert module1.name == "builtins" and module1.old == "__builtin__" and module1.new == "builtins"

    module2 = MovedModule("configparser", "ConfigParser")
    assert module2.name == "configparser" and module2.old == "ConfigParser" and module2.new == "configparser"

    module3 = MovedModule("configparser", "ConfigParser", "configparser")
    assert module3.name == "configparser" and module3.old == "ConfigParser" and module3.new == "configparser"



# Generated at 2022-06-25 22:34:05.377519
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_0 = MovedModule("builtins", "__builtin__")
    assert module_0.name == "builtins"
    assert module_0.new == "__builtin__"
    module_1 = MovedModule("robotparser", "robotparser", "urllib.robotparser")
    assert module_1.name == "robotparser"
    assert module_1.new == "urllib.robotparser"


# Generated at 2022-06-25 22:34:07.590521
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    six_moves_transformer_1 = SixMovesTransformer()
    assert six_moves_transformer_1 is not None



# Generated at 2022-06-25 22:34:12.334202
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert isinstance(six_moves_transformer, SixMovesTransformer)


# Generated at 2022-06-25 22:34:15.968374
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Constructor for MovedModule"""
    name = "builtins"
    old = "__builtin__"
    new = None
    m = MovedModule(name, old, new)
    assert m.name == "builtins"
    assert m.old == "__builtin__"
    assert m.new == None


# Generated at 2022-06-25 22:34:19.862568
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"


# Generated at 2022-06-25 22:34:21.641387
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:34:25.058924
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_object = MovedModule("builtins", "__builtin__")
    assert moved_module_object.name == "builtins"
    assert moved_module_object.new == "builtins"

# Generated at 2022-06-25 22:34:35.751381
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert six_moves_transformer_0.name == 'six_moves'
    assert six_moves_transformer_0.target == (2, 7)

# Generated at 2022-06-25 22:34:37.694481
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:34:47.239708
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name').name == 'name'
    assert MovedModule('name').old == 'name'
    assert MovedModule('name').new == 'name'


# Generated at 2022-06-25 22:34:52.042704
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # <class 'towel.marvin.MovedModule'>
    assert_equal(type(MovedModule('socketserver', 'SocketServer')), type(MovedModule))


# Generated at 2022-06-25 22:34:55.415270
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.dependencies == ['six']


# Generated at 2022-06-25 22:35:06.644514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:35:16.158658
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # case 0
    str_0 = 'wE\rNr8$\x0c'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)



# Generated at 2022-06-25 22:35:22.788225
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = None
    moved_attribute_0 = MovedAttribute(int_0, int_0, int_0)
    int_1 = None
    moved_module_0 = MovedModule(int_1, int_1)
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:30.221323
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'g\x1bzsf\xe1\x08\xcbj\xcb\xfd\x0f\xa2\x1b\x84\x0b'
    int_0 = None
    list_0 = [str_0, int_0, str_0]
    bool_0 = True
    tuple_0 = (str_0, bool_0, str_0)
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0, tuple_0)
    # Check for string attribute: moved_attribute_0.name
    assert(moved_attribute_0.name == 'g\x1bzsf\xe1\x08\xcbj\xcb\xfd\x0f\xa2\x1b\x84\x0b')

# Generated at 2022-06-25 22:35:35.287480
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '!n\x1dH'
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)
    assert moved_attribute_0.name == str_0


# Generated at 2022-06-25 22:35:43.993648
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:35:44.958847
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    pass # TODO


# Generated at 2022-06-25 22:35:48.718640
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'W1Uhv\t5\\mS\\'
    list_0 = [str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:35:49.693732
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # TODO
    pass


# Generated at 2022-06-25 22:35:57.721826
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)

    pass


# Generated at 2022-06-25 22:36:08.775842
# Unit test for constructor of class MovedModule
def test_MovedModule():
  try:
    moved_module_0 = MovedModule('d!4%c', 'importlib', '1111')
    assert moved_module_0.name == 'd!4%c'
    assert moved_module_0.new == '1111'
    assert moved_module_0.old == 'importlib'
  except:
    assert False


# Generated at 2022-06-25 22:36:11.362005
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(None, None, None)
    assert moved_module_0.name == None
    assert moved_module_0.new == None


# Generated at 2022-06-25 22:36:20.577978
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    assert moved_module_0.name is dict_0
    assert moved_module_0.new is dict_0
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    str_1 = 'N'

# Generated at 2022-06-25 22:36:21.800125
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    method_0 = SixMovesTransformer(module_0.AST())


# Generated at 2022-06-25 22:36:26.365069
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = "\"\\"
    bool_0 = True
    int_0 = 0
    moved_module_0 = MovedModule(str_0, bool_0, int_0)
    assert moved_module_0.name == str_0
    assert moved_module_0.old == bool_0
    assert moved_module_0.new == int_0


# Generated at 2022-06-25 22:36:31.028825
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        str_0 = 'dXG'
        bool_0 = True
        a_s_t_0 = module_0.AST()
        six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    except Exception:
        print('An exception was raised while testing the constructor of class SixMovesTransformer')


# Generated at 2022-06-25 22:36:32.045035
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    pass


# Generated at 2022-06-25 22:36:38.979000
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    assert moved_module_0.name == dict_0
    assert moved_module_0.new == dict_0
    dict_1 = None
    moved_module_1 = MovedModule('l8', dict_1)
    assert moved_module_1.name == 'l8'
    assert moved_module_1.new == 'l8'


# Generated at 2022-06-25 22:36:47.216717
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'sL\x0c'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:36:49.238361
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 22:37:08.113970
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'M<UI}s(D\ndS'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:37:10.637301
# Unit test for constructor of class MovedModule
def test_MovedModule():
    '''
    Constructor
    '''
    moved_module_0 = MovedModule(str(""), None, None)


# Generated at 2022-06-25 22:37:17.238014
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:37:26.957598
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'TYEg\x1eb@\x1b\x1e\x12\x1c&\x16'
    bool_0 = False
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:37:36.419455
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    
    # constructor test
    # Variables:
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)



# Generated at 2022-06-25 22:37:39.586770
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '}q\nHc'
    list_0 = [str_0]
    float_0 = 0.7
    moved_attribute_0 = MovedAttribute(str_0, list_0, float_0)


# Generated at 2022-06-25 22:37:45.388611
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'pwfN28R^sAb'
    bool_0 = False
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)
    assert isinstance(moved_attribute_0, MovedAttribute)


# Generated at 2022-06-25 22:37:49.577776
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'p\x0b'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:50.502021
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert True


# Generated at 2022-06-25 22:37:53.754893
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_module_0 = MovedModule('', '', '')
    str_0 = ''
    moved_attribute_0 = MovedAttribute(str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 22:38:26.416071
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:38:31.519706
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_1 = 'U6rF&V'
    bool_1 = False
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    moved_module_1 = MovedModule(str_1, bool_1, bool_1)
    assert moved_module_1.name is str_1
    assert moved_module_1.old is bool_1
    assert moved_module_1.new is bool_1


# Generated at 2022-06-25 22:38:43.092211
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

    assert 'six' in six_moves_transformer_0.dependencies
    assert ('sys.version_info', 'six.PY2') in six_moves_transformer_0.rewrites
    assert ('sys.version_info', 'six.PY3') in six_moves_transformer_0.rewrites
    assert ('sys.version_info', 'six.PY34') in six_moves_transformer_0.rewrites
    assert ('sys.version_info', 'six.PY35') in six_m

# Generated at 2022-06-25 22:38:47.793924
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test TypeError
    try:
        'yJfOy&'
        False
        dict_0 = None
        moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
        list_0 = [dict_0, dict_0, dict_0]
        False
    except TypeError as e:
        pass


# Generated at 2022-06-25 22:38:55.898368
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    assert moved_module_0.name == dict_0
    assert moved_module_0.new == dict_0
    assert moved_module_0.old == dict_0
    str_1 = 'I'
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)

# Generated at 2022-06-25 22:39:01.927297
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
  str_0 = 'cYNRLd\tbP\n\\&#'
  bool_0 = True
  module_0 = typed_ast.ast3
  a_s_t_0 = module_0.AST()
  SixMovesTransformer(a_s_t_0)
  dict_0 = None
  moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
  list_0 = [str_0, bool_0, str_0]
  int_0 = None
  moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)

# Generated at 2022-06-25 22:39:12.310031
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  str_0 = 'xO]^E!?\r(.WO'
  int_0 = None
  moved_attribute_0 = MovedAttribute(str_0, str_0, int_0)
  moved_attribute_0.name
  moved_attribute_0.new_mod
  moved_attribute_0.new_attr
  moved_attribute_0.old_mod
  moved_attribute_0.old_attr
  assert_equal(moved_attribute_0.name, 'xO]^E!?\r(.WO')
  assert_equal(moved_attribute_0.new_mod, 'xO]^E!?\r(.WO')
  assert_equal(moved_attribute_0.new_attr, 'xO]^E!?\r(.WO')
  assert_equal

# Generated at 2022-06-25 22:39:22.070754
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:39:29.802966
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)
    test_case_0()


# Generated at 2022-06-25 22:39:39.329762
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)
    six_moves_transformer_1 = SixMovesTransformer()
    six_moves_transformer_2 = SixMovesTransformer('c;\x1fH')
    six_m

# Generated at 2022-06-25 22:40:37.167417
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule != None


# Generated at 2022-06-25 22:40:44.278216
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)


# Generated at 2022-06-25 22:40:51.271192
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_1 = 'cYNRLd\tbP\n\\&#'
    bool_1 = True
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovedTransformer(a_s_t_1)
    dict_1 = None
    moved_module_1 = MovedModule(str_1, bool_1, bool_1)
    list_1 = [str_1, bool_1, str_1]
    int_1 = None
    moved_attribute_1 = MovedAttribute(str_1, list_1, int_1)

# Generated at 2022-06-25 22:40:54.618169
# Unit test for constructor of class MovedModule
def test_MovedModule():
    int_0 = -49
    moved_module_0 = MovedModule(int_0, int_0)
    assert moved_module_0.name == int_0
    assert moved_module_0.new == int_0
    pass


# Generated at 2022-06-25 22:41:03.212728
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)
    assert_equal(moved_module_0.name, dict_0)
    assert_equal(moved_module_0.new, dict_0)

# Generated at 2022-06-25 22:41:04.348845
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()


# Generated at 2022-06-25 22:41:11.946220
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    global moved_attribute_0
    str_0 = 'cYNRLd\tbP\n\\&#'
    bool_0 = True
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = None
    moved_module_0 = MovedModule(dict_0, dict_0, dict_0)
    list_0 = [str_0, bool_0, str_0]
    int_0 = None
    moved_attribute_0 = MovedAttribute(str_0, list_0, int_0)
    assert moved_attribute_0.name == str_0
    assert moved_attribute_0.new_mod == int_0
    assert moved_attribute_0.new_