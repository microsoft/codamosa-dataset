

# Generated at 2022-06-25 22:31:12.975776
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'


# Generated at 2022-06-25 22:31:15.425601
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:16.902334
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule_0 = MovedModule("ast", "ast")


# Generated at 2022-06-25 22:31:18.011544
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    case_0()


# Generated at 2022-06-25 22:31:20.890592
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('queue', 'Queue')
    assert obj.name == 'queue'
    assert obj.old == 'Queue'
    assert obj.new == 'queue'


# Generated at 2022-06-25 22:31:25.823015
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('x', 'a', 'b')
    assert MovedAttribute('x', 'a', 'b', 'c', 'd')
    assert MovedAttribute('x', 'a', 'b', 'c')
    assert MovedAttribute('x', 'a', 'b', new_attr='c')


# Generated at 2022-06-25 22:31:27.833014
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')


# Generated at 2022-06-25 22:31:30.556608
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Create an instance of MovedAttribute
    moved_attribute_0 = MovedAttribute('2', '2', '2', '2', '2')



# Generated at 2022-06-25 22:31:35.441675
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"


# Generated at 2022-06-25 22:31:45.271320
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Calling the constructor of class SixMovesTransformer
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    del six_moves_transformer_0
    # Calling the constructor of class SixMovesTransformer
    a_s_t_1 = None
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    del six_moves_transformer_1
    # Calling the constructor of class SixMovesTransformer
    a_s_t_2 = None
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_2)
    del six_moves_transformer_2


# Generated at 2022-06-25 22:31:47.704078
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, type)


# Generated at 2022-06-25 22:31:49.907086
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = None
    moved_module_0 = MovedModule("name", "old")


# Generated at 2022-06-25 22:31:51.765609
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'


# Generated at 2022-06-25 22:31:56.001184
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule_0 = MovedModule('name', 'old', 'new')
    assert movedModule_0.name == 'name'
    assert movedModule_0.new == 'new'


# Generated at 2022-06-25 22:31:57.813652
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    test_case_0()


# Generated at 2022-06-25 22:32:11.314166
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    a_moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    # Test attribute name
    assert a_moved_attribute_0.name == "cStringIO"
    assert a_moved_attribute_0.name != "cStringI"

    # Test attribute new_mod
    assert a_moved_attribute_0.new_mod == "io"
    assert a_moved_attribute_0.new_mod != "cStringIO"

    # Test attribute new_attr
    assert a_moved_attribute_0.new_attr == "StringIO"
    assert a_moved_attribute_0.new_attr != "StringI"


# Generated at 2022-06-25 22:32:18.885224
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_mod == 'old_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'



# Generated at 2022-06-25 22:32:21.374932
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    assert SixMovesTransformer(a_s_t_0) is not None


# Generated at 2022-06-25 22:32:24.411460
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = None
    old_0 = None
    new_0 = None
    moved_module_0 = MovedModule(name_0, old_0, new_0)


# Generated at 2022-06-25 22:32:31.352467
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("queue", "Queue")
    assert module.name == "queue"


# Generated at 2022-06-25 22:32:34.321397
# Unit test for constructor of class MovedModule
def test_MovedModule():
    var_1 = MovedModule(var_0, var_0)


# Generated at 2022-06-25 22:32:39.840516
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_0 = MovedAttribute("six.moves.filter", "six.moves.itertools", "six.moves.builtins")
    var_1 = MovedAttribute("six.moves.filter", "six.moves.itertools", "six.moves.builtins", "six.moves.ifilter", "six.moves.filter")


# Generated at 2022-06-25 22:32:51.178590
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_0 = SixMovesTransformer()
    assert var_0.depends == set(['six']), 'Expected' + str(set(['six'])) + ' but got ' + str(var_0.depends)
    assert var_0.__class__.__name__ == 'SixMovesTransformer', 'Expected SixMovesTransformer but got ' + var_0.__class__.__name__
    assert var_0.target == (2, 7), 'Expected' + str((2, 7)) + ' but got ' + str(var_0.target)
    test_case_0()

#######################

# Fill in the values
SixMovesTransformer.depends = set(['six'])
SixMovesTransformer.__name__ = 'SixMovesTransformer'
SixMovesTransformer

# Generated at 2022-06-25 22:32:54.423318
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # var_0 = MovedModule(name='urllib.request', old='urllib2', new='urllib.request')
    var_0 = MovedModule('urllib.request', 'urllib2')


# Generated at 2022-06-25 22:33:00.116042
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_1 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert (var_1.name) == 'cStringIO'
    assert (var_1.new_mod) == 'io'
    assert (var_1.new_attr) == 'StringIO'


# Generated at 2022-06-25 22:33:05.205255
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_12 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert var_12.name == 'name'
    assert var_12.new_attr == 'new_attr'
    assert var_12.new_mod == 'new_mod'


# Generated at 2022-06-25 22:33:12.467867
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # `name` argument
    assert MovedModule('', None, None).name == ''
    assert MovedModule(123, None, None).name == 123

    # `old` argument
    assert MovedModule('', '', None).old == ''
    assert MovedModule('', 123, None).old == 123

    # `new` argument
    assert MovedModule('', None, '').new == ''
    assert MovedModule('', None, 123).new == 123


# Generated at 2022-06-25 22:33:16.740093
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_1 = SixMovesTransformer()
    assert var_1.dependencies == ['six']
    assert var_1.rewrites == _get_rewrites()
    assert (var_1.target == (2, 7))



# Generated at 2022-06-25 22:33:18.903853
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:33:20.738512
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:33:23.536308
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass #TODO


# Generated at 2022-06-25 22:33:26.562683
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_0 = SixMovesTransformer()
    if id(var_0) == id(None):
        print('test_SixMovesTransformer failed: test_1')


# Generated at 2022-06-25 22:33:30.201686
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_0 = SixMovesTransformer(target=(2, 7), rewrites=_get_rewrites())
    assert isinstance(var_0, BaseImportRewrite)


# Generated at 2022-06-25 22:33:40.749008
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_1 = SixMovesTransformer(6)
    assert var_1.target == (2, 7)
    assert var_1.dependencies == ['six']
    assert len(var_1.rewrites) == 53

# Generated at 2022-06-25 22:33:41.722018
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:33:50.700293
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert var_0.name == 'cStringIO'
    assert var_0.new_mod == 'cStringIO'
    assert var_0.new_attr == 'StringIO'
    var_1 = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert var_1.name == 'filter'
    assert var_1.new_mod == 'itertools'
    assert var_1.new_attr == 'ifilter'
    var_2 = MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    assert var_2.name == 'filterfalse'
    assert var_2.new_mod

# Generated at 2022-06-25 22:33:51.763734
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_0 = SixMovesTransformer()


# Generated at 2022-06-25 22:33:52.657756
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    var_1 = SixMovesTransformer()



# Generated at 2022-06-25 22:34:04.190444
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    # AssertionError: assert obj_0.new_attr == 'StringIO'
    var_0 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    # AssertionError: assert var_0.new_attr == 'filter'
    var_1 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    # AssertionError: assert var_1.new_attr == 'filterfalse'
    var_2 = MovedAttribute("input", "__builtin__", "builtins")
    # AssertionError: assert var_2.new_attr == 'input'
    var_3 = Moved

# Generated at 2022-06-25 22:34:08.494260
# Unit test for constructor of class MovedModule
def test_MovedModule():
    Test_MovedModule_0 = MovedModule("name0", "old0")
    Test_MovedModule_1 = MovedModule("name1", "old1", "new1")
    Test_MovedModule_2 = MovedModule("name2", "old2", None)


# Generated at 2022-06-25 22:34:17.936789
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007

# Generated at 2022-06-25 22:34:30.528189
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'MovedAttribute(moved_module_0, moved_module_1)'
    str_1 = 'MovedAttribute(moved_module_0, moved_module_1, moved_module_1)'
    str_2 = 'MovedAttribute(moved_module_0, moved_module_1, moved_module_1, moved_module_0)'
    str_3 = 'MovedAttribute(moved_module_1, moved_module_1, moved_module_1, moved_module_1, moved_module_0)'
    moved_attribute_0 = MovedAttribute(str_0)
    moved_attribute_1 = MovedAttribute(str_1)
    moved_attribute_2 = MovedAttribute(str_2)
    moved_attribute_3 = MovedAttribute(str_3)

# Unit

# Generated at 2022-06-25 22:34:37.168694
# Unit test for constructor of class MovedModule
def test_MovedModule():
  try:
    str_0 = '\xbb\xab\x8c\x1d\xef\x01\x81\xb0\x96\xea\x90\xc8D\x07\xd4\xc1\x7fU'
    str_1 = '3\xe4\x1c\x97\xa3d\xfb5Y\x1e\xfe\x11c\xaa\xf5\x8d'
    moved_module_0 = MovedModule(str_0, str_1)
  except BaseException as e:
    if type(e) is AssertionError:
      pass
    else:
      raise e
  else:
    pass


# Generated at 2022-06-25 22:34:40.579775
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert hasattr(MovedModule, '__init__')
    assert MovedModule.__init__.__annotations__ == dict(self=MovedModule)


# Generated at 2022-06-25 22:34:47.423749
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    assert str_0 == moved_module_0.name
    assert str_1 == moved_module_0.new


# Generated at 2022-06-25 22:34:57.523048
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    string_0 = 'jr]d/Q/=@!T"&/\x16-zB|\x05\x1d\x06\x1dXV\x1b\x17'
    string_1 = 'e\x11\x03\x18\x18\x12\x1c\x1f\x1c\x04\x16\x18\x00\x11\x07\x18\x06\x1c\x17\x08\x13s\x07\x1b\x12\x1e\x07\x1c\x05-\x1c\x13\x1b\x1c\x1b\x06\x17'

# Generated at 2022-06-25 22:35:08.447590
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'IoT,f9d@}8hSjKz{'
    bytes_0 = b'8\xec\xcf\x1e\x98\x83\x14\x7f\xa2H!\xf8Y\x16\x0e\xfd\x7f\x9e'
    float_0 = 344.0
    bytes_1 = b'n\xb8\xef\x0c\x019\x8d\x10\xb3\xbf4v\x15\xd8Z\x92\xec\x17\x16\x8b'
    float_1 = 1139.0
    tuple_0 = (bytes_1, float_1)

# Generated at 2022-06-25 22:35:19.027336
# Unit test for constructor of class MovedModule

# Generated at 2022-06-25 22:35:28.431856
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test to make sure that the constructor is working as expected
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}

# Generated at 2022-06-25 22:35:30.932150
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:43.638461
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('2]\x1f!', 'mPygD\x92U6\xf9\x81')
    assert isinstance(moved_module_0, MovedModule)
    assert moved_module_0.name == '2]\x1f!'
    assert moved_module_0.new == 'mPygD\x92U6\xf9\x81'
    moved_module_1 = MovedModule('Jn', None)
    assert isinstance(moved_module_1, MovedModule)
    assert moved_module_1.name == 'Jn'
    assert moved_module_1.new == 'Jn'


# Generated at 2022-06-25 22:35:53.371410
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(moved_module_0)
    dict_0 = {six_moves_transformer_0: six_moves_transformer_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007
    bytes_1 = None

# Generated at 2022-06-25 22:35:57.256777
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_attribute_0 = MovedAttribute(str_0, str_1)


# Generated at 2022-06-25 22:36:02.988951
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = 'Wm!8oq'
    str_1 = 'K|\t9*7\x7f'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:09.873749
# Unit test for constructor of class MovedModule
def test_MovedModule():
	a_s_t_0 = module_0.AST()
	str_0 = ':P$\x15\x1d\x0e\x1c\x1a\x10\x18\x8a\x03'
	str_1 = '!_\n\x1c.\x84\x19\x0b:<\x12'
	moved_module_0 = MovedModule(str_0, str_1)


# Generated at 2022-06-25 22:36:19.396536
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = 'zi)rX0Q\\>;h2J'
    str_1 = '"^e<:pXY-J\n]\x1c'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    list_0 = [six_moves_transformer_0, six_moves_transformer_0, six_moves_transformer_0]
    six_moves_transformer_0.rewrites = list_0
    str_2 = 'f#5\x1b`\x11\\\xfb\x91(8\\V7'

# Generated at 2022-06-25 22:36:28.679516
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-25 22:36:38.896744
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = 'z\'d#I^J#M|L1\x1dX\x17<:6\x0eT\x01P+\x03\x1a\x0f(m\x18\x1d\x11\x01\x0eM8\x1b\x17\x05"\x0bt8\x1d\x1b\x0b\x1d\x03L\x0e\\\x12'
    str_1 = '=&H\\=6_{8l%I'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
   

# Generated at 2022-06-25 22:36:49.293119
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test with an instance of AST
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'


# Generated at 2022-06-25 22:36:58.099050
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_1 = '=&H\\=6_{8l%I'
    str_0 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_1, str_0)
    str_2 = 'O^Hg.s3Zlg!tqk0]E'
    assert moved_module_0.name == str_2
    str_3 = 'O^Hg.s3Zlg!tqk0]E'
    assert moved_module_0.new == str_3


# Generated at 2022-06-25 22:37:09.854752
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test 1: Instantiates object with non-string names
    try:
        MovedModule(1, 2)
        assert False
    except AssertionError:
        assert True
    # Test 2: Instantiates object with a non-string new value
    try:
        MovedModule("a", 2)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-25 22:37:18.333444
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = '\x17\x9c\x80\x8d\x06\xc6\x0c\xff\x95\xad\xf2'
    str_1 = ']#Q\x81\xf6\\@c\xd7\x02\x8a\x1c\x97\xed\x07'
    moved_module_0 = MovedModule(str_0, str_1)
    str_2 = 'T\x17\x04\xa8\xfa\x1fN\x9c\x88[\xbe'
    str_3 = '\xae\x0c\xae\xcb\x06\xab\x1b\xc7\x1c\x93'

# Generated at 2022-06-25 22:37:29.474852
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    dict_0 = {six_moves_transformer_0: a_s_t_0}

# Generated at 2022-06-25 22:37:35.510413
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = 2116
    list_1 = [int_0]
    long_0 = long(1708)
    int_1 = 1789
    moved_attribute_1 = MovedAttribute(list_1, long_0, int_1)
    int_2 = 1803
    moved_attribute_2 = MovedAttribute(int_1, int_1, int_2)


# Generated at 2022-06-25 22:37:43.849482
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007

# Generated at 2022-06-25 22:37:53.838854
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007

# Generated at 2022-06-25 22:37:58.241625
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_1 = MovedAttribute(b'd\x1f', None, None)
    assert(moved_attribute_1.name == b'd\x1f')
    assert(moved_attribute_1.new_mod == b'd\x1f')
    assert(moved_attribute_1.new_attr == b'd\x1f')


# Generated at 2022-06-25 22:38:07.667015
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = 'qg`Qjj$xKd}8w>y'

# Generated at 2022-06-25 22:38:14.198903
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    str_0 = '_6\n\x17Xl\xea\xd8\x96\x0b\xea\xaf.\x80\xed\xb7\xd6\x9d\xb9\xeb\xdd'
    moved_attribute_0 = MovedAttribute(str_0, list_0)
    assert isinstance(moved_attribute_0, MovedAttribute)
    assert moved_attribute_0.name == str_0
    assert moved_attribute_0.new_attr == str_0
    assert moved_attribute_0.new_mod == list_0


# Generated at 2022-06-25 22:38:23.145317
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    dict_0 = {six_moves_transformer_1: a_s_t_1}
    a_s_t_2 = module_0.AST()
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_2)
    dict_1 = {six_moves_transformer_2: a_s_t_2}

# Generated at 2022-06-25 22:38:46.549678
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'xh9$p)u_dR<}H"G"M`g'
    str_1 = 'ZL-O&\x07Xl\x18d\r\r\x17\x1c\x1a'
    moved_module_0 = MovedModule(str_0, str_1)
    str_2 = ' '
    bytes_0 = b'`\'\x95\x9f@\xe35\xfa&\x8e\xcc\xf1l\x95\xaa\xee\xc3'
    bytes_1 = None
    moved_attribute_0 = MovedAttribute(bytes_0, str_2, bytes_1)

# Generated at 2022-06-25 22:38:55.027834
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = 'F}S\x8a\x85\x88\x86\xba\x85\x00k\x80\xe3\x0b\xc3?\xad\x1f\x1d\xce\x04\xb2\\\x94\xd7\xc5\x07\x1a\x08\xf7\x1a}'
    str_1 = '?'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:02.424076
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    a_s_t_1 = module_0.AST()
    str_2 = '=&H\\=6_{8l%I'
    str_3 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_1 = MovedModule(str_2, str_3)

# Generated at 2022-06-25 22:39:10.174938
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = '*'
    str_1 = 'l^F\x1f:N'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0.dependencies = set(['six'])
    six_moves_transformer_0._make_tree(a_s_t_0)



# Generated at 2022-06-25 22:39:12.854586
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule('s')
    except TypeError:
        pass
    except:
        pass
    else:
        assert False


# Generated at 2022-06-25 22:39:17.388651
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('X', '*', 'S', 'n', 't')
    assert(moved_attribute_0.new_mod == 'S')
    assert(moved_attribute_0.name == 'X')
    assert(moved_attribute_0.new_attr == 't')


# Generated at 2022-06-25 22:39:28.352159
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007

# Generated at 2022-06-25 22:39:37.398273
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_2 = '=&H\\=6_{8l%I'
    str_3 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_1 = MovedModule(str_2, str_3)
    len_0 = len(six_moves_transformer_0)

# Generated at 2022-06-25 22:39:46.072338
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = dict()
    list_0 = list()
    moved_module_0 = MovedModule(dict_0, list_0)
    assert(isinstance(moved_module_0, MovedModule))
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_1 = MovedModule(str_0, str_1)
    assert(isinstance(moved_module_1, MovedModule))


# Generated at 2022-06-25 22:39:54.176125
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007

# Generated at 2022-06-25 22:40:34.396362
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '_P2r,[x~(\x1e'
    int_0 = -0
    bytes_0 = b'\xc2\xef\xb2\x0e\x98\x1c\xdd\x8a\xb2\xc2\xc7\x16\xf8%\x84\x1e\xad\xcb!\x88\xf9\x1b1c\xd6\xcd\x0c\xbd\x18\xf4\x9e\xd4\xbb\x17\x1a\x8a\xb5\xe7\xdd/\xe7\x9f\xba\x1a\xdb\xbf\x16\xc0\xcf\x05\xe5\x9c'
    int_1

# Generated at 2022-06-25 22:40:40.417904
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = '{n\\i>\\FxX>D\\dIC|'
    str_1 = 'b7CgK'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_2 = '^`;Em[}M2'
    str_3 = '[kAj+T'
    moved_module_1 = MovedModule(str_2, str_3)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:40:49.800494
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = 'pY'
    str_1 = 'E5r'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'\x1cQ\xef\xd1\xc8\x19l\xff\x16\xd5\xb4\x82\xe3t\x9d\xa0\x95\xfbby'
    float_0 = 378.0007
    bytes_1 = None

# Generated at 2022-06-25 22:40:58.633903
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    str_0 = '=&H\\=6_{8l%I'
    str_1 = 'O^Hg.s3Zlg!tqk0]E'
    moved_module_0 = MovedModule(str_0, str_1)
    str_2 = 'o]P_{x0.0=R}?\xfc|'
    str_3 = 'o\x9cc\xf5\x14\xac\x89\xcbQ\xb4\xc0\xb6\xec\x9d\x00\x1d\xda\xfb'
    moved_module_1 = MovedModule(str_2, str_3)

# Generated at 2022-06-25 22:41:07.704388
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_s_t_0 = module_0.AST()
    str_0 = 'W(=bYvw0\\3x'
    str_1 = '<7$'
    moved_module_0 = MovedModule(str_0, str_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_0 = {six_moves_transformer_0: a_s_t_0}
    bytes_0 = b'!{e\xa3V\xdb\xaa\xf7\xbe\xe7\x02\xa6\x9b\xb8\x14\x17\xaeZ\xab8'
    float_0 = 314.4275
    bytes_1 = None

# Generated at 2022-06-25 22:41:14.265887
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_2 = 'V7T`\x1e\x8ai\x98\x91\xad'
    str_3 = 'fa,@\xa4\xfa3\x1d\xb4'
    moved_module_2 = MovedModule(str_2, str_3)
    str_4 = '\x83\t\x81\x19\xec\x93\xc9\x10\x19\xac\x85\x8e\xb1\x1e\xa5\xea\x9c'
    str_5 = '\xb5\xcd\xed\xaf\x84\x1a|\x02\xaf>#\x97'
    moved_module_3 = MovedModule(str_4, str_5)
    moved_module_