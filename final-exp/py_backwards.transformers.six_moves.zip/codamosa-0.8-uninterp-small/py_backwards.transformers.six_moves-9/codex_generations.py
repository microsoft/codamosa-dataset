

# Generated at 2022-06-25 22:31:13.154605
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == 'name'
    assert moved_module_0.old == 'old'
    assert moved_module_0.new == 'new'


# Generated at 2022-06-25 22:31:15.568226
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:20.983180
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        moved_module_0 = MovedModule("builtins", "__builtin__")
        if moved_module_0.name == "builtins":
            if moved_module_0.new == "builtins":
                if moved_module_0.old == "__builtin__":
                    print("Everything is OK")
    except:
        print("Error has occured")


# Generated at 2022-06-25 22:31:31.613126
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.ast is a_s_t_0
    assert six_moves_transformer_0.has_changed == 0

# Generated at 2022-06-25 22:31:42.768310
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").name == "input")
    assert(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_mod == "builtins")
    assert(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_attr == "input")
    assert(MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").old_attr == "raw_input")
    assert(MovedAttribute("input", "__builtin__", None, "raw_input", "input").new_mod == "input")

# Generated at 2022-06-25 22:31:45.443802
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:49.742887
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    source = '''
import copy
s = copy.deepcopy("x")
'''
    expect = '''
import six.moves.copy as copy0
s = copy0.deepcopy("x")
'''
    six_moves_transformer_0 = SixMovesTransformer(get_ast(source))
    rewrite_and_check(six_moves_transformer_0, source, expect)


# Generated at 2022-06-25 22:31:52.323780
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:58.918349
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = 'name_0'
    old_mod_0 = 'old_mod_0'
    new_mod_0 = 'new_mod_0'
    old_attr_0 = 'old_attr_0'
    new_attr_0 = 'new_attr_0'
    moved_attribute_0 = MovedAttribute(name_0, old_mod_0, new_mod_0, old_attr_0, new_attr_0)


# Generated at 2022-06-25 22:32:04.219236
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)


# Generated at 2022-06-25 22:32:10.028964
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:32:17.614526
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    passed = True
    name = 'foo'
    old_mod = 'bar'
    new_mod = 'baz'
    old_attr = 'qux'
    new_attr = 'quux'
    moved_attribute_0 = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    passed = passed and moved_attribute_0.name == 'foo'
    passed = passed and moved_attribute_0.new_mod == 'baz'
    passed = passed and moved_attribute_0.new_attr == 'quux'
    if not passed:
        raise Exception('Unit test for constructor of class MovedAttribute failed')


# Generated at 2022-06-25 22:32:28.715940
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test attribute 'name'
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute("name", "name", "name")

    # Test attribute 'new_mod'
    moved_attribute_2 = MovedAttribute("cStringIO", None, "io", "StringIO")
    moved_attribute_3 = MovedAttribute("new_mod", None, None)

    # Test attribute 'old_attr'
    moved_attribute_4 = MovedAttribute("cStringIO", "cStringIO", "io", None)
    moved_attribute_5 = MovedAttribute("old_attr", None, None)

    # Test attribute 'new_attr'

# Generated at 2022-06-25 22:32:36.602200
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_1 = 'a'
    b_s_t_1 = 'b'
    c_s_t_1 = 'c'
    moved_module_0 = MovedModule(a_s_t_1, b_s_t_1, c_s_t_1)
    assert(moved_module_0.name == 'a')
    assert(moved_module_0.new == 'c')


# Generated at 2022-06-25 22:32:38.820066
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer
    assert isinstance(six_moves_transformer_0, type)

# Generated at 2022-06-25 22:32:42.316270
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:32:46.978313
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute_0.name == "cStringIO"
    assert moved_attribute_0.new_mod == "io"
    assert moved_attribute_0.new_attr == "StringIO"


# Generated at 2022-06-25 22:32:50.416303
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    assert SixMovesTransformer(a_s_t_0).ast == a_s_t_0


# Generated at 2022-06-25 22:32:54.694770
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m_a_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m_a_0.name == "cStringIO"
    assert m_a_0.new_mod == "io"
    assert m_a_0.new_attr == "StringIO"


# Generated at 2022-06-25 22:32:59.590584
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test a constructor call
    MovedModule_0 = MovedModule('__builtin__','__builtin__','builtins')

    # Test a constructor call
    MovedModule_1 = MovedModule('__main__','__main__')


# Generated at 2022-06-25 22:33:05.337704
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute(m_1, m_2, m_3, m_4, m_5)


# Generated at 2022-06-25 22:33:07.343450
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('name0', 'old0', 'new0')


# Generated at 2022-06-25 22:33:09.500609
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute(None, None, None, None, None)


# Generated at 2022-06-25 22:33:20.926224
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from typed_ast.ast3 import AST
    from .sixmoves import SixMovesTransformer
    a_s_t_0 = AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.target == (2, 7)

# Generated at 2022-06-25 22:33:25.944581
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    param0 = 'filter'
    param1 = 'itertools'
    param2 = 'builtins'
    param3 = 'ifilter'
    param4 = 'filter'
    movedattribute_0 = MovedAttribute(param0, param1, param2, param3, param4)
    assert movedattribute_0 != None


# Generated at 2022-06-25 22:33:33.881491
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0.ast, module_0.AST)
    assert six_moves_transformer_0.dependencies == ['six']
    assert isinstance(six_moves_transformer_0.rewrites, list)
    assert six_moves_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:33:37.101537
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test for constructor of class SixMovesTransformer
    test_case_0()

if __name__ == '__main__':
    # Unit tests for SixMovesTransformer
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:33:47.112979
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 is not None
    assert six_moves_transformer_0.ast is a_s_t_0

# Generated at 2022-06-25 22:33:48.748507
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name_0", "old_0")


# Generated at 2022-06-25 22:33:50.549911
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', None, 'old_attr', 'new_attr')


# Generated at 2022-06-25 22:34:05.075813
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # TODO: Gotta be a better way
    import six.moves.cStringIO as cStringIO
    import six.moves.builtins as builtins
    import six.moves.imp as imp
    import six.moves.importlib as importlib
    import six as six
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute("filter", "itertools", "builtins")
    moved_attribute_2 = MovedAttribute("intern", "__builtin__", "sys")
    moved_attribute_3 = MovedAttribute("range", "__builtin__", "builtins")
    moved_attribute_4 = MovedAttribute("reload_module", "__builtin__", "imp")
    moved_attribute_

# Generated at 2022-06-25 22:34:09.289864
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("builtins", "__builtin__")
    assert moved_module_0.name == "builtins"
    assert moved_module_0.old == "__builtin__"
    assert moved_module_0.new == "builtins"


# Generated at 2022-06-25 22:34:11.760303
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    # constructor call
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:34:15.686426
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

# Unit tests for class MovedAttribute

# Generated at 2022-06-25 22:34:19.907662
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    assert isinstance(MovedModule(a_s_t_0, a_s_t_0, a_s_t_0), MovedModule)


# Generated at 2022-06-25 22:34:23.395977
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Assert if the __init__ function raises any errors.
    test_MovedModule_0 = MovedModule('name', 'old')
    test_MovedModule_1 = MovedModule('name', 'old', 'new')


# Generated at 2022-06-25 22:34:25.202039
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:34:35.836689
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_0.ImportFrom(module_0.Name(module_0.Load(), 'six.moves', module_0.Load()), module_0.alias(module_0.Name(module_0.Load(), 'python_2_unicode_compatible', module_0.Load()), None), 0)
    module_0.Assign([module_0.Name(module_0.Store(), 'python_2_unicode_compatible', module_0.Store())], module_0.Name(module_0.Load(), 'six.moves.python_2_unicode_compatible', module_0.Load()))

# Generated at 2022-06-25 22:34:44.434385
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        test_case_0()
        print('Unit test for constructor of class SixMovesTransformer: ok')
    except AssertionError:
        print('Unit test for constructor of class SixMovesTransformer: FAILED')

if __name__ == '__main__':
    test_SixMovesTransformer()
    test_0 = Tuple([Num(1), Num(2)])
    #test_1 = Subscript(Name('x', Load), Index(Num(1)), Load)

# Generated at 2022-06-25 22:34:47.387492
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(module_0)

test_case_0()

test_SixMovesTransformer()

# Generated at 2022-06-25 22:34:55.895785
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    result = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert result


# Generated at 2022-06-25 22:34:57.487318
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None, None, None)

# Generated at 2022-06-25 22:34:59.629055
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = MovedModule("builtins", "__builtin__")


# Generated at 2022-06-25 22:35:10.371973
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    #
    try:
        from . import six
    except ImportError:
        six = None

    assert six_moves_transformer.dependencies == ['six']
    assert six_moves_transformer.target == (2, 7)
    assert six_moves_transformer.rewrites == _get_rewrites()

# Generated at 2022-06-25 22:35:12.289783
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    atr_0 = SixMovesTransformer()
    assert isinstance(atr_0, BaseImportRewrite)

# Generated at 2022-06-25 22:35:23.210275
# Unit test for constructor of class MovedModule
def test_MovedModule():
    args_0 = None
    args_1 = 'name'
    args_2 = 'name', 'old'
    args_3 = 'name', 'old', 'new'

    args_4 = 1
    args_5 = 1, 2
    args_6 = 1, 2, 3

    args_7 = 'name', 'old', 3

    args_8 = 'name', 'old', 'new', 4

    # Invalid parameters
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule(*args_4)
    with pytest.raises(TypeError):
        MovedModule(*args_5)
    with pytest.raises(TypeError):
        MovedModule(*args_6)

# Generated at 2022-06-25 22:35:29.828097
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    target_1 = (2, 7)
    rewrites_1 = _get_rewrites()
    dependencies_1 = ['six']
    test_obj_0 = SixMovesTransformer(a_s_t_0, target_1, rewrites_1, dependencies_1)
    return (test_obj_0, )

if __name__ == '__main__':
    import sys
    # When this module is executed from the command-line, it runs all its tests
    #print('Running module test: %s' % __file__)
    __test__ = {}
    test_SixMovesTransformer(*sys.argv[1:])

# Generated at 2022-06-25 22:35:37.330058
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_m_s_s_t_0 = MovedAttribute(
        name="name",
        old_mod="old_mod",
        new_mod="new_mod",
        old_attr="old_attr",
        new_attr="new_attr"
    )
    assert a_m_s_s_t_0.name is "name"
    assert a_m_s_s_t_0.new_mod is "new_mod"
    assert a_m_s_s_t_0.new_attr is "new_attr"


# Generated at 2022-06-25 22:35:38.984972
# Unit test for constructor of class MovedModule
def test_MovedModule():
    #MovedModule(name, old, new=None)
    pass


# Generated at 2022-06-25 22:35:42.722140
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_ast_0 = ast.parse('import builtins')
    a_s_t_0 = copy.deepcopy(module_ast_0)
    test_0 = SixMovesTransformer()
    assert True


# Generated at 2022-06-25 22:35:52.637328
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(six_moves_transformer_1)
    assert not getattr(six_moves_transformer_0, "dict_0")


# Generated at 2022-06-25 22:35:54.638313
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()

if __name__ == '__main__':
    test_MovedAttribute()

# Generated at 2022-06-25 22:35:57.860555
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)



# Generated at 2022-06-25 22:36:09.065669
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert issubclass(MovedModule, object)
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object

# Generated at 2022-06-25 22:36:12.328587
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:21.291240
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    keyword_0 = None
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}


# Generated at 2022-06-25 22:36:22.656142
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()


# Generated at 2022-06-25 22:36:27.168363
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    moved_attribute_0 = MovedAttribute(a_s_t_1, a_s_t_0)


# Generated at 2022-06-25 22:36:33.350828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    moved_module_0 = MovedModule(six_moves_transformer_0, six_moves_transformer_1, six_moves_transformer_0)

# Generated at 2022-06-25 22:36:44.612379
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    moved_attribute_1 = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    moved_attribute_2 = MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    moved_attribute_3 = MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    moved_attribute_4 = MovedAttribute('intern', '__builtin__', 'sys')
    moved_attribute_5 = MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map')

# Generated at 2022-06-25 22:36:53.284912
# Unit test for constructor of class MovedModule
def test_MovedModule():
    parameter_0 = None
    parameter_1 = None
    parameter_2 = None
    moved_module_0 = MovedModule(parameter_0, parameter_1, parameter_2)


# Generated at 2022-06-25 22:37:04.566649
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 is not None
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    assert six_moves_transformer_1 is not None
    complex_0 = None
    list_0 = [complex_0, a_s_t_1, complex_0]
    moved_attribute_0 = MovedAttribute(a_s_t_1, six_moves_transformer_1, complex_0, list_0)

# Generated at 2022-06-25 22:37:14.451230
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    complex_0 = None
    complex_1 = None
    list_0 = [complex_1, complex_1, complex_0]
    moved_module_0 = MovedModule(six_moves_transformer_1, list_0)
    assert(moved_module_0.name == six_moves_transformer_1)
    assert(moved_module_0.new == list_0)


# Generated at 2022-06-25 22:37:17.714813
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_1 = {}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert (isinstance(six_moves_transformer_0, BaseImportRewrite))



# Generated at 2022-06-25 22:37:19.028872
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()

test_MovedAttribute()

# Generated at 2022-06-25 22:37:30.159801
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    dict_2 = {}
    a_s_t_2 = module_0.AST(**dict_2)
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_2)
    dict_3 = {}
    a_s_t_3 = module_0.AST(**dict_3)
    six_moves_transformer_

# Generated at 2022-06-25 22:37:31.933312
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(a_s_t_1)


# Generated at 2022-06-25 22:37:42.025581
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTrans

# Generated at 2022-06-25 22:37:51.736739
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    complex_0 = None
    list_0 = [complex_0, a_s_t_1, complex_0]
    moved_attribute_0 = MovedAttribute(a_s_t_1, six_moves_transformer_1, complex_0, list_0)

    assert moved_attribute_0.name == a_s_t_1
    assert moved_attribute_0.new_mod == six_moves_

# Generated at 2022-06-25 22:38:01.783043
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    complex_0 = None
    list_0 = [complex_0, a_s_t_1, complex_0]
    moved_attribute_0 = MovedAttribute(six_moves_transformer_1, six_moves_transformer_1, complex_0, list_0)
    print(moved_attribute_0.name)
    print(moved_attribute_0.new_mod)

# Generated at 2022-06-25 22:38:17.138989
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert True == False


# Generated at 2022-06-25 22:38:19.783988
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('module', 'old_module', 'new_module')
    assert moved_module.name == 'module'
    assert moved_module.new == 'new_module'


# Generated at 2022-06-25 22:38:21.027459
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()


# Generated at 2022-06-25 22:38:24.906532
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(six_moves_transformer_0)


# Generated at 2022-06-25 22:38:26.369604
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:38:27.541220
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()

import typing as module_1


# Generated at 2022-06-25 22:38:30.814593
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert (MovedModule.__class__ == type)
    assert MovedModule(a_s_t_1, six_moves_transformer_1, complex_0)
    assert MovedModule(a_s_t_1, six_moves_transformer_1)


# Generated at 2022-06-25 22:38:36.973031
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
  dict_0 = {}
  tuple_0 = None
  complex_0 = None
  list_0 = [complex_0, complex_0]
  moved_attribute_0 = MovedAttribute(tuple_0, six_moves_transformer_2, bool_0)


# Generated at 2022-06-25 22:38:45.309895
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    complex_0 = None
    list_0 = [complex_0, a_s_t_1, complex_0]
    moved_attribute_0 = MovedAttribute(a_s_t_1, six_moves_transformer_1, complex_0, list_0)


# Generated at 2022-06-25 22:38:51.304197
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    MovedAttribute = six_moves_transformer_0.MovedAttribute
    MovedModule = six_moves_transformer_0.MovedModule
    _moved_attributes = six_moves_transformer_0._moved_attributes
    _urllib_parse_moved_attributes = six_moves_transformer_0._urllib_parse_moved_attributes
    _urllib_error_moved_attributes = six_moves_transformer_0._urllib_error_moved_attributes
    _urllib_request_moved_

# Generated at 2022-06-25 22:39:17.432811
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Nothing to test here
    return None


# Generated at 2022-06-25 22:39:23.694741
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Create a SixMovesTransformer object
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    
    # Make sure the constructor was called
    assert six_moves_transformer_0


# Generated at 2022-06-25 22:39:24.685592
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:39:32.685681
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_0 = object
    six_moves_transformer_0 = SixMovesTransformer(module_0)
    module_1 = object
    six_moves_transformer_1 = SixMovesTransformer(module_1)
    six_moves_transformer_2 = SixMovesTransformer(module_1)
    bool_0 = bool
    moved_module_0 = MovedModule(six_moves_transformer_1, six_moves_transformer_2, bool_0)
    six_moves_transformer_3 = SixMovesTransformer(module_0)
    six_moves_transformer_4 = SixMovesTransformer(module_1)
    float_0 = float

# Generated at 2022-06-25 22:39:36.358346
# Unit test for constructor of class MovedModule
def test_MovedModule():
    complex_0 = None
    list_0 = [complex_0, complex_0, complex_0]
    moved_attribute_0 = MovedAttribute(complex_0, complex_0, complex_0, list_0)
    tuple_0 = None


# Generated at 2022-06-25 22:39:47.645896
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    complex_0 = None
    list_0 = [complex_0, a_s_t_1, complex_0]
    moved_attribute_0 = MovedAttribute(a_s_t_1, six_moves_transformer_1, complex_0, list_0)
    tuple_0 = None
    dict_1 = {}
    a_s_t_2 = module_0.AST(**dict_1)


# Generated at 2022-06-25 22:39:52.422813
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_attribute_0 = MovedAttribute("http_client", "httplib", "http.client")
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_module_0 = MovedModule("http_client.client", six_moves_transformer_0, moved_attribute_0)


# Generated at 2022-06-25 22:40:01.026128
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test 1: Call without any arguments
    # Expected: __init__ should set default values to all attributes
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_0)
    moved_module_0 = MovedModule(six_moves_transformer_0, six_moves_transformer_1, six_moves_transformer_2)
    assert moved_module_0.name == six_moves_transformer_0
    assert moved_module

# Generated at 2022-06-25 22:40:06.429094
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    complex_0 = None
    list_0 = [complex_0, complex_0, complex_0]
    moved_attribute_0 = MovedAttribute(complex_0, complex_0, complex_0, list_0)
    tuple_0 = None
    moved_attribute_1 = MovedAttribute(tuple_0, tuple_0, tuple_0)


# Generated at 2022-06-25 22:40:12.555434
# Unit test for constructor of class MovedModule
def test_MovedModule():
    complex_0 = None
    list_0 = [complex_0, complex_0, complex_0]
    moved_module_0 = MovedModule(complex_0, complex_0, list_0)
    str_0 = moved_module_0.name
    moved_module_0.new = list_0
