

# Generated at 2022-06-25 22:31:17.334751
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(name = "name", old_mod = "old_mod", new_mod = "new_mod", old_attr = "old_attr", new_attr = "new_attr")
    assert moved_attribute_0.name == "name"
    assert moved_attribute_0.new_mod == "new_mod"
    assert moved_attribute_0.new_attr == "new_attr"


# Generated at 2022-06-25 22:31:21.970361
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute_0 = MovedAttribute('test_MovedAttribute_name_0', 'test_MovedAttribute_old_mod_0', 'test_MovedAttribute_new_mod_0', 'test_MovedAttribute_old_attr_0', 'test_MovedAttribute_new_attr_0')


# Generated at 2022-06-25 22:31:26.387024
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule_0 = MovedModule('builtins', '__builtin__')
    string_0 = repr(MovedModule_0)
    string_1 = str(MovedModule_0)
    string_2 = MovedModule_0.__dict__
    string_3 = MovedModule_0.__doc__
    

# Generated at 2022-06-25 22:31:29.191559
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:34.991533
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_0 = SixMovesTransformer.MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move_0.name == 'cStringIO'
    assert move_0.new_mod == 'io'
    assert move_0.new_attr == 'StringIO'

test_case_0()
test_MovedAttribute()

# Generated at 2022-06-25 22:31:41.672739
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test with no args
    try:
        a_moved_module_0 = MovedModule()
    except:
        a_moved_module_0 = None
    # Test with multiple args
    try:
        a_moved_module_1 = MovedModule('name', 'old', 'new')
    except:
        a_moved_module_1 = None
    # Verify objects are not identical
    assert a_moved_module_0 is not a_moved_module_1


# Generated at 2022-06-25 22:31:44.545843
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:52.371734
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for correct runtime behavior
    assert MovedModule('builtins', '__builtin__')
    # Test for correct runtime behavior
    assert MovedModule('configparser', 'ConfigParser')
    # Test for correct runtime behavior
    assert MovedModule('copyreg', 'copy_reg')
    # Test for correct runtime behavior
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    # Test for correct runtime behavior
    assert MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    # Test for correct runtime behavior
    assert MovedModule('http_cookiejar', 'cookielib', 'http.cookiejar')
    # Test for correct runtime behavior
    assert MovedModule('http_cookies', 'Cookie', 'http.cookies')
    # Test for

# Generated at 2022-06-25 22:32:06.110730
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('string', 'string').__str__() == "MovedModule(name='string', old='string', new='string')"
    assert MovedModule('string', 'string', 'string').__str__() == "MovedModule(name='string', old='string', new='string')"
    assert MovedModule('string', old='string').__str__() == "MovedModule(name='string', old='string', new='string')"
    assert MovedModule('string', new='string').__str__() == "MovedModule(name='string', old='string', new='string')"
    assert MovedModule('string', old='string', new='string').__str__() == "MovedModule(name='string', old='string', new='string')"

# Generated at 2022-06-25 22:32:10.146338
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = "name"
    old_0 = "old"
    new_0 = "new"
    moved_module_0 = MovedModule(name_0, old_0, new_0)


# Generated at 2022-06-25 22:32:24.358329
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()

    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_4 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_5 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_6 = SixMovesTransformer(a_s_t_0)
   

# Generated at 2022-06-25 22:32:29.323112
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(name='builtins', old='__builtin__', new='builtins')
    assert moved_module_0.new == 'builtins'
    assert moved_module_0.name == 'builtins'
    assert moved_module_0.old == '__builtin__'


# Generated at 2022-06-25 22:32:36.808632
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.old_mod == "old_mod"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.old_attr == "old_attr"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-25 22:32:42.981094
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    if (six_moves_transformer_0.ast != a_s_t_0):
        print("Test with expected result failed.")
    if (isinstance(six_moves_transformer_0, SixMovesTransformer) != True):
        print("Test with expected result failed.")
    six_moves_transformer_0.target = (2, 7)
    six_moves_transformer_0.rewrites = _get_rewrites()
    six_moves_transformer_0.dependencies = ['six']

# Generated at 2022-06-25 22:32:51.541410
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    # Assert that the constructor of class SixMovesTransformer is starting with the right state
    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.dependencies == ['six']
    assert six_moves_transformer_0.rewrites == _get_rewrites()

# Unit tests for method SixMovesTransformer.transform of class SixMovesTransformer

# Generated at 2022-06-25 22:32:54.061784
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:32:59.540032
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_s_t_0 = module_0.AST()
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute(__name__, "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:33:01.356899
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    print('Testing MovedAttribute constructor')
    instance_0 = MovedAttribute(None, None, None)


# Generated at 2022-06-25 22:33:05.547992
# Unit test for constructor of class MovedModule
def test_MovedModule():
    f_0 = MovedModule("f_0", "a_0", "b_0")
    assert f_0.name == "f_0"
    assert f_0.old == "a_0"
    assert f_0.new == "b_0"


# Generated at 2022-06-25 22:33:11.058587
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute_0.name == 'name'
    assert moved_attribute_0.new_mod == 'new_mod'
    assert moved_attribute_0.new_attr == 'new_attr'


# Generated at 2022-06-25 22:33:22.448549
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test with both required params
    movedModule_0 = MovedModule(name = 'name', old = 'old')
    assert movedModule_0.name == 'name'
    assert movedModule_0.old == 'old'
    assert movedModule_0.new == 'name'

    # Test with only required params:
    movedModule_2 = MovedModule(name = 'name', old = 'old')


# Generated at 2022-06-25 22:33:26.410596
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    SixMovesTransformer(ast_tree) -> transform_module

    Return callable that transforms Python 2 `ast_tree` to Python 3,
    with support for migrating modules that have been moved to `six.moves`.
    """
    test_case_0()

# Generated at 2022-06-25 22:33:32.355989
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute_0.name == "name"
    assert moved_attribute_0.new_mod == "new_mod"
    assert moved_attribute_0.new_attr == "new_attr"


# Generated at 2022-06-25 22:33:34.876573
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        a_MovedModule_0 = MovedModule('str', 'str')
    except Exception as error:
        assert False, error


# Generated at 2022-06-25 22:33:38.745001
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        a_s_t_0 = module_0.AST()
        six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    except Exception as exception_0:
        assert False


# Generated at 2022-06-25 22:33:42.226308
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == 'name'
    assert moved_module_0.new == 'new'

test_case_0()

# Generated at 2022-06-25 22:33:43.963350
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_moved_module_0 = MovedModule("itertools", "itertools")


# Generated at 2022-06-25 22:33:45.305098
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_instance_0 = MovedModule(1, 2, 3)

# Generated at 2022-06-25 22:33:46.255935
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    pass


# Generated at 2022-06-25 22:33:47.553671
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with raises(ValueError):
        MovedAttribute()


# Generated at 2022-06-25 22:34:04.817824
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'S<}e7?*1\x1bZ{B4s#'
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = 410.986
    str_1 = 'UserList'
    int_0 = -30
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    bytes_0 = None
    str_2 = '=8j\x16\x1b\x1e\x1d6\x0b\x0c'
    bytes_1 = b''
    complex_0 = None
    moved

# Generated at 2022-06-25 22:34:12.375039
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        # Testing that MovedModule constructor raises TypeError if invalid number of arguments passed
        moved_module_2 = MovedModule(moved_module_0, six_moves_transformer_0)
        assert False
    except TypeError:
        pass

    try:
        # Testing that MovedModule constructor raises TypeError if invalid type of arguments passed
        moved_module_2 = MovedModule(six_moves_transformer_0, six_moves_transformer_0, six_moves_transformer_0)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-25 22:34:21.989687
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_3 = 'customer'
    str_4 = 'export'
    str_5 = 'close'
    int_1 = 1280
    str_6 = 'fUwM(z*f\tM9XG\x0b\x0b#y"<'
    str_7 = '\x0c>wxU\x0b9FA\t,%@Xf>z#'
    list_5 = [str_7, str_7, str_7]
    a_s_t_2 = module_0.AST()
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_2)
    float_1 = -764.08303
    str_8 = 'urlparse'
    int_2 = -2128
    six_moves_trans

# Generated at 2022-06-25 22:34:24.638062
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(13, 'DjK?1O', 'i\x0f%\x06v')


# Generated at 2022-06-25 22:34:35.517201
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '-'
    str_1 = 'a`u<'
    str_2 = '5b\x7fq'
    str_3 = '\x0f0H\x1a\x1d\x03\x05\x11/\x14'
    str_4 = 'N\x05\x0e\x1d\x0c\n\x15\x04\x11\x0c\x1d\x01\x11'
    float_0 = -690.3975
    bytes_0 = b'\x1c\x18\x1d\x07\x13\x06\x1f'
    bool_0 = True
    int_0 = 1

# Generated at 2022-06-25 22:34:37.524396
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_0.AST()
    SixMovesTransformer()



# Generated at 2022-06-25 22:34:39.440094
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert hasattr(SixMovesTransformer, '__init__')

# Generated at 2022-06-25 22:34:44.248596
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # Unit test for constructor of class MovedAttribute
    def test_MovedAttribute():
        repr_0 = repr(moved_attribute_2)
        repr_1 = repr(moved_attribute_0)
        repr_2 = repr(moved_attribute_1)

# Generated at 2022-06-25 22:34:45.643166
# Unit test for constructor of class MovedModule
def test_MovedModule():
  moved_module_0 = MovedModule(None, None, None)


# Generated at 2022-06-25 22:34:47.472011
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_0 = MovedModule('UserList', 'cStringIO', 'os')


# Generated at 2022-06-25 22:35:09.877648
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'r$\n)yB\x0bX\x7f'
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = -957.128687
    str_1 = 'UserList'
    int_0 = -1364
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    bytes_0 = None
    str_2 = 'hWlo*u7!j]VYy{'
    bytes_1 = b''
    complex_0 = None

# Generated at 2022-06-25 22:35:21.065102
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '6Z\x6f\x6e\x6dr\x70\n*\x65\x75\x6d\x68Lmf\x71\x5f\x5b+\x7a\x73\x7b'
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = -957.128687
    str_1 = 'UserList'
    int_0 = -1364
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    bytes_0 = None

# Generated at 2022-06-25 22:35:29.244646
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'X{ZH0'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -1567
    str_1 = '<&e{i'
    bytes_0 = b'BU=\x0fPd\x0c%\x0e\x0e\x13\x1b,[\x18\x12'
    complex_0 = -890.6833
    moved_attribute_0 = MovedAttribute(int_0, str_1, bytes_0, complex_0)
    assert(moved_attribute_0.name == int_0)
    assert(moved_attribute_0.new_mod == str_1)

# Generated at 2022-06-25 22:35:39.661875
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test case : test_1
    str_0 = 'x@\t\r^r\r\rP\nD]\x0b'
    list_0 = [str_0, str_0]
    a_s_t_0 = module_0.AST(*list_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_1 = ''
    str_2 = ''
    str_3 = 'M+'
    str_4 = 'hWlo*u7!j]VYy{'
    bytes_0 = b''
    complex_0 = dup_1 = dup_2 = dup_3 = dup_0 = complex(1.0, 1.0)

# Generated at 2022-06-25 22:35:49.782690
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '<\nG\x0c\x1a@@,\x1bB'
    str_1 = 'StringIO'
    str_2 = '_thread'
    int_0 = -94885
    bytes_0 = b''
    str_3 = '\x1b\x1f\n\x10\x04\x11\x0c\x00\x1c\x1f&\x1f'
    six_moves_transformer_0 = SixMovesTransformer()
    moved_attribute_0 = MovedAttribute(str_0, str_1, str_3, int_0)
    moved_attribute_1 = MovedAttribute(str_0, str_1, six_moves_transformer_0, moved_attribute_0)
    moved_attribute_

# Generated at 2022-06-25 22:35:55.945885
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moves_transformer_0 = SixMovesTransformer(object())
    int_0 = -1823
    complex_0 = None
    moved_attribute_0 = MovedAttribute(int_0, six_moves_transformer_0, complex_0)
    list_0 = [moved_attribute_0, moved_attribute_0]
    moved_module_0 = MovedModule(list_0, six_moves_transformer_0)


# Generated at 2022-06-25 22:35:59.981167
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:11.273375
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'y:G]\t'
    a_s_t_0 = module_0.AST()
    str_1 = '\x0b\x0c<N\t6\x0b\x0c<N\t6\x0b\x0c<N\t6'
    list_0 = [str_0, str_1]
    int_0 = -1360
    float_0 = 507.832
    str_2 = 'urllib_error'
    moved_attribute_0 = MovedAttribute(str_0, str_0, str_1, int_0)
    moved_attribute_1 = MovedAttribute(moved_attribute_0, str_1, moved_attribute_0, str_2)

# Generated at 2022-06-25 22:36:20.502910
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'CGIHTTPServer'
    int_0 = 1943
    six_moves_transformer_0 = SixMovesTransformer()
    list_0 = [six_moves_transformer_0, six_moves_transformer_0, six_moves_transformer_0]
    moved_module_0 = MovedModule(str_0, six_moves_transformer_0, list_0)
    six_moves_transformer_1 = SixMovesTransformer(True)
    six_moves_transformer_2 = SixMovesTransformer(six_moves_transformer_1)
    bool_0 = False
    moved_module_1 = MovedModule(int_0, bool_0, six_moves_transformer_2)
    moved_module_2 = Moved

# Generated at 2022-06-25 22:36:29.780699
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_x_0 = 'oM\x0c>wxU\x0b9FA\t,%@Xf>z#'
    list_x_0 = [str_x_0, str_x_0, str_x_0]
    a_s_t_x_0 = module_0.AST()
    six_moves_transformer_x_0 = SixMovesTransformer(a_s_t_x_0)
    float_x_0 = -957.128687
    str_x_1 = 'UserList'
    int_x_0 = -1364
    six_moves_transformer_x_1 = SixMovesTransformer(a_s_t_x_0)
    bytes_x_0 = None

# Generated at 2022-06-25 22:36:56.561760
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with expected(Exception):
        SixMovesTransformer(module_0.AST())

if __name__ == '__main__':
    test_SixMovesTransformer()
    test_case_0()

# Generated at 2022-06-25 22:37:04.478183
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_0 = '!y9P2/{%k\x17\x13'
    float_0 = -1.354908E38
    list_0 = [float_0, float_0, float_0]
    moved_module_0 = MovedModule(str_0, six_moves_transformer_0, list_0)


# Generated at 2022-06-25 22:37:14.701264
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test with args: 'oM\x0c>wxU\x0b9FA\t,%@Xf>z#', None
    str_0 = 'oM\x0c>wxU\x0b9FA\t,%@Xf>z#'
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = -957.128687
    str_1 = 'UserList'
    int_0 = -1364
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    bytes_0 = None

# Generated at 2022-06-25 22:37:17.820491
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:37:28.758127
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def test_SixMovesTransformer_0():
        i_a_t_0 = module_0.ImportFrom()
        six_moves_transformer_0 = SixMovesTransformer(i_a_t_0)
        str_0 = '))Z[cHU"\n(6p'
        set_0 = {str_0, str_0}
        six_moves_transformer_1 = SixMovesTransformer(set_0)
        six_moves_transformer_2 = SixMovesTransformer(six_moves_transformer_0)
        float_0 = 8.9
        list_0 = []
        six_moves_transformer_3 = SixMovesTransformer(list_0)

# Generated at 2022-06-25 22:37:33.289912
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Instantiation of moved_module_0
    list_0 = []
    six_moves_transformer_0 = SixMovesTransformer(six_moves_transformer_0)
    moved_module_0 = MovedModule(moved_module_0, six_moves_transformer_0)

# Generated at 2022-06-25 22:37:42.640278
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = '2}%\x1e\x1d\x1f\x1f\x1d\x1e\x1f\x1c\x1e\x1f\x10'
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = -957.128687
    str_1 = 'UserList'
    int_0 = -1364
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    bytes_0 = None
    str_2 = 'hWlo*u7!j]VYy{'

# Generated at 2022-06-25 22:37:52.342709
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = -77
    list_0 = ['X', 'Yu', '3(vj' '0A>\x0c', '\x0b\x0b']
    moved_attribute_0 = MovedAttribute(int_0, '\x0c', list_0)
    str_0 = '9Vu\x0b'
    list_1 = [str_0, str_0, str_0]
    moved_module_0 = MovedModule(int_0, moved_attribute_0, list_1)
    a_s_t_0 = module_0.AST()
    moved_attribute_1 = MovedAttribute(moved_attribute_0, a_s_t_0, moved_module_0)

# Generated at 2022-06-25 22:37:53.714053
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # AST
    test_case_0()


# Generated at 2022-06-25 22:38:01.784446
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_3 = 'Y\r\x12\x0bx}I\x1d\x1c'
    a_s_t_2 = module_0.AST()
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    six_moves_transformer_4 = SixMovesTransformer(a_s_t_3)
    moved_attribute_3 = MovedAttribute(str_3, six_moves_transformer_3, six_moves_transformer_4)


# Generated at 2022-06-25 22:38:55.610814
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(str_0, moved_attribute_2)


# Generated at 2022-06-25 22:39:02.895536
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'Y\x1dWS$o\x12\x1a(O\x1aI\x1d,\x17\x16\x1a.\x04\x01w\x1a\x1e4[cO'
    list_0 = [str_0, str_0]
    a_s_t_0 = module_0.AST(*list_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:13.264751
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'AH&^i'
    moved_attribute_0 = MovedAttribute(str_0)
    str_1 = ''
    moved_attribute_1 = MovedAttribute(str_0, moved_attribute_0, str_0, moved_attribute_0, str_1)
    moved_module_0 = MovedModule(moved_attribute_0, str_0, str_1)
    moved_module_0 = MovedModule(moved_attribute_0, str_1)
    moved_module_0 = MovedModule(str_0, moved_attribute_1)
    moved_module_0 = MovedModule(str_1)
    moved_module_0 = MovedModule(str_0, moved_attribute_1, str_0)

# Generated at 2022-06-25 22:39:14.662350
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()


# Generated at 2022-06-25 22:39:25.949367
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'UserString'
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    list_1 = []
    six_moves_transformer_1 = SixMovesTransformer(*list_1)
    str_1 = 'cStringIO'
    str_2 = 'UserString'
    list_2 = [str_1, str_0, str_2, str_1]
    six_moves_transformer_2 = SixMovesTransformer(*list_2)
    a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 22:39:29.650689
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    int_0 = -1364
    str_0 = 'hWlo*u7!j]VYy{'
    bytes_0 = b''
    complex_0 = None
    moved_attribute_0 = MovedAttribute(int_0, str_0, bytes_0, complex_0)


# Generated at 2022-06-25 22:39:31.084873
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    six_moves_transformer_2 = SixMovesTransformer(moved_attribute_1)


# Generated at 2022-06-25 22:39:34.674767
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Instance of class AST
    a_s_t_0 = module_0.AST()
    # Instance of class SixMovesTransformer
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:39:45.499566
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'xF=\x1d\x1d@gL-\x0c\x1d'
    str_1 = '\x1c\x18\x0b7;\x07\x1d'
    str_2 = 'z5\x1ckL\x0e\x1eSa'
    list_0 = [str_0, str_0, str_0, str_0]
    tuple_0 = (str_1, str_2, list_0)
    moved_module_0 = MovedModule(vector_0, tuple_0)
    vector_0 = vector()
    vector_1 = vector()
    vector_2 = vector()
    vector_3 = vector()


# Generated at 2022-06-25 22:39:53.720634
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = [str_0, str_0, str_0]
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    float_0 = -957.128687
    str_1 = 'UserList'
    int_0 = -1364
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    bytes_0 = None
    str_2 = 'hWlo*u7!j]VYy{'
    bytes_1 = b''
    complex_0 = None
    moved_attribute_0 = MovedAttribute(int_0, str_2, bytes_1, complex_0)
    moved_attribute_1 = MovedAttribute