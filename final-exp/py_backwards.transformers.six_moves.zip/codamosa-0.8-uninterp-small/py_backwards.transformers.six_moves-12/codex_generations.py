

# Generated at 2022-06-25 22:31:06.084774
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:31:08.297613
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(name=None, old_mod=None, new_mod=None, old_attr=None, new_attr=None)
    assert moved_attribute_0 is not None


# Generated at 2022-06-25 22:31:17.821137
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    a_moved_attribute_1 = MovedAttribute("cStringIO", "cStringIO", "io")
    a_moved_attribute_2 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    a_moved_attribute_3 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    a_moved_attribute_4 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    a_moved_attribute_5 = MovedAttribute("intern", "__builtin__", "sys")
    a_moved_attribute_

# Generated at 2022-06-25 22:31:20.332986
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:24.109123
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a_move.name == "cStringIO"
    assert a_move.new_mod == "io"
    assert a_move.new_attr == "StringIO"


# Generated at 2022-06-25 22:31:27.059432
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

import unittest


# Generated at 2022-06-25 22:31:29.988110
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:32.698576
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = "builtins"
    old_0 = "__builtin__"
    MovedModule_0 = MovedModule(name_0, old_0)


# Generated at 2022-06-25 22:31:40.167289
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = 'name_0'
    old_mod_0 = 'old_mod_0'
    new_mod_0 = 'new_mod_0'
    old_attr_0 = 'old_attr_0'
    new_attr_0 = 'new_attr_0'
    # Default argument new_attr_0 not tested

    movedattribute_0 = MovedAttribute(name_0, old_mod_0, new_mod_0, old_attr_0, new_attr_0)


# Generated at 2022-06-25 22:31:45.314132
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert a_moved_attribute_0.name == 'cStringIO'
    assert a_moved_attribute_0.new_mod == 'io'
    assert a_moved_attribute_0.new_attr == 'StringIO'


# Generated at 2022-06-25 22:31:50.279720
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')


# Generated at 2022-06-25 22:31:56.564947
# Unit test for constructor of class MovedModule
def test_MovedModule():
    var_0 = MovedModule('dummy_process', 'Process', 'collections')
    assert var_0.name == 'dummy_process'
    assert str(var_0.name) == 'dummy_process'
    assert var_0.new == 'collections'
    assert str(var_0.new) == 'collections'


# Generated at 2022-06-25 22:32:03.143540
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', )
    assert moved_attribute_0.name == 'cStringIO'
    assert moved_attribute_0.new_mod == 'io'
    assert moved_attribute_0.new_attr == 'StringIO'


# Generated at 2022-06-25 22:32:14.366797
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('builtins', '__builtin__')
    MovedModule('configparser', 'ConfigParser')
    MovedModule('copyreg', 'copy_reg')
    MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    MovedModule('_dummy_thread', 'dummy_thread', '_dummy_thread')
    MovedModule('http_cookiejar', 'cookielib', 'http.cookiejar')
    MovedModule('http_cookies', 'Cookie', 'http.cookies')
    MovedModule('html_entities', 'htmlentitydefs', 'html.entities')
    MovedModule('html_parser', 'HTMLParser', 'html.parser')
    MovedModule('http_client', 'httplib', 'http.client')

# Generated at 2022-06-25 22:32:18.636697
# Unit test for constructor of class MovedModule
def test_MovedModule():
      moved_module_0 = MovedModule("six.moves.urllib.parse", "six.moves.urllib_parse", "urllib.parse")
      moved_module_0.name
      moved_module_0.new


# Generated at 2022-06-25 22:32:21.533961
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    assert type(SixMovesTransformer(a_s_t_0)) == SixMovesTransformer


# Generated at 2022-06-25 22:32:27.679048
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_0 = __import__('typed_ast._ast3', globals(), locals(), ['AST'], 0)
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert(isinstance(six_moves_transformer_0, SixMovesTransformer))


# Generated at 2022-06-25 22:32:32.699927
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    _moved_attribute = MovedAttribute('_moved_attribute', '_moved_attribute', '_moved_attribute', '_moved_attribute', '_moved_attribute')


# Generated at 2022-06-25 22:32:33.717812
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:32:35.454919
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass



# Generated at 2022-06-25 22:32:50.550048
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    list_1 = []
    bool_1 = True
    complex_1 = None
    moved_attribute_1 = MovedAttribute(list_1, bool_1, complex_1)
    list_2 = []
    bool_2 = True
    complex_2 = None
    moved_attribute_2 = MovedAttribute(list_2, bool_2, complex_2)
    list_3 = []
    bool_3 = True
    complex_3 = None
    moved_attribute_3 = MovedAttribute(list_3, bool_3, complex_3)
    list_4 = []
    bool_4 = True

# Generated at 2022-06-25 22:32:54.502280
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Check whether the constructor is working correctly
    moved_attribute_0 = MovedAttribute(None, None, None)

    assert (moved_attribute_0.name is None) and (moved_attribute_0.new_attr is None) and (moved_attribute_0.new_mod is None)


# Generated at 2022-06-25 22:33:00.973288
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert moved_attribute_0.name == list_0
    assert moved_attribute_0.new_mod == bool_0
    assert moved_attribute_0.new_attr == complex_0


# Generated at 2022-06-25 22:33:09.246102
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _get_rewrites()

# Generated at 2022-06-25 22:33:11.147677
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _1 = SixMovesTransformer()
    assert isinstance(_1, SixMovesTransformer)


# Generated at 2022-06-25 22:33:15.461293
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_module = MovedModule(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:33:18.397149
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:33:21.011146
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)

# Generated at 2022-06-25 22:33:22.679575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    string_0 = None
    moves_0 = MovedModule(string_0)

# Generated at 2022-06-25 22:33:25.634190
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:33:39.500152
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(bool(1), None)
    moved_module_1 = MovedModule(bool(1), complex(1))
    # AssertionError: None != complex(1)
    try:
        assert moved_module_0.new == moved_module_1.new
    except AssertionError:
        pass
    moved_module_2 = MovedModule(bool(1), None, None)
    # AssertionError: None != None
    try:
        assert moved_module_0.new == moved_module_2.new
    except AssertionError:
        pass


# Generated at 2022-06-25 22:33:41.395513
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = ""
    MovedModule(str_0, str_0)



# Generated at 2022-06-25 22:33:43.869886
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer(2, 7)
    assert isinstance(six_moves_transformer, SixMovesTransformer)


# Generated at 2022-06-25 22:33:45.946798
# Unit test for constructor of class MovedModule
def test_MovedModule():
    string_0 = "test"
    moved_module_0 = MovedModule("six", "six", string_0)



# Generated at 2022-06-25 22:33:49.642443
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_module_0 = MovedModule(list_0, bool_0, complex_0)
    assert moved_module_0.name == list_0
    assert moved_module_0.new == bool_0



# Generated at 2022-06-25 22:33:58.402602
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert_equal(moved_attribute_0.name, list_0)
    assert_equal(moved_attribute_0.new_mod, bool_0)
    assert_equal(moved_attribute_0.new_attr, list_0)
    # AssertionError: expected True, got None
    #assert_equal(moved_attribute_0.old_attr, bool_0)


# Generated at 2022-06-25 22:34:00.144798
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer is not None

# Generated at 2022-06-25 22:34:01.542616
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("builtins", "__builtin__", )


# Generated at 2022-06-25 22:34:02.958756
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer is not None


# Generated at 2022-06-25 22:34:06.740194
# Unit test for constructor of class MovedModule
def test_MovedModule():
    i = MovedModule('foo', 'bar')
    assert i.name == 'foo'
    assert i.new == 'bar'
    assert i.old == 'foo'


# Generated at 2022-06-25 22:34:19.812828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'name'
    old = 'old'
    new = 'new'
    moved_module_0 = MovedModule(name, old, new)


# Generated at 2022-06-25 22:34:25.973519
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    moved_attribute_0 = MovedAttribute(list_0, bool_0)
    moved_module_0 = MovedModule(list_0, bool_0)
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.rewrites == _get_rewrites()
    assert six_moves_transformer.dependencies == ['six']

# Generated at 2022-06-25 22:34:31.440348
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """ Test for constructor of class SixMovesTransformer """
    six_moves_transformer_0 = SixMovesTransformer()
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:34:39.241163
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    list_1 = []
    str_0 = "test_value"
    str_1 = "test_value"
    list_1.append(MovedModule(str_0, str_1))
    bool_1 = False
    six_moves_transformer_0 = SixMovesTransformer(list_1, bool_1)


# Generated at 2022-06-25 22:34:46.331580
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'c'
    str_4 = 'd'
    moved_attribute_1 = MovedAttribute(str_1, str_2, str_3, str_4)
    assert moved_attribute_1.name == 'a'
    assert moved_attribute_1.new_mod == 'b'
    assert moved_attribute_1.new_attr == 'c'


# Generated at 2022-06-25 22:34:53.899496
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Note: method test_case_0 contains code that generates errors and warnings
    # which cause the unit test to fail.
    # This is not an issue, because the code is used for testing purposes and it
    # is not part of this unit test.
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_module_0 = MovedModule(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:34:59.997005
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert moved_attribute_0.name == list_0
    assert moved_attribute_0.new_mod == bool_0
    assert moved_attribute_0.new_attr == list_0


# Generated at 2022-06-25 22:35:05.308452
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for __init__(name: str, old: str, new: Optional[str] = None)
    try:
        moved_module_0 = MovedModule(str_0, str_0, str_0)
    except:
        stypy.errors.StypyTypeError.get_error_msgs()
        stypy.errors.StypyTypeError.get_error_msgs()



# Generated at 2022-06-25 22:35:10.078437
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert issubclass(SixMovesTransformer, BaseImportRewrite) is True
    assert SixMovesTransformer.target is (2, 7)
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']


# Generated at 2022-06-25 22:35:13.503972
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:35:39.709355
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    six_moves_transformer_0 = SixMovesTransformer(moved_attribute_0)
    assert six_moves_transformer_0 is not None

# Generated at 2022-06-25 22:35:41.722038
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Assert
    assert isinstance(SixMovesTransformer, object)


# Generated at 2022-06-25 22:35:44.610995
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:35:48.036822
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    transformer_0 = SixMovesTransformer()



# Generated at 2022-06-25 22:35:51.310995
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for class MovedModule
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_module_0 = MovedModule(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:35:56.271468
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer(test_case_0, (1, 0))
    assert re.search(r'^RewriteImport\(six.moves\)\(name=test_case_0, version=\(1, 0\)\)$', repr(six_moves_transformer_0))



# Generated at 2022-06-25 22:36:07.195058
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    object_0 = object()
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)

# Generated at 2022-06-25 22:36:10.258384
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    str_0 = 'moved_attribute_0'
    str_1 = 'moved_attribute_0'
    bool_1 =  isinstance(moved_attribute_0, MovedAttribute)
    assert bool_1
    assert str_0 is str_1
    assert id(str_0) == id(str_1)    


# Generated at 2022-06-25 22:36:19.665133
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert moved_attribute_0.name == list_0
    assert moved_attribute_0.new_mod == bool_0
    assert getattr(moved_attribute_0, 'new_attr', None) == complex_0
    assert getattr(moved_attribute_0, 'old_mod', None) == list_0
    assert getattr(moved_attribute_0, 'old_attr', None) == bool_0
    moved_attribute_1 = MovedAttribute(list_0, bool_0)
    assert moved_attribute_1.name == list_0
    assert moved_attribute_1.new_mod == bool_0

# Generated at 2022-06-25 22:36:23.392071
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    string_0 = ''
    string_1 = ''
    string_2 = ''
    string_3 = ''
    moved_attribute_0 = MovedAttribute(string_0, string_1, string_2, string_3)
    string_0 = moved_attribute_0.name
    string_1 = moved_attribute_0.new_mod
    string_2 = moved_attribute_0.new_attr


# Generated at 2022-06-25 22:37:15.925261
# Unit test for constructor of class MovedModule

# Generated at 2022-06-25 22:37:18.296567
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)


# Generated at 2022-06-25 22:37:23.606659
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert(moved_attribute_0.name == list_0)
    assert(moved_attribute_0.new_mod == bool_0)
    assert(moved_attribute_0.new_attr == complex_0)


# Generated at 2022-06-25 22:37:26.232257
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = []
    moved_attribute_0 = MovedModule(list_0)


# Generated at 2022-06-25 22:37:28.618092
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer(None)

    assert six_moves_transformer != None

# Generated at 2022-06-25 22:37:30.808991
# Unit test for constructor of class MovedModule
def test_MovedModule():
    string_0 = ""
    string_1 = ""
    moved_module_0 = MovedModule(string_0, string_1)

# Generated at 2022-06-25 22:37:34.484546
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']


# Generated at 2022-06-25 22:37:38.604640
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '$^&%#$'
    str_1 = '**%$#'
    str_2 = '*^&%$'
    moved_module_0 =  MovedModule(str_2,str_1,str_0)
    assert moved_module_0 is not None


# Generated at 2022-06-25 22:37:40.696294
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)

# Generated at 2022-06-25 22:37:42.210960
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
  instance = SixMovesTransformer()
  assert isinstance(instance,SixMovesTransformer)

# Generated at 2022-06-25 22:39:19.226622
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert moved_attribute_0 is not None


# Generated at 2022-06-25 22:39:23.319766
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for constructor of MovedModule
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_module_0 = MovedModule(list_0, bool_0, complex_0)

# Generated at 2022-06-25 22:39:26.502366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    assert moved_attribute_0.name is list_0



# Generated at 2022-06-25 22:39:29.186901
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves = [
        MovedModule('example', 'fake.module')
    ]

    transformer = SixMovesTransformer(moves)

    assert transformer.rewrites == [('example', 'six.moves.example')]

# Generated at 2022-06-25 22:39:31.439017
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(bool_0, complex_0)
    str_0 = moved_module_0.name
    str_0 = moved_module_0.new


# Generated at 2022-06-25 22:39:34.936956
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
    six_moves_transformer_0 = SixMovesTransformer(moved_attribute_0)

# Generated at 2022-06-25 22:39:35.660661
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute()

# Generated at 2022-06-25 22:39:39.634004
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Setup
    str_0 = 'test'
    str_1 = 'test'
    # Exercise
    moved_module_0 = MovedModule(str_0, str_1)
    # Verify
    assert moved_module_0 is not None


# Generated at 2022-06-25 22:39:42.405017
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = None
    old = None
    new = None
    moved_module_0 = MovedModule(name, old, new)

# Generated at 2022-06-25 22:39:46.146937
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = []
    bool_0 = True
    complex_0 = None
    moved_attribute_0 = MovedAttribute(list_0, bool_0, complex_0)
