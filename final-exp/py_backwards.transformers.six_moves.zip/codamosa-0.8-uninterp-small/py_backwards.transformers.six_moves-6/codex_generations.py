

# Generated at 2022-06-25 22:31:12.549651
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)



# Generated at 2022-06-25 22:31:14.995236
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:24.506310
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    _moved_attributes_0_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    _moved_attributes_0_1 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    _moved_attributes_0_2 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    _moved_attributes_0_3 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    _moved_attributes_0_4 = MovedAttribute("intern", "__builtin__", "sys")

# Generated at 2022-06-25 22:31:35.992474
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    moved_attribute_2 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    moved_attribute_3 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    moved_attribute_4 = MovedAttribute("intern", "__builtin__", "sys")
    moved_attribute_5 = MovedAttribute("map", "itertools", "builtins", "imap", "map")

# Generated at 2022-06-25 22:31:38.958282
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:31:48.552780
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    six_moves_transformer_4 = SixMovesTrans

# Generated at 2022-06-25 22:31:57.114226
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = 'name'
    old_mod_0 = 'old_mod'
    new_mod_0 = 'new_mod'
    old_attr_0 = 'old_attr'
    new_attr_0 = 'new_attr'
    _moved_attribute_0 = MovedAttribute(name_0, old_mod_0, new_mod_0, old_attr_0, new_attr_0)
    _moved_attribute_1 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')


# Generated at 2022-06-25 22:32:01.669214
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('name', 'old', 'new')
    assert moved_module_0.name == 'name'
    assert moved_module_0.old == 'old' and moved_module_0.new == 'new'


# Generated at 2022-06-25 22:32:07.349549
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert moved_attribute.name == 'cStringIO'
    assert moved_attribute.new_mod == 'io'
    assert moved_attribute.new_attr == 'StringIO'



# Generated at 2022-06-25 22:32:11.626245
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 is not None


# Generated at 2022-06-25 22:32:18.871708
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert callable(SixMovesTransformer), 'SixMovesTransformer should be callable'
    assert isinstance(SixMovesTransformer(a_s_t_0), SixMovesTransformer), \
        'SixMovesTransformer should return an instance of itself'

# Generated at 2022-06-25 22:32:23.402925
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test class constructor of SixMovesTransformer
    """
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    assert six_moves_transformer_1 is not None


# Generated at 2022-06-25 22:32:30.113881
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    moved_attribute_2 = MovedAttribute("cStringIO", "cStringIO", "io")
    moved_attribute_3 = MovedAttribute("cStringIO", "cStringIO", "io", new_attr = "cStringIO")


# Generated at 2022-06-25 22:32:32.708855
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')


# Generated at 2022-06-25 22:32:35.543955
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__") == MovedModule("builtins", "__builtin__")


# Generated at 2022-06-25 22:32:42.981251
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb")
   

# Generated at 2022-06-25 22:32:45.268998
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:32:50.024292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:32:58.422866
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("Comprehension", "oldsix", "newsix", "oldattr", "newattr")
    assert moved_attribute.name == "oldattr"
    assert moved_attribute.new_mod == "oldsix"
    assert moved_attribute.name == "newattr"


# Generated at 2022-06-25 22:33:01.942568
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for constructor with valid arguments
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == "name"
    assert moved_module_0.new == "new"


# Generated at 2022-06-25 22:33:14.119437
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"


# Generated at 2022-06-25 22:33:25.255672
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    MovedAttribute_1 = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    MovedAttribute_2 = MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')
    MovedAttribute_3 = MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    MovedAttribute_4 = MovedAttribute('intern', '__builtin__', 'sys')
    MovedAttribute_5 = MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map')

# Generated at 2022-06-25 22:33:28.754701
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six.moves.cStringIO
    assert six.moves.cStringIO.StringIO == six.moves.io.StringIO


# Generated at 2022-06-25 22:33:35.442682
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert (moved_attribute_0.__init__('cStringIO', 'cStringIO', 'io', 'StringIO') == None)
    assert (moved_attribute_0.name == 'cStringIO')
    assert (moved_attribute_0.new_mod == 'io')
    assert (moved_attribute_0.new_attr == 'StringIO')


# Generated at 2022-06-25 22:33:39.637988
# Unit test for constructor of class MovedModule
def test_MovedModule():
    arg01_0 = 'arg01'
    arg02_0 = 'arg02'
    arg03_0 = 'arg03'
    moved_module_0 = MovedModule(arg01_0, arg02_0, arg03_0)


# Generated at 2022-06-25 22:33:40.796702
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

import unittest


# Generated at 2022-06-25 22:33:45.126433
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0)
    assert (isinstance(six_moves_transformer_1, SixMovesTransformer))

import python_minifier.core as module_1


# Generated at 2022-06-25 22:33:46.846305
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = MovedModule("tkinter", "Tkinter")


# Generated at 2022-06-25 22:33:50.993226
# Unit test for constructor of class MovedModule
def test_MovedModule():
    o = MovedModule('builtins', '__builtin__')
    assert(o.name == 'builtins')
    assert(o.new == 'builtins')
    o = MovedModule('builtins', '__builtin__', 'builtins')
    assert(o.name == 'builtins')
    assert(o.new == 'builtins')


# Generated at 2022-06-25 22:33:52.774087
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('a', 'b', 'c')


# Generated at 2022-06-25 22:34:00.005392
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(str_1, moved_attribute_0, str_1)


# Generated at 2022-06-25 22:34:10.571133
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = '\'~k8Nv7VuH_I{|SNun)w'
    bytes_0 = None
    str_1 = 'kB8c_\\lgntu`ABzHV~L:'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    moved_module_0 = MovedModule(dict_0, str_0, bytes_0, int_0)


# Generated at 2022-06-25 22:34:14.632907
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'Bk>sD^p$x|V7S8'
    dict_0 = {}
    dict_1 = {str_0: dict_0}
    moved_module_0 = MovedModule(str_0, **dict_1)
    assert moved_module_0.name == str_0
    assert moved_module_0.new == str_0


# Generated at 2022-06-25 22:34:20.212101
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = ''.join('a' for i in range(10))
    bytes_0 = None
    str_1 = ''.join('б' for i in range(10))
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)

# Generated at 2022-06-25 22:34:32.625426
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    str_0 = '*mJ$\'cF"\tC%/\nfb"^'
    bytes_0 = None
    str_1 = '\n6:3{\\U?vv+mL\x7f.!w'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -586
    moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)


# Generated at 2022-06-25 22:34:44.389557
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    str_0 = '*\x17\x1c\x1f\x1c]\x0c\x15\x14\x1c\x1e*\x1a\x14\x11\x1f\x17\x07\x1e\x1d['
    bytes_0 = None

# Generated at 2022-06-25 22:34:55.714146
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*8]\x0bpv'
    bytes_0 = None
    str_1 = 'C@w'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_2 = 'C@w'
    dict_2 = {}
    bytes_1 = None
    str_3 = 'RL\x1d\x0e\x0b'

# Generated at 2022-06-25 22:35:05.204397
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {'_target': (1, 0)}
    str_0 = '\tR8XVzjC%u|Lh'
    bytes_0 = None
    str_1 = 'C|\t>%'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.target == (1, 0)


# Generated at 2022-06-25 22:35:16.305765
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)
    assert moved_attribute_0.name == dict_0

# Generated at 2022-06-25 22:35:26.410592
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'd|"y1QQq3&%v\x74-'
    dict_0 = {}
    dict_1 = {str_0: dict_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

if __name__ == '__main__':
    import sys
    import typing
    # The line below may look strange... It is to avoid a recursion problem when we are testing this file.
    # When we execute this file, the execution flow reaches line below and imports this file. At this
    # time, the six_moves_transformer module doesn't exist, so it crashes. To fix this, we put this file
    # in a if __name__ == '

# Generated at 2022-06-25 22:35:45.055488
# Unit test for constructor of class MovedModule
def test_MovedModule():
  dict_0 = {}
  str_0 = 'n=,C5c%Y5}]2H;^3wW{'
  bytes_0 = None
  str_1 = 'K_Zi}rZR~(:|p%f<!Kg'
  dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
  moves_module_0 = MovedModule(dict_0, bytes_0, dict_1)


# Generated at 2022-06-25 22:35:55.110049
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  dict_0 = {}
  str_0 = '-*]g;u11&`<\rZH'
  bytes_0 = None
  str_1 = 'yF78^x8#<cB9'
  a_s_t_0 = module_0.AST(**{str_0: dict_0, str_1: dict_0, str_0: str_0, str_0: bytes_0})
  six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
  int_0 = -749
  moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)
  module_0.AST()
  str_0 = 'uV7Z(1_Zu#h*'
  bytes_

# Generated at 2022-06-25 22:36:04.623123
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import typed_ast._ast3 as module_0
    dict_0 = {}
    str_0 = '*$QYt7Gl]5-e/y8/4h'
    bytes_0 = None
    str_1 = 'm\t}@BU)l0IGQ\t8j-W'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 is not None


# Generated at 2022-06-25 22:36:13.526169
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = 'o>M,a_z38\n1jy(1t'
    bytes_0 = None
    bytes_1 = None
    dict_1 = {str_0: bytes_0, str_0: bytes_0, str_0: bytes_1, str_0: bytes_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_module_0 = MovedModule(dict_0, bytes_0, bytes_0)


# Generated at 2022-06-25 22:36:19.741843
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = 'Z~q3o}F$^g|`"\t$'
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: str_0, str_1: dict_0, str_0: dict_0}
    moved_module_0 = MovedModule(dict_0, str_0, **dict_1)


# Generated at 2022-06-25 22:36:20.892400
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case_0()


# Generated at 2022-06-25 22:36:30.173692
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '6!9&!7@|}'
    bytes_0 = None
    str_1 = '\t\n_2V,v~8?[z\x0bKsF'
    str_2 = 'tZEH?<;fj)%I'
    str_3 = '-PQo<{vN.A\t'
    str_4 = '\n\tqW^y8\n)A%O]T1'
    str_5 = 'g?D=Cz\x16sH'
    str_6 = '*ai?^vlH'
    str_7 = '{!hx_e'
    str_8 = '\x13|>;b'

# Generated at 2022-06-25 22:36:40.389355
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.ast == a_s_t_0 and six_moves_transformer_0.moves == _get_rewrites() and six_moves_transformer_

# Generated at 2022-06-25 22:36:44.017261
# Unit test for constructor of class MovedModule
def test_MovedModule():
  m = MovedModule('new', 'old', 'new')
  assert m.name == 'new'
  assert m.old == 'old'
  assert m.new == 'new'


# Generated at 2022-06-25 22:36:53.325843
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    module_0 = module_0  # type: typing.Any
    module_1 = module_1  # type: typing.Any
    module_2 = module_2  # type: typing.Any
    module_3 = module_3  # type: typing.Any
    module_4 = module_4  # type: typing.Any
    module_5 = module_5  # type: typing.Any
    module_6 = module_6  # type: typing.Any
    module_7 = module_7  # type: typing.Any
    module_8 = module_8  # type: typing.Any
    module_9 = module_9  # type: typing.Any
    module_10 = module_10  # type: typing.Any
    module_11 = module_11  # type: typing.Any
    module_12 = module_

# Generated at 2022-06-25 22:37:22.822038
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:28.899369
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = '7/u0~qau"(aiV+_|['
    str_1 = 'hDn'
    int_0 = -49
    moved_module_0 = MovedModule(dict_0, str_0, str_1, int_0)
    assert moved_module_0 != ()


# Generated at 2022-06-25 22:37:37.624144
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:44.323928
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  dict_0 = {}
  str_0 = '*,V5/C*ef5?"Zm\t-Aok'
  bytes_0 = None
  str_1 = '\tvwpJ?7N@+l6{|%XdF'
  dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
  a_s_t_0 = module_0.AST(**dict_1)
  six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
  int_0 = -749
  moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)


# Generated at 2022-06-25 22:37:52.865663
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = '\x7F'
    str_1 = '(x<{tr'
    dict_1 = {str_0: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_0, int_0)
    moved_module_0 = MovedModule(str_0, str_0, str_1)


# Generated at 2022-06-25 22:37:59.776812
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '~k]Q(z\nM|> S'
    bytes_0 = None
    str_1 = 'g/C%c}\x0b\x7fT\x03'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:38:07.171477
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    assert SixMovesTransformer(a_s_t_0) is not None


# Generated at 2022-06-25 22:38:13.734576
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:38:20.821474
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:38:23.464689
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'buxz9/qn&rY'
    str_1 = ''
    moved_module_0 = MovedModule(str_0, str_1)

# Generated at 2022-06-25 22:39:22.208355
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    str_0 = '\xa0\xc5z\x9b\x9e\xaaz\xdb~\xb4+\xc4\xab\xad'
    bytes_0 = None
    str_1 = '\x84\xa1\x8a\xad\xed\x0b\xf7\x8e\x1d\x1a\x2a\x8f\xdc\xed\xb0\x86\xb8\x9a\x19\xa2'
    moved_attribute_0 = MovedAttribute(str_1, str_1, str_1, bytes_0)

# Generated at 2022-06-25 22:39:29.916849
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'mvQmG0fL'
    str_1 = 'eV2aW'
    str_2 = ']~;Mv'
    bytes_0 = None
    moved_module_0 = MovedModule(str_0, str_1, str_2)
    int_0 = -936
    moved_module_0 = MovedModule(str_0, str_1, bytes_0)
    bytes_1 = None
    moved_module_0 = MovedModule(str_0, str_1, bytes_1)
    moved_module_0 = MovedModule(str_0, str_1)


# Generated at 2022-06-25 22:39:30.679401
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:39:41.260877
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    try:
        moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)
    except Exception:
        pass
   

# Generated at 2022-06-25 22:39:46.397536
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '\t/~,"i8Er$:%\x0cZ1,hs'
    str_1 = '\x03,m\n(|zQ8hKM]iMYm'
    moved_module_0 = MovedModule(str_0, str_1, str_0)


# Generated at 2022-06-25 22:39:54.396075
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = '*{5nm5y2@5z~f?;(}'
    bytes_0 = None
    str_1 = 'suX9y0k-YGv\t=\x0cA'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    moved_module_0 = MovedModule(int_0, dict_0, dict_0)

# Generated at 2022-06-25 22:40:02.005516
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = 'pLUj y(t=\x0e(]j)w'
    bytes_0 = None
    a_s_t_0 = module_0.AST(**{str_0: dict_0, str_0: bytes_0, str_0: str_0})
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(**{str_0: a_s_t_0})
    six_moves_transformer_1 = SixMovesTransformer(**{str_0: a_s_t_0, str_0: a_s_t_0, str_0: a_s_t_0})


# Generated at 2022-06-25 22:40:13.913218
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '6Rb<1Q2!yk[WC%]\n*_'
    bytes_0 = None
    str_1 = '\tdV!3yT\x1d7>B}wC@'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)


# Generated at 2022-06-25 22:40:21.122249
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = 'L6+S\nz[XU>>@F|]2?M'
    bytes_0 = None
    str_1 = '+:/{z\'v)XE_W8:+n'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_module_0 = MovedModule(str_1, str_0, str_0)
    assert moved_module_0.name is not None


# Generated at 2022-06-25 22:40:29.647484
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    str_0 = '*,V5/C*ef5?"Zm\t-Aok'
    bytes_0 = None
    str_1 = '\tvwpJ?7N@+l6{|%XdF'
    dict_1 = {str_0: dict_0, str_0: bytes_0, str_1: dict_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    int_0 = -749
    moved_attribute_0 = MovedAttribute(dict_0, str_0, bytes_0, int_0)

test_SixMovesTransformer()