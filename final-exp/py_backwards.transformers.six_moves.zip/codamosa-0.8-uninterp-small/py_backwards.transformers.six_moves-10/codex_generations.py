

# Generated at 2022-06-25 22:31:11.438302
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    print(moved_attribute_0.name)
    print(moved_attribute_0.new_mod)
    print(moved_attribute_0.new_attr)


# Generated at 2022-06-25 22:31:13.660795
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:31:17.001771
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    assert SixMovesTransformer(a_s_t_0) is not None

if __name__ == '__main__':
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-25 22:31:20.377545
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sixMovesTransformer = SixMovesTransformer()
    if sixMovesTransformer is None:
        raise RuntimeError
    if not isinstance(sixMovesTransformer, SixMovesTransformer):
        raise RuntimeError


# Generated at 2022-06-25 22:31:26.486043
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('name', 'old')
    assert moved_module_0.name == 'name'
    assert moved_module_0.new == 'name'
    moved_module_1 = MovedModule('name', 'old', 'new')
    assert moved_module_1.name == 'name'
    assert moved_module_1.new == 'new'


# Generated at 2022-06-25 22:31:30.556828
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('abcd', 'abcd', 'abcd')
    assert moved_module_0.name == 'abcd'
    assert moved_module_0.old == 'abcd'
    assert moved_module_0.new == 'abcd'

# Generated at 2022-06-25 22:31:41.673216
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") is not None
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter") is not None
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse") is not None
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input") is not None
    assert MovedAttribute("intern", "__builtin__", "sys") is not None
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map") is not None
    assert MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd") is not None
   

# Generated at 2022-06-25 22:31:43.798108
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert moved_attribute_0.new_mod == "io" and moved_attribute_0.new_attr == "StringIO"
    
# End of unit test for constructor of class MovedAttribute



# Generated at 2022-06-25 22:31:46.194375
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:48.059754
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:51.090842
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("builtins", "__builtin__")



# Generated at 2022-06-25 22:32:00.421034
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst._six import PY36
    from libcst import ParseError
    from libcst import parse_module
    from libcst.codemod import CodemodContext
    f = open("modules/python-codemod/tests/six_moves/test_case_0.py", 'r')
    mod = parse_module(f.read())
    c = CodemodContext(mod)
    f.close()
    six_moves_transformer_0 = SixMovesTransformer()
    assert(six_moves_transformer_0.target == (2, 7))
    assert(six_moves_transformer_0.target[0] == 2)
    assert(six_moves_transformer_0.target[1] == 7)

# Generated at 2022-06-25 22:32:03.822239
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()


# Generated at 2022-06-25 22:32:11.470610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute_0.name == 'name'
    assert moved_attribute_0.old_mod == 'old_mod'
    assert moved_attribute_0.new_mod == 'new_mod'
    assert moved_attribute_0.old_attr == 'old_attr'
    assert moved_attribute_0.new_attr == 'new_attr'


# Generated at 2022-06-25 22:32:16.318577
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule_0 = MovedModule("name", "old", "new")
    assert movedmodule_0.name == "name"
    assert movedmodule_0.old == "old"
    assert movedmodule_0.new == "new"


# Generated at 2022-06-25 22:32:26.606514
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", )
    moved_attribute_2 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", )
    assert moved_attribute_2.name == "cStringIO"
    assert moved_attribute_2.new_mod == "io"
    assert moved_attribute_2.new_attr == "StringIO"
    assert moved_attribute_2.__eq__(moved_attribute_1)
    assert moved_attribute_2.__ne__(moved_attribute_2)
    assert moved_attribute_2.__hash__() == hash("cStringIO")


# Generated at 2022-06-25 22:32:32.662713
# Unit test for constructor of class MovedModule
def test_MovedModule():
    instance1 = MovedModule(name="name", old="old", new="new")
    assert instance1.name == "name"
    assert instance1.new == "new"


# Generated at 2022-06-25 22:32:41.898530
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert moved_attribute_0.name == 'name'
    assert moved_attribute_0.old_mod == 'old_mod'
    assert moved_attribute_0.new_mod == 'new_mod'
    assert moved_attribute_0.old_attr == 'old_attr'
    assert moved_attribute_0.new_attr == 'old_attr'
    moved_attribute_1 = MovedAttribute('name', 'old_mod', 'new_mod')
    assert moved_attribute_1.name == 'name'
    assert moved_attribute_1.old_mod == 'old_mod'
    assert moved_attribute_1.new_mod == 'new_mod'
    assert moved_attribute_1.old_

# Generated at 2022-06-25 22:32:43.475466
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(str(), str(), str())


# Generated at 2022-06-25 22:32:47.270993
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.fixes.fix_six_moves import SixMovesTransformer
    from libfuturize.fixes.fix_six_moves import SixMovesTransformer
    six_moves_transformer = SixMovesTransformer()


# Generated at 2022-06-25 22:32:54.226074
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"


# Generated at 2022-06-25 22:32:55.887961
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, object)


# Generated at 2022-06-25 22:32:59.846965
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("dummy", "dummy")
    assert moved_module_0.name == "dummy"
    assert moved_module_0.new == "dummy"


# Generated at 2022-06-25 22:33:07.110151
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    six_moves_transformer = SixMovesTransformer()

    name = 'moved_attribute'
    old_mod = 'old_module'
    new_mod = 'new_module'
    old_attr = 'old_attribute'
    new_attr = 'new_attribute'

    moved_attribute = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)

    assert moved_attribute.name == name
    assert moved_attribute.new_mod == new_mod
    assert moved_attribute.new_attr == new_attr


# Generated at 2022-06-25 22:33:15.812028
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # noinspection PyMethodMayBeStatic
    class TestSixMovesTransformer(unittest.TestCase):
        def test_constructor(self):
            six_moves_transformer = SixMovesTransformer()
            self.assertIsInstance(six_moves_transformer, SixMovesTransformer)
            self.assertFalse(six_moves_transformer.is_activated)

    unittest.main()

if __name__ == '__main__':
    test_case_0()
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:33:18.396871
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    result = str(SixMovesTransformer().target)
    assert result == "(2, 7)", "Expected (2, 7), but got {}".format(result)


# Generated at 2022-06-25 22:33:21.971240
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod')
    assert moved_attribute_0.name == 'name' and moved_attribute_0.new_mod == 'new_mod'


# Generated at 2022-06-25 22:33:26.420173
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # setup
    import six
    from ..transformers.six_moves_transformer import SixMovesTransformer
    six_moves_transformer = SixMovesTransformer()
    # assert
    assert isinstance(six_moves_transformer, SixMovesTransformer)


# Generated at 2022-06-25 22:33:30.810801
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new, old = ('_winreg', 'winreg')
    _moved_module = MovedModule(new, old)
    _moved_module.name = old
    _moved_module.new = new

# Generated at 2022-06-25 22:33:34.933590
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MA_obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert MA_obj.name == "cStringIO"
    assert MA_obj.new_mod == "io"
    assert MA_obj.new_attr == "StringIO"


# Generated at 2022-06-25 22:33:42.089167
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()



# Generated at 2022-06-25 22:33:46.388873
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert six_moves_transformer_0 is not None
    # if five_six_transformer.rewrites.__len__() != 0:
    #     import six
    #     assert six_moves_transformer_0.rewrites.__len__() == 0

# Generated at 2022-06-25 22:33:47.721690
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    six_moves_transformer_1 = SixMovesTransformer()


# Generated at 2022-06-25 22:33:49.001638
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedAttribute0 = MovedAttribute('', '', '')


# Generated at 2022-06-25 22:33:52.462030
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.new == 'new'


# Generated at 2022-06-25 22:33:57.590903
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("urllib_robotparser", "robotparser", "urllib.robotparser").name == "urllib_robotparser"
    assert MovedModule("urllib_robotparser", "robotparser", "urllib.robotparser").new == "urllib.robotparser"



# Generated at 2022-06-25 22:34:02.558462
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    expect = "\n".join((
        "<class 'MovedAttribute'>",
        "| name: str",
        "| old_mod: str",
        "| new_mod: str",
        "| old_attr: str",
        "| new_attr: str",
    ))
    actual = repr(MovedAttribute)
    assert expect == actual


# Generated at 2022-06-25 22:34:08.918287
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'


# Generated at 2022-06-25 22:34:10.810535
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    testMove = MovedAttribute("stringName", "stringOld", "stringNew")
    assert testMove.name == "stringName"
    assert testMove.old_mod == "stringOld"
    assert testMove.new_mod == "stringNew"


# Generated at 2022-06-25 22:34:12.733295
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old")
    assert MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:34:26.685146
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        six_moves_transformer_0 = SixMovesTransformer()
        assert True
    except:
        assert False


# Generated at 2022-06-25 22:34:31.439400
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name = "robotparser", old = "robotparser", new = "urllib.robotparser")


# Generated at 2022-06-25 22:34:36.362381
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'new'

    obj = MovedModule('name', 'old')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'name'


# Generated at 2022-06-25 22:34:39.974860
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert(six_moves_transformer_0 is not None)


# Generated at 2022-06-25 22:34:43.118576
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:34:46.707862
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test of SixMovesTransformer()"""
    print('Test of SixMovesTransformer()')
    print('\tInitializing...')
    six_moves_transformer_0 = SixMovesTransformer()
    print('\tDone.')


# Generated at 2022-06-25 22:34:50.518290
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule("test", "aaa", "bbb")
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 22:34:55.881255
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mv_0 = MovedModule('configparser', 'ConfigParser')
    assert mv_0.name == 'configparser'
    assert mv_0.new == 'configparser'
    mv_1 = MovedModule('BaseHTTPServer', 'BaseHTTPServer', 'http.server')
    assert mv_1.name == 'BaseHTTPServer'
    assert mv_1.new == 'http.server'


# Generated at 2022-06-25 22:35:00.822400
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test if the class can be created without any error
    try:
        six_moves_transformer_0 = SixMovesTransformer()
    # Assertion error will be raised if the class cannot be created
    except AssertionError:
        raise AssertionError("Cannot create instance of class SixMovesTransformer")

# Generated at 2022-06-25 22:35:02.300790
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()


# Generated at 2022-06-25 22:35:28.141458
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:35:29.669563
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:35:33.263380
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert_equal(moved_module.name, 'name')
    assert_equal(moved_module.old, 'old')
    assert_equal(moved_module.new, 'new')

# Generated at 2022-06-25 22:35:38.823300
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod',
                                       'old_attr=None', 'new_attr=None')
    assert moved_attribute_0.new == 'name'
    assert moved_attribute_0.new_mod == 'name'
    assert moved_attribute_0.new_attr == 'name'


# Generated at 2022-06-25 22:35:39.520942
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert True



# Generated at 2022-06-25 22:35:40.225035
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert True

# Generated at 2022-06-25 22:35:48.097969
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert isinstance(moved_module, MovedModule)
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"
    moved_module_1 = MovedModule("name", "old")
    assert isinstance(moved_module_1, MovedModule)
    assert moved_module_1.name == "name"
    assert moved_module_1.old == "old"
    assert moved_module_1.new == "name"



# Generated at 2022-06-25 22:35:56.836774
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == \
        "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_mod == \
        "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == \
        "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old_attr == \
        "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == \
        "cStringIO"


# Generated at 2022-06-25 22:36:01.237663
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.dependencies == ['six']

# Generated at 2022-06-25 22:36:03.963298
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert not (SixMovesTransformer().rewrites is SixMovesTransformer.rewrites)
    assert not (SixMovesTransformer().rewrites is _get_rewrites())


# Generated at 2022-06-25 22:36:34.219374
# Unit test for constructor of class MovedModule
def test_MovedModule():
    float_0 = -426.0
    tuple_0 = ()
    str_0 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    str_1 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(float_0, str_1)
    assert (moved_module_0.name == float_0)
    assert (moved_module_0.new == str_1)


# Generated at 2022-06-25 22:36:45.505657
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_attribute_0 = MovedAttribute('TPtk', None, None, None)
    moved_module_0 = MovedModule('BaseHTTPServer', moved_attribute_0)
    moved_module_1 = MovedModule('Tkinter', moved_module_0)
    moved_module_2 = MovedModule('Tkconstants', moved_module_0)
    moved_module_4 = MovedModule('Tkdnd', moved_module_0)
    moved_module_3 = MovedModule('Tkinter', moved_module_4)
    moved_module_6 = MovedModule('Tkinter', moved_module_4)
    moved_module_5 = MovedModule('Tkinter', moved_module_6)
    moved_module_7 = MovedModule('Tkinter', moved_module_5)

# Generated at 2022-06-25 22:36:54.357918
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_attribute_0 = MovedAttribute('', None, None)
    moved_attribute_1 = MovedAttribute('', None, None, '')
    moved_attribute_2 = MovedAttribute('', None, None, '', '')
    moved_attribute_3 = MovedAttribute('', None, '')
    moved_attribute_4 = MovedAttribute('', None, '', '', '')
    moved_module_0 = MovedModule(0.0, 'SimpleHTTPServer')
    moved_module_1 = MovedModule('', moved_attribute_0)
    moved_module_2 = MovedModule(0.0, moved_attribute_0)

    instance_0 = SixMovesTransformer()
    assert instance_0 is not None

# unit = None

# Generated at 2022-06-25 22:36:58.865214
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'SimpleHTTPServer'
    tuple_0 = ()
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)


# Generated at 2022-06-25 22:37:08.572562
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Assign arguments
    name = ': '
    old_mod = 'CGIHTTPServer'
    new_mod = 'SimpleHTTPServer'
    old_attr = ()
    new_attr = ': '

    # Act
    moved_attribute_0 = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)

    # Assert
    moved_attribute_0.name = ': '
    moved_attribute_0.old_mod = 'CGIHTTPServer'
    moved_attribute_0.new_mod = 'SimpleHTTPServer'
    moved_attribute_0.old_attr = ()
    moved_attribute_0.new_attr = ': '



# Generated at 2022-06-25 22:37:17.685606
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Verify that MovedAttribute(name, old_mod, new_mod, old_attr=None, new_attr=None)
    # creates and returns an object
    float_0 = -426.0
    tuple_0 = ()
    str_0 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    # Verify member variables name, new_mod, and new_attr
    assert moved_attribute_0.name == str_0
    assert moved_attribute_0.new_mod == a_s_t_0
    assert moved_attribute_0.new_attr == a_s_t_0
    assert moved_attribute_0.old_attr == tuple_0
   

# Generated at 2022-06-25 22:37:27.499480
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_0 = -426.0
    tuple_0 = ()
    str_0 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    str_1 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(float_0, str_1)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    float_1 = 1414.0
    dict_0 = {}
    moved_attribute_1 = MovedAttribute(float_0, float_1, dict_0)

# Generated at 2022-06-25 22:37:38.103091
# Unit test for constructor of class MovedModule
def test_MovedModule():
    float_2 = -426.0
    tuple_1 = ()
    str_2 = ': '
    a_s_t_1 = None
    moved_attribute_2 = MovedAttribute(str_2, a_s_t_1, a_s_t_1, tuple_1)
    str_3 = 'SimpleHTTPServer'
    moved_module_2 = MovedModule(float_2, str_3)
    name = moved_module_2.name
    assert(name == float_2)
    str_4 = ': '
    a_s_t_2 = None
    moved_attribute_3 = MovedAttribute(str_4, a_s_t_2, a_s_t_2, tuple_1)
    assert(moved_module_2.old == str_3)


# Generated at 2022-06-25 22:37:40.609891
# Unit test for constructor of class MovedModule
def test_MovedModule():
    float_0 = 1414.0
    util_0 = MovedModule(None, float_0)
    util_1 = MovedModule(None, None)

    # Test for equality of util_0 and util_1
    assert util_0 == util_1


# Generated at 2022-06-25 22:37:49.876305
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_2 = -426.0
    tuple_1 = ()
    str_2 = ': '
    a_s_t_1 = None
    moved_attribute_2 = MovedAttribute(str_2, a_s_t_1, a_s_t_1, tuple_1)
    str_3 = 'SimpleHTTPServer'
    moved_module_2 = MovedModule(float_2, str_3)
    moved_module_3 = MovedModule(tuple_1, moved_attribute_2)
    float_3 = 1414.0
    dict_1 = {}
    moved_attribute_3 = MovedAttribute(float_2, float_3, dict_1)
    str_4 = 'SimpleHTTPServer'
    str_5 = '__builtin__'
    moved_attribute_4

# Generated at 2022-06-25 22:38:46.391232
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = ': '
    a_s_t_0 = None
    tuple_0 = ()
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)


# Generated at 2022-06-25 22:38:54.844804
# Unit test for constructor of class MovedModule
def test_MovedModule():
    float_0 = -426.0
    tuple_0 = ()
    str_0 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    str_1 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(float_0, str_1)
    assert (moved_module_0.name == float_0)
    assert (moved_module_0.new == str_1)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    assert (moved_module_1.name == tuple_0)
    assert (moved_module_1.new == moved_attribute_0)



# Generated at 2022-06-25 22:39:01.508580
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_0 = -426.0
    str_0 = ': '
    tuple_0 = ()
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    str_1 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(float_0, str_1)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    float_1 = 1414.0
    dict_0 = {}
    moved_attribute_1 = MovedAttribute(float_0, float_1, dict_0)

# Generated at 2022-06-25 22:39:11.896920
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_0 = -426.0
    tuple_0 = ()
    str_0 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    str_1 = 'SimpleHTTPServer'
    moved_attribute_1 = MovedAttribute(str_1, a_s_t_0, a_s_t_0, tuple_0)
    moved_attribute_2 = MovedAttribute('reload_module', '__builtin__', 'importlib', 'reload')
    moved_attribute_3 = MovedAttribute('reload_module', '__builtin__', 'imp', 'reload')
    float_0 = -426.0
    float_1 = 1414

# Generated at 2022-06-25 22:39:15.109028
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(' ')
    moved_module_1 = MovedModule()
    assert moved_module_0.name != " "
    assert moved_module_1.name != ""


# Generated at 2022-06-25 22:39:22.669306
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(str_0)
    moved_module_1 = MovedModule(str_0, str_0)
    str_1 = 'Cookie'
    moved_module_2 = MovedModule(str_0, moved_module_1)
    str_2 = 'MIMEText'
    moved_module_3 = MovedModule(str_0, str_2)


# Generated at 2022-06-25 22:39:31.118675
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    float_0 = -426.0
    tuple_0 = ()
    str_0 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    str_1 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(float_0, str_1)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)
    float_1 = 1414.0
    dict_0 = {}
    moved_attribute_1 = MovedAttribute(float_0, float_1, dict_0)
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:39:35.513949
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'SimpleHTTPServer'
    tuple_0 = ()
    moved_attribute_0 = MovedAttribute(str_0, tuple_0)
    assert moved_attribute_0.name == str_0
    assert moved_attribute_0.new_attr is None
    assert moved_attribute_0.new_mod is None


# Generated at 2022-06-25 22:39:46.898366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(str_0, str_0)
    str_1 = ': '
    a_s_t_0 = None
    moved_attribute_0 = MovedAttribute(str_1, a_s_t_0, a_s_t_0, str_0)
    assert moved_attribute_0.name == str_1
    assert moved_attribute_0.new_attr == str_0
    assert moved_attribute_0.new_mod == a_s_t_0
    str_2 = 'SimpleHTT'
    str_3 = 'CGIHTTPServer'
    a_s_t_1 = None

# Generated at 2022-06-25 22:39:54.763202
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = ': '
    a_s_t_0 = None
    tuple_0 = ()
    dict_0 = {}
    float_0 = 1414.0
    float_1 = -426.0
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, a_s_t_0, tuple_0)
    moved_attribute_1 = MovedAttribute(float_0, float_1, dict_0)
    str_1 = 'SimpleHTTPServer'
    moved_module_0 = MovedModule(float_0, str_1)
    moved_module_1 = MovedModule(tuple_0, moved_attribute_0)

    # test if constructor is defined
    transformer = SixMovesTransformer()