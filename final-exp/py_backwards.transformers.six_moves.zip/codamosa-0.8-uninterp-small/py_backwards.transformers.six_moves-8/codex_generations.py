

# Generated at 2022-06-25 22:31:14.193392
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('builtins', '__builtin__')


# Generated at 2022-06-25 22:31:16.686250
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module_ast_0 = module_0.AST()
    six_moves_transformer_obj_0 = SixMovesTransformer(module_ast_0)

# Generated at 2022-06-25 22:31:22.435064
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name_0', 'old_mod_0', 'new_mod_0', 'old_attr_0', 'new_attr_0')
    assert moved_attribute_0.name == 'name_0'
    assert moved_attribute_0.new_mod == 'new_mod_0'
    assert moved_attribute_0.new_attr == 'new_attr_0'


# Generated at 2022-06-25 22:31:24.760480
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('__main__.builtins', '__main__.builtins', '__main__.builtins')


# Generated at 2022-06-25 22:31:27.014065
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        moved_attribute_0 = MovedAttribute('name', 'old_mod', None)
    except TypeError:
        pass


# Generated at 2022-06-25 22:31:38.450304
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_c_string_IO_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute_c_string_IO_0.name == "cStringIO"
    moved_attribute_filter_0 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert moved_attribute_filter_0.new_attr == "filter"
    moved_attribute_input_0 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert moved_attribute_input_0.new_mod == "builtins"
    moved_attribute_getcwd_0 = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-25 22:31:41.002529
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:49.501931
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        with pytest.raises(TypeError):
            obj = MovedAttribute()
        with pytest.raises(TypeError):
            obj = MovedAttribute(1)
        with pytest.raises(TypeError):
            obj = MovedAttribute(1, 2)
        with pytest.raises(TypeError):
            obj = MovedAttribute(1, 2, 3, 4, 5, 6)
        obj = MovedAttribute(1, 2, 3, 4, 5)
        assert obj.name == 1
        assert obj.new_mod == 2
        assert obj.new_attr == 4
    except Exception as err:
        pytest.fail('MovedAttribute() raised an exception:', err)


# Generated at 2022-06-25 22:31:51.357547
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_moved_module_0 = MovedModule("", "", "")


# Generated at 2022-06-25 22:31:57.681733
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_moved_module_0 = MovedModule('a_name', a_old='a_old', a_new='a_new')
    assert a_moved_module_0.name == 'a_name'
    assert a_moved_module_0.old == 'a_old'
    assert a_moved_module_0.new == 'a_new'


# Generated at 2022-06-25 22:32:02.874919
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

import unittest

# Generated at 2022-06-25 22:32:07.910475
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        SixMovesTransformer(None)
    except Exception as inst:
        if 'Constructor requires' in str(inst):
            pass
    except RuntimeError as inst:
        if 'Constructor requires' in str(inst):
            pass
    except TypeError as inst:
        if 'Constructor requires' in str(inst):
            pass

# Generated at 2022-06-25 22:32:14.072829
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    if not hasattr(SixMovesTransformer, "__init__"):
        pytest.skip("Class SixMovesTransformer has no constructor")

    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

    assert six_moves_transformer_0  is not None


# Generated at 2022-06-25 22:32:16.213105
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('name', 'old', 'new')


# Generated at 2022-06-25 22:32:21.709963
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    assert six_moves_transformer_0.rewrites == _get_rewrites()


# Generated at 2022-06-25 22:32:31.688795
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('name', 'old_mod', 'new_mod')
    assert moved_attribute_0.name == 'name'
    # test that new_mod is set when it is not provided
    assert moved_attribute_0.new_mod == 'name'
    # test that new_attr is set when it is not provided
    assert moved_attribute_0.new_attr == 'name'
    moved_attribute_1 = MovedAttribute('attrName', 'moduleName', 'moduleName', 'old_attr', 'new_attr')
    assert moved_attribute_1.name == 'attrName'
    assert moved_attribute_1.new_mod == 'moduleName'
    assert moved_attribute_1.new_attr == 'old_attr'
    # Test that new_attr is assigned when old_attr is not provided

# Generated at 2022-06-25 22:32:38.947580
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    _arg_name_0 = ("")
    _arg_old_mod_0 = ("")
    _arg_new_mod_0 = ("")
    _arg_old_attr_0 = ("")
    _arg_new_attr_0 = ("")

    obj_0 = MovedAttribute(_arg_name_0, _arg_old_mod_0, _arg_new_mod_0, _arg_old_attr_0, _arg_new_attr_0)


# Generated at 2022-06-25 22:32:42.732413
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case_MovedModule_attributes_0 = MovedModule(name='builtins', old='__builtin__')
    assert getattr(test_case_MovedModule_attributes_0, 'new') == 'builtins'
    assert getattr(test_case_MovedModule_attributes_0, 'old') == '__builtin__'
    assert getattr(test_case_MovedModule_attributes_0, 'name') == 'builtins'


# Generated at 2022-06-25 22:32:43.874103
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:32:52.851210
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()

    # Check the constructor
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0
    # Check if the rewrites are available
    assert six_moves_transformer_0.rewrites

    # Check if the dependencies are available
    assert six_moves_transformer_0.dependencies

    assert six_moves_transformer_0.target == (2, 7)
    assert six_moves_transformer_0.ast == a_s_t_0


# Generated at 2022-06-25 22:33:05.913264
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        moved_attribute_0 = MovedAttribute('', '', '')
        print("MovedAttribute constructor test 1 passed.")
    except Exception as e:
        print("MovedAttribute constructor test 1 failed.")
    try:
        moved_attribute_0 = MovedAttribute('', '', '', '', '')
        print("MovedAttribute constructor test 2 passed.")
    except Exception as e:
        print("MovedAttribute constructor test 2 failed.")
    try:
        moved_attribute_0 = MovedAttribute('', '', '', '', '', )
        print("MovedAttribute constructor test 3 failed.")
    except Exception as e:
        print("MovedAttribute constructor test 3 passed.")


# Generated at 2022-06-25 22:33:08.752268
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:33:11.657974
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test 1
    MovedAttribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") 
    assert MovedAttribute_0.name == "cStringIO"
    assert MovedAttribute_0.new_mod == "io"
    assert MovedAttribute_0.new_attr == "StringIO"


# Generated at 2022-06-25 22:33:16.425500
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for constructor
    # Call: MoveAttribute(name, old_mod, new_mod, old_attr, new_attr)
    # Case-0: call without arguments
    try:
        moved_attribute_0 = MovedAttribute()
        assert False
    except TypeError as e:
        #  TypeError: __init__() takes at least 1 argument (0 given)
        assert e.args[0] == "__init__() takes at least 1 argument (0 given)"
    # Case-1: call with 5 arguments
    try:
        moved_attribute_1 = MovedAttribute("x", "y", "z", "a", "b")
    except Exception:
        assert False
    # Case-2: call with 4 arguments

# Generated at 2022-06-25 22:33:23.391612
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert issubclass(type(six_moves_transformer_0), SixMovesTransformer)
    try:
        six_moves_transformer_1 = SixMovesTransformer.__new__(SixMovesTransformer)
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 22:33:27.343637
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule_0 = MovedModule('name', 'old', 'new')
    assert MovedModule_0.name is 'name'
    assert MovedModule_0.old is 'old'
    assert MovedModule_0.new is 'new'


# Generated at 2022-06-25 22:33:30.482768
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule_instance_0 = MovedModule(name = "builtins", old = "__builtin__")


# Generated at 2022-06-25 22:33:34.967271
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    print(six_moves_transformer_0.__class__.__name__)

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:33:37.711312
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:33:40.253380
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('builtins', '__builtin__')
    assert moved_module_0.name == 'builtins'


# Generated at 2022-06-25 22:33:48.368125
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:33:54.989186
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__", "builtins").name == "builtins"
    assert MovedModule("builtins", "__builtin__", "builtins").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").name

# Generated at 2022-06-25 22:33:57.206260
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a_moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:34:08.262780
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "name"
    old_mod = "mod"
    new_mod = "new_mod"
    old_attr = "old_attr"
    new_attr = "new_attr"
    move = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    # Verifying that variable name is equal to its initial value
    if (str(move.name) != str("name")):
        raise AssertionError("Wrong value for attribute name: " + str(move.name))
    # Verifying that variable new_mod is equal to its initial value
    if (str(move.new_mod) != str("new_mod")):
        raise AssertionError("Wrong value for attribute new_mod: " + str(move.new_mod))
    # Verifying that variable new_

# Generated at 2022-06-25 22:34:10.842288
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:34:12.336214
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Successful creation
    moved_attribute_0 = MovedAttribute("configparser", "ConfigParser")


# Generated at 2022-06-25 22:34:14.836957
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # class constructor
    moved_module_0 = MovedModule('test_mmm', 'test_m')
    assert moved_module_0.name == 'test_mmm'
    assert moved_module_0.new == 'test_m'


# Generated at 2022-06-25 22:34:15.623473
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass


# Generated at 2022-06-25 22:34:18.670075
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule_0 = MovedModule("six", "six")
    assert(movedmodule_0.new == "six")


# Generated at 2022-06-25 22:34:21.220370
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(name='', old_mod='', new_mod=None, old_attr=None, new_attr=None)


# Generated at 2022-06-25 22:34:36.573419
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_module_0 = MovedModule(moved_attribute_0, set_0)
    assert moved_module_0.name == moved_attribute_0
    assert moved_module_0.new == set_0
    assert moved_module_0.old == None


# Generated at 2022-06-25 22:34:43.073221
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    float_0 = float(840.0)
    float_1 = float(840.0)
    moved_attribute_0 = MovedAttribute(float_0, float_1)
    moved_attribute_1 = MovedAttribute(float_0, float_1)
    assert moved_attribute_0 == moved_attribute_1


# Generated at 2022-06-25 22:34:54.640481
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    MovedAttribute(set_0, list_1, dict_0)
    assert_equal(moved_attribute_0.name, set_0)
    assert_equal(moved_attribute_0.new_mod, list_1)
    assert_equal(moved_attribute_0.new_attr, set_0)

# Unit

# Generated at 2022-06-25 22:35:05.391453
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_module_0 = MovedModule(moved_attribute_0, set_0)
    moved_module_1 = MovedModule(list_0, float_0)
    moved_module_2 = MovedModule(dict_0, tuple_0)
    six_moves_transformer = SixMovesTransformer()

# Generated at 2022-06-25 22:35:07.152698
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert isinstance(MovedAttribute(None, None, None), object)

# Generated at 2022-06-25 22:35:11.322348
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six

    int_0 = -3
    list_0 = [int_0]
    tuple_0 = ([int_0],)
    int_1 = 0
    moved_attribute_0 = MovedAttribute(int_1, list_0, tuple_0)


# Generated at 2022-06-25 22:35:15.897444
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        # Constructor test
        SixMovesTransformer()
    except TypeError:
        pass


if __name__ == '__main__':
    # Unit tests for six_moves.py
    test_case_0()
    # Constructor test
    check_constructor(SixMovesTransformer)

# Generated at 2022-06-25 22:35:25.483554
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test 'name' is readonly
    moved_module_0 = MovedModule(42, 42, 42)
    with pytest.raises(AttributeError):
        moved_module_0.name = 42

    # Test 'new' is readonly
    moved_module_0 = MovedModule(42, 42, 42)
    with pytest.raises(AttributeError):
        moved_module_0.new = 42

    # Test 'old' is readonly
    moved_module_0 = MovedModule(42, 42, 42)
    with pytest.raises(AttributeError):
        moved_module_0.old = 42

    # Test init
    moved_module_1 = MovedModule(42, 42, 42)


# Generated at 2022-06-25 22:35:35.288211
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_attribute_0 = MovedAttribute(str_0, float_0, tuple_0)
    moved_module_0 = MovedModule(tuple_0, dict_0)
    moved_module_1 = MovedModule(moved_attribute_0, float_0)
    moved_module_2 = MovedModule(set_0, float_0)
    moved_module_3 = MovedModule(list_1, float_0)
    moved_module_4 = MovedModule(list_0, float_0)
    moved_module_5 = MovedModule(tuple_0, float_0)
    moved_module_6 = MovedModule(dict_0, float_0)
    moved_module_7 = MovedModule(dict_0, float_0)
    moved_module_8 = MovedModule

# Generated at 2022-06-25 22:35:45.761118
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_attribute_1 = MovedAttribute(tuple_0, list_0, list_1)
    assert moved_attribute_0.name == set_0
    assert moved_attribute_1.name == tuple_0
    assert moved_attribute_0.new_mod == list_1
    assert moved_attribute_1.new_mod == list

# Generated at 2022-06-25 22:36:00.073709
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # if moved_attribute is instance of MovedAttribute
    moved_module_0 = MovedModule('', '', '')
    assert moved_module_0.name
    assert moved_module_0.new


# Generated at 2022-06-25 22:36:01.419637
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case_0()

# Generated at 2022-06-25 22:36:12.153615
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    global moved_module_2
    moved_module_2 = MovedModule(dict_0, tuple_0)
    try:
        six_moves_transformer_0 = SixMovesTransformer(moved_module_2)
    except RuntimeError:
        pass
    else:
        raise RuntimeError('AssertionError')
    assertEqual(SixMovesTransformer.rewrites, _get_rewrites(), 'SixMovesTransformer.rewrites must be _get_rewrites()')
    assertEqual(SixMovesTransformer.dependencies, ['six'], 'SixMovesTransformer.dependencies must be [\'six\']')

# Generated at 2022-06-25 22:36:18.269730
# Unit test for constructor of class MovedModule
def test_MovedModule():
    set_1 = {float('-47.0'), float('-12.0')}
    list_2 = [int('-119'), str('changed_attribute')]
    tuple_1 = (bool(1), bool(0))
    moved_module_3 = MovedModule(set_1, list_2)
    assert moved_module_3.name == set_1
    assert moved_module_3.new == list_2
    moved_module_4 = MovedModule(tuple_1)
    assert moved_module_4.name == tuple_1
    assert moved_module_4.new == tuple_1


# Generated at 2022-06-25 22:36:24.277493
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    assert moved_attribute_0.name == set_0


# Generated at 2022-06-25 22:36:27.878269
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    set_0 = {''}
    list_0 = ['']
    dict_0 = None
    moved_attribute_0 = MovedAttribute(set_0, list_0, dict_0)
    assert moved_attribute_0 is not None


# Generated at 2022-06-25 22:36:29.209034
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert test_case_0() == None


# Generated at 2022-06-25 22:36:30.767114
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()


# Generated at 2022-06-25 22:36:38.169202
# Unit test for constructor of class MovedModule
def test_MovedModule():
    tuple_0 = (4.0, 'b', 21.0)
    int_0 = 0
    bool_0 = bool()
    bool_1 = bool(int_0)
    bool_2 = bool(bool_1)
    bool_3 = bool(bool_1)
    bool_4 = bool(bool_3)
    bool_5 = bool(bool_1)
    moved_module_0 = MovedModule(bool_5, tuple_0)
    assert moved_module_0.new == tuple_0



# Generated at 2022-06-25 22:36:46.430124
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_module_0 = MovedModule(moved_attribute_0, set_0)



# Generated at 2022-06-25 22:37:18.511387
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_module_0 = MovedModule(moved_attribute_0, set_0)
    moved_module_1 = MovedModule(list_0, float_0)
    moved_module_2 = MovedModule(dict_0, tuple_0)
    six_moves_transformer_0 = SixMovesTransformer()
   

# Generated at 2022-06-25 22:37:29.717797
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'cStringIO'
    str_1 = 'cStringIO'
    str_2 = None
    str_3 = 'StringIO'
    str_4 = None
    MovedAttribute(str_0, str_1, str_2, str_3, str_4)
    str_0 = 'filter'
    str_1 = 'itertools'
    str_2 = 'builtins'
    str_3 = 'ifilter'
    str_4 = 'filter'
    MovedAttribute(str_0, str_1, str_2, str_3, str_4)
    str_0 = 'filterfalse'
    str_1 = 'itertools'
    str_2 = 'itertools'
    str_3 = 'ifilterfalse'

# Generated at 2022-06-25 22:37:34.537545
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Testing constructor of class SixMovesTransformer
    test_case_0()
    # Testing method rewrite_import
    test_SixMovesTransformer_rewrite_import()
    # Testing method rewrite_import_from
    test_SixMovesTransformer_rewrite_import_from()



# Generated at 2022-06-25 22:37:35.983359
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    global moved_module_2
    print(moved_module_2)

# Generated at 2022-06-25 22:37:44.124074
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_module_0 = MovedModule(moved_attribute_0, set_0)
    moved_module_1 = MovedModule(list_0, float_0)
    moved_module_2 = MovedModule(dict_0, tuple_0)
    assert_true(isinstance(SixMovesTransformer(), BaseImportRewrite))

# Generated at 2022-06-25 22:37:47.884680
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = [0, 0, 0]
    set_0 = {0}
    moved_attribute_0 = MovedAttribute(set_0, list_0, 0)
    assert moved_attribute_0.name == set_0


# Generated at 2022-06-25 22:37:56.793812
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    moved_module_0 = MovedModule(moved_attribute_0, set_0)
    moved_module_1 = MovedModule(list_0, float_0)
    moved_module_2 = MovedModule(dict_0, tuple_0)


# Generated at 2022-06-25 22:37:58.649450
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Call the constructor
    # Assert the default values of the constructor
    _SixMovesTransformer = SixMovesTransformer()


# Generated at 2022-06-25 22:38:02.206695
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'moved_module_2'
    tuple_0 = (set_0, list_1)
    moved_module_2 = MovedModule(str_0, tuple_0)

# Generated at 2022-06-25 22:38:04.058119
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(None, None)
    assert moved_module_0 is not None


# Generated at 2022-06-25 22:39:01.943339
# Unit test for constructor of class MovedModule
def test_MovedModule():
    set_0 = {'\\ds^\x0c', -840.0}
    float_0 = 0.0
    list_0 = []
    dict_0 = {set_0: list_0}
    moved_module_1 = MovedModule(set_0, list_0, dict_0)
    assert moved_module_1.name == set_0
    assert moved_module_1.new == list_0
    assert moved_module_1.old == dict_0


# Generated at 2022-06-25 22:39:12.354215
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_1 = None
    str_1 = '\\ds^\x0c'
    float_1 = -840.0
    tuple_1 = (str_1, float_1)
    list_2 = [str_1, tuple_1]
    set_1 = {tuple_1, tuple_1, str_1}
    list_3 = [set_1]
    moved_attribute_1 = MovedAttribute(set_1, list_3, dict_1)
    assert moved_attribute_1.name == set_1
    assert moved_attribute_1.old_mod == list_3
    assert moved_attribute_1.new_mod == dict_1
    assert moved_attribute_1.old_attr == list_2
    assert moved_attribute_1.new_attr == str_1

# Unit test

# Generated at 2022-06-25 22:39:15.200885
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    target = (2, 7)
    rewrites = _get_rewrites()
    dependencies = ['six']
    six_moves_transformer = SixMovesTransformer(target, rewrites, dependencies)



# Generated at 2022-06-25 22:39:19.757564
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    str_0 = '\x8b\x0f\xdc\x1c\x8f\xa3\xba'
    tuple_0 = (str_0, )
    moved_module_0 = MovedModule(tuple_0, dict_0)


# Generated at 2022-06-25 22:39:24.130535
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    assert isinstance(six_moves_transformer_0, object)

# Generated at 2022-06-25 22:39:32.322493
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _get_rewrites()

# Generated at 2022-06-25 22:39:42.882116
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    set_0 = {'\x0c\x0c', 'foo', 'w\x0c'}
    list_0 = ['foo', set_0]
    dict_0 = {'foo': 12, '\x0c\x0c': '', list_0: -840.0}
    float_0 = -840.0
    tuple_0 = ('\x0c\x0c', float_0)
    list_1 = [dict_0, tuple_0]
    moved_attribute_0 = MovedAttribute('foo', list_1, '\x0c\x0c')
    assert moved_attribute_0.name == 'foo'
    assert moved_attribute_0.new_attr is None
    assert moved_attribute_0.new_mod == '\x0c\x0c'
   

# Generated at 2022-06-25 22:39:52.459898
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = None
    str_0 = '\\ds^\x0c'
    float_0 = -840.0
    tuple_0 = (str_0, float_0)
    list_0 = [str_0, tuple_0]
    set_0 = {tuple_0, tuple_0, str_0}
    list_1 = [set_0]
    moved_attribute_0 = MovedAttribute(set_0, list_1, dict_0)
    assert moved_attribute_0.name == set_0
    assert moved_attribute_0.new_mod == list_1
    moved_attribute_0.name = set_0
    assert moved_attribute_0.name == set_0
    moved_attribute_0.new_mod = dict_0
    assert moved_attribute_0.new_

# Generated at 2022-06-25 22:39:56.110538
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    set_0 = {str_0, str_0}
    list_0 = [str_0, str_0]
    moved_attribute_0 = MovedAttribute(set_0, list_0, str_0, str_0)


# Generated at 2022-06-25 22:39:57.467247
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(None, None, None)
