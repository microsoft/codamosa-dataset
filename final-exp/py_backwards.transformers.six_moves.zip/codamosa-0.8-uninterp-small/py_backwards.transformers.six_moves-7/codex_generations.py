

# Generated at 2022-06-25 22:31:05.987213
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") is not None


# Generated at 2022-06-25 22:31:08.690378
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    ast0 = module_0.AST()
    six_moves_transformer0 = SixMovesTransformer(ast0)
    assert isinstance(six_moves_transformer0, SixMovesTransformer)


import typed_ast._ast27 as module_1


# Generated at 2022-06-25 22:31:11.208438
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:14.060435
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(name="name", old_mod="old_mod", new_mod="new_mod", old_attr="old_attr", new_attr="new_attr")


# Generated at 2022-06-25 22:31:19.109893
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("", "", "", "", "")
    # Assertion error: Expected MovedAttribute(name='', old_mod='', new_mod='', old_attr='', new_attr=''), but got: MovedAttribute(name='', old_mod='', new_mod='', new_attr='')


# Generated at 2022-06-25 22:31:25.525301
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')

    attr_0 = moved_attribute_0.name
    assert isinstance(attr_0, str)
    assert attr_0 == 'cStringIO'

    attr_1 = moved_attribute_0.new_mod
    assert isinstance(attr_1, str)
    assert attr_1 == 'io'

    attr_2 = moved_attribute_0.new_attr
    assert isinstance(attr_2, str)
    assert attr_2 == 'StringIO'


# Generated at 2022-06-25 22:31:29.087140
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

import typed_ast._ast27 as module_0


# Generated at 2022-06-25 22:31:31.981345
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:38.315410
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    # Check instance of class SixMovesTransformer
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    assert six_moves_transformer_0 is not None


# Generated at 2022-06-25 22:31:41.234613
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_0 = ('six')
    Moved_Module_0 = MovedModule(six_0, six_0, six_0)
    assert Moved_Module_0 is not None


# Generated at 2022-06-25 22:31:48.923501
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name_0 = 'name_0'
    old_0 = 'old_0'
    new_0 = 'new_0'
    # MovedModule_0 is an instance of class "MovedModule"
    MovedModule_0 = MovedModule(name_0, old_0, new_0)
    assert MovedModule_0.name == 'name_0'
    assert MovedModule_0.new == 'new_0'

# Generated at 2022-06-25 22:31:54.701063
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test with None
    try:
        a_moved_module_0 = MovedModule(None, None)
    except:
        pass
    else:
        raise RuntimeError("Failed to raise RuntimeError.")
    # Test with valid arguments
    a_moved_module_1 = MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:31:57.343127
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # No exception thrown.
    MovedModule("name", "old", "new")
    print("Constructor of class MovedModule works as expected.")


# Generated at 2022-06-25 22:32:03.072570
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_MovedModule = MovedModule("name", "old")
    assert test_MovedModule.name == "name"
    assert test_MovedModule.new == "name"
    assert test_MovedModule.old == "old"



# Generated at 2022-06-25 22:32:14.325235
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    # Test with real values from SixMovesTransformer.__init__
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0._ast is a_s_t_0
    # Test with None values
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    assert six_moves_transformer_1._ast is a_s_t_1
    # Test with real values from SixMovesTransformer.__init__
    a_s_t_2 = module_0.AST()
    six_moves_transformer_2 = SixMoves

# Generated at 2022-06-25 22:32:16.831821
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:32:21.001770
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 == six_moves_transformer_0

# Generated at 2022-06-25 22:32:31.034234
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test whether the constructor throws an exception
    try:
        SixMovesTransformer(0)
        import sys as module_1
        module_1.exit(1)
    # AssertionError is only available in Python 3
    except AssertionError:
        pass

if __name__ == '__main__':
    import sys as module_2
    import typing as module_3
    typing_0 = module_3.get_type_hints(SixMovesTransformer)
    typing_1 = module_0.AST
    typing_2 = typing_0.get('a_s_t')
    if (not ((typing_2 is typing_1) or ((sys is module_2) and (sys.version_info[0] < 3)))):
        module_2.exit(1)
    test_case_0

# Generated at 2022-06-25 22:32:34.455974
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    s_t_r_0 = str(moved_attribute_0)


# Generated at 2022-06-25 22:32:36.647627
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

import typing


# Generated at 2022-06-25 22:32:44.110885
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__')


# Generated at 2022-06-25 22:32:50.385167
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from typed_python import (
        Function, ListOf, Compiled, Tuple, TupleOf, Entrypoint
    )

    global a_s_t_0, six_moves_transformer_0
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# End of class test

# Generated at 2022-06-25 22:33:04.564185
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import pkgutil
    import sys
    import unittest
    import io
    import collections
    import six
    if six.PY3:
        import unittest.mock as mock
    else:
        import mock
    source = io.StringIO("import sys\nimport six.moves.UserDict\nimport six.moves.collections\nimport six.moves.urllib\nimport six.moves.urllib.parse\nimport six.moves.urllib.robotparser\nimport six.moves.urllib.request\nimport six.moves.urllib.error\nimport six.moves.urllib.response\n")
    subprocess_mock_0 = mock.Mock()
    subprocess_mock_0.check_output.return_

# Generated at 2022-06-25 22:33:08.741741
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:33:12.616942
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    source_code_0_0 = 'from urllib.request import urlopen\n'
    transformed_source_code_0_0 = 'from six.moves.urllib.request import urlopen\n'
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.transform_source_code(source_code_0_0) == transformed_source_code_0_0


# Generated at 2022-06-25 22:33:16.466146
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('builtins', '__builtin__')
    assert moved_module_0.name == 'builtins' and moved_module_0.new == 'builtins'


# Generated at 2022-06-25 22:33:21.011285
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "cStringIO"
    old_mod = "cStringIO"
    new_mod = "io"
    old_attr = "StringIO"
    new_attr = "cStringIO"
    moved_attribute_0 = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)


# Generated at 2022-06-25 22:33:32.529284
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = 'cStringIO'
    old_mod_0 = 'cStringIO'
    new_mod_0 = 'io'
    old_attr_0 = 'StringIO'
    new_attr_0 = None
    moved_attribute_0 = MovedAttribute(name_0, old_mod_0, new_mod_0, old_attr_0, new_attr_0)
    name_1 = 'filter'
    old_mod_1 = 'itertools'
    new_mod_1 = 'builtins'
    old_attr_1 = 'ifilter'
    new_attr_1 = 'filter'
    moved_attribute_1 = MovedAttribute(name_1, old_mod_1, new_mod_1, old_attr_1, new_attr_1)

# Generated at 2022-06-25 22:33:36.686768
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('configparser', 'ConfigParser')
    name = x.name
    #Correct because name is an attribute of the MovedModule class
    assert(name == 'configparser')

    new_mod = x.new
    assert(new_mod == 'ConfigParser')



# Generated at 2022-06-25 22:33:46.813175
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == "name"
    assert moved_module_0.old == "old"
    assert moved_module_0.new == "new"
    moved_module_1 = MovedModule("abc", "abc", "abc")
    assert moved_module_1.name == "abc"
    assert moved_module_1.old == "abc"
    assert moved_module_1.new == "abc"
    moved_module_2 = MovedModule("", "", "")
    assert moved_module_2.old == ""
    assert moved_module_2.name == ""
    assert moved_module_2.new == ""
    moved_module_3 = MovedModule("", "", "")
    assert moved_module

# Generated at 2022-06-25 22:33:54.512159
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 22:33:56.401241
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert(str(t).find('six') != -1)


# Generated at 2022-06-25 22:34:00.958988
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute_0 = MovedAttribute('foo', 'mod', 'mod2')
    assert(test_MovedAttribute_0.name == 'foo')
    assert(test_MovedAttribute_0.new_mod == 'mod2')
    assert(test_MovedAttribute_0.new_attr == 'foo')


# Generated at 2022-06-25 22:34:11.803444
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'import sys\nimport six.moves.urllib.robotparser\n'
    str_1 = 'import sys\nimport six.moves.urllib\n'
    str_2 = 'import sys\nimport six.moves.urllib.request\n'
    str_3 = 'import sys\nimport six.moves.urllib.response\n'
    str_4 = 'import sys\nimport six.moves.urllib.parse\n'
    str_5 = 'import sys\nimport six.moves.urllib.error\n'
    str_6 = 'import sys\nimport six.moves.collections\n'
    str_7 = 'import sys\n'

# Generated at 2022-06-25 22:34:13.838388
# Unit test for constructor of class MovedModule
def test_MovedModule():
    res = MovedModule('builtins', '__builtin__')
    assert res.name == 'builtins'
    assert res.new == 'builtins'


# Generated at 2022-06-25 22:34:15.151078
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    _MovedAttribute_0 = MovedAttribute('sys', None, None, None, None)


# Generated at 2022-06-25 22:34:22.716132
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'import sys\nimport six.moves.UserDict\nimport six.moves.collections\nimport six.moves.urllib\nimport six.moves.urllib.parse\nimport six.moves.urllib.robotparser\nimport six.moves.urllib.request\nimport six.moves.urllib.error\nimport six.moves.urllib.response\n'

    assert SixMovesTransformer().transform_code(str_0) == test_case_0()

# Generated at 2022-06-25 22:34:34.483672
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'import sys\nimport six.moves.UserDict\nimport six.moves.collections\nimport six.moves.urllib\nimport six.moves.urllib.parse\nimport six.moves.urllib.robotparser\nimport six.moves.urllib.request\nimport six.moves.urllib.error\nimport six.moves.urllib.response\n'
    MovedAttribute_0 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert_equal(MovedAttribute_0.new_mod, 'new_mod')
    assert_equal(MovedAttribute_0.name, 'name')

# Generated at 2022-06-25 22:34:41.903047
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'MovedModule(name, old, new=None)'
    str_1 = 'name'
    str_2 = 'old'
    str_3 = 'new'
    obj_0 = MovedModule(str_1, str_2, str_3)
    str_4 = str(obj_0)
    str_5 = 'MovedModule(name=name, old=old, new=new)'
    assert str_4 == str_5


# Generated at 2022-06-25 22:34:54.281271
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'import sys\nimport six.moves.UserDict\nimport six.moves.collections\nimport six.moves.urllib\nimport six.moves.urllib.parse\nimport six.moves.urllib.robotparser\nimport six.moves.urllib.request\nimport six.moves.urllib.error\nimport six.moves.urllib.response\n'

    t = MovedAttribute()
    #assert t == 'import sys\nimport six.moves.UserDict\nimport six.moves.collections\nimport six.moves.urllib\nimport six.moves.urllib.parse\nimport six.moves.urllib.robotparser\nimport six.moves.urllib.

# Generated at 2022-06-25 22:35:05.637793
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:35:16.746100
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    # AssertionError: assert 'g&Z5)TS\n]' == 'g&Z5)TS\n]'
    try:
        assert str_0 == str_0
    except AssertionError:
        print('AssertionError: assert str_0 == str_0')
    # AssertionError: assert 45.5 == 45.5

# Generated at 2022-06-25 22:35:24.423127
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    str_0 = 'Ug-L\x5e5[)$5l'
    float_0 = 45.5
    list_1 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_1, bool_0)

    assert moved_module_0.name == float_0
    assert moved_module_0.old == list_1
    assert moved_module_0.new == bool_0


# Generated at 2022-06-25 22:35:31.008051
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:35:41.630775
# Unit test for constructor of class MovedModule
def test_MovedModule():

    assert moved_module_0.name == 45.5
    assert moved_module_0.new == ['g&Z5)TS\n]', 'g&Z5)TS\n]', 45.5, 'g&Z5)TS\n]']
    assert moved_module_0.old == None


# Generated at 2022-06-25 22:35:51.536108
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Given
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    str_1 = '3.3'
    dict_0 = {str_0: MovedModule(float_0, list_0, bool_0), str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    # When

# Generated at 2022-06-25 22:36:01.915199
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from typed_ast import ast3 as ast
    
    # Test 1: Test instantiation of SixMovesTransformer
    x = ast.Str('test')
    y = ast.Str('test')
    z = ast.Str('test')
    a = ast.Str('test')
    
    y.str = 'test'
    y.s = 'test'
    y.ctx = ast.Load()
    
    z.value = 'test'
    z.s = 'test'
    z.ctx = ast.Load()
    
    a.values = []
    a.s = 'test'
    a.ctx = ast.Load()
    
    x.query = [y, z, a]
    x.query[0].arg = 'test'
    x.query[1].arg = 'test'
    x

# Generated at 2022-06-25 22:36:12.580286
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    print('Testing constructor')
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:36:19.447628
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:36:22.885876
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '*>;5[m\x15'
    moved_module_0 = MovedModule(str_0, str_0)
    # assert moved_module_0.name == str_0
    assert moved_module_0.new == str_0


# Generated at 2022-06-25 22:36:35.878602
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:36:47.010313
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, list_1)

# Generated at 2022-06-25 22:36:56.051797
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'func0'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    moved_module_1 = MovedModule(float_0, list_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:07.229338
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'qj[l?#'
    int_0 = -334
    moved_module_0 = MovedModule(str_0, int_0)
    str_1 = '0x&\t'
    moved_module_1 = MovedModule(str_0, int_0, str_1)
    int_1 = -20
    moved_module_2 = MovedModule(int_1, moved_module_0)
    # Check if the state of MovedModule is as expected
    assert moved_module_1.name == str_0
    assert moved_module_0.new == int_0
    # Check if the state of MovedModule is as expected
    assert moved_module_1.name == str_0
    assert moved_module_1.new == str_1
    # Check if the state

# Generated at 2022-06-25 22:37:16.876522
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    string_0 = ''

# Generated at 2022-06-25 22:37:18.728176
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Make sure it doesn't crash
    moved_module_0 = MovedModule('json', 'json', 'simplejson')



# Generated at 2022-06-25 22:37:27.116709
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    assert moved_module_0 is not None
    assert moved_module_0.name == float_0
    assert moved_module_0.new == list_0
    assert moved_module_0.old == bool_0


# Generated at 2022-06-25 22:37:37.727723
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:37:42.834540
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = ''
    float_0 = 0.0066
    list_0 = [str_0, str_0, str_0, str_0, str_0]
    a_s_t_0 = module_1.AST(**{})
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.module is a_s_t_0


# Generated at 2022-06-25 22:37:51.207669
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    float_0 = 87.44
    str_0 = '@7$3q\\'
    str_1 = '\\\n'
    list_0 = [float_0]
    moved_module_0 = MovedModule(str_0, str_1)
    int_0 = 50
    moved_attribute_0 = MovedAttribute(str_0, int_0)
    bool_0 = bool()
    moved_module_1 = MovedModule(str_1, moved_module_0, bool_0)
    moved_module_2 = MovedModule(moved_module_0, list_0, moved_attribute_0)


# Generated at 2022-06-25 22:38:26.178328
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '*k8]3yu'
    float_0 = -2.2
    list_0 = [str_0, str_0, float_0]
    moved_module_0 = MovedModule(float_0, list_0)
    assert moved_module_0.name == float_0
    assert moved_module_0.old == list_0
    assert moved_module_0.new == float_0
    str_1 = 'P_|7V'
    moved_module_1 = MovedModule(str_0, str_0, str_1)
    assert moved_module_1.name == str_0
    assert moved_module_1.old == str_0
    assert moved_module_1.new == str_1


# Generated at 2022-06-25 22:38:29.959611
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'e}2%^'
    float_0 = -11.85
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)


# Generated at 2022-06-25 22:38:41.985418
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import random
    import types
    import string
    import copy
    import sys
    import traceback


# Generated at 2022-06-25 22:38:49.361086
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    int_0 = -70
    str_0 = 'k^'
    float_0 = 85.0
    list_0 = [int_0, str_0, str_0, float_0]
    dict_0 = {int_0: list_0, str_0: str_0, str_0: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.ast == a_s_t_0


# Generated at 2022-06-25 22:38:57.462203
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:04.107284
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
  str_0 = 'g&Z5)TS\n]'
  float_0 = 45.5
  list_0 = [str_0, str_0, float_0, str_0]
  bool_0 = None
  moved_module_0 = MovedModule(float_0, list_0, bool_0)
  str_1 = '3.3'
  dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
  a_s_t_0 = module_1.AST(**dict_0)
  list_1 = None
  six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:13.629820
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  str_0 = 'g&Z5)TS\n]'
  float_0 = 45.5
  list_0 = [str_0, str_0, float_0, str_0]
  bool_0 = None
  moved_module_0 = MovedModule(float_0, list_0, bool_0)
  str_1 = '3.3'
  dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
  a_s_t_0 = module_1.AST(**dict_0)
  list_1 = None
  six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:24.864411
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = '@0.z4Q4'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:32.792910
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_2 = '^x33"4"g'

# Generated at 2022-06-25 22:39:43.353340
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '\x1a'
    float_0 = 80.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:40:51.159508
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

    six_moves_transformer_0.translate() # Nothing to test
    # Now

# Generated at 2022-06-25 22:41:00.139519
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'g&Z5)TS\n]'
    float_0 = 45.5
    list_0 = [str_0, str_0, float_0, str_0]
    bool_0 = None
    moved_module_0 = MovedModule(float_0, list_0, bool_0)
    str_1 = '3.3'
    dict_0 = {str_0: moved_module_0, str_0: list_0, str_1: float_0}
    a_s_t_0 = module_1.AST(**dict_0)
    list_1 = None
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_2 = '^x33"4"g'

# Generated at 2022-06-25 22:41:01.865952
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six.moves.map
    six.moves.filter
    six.moves.range
    six.moves.zip