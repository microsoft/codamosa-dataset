

# Generated at 2022-06-25 22:31:18.685992
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute()
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "name")
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO", "io", name="name")
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", name="name")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", new_attr="name")


# Generated at 2022-06-25 22:31:26.581235
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(a_s_t_0, module_0.AST)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    # Assertion is true
    try:
        six_moves_transformer_1 = SixMovesTransformer(six_moves_transformer_0)
        assert False
    except TypeError as e:
        assert True
    try:
        six_moves_transformer_2 = SixMovesTransformer(1)
        assert False
    except TypeError as e:
        assert True

# Unit tests for visit_Import method of class SixMovesTransformer

# Generated at 2022-06-25 22:31:29.509637
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t = module_0.AST()
    six_moves_transformer = SixMovesTransformer(a_s_t)


# Generated at 2022-06-25 22:31:30.509260
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_1 = MovedModule()


# Generated at 2022-06-25 22:31:41.620637
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__")
    assert MovedModule("configparser", "ConfigParser") 
    assert MovedModule("copyreg", "copy_reg")
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread")
    assert MovedModule("http_cookiejar", "cookielib", "http.cookiejar")
    assert MovedModule("http_cookies", "Cookie", "http.cookies")
    assert MovedModule("html_entities", "htmlentitydefs", "html.entities")
    assert MovedModule("html_parser", "HTMLParser", "html.parser")

# Generated at 2022-06-25 22:31:43.746196
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__") is not None


# Generated at 2022-06-25 22:31:50.514359
# Unit test for constructor of class MovedModule
def test_MovedModule():

    # Checks that the MovedModule constructor throws the correct error when called with the wrong number of arguments
    try:
        MovedModule()
        raise AssertionError("Expected error didn't occur")
    except TypeError as e:
        assert str(e) == '__init__() missing 3 required positional arguments: \'name\', \'old\', and \'new\''
    try:
        MovedModule('name')
        raise AssertionError("Expected error didn't occur")
    except TypeError as e:
        assert str(e) == '__init__() missing 2 required positional arguments: \'old\', and \'new\''

# Generated at 2022-06-25 22:31:51.538802
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_moved_module_0 = MovedModule()

# Generated at 2022-06-25 22:31:56.890629
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(
        "cStringIO",
        "cStringIO",
        "io",
        "StringIO")
    moved_attribute_1 = MovedAttribute(
        "cStringIO",
        "cStringIO",
        "io")


# Generated at 2022-06-25 22:32:09.993998
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute_0.name == 'cStringIO'
    assert moved_attribute_0.new_mod == 'io'
    assert moved_attribute_0.new_attr == 'StringIO'
    moved_attribute_1 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert moved_attribute_1.name == 'filter'
    assert moved_attribute_1.new_mod == 'builtins'
    assert moved_attribute_1.new_attr == 'filter'
    moved_attribute_2 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert moved_attribute_2.name

# Generated at 2022-06-25 22:32:19.183406
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_module_0 = MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    moved_module_1 = MovedModule("queue", "Queue")
    moved_module_2 = MovedModule("socketserver", "SocketServer")
    moved_module_3 = MovedModule("_thread", "thread", "_thread")
    moved_module_4 = MovedModule("tkinter", "Tkinter")
    moved_module_5 = MovedModule("tkinter_dialog", "Dialog", "tkinter.dialog")
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_1 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    moved_attribute_2

# Generated at 2022-06-25 22:32:23.680906
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("tkinter_tkfiledialog", "tkFileDialog", "tkinter.filedialog")
    assert moved_module.name == "tkinter_tkfiledialog"
    assert moved_module.new == "tkinter.filedialog"


# Generated at 2022-06-25 22:32:25.887052
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:32:31.871586
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()
    assert moved_module_0.name == ""
    assert moved_module_0.old == ""
    assert moved_module_0.new == ""
    moved_module_1 = MovedModule("moved_module_1", "old_1", "new_1")
    assert moved_module_1.name == "moved_module_1"
    assert moved_module_1.old == "old_1"
    assert moved_module_1.new == "new_1"


# Generated at 2022-06-25 22:32:39.389592
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module = astroid.parse('import foo')
    for name, path in SixMovesTransformer.rewrites:
        the_node = module.search_ancestors(name)
        if the_node is not None:
            break
    if name is None:
        raise AssertionError()
    else:
        original = the_node.name
        test_node = astroid.ExtSlice(the_node)
        a = SixMovesTransformer()
        a.visit_import(test_node)
        assert the_node.name != original

# Generated at 2022-06-25 22:32:41.157220
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()


# Generated at 2022-06-25 22:32:52.217321
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # assert type(moved_module_0) == <class 'six_moves_transformer.MovedModule'>
    assert type(moved_module_0) == MovedModule
    assert moved_module_0.name is None
    assert moved_module_0.new is None
    moved_module_1 = MovedModule("abc")
    assert moved_module_1.name == "abc"
    assert moved_module_1.new == "abc"
    moved_module_2 = MovedModule("abc", "def")
    assert moved_module_2.name == "abc"
    assert moved_module_2.new == "def"
    moved_module_3 = MovedModule("abc", "def", "ghi")
    assert moved_module_3.name == "abc"

# Generated at 2022-06-25 22:32:53.470004
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()



# Generated at 2022-06-25 22:33:05.390301
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute_0 = MovedAttribute("filter", "itertools", "builtins","ifilter", "filter")
    moved_attribute_0 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse","filterfalse")
    moved_attribute_0 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    moved_attribute_0 = MovedAttribute("intern", "__builtin__", "sys")
    moved_attribute_0 = MovedAttribute("map", "itertools", "builtins", "imap", "map")

# Generated at 2022-06-25 22:33:08.313745
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-25 22:33:10.831130
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:33:15.205012
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-25 22:33:16.605881
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:33:17.691047
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()


# Generated at 2022-06-25 22:33:28.997772
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_name = 'test_name'
    test_old_mod = 'test_old_mod'
    test_new_mod = 'test_new_mod'
    test_old_attr = 'test_old_attr'
    test_new_attr = 'test_new_attr'
    moved_attribute_0 = MovedAttribute(test_name, test_old_mod, test_new_mod, test_old_attr, test_new_attr)
    # Test property 'name'.
    assert moved_attribute_0.name == test_name
    # Test property 'new_mod'.
    assert moved_attribute_0.new_mod == test_new_mod
    # Test property 'new_attr'.
    assert moved_attribute_0.new_attr == test_new_attr
    moved_attribute_1 = MovedAttribute

# Generated at 2022-06-25 22:33:33.375948
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert mv.name == 'name'
    assert mv.new_mod == 'new_mod'
    assert mv.new_attr == 'new_attr'


# Generated at 2022-06-25 22:33:35.963283
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    moved_module_1 = MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:33:44.757755
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_module_1 = MovedModule()
    moved_module_2 = MovedModule()
    moved_module_3 = MovedModule()
    moved_module_4 = MovedModule()

    moved_attribute_0 = MovedAttribute()
    moved_attribute_1 = MovedAttribute()
    moved_attribute_2 = MovedAttribute()
    moved_attribute_3 = MovedAttribute()
    moved_attribute_4 = MovedAttribute()

    six_moves_transformer_0 = SixMovesTransformer()
    six_moves_transformer_1 = SixMovesTransformer()
    six_moves_transformer_2 = SixMovesTransformer()



# Generated at 2022-06-25 22:33:52.893354
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    smt = SixMovesTransformer()

# Generated at 2022-06-25 22:34:04.444684
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('name')
    moved_module_1 = MovedModule('name', 'old')
    moved_module_2 = MovedModule('name', 'old', 'new')
    moved_module_3 = MovedModule('name', old='old')
    moved_module_4 = MovedModule('name', old='old', new='new')
    moved_module_5 = MovedModule('name', new='new')
    moved_module_6 = MovedModule(name='name')
    moved_module_7 = MovedModule(name='name', old='old')
    moved_module_8 = MovedModule(name='name', old='old', new='new')
    moved_module_9 = MovedModule(name='name', new='new')



# Generated at 2022-06-25 22:34:08.590787
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:34:09.932522
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()


# Generated at 2022-06-25 22:34:14.469250
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv_attr = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io", old_attr="StringIO", new_attr="StringIO")
    assert mv_attr.name == "cStringIO"
    assert mv_attr.new_mod == "io"
    assert mv_attr.new_attr == "StringIO"


# Generated at 2022-06-25 22:34:19.719141
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_MovedAttribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert(test_MovedAttribute_0.name == "cStringIO")
    assert(test_MovedAttribute_0.new_mod == "io")
    assert(test_MovedAttribute_0.new_attr == "StringIO")


# Generated at 2022-06-25 22:34:22.769109
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old', 'new')
    assert(a.name == 'name')
    assert(a.old == 'old')
    assert(a.new == 'new')


# Generated at 2022-06-25 22:34:24.592226
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 39


# Generated at 2022-06-25 22:34:35.487238
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"
    moved_attribute_0 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert moved_attribute_0.name == "filter"
    assert moved_attribute_0.new_mod == "builtins"
    assert moved_attribute_0.new_attr == "filter"
    moved_attribute_1 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert moved_attribute_1.name == "filterfalse"

# Generated at 2022-06-25 22:34:40.169270
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("os", "os.path")
    assert (moved_module_0.name == "os")
    assert (moved_module_0.new == "os.path")


# Generated at 2022-06-25 22:34:44.446310
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute()
    assert obj.name == ""
    assert obj.old_mod == ""
    assert obj.new_mod == ""
    assert obj.old_attr == ""
    assert obj.new_attr == ""


# Generated at 2022-06-25 22:34:55.748802
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moved_module0 = MovedModule('name', 'old', 'new')
    moved_module1 = MovedModule('name', 'old')
    moved_module2 = MovedModule('name', new='new')
    moved_module3 = MovedModule('name')
    moved_attribute0 = MovedAttribute('name', 'old_mod', 'new_mod',
                                      'old_attr', 'new_attr')
    moved_attribute1 = MovedAttribute('name', 'old_mod', 'new_mod')
    moved_attribute2 = MovedAttribute('name', 'old_mod')
    moved_attribute3 = MovedAttribute('name',
                                      old_mod='old_mod', new_mod='new_mod')
    moved_attribute4 = MovedAttribute('name',
                                      old_mod='old_mod')
   

# Generated at 2022-06-25 22:35:03.903949
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-25 22:35:07.119979
# Unit test for constructor of class MovedModule
def test_MovedModule():
    return_value_0 = __new__(MovedModule('A', 'B', 'C'))
    assert return_value_0 == MovedModule('A', 'B', 'C')



# Generated at 2022-06-25 22:35:09.198798
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = MovedModule()
    assert moves is not None

# unit test for constructor of class MovedAttribute

# Generated at 2022-06-25 22:35:12.716262
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves_transformer_0 = SixMovesTransformer()
    assert isinstance(moves_transformer_0, object)
    assert isinstance(moves_transformer_0, BaseImportRewrite)
    


# Generated at 2022-06-25 22:35:14.403205
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 22:35:16.353432
# Unit test for constructor of class MovedModule
def test_MovedModule():
    n = "foo"
    o = "bar"
    MovedModule(n, o)


# Generated at 2022-06-25 22:35:17.784853
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()


# Generated at 2022-06-25 22:35:27.530255
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_1 = MovedModule('six.moves', 'urllib.parse', 'six.moves')
    moved_module_2 = MovedModule('six.moves', 'urllib.request', 'six.moves')
    moved_module_3 = MovedModule('six.moves', 'urllib.response', 'six.moves')
    moved_module_4 = MovedModule('six.moves', 'urllib.robotparser', 'six.moves')
    moved_module_5 = MovedModule('six.moves', 'urllib.error', 'six.moves')
    moved_module_6 = MovedModule('six.moves', '__builtin__', 'six.moves')

# Generated at 2022-06-25 22:35:29.752027
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert_equal(SixMovesTransformer().target, (2, 7))
    assert_equal(SixMovesTransformer().dependencies, ['six'])


# Generated at 2022-06-25 22:35:33.696545
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name = 'test_name', old = 'test_old', new = 'test_new')

# Generated at 2022-06-25 22:35:43.367601
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()
    assert moved_attribute_0.new_mod == None
    assert moved_attribute_0.name == None
    assert moved_attribute_0.new_attr == None


# Generated at 2022-06-25 22:35:44.699680
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
	moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:35:54.733077
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    move_1 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    move_2 = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    move_3 = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    move_4 = MovedAttribute("intern", "__builtin__", "sys")
    move_5 = MovedAttribute("map", "itertools", "builtins", "imap", "map")
    move_6 = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
   

# Generated at 2022-06-25 22:35:56.830197
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('getcwdb', 'os', 'os', 'getcwd', 'getcwdb')


# Generated at 2022-06-25 22:36:07.722964
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # constructor test 0
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    assert(moved_attribute_0.name == "cStringIO")
    assert(moved_attribute_0.new_mod == "io")
    assert(moved_attribute_0.new_attr == "StringIO")
    assert(moved_attribute_0.__class__ == MovedAttribute)

    # constructor test 1
    moved_attribute_1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    assert(moved_attribute_1.name == "cStringIO")
    assert(moved_attribute_1.new_mod == "io")
    assert(moved_attribute_1.new_attr == "StringIO")

# Generated at 2022-06-25 22:36:11.877294
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(name="b'name'",
                                       old_mod="b'old_mod'",
                                       new_mod="b'new_mod'",
                                       old_attr="b'old_attr'",
                                       new_attr="b'new_attr'")

# Generated at 2022-06-25 22:36:16.070570
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr_0 = MovedAttribute('StringIO', 'cStringIO', 'io')
    moved_attr_1 = MovedAttribute('StringIO', 'cStringIO', 'io', 'StringIO')
    moved_attr_2 = MovedAttribute('StringIO', 'cStringIO', 'io', None, 'StringIO')


# Generated at 2022-06-25 22:36:20.823971
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("7//3", "9.9%", "8.8").name == "7//3"
    MovedAttribute("8**3", "9.9%", "8.8").new_mod == "9.9%"
    MovedAttribute("~8", "9.9%", "8.8").new_attr == "8.8"



# Generated at 2022-06-25 22:36:22.838745
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Make sure the constructor works
    moved_attribute_0 = MovedAttribute()
    assert moved_attribute_0 != None


# Generated at 2022-06-25 22:36:26.997067
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute(
        'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-25 22:36:43.434834
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-25 22:36:47.174602
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule()
    assert(moved_module_0.name is None)
    assert(moved_module_0.old is None)
    assert(moved_module_0.new is None)


# Generated at 2022-06-25 22:36:50.218297
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('StringIO', 'StringIO', 'io')
    assert moved_module_0.name == 'StringIO'
    assert moved_module_0.new == 'io'



# Generated at 2022-06-25 22:36:51.326463
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:36:54.400891
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tester = SixMovesTransformer()
    assert tester.target == (2, 7)
    assert list(tester.rewrites) == _get_rewrites()
    assert tester.dependencies == ['six']


# Generated at 2022-06-25 22:37:00.043045
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('email.mime.quoprimime', 'quopriMIME', 'email.mime.quoprimime')
    assert moved_module.name == 'email.mime.quoprimime'
    assert moved_module.new == 'email.mime.quoprimime'

# Generated at 2022-06-25 22:37:02.488009
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    excinfo.match(r'__init__\(\) missing 4 required positional arguments')

# Generated at 2022-06-25 22:37:03.430725
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer() is not None

# Generated at 2022-06-25 22:37:08.862823
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute_0 = MovedAttribute('Module1', 'Module2')
    expected_value = ("Module1", "Module2", None, None, None)
    ret_value = (attribute_0.name, attribute_0.old_mod, attribute_0.new_mod,
                 attribute_0.old_attr, attribute_0.new_attr)
    assert ret_value == expected_value


# Generated at 2022-06-25 22:37:12.735220
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_2 = MovedModule("alg","old")
    assert moved_module_2.name == "alg"
    assert moved_module_2.old == "old"
    assert moved_module_2.new == "alg"
    
    

# Generated at 2022-06-25 22:37:26.055205
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer)


# Generated at 2022-06-25 22:37:35.005095
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name").name == "name"
    assert MovedModule("name").old == "name"
    assert MovedModule("name").new == "name"



# Generated at 2022-06-25 22:37:37.181390
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sixMovesTransformer = SixMovesTransformer(2, 7)
    assert sixMovesTransformer.target == (2, 7)


# Generated at 2022-06-25 22:37:40.607509
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old', 'new').old == 'old'



# Generated at 2022-06-25 22:37:42.412698
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_transformer_0 = SixMovesTransformer()
    assert six_transformer_0

# No unit test for class MovedModule


# Generated at 2022-06-25 22:37:43.741206
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute()


# Generated at 2022-06-25 22:37:46.860307
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == "name"
    assert moved_module_0.new == "new"
    

# Generated at 2022-06-25 22:37:51.493140
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('test_attribute', 'test_old_mod', 'test_new_mod', 'test_old_attr', 'test_new_attr')
    assert m.name == 'test_attribute'
    assert m.new_mod == 'test_new_mod'
    assert m.new_attr == 'test_new_attr'


# Generated at 2022-06-25 22:37:56.591391
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('abc', 'abc')
    assert (move.name == 'abc')
    assert (move.old == 'abc')
    assert (move.new == 'abc')
    move = MovedModule('def', 'def', 'def2')
    assert (move.name == 'def')
    assert (move.old == 'def')
    assert (move.new == 'def2')

# Generated at 2022-06-25 22:38:06.031578
# Unit test for constructor of class MovedModule
def test_MovedModule():
    instance0 = MovedModule("six", "subprocess", "__builtin__")
    instance1 = MovedModule("six.moves", "subprocess", "subprocess")
    instance2 = MovedModule("six.moves.subprocess", "subprocess", "subprocess")
    assert instance0.__name__ == "subprocess"
    assert instance1.__name__ == "subprocess"
    assert instance2.__name__ == "subprocess"
    assert instance0.subprocess == "subprocess"
    assert instance1.subprocess == "subprocess"
    assert instance2.subprocess == "subprocess"
    assert instance0.subprocess == "subprocess"
    assert instance1.subprocess == "subprocess"
    assert instance2.subprocess == "subprocess"

# Generated at 2022-06-25 22:38:41.386867
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attr_0 = MovedAttribute("name", "old_module", "new_module", "old_attr", "new_attr")
    assert moved_attr_0.name == "name"
    assert moved_attr_0.new_mod == "new_module"
    assert moved_attr_0.new_attr == "new_attr"


# Generated at 2022-06-25 22:38:50.478931
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert_raises(TypeError, test_case_0)
    moved_module_1 = MovedModule('collections', '__builtin__')
    expected_name_1 = 'collections'
    expected_old_1 = '__builtin__'
    expected_new_1 = 'collections'
    assert moved_module_1.name == expected_name_1
    assert moved_module_1.old == expected_old_1
    assert moved_module_1.new == expected_new_1
    moved_module_2 = MovedModule('collections', '__builtin__', 'collections')
    expected_name_2 = 'collections'
    expected_old_2 = '__builtin__'
    expected_new_2 = 'collections'
    assert moved_module_2.name == expected_name

# Generated at 2022-06-25 22:38:53.507203
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.target == (2, 7)
    assert six_moves_transformer.dependencies == ['six']
    assert six_moves_transformer.rewrites == _get_rewrites()


# Generated at 2022-06-25 22:38:56.453409
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert moved_module_0.name == ''
    assert moved_module_0.new == ''
    assert moved_module_1.name == 'builtins'
    assert moved_module_1.new == '__builtin__'


# Generated at 2022-06-25 22:38:58.814663
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-25 22:39:01.508616
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name","old_mod", "new_mod")
    assert moved_attribute.name == "name"
    assert moved_attribute.old_mod == "old_mod"
    assert moved_attribute.new_mod == "new_mod"


# Generated at 2022-06-25 22:39:08.057360
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = MovedAttribute.name
    old_attr_0 = MovedAttribute.old_attr
    new_attr_0 = MovedAttribute.new_attr
    old_mod_0 = MovedAttribute.old_mod
    new_mod_0 = MovedAttribute.new_mod
    case_0 = MovedAttribute(name_0,old_mod_0,new_mod_0,old_attr_0,new_attr_0)


# Generated at 2022-06-25 22:39:09.400588
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(TypeError):
        SixMovesTransformer()

# Generated at 2022-06-25 22:39:13.491163
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule()
    assert mm
    mm = MovedModule(name="name")
    assert mm
    mm = MovedModule(name="name", old="old")
    assert mm
    mm = MovedModule(name="name", old="old", new="new")
    assert mm


# Generated at 2022-06-25 22:39:24.730132
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    source = """import six
from six.moves import html_parser
import os
import sys
from six.moves import shlex_quote
from six.moves.urllib import request as urllib_request
from six.moves import urllib
from six.moves import urllib_parse
from six.moves import urllib_error
from six.moves.urllib.request import urlretrieve
import six.moves.urllib.parse"""

# Generated at 2022-06-25 22:39:55.960790
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo").name == "foo"
    assert MovedAttribute("foo").old_mod is None
    assert MovedAttribute("foo").new_mod == "foo"
    assert MovedAttribute("foo", "old_mod").new_mod == "old_mod"
    assert MovedAttribute("foo", new_mod="bar").new_mod == "bar"
    assert MovedAttribute("foo", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("foo", new_mod="bar", old_mod="foo")
    assert MovedAttribute("foo", new_mod="bar", old_mod="foo").new_mod == "bar"
    assert MovedAttribute("foo", "old_mod", "new_mod", "old_attr").old_attr == "old_attr"


# Generated at 2022-06-25 22:40:02.958275
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    dict_0 = None
    moved_attribute_0 = None
    str_0 = 'lp'
    str_1 = 'D(tq[]Psk^\rM6i`A'
    str_2 = '3.6'
    dict_1 = {str_0: dict_0, str_1: str_0, str_2: str_1}
    moved_module_0 = MovedModule(dict_0, moved_attribute_0, dict_1)
    moved_module_0 = MovedModule(dict_0, moved_attribute_0, list_0)
    moved_module_0 = MovedModule(dict_0, moved_attribute_0)
    moved_module_0 = MovedModule(dict_0, moved_attribute_0, list_0)
    moved

# Generated at 2022-06-25 22:40:14.709018
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    dict_0 = None
    moved_attribute_0 = None
    str_0 = 'lp'
    str_1 = 'D(tq[]Psk^\rM6i`A'
    str_2 = '3.6'
    dict_1 = {str_0: dict_0, str_1: str_0, str_2: str_1}
    moved_module_0 = MovedModule(dict_0, moved_attribute_0, dict_1)
    float_0 = 1540.9
    set_0 = set()
    bytes_0 = b'\x9c\xea\xfd<B\x98\xfe4\x8e\xf2\xb9\xbek\xfe'

# Generated at 2022-06-25 22:40:18.018615
# Unit test for constructor of class MovedModule
def test_MovedModule():
  # Setup inputs
  name = ''
  old_mod = ''
  new_mod = ''
  # Expected output
  expected_output = ('')
  # Call the method
  MovedModule(name, old_mod, new_mod)
  # Check if it's expected value
  assert expected_output == new_mod


# Generated at 2022-06-25 22:40:25.507414
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    dict_0 = None
    moved_attribute_0 = None
    str_0 = 'lp'
    str_1 = 'D(tq[]Psk^\rM6i`A'
    str_2 = '3.6'
    dict_1 = {str_0: dict_0, str_1: str_0, str_2: str_1}
    moved_module_0 = MovedModule(dict_0, moved_attribute_0, dict_1)


# Generated at 2022-06-25 22:40:27.680995
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # string, string, string, string, string -> NONE
    assert MovedAttribute('a', 'b', 'c', 'd', 'e') is not None



# Generated at 2022-06-25 22:40:35.396498
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    dict_0 = None
    moved_attribute_0 = None
    str_0 = 'lp'
    str_1 = 'D(tq[]Psk^\rM6i`A'
    str_2 = '3.6'
    dict_1 = {str_0: dict_0, str_1: str_0, str_2: str_1}
    moved_module_0 = MovedModule(dict_0, moved_attribute_0, dict_1)
    float_0 = 1540.9
    set_0 = set()
    bytes_0 = b'\x9c\xea\xfd<B\x98\xfe4\x8e\xf2\xb9\xbek\xfe'

# Generated at 2022-06-25 22:40:43.948350
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_2 = None
    dict_3 = None
    moved_attribute_2 = None
    str_0 = 'lp'
    str_1 = 'D(tq[]Psk^\rM6i`A'
    str_2 = '3.6'
    dict_1 = {str_0: dict_3, str_1: str_0, str_2: str_1}
    moved_module_0 = MovedModule(dict_3, moved_attribute_2, dict_1)
    float_0 = 1540.9
    set_0 = set()
    bytes_0 = b'\x9c\xea\xfd<B\x98\xfe4\x8e\xf2\xb9\xbek\xfe'

# Generated at 2022-06-25 22:40:46.983905
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'TbT;'
    list_0 = list()
    moved_attribute_0 = MovedAttribute(str_0, list_0, list_0)


# Generated at 2022-06-25 22:40:55.672159
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test attribute {moved_module_0} of type object
    moved_module_0 = MovedModule()
    assert (isinstance(moved_module_0, object))
    # Test attribute {moved_module_1} of type object
    list_0 = None
    dict_0 = None
    moved_attribute_0 = None
    str_0 = 'lp'
    str_1 = 'D(tq[]Psk^\rM6i`A'
    str_2 = '3.6'
    dict_1 = {str_0: dict_0, str_1: str_0, str_2: str_1}
    moved_module_1 = MovedModule(dict_0, moved_attribute_0, dict_1)
    assert (isinstance(moved_module_1, object))
