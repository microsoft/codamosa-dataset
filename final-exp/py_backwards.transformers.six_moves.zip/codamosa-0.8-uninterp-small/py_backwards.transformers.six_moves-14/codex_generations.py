

# Generated at 2022-06-25 22:31:10.426526
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    # Test the constructor of class SixMovesTransformer
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0 != None


# Generated at 2022-06-25 22:31:15.379606
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    target_0 = (2, 7)
    rewrites_0 = _get_rewrites()
    dependencies_0 = ['six']

    six_moves_transformer_0 = SixMovesTransformer(target_0, rewrites_0, dependencies_0)

if __name__ == '__main__':
    test_case_0()
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:31:17.723888
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:31:25.131859
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        SixMovesTransformer()
    except NameError:
        assert False, "Could not instantiate class SixMovesTransformer"
    else:
        assert True

_get_rewrites()
_rewrites = [('map', 'six.moves.map'), ('zip', 'six.moves.zip'), ('range', 'six.moves.range'), ('filter', 'six.moves.filter'), ('reduce', 'six.moves.reduce'), ('input', 'six.moves.input'), ('StringIO', 'six.moves.StringIO'), ('reload_module', 'six.moves.reload_module')]


# Generated at 2022-06-25 22:31:30.133227
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == "name"
    moved_module_1 = MovedModule("name", "old")
    assert moved_module_1.name == "name"
    assert moved_module_1.new == "name"


# Generated at 2022-06-25 22:31:36.542635
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test keyword arguments
    a_moved_attribute_0 = MovedAttribute(name=None, old_mod=None, new_mod=None, old_attr=None, new_attr=None)
    assert a_moved_attribute_0.name is None
    assert a_moved_attribute_0.new_mod is None
    assert a_moved_attribute_0.new_attr is None


# Generated at 2022-06-25 22:31:39.402306
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name_0 = "name"
    old_mod_0 = "old_mod"
    new_mod_0 = "new_mod"
    old_attr_0 = "old_attr"
    new_attr_0 = "new_attr"
    moved_attribute_0 = MovedAttribute(name_0, old_mod_0, new_mod_0, old_attr_0, new_attr_0)


# Generated at 2022-06-25 22:31:48.849559
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute_0_name = "cStringIO"
    movedattribute_1_name = "cStringIO"
    movedattribute_2_name = "cStringIO"
    movedattribute_1_old_mod = "cStringIO"
    movedattribute_1_new_mod = "io"
    movedattribute_2_old_mod = "cStringIO"
    movedattribute_2_new_mod = "io"
    movedattribute_1_old_attr = "StringIO"
    movedattribute_2_old_attr = "StringIO"
    movedattribute_1_new_attr = None
    movedattribute_2_new_attr = None
    movedattribute_1_name = movedattribute_1_name
    movedattribute_1_old_mod = movedattribute_1_old_mod
    movedattribute_1_new_mod

# Generated at 2022-06-25 22:31:59.042078
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Case 1
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.tree == a_s_t_0

# Generated at 2022-06-25 22:32:08.060380
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    _return = SixMovesTransformer(a_s_t_0)
    if isinstance(_return, SixMovesTransformer):
        pass
    else:
        raise Exception("Expected return value to be of type `SixMovesTransformer`, got {}".format(type(_return)))

LINES = ["from six import moves",
         'import six.moves']
OUTPUT = LINES


# Generated at 2022-06-25 22:32:13.174057
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_input = MovedModule("name", "old", "new")
    assert test_input.name == "name"
    assert test_input.old == "old"
    assert test_input.new == "new"


# Generated at 2022-06-25 22:32:14.487421
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:32:16.976036
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")


# Generated at 2022-06-25 22:32:18.972270
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)



# Generated at 2022-06-25 22:32:23.489741
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('moved_attribute', 'old_module', 'new_module')
    assert moved_attribute.name == 'moved_attribute'
    assert moved_attribute.new_mod == 'new_module'
    assert moved_attribute.new_attr == 'moved_attribute'


# Generated at 2022-06-25 22:32:26.013782
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(TypeError):
        SixMovesTransformer(arg1=1)


# Generated at 2022-06-25 22:32:29.690979
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_0 = MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server")
    assert test_0.name == "CGIHTTPServer"
    assert test_0.old == "CGIHTTPServer"
    assert test_0.new == "http.server"


# Generated at 2022-06-25 22:32:30.819123
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_1 = SixMovesTransformer()


# Generated at 2022-06-25 22:32:37.087826
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test Constructor of SixMovesTransformer
    six_moves_transformer_1 = SixMovesTransformer()
    # Test getting dependencies of SixMovesTransformer
    dependency = ['six']
    assert six_moves_transformer_1.dependencies == dependency
    # Test getting target of SixMovesTransformer
    assert six_moves_transformer_1.target == (2, 7)


# Generated at 2022-06-25 22:32:42.356697
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert type(MovedModule("name", "old", "new")) == MovedModule
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"


# Generated at 2022-06-25 22:32:51.349562
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"


# Generated at 2022-06-25 22:32:52.896280
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_1 = SixMovesTransformer()

# Generated at 2022-06-25 22:32:55.370202
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("dummy1", "dummy2", "dummy3")


# Generated at 2022-06-25 22:32:58.560117
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule0 = MovedModule('')
    assert movedModule0.name == ''
    assert movedModule0.new == ''



# Generated at 2022-06-25 22:33:01.065418
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'cStringIO'
    old_mod = 'cStringIO'
    new_mod = 'io'
    old_attr = 'StringIO'
    new_attr = 'StringIO'
    moved_attribute = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)


# Generated at 2022-06-25 22:33:03.110525
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") is not None


# Generated at 2022-06-25 22:33:09.511826
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mock_name = 'name'
    mock_old_mod = 'old_mod'
    mock_new_mod = 'new_mod'
    mock_old_attr = 'old_attr'
    mock_new_attr = 'new_attr'
    MovedAttribute(mock_name, mock_old_mod, mock_new_mod, mock_old_attr,
                   mock_new_attr)


# Generated at 2022-06-25 22:33:12.206961
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "cStringIO"
    old_mod = "cStringIO"
    new_mod = "cStringIO"
    old_attr = "cStringIO"
    new_attr = "cStringIO"
    moved_attribute = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)


# Generated at 2022-06-25 22:33:13.813418
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()


# Generated at 2022-06-25 22:33:19.042864
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute_0.name == "cStringIO"
    assert moved_attribute_0.new_mod == "io"
    assert moved_attribute_0.new_attr == "cStringIO"


# Generated at 2022-06-25 22:33:26.267199
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:33:34.549790
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedAttribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert movedAttribute.name == "cStringIO"
    assert movedAttribute.new_mod == "io"
    assert movedAttribute.new_attr == "StringIO"

    movedAttribute = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert movedAttribute.name == "filter"
    assert movedAttribute.new_mod == "builtins"
    assert movedAttribute.new_attr == "filter"



# Generated at 2022-06-25 22:33:36.958861
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(AssertionError):
        MovedModule('json', 'marshal')


# Generated at 2022-06-25 22:33:41.132450
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    moved_attribute_0.name
    moved_attribute_0.new_mod
    moved_attribute_0.new_attr


# Generated at 2022-06-25 22:33:42.897390
# Unit test for constructor of class MovedModule
def test_MovedModule():
        moved_module_1 = MovedModule("name", "old", "new")


# Generated at 2022-06-25 22:33:44.983658
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert isinstance(six_moves_transformer, SixMovesTransformer)

# Generated at 2022-06-25 22:33:46.768839
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr=None", "new_attr=None")


# Generated at 2022-06-25 22:33:48.066835
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer() is not None


# Generated at 2022-06-25 22:33:51.958281
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    print(six_moves_transformer_0.dependencies)
    print(six_moves_transformer_0.rewrites)
    print(six_moves_transformer_0.target)
    print(six_moves_transformer_0.target_is_python_version)

# Generated at 2022-06-25 22:33:57.402586
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    switches.PYTHON_VERSION = 2
    assert SixMovesTransformer.target == (2, 7)
    switches.PYTHON_VERSION = 3
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.dependencies == ['six']
    assert six_moves_transformer_0.source == 'six'


# Generated at 2022-06-25 22:34:10.712680
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
  assert MovedAttribute('arg1', 'arg2', 'arg3', 'arg4', 'arg5')


# Generated at 2022-06-25 22:34:13.867516
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', '/path/to/old_module', '/path/to/new_module')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == '/path/to/old_module'


# Generated at 2022-06-25 22:34:18.542312
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "builtins"
    old = "__builtin__"
    new_module = "builtins"
    x = MovedModule(name, old, new_module)
    assert x.name == "builtins"
    assert x.old == "__builtin__"
    assert x.new == "builtins"


# Generated at 2022-06-25 22:34:19.536292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:34:32.054708
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert six_moves_transformer_0.dependencies == ['six']

# Generated at 2022-06-25 22:34:33.964645
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        _ = MovedModule()


# Generated at 2022-06-25 22:34:39.241474
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites is not None
    # constructor test 1 will be removed in the next release
    # assert six_moves_transformer_0.rewrites is not None
    # constructor test 2 will be removed in the next release
    # assert six_moves_transformer_0.rewrites is not None


# Generated at 2022-06-25 22:34:43.971725
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert six_moves_transformer_0 is not None
    assert six_moves_transformer_0.target == (2, 7)

# Generated at 2022-06-25 22:34:46.862633
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"

# Generated at 2022-06-25 22:34:49.830469
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:35:11.819402
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    str_0 = '>aq*r=8\x0c'
    str_1 = 'ozY:4kxj'
    str_2 = 'addclosehook'
    a_s_t_0 = None
    set_0 = {a_s_t_0, a_s_t_0, list_0, a_s_t_0}
    str_3 = '{c\t`tZiF*h3\x0c4k>'
    dict_0 = {str_3: str_0}
    int_0 = -1432
    float_0 = -814.44578
    bool_0 = True
    tuple_0 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = Moved

# Generated at 2022-06-25 22:35:12.857685
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass


# Generated at 2022-06-25 22:35:23.720300
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    str_0 = 'D,uK5$'
    str_1 = 'C i2'
    str_2 = 'rUi)%c'
    a_s_t_0 = None
    set_0 = {a_s_t_0, a_s_t_0, list_0, a_s_t_0}
    str_3 = 'X,/W3$'
    dict_0 = {str_3: str_0}
    int_0 = -439
    float_0 = -824.85677
    bool_0 = True
    tuple_0 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = MovedModule(set_0, tuple_0)
    moved_attribute_0 = M

# Generated at 2022-06-25 22:35:30.148129
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'zQoVu&*$b9|Vr@'
    str_1 = '+5#t>lNxDxFJ$'
    str_2 = 'reload_module'
    a_s_t_0 = module_1.AST(*list(), **{str_2: str_2})
    a_s_t_1 = module_1.AST(*list(), **{str_1: str_2})
    moved_module_0 = MovedModule(str_0, a_s_t_1)
    moved_module_1 = MovedModule(str_1, a_s_t_0, moved_module_0)


# Generated at 2022-06-25 22:35:31.642790
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Safe to skip, because the constructor is trivial
    pass


# Generated at 2022-06-25 22:35:42.499086
# Unit test for constructor of class MovedModule

# Generated at 2022-06-25 22:35:45.628599
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    obj_1 = MovedAttribute(var_1, var_2, var_3, var_4, var_4)


# Generated at 2022-06-25 22:35:48.718723
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer(module_1.AST(*[], **{}))
    six_moves_transformer_0.rewrites = dict({})


# Generated at 2022-06-25 22:35:52.039359
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_1.AST()
    moved_attribute_0 = MovedAttribute('', '', None)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:36:02.501603
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'E^Kny7m'
    dict_0 = {str_0: str_0}
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0, bool_0]
    list_1 = [bool_0, bool_0, bool_0]
    tuple_0 = (list_1, list_1)
    dict_1 = {str_0: tuple_0}
    str_1 = '!_8\\v!k'
    str_2 = 'p5W8,vU5@39'
    str_3 = '~k-pDv1txe'
    str_4 = 'GQ`"b`xo'
    str_5 = '%cLf*y#F'

# Generated at 2022-06-25 22:36:34.577866
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    str_0 = '&j\x0cDd9bjw'
    str_1 = 'r6|>U\rvK'
    str_2 = 'addbase'
    a_s_t_0 = None
    set_0 = {a_s_t_0, a_s_t_0, list_0, a_s_t_0}
    str_3 = 'k@\tXqB\x0bK&*A<u'
    dict_0 = {str_3: str_0}
    int_0 = -1432
    float_0 = -814.44578
    bool_0 = True
    tuple_0 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = Moved

# Generated at 2022-06-25 22:36:44.769846
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '^IpY\n=:|\x0b@mZ`'
    set_0 = {str_0}
    str_1 = 'a|:%|\n>_$S\x0b'
    int_0 = -564
    bool_0 = True
    tuple_0 = (int_0, str_1, bool_0)
    moved_module_0 = MovedModule(set_0, tuple_0)
    str_2 = '#HZRj~.5DfKE+'
    moved_attribute_0 = MovedAttribute(str_2, tuple_0, bool_0, moved_module_0)


# Generated at 2022-06-25 22:36:45.837663
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'moves'


# Generated at 2022-06-25 22:36:48.569175
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule(str, str).name == str
    assert MovedModule(str, str, str).new == str
    assert MovedModule(str, str, str).name == str


# Generated at 2022-06-25 22:36:50.218684
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    func_0 = SixMovesTransformer(six_moves_transformer_1)


# Generated at 2022-06-25 22:36:52.254783
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test exception case
    try:
        MovedModule('test', None)
    except ValueError:
        pass


# Generated at 2022-06-25 22:36:57.797420
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = '4\'qN+Q\\CJn\x0c'
    moved_attribute_0 = MovedAttribute(str_0)
    a_s_t_0 = module_1.AST(*list(), **{})
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:08.373860
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    str_0 = '>aq*r=8\x0c'
    str_1 = 'ozY:4kxj'
    str_2 = 'addclosehook'
    a_s_t_0 = None
    set_0 = {a_s_t_0, a_s_t_0, list_0, a_s_t_0}
    str_3 = '{c\t`tZiF*h3\x0c4k>'
    dict_0 = {str_3: str_0}
    int_0 = -1432
    float_0 = -814.44578
    bool_0 = True
    tuple_0 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = Moved

# Generated at 2022-06-25 22:37:11.614241
# Unit test for constructor of class MovedModule
def test_MovedModule():
    set_0 = {str_0}
    tuple_0 = (list_0, bool_0, set_0)
    moved_module_0 = MovedModule(str_3, tuple_0)



# Generated at 2022-06-25 22:37:13.448195
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a = SixMovesTransformer(AST)
    # No assert


# Generated at 2022-06-25 22:38:05.991266
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'name'
    old_mod = 'old_mod'
    new_mod = 'new_mod'
    old_attr = 'old_attr'
    new_attr = 'new_attr'
    moved_attribute = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert moved_attribute.name == name
    assert moved_attribute.new_mod == new_mod
    assert moved_attribute.new_attr == new_attr


# Generated at 2022-06-25 22:38:14.089244
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {};
    dict_1 = {};
    dict_2 = {};
    dict_3 = {};
    dict_4 = {};
    dict_5 = {};
    dict_6 = {};
    dict_7 = {};
    dict_8 = {};
    dict_9 = {};
    dict_10 = {};
    dict_11 = {};
    dict_12 = {};
    dict_13 = {};
    dict_14 = {};
    dict_15 = {};
    dict_16 = {};
    dict_17 = {};
    dict_18 = {};
    dict_19 = {};
    dict_20 = {};
    dict_21 = {};
    dict_22 = {};
    dict_23 = {};
    dict_24 = {};

# Generated at 2022-06-25 22:38:20.338145
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    param1 = random.randint(0, 9)
    param2 = random.randint(0, 9)
    param3 = random.randint(0, 9)
    param4 = random.randint(0, 9)
    param5 = random.randint(0, 9)
    obj1 = MovedAttribute(param1, param2, param3, param4, param5)
    obj2 = MovedAttribute(param1, param2, param3, param4, param5)
    assert obj1 == obj2


# Generated at 2022-06-25 22:38:29.480483
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    str_0 = '>aq*r=8\x0c'
    str_1 = 'ozY:4kxj'
    str_2 = 'addclosehook'
    a_s_t_0 = None
    set_0 = {a_s_t_0, a_s_t_0, list_0, a_s_t_0}
    str_3 = '{c\t`tZiF*h3\x0c4k>'
    dict_0 = {str_3: str_0}
    int_0 = -1432
    float_0 = -814.44578
    bool_0 = True
    tuple_0 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = Moved

# Generated at 2022-06-25 22:38:41.608150
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    coder_0 = MovesCoder()

    str_0 = "moved"
    str_1 = "6"
    str_2 = "f"
    str_3 = "d"
    str_4 = "e"
    str_5 = "f"
    str_6 = "g"
    str_7 = "h"
    str_8 = "i"
    str_9 = "c"

    a_s_t_0 = module_1.AST()
    a_s_t_1 = module_1.AST()
    a_s_t_2 = module_1.AST()
    a_s_t_3 = module_1.AST()

    int_0 = 1

    tuple_0 = (str_0, str_1, str_2, str_3, str_4)

# Generated at 2022-06-25 22:38:50.591931
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = ')UD\n'
    tuple_0 = (str_0, str_0, str_0)
    dict_0 = {str_0: str_0}
    int_0 = -1222
    float_0 = -157.14093
    bool_0 = False
    tuple_1 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = MovedModule(tuple_0, tuple_1)
    moved_module_1 = MovedModule(moved_module_0, tuple_1)
    moved_module_2 = MovedModule(moved_module_1, str_0)
    dict_1 = {str_0: str_0, str_0: str_0}
    six_moves_transformer_0 = Six

# Generated at 2022-06-25 22:38:58.429300
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 's9p*s|3aE,p'
    str_1 = 'Kjtae2_tDAG,`'
    str_2 = 'ZQ8K]LDM#}oDoA'
    str_3 = 'd`0k0|+1X&\x0c8}'
    str_4 = 'u+zUJ\x0c\x0cQ,a'
    str_5 = 'I{dq$`Y%z\x0c3?y'
    str_6 = 'Faj9VKV8W@\r'
    moved_attribute_0 = MovedAttribute(str_6, str_2, str_0, str_4, str_1)
    moved_attribute_1 = MovedAttribute(str_4, str_4)


# Generated at 2022-06-25 22:39:08.098296
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    str_0 = '>aq*r=8\x0c'
    str_1 = 'ozY:4kxj'
    str_2 = 'addclosehook'
    a_s_t_0 = None
    set_0 = {a_s_t_0, a_s_t_0, list_0, a_s_t_0}
    str_3 = '{c\t`tZiF*h3\x0c4k>'
    dict_0 = {str_3: str_0}
    int_0 = -1432
    float_0 = -814.44578
    bool_0 = True
    tuple_0 = (dict_0, int_0, float_0, bool_0)
    moved_module_0 = Moved

# Generated at 2022-06-25 22:39:13.218799
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # x is the class being tested in this unit test
    x = SixMovesTransformer(six.moves)
    assert hasattr(x, 'BaseImportRewrite')
    assert hasattr(x.BaseImportRewrite, 'dependencies')
    assert hasattr(x.BaseImportRewrite, 'rewrites')
    assert hasattr(x, 'target')
    assert hasattr(x, 'six')


# Generated at 2022-06-25 22:39:24.500745
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_1 = {'l': 861.945, 'i_': 'N&!Pf<\nLDz3'}
    moved_module_0 = MovedModule('W3a;,\\', dict_1)
    bool_0 = moved_module_0.__class__ is MovedModule
    assert bool_0 == True, "expected bool_0 is True but got {}".format(bool_0)
    assert moved_module_0.name is 'W3a;,\\', "expected moved_module_0.name is 'W3a;,\\\\' but got {}".format(moved_module_0.name)