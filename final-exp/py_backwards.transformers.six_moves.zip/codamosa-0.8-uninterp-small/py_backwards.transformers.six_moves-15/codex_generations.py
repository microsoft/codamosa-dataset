

# Generated at 2022-06-25 22:31:14.589841
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', '__builtin__') == MovedModule('name', '__builtin__', 'name')
    assert MovedModule('name', '__builtin__', '__builtin__') == MovedModule('name', '__builtin__', '__builtin__')


# Generated at 2022-06-25 22:31:18.871837
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print('Testing Constructor of class SixMovesTransformer')
    # Unit test for __init__ method of class SixMovesTransformer
    print('Testing Method __init__ of class SixMovesTransformer')
    test_SixMovesTransformer_inherits_BaseImportRewrite()


# Generated at 2022-06-25 22:31:26.708949
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    filepath = 'src/six_moves_transformer.py'
    source = read_file(filepath)
    tree = ast.parse(source)
    obj = SixMovesTransformer(tree, source, filepath)

# Generated at 2022-06-25 22:31:36.934824
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    list_0 = [bool_0]
    moved_module_0 = MovedModule(dict_0, list_0)
    moved_module_1 = MovedModule(dict_0, list_0)
    assert moved_module_0 == moved_module_1
    assert moved_module_0 != moved_module_1
    assert hash(moved_module_0) == hash(moved_module_1)
    assert not moved_module_0 == moved_module_1
    assert not hash(moved_module_0) == hash(moved_module_1)


# Generated at 2022-06-25 22:31:41.978231
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "name"
    old_mod = "old_mod"
    new_mod = "new_mod"
    old_attr = "old_attr"
    new_attr = "new_attr"
    _moved_attribute_0 = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)


# Generated at 2022-06-25 22:31:50.624490
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    list_0 = [bool_0]
    moved_module_0 = MovedModule(dict_0, list_0)
    moved_attribute_0 = MovedAttribute(dict_0, list_0, dict_0)
    list_1 = list([bool_0])
    moved_attribute_1 = MovedAttribute(list_1, list_0, list_1, None, None)
    list_2 = list([bool_0])

# Generated at 2022-06-25 22:31:55.070863
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    class_0 = SixMovesTransformer()
    int_0 = SixMovesTransformer.__init__(class_0)
    assert (int_0 == None), "six_transformer_test.py:50"


# Generated at 2022-06-25 22:32:07.773178
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # TypeError
    try:
        moved_attribute_0 = MovedAttribute()
    except TypeError:
        pass

    # TypeError
    try:
        moved_attribute_0 = MovedAttribute(1, 1, 1, 1, 1, 1)
    except TypeError:
        pass

    # TypeError
    try:
        moved_attribute_0 = MovedAttribute(1, 1, 1, 1, 1, 1)
    except TypeError:
        pass

    # TypeError
    try:
        moved_attribute_0 = MovedAttribute(1, 1, 1, 1, 1, 1)
    except TypeError:
        pass

    # TypeError
    try:
        moved_attribute_0 = MovedAttribute(1, 1, 1, 1, 1, 1)
    except TypeError:
        pass

   

# Generated at 2022-06-25 22:32:17.645688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Instance of class MovedAttribute representing a move
    one_move = MovedAttribute('CStringIO', 'cStringIO', 'io', 'StringIO')
    assert one_move.name == 'CStringIO'
    assert one_move.new_mod == 'io'
    assert one_move.new_attr == 'StringIO'
    # Instance of class MovedAttribute representing a rename
    one_rename = MovedAttribute('StringIO', 'StringIO', None)
    assert one_rename.new_mod == 'StringIO'
    assert one_rename.new_attr == 'StringIO'
    # Instance of class MovedAttribute representing a rename within the same module
    one_rename = MovedAttribute('izip', 'itertools', 'itertools', 'izip', 'zip')
    assert one_

# Generated at 2022-06-25 22:32:22.334399
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test with 'test_case_0'
    stdout_0 = sys.stdout

    from io import StringIO

    try:
        sys.stdout = StringIO()
        test_case_0()
    finally:
        sys.stdout = stdout_0


# Generated at 2022-06-25 22:32:28.755331
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c0 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert c0.name == "name"
    assert c0.new_mod == "new_mod"
    assert c0.new_attr == "new_attr"


# Generated at 2022-06-25 22:32:35.391603
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Constructor for class SixMovesTransformer
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:32:39.183709
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_1 = MovedModule("name", "old", "new")
    assert moved_module_1.name == "name"
    assert moved_module_1.old == "old"
    assert moved_module_1.new == "new"


# Generated at 2022-06-25 22:32:46.784069
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    arg0 = 'arg0'
    arg1 = 'arg1'
    arg2 = 'arg2'
    arg3 = 'arg3'
    arg4 = 'arg4'
    test_moved_attribute = MovedAttribute(arg0, arg1, arg2, arg3, arg4)
    assert test_moved_attribute.name == 'arg0'
    assert test_moved_attribute.new_mod == 'arg2'
    assert test_moved_attribute.new_attr == 'arg4'


# Generated at 2022-06-25 22:32:49.509022
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    cStringIO_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:33:04.477606
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "itertools"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "ifilter"
    assert MovedAttribute

# Generated at 2022-06-25 22:33:10.540430
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_moved_attribute.name == 'cStringIO'
    assert test_moved_attribute.old_mod == 'cStringIO'
    assert test_moved_attribute.new_mod == 'io'
    assert test_moved_attribute.old_attr == 'StringIO'


# Generated at 2022-06-25 22:33:19.230644
# Unit test for constructor of class MovedModule
def test_MovedModule():
    
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").old == "__builtin__"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__", "new_builtin").old == "__builtin__"
    assert MovedModule("builtins", "__builtin__", "new_builtin").new == "new_builtin"
    
    

# Generated at 2022-06-25 22:33:23.825759
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('builtins', '__builtin__', 'builtins')
    assert moved_module_0.name == 'builtins'
    assert moved_module_0.old == '__builtin__'
    assert moved_module_0.new == 'builtins'


# Generated at 2022-06-25 22:33:25.254616
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()


# Generated at 2022-06-25 22:33:35.682083
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("name", "old", "new")
    assert moved_module_0.name == "name"
    assert moved_module_0.old == "old"
    assert moved_module_0.new == "new"

    moved_module_1 = MovedModule("name1", "old1")
    assert moved_module_1.name == "name1"
    assert moved_module_1.old == "old1"
    assert moved_module_1.new == "name1"


# Generated at 2022-06-25 22:33:46.036448
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test 1: using 1 argument
    try:
        moved_attribute_1 = MovedAttribute('module')
    except Exception as e:
        raise RuntimeError('Constructor of MovedAttribute should be able to accept 1 argument (name)')
    # Test 2: using 3 arguments
    try:
        moved_attribute_2 = MovedAttribute('module', 'module', 'module')
    except Exception as e:
        raise RuntimeError('Constructor of MovedAttribute should be able to accept 3 arguments (name, old_mod, new_mod)')
    # Test 3: using a string for name
    try:
        moved_attribute_3 = MovedAttribute(2, 'module', 'module')
    except Exception as e:
        raise RuntimeError('Constructor of MovedAttribute should not throw exception when constructing with a string for name')
    # Test 4:

# Generated at 2022-06-25 22:33:50.021460
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(name = "cStringIO", old_mod = "cStringIO", new_mod = "io", old_attr = "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-25 22:33:53.174531
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule(name='b', old='c', new='d')
    assert a.name == 'b'
    assert a.new == 'd'
    b = MovedModule(name='e', old='f')
    assert b.name == 'e'
    assert b.new == 'e'


# Generated at 2022-06-25 22:33:55.756413
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("urllib_request", "urllib2", "urllib.request")


# Generated at 2022-06-25 22:33:56.785291
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()

# Generated at 2022-06-25 22:33:59.069245
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:34:05.224614
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Constructor of class MovedModule takes the parameters:
    # name, old, new
    moved_module = MovedModule(name="test_move", old="old_name", new="new_name")
    assert moved_module.name == "test_move"
    assert moved_module.old == "old_name"
    assert moved_module.new == "new_name"


# Generated at 2022-06-25 22:34:07.838871
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)



# Generated at 2022-06-25 22:34:10.820526
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.target == (2, 7)
    assert len(SixMovesTransformer.rewrites) == 107
    assert len(SixMovesTransformer.dependencies) == 1



# Generated at 2022-06-25 22:34:21.512290
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("abc", "abc", "abc")
    moved_attribute = MovedAttribute("abc", "abc", "abc", "abc", "abc")
    moved_attribute = MovedAttribute("abc", "abc", "abc", old_attr = "abc", new_attr = "abc")



# Generated at 2022-06-25 22:34:33.686296
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert _urllib_parse_moved_attributes[0].name == 'ParseResult'
    assert _urllib_parse_moved_attributes[0].old_mod == 'urlparse'
    assert _urllib_parse_moved_attributes[0].new_mod == 'urllib.parse'
    assert _urllib_parse_moved_attributes[0].old_attr == None
    assert _urllib_parse_moved_attributes[0].new_attr == 'ParseResult'

    assert _urllib_parse_moved_attributes[1].name == 'SplitResult'
    assert _urllib_parse_moved_attributes[1].old_mod == 'urlparse'
    assert _urllib_parse_moved_attributes[1].new_

# Generated at 2022-06-25 22:34:36.413935
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("configparser", "ConfigParser")
    assert module.name == "configparser"
    assert module.new == "configparser"
    assert module.old == "ConfigParser"

# Generated at 2022-06-25 22:34:40.921887
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("time", "timeModule", "time")
    assert moved_module.name == "time"
    assert moved_module.old == "timeModule"
    assert moved_module.new == "time"



# Generated at 2022-06-25 22:34:44.663134
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("queue", "Queue")
    if mod.name == "queue" and mod.new == "Queue":
        return True
    else:
        return False


# Generated at 2022-06-25 22:34:46.425321
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moved_attributes = MovedModule('builtins', '__builtin__')


# Generated at 2022-06-25 22:34:53.990251
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    assert issubclass(SixMovesTransformer, BaseImportRewrite) is True
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    assert six_moves_transformer_0.rewrites == _get_rewrites()
    assert six_moves_transformer_0.dependencies == ['six']



# Generated at 2022-06-25 22:34:58.385356
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"



# Generated at 2022-06-25 22:35:00.675023
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")


# Generated at 2022-06-25 22:35:03.994450
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.__init__("cStringIO", "cStringIO", "io", "StringIO") == None


# Generated at 2022-06-25 22:35:16.791446
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)


# Generated at 2022-06-25 22:35:26.770028
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, None)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)
    six_moves_transformer_0 = None
    moved_attribute_2 = MovedAttribute(str_1, moved_attribute_0, str_0, moved_attribute_1, six_moves_transformer_0)

# Generated at 2022-06-25 22:35:30.754968
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_2 = True
    a_s_t_1 = module_0.AST()
    moved_module_1 = MovedModule(bool_2, a_s_t_1)
    assert moved_module_1.name is bool_2
    assert moved_module_1.old is a_s_t_1


# Generated at 2022-06-25 22:35:33.133272
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule('', None)
    assert moved_module_0.name == ''
    assert moved_module_0.new == None


# Generated at 2022-06-25 22:35:44.036446
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = MovedModule()
    a_s_t_0 = MovedModule('h2s8s', a_s_t_0)
    str_0 = '#6Ue.q*'
    int_0 = 0
    bool_0 = (a_s_t_0 == a_s_t_0)
    bool_1 = (a_s_t_0 != a_s_t_0)
    moved_attribute_0 = MovedAttribute(str_0, a_s_t_0, int_0, bool_1, bool_0)
    str_1 = 'A,I+W'
    bool_2 = (str_0 > str_1)

# Generated at 2022-06-25 22:35:53.781009
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute(None, None, None, None, None)
    assert(moved_attribute_0.name == None)
    assert(moved_attribute_0.old_mod == None)
    assert(moved_attribute_0.new_mod == None)
    assert(moved_attribute_0.old_attr == None)
    assert(moved_attribute_0.new_attr == None)
    assert(moved_attribute_0.args == (None, None, None, None, None))
    assert(moved_attribute_0.kwargs == {})
    moved_attribute_1 = MovedAttribute(1, 2, 3, 4, 5)
    assert(moved_attribute_1.name == 1)
    assert(moved_attribute_1.old_mod == 2)


# Generated at 2022-06-25 22:36:02.357056
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)


# Generated at 2022-06-25 22:36:11.120382
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str_0 = 'ncy6 -UY'
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(str_0, a_s_t_0)
    bool_0 = True
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, bool_0, six_moves_transformer_0)
    str_1 = None
    bool_1 = True
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_1, moved_module_0, str_1)


# Generated at 2022-06-25 22:36:17.892556
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    int_0 = 5
    tuple_0 = (int_0, int_0, int_0)
    dict_0 = dict(list(tuple_0))
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(str_0, dict_0, six_moves_transformer_0)
    moved_attribute_1 = MovedAttribute(bool_0, moved_attribute_0, six_moves_transformer_0)


# Generated at 2022-06-25 22:36:25.126972
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = SixMovesTransformer(moved_module_0, str_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_0 = MovedAttribute(six_moves_transformer_0, bool_0, moved_module_0, str_1)
    bool_1 = False
    six_moves_transformer_1 = SixMovesTransformer(moved_attribute_0, bool_1)


# Generated at 2022-06-25 22:36:46.697180
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'Oi,G'
    six_moves_transformer_0 = SixMovesTransformer(str_0)
    moved_module_0 = MovedModule(six_moves_transformer_0, SixMovesTransformer)
    int_0 = 16708
    moved_attribute_0 = MovedAttribute(moved_module_0, int_0, moved_module_0)
    str_1 = 'f0'
    moved_attribute_1 = MovedAttribute(str_1, six_moves_transformer_0, moved_attribute_0)


# Generated at 2022-06-25 22:36:56.052082
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    arr_0 = [bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0]

# Generated at 2022-06-25 22:37:00.472867
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)


# Generated at 2022-06-25 22:37:04.738928
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    bool_0 = True
    dict_0 = dict()
    list_0 = []
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(bool_0, dict_0, list_0, a_s_t_0)
    return None


# Generated at 2022-06-25 22:37:09.719548
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = False
    module_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, module_0)
    module_1 = moved_module_0.new
    assert module_1 is None
    module_2 = moved_module_0.name
    assert module_2 is False
    

# Generated at 2022-06-25 22:37:11.457023
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(isinstance(MovedModule(None, None), MovedModule))


# Generated at 2022-06-25 22:37:17.144159
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test case 1
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    
    # Test case 2
    bool_0 = True
    a_s_t_0 = module_0.AST()
    str_0 = None
    moved_module_0 = MovedModule(bool_0, a_s_t_0, str_0)


# Generated at 2022-06-25 22:37:27.210817
# Unit test for constructor of class MovedModule
def test_MovedModule():
    string_0 = None
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(string_0, a_s_t_0)
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, six_moves_transformer_0)
    a_s_t_1 = module_0.AST()
    moved_module_1 = MovedModule(moved_attribute_0, a_s_t_0, a_s_t_1)
    moved_attribute_1 = MovedAttribute(moved_module_1)
    module_0.AST(moved_attribute_1)


# Generated at 2022-06-25 22:37:37.821924
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = ''
    assert MovedAttribute('', '', '', '', '')
    assert MovedAttribute('', '', '', '', '')
    assert MovedAttribute(str_0, '', '', '', '')
    assert MovedAttribute(str_0, '', '', '', '')
    assert MovedAttribute(str_0, str_0, '', '', '')
    assert MovedAttribute(str_0, str_0, '', '', '')
    assert MovedAttribute(str_0, str_0, str_0, '', '')
    assert MovedAttribute(str_0, str_0, str_0, '', '')
    assert MovedAttribute('', '', '', '', '')
    assert MovedAttribute('', '', '', '', '')

# Generated at 2022-06-25 22:37:39.128295
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert True # TODO: implement your test here



# Generated at 2022-06-25 22:38:12.919835
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    assert moved_module_0.name == bool_0
    assert moved_module_0.new is a_s_t_0

    str_0 = 'bv}zI/'
    a_s_t_1 = module_0.AST()
    moved_module_1 = MovedModule(str_0, a_s_t_1, str_0)
    assert moved_module_1.name == str_0
    assert moved_module_1.new == str_0



# Generated at 2022-06-25 22:38:15.237036
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)


# Generated at 2022-06-25 22:38:16.501275
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:38:19.784153
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # setup
    str_0 = 'UY'
    # test
    six_moves_transformer_0 = SixMovesTransformer(str_0)
    assert six_moves_transformer_0 is not None # none-type check


# Generated at 2022-06-25 22:38:28.952344
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'foobar'
    old_mod = 'baz'
    new_mod = 'quz'
    old_attr = 'fizzbuzz'
    new_attr = 'fizzbuzz'
    obj_MovedAttribute = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    get_name = obj_MovedAttribute.name
    assert get_name == 'foobar', "Expected: {}, Actual: {}".format('foobar', get_name)
    get_old_mod = obj_MovedAttribute.old_mod
    assert get_old_mod == 'baz', "Expected: {}, Actual: {}".format('baz', get_old_mod)
    get_new_mod = obj_MovedAttribute.new_mod
    assert get_new_

# Generated at 2022-06-25 22:38:38.645658
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'EJ q'
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(str_0, a_s_t_0)
    str_1 = '5 B5'
    moved_attribute_0 = MovedAttribute(moved_module_0, str_1, str_0)
    assert (moved_module_0.name == str_0)
    assert (moved_module_0.new == a_s_t_0)


# Generated at 2022-06-25 22:38:44
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    # TypeError raises when any of the arguments is not of the proper type.
    with raises(TypeError):
        SixMovesTransformer(target = 0)

    # TypeError raises when any of the arguments is not of the proper type.
    with raises(TypeError):
        SixMovesTransformer(rewrites = 0)

    # TypeError raises when any of the arguments is not of the proper type.
    with raises(TypeError):
        SixMovesTransformer(dependencies = 0)

# Generated at 2022-06-25 22:38:52.621522
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute_name = 'test'
    old_module_name = 'six'
    new_module_name = 'six.moves'
    old_attribute_name = 'test'
    new_attribute_name = 'test'
    # Testing when all attributes are provided
    try:
        ma = MovedAttribute(attribute_name, old_module_name, new_module_name, old_attribute_name,new_attribute_name)
    except Exception as e:
        print("TEST FAILED: Moved Attribute test case 0")
        print(e)

    # Testing when no parameters are provided
    try:
        ma = MovedAttribute()
    except Exception as e:
        print("TEST FAILED: Moved Attribute test case 1")
        print(e)

    # Testing when one parameter is provided

# Generated at 2022-06-25 22:38:53.379243
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer() is not None

# Generated at 2022-06-25 22:38:59.918059
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)



# Generated at 2022-06-25 22:39:55.776791
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass


# Generated at 2022-06-25 22:40:01.711712
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)


# Generated at 2022-06-25 22:40:06.317574
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    assert type(moved_module_0) == MovedModule


# Generated at 2022-06-25 22:40:14.682234
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)


# Generated at 2022-06-25 22:40:15.864368
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass


# Generated at 2022-06-25 22:40:16.901324
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(False, None)


# Generated at 2022-06-25 22:40:25.413774
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)


# Generated at 2022-06-25 22:40:31.617779
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)
    str_0 = None
    six_moves_transformer_0 = None
    moved_attribute_0 = MovedAttribute(moved_module_0, str_0, six_moves_transformer_0)
    str_1 = 'ncy6 -UY'
    moved_attribute_1 = MovedAttribute(moved_attribute_0, bool_0, moved_module_0, str_1)


# Generated at 2022-06-25 22:40:34.297366
# Unit test for constructor of class MovedModule
def test_MovedModule():
    bool_0 = True
    a_s_t_0 = module_0.AST()
    moved_module_0 = MovedModule(bool_0, a_s_t_0)


# Generated at 2022-06-25 22:40:38.356321
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    bool_0 = False
    str_1 = 'Qf=q'
    mo_typed_ast_mod_0 = typed_ast.ast3.Module
    moved_module_0 = MovedModule(bool_0, mo_typed_ast_mod_0)
    moved_attribute_0 = MovedAttribute(moved_module_0, str_1)
    assert isinstance(moved_attribute_0, MovedAttribute) == True
