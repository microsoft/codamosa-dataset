

# Generated at 2022-06-25 22:31:13.927119
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-25 22:31:18.543492
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for MovedModule(name, old, new=None)
    _moved_module_0 = MovedModule("Tkinter", "Tkinter")
    assert _moved_module_0.name == "Tkinter" 
    assert _moved_module_0.new == "Tkinter" 


# Generated at 2022-06-25 22:31:24.144807
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a_s_t_0 = module_0.AST(**{})
    a_s_t_1 = module_0.AST(**{})
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_1)

if __name__ == '__main__':
    test_case_0()
    test_MovedModule()

# Generated at 2022-06-25 22:31:29.798392
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import typed_ast._ast3 as module_0
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

if __name__ == '__main__':
    test_SixMovesTransformer()
    test_case_0()

# Generated at 2022-06-25 22:31:32.128164
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')


# Generated at 2022-06-25 22:31:36.088290
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:38.624174
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

import ast
import six


# Generated at 2022-06-25 22:31:40.445307
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule("builtins", "__builtin__")


# Generated at 2022-06-25 22:31:45.225292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)

if __name__ == "__main__":
    test_case_0()
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:31:47.930370
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)


if __name__ == '__main__':
    test_case_0()
    test_SixMovesTransformer()

# Generated at 2022-06-25 22:31:59.587178
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test case where SixMovesTransformer.rewrites is unbound

    # Test where no existing imports
    transformer_0 = SixMovesTransformer()
    str_0 = 'foo'
    with pytest.raises(NameError):
        transformer_0._import_alias(str_0)

    # Test 'Tkinter' module
    transformer_1 = SixMovesTransformer()
    str_1 = 'Tkinter'
    transformer_1.rewrites = {str_1: 'six'}
    str_2 = 'six.moves.Tkinter'
    assert transformer_1._import_alias(str_1) == str_2

    # Test 'robotparser' module
    transformer_2 = SixMovesTransformer()
    str_3 = 'robotparser'

# Generated at 2022-06-25 22:32:06.902243
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        from libcst.codemod.visitors import CSTTransformer
    except ImportError:
        from cst.codemod.visitors import CSTTransformer
    from cst.codemod.helpers import ImportVisitor

    visitor = ImportVisitor()
    assert issubclass(SixMovesTransformer, CSTTransformer)

# Generated at 2022-06-25 22:32:17.046348
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from __future__ import print_function
    from typing import Any, Optional
    from lib3to2.refactor import RefactoringTool, fixers
    from lib3to2.tests.support import TestRefactoringTool
    from lib3to2.fixes import fix_print
    import sys
    import six
    import unittest
    import six
    import lib3to2.tests.test_all_fixers
    import fix_six_moves
    import io
    import lib3to2.tests.support
    from libfuturize.fixer_util import touch_import_top
    from six import moves
    from six.moves import _urllib_error_moved_attributes
    from six.moves import _urllib_parse_moved_attributes
    from six.moves import _urll

# Generated at 2022-06-25 22:32:24.100244
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'Tkinter'
    str_1 = 'builtins'
    moved_module_0 = MovedModule(str_0, str_0)
    assert moved_module_0.name == str_0
    assert moved_module_0.new == str_0
    moved_module_1 = MovedModule(str_0, str_0, str_1)
    assert moved_module_1.name == str_0
    assert moved_module_1.new == str_1

# Generated at 2022-06-25 22:32:28.795214
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'Tkinter'
    moved_module_0 = MovedModule(str_0, str_0)
    assert moved_module_0.name is not None
    assert moved_module_0.old is not None
    assert moved_module_0.new is not None


# Generated at 2022-06-25 22:32:31.639863
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'StringIO'
    str_1 = 'io'
    str_2 = 'StringIO'
    moved_attribute_0 = MovedAttribute(str_0, str_1, str_2)


# Generated at 2022-06-25 22:32:36.113500
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'urllib'
    str_1 = 'urllib'
    str_2 = 'request'
    moved_attribute_0 = MovedAttribute(str_0, str_1, str_2, str_1)


# Generated at 2022-06-25 22:32:39.729841
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    str_0 = 'Tkinter'
    moved_attribute_0 = MovedAttribute(str_0, str_0, str_0)
    assert moved_attribute_0.new =="Tkinter"
    assert moved_attribute_0.name =="Tkinter"

# Generated at 2022-06-25 22:32:51.134758
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst.codemod import CodemodContext
    from libcst.matchers import Module
    from libcst.testing.utils import data_provider

    imports = [
        'from six.moves import urllib_parse, urllib_error',
        'from six.moves import urllib_request',
        'from six.moves import urllib_response',
        'from six.moves import urllib_robotparser',
    ]


# Generated at 2022-06-25 22:32:57.171015
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute_0 = MovedAttribute("xrange", "", "")
    str_0 = moved_attribute_0.name
    moved_attribute_0.name.__class__
    moved_attribute_0.old_mod.__class__
    moved_attribute_0.new_mod.__class__
    moved_attribute_0.old_attr.__class__
    moved_attribute_0.new_attr.__class__
    str_1 = moved_attribute_0.new_mod
    str_2 = moved_attribute_0.new_attr


# Generated at 2022-06-25 22:33:00.177558
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    instance = object.__new__(MovedAttribute)


# Generated at 2022-06-25 22:33:08.286626
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_3)


# Generated at 2022-06-25 22:33:20.151833
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert six_moves_transformer_0.root == a_s_t_0
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST(**dict_1)
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_2)
    assert six_moves_transformer_2.root == a_s_t_2


# Generated at 2022-06-25 22:33:31.740849
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    six_moves_transformer_2 = SixMovesTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_3)
    a_s_t_4 = module_0.AST()
    six_moves_transformer_4 = SixMovesTrans

# Generated at 2022-06-25 22:33:34.383825
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()
    # AssertionError: TypeError: not enough arguments for format string
    test_case_0()

# Generated at 2022-06-25 22:33:44.804625
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:33:50.809032
# Unit test for constructor of class MovedModule
def test_MovedModule(): 
    moved_module_0 = MovedModule(moved_attribute_3, moved_attribute_0)
    moved_module_1 = MovedModule(six_moves_transformer_0, six_moves_transformer_1)
    moved_module_2 = MovedModule(six_moves_transformer_2, six_moves_transformer_1)
    moved_module_3 = MovedModule(six_moves_transformer_2, six_moves_transformer_1, moved_attribute_0)


# Generated at 2022-06-25 22:34:01.447097
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:34:07.402107
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'D=9N/~^1)JQ'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_module_0 = MovedModule(six_moves_transformer_0, str_0)


# Generated at 2022-06-25 22:34:16.218853
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Assign
    dict_0 = None
    set_0 = set()
    list_0 = list()
    str_0 = 'jZ|C0Gi<$'
    tuple_0 = ()
    six_moves_transformer_0 = SixMovesTransformer(dict_0, None, set_0, list_0, str_0, tuple_0)
    # Assert
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    assert isinstance(six_moves_transformer_0.rewrites, list)
    assert isinstance(six_moves_transformer_0.rewrite_cache, dict)
    assert isinstance(six_moves_transformer_0.rewrites, list)

# Generated at 2022-06-25 22:34:31.486307
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert(MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO')
    assert(MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input').name == 'input')
    assert(MovedAttribute('intern', '__builtin__', 'sys').name == 'intern')
    assert(MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map').name == 'map')
    assert(MovedAttribute('getcwd', 'os', 'os', 'getcwdu', 'getcwd').name == 'getcwd')
    assert(MovedAttribute('getcwdb', 'os', 'os', 'getcwd', 'getcwdb').name == 'getcwdb')

# Generated at 2022-06-25 22:34:33.286952
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer_0 = SixMovesTransformer()

# Generated at 2022-06-25 22:34:45.044994
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Generate instances of mock class MovedModule
    moved_module_0 = MovedModule(int_0, six_moves_transformer_0)
    moved_module_1 = MovedModule(int_0, six_moves_transformer_1)
    moved_module_2 = MovedModule(int_0, six_moves_transformer_2)
    moved_module_3 = MovedModule(int_0, six_moves_transformer_0)
    moved_module_4 = MovedModule(int_0, six_moves_transformer_1)
    moved_module_5 = MovedModule(int_0, six_moves_transformer_2)
    moved_module_6 = MovedModule(int_0, six_moves_transformer_2)
    moved_module_

# Generated at 2022-06-25 22:34:56.165175
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    assert moved_attribute_0.name == dict_0
    assert moved_attribute_0.new_mod == str_0
    assert moved_attribute_0.old_mod == six_moves_transformer_0

    dict_1 = {}

# Generated at 2022-06-25 22:34:59.120145
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    # Verify the types
    assert isinstance(SixMovesTransformer.rewrites, property)
    assert callable(SixMovesTransformer.rewrites)


# Generated at 2022-06-25 22:35:09.993315
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:35:21.170236
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:35:29.302394
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for constructor with parameters
    list_0 = None
    int_0 = 305
    float_0 = -392.0
    dict_0 = None
    str_0 = 'G!R/!C<5Q5Y'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)

# Generated at 2022-06-25 22:35:39.757453
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_0 = 'L4{%3qjJxn|+pz'
    set_0 = {six_moves_transformer_0, dict_0}
    moved_attribute_0 = MovedAttribute(dict_0, six_moves_transformer_0, dict_0, str_0, set_0)
    assert(moved_attribute_0.name == dict_0)
    assert(moved_attribute_0.new_mod == six_moves_transformer_0)
    assert(moved_attribute_0.old_mod == dict_0)

# Generated at 2022-06-25 22:35:40.828460
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_case_0()


# Generated at 2022-06-25 22:35:51.892922
# Unit test for constructor of class MovedModule
def test_MovedModule():
    str_0 = 'eRc|a(Z$O{z~4/]ci'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_1 = 'Yp$[nUCZ*xC&P@9Xd'
    set_0 = {six_moves_transformer_0, str_1}
    moved_module_0 = MovedModule(six_moves_transformer_0, str_0, set_0)
    int_0 = 2
    float_0 = 0.68
    moved_module_1 = MovedModule(int_0, moved_module_0, float_0)

# Generated at 2022-06-25 22:36:02.311683
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = None
    int_0 = 384
    float_0 = -1402.0
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:36:04.163853
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.raises(TypeError):
        SixMovesTransformer()


# Generated at 2022-06-25 22:36:14.448597
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_1 = None
    int_1 = 384
    float_1 = -1402.0
    dict_2 = None
    str_3 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_3 = module_0.AST()
    six_moves_transformer_3 = SixMovesTransformer(a_s_t_3)
    moved_attribute_4 = MovedAttribute(dict_2, str_3, six_moves_transformer_3)
    dict_3 = {}
    a_s_t_4 = module_0.AST(**dict_3)
    six_moves_transformer_4 = SixMovesTransformer(a_s_t_4)
    str_4 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:36:22.858518
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:36:24.954386
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        SixMovesTransformer(None, None)
        assert False
    except TypeError as e:
        pass


# Generated at 2022-06-25 22:36:28.590568
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)


# Generated at 2022-06-25 22:36:38.810807
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test 1: Calling constructor of class MovedAttribute with parameter value None
    # Assertion error raised as the constructor parameter cannot be None.
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    assert moved_attribute_0.name == dict_0

    # Test 2: Calling constructor of class MovedAttribute with parameter value of type dict
    dict_1 = {}
    a

# Generated at 2022-06-25 22:36:46.832707
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test whether TypeError is raised when there are too many arguments
    try:
        assert False
    except TypeError as e:
        pass
    # Test whether TypeError is raised when there are too few arguments
    try:
        assert False
    except TypeError as e:
        pass
    # Test whether the constructed object is an instance of SixMovesTransformer
    assert isinstance(SixMovesTransformer(), SixMovesTransformer)
    # Test whether the constructed object is an instance of BaseImportRewrite
    assert isinstance(SixMovesTransformer(), BaseImportRewrite)


# Generated at 2022-06-25 22:36:53.409268
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(list_0, moved_attribute_2, list_0)
    moved_module_1 = MovedModule(list_0, list_0)
    moved_module_2 = MovedModule(list_0, moved_module_0)
    moved_module_3 = MovedModule(list_0, moved_attribute_3)
    moved_module_4 = MovedModule(moved_module_2, list_0)
    moved_module_5 = MovedModule(moved_module_2, moved_attribute_3)

# Generated at 2022-06-25 22:37:15.101527
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:37:18.903241
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    
    # Test with python AST
    module_ast = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(module_ast)
    assert isinstance(six_moves_transformer_0, SixMovesTransformer)
    
    # Test with typed python AST
    
    pass

# Generated at 2022-06-25 22:37:30.072912
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    # Call the constructor
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)

# Generated at 2022-06-25 22:37:31.889661
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Input parameters
    moved_attribute_0 = MovedAttribute(None, None, None)


# Generated at 2022-06-25 22:37:37.180999
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    str_0 = 'qOz\\D'
    moved_module_0 = MovedModule(str_0, dict_0)
    dict_1 = {}
    int_0 = -865
    moved_module_1 = MovedModule(None, dict_1, int_0)


# Generated at 2022-06-25 22:37:40.287271
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_0.MovedModule(384, -1402.0, -1402.0)
    module_0.MovedModule(384, -1402.0)
    module_0.MovedModule(384)


# Generated at 2022-06-25 22:37:49.450650
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    str_0 = '*/jfGW:`Xr"~bd'
    float_0 = -1371.4
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    moved_module_0 = MovedModule(six_moves_transformer_0, float_0, moved_attribute_0)
    moved_module_1 = MovedModule(six_moves_transformer_0, float_0)

if __name__ == '__main__':
    test_case_0()
    test_MovedModule()


# Generated at 2022-06-25 22:37:58.527394
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:38:05.107251
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    str_0 = '&6gC#=v2H6;4|'
    list_0 = None
    moved_attribute_0 = MovedAttribute(dict_0, six_moves_transformer_0, list_0, str_0)


# Generated at 2022-06-25 22:38:06.901682
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Type error
    with pytest.raises(TypeError):
        MovedModule(name=None)



# Generated at 2022-06-25 22:38:45.076047
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:38:53.494190
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = None
    str_0 = 'yI8\\p,#Yq'
    six_moves_transformer_0 = SixMovesTransformer(dict_0)
    six_moves_transformer_1 = SixMovesTransformer(str_0)
    str_1 = 'l,Q"*~>o0GK|r1'
    dict_1 = {}
    int_0 = -493
    moved_module_0 = MovedModule(dict_1, six_moves_transformer_1, int_0)
    moved_module_1 = MovedModule(six_moves_transformer_0, dict_1)
    moved_module_2 = MovedModule(six_moves_transformer_0, str_0, dict_1)
    moved_module_3 = M

# Generated at 2022-06-25 22:38:56.828823
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_0 = MovedModule(dict_0, six_moves_transformer_0, moved_attribute_3)
    moved_module_1 = MovedModule(dict_0, moved_module_0, six_moves_transformer_2)


# Generated at 2022-06-25 22:39:03.783386
# Unit test for constructor of class MovedModule
def test_MovedModule():
    list_0 = None
    dict_0 = None
    str_0 = 'Z:^6U(W*[8TQ_!&f'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:39:13.491542
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:39:23.321010
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        a_s_t_0 = module_0.AST()
        six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
        assert(six_moves_transformer_0.a_s_t == a_s_t_0)
        assert(six_moves_transformer_0.dependencies == ['six'])
        assert(six_moves_transformer_0.rewrites is not None)
        assert(six_moves_transformer_0.target == (2, 7))
    except:
        print('Exception in constructor of class SixMovesTransformer')


# Generated at 2022-06-25 22:39:24.360708
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    pass


# Generated at 2022-06-25 22:39:25.363821
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass




# Generated at 2022-06-25 22:39:33.071072
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:39:43.599517
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:40:51.466523
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    list_0 = None
    int_0 = 384
    float_0 = -1402.0
    dict_0 = None
    str_0 = 'R`-S2NCT:\\ho"-Z'
    a_s_t_0 = module_0.AST()
    six_moves_transformer_0 = SixMovesTransformer(a_s_t_0)
    moved_attribute_0 = MovedAttribute(dict_0, str_0, six_moves_transformer_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    six_moves_transformer_1 = SixMovesTransformer(a_s_t_1)
    str_1 = '+rfP0o|.RRq+B~aX('

# Generated at 2022-06-25 22:40:53.987084
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert issubclass(MovedModule, MetaMovedAttribute) == False
    assert issubclass(MovedModule, MovedAttribute) == False
    assert issubclass(MovedModule, object) == True


# Generated at 2022-06-25 22:41:02.737161
# Unit test for constructor of class MovedModule
def test_MovedModule():
    dict_0 = {}
    float_0 = -1562.0
    six_moves_transformer_0 = SixMovesTransformer(dict_0)
    moved_module_0 = MovedModule(float_0, dict_0, six_moves_transformer_0)
    dict_1 = {}
    moved_module_1 = MovedModule('+rfP0o|.RRq+B~aX(', moved_module_0, dict_1)
    moved_module_2 = MovedModule(dict_0, dict_1, moved_module_1)
    six_moves_transformer_1 = SixMovesTransformer(moved_module_0)
    moved_module_3 = MovedModule('', dict_1, six_moves_transformer_1)
    dict_2 = {}

# Generated at 2022-06-25 22:41:04.789384
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Constructor call
    six_moves_transformer_0 = SixMovesTransformer(module_0.AST())
