

# Generated at 2022-06-12 03:50:50.613778
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Get a SixMovesTransformer object
    obj = SixMovesTransformer()
    # test the move attributes
    assert obj.rewrites

# Generated at 2022-06-12 03:51:01.255404
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from importlib import import_module
    from lib2to3.fixes import FixerTestCase
    from libmodernize.fixes.fix_six_moves import SixMovesTransformer

    class FixSixMovesTestCase(FixerTestCase):
        fixer = "six_moves"
        fixer_options = {}

    context = FixSixMovesTestCase('test_six_moves')
    fix = SixMovesTransformer(context)
    assert isinstance(fix._old_imports, dict)
    assert '_urllib' in fix._old_imports
    assert 'urllib' in fix._old_imports['_urllib']
    import_module('libmodernize.moves.urllib')
    assert isinstance(fix._new_imports, dict)

# Generated at 2022-06-12 03:51:03.004055
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())

# Generated at 2022-06-12 03:51:09.251457
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule(name='test', old='test', new='test_new')
    assert mm.name == 'test'
    assert mm.old == mm.new
    assert mm.old == 'test'
    assert mm.new == 'test_new'

    mm2 = MovedModule('test2', 'test2')
    assert mm2.name == 'test2'
    assert mm2.old == mm2.new
    assert mm2.old == 'test2'
    assert mm2.new is None

# Generated at 2022-06-12 03:51:20.880749
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("foo", "mod1", "mod2", "bar", "baz")
    if item.name != "foo":
        raise Exception("item.name")
    if item.new_mod != "mod2":
        raise Exception("item.new_mod")
    if item.new_attr != "baz":
        raise Exception("item.new_attr")

    item = MovedAttribute("foo", "mod1", "mod2")
    if item.name != "foo":
        raise Exception("item.name")
    if item.new_mod != "mod2":
        raise Exception("item.new_mod")
    if item.new_attr != "foo":
        raise Exception("item.new_attr")

    item = MovedAttribute("foo", "mod1", "mod2", "bar")

# Generated at 2022-06-12 03:51:25.264470
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "cStringIO"



# Generated at 2022-06-12 03:51:29.194230
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

# Generated at 2022-06-12 03:51:35.979455
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("my_name", "my_old_mod", "my_new_mod")
    assert moved.name == "my_name"
    assert moved.new_mod == "my_new_mod"
    assert moved.new_attr == "my_name"
    moved = MovedAttribute("my_name", "my_old_mod", "my_new_mod", "old_attr", "new_attr")
    assert moved.new_attr == "new_attr"


# Generated at 2022-06-12 03:51:40.153846
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.new == 'builtins'
    moved_module = MovedModule('configparser', 'ConfigParser')
    assert moved_module.name == 'configparser'
    assert moved_module.new == 'configparser'


# Generated at 2022-06-12 03:51:43.834149
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("tkinter", "Tkinter", "tkinter")
    assert m.name == "tkinter"
    assert m.new == "tkinter"

# Generated at 2022-06-12 03:51:48.821634
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-12 03:51:58.345582
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseTransformer
    from .base import BaseImportRewrite

    assert issubclass(SixMovesTransformer, BaseTransformer)
    assert issubclass(SixMovesTransformer, BaseImportRewrite)


# Generated at 2022-06-12 03:52:02.096729
# Unit test for constructor of class MovedModule
def test_MovedModule():
  assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
  assert MovedModule('name', 'old') == MovedModule('name', 'old')
  assert MovedModule('name') == MovedModule('name')
  assert MovedModule('name1') != MovedModule('name2')

# Generated at 2022-06-12 03:52:12.977317
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        MovedAttribute(name = 'a', old_mod = 'b', new_mod = 'c')
        assert False
    except TypeError:
        assert True
    assert MovedAttribute(name = 'a', old_mod = 'b', new_mod = 'c', old_attr = 'd', new_attr = 'e').__dict__ == \
           {'name': 'a', 'new_mod': 'c', 'new_attr': 'e'}
    assert MovedAttribute(name = 'a', old_mod = 'b', new_mod = 'c', old_attr = 'd').__dict__ == \
           {'name': 'a', 'new_mod': 'c', 'new_attr': 'd'}

# Generated at 2022-06-12 03:52:14.187333
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('test', 'test', 'test_new')
    assert mod.name == 'test'
    assert mod.new == 'test_new'



# Generated at 2022-06-12 03:52:17.066859
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"
    assert m.old == "old"

# Generated at 2022-06-12 03:52:19.795419
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('foo', 'bar')
    assert a.name == 'foo'
    assert a.new == 'bar'



# Generated at 2022-06-12 03:52:32.707292
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'

    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'name'
    assert moved_attribute.new_attr == 'name'

    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'

# Generated at 2022-06-12 03:52:34.164415
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('a', 'b')

# Generated at 2022-06-12 03:52:43.856818
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst import parse_module
    from libcst.matchers import ImportFrom, ImportName, Name
    transformer = SixMovesTransformer()
    test_module = parse_module("""
    from six.moves import filter, map
    from xmlrpc.client import Fault
    from xmlrpc.server import SimpleXMLRPCServer
    from six.moves.urllib.parse import quote
    import six.moves.urllib.request
    import six.moves.urllib.parse
    """)
    new_module = transformer.visit_Module(test_module)

    matcher = ImportFrom(
        module=Name('builtins'),
        names=[
            ImportName(name=Name('filter')),
            ImportName(name=Name('map'))
        ]
    )

# Generated at 2022-06-12 03:52:50.391358
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert str(SixMovesTransformer) == "<import_rewrites.sixmoves.SixMovesTransformer>"
    # This test is pretty lame, but there is no other way to test it.
    # To test this constructor requires that class SixMovesTransformer is imported.


# Generated at 2022-06-12 03:52:53.234078
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('x', 'y')
    assert x.name == 'y'
    assert x.new == 'x'
    y = MovedModule('x', 'y', 'z')
    assert y.name == 'y'
    assert y.new == 'z'

# Generated at 2022-06-12 03:53:06.078629
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libmodernize.main import parse
    from libmodernize.fixes.fix_imports import FixImports
    t = parse("""
        from six.moves import cStringIO
        from six.moves import UserDict
        from six import PY3
        from six.moves.urllib.parse import urlparse
        from six.moves.urllib import request
        import os
        import sys
        import tempfile
        import warnings
        """)
    six_moves_transformer = SixMovesTransformer(t, [])

# Generated at 2022-06-12 03:53:09.457911
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    e = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert e.name == "cStringIO"
    assert e.new_mod == "io"
    assert e.old_attr == "StringIO"
    assert e.new_attr == "StringIO"


# Generated at 2022-06-12 03:53:17.500717
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test1 = MovedModule('my_module', 'my_old_module', 'my_new_module')
    test2 = MovedModule('my_module', 'my_old_module')

    assert test1.new == 'my_new_module'
    assert test1.name == 'my_module'
    assert test1.old == 'my_old_module'

    assert test2.new == 'my_module'
    assert test2.name == 'my_module'
    assert test2.old == 'my_old_module'


# Generated at 2022-06-12 03:53:29.284501
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "cStringIO"
    #
    a = MovedAttribute(name="cStringIO", old_mod="cStringIO", new_mod="io", old_attr="StringIO", new_attr="StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"
    #
    a = MovedAttribute(name="filter",  old_mod="itertools", new_mod="builtins", old_attr="ifilter", new_attr="filter")

# Generated at 2022-06-12 03:53:40.529106
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_transformer_registry import mock_module_path

    def check_rewrites(transformer, six_modpath):
        with mock_module_path(six_modpath):
            rewrites = transformer.rewrites()
            assert len(rewrites) == len(transformer.constructor_rewrites)
            for r in rewrites:
                assert r[-1].startswith('six.moves')
        transformer.rewrites = None
        rewrites = transformer.rewrites()
        assert len(rewrites) == len(transformer.constructor_rewrites)
        for r in rewrites:
            assert r[-1].startswith('six.moves')


# Generated at 2022-06-12 03:53:45.514619
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert repr(MovedModule("name", "old")) == \
        "MovedModule(name='name', old='old', new='name')"
    assert repr(MovedModule("name", "old", "new")) == \
        "MovedModule(name='name', old='old', new='new')"


# Generated at 2022-06-12 03:53:52.438951
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"

    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "old"

# Generated at 2022-06-12 03:53:58.121030
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.new_attr == "StringIO"
    assert m.new_mod == "io"
    m2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m2.new_attr == "cStringIO"


# Generated at 2022-06-12 03:54:05.398904
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"

# Generated at 2022-06-12 03:54:15.364643
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__') == MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__', 'builtins') == MovedModule('builtins', '__builtin__', 'builtins')
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__', 'builtins').name == 'builtins'
    assert MovedModule('builtins', '__builtin__', 'builtins').old == '__builtin__'

# Generated at 2022-06-12 03:54:27.447752
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys

    assert sys.modules['six.moves'] is six.moves
    assert sys.modules['six.moves.urllib.parse'] is six.moves.urllib.parse
    assert sys.modules['six.moves.urllib.error'] is six.moves.urllib.error
    assert sys.modules['six.moves.urllib.request'] is six.moves.urllib.request
    assert sys.modules['six.moves.urllib.response'] is six.moves.urllib.response
    assert sys.modules['six.moves.urllib.robotparser'] is six.moves.urllib.robotparser
    assert 'six.moves.urllib_parse' not in sys.modules

# Generated at 2022-06-12 03:54:31.860397
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("builtins", "__builtin__")
    assert m.name == 'builtins'
    assert m.new == 'builtins'
    assert m.old == '__builtin__'

# Generated at 2022-06-12 03:54:38.591306
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tfm = SixMovesTransformer()
    assert len(tfm.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)

# Generated at 2022-06-12 03:54:43.745268
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    print("MovedAttribute")
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"


# Generated at 2022-06-12 03:54:49.212259
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "oldname").name == "name"
    assert MovedModule("name", "oldname").new == "name"
    assert MovedModule("name", "oldname", "newname").name == "name"
    assert MovedModule("name", "oldname", "newname").new == "newname"


# Generated at 2022-06-12 03:54:51.128029
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) == 49

# Generated at 2022-06-12 03:54:55.556583
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule('b', 'a')
    assert m1.name == 'b'
    assert m1.old == 'a'
    assert m1.new == 'b'

    m2 = MovedModule('b', 'a', 'c')
    assert m2.name == 'b'
    assert m2.old == 'a'
    assert m2.new == 'c'

# Generated at 2022-06-12 03:55:01.543383
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    module = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert module.name == 'cStringIO'
    assert module.new_mod == 'io'
    assert module.new_attr == 'StringIO'

    module2 = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert module2.name == 'filter'
    assert module2.new_mod == 'builtins'
    assert module2.new_attr == 'filter'



# Generated at 2022-06-12 03:55:12.115479
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"


# Generated at 2022-06-12 03:55:14.051816
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer._get_rewrites()


# Generated at 2022-06-12 03:55:17.295627
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_mod = MovedModule("name", "old", "new")
    assert moved_mod.name == "name"
    assert moved_mod.new == "new"
    assert moved_mod.old == "old"

# Generated at 2022-06-12 03:55:19.008037
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves = SixMovesTransformer()
    six_moves()

# Generated at 2022-06-12 03:55:21.844849
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("queue", "Queue")
    assert mm.name == "queue"
    assert mm.new == "queue"
    assert mm.old == "Queue"

# Generated at 2022-06-12 03:55:25.514816
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    bt = SixMovesTransformer(['six'])
    # Check that the initializer was able to add the rewrites
    assert len(bt.rewrites) == len(_get_rewrites())

# Generated at 2022-06-12 03:55:26.820740
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites()) == list(SixMovesTransformer.rewrites)

# Generated at 2022-06-12 03:55:29.648422
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('package.module1','package.module2','package.module3')
    assert move.name == 'package.module1'
    assert move.old == 'package.module2'
    assert move.new == 'package.module3'

# Generated at 2022-06-12 03:55:33.494552
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('x', 'y', 'z')
    MovedAttribute('x', 'y', 'z', 'a', 'b')
    MovedAttribute('x', 'y', 'z', 'a')
    MovedAttribute('x', 'y', 'z', new_attr='b')

# Generated at 2022-06-12 03:55:38.210756
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'cStringIO'



# Generated at 2022-06-12 03:55:53.447840
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_mod = MovedModule("http_client", "httplib", "http.client")
    assert test_mod.name == "http_client"
    assert test_mod.new == "http.client"


# Generated at 2022-06-12 03:55:57.470385
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.old == 'old'
    assert moved_module.new == 'new'

# Generated at 2022-06-12 03:56:00.016783
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer.__new__(SixMovesTransformer)
    assert x.target == (2, 7)
    assert len(x.rewrites) == 66

# Generated at 2022-06-12 03:56:08.013646
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-12 03:56:08.965382
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer is not None


# Generated at 2022-06-12 03:56:11.299280
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"


# Generated at 2022-06-12 03:56:17.956664
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == \
            MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io') == \
            MovedAttribute('cStringIO', 'cStringIO', 'io', 'cStringIO')
    a = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    b = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert a == b
    assert a != 'foo'
    assert a != MovedAttribute('cStringIO', 'cStringIO', 'io')

# Generated at 2022-06-12 03:56:19.338364
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    p = SixMovesTransformer()
    assert len(p.rewrites) == 82

# Generated at 2022-06-12 03:56:23.346594
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    expected_rewrites = list(_get_rewrites())
    assert len(expected_rewrites) == len(SixMovesTransformer.rewrites)

    expected_rewrites.sort()
    SixMovesTransformer.rewrites.sort()
    assert expected_rewrites == SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:56:32.262610
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-12 03:57:06.839594
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("attr_name", "old_module", "new_module")
    assert attr.name == "attr_name"
    assert attr.new_mod == "new_module"
    assert attr.new_attr == "attr_name"

    attr = MovedAttribute("attr_name", "old_module", "new_module", "old_attr_name")
    assert attr.name == "attr_name"
    assert attr.new_mod == "new_module"
    assert attr.new_attr == "old_attr_name"

    attr = MovedAttribute("attr_name", "old_module", "new_module", "old_attr_name", "new_attr_name")
    assert attr.name == "attr_name"
    assert attr.new_mod

# Generated at 2022-06-12 03:57:11.133215
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old") == MovedModule("name", "old")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old")


# Generated at 2022-06-12 03:57:13.495047
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    with pytest.raises(TypeError):
        MovedModule("Name")
    MovedModule("Name", "Old")
    MovedModule("Name", "Old", "New")


# Generated at 2022-06-12 03:57:16.978479
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule('name', 'old')
    assert m1.name == 'name'
    assert m1.old == 'old'
    assert m1.new == 'name'

    m2 = MovedModule('name', 'old','new')
    assert m2.name == 'name'
    assert m2.old == 'old'
    assert m2.ne

# Generated at 2022-06-12 03:57:19.888666
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("shlex_quote", "pipes", "shlex", "quote")
    assert move.name == "shlex_quote"
    assert move.old == "pipes"
    assert move.new == "shlex"


# Generated at 2022-06-12 03:57:29.079937
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo", "bar", "baz", "qux", "quux").name == "foo"
    assert MovedAttribute("foo", "bar", "baz", "qux", "quux").new_mod == "baz"
    assert MovedAttribute("foo", "bar", "baz", "qux", "quux").new_attr == "quux"
    assert MovedAttribute("foo", "bar", "baz").name == "foo"
    assert MovedAttribute("foo", "bar", "baz").new_mod == "baz"
    assert MovedAttribute("foo", "bar", "baz").new_attr == "foo"
    assert MovedAttribute("foo", "bar", "baz", "qux").name == "foo"

# Generated at 2022-06-12 03:57:37.862231
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # No-op when there are no six imports
    test_data = ['import datetime']
    transpiler = SixMovesTransformer()
    assert transpiler.transform(test_data) == test_data

    # Test that replacements happen
    test_data = ['import six',
                 'import six.moves.urllib.request',
                 'a = six.moves.urllib.request.quote_plus']
    transpiler = SixMovesTransformer()
    assert transpiler.transform(test_data) == ['import six',
                                               'import six.moves.urllib.request',
                                               'a = urllib.parse.quote_plus']

# Generated at 2022-06-12 03:57:40.468556
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import MovedModule
    assert MovedModule.name == 'name'
    assert MovedModule.old == 'old'
    assert MovedModule.new == 'old'

# Generated at 2022-06-12 03:57:41.489552
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()


# Generated at 2022-06-12 03:57:43.035592
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        import six
    except ImportError:
        return

    SixMovesTransformer()

# Generated at 2022-06-12 03:58:45.875757
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    """Test method `SixMovesTransformer`."""
    SixMovesTransformer()

# Generated at 2022-06-12 03:58:49.100991
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("ParseResult", "urlparse", "urllib.parse")
    assert move.name == "ParseResult"
    assert move.new_mod == "urllib.parse"
    assert move.new_attr == "ParseResult"


# Generated at 2022-06-12 03:58:52.864574
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

    # check each rewrite
    for (x, y) in _get_rewrites():
        assert transformer.rewrites[x] == y

    # check dependencies
    assert transformer.dependencies == ['six']


if __name__ == '__main__':
    SixMovesTransformer().main()

# Generated at 2022-06-12 03:59:00.881485
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__") == MovedModule("builtins", "__builtin__")
    assert MovedModule("configparser", "ConfigParser") == MovedModule("configparser", "ConfigParser")
    assert MovedModule("copyreg", "copy_reg") == MovedModule("copyreg", "copy_reg")
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu") == MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert MovedModule("http_cookiejar", "cookielib", "http.cookiejar") == MovedModule("http_cookiejar", "cookielib", "http.cookiejar")

# Generated at 2022-06-12 03:59:02.957861
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('old', 'new')
    assert mod.name == 'old'
    assert mod.new == 'new'

# Generated at 2022-06-12 03:59:13.757967
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    move2 = MovedAttribute("cStringIO", "cStringIO", "io")
    move3 = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO")
    move4 = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO")
    move5 = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="StringIO")
    assert move.name == move2.name == move3.name == move4.name == move5.name == 'cStringIO'
    assert move.new_mod == move2.new_mod == move3.new_mod == move4.new_mod == move5

# Generated at 2022-06-12 03:59:15.692748
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None).rewrites is _get_rewrites.func()
    assert SixMovesTransformer(None).dependencies == ['six']

# Generated at 2022-06-12 03:59:24.455349
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()
    assert x.target == (2, 7)

# Generated at 2022-06-12 03:59:28.148603
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mo = MovedAttribute("test", "old", "new", "old_attr", "new_attr")
    assert mo.name == "test"
    assert mo.new_mod == "new"
    assert mo.new_attr == "new_attr"


# Generated at 2022-06-12 03:59:30.556102
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(
        MovedModule(
            'builtins',
            '__builtin__',
            'builtins').new,
        str)