

# Generated at 2022-06-12 03:50:46.643404
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr', new_attr='new_attr')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'

# Generated at 2022-06-12 03:50:49.651953
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'name'
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'



# Generated at 2022-06-12 03:50:59.261124
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer, type)
    assert hasattr(SixMovesTransformer, 'target')
    assert hasattr(SixMovesTransformer, 'rewrites')
    assert hasattr(SixMovesTransformer, 'dependencies')
    assert isinstance(SixMovesTransformer.target, tuple)
    assert SixMovesTransformer.target == (2, 7)
    assert isinstance(SixMovesTransformer.rewrites, tuple)
    assert len(SixMovesTransformer.rewrites) == 43
    assert all('six.moves' in r for r in SixMovesTransformer.rewrites)
    assert isinstance(SixMovesTransformer.dependencies, list)
    assert all(isinstance(d, str) for d in SixMovesTransformer.dependencies)

# Generated at 2022-06-12 03:51:03.918969
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c = MovedAttribute("cStringIO", "cStringIO", "six")
    assert c.name == "cStringIO"
    assert c.new_mod == "six"
    assert c.new_attr == "cStringIO"

# Generated at 2022-06-12 03:51:11.885064
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').old_mod == 'old_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod').old_attr == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod', None).name == 'name'
    assert MovedAttribute('name', 'old_mod', None).old_mod == 'old_mod'

# Generated at 2022-06-12 03:51:14.929106
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert_equal(SixMovesTransformer.rewrites, _get_rewrites())
    assert_equal(SixMovesTransformer.target, (2, 7))


# Generated at 2022-06-12 03:51:27.354771
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    imports = {
        'django.conf.settings.configure': ['django.conf'],
        'django.core.management.get_commands': ['django.core.management'],
        'django.core.management.execute_manager': ['django.core.management'],
        'django.core.management.execute_from_command_line': ['django.core.management'],
        'django.core.management.setup_environ': ['django.core.management'],
        'django.core.management.validate': ['django.core.management'],
        'six.moves': [],
    }

# Generated at 2022-06-12 03:51:29.998488
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert ('__builtin__.sqlite3', 'six.moves.sqlite3') in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:51:31.102362
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 66

# Generated at 2022-06-12 03:51:34.312187
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    for single_rewrite in rewrites:
        path = single_rewrite[0]
        replacement = single_rewrite[1]
        assert path == replacement[8:]

# Generated at 2022-06-12 03:51:39.614923
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    len_rewrites = len(rewrites)
    assert len_rewrites == 149, 'it should have 149 rewriting rules'
    assert type(rewrites) is list, 'it should be list of tuples'
    assert type(rewrites[0]) is tuple, 'it should be list of tuples'
    assert len(rewrites[0]) == 2, 'it should be list of 2-tuples'

# Generated at 2022-06-12 03:51:46.173507
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('foo', 'bar', 'baz').name == 'foo'
    assert MovedAttribute('foo', 'bar', 'baz').new_mod == 'baz'
    assert MovedAttribute('foo', 'bar', 'baz').new_attr == 'foo'
    assert MovedAttribute('foo', 'bar', 'baz', 'thing', 'stuff').new_attr == 'stuff'

# Generated at 2022-06-12 03:51:47.834091
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 42

# Generated at 2022-06-12 03:51:57.635121
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:52:00.491858
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_test = MovedModule("test_module","test_module")
    assert moved_module_test.name == "test_module"
    assert moved_module_test.new == "test_module"


# Generated at 2022-06-12 03:52:07.708414
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module = MovedModule("tkinter", "Tkinter")
    assert move_module.name == "tkinter"
    assert move_module.new == "tkinter"

    move_module = MovedModule("tkinter", "Tkinter", "tkinter")
    assert move_module.name == "tkinter"
    assert move_module.new == "tkinter"

    move_module = MovedModule("tkinter", "Tkinter", "tk")
    assert move_module.name == "tkinter"
    assert move_module.new == "tk"



# Generated at 2022-06-12 03:52:08.778273
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _get_rewrites()

# Generated at 2022-06-12 03:52:12.456338
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-12 03:52:13.201378
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass

# Generated at 2022-06-12 03:52:14.590086
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer

# Generated at 2022-06-12 03:52:22.365868
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'



# Generated at 2022-06-12 03:52:34.222705
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys, os
    import subprocess

    # Run Vulture and test output
    my_env = os.environ.copy()
    my_env["PATH"] = "/usr/local/bin:" + my_env["PATH"]

    # print(os.environ["PATH"])
    output = subprocess.check_output(['vulture', 'six_moves.py'], env=my_env)
    assert 'six_moves.py' in str(output)
    assert 'xxx' in str(output)
    assert 'six.moves' in str(output)
    assert not ('MovedAttribute' in str(output) and
        'os' in str(output) and 'urllib' in str(output))

# Generated at 2022-06-12 03:52:43.951003
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ob = MovedAttribute('a','b','c', 'd', 'e')
    assert ob.name == 'a'
    assert ob.new_mod == 'c'
    assert ob.new_attr == 'e'

    ob = MovedAttribute('a','b',None, 'd', 'e')
    assert ob.name == 'a'
    assert ob.new_mod == 'a'
    assert ob.new_attr == 'e'

    ob = MovedAttribute('a','b','c', 'd', None)
    assert ob.name == 'a'
    assert ob.new_mod == 'c'
    assert ob.new_attr == 'd'

    ob = MovedAttribute('a','b','c', None, None)
    assert ob.name == 'a'

# Generated at 2022-06-12 03:52:47.818638
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"



# Generated at 2022-06-12 03:52:57.158725
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-12 03:53:05.985610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

    ma = MovedAttribute("filter", "itertools", "builtins")
    assert ma.name == "filter"
    assert ma.new_mod == "builtins"
    assert ma.new_attr == "filter"

# Generated at 2022-06-12 03:53:14.112697
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = []
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                rewrites.append((path, 'six.moves{}.{}'.format(prefix, move.name)))
            elif isinstance(move, MovedModule):
                rewrites.append((move.new, 'six.moves%s.%s' % (prefix, move.name)))
    assert SixMovesTransformer.rewrites == rewrites

# Generated at 2022-06-12 03:53:18.878045
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old")
    assert a.name == "name"
    assert a.old == "old"
    assert a.new == "name"

    b = MovedModule("name", "old", "new")
    assert b.name == "name"
    assert b.old == "old"
    assert b.new == "new"

# Generated at 2022-06-12 03:53:31.066215
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert six.builtins == builtins
    assert six.zip == zip
    assert six.moves.reduce == functools.reduce
    assert six.moves.cPickle == pickle
    assert six.moves.configparser == configparser
    assert six.moves.filter == filter
    assert six.moves.http_client.HTTPResponse
    assert six.moves.urllib.parse.ParseResult
    assert six.moves.urllib.error.URLError
    assert six.moves.urllib.request.Request
    assert six.moves.urllib.response.addbase
    assert six.moves.urllib.robotparser.RobotFileParser

if __name__ == "__main__":
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:53:35.886133
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old_mod', 'new_mod')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'name'
    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'


# Generated at 2022-06-12 03:53:53.294487
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:53:58.330972
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute(
        "name",
        "old_mod",
        "new_mod",
        "old_attr",
        "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"



# Generated at 2022-06-12 03:54:04.119816
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "old")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "name"

    obj = MovedModule("name", "old", new="new")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "new"


# Generated at 2022-06-12 03:54:14.482188
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # This is not really a test, but rather a code snippet,
    # to create mapping of all moves.
    header = []
    header.append('# Generated from six.moves from https://pypi.org/project/six/')
    header.append('')
    header.append('# Code copied from six:')
    header.append('')

    footer = []
    footer.append('# end of code from six')
    footer.append('')

    print()
    print('\n'.join(header))

# Generated at 2022-06-12 03:54:19.809975
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _six_moves_transformer = SixMovesTransformer()
    assert _six_moves_transformer.target == (2, 7)
    assert _six_moves_transformer.rewrites == _get_rewrites()
    assert _six_moves_transformer.depencencies == ['six']

# Generated at 2022-06-12 03:54:23.597491
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("six.moves.urllib.parse", "six.moves.urllib.parse").new == MovedModule("six.moves.urllib.parse", "six.moves.urllib.parse").name

# Generated at 2022-06-12 03:54:28.955862
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old")
    assert a.name == "name"
    assert a.new == "name"
    assert a.old == "old"

    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.new == "new"
    assert a.old == "old"



# Generated at 2022-06-12 03:54:32.128418
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    assert six.moves == sys.modules['six.moves']



# Generated at 2022-06-12 03:54:36.484664
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('a', 'oldmod', 'newmod', 'oldattr', 'newattr')
    assert ma.name == 'a'
    assert ma.new_mod == 'newmod'
    assert ma.new_attr == 'newattr'


# Generated at 2022-06-12 03:54:39.891702
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("django", "django")
    assert moved_module.name == "django"
    assert moved_module.new == "django"



# Generated at 2022-06-12 03:54:52.198898
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('a', 'b', c='d')

# Generated at 2022-06-12 03:54:53.744777
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")


# Generated at 2022-06-12 03:54:57.529524
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule(name="name", old="old", new="new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"

    m = MovedModule(name="name", old="old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"


# Generated at 2022-06-12 03:54:59.437446
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six
    moved_attribute = six._moved_attributes[0]
    assert moved_attribute.name == moved_attribute.new_attr

# Generated at 2022-06-12 03:55:02.363579
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-12 03:55:05.731106
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "MovedModule"
    old = "old"
    new = "new"
    move = MovedModule(name, old, new)
    assert move.name == name
    assert move.old == old
    assert move.new == new


# Generated at 2022-06-12 03:55:06.807150
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("tkinter", "Tkinter")

# Generated at 2022-06-12 03:55:17.198022
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", None).__dict__ == \
        {'name': 'cStringIO', 'old_attr': 'StringIO', 'old_mod': 'cStringIO', 'new_attr': 'StringIO', 'new_mod': 'io'}
    assert MovedAttribute("cStringIO", "cStringIO", "io", None, None).__dict__ == \
        {'name': 'cStringIO', 'old_attr': None, 'old_mod': 'cStringIO', 'new_attr': 'cStringIO', 'new_mod': 'io'}

# Generated at 2022-06-12 03:55:19.315861
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == next(SixMovesTransformer.__eager__)

# Generated at 2022-06-12 03:55:26.925159
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer().rewrites, dict)
    assert len(SixMovesTransformer().rewrites) > 0

# This code is needed by the 'unittests' target in the Makefile.
# isort:off
if __name__ == "__main__":
    import os, sys

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    # isort:on
    import unittest

    unittest.main()

# Generated at 2022-06-12 03:55:51.463547
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests that SixMovesTransformer is correctly constructed."""
    assert len(SixMovesTransformer.rewrites) == 20

# Generated at 2022-06-12 03:55:58.935170
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

    ma = MovedAttribute("cStringIO", "cStringIO", "io")

    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "cStringIO"

    return True



# Generated at 2022-06-12 03:56:07.278312
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:13.488005
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') \
        .__dict__ == {
                'name': 'cStringIO',
                'new_mod': 'io',
                'new_attr': 'StringIO'
                }
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter') \
        .__dict__ == {
                'name': 'filter',
                'new_mod': 'builtins',
                'new_attr': 'filter'
                }

# Generated at 2022-06-12 03:56:16.653813
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("name", "old")
    assert test.name == "name"
    assert test.old == "old"
    assert test.new == "name"

    test = MovedModule("name", "old", "new")
    assert test.name == "name"
    assert test.old == "old"
    assert test.new == "new"


# Generated at 2022-06-12 03:56:22.406002
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # new_attr = old_attr = name = 'test'
    m = MovedAttribute('test', 'old_mod', 'new_mod')
    assert m.name == 'test'
    assert m.old_mod == 'old_mod'
    assert m.new_mod == 'new_mod'
    assert m.old_attr == m.new_attr == m.name
    m = MovedAttribute('test', 'old_mod', 'new_mod', 'old_attr')
    assert m.name == 'test'
    assert m.old_mod == 'old_mod'
    assert m.new_mod == 'new_mod'
    assert m.old_attr == 'old_attr'
    assert m.new_attr == m.name

# Generated at 2022-06-12 03:56:25.568228
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    atribute = MovedAttribute("foo", "bar", "baz")
    assert atribute.name == "foo"
    assert atribute.new_mod == "baz"
    assert atribute.new_attr == "foo"

# Generated at 2022-06-12 03:56:28.579808
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.old == "__builtin__"
    assert move.new == "builtins"


# Generated at 2022-06-12 03:56:30.864442
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Just checking that this doesn't error
    MovedModule('foo', 'bar')
    MovedModule('foo', 'bar', 'baz')



# Generated at 2022-06-12 03:56:36.191334
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert [MovedAttribute("cStringIO", "cStringIO", "io"),
            MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"),
            MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")] == [
        MovedAttribute("cStringIO", "cStringIO", "io"),
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"),
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")
    ]


# Unittest for constructor of class MovedModule

# Generated at 2022-06-12 03:57:26.343262
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"

# Generated at 2022-06-12 03:57:28.151658
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:57:37.990752
# Unit test for constructor of class MovedModule

# Generated at 2022-06-12 03:57:39.929440
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None, None, None, None).target == (2, 7)

# Generated at 2022-06-12 03:57:47.138316
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 54
    assert ('os.getcwd', 'six.moves.getcwd') in _get_rewrites()
    assert ('os.getcwdb', 'six.moves.getcwdb') in _get_rewrites()
    assert ('builtins.filter', 'six.moves.filter') in _get_rewrites()
    assert ('builtins.map', 'six.moves.map') in _get_rewrites()
    assert ('builtins.input', 'six.moves.input') in _get_rewrites()
    assert ('builtins.range', 'six.moves.range') in _get_rewrites()
    assert ('imp.reload', 'six.moves.reload_module') in _get_rewrites()

# Generated at 2022-06-12 03:57:54.718113
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class_name = MovedModule('module_name', 'old_module_name', 'new_module_name')
    assert class_name.name == 'module_name'
    assert class_name.old == 'old_module_name'
    assert class_name.new == 'new_module_name'

    class_name = MovedModule('module_name', 'old_module_name')
    assert class_name.new == 'module_name'


# Generated at 2022-06-12 03:57:57.280552
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") == MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")


# Generated at 2022-06-12 03:58:00.514710
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule("name", "old", "new")
    assert t.name == "name"
    assert t.new == "new"
    t = MovedModule("name", "old")
    assert t.name == "name"
    assert t.new == "name"


# Generated at 2022-06-12 03:58:03.063065
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('testname', 'testmod', 'testmod', 'testold', 'testnew')
    assert attr.name == 'testname'
    assert attr.new_mod == 'testmod'
    assert attr.new_attr == 'testnew'

# Generated at 2022-06-12 03:58:06.025160
# Unit test for constructor of class MovedModule
def test_MovedModule():

    mm = MovedModule("foo", "bar", "baz")
    assert mm.name == "foo"
    assert mm.old == "bar"
    assert mm.new == "baz"

# Generated at 2022-06-12 04:00:07.791570
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule("", "", "")
    except TypeError:
        raise
    else:
        pass
    try:
        MovedModule("", "sdfs", "")
    except TypeError:
        pass
    else:
        raise
    try:
        MovedModule("", "", "asdas")
    except TypeError:
        pass
    else:
        raise

# Generated at 2022-06-12 04:00:09.306235
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer().rewrites)  # noqa

# Generated at 2022-06-12 04:00:16.596997
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mo = MovedAttribute('Name of moved attribute',
                        'old_module',
                        'new_module',
                        'old_attribute',
                        'new_attribute')
    assert mo.name == 'Name of moved attribute'
    assert mo.new_mod == 'new_module'
    assert mo.new_attr == 'new_attribute'
    # Now without giving the attributes
    mo = MovedAttribute('Name of moved attribute',
                        'old_module',
                        'new_module')
    assert mo.name == 'Name of moved attribute'
    assert mo.new_mod == 'new_module'
    assert mo.new_attr == 'Name of moved attribute'

# Generated at 2022-06-12 04:00:20.029918
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('range', '__builtin__', 'builtins', 'xrange', 'range')
    assert move.name == 'range'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'range'

# Generated at 2022-06-12 04:00:23.496844
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('name', 'old', 'new')
    assert mod.name == 'name'
    assert mod.new == 'new'

    mod = MovedModule('name', 'old')
    assert mod.name == 'name'
    assert mod.new == 'name'



# Generated at 2022-06-12 04:00:28.246129
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm1 = MovedModule("module1", "module1")
    assert mm1.name == "module1"
    assert mm1.new == "module1"
    mm2 = MovedModule("module2", "module2", "module2a")
    assert mm2.name == "module2"
    assert mm2.new == "module2a"

# Generated at 2022-06-12 04:00:32.559221
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert 'cStringIO' == ma.name
    assert 'cStringIO' == ma.old_mod
    assert 'io' == ma.new_mod
    assert 'StringIO' == ma.old_attr
    assert 'cStringIO' == ma.new_attr


# Generated at 2022-06-12 04:00:36.394817
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("a", "b")
    assert m.name == 'a'
    assert m.new == 'b'

    m = MovedModule("a", "b", "c")
    assert m.name == 'a'
    assert m.new == 'c'


# Generated at 2022-06-12 04:00:44.362743
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", None).new_mod == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").new_attr == "old_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", old_attr=None).new_attr == "name"


