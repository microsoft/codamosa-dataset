

# Generated at 2022-06-12 03:50:51.386918
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert obj.new_mod == 'cStringIO'
    assert obj.new_attr == 'StringIO'
    assert obj.name == 'cStringIO'
    obj = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert obj.new_mod == 'cStringIO'
    assert obj.new_attr == 'cStringIO'
    assert obj.name == 'cStringIO'
    obj = MovedAttribute('cStringIO', 'cStringIO', 'io', new_attr="test")
    assert obj.new_mod == 'cStringIO'
    assert obj.new_attr == 'test'
    assert obj.name == 'cStringIO'

# Generated at 2022-06-12 03:50:52.695528
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # just need to know that it runs
    SixMovesTransformer()

# Generated at 2022-06-12 03:50:54.622803
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')

# Generated at 2022-06-12 03:51:06.146364
# Unit test for constructor of class MovedModule

# Generated at 2022-06-12 03:51:17.865510
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_mod == 'old_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').old_attr == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'

# Generated at 2022-06-12 03:51:29.407909
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert ma.name == 'cStringIO'
    assert ma.old_mod is None
    assert ma.new_mod == 'io'
    assert ma.old_attr is None
    assert ma.new_attr == 'StringIO'

    ma1 = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert ma1.old_attr is None
    assert ma1.new_attr == 'cStringIO'

    ma2 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert ma2.old_attr == 'StringIO'
    assert ma2.new_attr == 'StringIO'

# Generated at 2022-06-12 03:51:33.901095
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test SixMovesTransformer constructor."""
    t = SixMovesTransformer()
    for path, new_path in t.rewrites:
        assert path in sys.modules or new_path in sys.modules
        # check that the module exists
        exec("import " + path, {}, {})

# Generated at 2022-06-12 03:51:42.012939
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "old_attr"

    ma = MovedAttribute("name", "old_mod", "new_mod")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "name"


# Generated at 2022-06-12 03:51:53.678852
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the constructor of class SixMovesTransformer"""
    obj = SixMovesTransformer()
    assert obj.target == (2, 7), \
        'SixMovesTransformer.target must be (2, 7)'
    # This must be a static attribute
    assert isinstance(obj.rewrites, tuple), \
        'SixMovesTransformer.rewrites must be a tuple'
    for rewrite in obj.rewrites:
        assert len(rewrite) == 2, \
            'Each rewrite must be a tuple of length 2'
        assert all(isinstance(item, str) for item in rewrite), \
            'Each rewrite must be a tuple of strings'
    assert isinstance(obj.dependencies, tuple), \
        'SixMovesTransformer.dependencies must be a tuple'



# Generated at 2022-06-12 03:51:59.976808
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module1 = MovedModule("test_module", "test_old_module", "test_new_module")
    assert module1.name == "test_module"
    assert module1.old == "test_old_module"
    assert module1.new == "test_new_module"
    module2 = MovedModule("test_module2", "test_old_module2")
    assert module2.name == "test_module2"
    assert module2.old == "test_old_module2"
    assert module2.new == "test_module2"


# Generated at 2022-06-12 03:52:04.506974
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser").old == "ConfigParser"


# Generated at 2022-06-12 03:52:13.136544
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('test', 'a', 'b')
    assert m.new_mod == 'b'
    assert m.new_attr == 'test'
    m = MovedAttribute('test', 'a', 'b', new_attr='c')
    assert m.new_mod == 'b'
    assert m.new_attr == 'c'
    m = MovedAttribute('test', 'a', 'b', old_attr='c')
    assert m.new_mod == 'b'
    assert m.new_attr == 'c'


# Generated at 2022-06-12 03:52:19.169094
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'


# Generated at 2022-06-12 03:52:23.272580
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.new == "new"
    assert moved_module.old == "old"


# Generated at 2022-06-12 03:52:28.157170
# Unit test for constructor of class MovedModule
def test_MovedModule():
    var = MovedModule("name","old","new")
    assert var.name == "name"
    assert var.old == "old"
    assert var.new == "new"


# Generated at 2022-06-12 03:52:32.265305
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    line = 'from six.moves import filter'
    expect = 'from six.moves import filter\nfrom six.moves import StringIO, xrange'
    transformer = SixMovesTransformer(None)
    assert transformer.on_line(line) == expect

# Generated at 2022-06-12 03:52:41.569438
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'mod', 'newmod', 'oldattr', 'newattr') == \
        MovedAttribute('name', 'mod', 'newmod', 'oldattr', 'newattr')
    assert MovedAttribute('name', 'mod', 'newmod', 'oldattr') == \
        MovedAttribute('name', 'mod', 'newmod', 'oldattr', 'oldattr')
    assert MovedAttribute('name', 'mod', 'newmod', old_attr=None) == \
        MovedAttribute('name', 'mod', 'newmod')
    assert MovedAttribute('name', 'newmod') == \
        MovedAttribute('name', 'newmod', 'newmod')


# Generated at 2022-06-12 03:52:47.030456
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("foobar", "barfoo")
    assert a.name == "foobar"
    assert a.new == "foobar"
    assert a.old == "barfoo"

    b = MovedModule("foobar", "barfoo", "bar")
    assert b.name == "foobar"
    assert b.old == "barfoo"
    assert b.new == "bar"



# Generated at 2022-06-12 03:52:50.125562
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tt = SixMovesTransformer(None)
    assert tt.target == (2, 7)
    assert len(tt.rewrites) == 173


if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:52:51.052498
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-12 03:52:58.042623
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('test_module', 'old_name')
    assert moved_module.name == 'test_module'
    assert moved_module.old == 'old_name'
    assert moved_module.new == 'test_module'


# Generated at 2022-06-12 03:53:00.855967
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")

# Generated at 2022-06-12 03:53:06.190223
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('windows', '_winreg')
    assert moved_module.name == 'windows'
    assert moved_module.new == 'windows'
    assert moved_module.old == '_winreg'
    print('Finish test_MovedModule')


# Generated at 2022-06-12 03:53:10.430082
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.refactor import RefactoringTool
    r = RefactoringTool([SixMovesTransformer], b'3.6')
    assert len(r.refactorings) == 1
    assert r.refactorings[0].__class__ == SixMovesTransformer
    assert r.refactorings[0].dependencies == ['six']
    assert len(r.refactorings[0].rewrites) == 223

# Generated at 2022-06-12 03:53:20.271833
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:53:22.648587
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .moves import _get_rewrites
    rewrites = _get_rewrites()
    assert rewrites == _moved_attributes

# Generated at 2022-06-12 03:53:27.493582
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("new_name", "old_location").name == "new_name"
    assert MovedModule("new_name", "old_location").new == "new_name"
    assert MovedModule("new_name", "old_location", "name").new == "name"



# Generated at 2022-06-12 03:53:31.015554
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"



# Generated at 2022-06-12 03:53:36.548834
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").name == "input"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").name == "filterfalse"

# Generated at 2022-06-12 03:53:39.196652
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # don't actually call it, just make sure it's eagerly evaluated.
    _get_rewrites()

# Generated at 2022-06-12 03:53:57.111474
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert t.rewrites[1] == ('builtins.filter', 'six.moves.filter')
    assert t.rewrites[2] == ('itertools.filterfalse', 'six.moves.filterfalse')
    assert t.rewrites[3] == ('builtins.input', 'six.moves.input')
    assert t.rewrites[4] == ('sys.intern', 'six.moves.intern')
    assert t.rewrites[5] == ('builtins.map', 'six.moves.map')
    assert t.rewrites[6] == ('os.getcwd', 'six.moves.getcwd')

# Generated at 2022-06-12 03:54:02.337099
# Unit test for constructor of class MovedModule
def test_MovedModule():
    correct_cases = [
        ('queue', 'Queue', 'queue'),
        ('socketserver', 'SocketServer', 'socketserver'),
        ('_winreg', '_winreg', '_winreg')
    ]
    for case in correct_cases:
        assert case == MovedModule(*case).__dict__


# Generated at 2022-06-12 03:54:08.275315
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("a", "b")
    assert mm.name == "a"
    assert mm.new == "a"
    assert mm.old == "b"

    mm = MovedModule("a", "b", "c")
    assert mm.name == "a"
    assert mm.new == "c"
    assert mm.old == "b"

# Generated at 2022-06-12 03:54:13.113868
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

# Generated at 2022-06-12 03:54:20.750342
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('abc', 'abc')
    assert mm.name == 'abc'
    assert mm.new == 'abc'

    mm = MovedModule('abc', 'xyz')
    assert mm.name == 'abc'
    assert mm.new == 'xyz'

    mm = MovedModule('xyz', 'abc', 'xyz')
    assert mm.name == 'xyz'
    assert mm.new == 'xyz'


# Generated at 2022-06-12 03:54:27.864181
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from .base import MovedModule

    m1 = MovedModule("builtins", "__builtin__")
    m2 = MovedModule("toto", "tutu", "tata")

    assert m1.name == "builtins"
    assert m1.old == "__builtin__"
    assert m1.new == "builtins"

    assert m2.name == "toto"
    assert m2.old == "tutu"
    assert m2.new == "tata"



# Generated at 2022-06-12 03:54:32.693345
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("tkinter", "Tkinter")
    assert moved_module.name == "tkinter"
    assert moved_module.old == "Tkinter"
    assert moved_module.new == "tkinter"


# Generated at 2022-06-12 03:54:45.052945
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("a", "b")
    MovedAttribute("a", "b", "c")
    MovedAttribute("a", "b", "c", "d")
    MovedAttribute("a", "b", "c", "d", "e")
    MovedAttribute("a", "b", "c", "d", None)
    MovedAttribute("a", "b", "c", None, None)
    MovedAttribute("a", "b", "c", None, "e")
    MovedAttribute("a", "b", "c", old_attr="d", new_attr=None)
    MovedAttribute("a", "b", "c", old_attr=None, new_attr="e")
    MovedAttribute("a", "b", "c", old_attr="d")

# Generated at 2022-06-12 03:54:51.337126
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("foo", "bar", "baz")
    assert a.name == "foo"
    assert a.new_mod == "baz"
    assert a.new_attr == "foo"
    b = MovedAttribute("foo", "bar", "baz", "barfoo", "bazfoo")
    assert b.name == "foo"
    assert b.new_mod == "baz"
    assert b.new_attr == "bazfoo"

# Generated at 2022-06-12 03:54:54.222153
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('a', 'b', 'c', 'd', 'e')
    assert a.name == 'a'
    assert a.new_mod == 'c'
    assert a.new_attr == 'e'


# Generated at 2022-06-12 03:55:08.987094
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule('name', 'old', 'new')
    assert t.name == 'name'
    assert t.old == 'old'
    assert t.new == 'new'

# Generated at 2022-06-12 03:55:10.757884
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    six.moves.dbm_gnu.open
    six.moves.builtins.open

# Generated at 2022-06-12 03:55:13.422248
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites  # Make sure it worked
    assert len(t.rewrites) > 0

# Test for SixMovesTransformer

# Generated at 2022-06-12 03:55:20.236888
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import utils
    from .future import FutureImportTransformer

    # Test that rewrites point at the right modules
    six_moves = SixMovesTransformer(utils, {})
    future = FutureImportTransformer(utils, {})

    for rewrite in six_moves.rewrites:
        assert rewrite[1] not in future.rewrites, 'six.moves{} is already in future.rewrites'.format(rewrite[1])


# Generated at 2022-06-12 03:55:30.017587
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:55:41.601433
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') == \
        MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') != \
        MovedAttribute('map', 'itertools', 'builtins', 'imap', 'map')

    assert MovedAttribute('cStringIO', 'cStringIO', 'io').name == \
        MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').new_mod == \
        MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod

# Generated at 2022-06-12 03:55:44.799922
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm=MovedModule("name","old","new")
    assert mm.name=="name"
    assert mm.old=="old"
    assert mm.new=="new"
    


# Generated at 2022-06-12 03:55:55.550829
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test SixMovesTransformer"""

# Generated at 2022-06-12 03:55:56.489608
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("builder", "HTMLParser")

# Generated at 2022-06-12 03:55:59.520806
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('test', 'old', 'new')
    assert m.name == 'test'
    assert m.new_mod == 'new'
    assert m.new_attr == 'test'


# Generated at 2022-06-12 03:56:13.152005
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites() != {}
    assert SixMovesTransformer.rewrites != []

# Generated at 2022-06-12 03:56:19.693633
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test simple transformer"""

# Generated at 2022-06-12 03:56:22.945361
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    assert rewrites


if __name__ == "__main__":
    import pytest
    pytest.main(str(__file__.replace('\\', '/')) + ' -v')

# Generated at 2022-06-12 03:56:31.507327
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") == \
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("filter", "itertools", "builtins") == \
        MovedAttribute("filter", "itertools", "builtins")
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter") == \
        MovedAttribute("filter", "itertools", "builtins", "ifilter")
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter") == \
        MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")



# Generated at 2022-06-12 03:56:33.683298
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    old_rewrites = []
    for item in rewrites:
        old_rewrites.append(item)
    assert list(rewrites) == old_rewrites

# Generated at 2022-06-12 03:56:44.709563
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_attribute.name == "cStringIO"
    assert move_attribute.new_mod == "io"
    assert move_attribute.new_attr == "StringIO"


if __name__ == '__main__':
    import sys
    import os
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Generated at 2022-06-12 03:56:53.191943
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test for a valid initialization
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'
    # Test for an initialization without new_attr
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'old_attr'
    # Test for an initialization without old_attr

# Generated at 2022-06-12 03:57:02.269472
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:57:07.358761
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    assert mm.new == "new"
    # test for old value if not given
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"

# Generated at 2022-06-12 03:57:11.004845
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import_path = 'six.moves.urllib.parse'
    moved_module = MovedModule('urllib.parse', 'six.moves', 'urllib.parse')
    assert moved_module.new == import_path
    assert moved_module.name == import_path

# Generated at 2022-06-12 03:57:28.862871
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert c.name == "cStringIO"
    assert c.new_mod == "io"
    assert c.new_attr == "StringIO"


# Generated at 2022-06-12 03:57:29.997060
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:57:39.978688
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.fixes.fix_next import FixNext
    from lib2to3.fixes.fix_imports2 import FixImports
    from lib2to3.fixes.fix_import import is_import, is_from
    prefix = __name__ + '.'

    def _make_attr(attr):
        return '{}.{}'.format(attr.new_mod, attr.new_attr)

    def _make_rewrites(moves, prefix=''):
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = _make_attr(move)
                yield (path, 'six.moves{}.{}'.format(prefix, move.name))

# Generated at 2022-06-12 03:57:45.004945
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__') == MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__', 'builtins') == MovedModule('builtins', '__builtin__', 'builtins')
    assert MovedModule('builtins', '__builtin__') != MovedModule('builtins', '__builtin__', 'builtins')
    assert MovedModule('builtins', '__builtin__') != object()

# Generated at 2022-06-12 03:57:50.752953
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.dependencies) == 1
    assert SixMovesTransformer.dependencies == ['six']
    assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())
    assert all(
        (SixMovesTransformer.rewrites[i] == _get_rewrites()[i])
        for i in range(len(SixMovesTransformer.rewrites))
    )

# Generated at 2022-06-12 03:57:57.164856
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import_names = ('reprlib', 'http.server', 'http.cookiejar', '_thread')
    moved_module_names = ('repr', 'BaseHTTPServer', 'CGIHTTPServer',
        'SimpleHTTPServer', 'Cookie', 'cookielib', '_dummy_thread', 'thread')
    for name, moved in zip(import_names, moved_module_names):
        mm = MovedModule(name, moved)
        assert mm.new == name
        assert mm.name == moved

# Generated at 2022-06-12 03:58:00.722868
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for name, new in _get_rewrites():
        if 'urllib' in new:
            assert new == 'six.moves{0}.urllib'.format('.urllib.parse')
        else:
            assert new == 'six.moves{0}.{1}'.format('', name.split('.')[-1])

# Generated at 2022-06-12 03:58:06.971163
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    temp_MovedAttribute = MovedAttribute(name="testAttr",
                                         old_mod="testMod",
                                         new_mod="newMod",
                                         old_attr="testOldAttr",
                                         new_attr="testNewAttr")
    assert temp_MovedAttribute.name == "testAttr"
    assert temp_MovedAttribute.new_mod == "newMod"
    assert temp_MovedAttribute.new_attr == "testNewAttr"

# Generated at 2022-06-12 03:58:14.519601
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('test_name', 'test_old_name', 'test_new_name')
    assert moved_module.name == 'test_name'
    assert moved_module.old == 'test_old_name'
    assert moved_module.new == 'test_new_name'
    moved_module = MovedModule('test_name', 'test_old_name')
    assert moved_module.name == 'test_name'
    assert moved_module.old == 'test_old_name'
    assert moved_module.new == 'test_name'



# Generated at 2022-06-12 03:58:16.865021
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, list)
    assert len(SixMovesTransformer.rewrites) > 0

# Generated at 2022-06-12 03:58:41.498253
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    y = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO")
    z = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO")

    assert x.name == "cStringIO"
    assert x.new_mod == "io"
    assert x.new_attr == "StringIO"

    assert y.name == "cStringIO"
    assert y.new_mod == "io"
    assert y.new_attr == "StringIO"

    assert z.name == "cStringIO"
    assert z.new_mod == "io"
    assert z.new_attr == "StringIO"


# Generated at 2022-06-12 03:58:42.414651
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:58:49.067056
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__', 'new_builtins').name == 'builtins'
    assert MovedModule('builtins', '__builtin__', 'new_builtins').old == '__builtin__'
    assert MovedModule('builtins', '__builtin__', 'new_builtins').new == 'new_builtins'


# Generated at 2022-06-12 03:58:53.163001
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old", "name")
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"



# Generated at 2022-06-12 03:58:56.457301
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """
    Test constructor of MovedModule.
    """
    m = MovedModule("pil", "PIL", "pil")
    assert m.name == "pil"
    assert m.old == "PIL"
    assert m.new == "pil"


# Generated at 2022-06-12 03:59:00.756682
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'


# Generated at 2022-06-12 03:59:11.442587
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:59:18.910720
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"

# Generated at 2022-06-12 03:59:21.080265
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == list(_get_rewrites())
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:59:30.769389
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from conversions import to_python

    rewrites = SixMovesTransformer.rewrites
    assert rewrites['urllib.parse.ParseResult'] == 'six.moves.urllib_parse.ParseResult'
    assert rewrites['urllib.parse.parse_qs'] == 'six.moves.urllib_parse.parse_qs'
    assert rewrites['urllib.request.urlopen'] == 'six.moves.urllib_request.urlopen'
    assert rewrites['functools.reduce'] == 'six.moves.reduce'
    assert rewrites['urllib.request.ProxyBasicAuthHandler'] == 'six.moves.urllib_request.ProxyBasicAuthHandler'

# Generated at 2022-06-12 04:00:10.161348
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_test = MovedModule("testname", "testold", "testnew")
    assert moved_module_test.name == "testname"
    assert moved_module_test.old == "testold"
    assert moved_module_test.new == "testnew"



# Generated at 2022-06-12 04:00:17.393298
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod").new_attr == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr != "old_attr"


# Generated at 2022-06-12 04:00:18.212323
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 04:00:24.914082
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert ma.new_attr == "name"
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.new_attr == "new_attr"
    ma = MovedAttribute("name", "old_mod", "new_mod")
    assert ma.new_attr == "name"
    ma = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    assert ma.new_attr == "new_attr"

# Generated at 2022-06-12 04:00:34.617086
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "cStringIO"
    assert moved_attribute.new_attr == "StringIO"
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attribute.new_attr == "cStringIO"
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io",
                                     old_attr="StringIO", new_attr="io")
    assert moved_attribute.old_mod == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.old_attr == "StringIO"
    assert moved_attribute.new

# Generated at 2022-06-12 04:00:37.483566
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("queue", "Queue")
    assert module.name == "queue"
    assert module.old == "Queue"
    assert module.new == "queue"


# Generated at 2022-06-12 04:00:39.882442
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    sys.modules['six.moves'] = six.moves
    # One more unit test (in addition to the one in `__init__`
    # and the one in this file) is done by test_six.py
    SixMovesTransformer()

# Generated at 2022-06-12 04:00:42.177893
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "new"


# Generated at 2022-06-12 04:00:50.099799
# Unit test for constructor of class SixMovesTransformer