

# Generated at 2022-06-12 03:50:50.838892
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    if sys.version_info[:2] >= (3, 5):
        assert 'six.moves.http_cookies' in SixMovesTransformer.rewrites
        assert 'http.cookies' in [k for k, v in SixMovesTransformer.rewrites]
    else:
        assert 'six.moves.http_cookies' in SixMovesTransformer.rewrites
        assert 'http.cookies' not in [k for k, v in SixMovesTransformer.rewrites]


# Generated at 2022-06-12 03:51:01.626960
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    mc = SixMovesTransformer()

# Generated at 2022-06-12 03:51:05.821983
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("test_name", "test_old")
    assert mm.name == "test_name"
    assert mm.old == "test_old"
    assert mm.new == "test_name"
    mm = MovedModule("test_name", "test_old", "test_new")
    assert mm.name == "test_name"
    assert mm.old == "test_old"
    assert mm.new == "test_new"

# Generated at 2022-06-12 03:51:17.876409
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test that the constructor creates the correct rewrites.
    """
    # Assert that the rewrites is a tuple
    assert isinstance(SixMovesTransformer.rewrites, tuple)
    # Assert that the tuple contains the correct tuples
    assert ('sys.getcwd', 'six.moves.getcwd') in SixMovesTransformer.rewrites
    assert ('sys.getcwdb', 'six.moves.getcwdb') in SixMovesTransformer.rewrites
    assert ('sys.intern', 'six.moves.sys.intern') in SixMovesTransformer.rewrites
    assert ('os.getcwd', 'six.moves.getcwd') in SixMovesTransformer.rewrites
    assert ('os.getcwdb', 'six.moves.getcwdb')

# Generated at 2022-06-12 03:51:22.263059
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old", "new", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new"
    assert attr.new_attr == "new_attr"


# Generated at 2022-06-12 03:51:33.902083
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("moved", "old", "new", "old_attr", "new_attr").__dict__ == \
        {'name': 'moved',
         'new_mod': 'new',
         'new_attr': 'new_attr'}

    assert MovedAttribute("moved", "old", "new", "old_attr", None).__dict__ == \
        {'name': 'moved',
         'new_mod': 'new',
         'new_attr': 'old_attr'}

    assert MovedAttribute("moved", "old", "new", None, None).__dict__ == \
        {'name': 'moved',
         'new_mod': 'new',
         'new_attr': 'moved'}

    assert MovedAttribute("moved", "old", "new").__dict

# Generated at 2022-06-12 03:51:40.459545
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2.token import NAME, OP, COMMA

    t = SixMovesTransformer()

# Generated at 2022-06-12 03:51:51.647042
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # arrange
    expected_name = 'filter'
    expected_old_mod = 'itertools'
    expected_new_mod = 'builtins'
    expected_old_attr = 'ifilter'
    expected_new_attr = 'filter'
    # act
    actual = MovedAttribute(expected_name, expected_old_mod, expected_new_mod,
                            expected_old_attr, expected_new_attr)
    # assert
    assert actual.name == expected_name
    assert actual.old_mod == expected_old_mod
    assert actual.new_mod == expected_new_mod
    assert actual.old_attr == expected_old_attr
    assert actual.new_attr == expected_new_attr



# Generated at 2022-06-12 03:52:00.495617
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:52:08.578756
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    def try_moved_attribute(name, old_mod, new_mod, old_attr=None, new_attr=None):
        moved = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
        assert moved.name == name
        assert moved.new_mod == new_mod
        assert moved.new_attr == new_attr

    yield try_moved_attribute, "name", "old", "new"
    yield try_moved_attribute, "name", "old", "new", "oldattr"
    yield try_moved_attribute, "name", "old", "new", "oldattr", "newattr"

# Generated at 2022-06-12 03:52:13.344628
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name is 'name'
    assert module.old is 'old'
    assert module.new is 'new'


# Generated at 2022-06-12 03:52:16.898369
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.new == "builtins"
    assert module.old == "__builtin__"

# Generated at 2022-06-12 03:52:30.375161
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    MovedModule("configparser", "ConfigParser")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    MovedAttribute("intern", "__builtin__", "sys")
    MovedAttribute("map", "itertools", "builtins", "imap", "map")
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-12 03:52:36.816336
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('attr', 'old_mod', 'new_mod')
    assert attr.name == 'attr'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'attr'
    attr = MovedAttribute('attr', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert attr.name == 'attr'
    assert attr.new_mod == 'new_mod'
    assert attr.new_attr == 'new_attr'

# Generated at 2022-06-12 03:52:39.121211
# Unit test for constructor of class MovedModule
def test_MovedModule():
    for move in _moved_attributes:
        if isinstance(move, MovedModule):
            assert move.name== move.new

# Generated at 2022-06-12 03:52:42.422247
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('StringIO', 'cStringIO', 'io')
    assert attr.name == 'StringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'

# Generated at 2022-06-12 03:52:46.431072
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

# Generated at 2022-06-12 03:52:49.565539
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'oldmod', 'newmod', 'oldattr', 'newattr')
    assert move.name == 'name'
    assert move.new_mod == 'newmod'
    assert move.new_attr == 'newattr'

# Generated at 2022-06-12 03:52:52.148387
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            path = 'six.moves{}.{}'.format(prefix, move.name)
            assert path in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:52:53.097349
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:53:02.710284
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert moved_attribute.name == "name"
    assert moved_attribute.new_mod == "new_mod"
    assert moved_attribute.new_attr == "new_attr"


# Generated at 2022-06-12 03:53:09.458508
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").old == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"

# Generated at 2022-06-12 03:53:11.418171
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('foo','bar','baz','old','new')

# Generated at 2022-06-12 03:53:12.916119
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 68

# Generated at 2022-06-12 03:53:21.657642
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").__dict__ == \
           {
               "name": "name",
               "old_mod": "old_mod",
               "new_mod": "new_mod",
               "old_attr": "old_attr",
               "new_attr": "new_attr"
           }

    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").__dict__ == \
           {
               "name": "name",
               "old_mod": "old_mod",
               "new_mod": "new_mod",
               "old_attr": "old_attr",
               "new_attr": "old_attr"
           }


# Generated at 2022-06-12 03:53:26.904724
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule("moved_module", "old_module", "new_module")
    assert test_moved_module.name == "moved_module"
    assert test_moved_module.old == "old_module"
    assert test_moved_module.new == "new_module"


# Generated at 2022-06-12 03:53:31.681635
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('test_name (t1)', 'test_old (t2)', 'test_new (t3)')
    assert m.name == 'test_name (t1)'
    assert m.old == 'test_old (t2)'
    assert m.new == 'test_new (t3)'

# Generated at 2022-06-12 03:53:37.505668
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert transformer.rewrites
    assert transformer.dependencies

if __name__ == "__main__":
    # Unit test for SixMovesTransformer
    transformer = SixMovesTransformer(None)
    for rewrite in transformer.rewrites:
        print(rewrite)
    for dependency in transformer.dependencies:
        print(dependency)

# Generated at 2022-06-12 03:53:49.159387
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attr = MovedAttribute("foo", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move_attr.name == 'foo'
    assert move_attr.new_mod == 'new_mod'
    assert move_attr.new_attr == 'new_attr'
    move_attr = MovedAttribute("foo", "old_mod", "new_mod", new_attr=None)
    assert move_attr.name == 'foo'
    assert move_attr.new_mod == 'new_mod'
    assert move_attr.new_attr == 'foo'
    move_attr = MovedAttribute("foo", "old_mod", "new_mod", old_attr='old_attr', new_attr=None)
    assert move_attr.name == 'foo'
    assert move_attr

# Generated at 2022-06-12 03:53:53.587758
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('old', 'new')
    assert(moved_module.name == 'old')
    assert(moved_module.new == 'new')
    assert(eager(moved_module.new) == 'new')


# Generated at 2022-06-12 03:54:10.911972
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transform = SixMovesTransformer()
    rewrites = transform._get_rewrites()

# Generated at 2022-06-12 03:54:17.341059
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("foo", "bar")
    assert move.name == "foo"
    assert move.new == "foo"
    assert move.old == "bar"

    move = MovedModule("foo", "bar", "baz")
    assert move.name == "foo"
    assert move.new == "baz"
    assert move.old == "bar"



# Generated at 2022-06-12 03:54:23.135616
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert ('{} = six.moves{}.{}'.format(path, prefix, move.name)) in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:54:28.501787
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")

    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"

    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "name"



# Generated at 2022-06-12 03:54:41.779503
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()

# Generated at 2022-06-12 03:54:48.896586
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move1 = MovedModule('m1', 'm1old')
    move2 = MovedModule('mod2', 'mod2old', 'mod2new')
    assert move1.name == 'm1'
    assert move2.name == 'mod2'
    assert move1.old == 'm1old'
    assert move2.old == 'mod2old'
    assert move1.new == 'm1'
    assert move2.new == 'mod2new'



# Generated at 2022-06-12 03:54:52.577117
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'old'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-12 03:54:55.038833
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm=MovedModule("test", "old", "new")
    assert mm.name == "test"
    assert mm.old =="old"
    assert mm.new =="new"


# Generated at 2022-06-12 03:55:03.805093
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").name == "filterfalse"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_mod == "builtins"
    assert MovedAttribute("intern", "__builtin__", "sys", "intern").new_attr == "intern"
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map").new_attr == "map"
    assert Moved

# Generated at 2022-06-12 03:55:13.675414
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test the default constructor
    m = MovedAttribute('test_attr')
    assert m.name == 'test_attr'
    assert m.new_mod == 'test_attr'
    assert m.new_attr == 'test_attr'

    # Test the full constructor
    m = MovedAttribute('test_attr', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert m.name == 'test_attr'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'

    # Test the meta full constructor
    m = MovedAttribute('test_attr', 'old_mod', 'new_mod', 'old_attr')
    assert m.name == 'test_attr'
    assert m.new_mod == 'new_mod'


# Generated at 2022-06-12 03:55:26.556885
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")


# Generated at 2022-06-12 03:55:36.448528
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:55:43.346363
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('configparser', 'ConfigParser')
    assert m.name == 'configparser'
    assert m.new == 'configparser'
    m = MovedModule('configparser', 'ConfigParser', 'configparser')
    assert m.name == 'configparser'
    assert m.new == 'configparser'
    m = MovedModule('configparser', 'ConfigParser', 'configparser.configparser')
    assert m.name == 'configparser'
    assert m.new == 'configparser.configparser'

# Generated at 2022-06-12 03:55:52.591684
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test for name, old, new
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

    # Test for name, old
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"

    # Test for name
    moved_module = MovedModule("name")
    assert moved_module.name == "name"
    assert moved_module.old == "name"
    assert moved_module.new == "name"


# Generated at 2022-06-12 03:55:58.598508
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    s = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert s.new_mod == 'new_mod'
    assert s.name == 'name'
    assert s.old_mod == 'old_mod'
    assert s.new_attr == 'new_attr'
    assert s.old_attr == 'old_attr'


# Generated at 2022-06-12 03:55:59.605752
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer(None)

# Generated at 2022-06-12 03:56:00.557669
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _ = SixMovesTransformer()

# Generated at 2022-06-12 03:56:04.328007
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'


# Generated at 2022-06-12 03:56:07.154364
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test constructor of class MovedModule."""
    name = 'test_name'
    old = 'test_old'
    new = 'test_new'
    move = MovedModule(name, old, new)
    assert move.name == name
    assert move.new == new

# Generated at 2022-06-12 03:56:08.572841
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer().rewrites, dict)
    assert len(SixMovesTransformer().rewrites) == 51

# Generated at 2022-06-12 03:56:40.244575
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    if sys.version_info[0] == 2:
        from lib2to3.fixer_util import String, syms
        from lib2to3.pgen2.token import NAME
        six_moves_transformer = SixMovesTransformer()
        assert len(six_moves_transformer.rewrites) == len(_get_rewrites())
        assert len(six_moves_transformer.rewrites) == len(prefixed_moves)
        assert six_moves_transformer

# Generated at 2022-06-12 03:56:50.132634
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("builtins", "__builtin__")
    assert m.name == "builtins"
    assert m.new == "builtins"
    m = MovedModule("builtins", "__builtin__", "__builtin__")
    assert m.name == "builtins"
    assert m.new == "__builtin__"
    m = MovedModule("os.path.abspath", "os.path", "os.path")
    assert m.name == "os.path.abspath"
    assert m.new == "os.path"
    m = MovedModule("os.path.abspath", "os.path", "os.path.abspath")
    assert m.name == "os.path.abspath"

# Generated at 2022-06-12 03:56:52.735199
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.new == 'new'

# Generated at 2022-06-12 03:56:57.761176
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    module_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    assert module_attribute.name == "cStringIO"
    assert module_attribute.old_mod == "cStringIO"
    assert module_attribute.new_mod == "io"
    assert module_attribute.old_attr == "StringIO"
    assert module_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:57:02.659233
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod')
    assert(move.new_mod == 'new_mod')
    assert(move.name == 'name')
    assert(move.new_attr == 'name')
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert(move.new_attr == 'old_attr')

# Generated at 2022-06-12 03:57:05.715265
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("name", "old_mod", "new_mod")
    assert moved.name == "name"
    assert moved.new_mod == "new_mod"
    assert moved.new_attr == moved.name


# Generated at 2022-06-12 03:57:07.279772
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites
    t.finalize()
    assert t.rewrites

# Generated at 2022-06-12 03:57:16.315482
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule('name', 'old')
    assert t.name == 'name'
    assert t.old == 'old'
    assert t.new == 'name'

    t = MovedModule('name', 'old', 'new')
    assert t.name == 'name'
    assert t.old == 'old'
    assert t.new == 'new'

    t = MovedModule('name', 'old', 'new')
    assert t.name == 'name'
    assert t.old == 'old'
    assert t.new == 'new'

    with pytest.raises(TypeError):
        t = MovedModule()

    with pytest.raises(TypeError):
        t = MovedModule('name', 'old', 'new', 'extra')



# Generated at 2022-06-12 03:57:23.016798
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    rewrites = transformer.rewrites
    assert rewrites['io.StringIO'] == 'six.moves.cStringIO.StringIO'
    assert rewrites['builtins.filter'] == 'six.moves.filter'
    assert rewrites['itertools.filterfalse'] == 'six.moves.filterfalse'
    assert rewrites['builtins.input'] == 'six.moves.input'
    assert rewrites['sys.intern'] == 'six.moves.intern'
    assert rewrites['builtins.map'] == 'six.moves.map'
    assert rewrites['os.getcwd'] == 'six.moves.getcwd'

# Generated at 2022-06-12 03:57:27.795451
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("a", "b")
    b = MovedModule("a", "b", "c")
    assert a.name == "a"
    assert a.new == "a"
    assert b.name == "a"
    assert b.new == "c"
    assert a.old == "b"
    assert b.old == "b"

# Generated at 2022-06-12 03:58:27.984158
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-12 03:58:31.491833
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old', 'new').old == 'old'


# Generated at 2022-06-12 03:58:33.302896
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('Tkinter', 'Tkinter')

# Generated at 2022-06-12 03:58:35.342305
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("Module", "old")
    assert move.name == "Module"
    assert move.new == "Module"


# Generated at 2022-06-12 03:58:38.998419
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'


# Generated at 2022-06-12 03:58:41.415440
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule('a', 'b')
    assert t
    assert t.name == 'a'
    assert t.new == 'b'
    assert t.old == 'b'


# Generated at 2022-06-12 03:58:49.692418
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 56
    assert len(_urllib_parse_moved_attributes) == 23
    assert len(_urllib_error_moved_attributes) == 3
    assert len(_urllib_request_moved_attributes) == 37
    assert len(_urllib_response_moved_attributes) == 4
    assert len(_urllib_robotparser_moved_attributes) == 1
    assert _urllib_parse_moved_attributes[0].name == "ParseResult"
    assert _urllib_parse_moved_attributes[0].new_mod == "urllib.parse"
    assert _urllib_parse_moved_attributes[0].new_attr == "ParseResult"
    assert _urll

# Generated at 2022-06-12 03:58:56.267579
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    sys.stderr.write("Testing %s\n" % __file__)

    if sys.version_info[0] == 2:
        # check if we have moved stuff
        assert SixMovesTransformer.rewrites
        # check if it's a copy
        assert SixMovesTransformer.rewrites is not _get_rewrites()
        # check if we have the right number of stuff
        assert len(SixMovesTransformer.rewrites) == len(_get_rewrites())
        for item in SixMovesTransformer.rewrites:
            # check if we have the right item
            assert item in _get_rewrites()

# Generated at 2022-06-12 03:58:58.886816
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves = _get_rewrites()
    s = SixMovesTransformer(moves=moves)
    assert s.moves == moves

# Generated at 2022-06-12 03:59:04.061489
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('abc', '123', '456')
    assert obj.name == 'abc'
    assert obj.new_mod == '456'
    assert obj.new_attr == 'abc'
    obj = MovedAttribute('abc', '123', '456', 'def', 'ghi')
    assert obj.name == 'abc'
    assert obj.new_mod == '456'
    assert obj.new_attr == 'ghi'