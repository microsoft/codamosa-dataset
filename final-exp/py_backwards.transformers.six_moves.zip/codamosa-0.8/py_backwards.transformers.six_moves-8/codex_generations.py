

# Generated at 2022-06-12 03:50:47.496557
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that the SixMovesTransformer constructor works as expected"""
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert len(t.rewrites) == len(_get_rewrites())

# Generated at 2022-06-12 03:50:56.148170
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests SixMovesTransformer"""
    from ..examples.six_moves import class_test
    result = SixMovesTransformer.run_transformation(class_test)
    assert result.code == class_test_transformed



# Generated at 2022-06-12 03:51:03.058451
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mv.name == "cStringIO"
    assert mv.new_mod == "io"
    assert mv.new_attr == "StringIO"
    mv = MovedAttribute("cStringIO", "cStringIO", "io")
    assert mv.new_attr == "cStringIO"

# Generated at 2022-06-12 03:51:09.825294
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert (path, 'six.moves{}.{}'.format(prefix, move.name)) in _get_rewrites()

            elif isinstance(move, MovedModule):
                path = move.new
                assert (path, 'six.moves{}.{}'.format(prefix, move.name)) in _get_rewrites()

# Generated at 2022-06-12 03:51:15.152473
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from astroid import test_utils
    from transform import sixmoves
    module = test_utils.build_module("from six.moves import urllib as uh")
    assert isinstance(module, astroid.Module)

    r = sixmoves.SixMovesTransformer(module)
    assert isinstance(r, astroid.Module)


# Generated at 2022-06-12 03:51:27.564808
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    class MovedAttribute:
        def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
            self.name = name
            if new_mod is None:
                new_mod = name
            self.new_mod = new_mod
            if new_attr is None:
                if old_attr is None:
                    new_attr = name
                else:
                    new_attr = old_attr
            self.new_attr = new_attr

        def to_dict(self):
            return {
                'name': self.name,
                'old_mod': self.old_mod,
                'new_mod': self.new_mod,
                'old_attr': self.old_attr,
                'new_attr': self.new_attr,
            }

   

# Generated at 2022-06-12 03:51:34.358505
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import SixMovesTransformer

    # Test with exact version
    t = SixMovesTransformer(target=(2, 7))
    assert t.target == (2, 7)

    # Test with partial version
    t = SixMovesTransformer(target=(2, 7, 0))
    assert t.target == (2, 7)

    # Test with default target
    t = SixMovesTransformer()
    assert t.target == (2, 7)



# Generated at 2022-06-12 03:51:37.525623
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    assert moved_module.old == "__builtin__"

# Generated at 2022-06-12 03:51:40.644705
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "WINK")
    assert a.name == 'cStringIO'
    assert a.new_mod == 'io'
    assert a.new_attr == 'WINK'

# Generated at 2022-06-12 03:51:52.586669
# Unit test for constructor of class MovedModule
def test_MovedModule():
    inp = "from six.moves import configparser as six_moves_configparser"
    inp_output = "from six.moves import configparser"
    out = "from configparser import configparser"
    mm = MovedModule("configparser", "ConfigParser")
    assert mm.name == "configparser"
    assert mm.old == "ConfigParser"
    assert mm.new == "configparser"
    assert MovedModule("name", "old", "new").new == "new"
    assert mm.rewrite(inp) == inp_output
    assert mm.translate(out) == inp_output
    assert mm.is_moved_module("configparser")
    assert mm.is_moved_module("CONFIGPARSER") is False

# Generated at 2022-06-12 03:52:02.404623
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'module', 'new_module', 'attr', 'new_attr') == MovedAttribute('name', 'module', 'new_module', 'attr', 'new_attr')
    assert MovedAttribute('name', 'module', 'new_module', 'attr', 'new_attr') != MovedAttribute('name', 'module', 'new_module', 'attr', 'other_new_attr')
    assert MovedAttribute('name', 'module', 'new_module', 'attr', 'new_attr') != MovedAttribute('name', 'module', 'new_module', 'other_attr', 'new_attr')
    assert MovedAttribute('name', 'module', 'new_module', 'attr', 'new_attr') != MovedAttribute('name', 'module', 'other_new_module', 'attr', 'new_attr')
   

# Generated at 2022-06-12 03:52:04.244348
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('name', 'old', 'new')
    assert module.name == 'name'
    assert module.new == 'new'

# Generated at 2022-06-12 03:52:12.357198
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # without new
    move1 = MovedModule('builtins', '__builtin__')
    assert move1.name == 'builtins'
    assert move1.old == '__builtin__'
    assert move1.new == 'builtins'
    # with new
    move2 = MovedModule('builtins', '__builtin__', 'builtins')
    assert move2.name == 'builtins'
    assert move2.old == '__builtin__'
    assert move2.new == 'builtins'



# Generated at 2022-06-12 03:52:15.113491
# Unit test for constructor of class MovedModule
def test_MovedModule():
    for module in _moved_attributes:
        if isinstance(module, MovedModule):
            assert module.name == module.new



# Generated at 2022-06-12 03:52:19.116046
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # type: () -> None
    mov = MovedModule('name', 'old', 'new')
    assert mov.name == "name"
    assert mov.old == "old"
    assert mov.new == "new"



# Generated at 2022-06-12 03:52:32.131050
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attributes = [
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"),
        MovedAttribute("cStringIO", None, "io", "StringIO"),
        MovedAttribute("cStringIO", "cStringIO", None, "StringIO"),
        MovedAttribute("cStringIO", None, None, "StringIO"),
        MovedAttribute("cStringIO", "cStringIO", "io", None),
        MovedAttribute("cStringIO", None, "io", None),
        MovedAttribute(None, None, None, None),
    ]
    assert moved_attributes[0].name == "cStringIO"
    assert moved_attributes[0].old_mod == "cStringIO"
    assert moved_attributes[0].new_mod == "io"
    assert moved_

# Generated at 2022-06-12 03:52:34.992141
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class Dog:
        def bark(self):
            return "Woof!"
    d = Dog()
    assert d.bark() == "Woof!"

# Generated at 2022-06-12 03:52:37.852170
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from .. import rewrites  # we are not actually importing from rewrites
    rewrites.MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')



# Generated at 2022-06-12 03:52:42.475382
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the constructor SixMovesTransformer"""
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert ('{}.{}'.format(path, move.new_attr),
                        'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves{}.{}'.format(prefix, move.name)) in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:52:50.805583
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "getcwd"
    old_mod = "os"
    new_mod = "os"
    old_attr = "getcwdu"
    new_attr = "getcwd"
    name2 = "getcwdb"
    old_mod2 = "os"
    new_mod2 = "os"
    old_attr2 = "getcwd"
    new_attr2 = "getcwdb"
    assert MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert MovedAttribute(name2, old_mod2, new_mod2, old_attr2, new_attr2)



# Generated at 2022-06-12 03:52:55.688351
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    """ Tests that SixMovesTransformer constructor doesn't raise an exception """
    SixMovesTransformer()

# Generated at 2022-06-12 03:52:57.728330
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for a, b in SixMovesTransformer.rewrites:
        print(a, b)

# Generated at 2022-06-12 03:52:59.803779
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) >= 100

# Generated at 2022-06-12 03:53:05.489817
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of class SixMovesTransformer."""


# Generated at 2022-06-12 03:53:08.924820
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")

    assert item.name == "cStringIO"
    assert item.new_mod == "io"
    assert item.new_attr == "StringIO"


# Generated at 2022-06-12 03:53:10.171739
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')


# Generated at 2022-06-12 03:53:14.213933
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name='test', old='test', new='test')
    assert moved_module.old == 'test'
    assert moved_module.new == 'test'
    assert moved_module.name == 'test'


# Generated at 2022-06-12 03:53:22.345832
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = 'name'
    old_mod = 'old_mod'
    new_mod = 'new_mod'
    old_attr = 'old_attr'
    new_attr = 'new_attr'
    moved_attr = MovedAttribute(name, old_mod, new_mod, old_attr, new_attr)
    assert moved_attr.name == name
    assert moved_attr.new_mod == new_mod
    assert moved_attr.new_attr == new_attr

    moved_attr = MovedAttribute(name, old_mod, new_mod)
    assert moved_attr.name == name
    assert moved_attr.new_mod == name
    assert moved_attr.new_attr == name

    moved_attr = MovedAttribute(name, old_mod, new_mod, old_attr)
    assert moved_

# Generated at 2022-06-12 03:53:33.611863
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from importlib import import_module
    from textwrap import dedent
    from ..api import run_import_rewrite
    from ..tests import assert_transformer_output

    def check(code, expected, *args):
        assert_transformer_output(SixMovesTransformer, code, expected, *args)

    # Test that the imports are being rewritten to include the right moves
    check(dedent("""
        import ConfigParser as configparser
        import Tix as tkinter_tix
        import _winreg
    """), dedent("""
        import six.moves.configparser as configparser
        import six.moves.tkinter_tix
        import six.moves._winreg
    """), 'six')

    # Test that moved attributes are being rewritten to the right imports

# Generated at 2022-06-12 03:53:39.349905
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", "old", "new")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "new"
    # Check that new is set by default to name
    obj = MovedModule("name", "old")
    assert obj.new == "name"


# Generated at 2022-06-12 03:53:57.112471
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # set up variables
    test_name = 'test_name'
    test_old_mod = 'test_old_mod'
    test_new_mod = 'test_new_mod'
    test_old_attr = 'test_old_attr'
    test_new_attr = 'test_new_attr'

    # constructor with no optional parameters
    test_moved_attr = MovedAttribute(test_name, test_old_mod, test_new_mod)
    assert test_moved_attr.name == test_name
    assert test_moved_attr.new_mod == test_new_mod
    assert test_moved_attr.new_attr == test_name

    # constructor with both optional parameters

# Generated at 2022-06-12 03:54:00.055020
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("foo", "bar", "quux", "old", "new")
    assert x.name == "foo"
    assert x.new_mod == "quux"
    assert x.new_attr == "new"


# Generated at 2022-06-12 03:54:06.333978
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("__builtin__", "__builtin__")
    assert move.name == "__builtin__"
    assert move.new == "__builtin__"
    move = MovedModule("__builtin__", "__builtin__", "builtins")
    assert move.name == "__builtin__"
    assert move.new == "builtins"


# Generated at 2022-06-12 03:54:15.883896
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute("parse_qs", "urlparse", "urllib.parse")
    assert mv.name == "parse_qs"
    assert mv.old_mod == "urlparse"
    assert mv.new_mod == "urllib.parse"
    assert mv.old_attr == "parse_qs"
    assert mv.new_attr == "parse_qs"
    mv = MovedAttribute("parse_qsl", "urlparse", "urllib.parse", "parse_qsl", "parse_qsl")
    assert mv.name == "parse_qsl"
    assert mv.old_mod == "urlparse"
    assert mv.new_mod == "urllib.parse"
    assert mv.old_attr == "parse_qsl"
    assert m

# Generated at 2022-06-12 03:54:25.647325
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = MovedModule("tkinter", "Tkinter")
    assert moves.name == "tkinter"
    assert moves.new == "tkinter"
    assert moves.old == "Tkinter"

    moves = MovedModule("tkinter", "Tkinter", "tk")
    assert moves.name == "tkinter"
    assert moves.new == "tk"
    assert moves.old == "Tkinter"

    moves = MovedModule("tkinter", "Tkinter", new="tk")
    assert moves.name == "tkinter"
    assert moves.new == "tk"
    assert moves.old == "Tkinter"



# Generated at 2022-06-12 03:54:29.332223
# Unit test for constructor of class MovedModule
def test_MovedModule():
    class_object = MovedModule("name", "old", "new")
    assert class_object.name == "name"
    assert class_object.old == "old"
    assert class_object.new == "new"


# Generated at 2022-06-12 03:54:40.095988
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old") == MovedModule("name", "old", "name")
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").old == "old"
    assert MovedModule("name", "old", "new").new == "new"

# Generated at 2022-06-12 03:54:44.611174
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm_object = MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server")
    assert mm_object.name == "CGIHTTPServer"
    assert mm_object.new == "http.server"

# Generated at 2022-06-12 03:54:54.421216
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-12 03:55:00.336037
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    '''Test SixMovesTransformer.__init__()'''

    # Test that SixMovesTransformer constructor returns a SixMovesTransformer object
    transformer = SixMovesTransformer()
    assert isinstance(transformer, SixMovesTransformer)
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:55:22.714936
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer(None, None)
    assert x.target == (2, 7)
    assert len(x.rewrites) >= 22
    assert sorted(x.rewrites)[0] == ('collections.UserDict', 'six.moves.UserDict')
    assert x.dependencies == ['six']

if __name__ == '__main__':
    from logging import basicConfig, DEBUG, ERROR
    basicConfig(level=ERROR)
    for x in _moved_attributes:
        print(x)
    for x in _urllib_parse_moved_attributes:
        print(x)
    for x in _urllib_error_moved_attributes:
        print(x)

# Generated at 2022-06-12 03:55:25.882787
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("x", "y")
    assert m.name == "x"
    assert m.new == "x"
    assert m.old == "y"


# Generated at 2022-06-12 03:55:30.947113
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "new_mod", "old_mod", "new_attr", "old_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"
    move2 = MovedAttribute("name", "new_mod", "old_mod")
    assert move2.name == "name"
    assert move2.new_mod == "name"
    assert move2.new_attr == "name"

# Generated at 2022-06-12 03:55:42.451099
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a1 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    a2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", None)
    a3 = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    a4 = MovedAttribute("name", "old_mod", "new_mod", None, None)

    assert a1.name == "name"
    assert a1.new_mod == "new_mod"
    assert a1.new_attr == "new_attr"

    assert a2.name == "name"
    assert a2.new_mod == "new_mod"
    assert a2.new_attr == "old_attr"


# Generated at 2022-06-12 03:55:52.706447
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """This tests the basic class constructor with transforms to replace moved modules with ones from six.moves.

    The constructor of class SixMovesTransformer is tested.
    """
    smt = SixMovesTransformer()

    assert smt.target == (2, 7)

    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert ('{}.{}'.format(path, move.new_attr), 'six.moves{}.{}'.format(prefix, move.name)) in smt.rewrites

# Generated at 2022-06-12 03:55:58.367793
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    for path, full_name in transformer.rewrites:
        try:
            mod = eval('__import__("{}")'.format(path))
            assert mod is not None
        except ImportError:
            raise AssertionError('Expected {} to exist'.format(full_name))
    assert transformer.dependencies == ["six"]

# Generated at 2022-06-12 03:56:06.996682
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:13.182147
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:19.746102
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib3to2.tests.test_all_fixers import lib3to2FixerTestCase


# Generated at 2022-06-12 03:56:24.177203
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "test_name"
    old = "test_old"
    new = "test_new"
    mm = MovedModule(name, old, new)
    assert mm.name == name
    assert mm.new == new
    mm = MovedModule(name, old)
    assert mm.name == name
    assert mm.new == old

# Generated at 2022-06-12 03:56:49.936203
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").__dict__ == {'name': 'builtins', 'old': '__builtin__', 'new': 'builtins'}

# Generated at 2022-06-12 03:56:51.138314
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    pass


# Code to test the move of properties

# Generated at 2022-06-12 03:56:55.520374
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'import six.moves.urllib.parse as urllib_parse' in \
           str(SixMovesTransformer('import urllib.parse as urllib_parse'))
    assert 'import six.moves as six_moves' in \
           str(SixMovesTransformer('import six.moves as six_moves'))


# Generated at 2022-06-12 03:57:01.836342
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"
    attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "cStringIO"


# Generated at 2022-06-12 03:57:06.996339
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old', 'new')
    assert ma.new_mod == 'new', 'Expected \'new\' instead of \'%s\'.' % ma.new_mod
    assert ma.new_attr == 'name', 'Expected \'name\' instead of \'%s\'.' % ma.new_attr
    assert ma.name == 'name', 'Expected \'name\' instead of \'%s\'.' % ma.name


# Generated at 2022-06-12 03:57:10.555429
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_data = [
        ('Tkinter', 'tkinter'),
        ('tkinter', 'tkinter')
    ]

    for old, new in test_data:
        module = MovedModule(old, new)
        assert module.name == old
        assert module.new == new

# Generated at 2022-06-12 03:57:17.004764
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('name', 'old')
    assert x.name == 'name'
    assert x.old == 'old'
    assert x.new == 'name'

    x = MovedModule('name', 'old', 'new')
    assert x.name == 'name'
    assert x.old == 'old'
    assert x.new == 'new'

    x = MovedModule('name', 'old', None)
    assert x.name == 'name'
    assert x.old == 'old'
    assert x.new == 'name'

# Generated at 2022-06-12 03:57:23.353710
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    trans = SixMovesTransformer()

# Generated at 2022-06-12 03:57:32.932077
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"


# Generated at 2022-06-12 03:57:42.576729
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    ma2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma2.name == "cStringIO"
    assert ma2.new_mod == "io"
    assert ma2.new_attr == "cStringIO"
    ma3 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "newStringIO")
    assert ma3.name == "cStringIO"
    assert ma3.new_mod == "io"
    assert ma3.new_attr == "newStringIO"


# Generated at 2022-06-12 03:58:46.141304
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moves = [MovedAttribute(i, j, k) for i, j, k in (('a', 'b', 'c'), ('a', 'b', 'b'))]
    assert moves[0].name == 'a'
    assert moves[0].old_mod == 'b'
    assert moves[0].new_mod == 'c'
    assert moves[0].new_attr == 'a'

    assert moves[1].name == 'a'
    assert moves[1].old_mod == 'b'
    assert moves[1].new_mod == 'b'
    assert moves[1].new_attr == 'a'


# Generated at 2022-06-12 03:58:47.688774
# Unit test for constructor of class MovedModule
def test_MovedModule():
    e = MovedModule("name", "old", "new")
    assert isinstance(e, MovedModule)

# Generated at 2022-06-12 03:58:49.318975
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert len(t.rewrites) == len(_get_rewrites())

# Generated at 2022-06-12 03:58:50.417564
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-12 03:58:51.607200
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == _get_rewrites()

# Generated at 2022-06-12 03:58:54.685906
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-12 03:58:58.845107
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    t = SixMovesTransformer(sys.modules[__name__])


# ########################

if __name__ == "__main__":
    # Run the unit tests
    import sys

    t = SixMovesTransformer(sys.modules[__name__])
    t.run_tests()

# Generated at 2022-06-12 03:59:00.029136
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:59:10.558779
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:59:12.022780
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for a, b in _get_rewrites():
        assert a == b