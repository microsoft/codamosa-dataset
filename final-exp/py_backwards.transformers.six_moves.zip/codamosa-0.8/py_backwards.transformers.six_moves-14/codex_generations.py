

# Generated at 2022-06-12 03:50:52.814522
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
    Test the SixMovesTransformer
    """
    rewrites = _get_rewrites()

    # Check that no rewrites are empty
    for rewrite in rewrites:
        assert rewrite[0]
        assert rewrite[1]

# Generated at 2022-06-12 03:50:56.697471
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser", "foo").new == "foo"


# Generated at 2022-06-12 03:50:59.780054
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_case = MovedModule('test', 'old_name', 'new_name')
    assert test_case.name == 'test'
    assert test_case.new == 'new_name'



# Generated at 2022-06-12 03:51:05.942599
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mo = MovedModule('y', 'x')
    assert mo.new == 'y'
    assert mo.name == 'y'
    assert mo.old == 'x'

    mo = MovedModule('y', 'x', 'z')
    assert mo.new == 'z'
    assert mo.name == 'y'
    assert mo.old == 'x'



# Generated at 2022-06-12 03:51:13.163579
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:51:16.268735
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import builtins
    assert isinstance(builtins, MovedModule)
    assert isinstance(builtins, object)



# Generated at 2022-06-12 03:51:25.088013
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m1 = MovedAttribute('name', 'old_mod', 'new_mod')
    assert m1.name == 'name'
    assert m1.new_mod == 'new_mod'
    assert m1.new_attr == 'name'

    m2 = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert m2.name == 'name'
    assert m2.new_mod == 'new_mod'
    assert m2.new_attr == 'new_attr'



# Generated at 2022-06-12 03:51:31.102559
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("foo", "bar")
    assert m.name == "foo"
    assert m.old == "bar"
    assert m.new == "foo"

    m = MovedModule("foo", "bar", "baz")
    assert m.name == "foo"
    assert m.old == "bar"
    assert m.new == "baz"


# Generated at 2022-06-12 03:51:33.044050
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mod = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert mod.name == "cStringIO"
    assert mod.new_mod == "io"
    assert mod.new_attr == "StringIO"

# Generated at 2022-06-12 03:51:35.456648
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor."""
    transformer = SixMovesTransformer()
    assert transformer
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']



# Generated at 2022-06-12 03:51:40.194646
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-12 03:51:40.829394
# Unit test for constructor of class MovedModule
def test_MovedModule():
    pass

# Generated at 2022-06-12 03:51:43.345816
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    print(rewrites)

# Generated at 2022-06-12 03:51:48.932092
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("a", "b", "c", "d", "e")
    assert m.name == "a"
    assert m.new_mod == "c"
    assert m.new_attr == "e"
    m2 = MovedAttribute("a", "b", "c")
    assert m2.new_attr == "a"


# Generated at 2022-06-12 03:51:58.122513
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mv_obj = MovedModule("builtins", "__builtin__")
    assert mv_obj.name == "builtins"
    assert mv_obj.new == "builtins"
    assert mv_obj.old is None
    mv_obj = MovedModule("builtins", "__builtin__", "__builtin__")
    assert mv_obj.name == "builtins"
    assert mv_obj.new == "__builtin__"
    assert mv_obj.old is None
    with pytest.raises(TypeError) as exc:
        mv_obj = MovedModule("builtins", "__builtin__", new_name="__builtin__")
    assert 'MovedModule takes no keyword arguments' in str(exc)

# Generated at 2022-06-12 03:52:03.977864
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # This is just to make sure we are working with the class
    # as defined in six, not one of our own (because it's
    # called MovedAttribute).
    assert six.MovedAttribute.__module__ == 'six'
    assert six.MovedAttribute("name", "old_mod", "new_mod")
    assert six.MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    with pytest.raises(TypeError):
        six.MovedAttribute("name", "old_mod")



# Generated at 2022-06-12 03:52:15.793982
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:52:17.329976
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) > 0

# Generated at 2022-06-12 03:52:21.721467
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"

# Generated at 2022-06-12 03:52:34.623997
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'

    attr = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'cStringIO'

    attr = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 's')
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 's'



# Generated at 2022-06-12 03:52:46.382098
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import unittest
    import tempfile
    import shutil

    from .utils import rewrap_source

    from ..contrib.sixmoves import SixMovesTransformer

    class TestSixMovesTransformer(unittest.TestCase):
        def setUp(self):
            self.d = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.d)

        def write_file(self, filename, text):
            filename = os.path.join(self.d, filename)
            with open(filename, 'w') as f:
                f.write(text)
            return filename

        def test_simple_import(self):
            code = """
            import os
            os.getcwd()
            """

# Generated at 2022-06-12 03:52:48.133630
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    c = SixMovesTransformer
    assert c.rewrites == frozenset(_get_rewrites())

# Generated at 2022-06-12 03:52:52.459610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute(name="filter", old_mod="itertools", new_mod="builtins",
                           old_attr="ifilter", new_attr="filter")
    assert move1.name == "filter"
    assert move1.new_mod == "builtins"
    assert move1.new_attr == "filter"



# Generated at 2022-06-12 03:53:00.911486
# Unit test for constructor of class MovedModule
def test_MovedModule():
    err_msg = "name must be a string!"
    with pytest.raises(TypeError, match=err_msg):
        _ = MovedModule(1, "asdf")
    err_msg = "new must be a string!"
    with pytest.raises(TypeError, match=err_msg):
        _ = MovedModule("asdf", 1)
    err_msg = "old must be a string!"
    with pytest.raises(TypeError, match=err_msg):
        _ = MovedModule("asdf", "asdf", 1)



# Generated at 2022-06-12 03:53:12.820648
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer('')

# Generated at 2022-06-12 03:53:13.903048
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()


# Generated at 2022-06-12 03:53:21.248486
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("abc", "abc", "abc")
    assert ma.name == "abc"
    assert ma.new_mod == "abc"
    assert ma.new_attr == "abc"

    ma = MovedAttribute("abc", "abc", "abc", "def")
    assert ma.name == "abc"
    assert ma.new_mod == "abc"
    assert ma.new_attr == "def"

    ma = MovedAttribute("abc", "abc", "abc", "def", "geh")
    assert ma.name == "abc"
    assert ma.new_mod == "abc"
    assert ma.new_attr == "geh"

# Generated at 2022-06-12 03:53:32.618025
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:53:43.974014
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")\
        .new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")\
        .name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")\
        .new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")\
        .new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")\
        .name == "cStringIO"
   

# Generated at 2022-06-12 03:53:50.600448
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('abc', 'from_mod', 'to_mod')
    assert a.name == 'abc'
    assert a.new_mod == 'to_mod'
    assert a.new_attr == 'abc'
    a = MovedAttribute('abc', 'from_mod', 'to_mod', 'from_attr', 'to_attr')
    assert a.new_attr == 'to_attr'

# Generated at 2022-06-12 03:53:57.335049
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("new_module", "old_module")
    assert mm.name == "new_module"
    assert mm.new == "new_module"
    assert mm.old == "old_module"


# Generated at 2022-06-12 03:54:00.672343
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("name", "old", "new")
    assert test_module.name == "name"
    assert test_module.old == "old"
    assert test_module.new == "new"

# Generated at 2022-06-12 03:54:12.108705
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("name", "old_mod", "old_attr", "new_mod", "new_attr")
    assert item.name == "name"
    assert item.new_mod == "new_mod"
    assert item.new_attr == "new_attr"
    item = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert item.name == "name"
    assert item.new_mod == "new_mod"
    assert item.new_attr == "new_attr"
    item = MovedAttribute("name", "old_mod", "old_attr", "new_mod")
    assert item.name == "name"
    assert item.new_mod == "new_mod"
    assert item.new_attr == "old_attr"


# Generated at 2022-06-12 03:54:22.770917
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test initialization of class
    moves_transformer = SixMovesTransformer()

    # Test that move transformers are generated properly
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedModule):
                assert moves_transformer.rewrites.get(move.new) == 'six.moves{}.{}'.format(prefix, move.name)
            elif isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert moves_transformer.rewrites.get(path) == 'six.moves{}.{}'.format(prefix, move.name)

# Generated at 2022-06-12 03:54:25.502399
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "name"

# Generated at 2022-06-12 03:54:27.974030
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").to_import == "six.moves.builtins"



# Generated at 2022-06-12 03:54:35.032915
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("winreg", "_winreg")
    assert moved_module.name == "winreg"
    assert moved_module.new == "_winreg"
    moved_module = MovedModule("builtins", "__builtin__", "builtins")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"


# Generated at 2022-06-12 03:54:37.637623
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("tkinter", "Tkinter")
    assert a.name == "tkinter"
    assert a.new == "tkinter"

# Generated at 2022-06-12 03:54:42.126092
# Unit test for constructor of class MovedModule
def test_MovedModule():
    source = "from six.moves import queue"
    module = MovedModule("Queue", "Queue")
    assert module.name == "Queue"
    assert module.old == "Queue"
    assert module.new == "queue"



# Generated at 2022-06-12 03:54:48.442124
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedmodule = MovedModule("name", "old", "new")
    assert movedmodule.name == "name"
    assert movedmodule.old == "old"
    assert movedmodule.new == "new"
    movedmodule = MovedModule("name", "old")
    assert movedmodule.name == "name"
    assert movedmodule.old == "old"
    assert movedmodule.new == "name"


# Generated at 2022-06-12 03:55:03.100736
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """
    Simple test case
    """
    a = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert a.name == 'cStringIO'
    assert a.new_mod == 'io'
    assert a.new_attr == 'StringIO'

    b = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert b.name == 'cStringIO'
    assert b.new_mod == 'io'
    assert b.new_attr == 'StringIO'

    c = MovedAttribute('cStringIO', 'cStringIO', 'io', None, 'StringIO')
    assert c.name == 'cStringIO'
    assert c.new_mod == 'io'
    assert c.new_attr == 'StringIO'

# Generated at 2022-06-12 03:55:06.496834
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "cStringIO"
    assert attr.new_attr == "StringIO"

# Generated at 2022-06-12 03:55:10.298545
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'



# Generated at 2022-06-12 03:55:12.918832
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("ConfigParser", "ConfigParser", "configparser")
    assert move.name == "ConfigParser"
    assert move.new == "configparser"

# Generated at 2022-06-12 03:55:15.727730
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.name == "name"
    assert mm.new == "name"
    assert mm.old == "old"

# Generated at 2022-06-12 03:55:19.956168
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule(name="tkinter", old="Tkinter", new="tkinter")
    assert moved_module.name == "tkinter"
    assert moved_module.new == "tkinter"
    assert moved_module.old == 'Tkinter'

# Generated at 2022-06-12 03:55:29.799995
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.refactor import RefactoringTool
    from libmodernize.fixes.fix_six_moves import SixMovesTransformer
    from libmodernize import module_util
    from textwrap import dedent
    import unittest
    import six

    class TestSixMovesTransformer(unittest.TestCase):
        def test_run_simple(self):
            unittest.TestCase.maxDiff = None
            s = dedent('''
            import os.path
            import os.path
            import os.path
            import time
            ''')
            t = dedent('''
            import os
            import os.path
            import os.path
            import time
            ''')

# Generated at 2022-06-12 03:55:32.389575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule('test', 'test1', 'test2')
    assert test.name == 'test'
    assert test.new == 'test2'


# Generated at 2022-06-12 03:55:42.836244
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test = SixMovesTransformer(('six.moves', 'http.cookies', 'http.cookies.CookieJar', 'CookieJar'))
    assert test.rewrites == [
        ('six.moves', 'six'),
        ('six.moves.http_cookies', 'http.cookies'),
        ('six.moves.http_cookies.CookieJar', 'http.cookies.CookieJar'),
        ('six.moves.http_cookies.CookieJar', 'CookieJar'),
        ('http.cookies.CookieJar', 'http.cookies.CookieJar'),
        ('http.cookies.CookieJar', 'CookieJar'),
        ('CookieJar', 'CookieJar')
    ]

# Generated at 2022-06-12 03:55:45.626239
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for path, expected in _get_rewrites():
        assert path, '{} does not match any six.moves from 2.7'.format(path)



# Generated at 2022-06-12 03:56:06.664912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-12 03:56:09.718082
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("name", "old")
    assert mod.name == "name"
    assert mod.new == "name"
    assert mod.old == "old"
    mod = MovedModule("name", "old", "new")
    assert mod.name == "name"
    assert mod.old == "old"
    assert mod.new == "new"



# Generated at 2022-06-12 03:56:12.161540
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-12 03:56:14.341127
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves
    from lib2to3.fixes import fix_six_moves
    assert set(fix_six_moves._SixMovesTransformer.rewrites.keys()) == set(dir(six.moves))

# Generated at 2022-06-12 03:56:20.671509
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3.pgen2 import token
    from lib2to3 import pytree
    from libfuturize.fixes.six_moves import SixMovesTransformer
    #
    s = 'from six.moves import configparser\n'
    t = SixMovesTransformer().transform(pytree.parse(s), 0)
    assert t.next_term(0).next_term(1).next_term(0).type == token.NAME and \
           t.next_term(0).next_term(1).next_term(0).value == 'configparser'
    #
    s = 'from six.moves import configparser as cg'
    t = SixMovesTransformer().transform(pytree.parse(s), 0)

# Generated at 2022-06-12 03:56:26.798711
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test', 'test').name == 'test'
    assert MovedModule('test', 'test').new == 'test'
    assert MovedModule('test', 'test2').name == 'test'
    assert MovedModule('test', 'test2').new == 'test2'
    assert MovedModule('test', 'test2', 'test3').name == 'test'
    assert MovedModule('test', 'test2', 'test3').new == 'test3'


# Generated at 2022-06-12 03:56:32.941629
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.old == "old"
    assert a.new == "new"
    b = MovedModule("name1", "old1")
    assert b.name == "name1"
    assert b.old == "old1"
    assert b.new == "name1"
    c = MovedModule("name2")
    assert c.name == "name2"
    assert c.old == "name2"
    assert c.new == "name2"


# Generated at 2022-06-12 03:56:34.198097
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer()

# Generated at 2022-06-12 03:56:40.676731
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert_equal(MovedAttribute("execute", "dbm_gnu", None, "execute", "execute").name, "execute")
    assert_equal(MovedAttribute("execute", "dbm_gnu", None, "execute", "execute").new_mod, "dbm_gnu")
    assert_equal(MovedAttribute("execute", "dbm_gnu", None, "execute", "execute").new_attr, "execute")



# Generated at 2022-06-12 03:56:45.372679
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'builtins'
    old = '__builtin__'
    new = name
    m = MovedModule(name, old, new)
    assert getattr(m, 'name') == name
    assert getattr(m, 'old') == old
    assert getattr(m, 'new') == new



# Generated at 2022-06-12 03:57:18.953599
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move1.name == "cStringIO"
    assert move1.new_mod == 'io'
    assert move1.new_attr == 'StringIO'
    assert move1.old_attr is None
    assert str(move1) == ("<MovedAttribute: "
                          "six.moves.cStringIO -> six.moves.io.StringIO>")

    move2 = MovedAttribute("cStringIO", "cStringIO", "io", None, "new_stringio")
    assert move2.name == "cStringIO"
    assert move2.new_mod == 'io'
    assert move2.new_attr == 'new_stringio'
    assert move2.old_attr is None
   

# Generated at 2022-06-12 03:57:28.023456
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # TypeError should be raised if name is a non-string
    with pytest.raises(TypeError):
        MovedModule(1, "ab")
    # TypeError should be raised if old is a non-string
    with pytest.raises(TypeError):
        MovedModule("ab", 1)
    # TypeError should be raised if new is a non-string
    with pytest.raises(TypeError):
        MovedModule("ab", "cd", 1)
    # Test if function works with correct inputs
    m_module = MovedModule("ab", "cd", "ef")
    assert m_module.name == "ab"
    assert m_module.old == "cd"
    assert m_module.new == "ef"
    # Test if new is set to name if not specified
    m_module = Moved

# Generated at 2022-06-12 03:57:29.701817
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:57:33.295047
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-12 03:57:39.250746
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_mv = MovedAttribute(name = 'test_name', old_mod = 'test_oldmod', new_mod = 'test_newmod', old_attr = 'test_oldattr', new_attr = 'test_newattr')
    assert test_mv.name == 'test_name'
    assert test_mv.new_mod == 'test_newmod'
    assert test_mv.new_attr == 'test_newattr'

# Generated at 2022-06-12 03:57:41.455399
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with open('tests/stubs/six.pyi', 'r') as stubs:
        s = SixMovesTransformer(stubs, {}).rewrite('stub')
        assert s == 'six.moves'

# Generated at 2022-06-12 03:57:47.726400
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mov = MovedAttribute("name", "mod", "new_mod")
    assert mov.name == "name"
    assert mov.new_mod == "new_mod"
    assert mov.new_attr == "name"

    mov = MovedAttribute("name", "mod", "new_mod", "attr")
    assert mov.name == "name"
    assert mov.new_mod == "new_mod"
    assert mov.new_attr == "attr"

    mov = MovedAttribute("name", "mod", "new_mod", "attr", "new_attr")
    assert mov.name == "name"
    assert mov.new_mod == "new_mod"
    assert mov.new_attr == "new_attr"



# Generated at 2022-06-12 03:57:50.106740
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 90

# Generated at 2022-06-12 03:57:55.794075
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    test_rewrites = []
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                test_rewrites.append((path, 'six.moves{}.{}'.format(prefix, move.name)))
            elif isinstance(move, MovedModule):
                test_rewrites.append((move.new, 'six.moves{}.{}'.format(prefix, move.name)))
    assert transformer.rewrites == test_rewrites

# Generated at 2022-06-12 03:58:01.695477
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old') == MovedModule('name', 'old', 'name')
    assert MovedModule('name', 'old') == MovedModule('name', 'old', None)
    assert MovedModule('name', 'old') == MovedModule('name', 'old', '')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'old', 'other')
    assert MovedModule('name', 'old', 'new') != MovedModule('other', 'old', 'new')

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:59:06.536317
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old')
    assert m.name == 'name'
    assert m.new == 'name'
    m = MovedModule('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new == 'new'

# Generated at 2022-06-12 03:59:16.488566
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    import six.moves
    for module in prefixed_moves:
        for move in module[1]:
            expected_attr = move.name
            if isinstance(move, MovedModule):
                mod_name = move.new.replace('.', '_')
            elif isinstance(move, MovedAttribute):
                mod_name = move.new_mod.replace('.', '_')
            else:
                assert False, "No support for this move"
            attr = getattr(six.moves, mod_name)
            expected_attr = move.name
            if isinstance(move, MovedModule):
                if attr != getattr(six.moves, move.name):
                    assert False, "MovedModule constructor error"

# Generated at 2022-06-12 03:59:18.105527
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0
    for rewrite in _get_rewrites():
        print(rewrite)


# Generated at 2022-06-12 03:59:24.454852
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('a', 'b', 'c')
    assert m.name == 'a'
    assert m.old == 'b'
    assert m.new == 'c'

    m = MovedModule('a', 'b')
    assert m.name == 'a'
    assert m.old == 'b'
    assert m.new == 'a'

    m = MovedModule('a')
    assert m.name == 'a'
    assert m.old == 'a'
    assert m.new == 'a'

# Generated at 2022-06-12 03:59:29.114647
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert ('urllib', 'urllib', 'urllib') == MovedModule('urllib', 'urllib').__dict__
    assert ('urllib', 'urllib', 'urllib.robotparser') == MovedModule('urllib', 'urllib', 'urllib.robotparser').__dict__

# Generated at 2022-06-12 03:59:30.556782
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 39

# Generated at 2022-06-12 03:59:33.957708
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move=MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name=='name'
    assert move.new_mod=='new_mod'
    assert move.new_attr=='new_attr'


# Generated at 2022-06-12 03:59:35.530730
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from six.moves import xrange
    assert xrange is range  # noqa: F821

# Generated at 2022-06-12 03:59:40.141716
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('queue', 'Queue')
    y = MovedModule('queue', 'Queue', 'queue')
    assert x.name == 'queue'
    assert x.old == 'Queue'
    assert x.new == 'queue'
    assert y.name == 'queue'
    assert y.old == 'Queue'
    assert y.new == 'queue'


# Generated at 2022-06-12 03:59:43.928595
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "new_mod", "old_mod")
    assert(ma.name == "name")
    assert(ma.new_mod == "new_mod")
    assert(ma.new_attr == "name")
    assert(ma.new_mod == "new_mod")

