

# Generated at 2022-06-12 03:50:45.987226
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'oldmodule', 'newmodule') == \
            MovedAttribute('name', 'oldmodule', 'newmodule', 'name', 'name')
    assert MovedAttribute('name', 'oldmodule', 'newmodule', 'oldattr', 'newattr') == \
            MovedAttribute('name', 'oldmodule', 'newmodule', 'oldattr', 'newattr')

# Generated at 2022-06-12 03:50:53.598832
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    rewrites = t.rewrites
    for renamed_module in ('dbm_gnu', 'tkinter_dialog', 'urllib.response'):
        assert not any([renamed_module in path for path, repl in rewrites])
    for renamed_attr in ('dbm.gnu', 'tkinter.dialog', 'urllib.response'):
        assert not any([renamed_attr in repl for path, repl in rewrites])
    assert (False, 'six.moves.tkinter_dialog') in rewrites
    assert (True, 'six.moves.urllib.response') in rewrites
    assert (True, 'six.moves.urllib.parse') in rewrites

# Generated at 2022-06-12 03:50:55.676707
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:50:57.809984
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite
    SixMovesTransformer()
    assert isinstance(BaseImportRewrite.rewrites, dict)

# Generated at 2022-06-12 03:51:05.429347
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'name'
    old = 'foo'
    new = 'bar'
    mod = MovedModule(name, old, new)
    assert mod.name == 'name'
    assert mod.old == 'foo'
    assert mod.new == 'bar'
    mod = MovedModule(name, old)
    assert mod.name == 'name'
    assert mod.old == 'foo'
    assert mod.new == 'name'



# Generated at 2022-06-12 03:51:11.910755
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=import-outside-toplevel
    from ..automaton import Automaton
    from ..parser import PythonParser
    from ..tokenizer import PythonTokenizer
    from ..transformers import SixMovesTransformer
    # pylint: enable=import-outside-toplevel
    parser = PythonParser(
        tokenizer=PythonTokenizer(),
        transformers=[SixMovesTransformer])
    parser.parse(
        """
        """
    )
    automaton = parser.make_automaton()
    assert isinstance(automaton, Automaton)

# Generated at 2022-06-12 03:51:19.965145
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c').name == 'a'
    assert MovedAttribute('a', 'b', 'c').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c').new_attr == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'
    assert MovedAttribute('a', 'b', 'c', 'd').new_attr == 'd'



# Generated at 2022-06-12 03:51:25.639709
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import ast
    m = ast.parse('import six.moves.urllib.parse as parse')
    assert m is not None
    r = SixMovesTransformer(m)
    r.transform()
    r.optimize()
    assert ast.dump(m) == ast.dump(ast.parse('import six'))

# Generated at 2022-06-12 03:51:27.615542
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves = _get_rewrites()
    assert moves


transformer = SixMovesTransformer

# Generated at 2022-06-12 03:51:38.020549
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test the constructor for class MovedModule."""
    # By default, name = new = new_mod = old = old_mod
    test_1 = MovedModule('test')
    assert test_1.name == 'test'
    assert test_1.new == 'test'
    assert test_1.new_mod == 'test'
    assert test_1.old == 'test'
    assert test_1.old_mod == 'test'

    # The 'old' module can be defined
    test_2 = MovedModule('test', 'old_test')
    assert test_2.name == 'test'
    assert test_2.new == 'test'
    assert test_2.new_mod == 'test'
    assert test_2.old == 'old_test'

# Generated at 2022-06-12 03:51:40.733550
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer([], SRC_DIR, DST_DIR, {})

# Generated at 2022-06-12 03:51:46.228774
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.target == (2, 7)
    assert six_moves_transformer.dependencies == ['six']
    assert len(six_moves_transformer.rewrites) == 141

# Generated at 2022-06-12 03:51:52.167659
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    m2 = MovedModule("name2", "old2")
    assert m2.name == "name2"
    assert m2.old == "old2"
    assert m2.new == "name2"


# Generated at 2022-06-12 03:51:55.290418
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-12 03:51:58.485924
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    s = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert s.name == 'cStringIO'
    assert s.new_mod == 'io'
    assert s.new_attr == 'StringIO'

# Generated at 2022-06-12 03:52:05.506688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"
    assert MovedAttribute("winreg", "_winreg").name == "winreg"
    assert MovedAttribute("winreg", "_winreg").new_mod == "winreg"
    assert MovedAttribute("winreg", "_winreg").new_attr == "winreg"


# Generated at 2022-06-12 03:52:17.569342
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old', 'new').name == 'name'
    assert MovedAttribute('name', 'old', 'new').old_mod == 'old'
    assert MovedAttribute('name', 'old', 'new').new_mod == 'new'
    assert MovedAttribute('name', 'old', 'new').old_attr == 'name'
    assert MovedAttribute('name', 'old', 'new').new_attr == 'name'
    assert MovedAttribute('name', 'old', 'new', 'old_attr', 'new_attr').old_attr == 'old_attr'
    assert MovedAttribute('name', 'old', 'new', 'old_attr', 'new_attr').new_attr == 'new_attr'

# Generated at 2022-06-12 03:52:30.937508
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('name', 'old_mod', 'new_mod')
    assert obj.name == 'name'
    assert obj.new_mod == 'new_mod'
    assert obj.new_attr == 'name'
    assert str(obj) == "Attribute 'name' moved from 'old_mod' to 'new_mod'."
    obj = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert obj.new_attr == 'old_attr'
    assert str(obj) == ("Attribute 'name' moved from 'old_mod' to 'new_mod'. "
                        "Rename 'old_attr' to 'name'.")
    obj = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert obj.new_

# Generated at 2022-06-12 03:52:38.880346
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves

# Generated at 2022-06-12 03:52:41.012332
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('argv', 'oldmod', 'newmod', 'oldattr', 'newattr')
    assert m.name == 'argv'
    assert m.new_mod == 'newmod'
    assert m.new_attr == 'newattr'


# Generated at 2022-06-12 03:52:48.740175
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'



# Generated at 2022-06-12 03:52:58.364228
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    # print(rewrites)
    assert len(rewrites) == 155
    assert rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert rewrites[1] == ('builtins.filter', 'six.moves.filter')
    assert rewrites[2] == ('__builtin__.raw_input', 'six.moves.input')
    assert rewrites[3] == ('sys.intern', 'six.moves.intern')
    assert rewrites[4] == ('os.getcwdb', 'six.moves.getcwdb')
    assert rewrites[5] == ('subprocess.getstatusoutput', 'six.moves.getstatusoutput')

# Generated at 2022-06-12 03:53:05.841893
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("name", "old")
    assert x.name == "name"
    assert x.old == "old"
    assert x.new == "name"
    x = MovedModule("name", "old", "new")
    assert x.name == "name"
    assert x.old == "old"
    assert x.new == "new"



# Generated at 2022-06-12 03:53:13.131384
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # The dependency check is for the "six" module. Always works.
    # The rewrites checks are for the test of whether the rewrites are correct.
    # This "six" module is built for Python 2.7, so the checks will always work.
    # pylint: disable=unused-import
    from lib2to3 import refactor
    from libfuturize.fixes import fix_six_moves_imports
    refactoring_tool = refactor.RefactoringTool([fix_six_moves_imports])
    fixes = refactoring_tool.get_fixers_from_package('libfuturize.fixes')
    six_moves_transformer = fixes[0]
    assert six_moves_transformer.target == (2, 7)
    rewrites = six_moves_

# Generated at 2022-06-12 03:53:15.919569
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for move in _moved_attributes:
        assert 'six.moves.{}'.format(move.name) == MovedAttribute(*move).name



# Generated at 2022-06-12 03:53:21.719988
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert move.new_attr == 'old_attr'
    move = MovedAttribute('name', 'old_mod', 'new_mod')
    assert move.new_attr == 'name'

# Generated at 2022-06-12 03:53:27.442073
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test = MovedModule("name", "old")
    assert test.name == "name"
    assert test.old == "old"
    assert test.new == "name"

    test = MovedModule("name", "old", "new")
    assert test.name == "name"
    assert test.old == "old"
    assert test.new == "new"



# Generated at 2022-06-12 03:53:31.783331
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = 'name'
    old = 'old'
    new = 'new'
    m = MovedModule(name, old, new)
    assert m.name == name
    assert m.old == old
    assert m.new == new


# Generated at 2022-06-12 03:53:33.914696
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("tkinter", "Tkinter")
    assert module.name == "tkinter"
    assert module.new == "tkinter"
    assert module.old == "Tkinter"

# Generated at 2022-06-12 03:53:45.617403
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer = SixMovesTransformer()
    assert six_moves_transformer.target == (2, 7)
    assert six_moves_transformer.dependencies == ['six']

# Generated at 2022-06-12 03:53:53.480400
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:53:58.543896
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

    # check conditions for class variables
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']

    # check conditions for variables in init method
    assert transformer.rewrites == _get_rewrites()


# A test for rewrite method of class SixMovesTransformer

# Generated at 2022-06-12 03:54:02.956110
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _six_moves_rewrites = _get_rewrites()
    _six_moves = SixMovesTransformer()
    assert _six_moves.rewrites == _six_moves_rewrites
    assert _six_moves.target == (2, 7)

# Generated at 2022-06-12 03:54:10.132466
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError) as ex:
        MovedAttribute("cStringIO")
    assert str(ex.value) == "__init__() missing 2 required positional arguments: 'old_mod' and 'new_mod'"

    with pytest.raises(TypeError) as ex:
        MovedAttribute("cStringIO", "cStringIO", "io")
    assert str(ex.value) == "__init__() missing 1 required positional argument: 'old_attr'"

# Generated at 2022-06-12 03:54:22.231942
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import six.moves.urllib.robotparser
    transformer = SixMovesTransformer()
    assert repr(transformer) == '<SixMovesTransformer>'
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)
    print(transformer.rewrites)
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:54:25.834388
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.source == (2, 7)
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:54:31.649479
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test whether the constructor of class SixMovesTransformer works

    The constructor of class SixMovesTransformer should provide
    a class attribute named rewrites.
    """

    obj = SixMovesTransformer(None)
    # pylint: disable=no-member
    assert isinstance(obj.rewrites, tuple)

# Generated at 2022-06-12 03:54:38.838874
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    method_name = 'foo'
    old_mod = 'oldmod'
    new_mod = 'newmod'
    old_attr = 'oldattr'
    new_attr = 'newattr'
    ma = MovedAttribute(method_name, old_mod, new_mod, old_attr, new_attr)
    assert method_name == ma.name
    assert new_mod == ma.new_mod
    assert new_attr == ma.new_attr


# Generated at 2022-06-12 03:54:42.663523
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_test = MovedModule("test", "old", "new")
    assert module_test.name == "test"
    assert module_test.old == "old"
    assert module_test.new == "new"

# Generated at 2022-06-12 03:54:46.274477
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the constructor of class SixMovesTransformer."""
    transformer = SixMovesTransformer(None)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:54:53.345474
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Create object
    assert MovedModule('name', 'old', 'new') is not None

# Generated at 2022-06-12 03:54:56.276154
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert attr.name == 'input'
    assert attr.new_mod == 'builtins'
    assert attr.new_attr == 'input'

# Generated at 2022-06-12 03:55:05.034757
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:55:10.386372
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'foo'

    mm = MovedModule('foo', 'bar', 'zoo')
    assert mm.name == 'foo'
    assert mm.old == 'bar'
    assert mm.new == 'zoo'



# Generated at 2022-06-12 03:55:21.292443
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mod = MovedAttribute("mod", "old_module", "new_module")
    assert mod.name == "mod"
    assert mod.old_mod == "old_module"
    assert mod.new_mod == "new_module"
    assert mod.old_attr == None
    assert mod.new_attr == "mod"

    mod = MovedAttribute("mod", "old_module", "new_module", "foo", "bar")
    assert mod.name == "mod"
    assert mod.old_mod == "old_module"
    assert mod.new_mod == "new_module"
    assert mod.old_attr == "foo"
    assert mod.new_attr == "bar"

    mod = MovedAttribute("mod", "old_module", "new_module", "foo")

# Generated at 2022-06-12 03:55:25.752997
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"



# Generated at 2022-06-12 03:55:35.189139
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO').new_attr == 'StringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').name == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').new_mod == 'io'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io').new_attr == 'cStringIO'
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'cStringIO').name

# Generated at 2022-06-12 03:55:39.555041
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test.name == "cStringIO"
    assert test.new_mod == "io"
    assert test.new_attr == "StringIO"

# Generated at 2022-06-12 03:55:46.537282
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', None, 'mod').new_mod == 'mod'
    assert MovedAttribute('name', None, None).new_mod == 'name'
    assert MovedAttribute('name', 'mod').new_mod == 'name'
    assert MovedAttribute('name', 'mod', old_attr='old_attr').new_attr == 'old_attr'
    assert MovedAttribute('name', 'mod', new_attr='new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'mod', 'mod', 'old_attr').new_attr == 'old_attr'

# Generated at 2022-06-12 03:55:51.463002
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-12 03:56:09.796073
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a=MovedAttribute(name='abc', old_mod='abc', new_mod='abc')
    assert a.name == 'abc'
    assert a.new_mod == 'abc'
    assert a.new_attr == 'abc'

    b=MovedAttribute(name='abc', old_mod='abc', new_mod='abc', new_attr='ab')
    assert b.name == 'abc'
    assert b.new_mod == 'abc'
    assert b.new_attr == 'ab'

    c=MovedAttribute(name='abc', old_mod='abc', new_mod='abc', old_attr='ab')
    assert c.name == 'abc'
    assert c.new_mod == 'abc'
    assert c.new_attr == 'ab'


# Generated at 2022-06-12 03:56:13.393064
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule("test", "test", "test")
    assert test_moved_module.name == "test"
    assert test_moved_module.new == "test"
    test_moved_module = MovedModule("test", "test")
    assert test_moved_module.name == "test"
    assert test_moved_module.new == "test"


# Generated at 2022-06-12 03:56:15.616775
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_name = 'test_name'
    test_mod = 'test_module'
    test = MovedAttribute(test_name, None, test_mod)

    assert test.name == test_name
    assert test.new_mod == test_mod

# Generated at 2022-06-12 03:56:21.668129
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"



# Generated at 2022-06-12 03:56:23.767227
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    six_moves_transformer=SixMovesTransformer()   
    assert six_moves_transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:56:25.827264
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert len(transformer.rewrites) == 92

# Generated at 2022-06-12 03:56:33.253244
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    settings = {
        "deprecation_analysis_script.deprecated_modules": ""
    }
    code = """
from six.moves.urllib.request import urlopen
from six.moves.urllib.parse import quote
"""
    result = """
from six.moves import urllib.request as _six_moves_urllib_request
from six.moves import urllib.parse as _six_moves_urllib_parse
urlopen = _six_moves_urllib_request.urlopen
quote = _six_moves_urllib_parse.quote
"""
    trans = SixMovesTransformer(settings=settings)
    trans.verify(code, result)

# Generated at 2022-06-12 03:56:34.934979
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # this test fails if the constructor of SixMovesTransformer is called
    assert True

# Generated at 2022-06-12 03:56:45.495996
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo", "bar", "blah", "a", "b") == \
        MovedAttribute("foo", "bar", "blah", "a", "b")
    # Different name
    assert MovedAttribute("foo", "bar", "blah", "a", "b") != \
        MovedAttribute("boo", "bar", "blah", "a", "b")
    # Different module
    assert MovedAttribute("foo", "bar", "blah", "a", "b") != \
        MovedAttribute("foo", "car", "blah", "a", "b")
    # Different attribute
    assert MovedAttribute("foo", "bar", "blah", "a", "b") != \
        MovedAttribute("foo", "bar", "blah", "b", "b")
    # Different

# Generated at 2022-06-12 03:56:48.517280
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("test", "test", "test")
    assert move.name == "test"
    assert move.new_mod == "test"
    assert move.new_attr == "test"


# Generated at 2022-06-12 03:57:20.897257
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_module", "new_module")
    assert ma.name == "name"
    assert ma.new_mod == "new_module"
    assert ma.new_attr == "name"

    ma = MovedAttribute("name", "old_module", "new_module", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_module"
    assert ma.new_attr == "new_attr"

    ma = MovedAttribute("name", "old_module", "new_module", "old_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_module"
    assert ma.new_attr == "old_attr"



# Generated at 2022-06-12 03:57:30.446127
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for path, mod in _get_rewrites():
        assert transform_imports(path, optimizations={'SixMovesTransformer': True}) == mod
    assert transform_imports('configparser', optimizations={'SixMovesTransformer': True}) == 'six.moves.configparser'
    assert transform_imports('urllib.parse.urlparse', optimizations={'SixMovesTransformer': True}) == 'six.moves.urllib_parse.urlparse'
    assert transform_imports('urllib.parse.ParseResult', optimizations={'SixMovesTransformer': True}) == 'six.moves.urllib_parse.ParseResult'


if __name__ == '__main__':
    # Unit test for constructor of class SixMovesTransformer
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:57:35.196666
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    name = "Name"
    attr = MovedAttribute(name, "OldMod", "NewMod")

    assert attr.name == name
    assert attr.old_mod == "OldMod"
    assert attr.new_mod == "NewMod"
    assert attr.old_attr == name
    assert attr.new_attr == name


# Generated at 2022-06-12 03:57:44.544376
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("attrname", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "attrname"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"
    attr = MovedAttribute("attrname", "old_mod", "new_mod")
    assert attr.name == "attrname"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "attrname"
    attr = MovedAttribute("attrname", "old_mod", "new_mod", "old_attr")
    assert attr.name == "attrname"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr

# Generated at 2022-06-12 03:57:47.688559
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'


# Generated at 2022-06-12 03:57:50.062614
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:57:56.978576
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('mod_name', 'old_name').name == 'mod_name'
    assert MovedModule('mod_name1', 'old_name').name == 'mod_name1'
    assert MovedModule('mod_name2', 'old_name').name == 'mod_name2'
    assert MovedModule('mod_name3', 'old_name', 'new_name').new == 'new_name'
    assert MovedModule('mod_name4', 'old_name', 'new_name').new == 'new_name'
    assert MovedModule('mod_name5', 'old_name', 'new_name').new == 'new_name'
    assert MovedModule('mod_name6', 'old_name', 'new_name').new == 'new_name'



# Generated at 2022-06-12 03:58:06.416230
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    def check(name, old_mod, new_mod, old_attr, new_attr):
        assert MovedAttribute(name, old_mod, new_mod, old_attr, new_attr).name == name
        assert MovedAttribute(name, old_mod, new_mod, old_attr, new_attr).old_mod == old_mod
        assert MovedAttribute(name, old_mod, new_mod, old_attr, new_attr).new_mod == new_mod
        assert MovedAttribute(name, old_mod, new_mod, old_attr, new_attr).old_attr == old_attr
        assert MovedAttribute(name, old_mod, new_mod, old_attr, new_attr).new_attr == new_attr


# Generated at 2022-06-12 03:58:15.767598
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import Import
    from .base import NoQName
    from .base import print_tree
    from .base import BaseImportRewrite
    from .base import PretendModule
    from .base import AbsoluteImport
    from .base import RelativeImport
    from .base import DottedModuleName
    from .base import DottedName
    from .base import Name
    from .base import NodeTransformer
    from .base import RelativeImport
    # call the constructor of class SixMovesTransformer
    SixMovesTransformer()
    # call the constructor of class BaseImportRewrite
    BaseImportRewrite()
    # call the constructor of class AbsoluteImport
    AbsoluteImport()
    # call the constructor of class RelativeImport
    RelativeImport()
    # call the constructor of class DottedModuleName

# Generated at 2022-06-12 03:58:19.009260
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('moved', 'old')
    assert move.name == 'moved'
    assert move.new == 'moved'
    assert move.old == 'old'


# Generated at 2022-06-12 03:59:26.132054
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("configparser", "ConfigParser").old == "ConfigParser"
    assert MovedModule("tkinter", "Tkinter").old == "Tkinter"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("tkinter", "Tkinter").new == "tkinter"



# Generated at 2022-06-12 03:59:32.052482
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'


# Generated at 2022-06-12 03:59:34.829491
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import libmodernize
    import libmodernize.fixes.fix_six_moves
    assert isinstance(libmodernize.fixes.fix_six_moves.SixMovesTransformer, type)
test_SixMovesTransformer()

# Generated at 2022-06-12 03:59:43.970343
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:59:49.296265
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('a', 'b', 'c').new == 'c'
    assert MovedModule('a', 'b', 'c').name == 'a'
    assert MovedModule('a', 'b').new == 'a'
    assert MovedModule('a', 'b').name == 'a'


# Generated at 2022-06-12 03:59:57.897932
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert(ma.name == "cStringIO")
    assert(ma.new_mod == "io")
    assert(ma.new_attr == "StringIO")
    ma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert(ma.name == "cStringIO")
    assert(ma.new_mod == "io")
    assert(ma.new_attr == "cStringIO")
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "CStringIO")
    assert(ma.name == "cStringIO")
    assert(ma.new_mod == "io")
    assert(ma.new_attr == "CStringIO")

# Unit test

# Generated at 2022-06-12 04:00:00.760804
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.old == "__builtin__"
    assert move.new == "builtins"


# Generated at 2022-06-12 04:00:04.472645
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('a', 'b', 'c')
    assert mm.name =='a'
    assert mm.old == 'b'
    assert mm.new == 'c'

    mm = MovedModule('a')
    assert mm.name == 'a'
    assert mm.old == 'a'
    assert mm.new == 'a'


# Generated at 2022-06-12 04:00:07.832492
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_moved_module = MovedModule("name", "old", "new")
    assert test_moved_module.name == "name"
    assert test_moved_module.old == "old"
    assert test_moved_module.new == "new"


# Generated at 2022-06-12 04:00:11.775945
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").new == "foo"
    assert MovedModule("foo", "bar").old == "bar"
    assert MovedModule("foo", "bar", "baz").new == "baz"