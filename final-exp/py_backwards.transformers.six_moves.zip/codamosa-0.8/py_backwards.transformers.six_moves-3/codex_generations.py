

# Generated at 2022-06-12 03:50:51.740145
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    if type(SixMovesTransformer.rewrites) == types.GeneratorType:
        raise TypeError('Generator instead of eager list')

# Generated at 2022-06-12 03:51:02.953504
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == 'io'
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", None).new_attr == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", None).name == 'cStringIO'
    assert MovedAttribute("cStringIO", "cStringIO", None).new_mod == 'cStringIO'


# Generated at 2022-06-12 03:51:05.344632
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    import six
    m = MovedAttribute("foo", "bar", "baz", "1", "2")
    assert m.name == "foo"
    assert m.new_mod == "baz"
    assert m.new_attr == "2"


# Generated at 2022-06-12 03:51:13.183415
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", None)
    assert(a.name == "cStringIO")
    assert(a.new_mod == "io")
    assert(a.new_attr == "StringIO")
    a = MovedAttribute("cStringIO", "cStringIO", "io", None, None)
    assert(a.name == "cStringIO")
    assert(a.new_mod == "io")
    assert(a.new_attr == "cStringIO")
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "Input")
    assert(a.name == "cStringIO")
    assert(a.new_mod == "io")
    assert(a.new_attr == "Input")
    a

# Generated at 2022-06-12 03:51:25.425058
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").name == "copyreg"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").name == "dbm_gnu"
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu").new == "dbm.gnu"

# Generated at 2022-06-12 03:51:31.054953
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule('old_module', 'old_module')
    assert m1.name == 'old_module'
    assert m1.new == 'old_module'
    m1 = MovedModule('old_module', 'old_module', 'new_module')
    assert m1.name == 'old_module'
    assert m1.new == 'new_module'

# Generated at 2022-06-12 03:51:39.493827
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO", "Wrong name property"
    assert m.new_mod == "io", "Wrong new_mod property"
    assert m.new_attr == "StringIO", "Wrong new_attr property"

    m = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    assert m.name == "getcwd", "Wrong name property"
    assert m.new_mod == "os", "Wrong new_mod property"
    assert m.new_attr == "getcwdu", "Wrong new_attr property"

# Generated at 2022-06-12 03:51:46.006128
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("mystical_meaning_of_life", "my_life", "mystical_life")
    assert a.name == "mystical_meaning_of_life"
    assert a.new == "mystical_life"

    # No need to test further, as the other variables are initialized
    # in the constructor in the same way as in the other test.

# Generated at 2022-06-12 03:51:48.098737
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    im = SixMovesTransformer()
    assert im.rewrites == _get_rewrites()



# Generated at 2022-06-12 03:51:57.838277
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()
    assert st.target == (2, 7)
    assert not isinstance(st.rewrites, list)

# Generated at 2022-06-12 03:52:01.703539
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("foo.bar", "foo.baz")
    assert move.name == "foo.bar"
    assert move.old == "foo.baz"
    assert move.new == "foo.bar"

# Generated at 2022-06-12 03:52:10.262030
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new') == MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old') == MovedModule('name', 'old')
    assert MovedModule('name', 'old', 'old') == MovedModule('name', 'old')
    assert MovedModule('name', 'old', 'new') != MovedModule('other', 'old', 'new')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'other', 'new')
    assert MovedModule('name', 'old', 'new') != MovedModule('name', 'old', 'other')

# Generated at 2022-06-12 03:52:11.849010
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer.rewrites  # make sure it is initialized

# Generated at 2022-06-12 03:52:17.676835
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('new', 'old')
    assert a.name is 'new'
    assert a.new is 'new'
    assert a.old is 'old'
    b = MovedModule('test', 'foo', 'bar')
    assert b.name is 'test'
    assert b.new is 'bar'
    assert b.old is 'foo'

# Generated at 2022-06-12 03:52:23.273301
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    mv = MovedAttribute('unicode', 'six.moves', 'six.moves.builtins', 'u', 'text_type')
    assert mv.name == 'unicode'
    assert mv.new_mod == 'six.moves.builtins'
    assert mv.new_attr == 'text_type'


# Generated at 2022-06-12 03:52:28.594114
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m=MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name=="cStringIO"
    assert m.new_mod=="io"
    assert m.new_attr=="StringIO"

# Generated at 2022-06-12 03:52:37.763901
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("foo", "bar", "bar")
    assert move.name == "foo"
    assert move.new_mod == "bar"
    assert move.new_attr == "foo"

    move = MovedAttribute("foo", "bar", "bar", "foo", "bar")
    assert move.name == "foo"
    assert move.new_mod == "bar"
    assert move.new_attr == "bar"

    move = MovedAttribute("foo", "bar", "bar", "bar", "foo")
    assert move.name == "foo"
    assert move.new_mod == "bar"
    assert move.new_attr == "foo"

    move = MovedAttribute("foo", "bar", "bar", None, None)
    assert move.name == "foo"
    assert move.new_mod

# Generated at 2022-06-12 03:52:41.880949
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('test', 'old_name')
    assert module.name == 'test'
    assert module.new == 'test'
    module = MovedModule('test', 'old_name', 'new_name')
    assert module.name == 'test'
    assert module.new == 'new_name'

# Generated at 2022-06-12 03:52:46.180329
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert test_move.name == "name"
    assert test_move.new_mod == "new_mod"
    assert test_move.new_attr == "new_attr"

# Generated at 2022-06-12 03:52:50.139996
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "mod", "new_mod").name == "name"
    assert MovedAttribute("name", "mod", "new_mod").new_mod == "new_mod"
    assert MovedAttribute("name", "mod", "new_mod").new_attr == "name"
    assert MovedAttribute("name", "mod", "new_mod", "attr", "new_attr").new_attr == "new_attr"


# Generated at 2022-06-12 03:52:55.472530
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'foo', 'foo')
    assert mm.name == 'foo'
    assert mm.old == 'foo'
    assert mm.new == 'foo'

# Generated at 2022-06-12 03:52:57.934561
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that the constructor produces the expected rewrites."""
    transformer = SixMovesTransformer()
    assert len(transformer.rewrites) == 520

# Generated at 2022-06-12 03:53:10.636153
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import six as six_module
    from .six.moves import builtins as builtins_move
    from .six.moves import urllib
    from .six.moves.urllib.parse import parse_qs as parse_qs_move
    from .six.moves.urllib.error import URLError as URLError_move
    from .six.moves.urllib.request import urlopen as urlopen_move
    from .six.moves.urllib.request import URLopener as URLopener_move
    from .six.moves.urllib.response import addinfo as addinfo_move

    assert import_module('six') is six_module

    assert import_module('builtins') is builtins_move
    assert import_module('urllib') is urllib


# Generated at 2022-06-12 03:53:20.383428
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('x', 'y', 'z').name == 'x'
    assert MovedAttribute('x', 'y', 'z').new_mod == 'z'
    assert MovedAttribute('x', 'y', 'z', 'u').new_attr == 'u'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').old_mod == 'b'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').old_attr == 'd'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_

# Generated at 2022-06-12 03:53:25.065228
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("test", "test", "test2")
    assert move.name == "test"
    assert move.new == "test2"

    move = MovedModule("test", "test")
    assert move.name == "test"
    assert move.new == "test"


# Generated at 2022-06-12 03:53:33.524372
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('sys', 'sys')
    assert mm.name == 'sys'
    assert mm.new == 'sys'
    mm = MovedModule('sys', 'sys', 'sys')
    assert mm.name == 'sys'
    assert mm.new == 'sys'
    mm = MovedModule('sys', 'sys', 'sys_')
    assert mm.name == 'sys'
    assert mm.new == 'sys_'
    mm = MovedModule('sys', 'sys_')
    assert mm.name == 'sys'
    assert mm.new == 'sys'


# Generated at 2022-06-12 03:53:37.453028
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("name", old="old", new="new")
    assert obj.name == "name"
    assert obj.old == "old"
    assert obj.new == "new"



# Generated at 2022-06-12 03:53:41.596831
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    objMovedAttribute = MovedAttribute("join", "os", "os", "string", "join")
    assert objMovedAttribute.name == "join"
    assert objMovedAttribute.new_mod == "os"
    assert objMovedAttribute.new_attr == "join"

# Generated at 2022-06-12 03:53:45.092422
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("urllib.parse", "urllib2")
    x = MovedModule("urllib.parse", "urlparse", "urllib.parse")
    assert module.name == x.name


# Generated at 2022-06-12 03:53:47.114930
# Unit test for constructor of class MovedModule
def test_MovedModule():
  foo = MovedModule("name", "old")
  assert foo is not None


# Generated at 2022-06-12 03:53:54.632988
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s
    assert s.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:53:58.017993
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites['builtins.filter'] == 'six.moves.filter'
    assert transformer.rewrites['ConfigParser'] == 'six.moves.configparser'

# Generated at 2022-06-12 03:54:08.451810
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a1 = MovedAttribute("a", "b", "c")
    assert a1.name == "a"
    assert a1.new_mod == "c"
    assert a1.new_attr == "a"
    a2 = MovedAttribute("a", "b", "c", "d", "e")
    assert a2.name == "a"
    assert a2.new_mod == "c"
    assert a2.new_attr == "e"
    a3 = MovedAttribute("a", "b", "c", "d")
    assert a3.name == "a"
    assert a3.new_mod == "c"
    assert a3.new_attr == "d"

# Generated at 2022-06-12 03:54:17.071296
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"

    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

    # if no old_attr is given, new_attr is taken from name
    assert MovedAttribute("range", "__builtin__", "builtins", None, None).new_attr == "range"

    # if no new_mod is given, new_mod is taken from name
    assert MovedAttribute

# Generated at 2022-06-12 03:54:23.700653
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('a', 'c').name == 'a'
    assert MovedModule('a', 'c').old == 'c'
    assert MovedModule('a', 'c').new == 'a'
    assert MovedModule('a', 'c', 'b').name == 'a'
    assert MovedModule('a', 'c', 'b').old == 'c'
    assert MovedModule('a', 'c', 'b').new == 'b'

# Generated at 2022-06-12 03:54:27.813824
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.name == "name"
    assert move.new_mod == "new_mod"
    assert move.new_attr == "new_attr"

# Generated at 2022-06-12 03:54:40.714870
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:54:44.307044
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'



# Generated at 2022-06-12 03:54:47.466692
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.new == "new"


# Generated at 2022-06-12 03:54:49.671704
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('queue', 'Queue')
    assert 'Queue' == module.name
    assert 'queue' == module.new


# Generated at 2022-06-12 03:55:03.924486
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"


# Generated at 2022-06-12 03:55:07.865374
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:55:18.500447
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("foo", "bar", "baz") == \
           MovedAttribute("foo", "bar", "baz", "foo", "foo")
    assert MovedAttribute("foo", "bar", "baz", "foo") == \
           MovedAttribute("foo", "bar", "baz", "foo", "foo")
    assert MovedAttribute("foo", "bar", "baz", new_attr="foo") == \
           MovedAttribute("foo", "bar", "baz", "foo", "foo")
    assert MovedAttribute("foo", "bar", "baz", old_attr="foo") == \
           MovedAttribute("foo", "bar", "baz", "foo", "foo")
    assert MovedAttribute("foo", "bar", "baz", "foo", "bar") == \
           MovedAttribute

# Generated at 2022-06-12 03:55:28.805674
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'StringIO'
    m = MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert m.name == 'filter'
    assert m.new_mod == 'builtins'
    assert m.new_attr == 'filter'
    m = MovedAttribute('input', '__builtin__', 'builtins', 'raw_input', 'input')
    assert m.name == 'input'
    assert m.new_mod == 'builtins'
    assert m.new_attr == 'input'

# Generated at 2022-06-12 03:55:30.432860
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:55:38.849092
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    from .base import BaseImportRewrite
    from ..py2to3 import tools
    from ..py2to3 import refactor

    transformer = SixMovesTransformer(tools.OutputOptions(None))
    assert isinstance(transformer, BaseImportRewrite)

    transformer = SixMovesTransformer(None)
    assert isinstance(transformer, BaseImportRewrite)

    transformer = SixMovesTransformer(refactor.RefactoringTool())
    assert isinstance(transformer, BaseImportRewrite)



# Generated at 2022-06-12 03:55:42.488855
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("test", "test1", "test2", "test3", "test4")
    assert ma.name == "test"
    assert ma.new_mod == "test2"
    assert ma.new_attr == "test4"


# Generated at 2022-06-12 03:55:43.730413
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    str(SixMovesTransformer)

# Generated at 2022-06-12 03:55:46.657517
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("tkinter", "Tkinter")
    assert move.name == "tkinter"
    assert move.new == "tkinter"
    assert move.old == "Tkinter"

# Generated at 2022-06-12 03:55:50.528234
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("builtins", "__builtin__")
    assert obj.name == "builtins"
    assert obj.old == "__builtin__"
    assert obj.new == "builtins"



# Generated at 2022-06-12 03:56:16.686385
# Unit test for constructor of class MovedModule
def test_MovedModule():
    t = MovedModule('foo', 'bar')
    assert t.name == 'foo'
    assert t.old == 'bar'
    assert t.new == 'foo'
    t = MovedModule('foo', 'bar', 'baz')
    assert t.name == 'foo'
    assert t.old == 'bar'
    assert t.new == 'baz'

# Generated at 2022-06-12 03:56:19.527729
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mv = MovedModule("builtins", "__builtin__")
    assert mv.name == "builtins"

    mv = MovedModule("builtins", "__builtin__", "builtins")
    assert mv.new == "builtins"


# Unit tests for SixMovesTransformer tests

# Generated at 2022-06-12 03:56:21.767518
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule("name", "old")
    assert moved.name == "name"
    assert moved.new == "name"

# Generated at 2022-06-12 03:56:23.081258
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('c', 'c', None, None, None)


# Generated at 2022-06-12 03:56:24.502651
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(set(_get_rewrites()))

# Generated at 2022-06-12 03:56:32.223007
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=unexpected-keyword-arg
    assert MovedAttribute("test", "test", None).new_attr == "test"
    assert MovedAttribute("test", "test", None).new_mod == "test"
    assert MovedAttribute("test", "test", "test2").new_mod == "test2"
    assert MovedAttribute("test", "test", "test2",
                          "test3").new_attr == "test3"
    assert MovedAttribute("test", "test", None,
                          "test4", "test5").new_attr == "test4"
    assert MovedAttribute("test", "test", None,
                          "test6").new_attr == "test6"

# Generated at 2022-06-12 03:56:44.182797
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod")
    assert move.name == "name"
    assert move.old_mod == "old_mod"
    assert move.new_mod == "new_mod"
    assert move.old_attr == None
    assert move.new_attr == "name"
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert move.name == "name"
    assert move.old_mod == "old_mod"
    assert move.new_mod == "new_mod"
    assert move.old_attr == "old_attr"
    assert move.new_attr == "old_attr"

# Generated at 2022-06-12 03:56:46.541504
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test if _get_rewrites returns something
    # If it does, it means the constructor worked correctly
    assert len(list(_get_rewrites())) > 0

# Generated at 2022-06-12 03:56:50.210173
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"

# Generated at 2022-06-12 03:56:52.843355
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(2, 7)
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:57:44.304459
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod1 = MovedModule("mod1", "mod2")
    mod2 = MovedModule("mod1", "mod2", "mod3")
    assert mod1.name == 'mod1'
    assert mod1.old == 'mod2'
    assert mod1.new == "mod1"
    assert mod2.n

# Generated at 2022-06-12 03:57:46.076340
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import_rewrite_from_import = SixMovesTransformer()
    for rewrite_from_import in import_rewrite_from_import.rewrites:
        rewrite_from_import

# Generated at 2022-06-12 03:57:50.831960
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'

# Generated at 2022-06-12 03:57:54.604791
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer()  # type: ignore
    assert len(st.rewrites) == len(_get_rewrites())
    for p, m in _get_rewrites():
        assert (p, m) in st.rewrites

# Generated at 2022-06-12 03:58:01.613339
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=invalid-name
    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attr.name == "cStringIO"
    assert moved_attr.new_mod == "io"
    assert moved_attr.new_attr == "StringIO"

    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attr.name == "cStringIO"
    assert moved_attr.new_mod == "io"
    assert moved_attr.new_attr == "cStringIO"

    moved_attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "new_StringIO")
    assert moved_attr.name == "cStringIO"
    assert moved_attr

# Generated at 2022-06-12 03:58:06.338125
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("cookie", "cookielib").name == "cookie"
    assert MovedModule("html", "html.parser").name == "html"
    assert MovedModule("http", "http.client").name == "http"
    # assert MovedModule("test", "test").name == "test"



# Generated at 2022-06-12 03:58:08.981600
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    if sys.version_info < (2, 7):
        with pytest.raises(ImportError):
            import backports.shutil_get_terminal_size

# Code copied from six:


# Generated at 2022-06-12 03:58:12.130361
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.old == "old"
    assert a.new == "new"

# Generated at 2022-06-12 03:58:16.817856
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'

    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'

# Generated at 2022-06-12 03:58:23.322271
# Unit test for constructor of class MovedModule
def test_MovedModule():
    d = MovedModule("dummy", "dummy")
    assert d.name == "dummy"
    assert d.new == "dummy"

    d = MovedModule("dummy", "dummy", "new")
    assert d.name == "dummy"
    assert d.new == "new"

    e = MovedModule("dummy", "dummy")
    assert e == d

    f = MovedModule("dummy", "dummy", "other")
    assert f != d

# Generated at 2022-06-12 03:59:24.429100
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) == 54
    assert len(_urllib_parse_moved_attributes) == 18
    assert len(_urllib_error_moved_attributes) == 3
    assert len(_urllib_request_moved_attributes) == 35
    assert len(_urllib_response_moved_attributes) == 4
    assert len(_urllib_robotparser_moved_attributes) == 1
    assert len(list(_get_rewrites())) == 54 + 18 + 3 + 35 + 4 + 1

# Generated at 2022-06-12 03:59:28.147626
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("abc") == MovedModule("abc", "abc")
    assert MovedModule("abc", "def") == MovedModule("abc", "def")
    assert MovedModule("abc", "def", "jkl") == MovedModule("abc", "def", "jkl")

# Generated at 2022-06-12 03:59:31.540379
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('print', '__builtin__', 'functions', 'print', 'printer')
    assert ma.name == 'print'
    assert ma.new_mod == 'functions'
    assert ma.new_attr == 'printer'

# Generated at 2022-06-12 03:59:34.302255
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_object = MovedModule('name', 'old')
    assert test_object.name == 'name'
    assert test_object.old == 'old'
    assert test_object.new == 'name'


# Generated at 2022-06-12 03:59:37.053775
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that the SixMovesTransformer constructor constructs the correct
    set of rewrites.

    """
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:59:37.963709
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:59:42.222757
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == [
        ('module-name', 'six.moves.attribute-name'),
        ('module-name', 'six.moves.another-name'),
        ('module-name.sub-module', 'six.moves.sub-module-name')
    ]


# Generated at 2022-06-12 03:59:44.466698
# Unit test for constructor of class MovedModule
def test_MovedModule():
    instance = MovedModule('some_name', 'old', 'new')
    assert instance.name == 'some_name'
    assert instance.new == 'new'


# Generated at 2022-06-12 03:59:47.853309
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'

# Generated at 2022-06-12 03:59:56.478468
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # type: () -> None
    _get_rewrites()  # This is usually done at import time, but we need to do it explicitly here.
    assert len(SixMovesTransformer.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)
    assert SixMovesTransformer.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert SixMovesTransformer.rewrites[1] == ('itertools.ifilter', 'six.moves.filter')
   