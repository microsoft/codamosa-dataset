

# Generated at 2022-06-12 03:50:46.741165
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert len(t.rewrites) == len(prefixed_moves) * 2

# Generated at 2022-06-12 03:50:50.299383
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("tkinter", "Tkinter").name == "tkinter"
    assert MovedModule("tkinter", "Tkinter").new == "tkinter"
    assert MovedModule("tkinter", "Tkinter", "tcl").name == "tkinter"
    assert MovedModule("tkinter", "Tkinter", "tcl").new == "tcl"

# Generated at 2022-06-12 03:50:53.838343
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:50:56.749434
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    x = SixMovesTransformer(None)
    print(x.rewrites)

if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:50:58.079578
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        MovedModule("1", "2")
    except:
        assert False

# Generated at 2022-06-12 03:51:04.501343
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("test_name", "test_old_mod", "test_new_mod", "test_old_attr", "test_new_attr")
    assert a.name == "test_name"
    assert a.new_mod == "test_new_mod"
    assert a.new_attr == "test_new_attr"



# Generated at 2022-06-12 03:51:07.475276
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('modulename', 'old', 'new')
    assert mod.name == 'modulename'
    assert mod.old == 'old'
    assert mod.new == 'new'


# Generated at 2022-06-12 03:51:12.613831
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"
    mm = MovedModule("name2", "old2")
    assert mm.name == "name2"
    assert mm.old == "old2"
    assert mm.new == "name2"

# Generated at 2022-06-12 03:51:13.772456
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0

# Generated at 2022-06-12 03:51:20.186781
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.__dict__ == {"name": "name", "old": "old", "new": "new"}

    mm = MovedModule("name", "old")
    assert mm.__dict__ == {"name": "name", "old": "old", "new": "name"}



# Generated at 2022-06-12 03:51:32.645823
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar') == MovedModule('foo', 'bar')
    assert MovedModule('bar', 'foo') != MovedModule('foo', 'bar')
    assert MovedModule('bar', 'foo') != MovedAttribute('bar', 'foo')
    assert MovedModule('foo', 'bar', 'fun') == MovedModule('foo', 'bar', 'fun')
    assert MovedModule('foo', 'bar', 'fun') != MovedModule('foo', 'fun')
    assert MovedModule('foo', 'bar', 'fun') != MovedModule('foo', 'bar', 'baz')
    assert MovedModule('foo', 'bar', 'fun') != MovedModule('foo', 'baz', 'fun')

# Generated at 2022-06-12 03:51:35.532286
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from .base import BaseImportRewrite, register_transformer, main_import_rewrite
    m = MovedModule("six.moves.http_client", "httplib", "http.client")
    assert m.name == "six.moves.http_client"
    assert m.new == "http.client"



# Generated at 2022-06-12 03:51:44.612904
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    atr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert atr.name == "cStringIO"
    assert atr.new_mod == "io"
    assert atr.new_attr == "StringIO"
    atr = MovedAttribute("reload_module", "__builtin__", "imp", "reload")
    assert atr.name == "reload_module"
    assert atr.new_mod == "imp"
    assert atr.new_attr == "reload"
    atr = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert atr.name == "filter"
    assert atr.new_mod == "builtins"
    assert atr.new_attr == "filter"


# Generated at 2022-06-12 03:51:55.204923
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"

    m = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "cStringIO"
    assert m.new_attr == "StringIO"

    m = MovedAttribute("cStringIO", "cStringIO", None)

# Generated at 2022-06-12 03:51:57.147184
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    assert six.moves.configparser == configparser
    assert six.moves.http_cookiejar == http.cookiejar

# Generated at 2022-06-12 03:52:03.007918
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm_orig = MovedModule('qwerty', 'asdf')
    mm_test1 = MovedModule('qwerty')
    mm_test2 = MovedModule('qwerty', 'asdf', 'rtyu')
    assert mm_orig.name == mm_test1.name == mm_test2.name
    assert mm_orig.old == mm_test1.old == 'asdf'
    assert mm_orig.new == 'asdf'
    assert mm_test1.new == 'qwerty'
    assert mm_test2.new == 'rtyu'

# Generated at 2022-06-12 03:52:06.398142
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    code = "import six.moves.urllib.parse;"
    res = SixMovesTransformer.replace(code)
    assert res == "import six.moves.urllib_parse;"

# Generated at 2022-06-12 03:52:08.009025
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:52:19.587185
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("foo", "bar")
    assert ma.name == 'foo'
    assert ma.new_mod == 'bar'
    assert ma.new_attr == 'foo'
    ma = MovedAttribute("foo", "bar", "baz")
    assert ma.name == 'foo'
    assert ma.new_mod == 'bar'
    assert ma.new_attr == 'baz'
    ma = MovedAttribute("foo", "bar", "baz", "qux")
    assert ma.name == 'foo'
    assert ma.new_mod == 'bar'
    assert ma.new_attr == 'qux'
    ma = MovedAttribute("foo", "bar", "baz", "qux", "quux")
    assert ma.name == 'foo'

# Generated at 2022-06-12 03:52:25.962294
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_module = MovedModule("test_module", "test_old")
    assert test_module.name == "test_module"
    assert test_module.old == "test_old"


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-12 03:52:37.122626
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') == \
           MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') != \
           MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr1')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') != \
           MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr1', 'new_attr')

# Generated at 2022-06-12 03:52:38.524517
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == list(_get_rewrites())

# Generated at 2022-06-12 03:52:41.165376
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("winreg", "_winreg")
    assert moved_module.name == "winreg"
    assert moved_module.new == "_winreg"

# Generated at 2022-06-12 03:52:44.502099
# Unit test for constructor of class MovedModule
def test_MovedModule():
    testMovedModule = MovedModule(name="foo", old="oldFoo")
    assert testMovedModule.name == "foo"
    assert testMovedModule.old == "oldFoo"
    assert testMovedModule.new == "foo"

# Generated at 2022-06-12 03:52:53.798044
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("foo", "bar", "baz")
    assert attr.name == "foo"
    assert attr.new_mod == "baz"
    assert attr.new_attr == "foo"

    attr = MovedAttribute("foo", "bar", "baz", "foo", "baz")
    assert attr.name == "foo"
    assert attr.new_mod == "baz"
    assert attr.new_attr == "baz"

    attr = MovedAttribute("foo", "bar", "baz", "foo")
    assert attr.name == "foo"
    assert attr.new_mod == "baz"
    assert attr.new_attr == "foo"


# Generated at 2022-06-12 03:52:57.781263
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "cStringIO"
    assert attr.new_mod == "io"
    assert attr.new_attr == "StringIO"

# Generated at 2022-06-12 03:53:10.258230
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None, None)
    # test if rewrites are generated correctly
    assert len(transformer.rewrites) == len(_moved_attributes) + len(_urllib_parse_moved_attributes) + len(_urllib_error_moved_attributes) + len(_urllib_request_moved_attributes) + len(_urllib_response_moved_attributes) + len(_urllib_robotparser_moved_attributes)
    # test if the first element is treated correctly
    path = transformer.rewrites[0][0]
    assert path == 'io.StringIO'
    # test if the last element is treated correctly
    path = transformer.rewrites[-1][0]

# Generated at 2022-06-12 03:53:11.329114
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rw = SixMovesTransformer()
    assert isinstance(rw, SixMovesTransformer)

# Generated at 2022-06-12 03:53:16.898660
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    b = MovedAttribute("cStringIO", "cStringIO", "io")
    assert b.new_attr == "cStringIO"


# Generated at 2022-06-12 03:53:28.465054
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a1 = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")
    assert a1.name == "getcwd"
    assert a1.new_mod == "os"
    assert a1.new_attr == "getcwd"
    a2 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a2.new_mod == "io"
    assert a2.new_attr == "StringIO"
    a3 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert a3.new_attr == "filter"
    a4 = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")

# Generated at 2022-06-12 03:53:33.543595
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("cStringIO", "cStringIO", "io")
    assert mm.new == "io"
    assert mm.name == "cStringIO"

# Generated at 2022-06-12 03:53:45.043688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("ma", "a", "b", "c", "d")
    assert ma.name == "ma"
    assert ma.old_mod is None
    assert ma.new_mod == "b"
    assert ma.old_attr is None
    assert ma.new_attr == "d"
    ma = MovedAttribute("ma", "a", "b", "c")
    assert ma.name == "ma"
    assert ma.old_mod is None
    assert ma.new_mod == "b"
    assert ma.old_attr == "c"
    assert ma.new_attr == "c"
    ma = MovedAttribute("ma", "a", "b")
    assert ma.name == "ma"
    assert ma.old_mod is None
    assert ma.new_mod == "b"


# Generated at 2022-06-12 03:53:46.012535
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    assert six.moves.Queue == _moved_attributes[-2].new

# Generated at 2022-06-12 03:53:49.946058
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert str(MovedModule("name", "old")) == "MovedModule(name, old, name)"
    assert str(MovedModule("name", "old", "new")) == "MovedModule(name, old, new)"

# Generated at 2022-06-12 03:53:54.366109
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"



# Generated at 2022-06-12 03:53:59.881419
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'Foo') == MovedModule('foo', 'Foo')
    assert MovedModule('foo', 'Foo') != MovedModule('bar', 'Foo')
    assert MovedModule('foo', 'Foo') != MovedModule('foo', 'Foo', 'bar')
    assert MovedModule('foo', 'Foo') != 'bar'

# Generated at 2022-06-12 03:54:11.477055
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    ma = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert ma.name == "filter"
    assert ma.new_mod == "builtins"
    assert ma.new_attr == "filter"
    ma = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert ma.name == "filterfalse"
    assert ma.new_mod == "itertools"
    assert ma.new_attr == "filterfalse"

# Generated at 2022-06-12 03:54:23.294375
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('x', 'y', 'z') == \
        MovedAttribute('x', 'y', 'z', None, None)
    assert MovedAttribute('x', 'y', 'z') == \
        MovedAttribute('x', 'y', 'z', 'x', 'x')
    assert MovedAttribute('x', 'y', 'z', 'a', 'b') == \
        MovedAttribute('x', 'y', 'z', 'a', 'b')
    assert MovedAttribute('x', 'y', 'z', 'a', 'b') != \
        MovedAttribute('x', 'y', 'z', 'a', 'a')
    assert MovedAttribute('x', 'y', 'z', 'a', 'a') == \
        MovedAttribute('x', 'y', 'z', 'a', None)

# Generated at 2022-06-12 03:54:35.590814
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()

# Generated at 2022-06-12 03:54:47.952689
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("testattr", "testmod")
    assert attr.name == "testattr"
    assert attr.new_mod == "testmod"
    assert attr.new_attr == "testattr"
    attr = MovedAttribute("testattr", "testmod", "newmod")
    assert attr.name == "testattr"
    assert attr.new_mod == "newmod"
    assert attr.new_attr == "testattr"
    attr = MovedAttribute("testattr", "testmod", new_attr = "newattr")
    assert attr.name == "testattr"
    assert attr.new_mod == "testmod"
    assert attr.new_attr == "newattr"

# Generated at 2022-06-12 03:54:59.880684
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-12 03:55:01.167887
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 59

# Generated at 2022-06-12 03:55:05.492858
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test_moved_attr = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO')
    assert(test_moved_attr.name=='cStringIO')
    assert(test_moved_attr.new_mod=='io')
    assert(test_moved_attr.new_attr=='StringIO')


# Generated at 2022-06-12 03:55:09.313876
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"



# Generated at 2022-06-12 03:55:13.893186
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    actual = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    expected = {'name': 'cStringIO', 'old_mod': 'cStringIO', 'new_mod': 'io', 'old_attr': 'StringIO', 'new_attr': 'StringIO'}
    assert actual.__dict__ == expected

# Generated at 2022-06-12 03:55:22.000711
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert move1.name == 'cStringIO'
    assert move1.new_mod == 'io'
    assert move1.new_attr == 'StringIO'
    move2 = MovedAttribute('reload_module', '__builtin__', 'importlib', 'reload')
    assert move2.name == 'reload_module'
    assert move2.new_mod == 'importlib'
    assert move2.new_attr == 'reload'



# Generated at 2022-06-12 03:55:31.100960
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import tempfile
    import astor

# Generated at 2022-06-12 03:55:35.490197
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"


# Generated at 2022-06-12 03:55:45.081562
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == \
        {'name': 'cStringIO', 'old_attr': 'StringIO', 'old_mod': 'cStringIO', 'new_attr': 'cStringIO', 'new_mod': 'io'}
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").__dict__ == \
        {'name': 'filter', 'old_attr': 'ifilter', 'old_mod': 'itertools', 'new_attr': 'filter', 'new_mod': 'builtins'}

# Generated at 2022-06-12 03:55:48.852851
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('hey', 'thing', 'stuff')
    assert m.name == 'hey'
    assert m.new == 'stuff'

    m = MovedModule('hey', 'thing')
    assert m.name == 'hey'
    assert m.new == 'hey'

# Generated at 2022-06-12 03:56:05.791430
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule(name='name', old='old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'

    mm = MovedModule(name='name', old='old', new='new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'



# Generated at 2022-06-12 03:56:11.756346
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    source = SixMovesTransformer()
    assert source.target == (2, 7)

# Generated at 2022-06-12 03:56:13.975774
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    expected = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert expected.name == 'cStringIO'
    assert expected.new_mod == 'io'
    assert expected.new_attr == 'cStringIO'


# Generated at 2022-06-12 03:56:16.935550
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old')
    b = MovedModule('name', 'old', 'new')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'name'
    assert b.old == 'old'
    assert b.new == 'new'


# Generated at 2022-06-12 03:56:19.528870
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert len(t.rewrites) == 56

# Generated at 2022-06-12 03:56:28.835131
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:30.784584
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('name', 'old_name', 'new_name')
    assert isinstance(m, MovedModule)


# Generated at 2022-06-12 03:56:32.877017
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("test","test1",None)
    assert move.name == "test"
    assert move.new == "test1"


# Generated at 2022-06-12 03:56:34.198934
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:56:39.474692
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
       MovedAttribute('name','old_mod','new_mod')
       MovedAttribute('name','old_mod','new_mod', 'old_attr', 'new_attr')
    except:
        raise AssertionError("Unable to create an instance of"
                             " class MovedAttribute")



# Generated at 2022-06-12 03:57:12.079711
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    b = MovedAttribute("cStringIO", "cStringIO", "io")
    c = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")

    assert a.name == "cStringIO"
    assert a.new_mod == "cStringIO"
    assert a.old_attr == "StringIO"
    assert a.new_attr == "StringIO"

    assert b.name == "cStringIO"
    assert b.new_mod == "cStringIO"
    assert b.old_attr is None
    assert b.new_attr == "cStringIO"

    assert c.name == "cStringIO"
    assert c.new_mod == "cStringIO"

# Generated at 2022-06-12 03:57:15.015700
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('m', 'o', 'n')
    assert MovedModule('m', 'o')
    assert MovedModule('m')

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:57:18.031166
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    code = "from docker import dockerfile"
    expected = "from six.moves.dockerfile import dockerfile"
    tree = ast.parse(code)
    transformed = SixMovesTransformer(code, tree)
    assert transformed == expected

# Generated at 2022-06-12 03:57:20.131206
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('name', 'old')
    assert moved.name == 'name'
    assert moved.old == 'old'
    assert moved.new == 'name'


# Generated at 2022-06-12 03:57:23.070343
# Unit test for constructor of class MovedModule
def test_MovedModule():
    def create():
        return MovedModule("a", "b", "c")
    m = create()
    assert m.name == "a"
    assert m.old == "b"
    assert m.new == "c"


# Generated at 2022-06-12 03:57:29.260490
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert repr(MovedModule('old', 'old', 'new')) == 'MovedModule(name=\'old\', old=\'old\', new=\'new\')'
    assert repr(MovedModule('old', 'old', None)) == 'MovedModule(name=\'old\', old=\'old\', new=\'old\')'
    assert repr(MovedModule('old', 'old')) == 'MovedModule(name=\'old\', old=\'old\', new=\'old\')'

# Generated at 2022-06-12 03:57:35.641648
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('module_name', 'old_module_name', 'new_module_name')
    assert mm.name == 'module_name'
    assert mm.old == 'old_module_name'
    assert mm.new == 'new_module_name'

    mm = MovedModule('module_name', 'old_module_name')
    assert mm.name == 'module_name'
    assert mm.old == 'old_module_name'
    assert mm.new == 'module_name'

# Generated at 2022-06-12 03:57:39.294181
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    d = {'six': Module(six.__name__)}
    t = SixMovesTransformer(d)
    assert len(t.rewrites) == len(set(t.rewrites).union(_get_rewrites()))

# Generated at 2022-06-12 03:57:44.736275
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # type: () -> None
    m1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m1.name == "cStringIO"
    assert m1.new_mod == "io"
    assert m1.new_attr == "StringIO"

    m2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m2.name == "cStringIO"
    assert m2.new_mod == "io"
    assert m2.new_attr == "cStringIO"


# Generated at 2022-06-12 03:57:45.979998
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:58:47.323809
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old')
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'name'

    b = MovedModule('name', 'old', 'new')
    assert b.name == 'name'
    assert b.old == 'old'
    assert b.new == 'new'

# Generated at 2022-06-12 03:58:48.666448
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()

# Generated at 2022-06-12 03:58:51.016127
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    sys.modules["six"] = type('module', (), {})
    im = SixMovesTransformer()
    assert im.rewrites
    assert im.dependencies
    assert im.target

# Generated at 2022-06-12 03:58:53.833337
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('module', 'old', 'new')
    assert 'module' == moved_module.name
    assert 'old' == moved_module.old
    assert 'new' == moved_module.new


# Generated at 2022-06-12 03:58:58.602753
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("copyreg", "copy_reg").new == "copyreg"



# Generated at 2022-06-12 03:59:08.135045
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert (MovedAttribute("name", "old_mod", "new_mod").name == "name")
    assert (MovedAttribute("test", "mod", "test_module").new_mod == "test_module")
    assert (MovedAttribute("test", "mod", "test_module").new_attr == "test")
    assert (MovedAttribute("test", "mod", "test_module", "old_attr").new_attr == "old_attr")
    assert (MovedAttribute("test", "mod", "test_module", "old_attr").new_attr == "old_attr")
    assert (MovedAttribute("test", "mod", "test_module", "old_attr", "new_attr").new_mod == "test_module")

# Generated at 2022-06-12 03:59:17.524641
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """
Do the init structures right.
    """
    m = MovedAttribute("foo", "old", "new")
    assert m.name == "foo"
    assert m.new_mod == "new"
    assert m.new_attr == "foo"
    m = MovedAttribute("foo", "old", "new", "old_attr")
    assert m.new_attr == "old_attr"
    m = MovedAttribute("foo", "old", "new", "old_attr", "new_attr")
    assert m.new_attr == "new_attr"
    assert m.name == "foo"
    assert m.new_mod == "new"
    m = MovedAttribute("foo", "old", "new", new_attr="new_attr")
    assert m.new_attr == "new_attr"
   

# Generated at 2022-06-12 03:59:22.078298
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert MovedAttribute('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')

# Generated at 2022-06-12 03:59:32.504188
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('abc', 'abc', 'abc')
    assert a.name == 'abc'
    assert a.new_mod == 'abc'
    assert a.new_attr == 'abc'
    a = MovedAttribute('abc', 'def', 'def', 'ghi')
    assert a.name == 'abc'
    assert a.new_mod == 'def'
    assert a.new_attr == 'ghi'
    a = MovedAttribute('abc', 'def', 'def', 'ghi', 'jkl')
    assert a.name == 'abc'
    assert a.new_mod == 'def'
    assert a.new_attr == 'jkl'
    a = MovedAttribute('abc', 'def', 'def', new_attr='jkl')
    assert a.name == 'abc'

# Generated at 2022-06-12 03:59:41.361344
# Unit test for constructor of class SixMovesTransformer