

# Generated at 2022-06-12 03:50:54.663407
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move_module = MovedModule("name", "old", "new")
    assert move_module.name == "name"
    assert move_module.old == "old"
    assert move_module.new == "new"

    move_module = MovedModule("name", "old")
    assert move_module.old == "old"
    assert move_module.new == "name"


# Generated at 2022-06-12 03:50:56.192519
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer.rewrites) == _get_rewrites()

# Generated at 2022-06-12 03:51:07.566118
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
	assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
	assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
	assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
	assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
	assert MovedAttribute("intern", "__builtin__", "sys")
	assert MovedAttribute("map", "itertools", "builtins", "imap", "map")
	assert MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-12 03:51:18.818910
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():

    class dummy:
        pass

    m = MovedAttribute("name", "old_mod", "new_mod", old_attr="old_attr", new_attr="new_attr")
    assert m.name == "name"
    assert m.new_mod == "new_mod"
    assert m.new_attr == "new_attr"

    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert m.name == "name"
    assert m.new_mod == "new_mod"
    assert m.new_attr == "new_attr"

    m = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert m.name == "name"
    assert m.new_mod == "new_mod"


# Generated at 2022-06-12 03:51:30.780879
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"
    assert a.name == "cStringIO"
    b = MovedAttribute("cStringIO", "cStringIO", "io")
    assert b.new_mod == "io"
    assert b.new_attr == "cStringIO"
    assert b.name == "cStringIO"
    c = MovedAttribute("cStringIO", "cStringIO", None, "StringIO")
    assert c.new_mod == "cStringIO"
    assert c.new_attr == "StringIO"
    assert c.name == "cStringIO"
    d = MovedAttribute("cStringIO", "cStringIO", None)

# Generated at 2022-06-12 03:51:33.614389
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("winreg", "_winreg")
    assert module.name == "_winreg"
    assert module.new == "winreg"


# Generated at 2022-06-12 03:51:36.814092
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import operator
    import sys
    import six
    sys.meta_path.insert(0, SixMovesTransformer())
    assert operator.isCallable(six.moves.map)
    assert six.moves.map == map

# Generated at 2022-06-12 03:51:47.521862
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:51:57.391621
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attributes = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attributes.name == "cStringIO"
    assert moved_attributes.new_mod == "io"
    assert moved_attributes.new_attr == "StringIO"
    moved_attributes = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_attributes.name == "cStringIO"
    assert moved_attributes.new_mod == "io"
    assert moved_attributes.new_attr == "cStringIO"
    moved_attributes = MovedAttribute("cStringIO", "cStringIO", "io", None, "cStringIO")
    assert moved_attributes.name == "cStringIO"

# Generated at 2022-06-12 03:52:00.820516
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mv = MovedModule("io", "StringIO")
    assert mv.name == "io"
    assert mv.new == "io"
    mv = MovedModule("queue", "Queue")
    assert mv.name == "queue"
    assert mv.new == "queue"

# Generated at 2022-06-12 03:52:04.955057
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer.rewrites) == 46

# Generated at 2022-06-12 03:52:16.948866
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute(
        'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute(
        'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute(
        'name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute(
        'name', 'old_mod', 'new_mod', 'old_attr').new_attr == 'old_attr'
    assert MovedAttribute(
        'name', 'old_mod', 'new_mod').new_attr == 'name'
    assert MovedAttribute('name', 'old_mod').new_

# Generated at 2022-06-12 03:52:30.419054
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    assert (2, 7) == SixMovesTransformer.target
    assert six.moves.cStringIO.StringIO == SixMovesTransformer.rewrites[0][1]
    assert six.moves.builtins.filter == SixMovesTransformer.rewrites[1][1]
    assert six.moves.itertools.filterfalse == SixMovesTransformer.rewrites[2][1]
    assert six.moves.builtins.input == SixMovesTransformer.rewrites[3][1]
    assert six.moves.sys.intern == SixMovesTransformer.rewrites[4][1]
    assert six.moves.builtins.map == SixMovesTransformer.rewrites[5][1]

# Generated at 2022-06-12 03:52:31.282060
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar', 'baz').name == 'foo'

# Generated at 2022-06-12 03:52:39.060850
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test the simplest MovedAttribute with new_attr = None
    test_MovedAttribute_simple = MovedAttribute("cStringIO", "cStringIO", "io")
    assert test_MovedAttribute_simple.name == "cStringIO"
    assert test_MovedAttribute_simple.new_mod == "io"
    assert test_MovedAttribute_simple.new_attr == "cStringIO"
    # Test the simplest MovedAttribute with new_attr = name
    test_MovedAttribute_new_attr_name = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert test_MovedAttribute_new_attr_name.name == "cStringIO"
    assert test_MovedAttribute_new_attr_name.new_mod == "io"
    assert test_MovedAttribute_new

# Generated at 2022-06-12 03:52:42.785667
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # constructor of MovedAttribute
    m1 = MovedAttribute("cStringIO","cStringIO","io","StringIO")
    assert m1.name == "cStringIO"
    assert m1.new_mod == "io"
    assert m1.new_attr == "StringIO"

    m2 = MovedAttribute("cStringIO","cStringIO","io")
    assert m2.name == "cStringIO"
    assert m2.new_mod == "io"
    assert m2.new_attr == "cStringIO"


# Generated at 2022-06-12 03:52:45.973388
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, list)
    assert len(SixMovesTransformer.rewrites) == 84
    assert len(SixMovesTransformer.dependencies) == 1


# Generated at 2022-06-12 03:52:52.748897
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()

    with pytest.raises(TypeError):
        MovedModule("name")

    with pytest.raises(TypeError):
        MovedModule("name", "old", "new", 1)

    with pytest.raises(TypeError):
        MovedModule("name", "old", 1, "new")

    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"

    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-12 03:52:55.194098
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert repr(MovedModule('aa', 'bb', 'cc')) == 'MovedModule(name=\'aa\', old=\'bb\', new=\'cc\')'

# Generated at 2022-06-12 03:52:56.136706
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 100



# Generated at 2022-06-12 03:53:08.883415
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("x", None).name == "x"
    assert MovedModule("x", None).new == "x"
    assert MovedModule("x", "y").name == "x"
    assert MovedModule("x", "y").new == "y"
    assert MovedModule("x", "y", "z").name == "x"
    assert MovedModule("x", "y", "z").new == "z"
    assert MovedModule("x", None, "z").name == "x"
    assert MovedModule("x", None, "z").new == "z"


# Generated at 2022-06-12 03:53:14.927281
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("winreg", "_winreg")
    assert moved_module.name == "winreg"
    assert moved_module.new == "winreg"

    moved_module = MovedModule("winreg", "_winreg", "winregistry")
    assert moved_module.name == "winreg"
    assert moved_module.new == "winregistry"



# Generated at 2022-06-12 03:53:16.024628
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 99

# Generated at 2022-06-12 03:53:17.039186
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:53:18.527099
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer.rewrites)
    print(SixMovesTransformer.dependencies)

# Generated at 2022-06-12 03:53:23.232239
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("moved", "old", "new", "old_attribute", "new_attribute")
    assert moved.name == 'moved'
    assert moved.new_mod == 'new'
    assert moved.new_attr == 'new_attribute'


# Generated at 2022-06-12 03:53:25.380790
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('tkinter', 'Tkinter').name == 'tkinter'


# Generated at 2022-06-12 03:53:31.119508
# Unit test for constructor of class MovedModule
def test_MovedModule():
    r = MovedModule("name", "old")
    assert r.name == "name"
    assert r.new == "name"
    assert r.old == "old"
    r = MovedModule("name", "old", "new")
    assert r.name == "name"
    assert r.old == "old"
    assert r.new == "new"

# Generated at 2022-06-12 03:53:34.911876
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'

# Generated at 2022-06-12 03:53:38.986099
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('foo', 'bar', 'baz')
    assert mm.name == 'foo'
    assert mm.new == 'bar'


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:53:56.682120
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"

    obj2 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO2")
    assert obj2.name == "cStringIO"
    assert obj2.new_mod == "io"
    assert obj2.new_attr == "StringIO2"

    obj3 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert obj3.name == "cStringIO"
    assert obj3.new_mod == "io"
    assert obj3.new_attr == "cStringIO"

    obj4 = M

# Generated at 2022-06-12 03:54:01.320357
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-12 03:54:12.619252
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    c1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert c1.name == "cStringIO"
    assert c1.new_mod == "io"
    assert c1.new_attr == "StringIO"

    c2 = MovedAttribute("print", "__builtin__", "builtins")
    assert c2.name == "print"
    assert c2.new_mod == "builtins"
    assert c2.new_attr == None

    c3 = MovedAttribute("print", "__builtin__", "builtins", "print")
    assert c3.name == "print"
    assert c3.new_mod == "builtins"
    assert c3.new_attr == "print"

    # Confirm that original code still works
    c1.new

# Generated at 2022-06-12 03:54:24.525066
# Unit test for constructor of class MovedModule
def test_MovedModule():
    source = MovedModule("builtins", "__builtin__")
    assert source.name == "builtins"
    assert source.new == "builtins"
    assert source.old == "__builtin__"

    source = MovedModule("robotparser", "robotparser", "urllib.robotparser")
    assert source.name == "robotparser"
    assert source.new == "urllib.robotparser"
    assert source.old == "robotparser"

    # this test should fail if a parameter is not passed in correctly
    with pytest.raises(Exception):
        source = MovedModule("robotparser")
    with pytest.raises(Exception):
        source = MovedModule("robotparser", "robotparser", "urllib.robotparser", "foo")


# Unit

# Generated at 2022-06-12 03:54:32.383621
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule("test1", "test2")
    assert movedModule.name == "test1"
    assert movedModule.new == "test1"
    assert movedModule.old == "test2"

    movedModule = MovedModule("test1", "test2", "test3")
    assert movedModule.name == "test1"
    assert movedModule.new == "test3"
    assert movedModule.old == "test2"



# Generated at 2022-06-12 03:54:40.714066
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "cStringIO"
    assert ma.new_attr == "StringIO"

    ma = MovedAttribute("cStringIO", "cStringIO", "io")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "cStringIO"
    assert ma.new_attr == "cStringIO"


# Generated at 2022-06-12 03:54:49.734672
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_moved_attributes) > 0
    assert len(_urllib_parse_moved_attributes) > 0
    assert len(_urllib_error_moved_attributes) > 0
    assert len(_urllib_request_moved_attributes) > 0
    assert len(_urllib_response_moved_attributes) > 0
    assert len(_urllib_robotparser_moved_attributes) > 0
    assert len(_get_rewrites()) > 0


if __name__ == "__main__":
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:54:54.536741
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    if transformer.rewrites[0][0] != 'builtins.filter':
        raise Exception('Bad test: we were expecting the six.moves.filter to be the first rewrites.')
    if transformer.rewrites[0][1] != 'six.moves.filter':
        raise Exception('Bad test: we were expecting the six.moves.filter to be the target rewrites.')

# Generated at 2022-06-12 03:54:57.091284
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("test", "old", "new")
    assert test.name == 'test'
    assert test.new_mod == 'new'
    assert test.new_attr == 'test'


# Generated at 2022-06-12 03:54:59.447631
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('foo', 'bar')
    assert mod.name == 'foo'
    assert mod.new == 'foo'
    assert mod.old == 'bar'

# Generated at 2022-06-12 03:55:15.568831
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod',
                                     'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-12 03:55:26.764244
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import ast
    # Test that with the following input

# Generated at 2022-06-12 03:55:29.923148
# Unit test for constructor of class MovedModule
def test_MovedModule():
    movedModule = MovedModule("module_name", "old_module_name")
    assert movedModule.name == "module_name"
    assert movedModule.old == "old_module_name"
    assert movedModule.new == "module_name"


# Generated at 2022-06-12 03:55:41.470661
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    data = list(_get_rewrites())
    # Standard py2-py3 replacements
    assert data[0] == ("sys.version_info", "six.moves.builtins.__dict__['reload']")
    assert data[1] == ("sys.version_info", "six.moves.imp.reload")
    assert data[2] == ("sys.version_info", "six.moves.importlib.reload")
    assert data[3] == ("sys.version_info", "six.moves.builtins.filter")
    assert data[4] == ("sys.version_info", "six.moves.builtins.map")
    assert data[5] == ("sys.version_info", "six.moves.builtins.range")

# Generated at 2022-06-12 03:55:42.689914
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        move_module = MovedModule()

# Generated at 2022-06-12 03:55:46.972394
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m1 = MovedModule('name', 'old')
    assert m1.new == 'name'
    assert m1.old == 'old'

    m1 = MovedModule('name', 'old', 'new')
    assert m1.new == 'new'
    assert m1.old == 'old'

# Generated at 2022-06-12 03:55:48.536712
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('tests', 'test')


# Generated at 2022-06-12 03:55:52.929964
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert(MovedModule('foo', 'bar').name == 'foo')
    assert(MovedModule('foo', 'bar').new == 'bar')
    assert(MovedModule('foo', 'bar', 'baz').new == 'baz')
    assert(MovedModule('foo', 'bar', 'baz').name == 'foo')


# Generated at 2022-06-12 03:55:58.648662
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name")
    assert moved_module.name == "name"
    assert moved_module.new == "name"
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"

# Generated at 2022-06-12 03:56:00.550406
# Unit test for constructor of class MovedModule
def test_MovedModule():
	assert MovedModule('name', 'old').name == 'name'
	assert MovedModule('name', 'old').new == 'name'
	assert MovedModule('name', 'old', 'new').name == 'name'
	assert MovedModule('name', 'old', 'new').new == 'new'

# Generated at 2022-06-12 03:56:32.564924
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:34.299701
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libmodernize.fixes.six_moves import SixMovesTransformer

    assert("six.moves" in str(SixMovesTransformer.rewrites))

# Generated at 2022-06-12 03:56:36.184743
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(SixMovesTransformer().rewrites) == list(_get_rewrites())

# Generated at 2022-06-12 03:56:41.369662
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("a","b")
    assert mod.name == "a"
    assert mod.old == "b"
    assert mod.new == "a"
    mod = MovedModule("c","d","e")
    assert mod.name == "c"
    assert mod.old == "d"
    assert mod.new == "e"


# Generated at 2022-06-12 03:56:49.455552
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Unit test for class MovedModule"""
    assert MovedModule('moved', 'original', 'moved') == \
        MovedModule('moved', 'original', 'moved')
    assert MovedModule('moved', 'original', 'moved') != \
        MovedModule('moved', 'new', 'moved')
    assert MovedModule('moved', 'original', 'moved') != \
        MovedModule('moved', 'original', 'original')
    assert not MovedModule('moved', 'original', 'moved') != \
        MovedModule('moved', 'original', 'moved')



# Generated at 2022-06-12 03:56:58.417690
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:57:00.493914
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """
        >>> SixMovesTransformer
        <class 'six.transforms.SixMovesTransformer'>
    """
    pass

# Generated at 2022-06-12 03:57:05.497086
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("os","os").name == "os"
    assert MovedModule("os","os").new == "os"
    assert MovedModule("os.path","os.path").name == "os.path"
    assert MovedModule("os.path","os.path").new == "os.path"
    assert MovedModule("os.path","pathlib").name == "os.path"
    assert MovedModule("os.path","pathlib").new == "pathlib"

# Generated at 2022-06-12 03:57:14.488972
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    try:
        MovedAttribute("name", "old_mod")
    except TypeError:
        assert True
    except:  # noqa
        assert False
    finally:
        assert MovedAttribute("name", "old_mod", "new_mod")
        assert MovedAttribute("name", "old_mod", "new_mod", "old_attr").new_attr=='old_attr'
        assert MovedAttribute("name", "old_mod", "new_mod", new_attr="new_attr").new_attr=='new_attr'
        assert MovedAttribute("name", "old_mod", "new_mod", old_attr="old_attr", new_attr="new_attr").new_attr=='new_attr'

# Generated at 2022-06-12 03:57:18.990912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("zip", "itertools", "builtins", "izip", "zip").new_attr == "zip"

# Generated at 2022-06-12 03:58:21.769164
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.transformer_class == SixMovesTransformer
    assert transformer.transformer_id == "six-moves"
    assert transformer.transformer_name == "six moves"
    assert transformer.inplace == False
    assert transformer.line_number == False
    assert transformer.always_run == True
    assert transformer.warnings == False
    assert transformer.crash_on_error == False
    assert transformer.dependencies == ['six']
    assert transformer.python_version == (3, 6)
    assert transformer.tb == '<no traceback>'

# Generated at 2022-06-12 03:58:30.859810
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    f = MovedAttribute("getstatusoutput", "commands", "subprocess")
    assert f.name == "getstatusoutput"
    assert f.new_mod == "subprocess"
    assert f.new_attr == "getstatusoutput"

    g = MovedAttribute("getstatusoutput", "commands", "subprocess", "getstatusoutput", "getstatusoutput2")
    assert g.name == "getstatusoutput"
    assert g.new_mod == "subprocess"
    assert g.new_attr == "getstatusoutput2"

    h = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert h.name == "cStringIO"
    assert h.new_mod == "io"
    assert h.new_attr == "StringIO"


# Generated at 2022-06-12 03:58:35.301070
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves_transformer = SixMovesTransformer(None)
    assert isinstance(moves_transformer.rewrites, list)
    assert moves_transformer.rewrites == _get_rewrites()
    assert moves_transformer.dependencies == ['six']

# Generated at 2022-06-12 03:58:44.101485
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    res = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    expected = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    expected.__qualname__ = 'MovedAttribute'
    assert res == expected

# There seems to be an issue with multiprocessing/threading
# When I run on my machine in the interpreter, this passes
# When I run it in Pytest, or with MagickWand, it fails
# The problem is that the constructor is called twice, once in
# the thread, and once when it returns from the thread
# I have no idea why this is
# written in a manner that might seem odd, but is to try to ensure
# that the thread is constructed around the class, so the
# class does not leak out

# Generated at 2022-06-12 03:58:47.506158
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('test', 'oldtest')
    assert move.name == 'test'
    assert move.new == 'test'

    move = MovedModule('test', 'oldtest', 'newtest')
    assert move.name == 'test'
    assert move.new == 'newtest'


# Generated at 2022-06-12 03:58:50.564566
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.old == "__builtin__"
    assert moved_module.new == "builtins"


# Generated at 2022-06-12 03:58:53.461457
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new_module = MovedModule("name", "old")
    assert new_module.name == "name"
    assert new_module.new == "name"
    assert new_module.old == "old"



# Generated at 2022-06-12 03:58:55.821636
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.cStringIO' in SixMovesTransformer.rewrites
    assert 'six.moves.urllib.parse' in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:58:57.736569
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old")
    assert mm.new == mm.name

# Generated at 2022-06-12 03:59:03.150891
# Unit test for constructor of class MovedModule
def test_MovedModule():
    old_module = 'old_module_name'
    new_module = 'new_module_name'
    obj = MovedModule(old_module, old_module, new_module)
    assert obj.name == old_module
    assert obj.new == new_module
    # Test case when new_module is None
    obj = MovedModule(old_module, old_module)
    assert obj.name == old_module
    assert obj.new == old_module