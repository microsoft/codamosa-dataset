

# Generated at 2022-06-12 03:50:50.614071
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']


# The following tests are copied from six


# Generated at 2022-06-12 03:50:55.676233
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moving_module = MovedModule("builtins", "__builtin__")
    assert moving_module.name == "builtins"
    assert moving_module.new == "builtins"
    moving_module = MovedModule("builtins", "__builtin__", "__builtin__")
    assert moving_module.name == "builtins"
    assert moving_module.new == "__builtin__"


# Generated at 2022-06-12 03:51:02.577168
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError, match='__init__'):
        _ = MovedModule()
    _ = MovedModule('name1', 'old1', 'new1')
    _ = MovedModule('name2', 'old2')
    _ = MovedModule('name3', 'old3', new='')
    _ = MovedModule('name4', 'old4', new=None)



# Generated at 2022-06-12 03:51:05.016922
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule("name", "old", "new")
    assert moved.name == "name"
    assert moved.new == "new"

# Generated at 2022-06-12 03:51:12.556484
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    import six.moves.urllib.parse as urllib_parse
    assert(urllib_parse)
    import six.moves.urllib.error as urllib_error
    assert(urllib_error)
    import six.moves.urllib.request as urllib_request
    assert(urllib_request)
    import six.moves.urllib.response as urllib_response
    assert(urllib_response)
    import six.moves.urllib.robotparser as urllib_robotparser
    assert(urllib_robotparser)



test_MovedModule()

# Generated at 2022-06-12 03:51:14.088692
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer(None)
    assert transformer is not None

# Generated at 2022-06-12 03:51:16.715064
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO') != None


# Generated at 2022-06-12 03:51:28.496301
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    MovedAttribute("cStringIO", "cStringIO", "io")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    with pytest.raises(TypeError):
        MovedAttribute(1, "cStringIO", "io")
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", 1, "io")
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO", 1)

# Generated at 2022-06-12 03:51:30.261523
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s is not None

# Generated at 2022-06-12 03:51:33.173949
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # noqa: D103
    moves = _get_rewrites()
    assert any(('six.moves.http_client', 'http.client') in move for move in moves)

# Generated at 2022-06-12 03:51:42.444614
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") \
        == ('cStringIO', 'cStringIO', 'io', 'StringIO', 'cStringIO')
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter") \
        == ('filter', 'itertools', 'builtins', 'ifilter', 'filter')
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse") \
        == ('filterfalse', 'itertools', 'itertools', 'ifilterfalse', 'filterfalse')

# Generated at 2022-06-12 03:51:48.410464
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test that SixMovesTransformer contains the expected rewrites."""
    rewrites = SixMovesTransformer.rewrites
    assert 'json.loads' in rewrites
    assert 'urllib.moves.urllib2.urlopen' in rewrites
    assert 'xml.etree.ElementTree.parse' in rewrites

# Generated at 2022-06-12 03:51:52.853609
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("new", "old")
    assert module.name == "new"
    assert module.new == "new"
    module = MovedModule("new", "old", "new")
    assert module.name == "new"
    assert module.new == "new"


# Generated at 2022-06-12 03:52:01.430428
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-12 03:52:12.044902
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert m.old_mod == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.old_attr == 'StringIO'
    assert m.new_attr == 'StringIO'
    m = MovedAttribute('cStringIO', 'cStringIO', 'io')
    assert m.old_attr == 'cStringIO'
    assert m.new_attr == 'cStringIO'
    m = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'new_StringIO')
    assert m.old_mod == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.old_attr == 'StringIO'
    assert m.new_

# Generated at 2022-06-12 03:52:16.495165
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-12 03:52:29.974348
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from libcst.metadata.base_provider import BaseMetadataProvider
    from libcst.matchers import ImportAlias, ImportFrom, Name
    from libcst.transformers.base import CSTTransformer
    import six
    # Tests the constructor of class SixMovesTransformer
    assert hasattr(SixMovesTransformer, 'target')
    assert hasattr(SixMovesTransformer, 'rewrites')
    assert isinstance(SixMovesTransformer.target, tuple)
    assert isinstance(SixMovesTransformer.rewrites, dict)
    # Tests that the rewrites attribute of SixMovesTransformer is non-null
    assert isinstance(SixMovesTransformer.rewrites, dict)
    assert len(SixMovesTransformer.rewrites) > 0
    # Tests that the dependencies attribute of SixMovesTransformer is non

# Generated at 2022-06-12 03:52:35.737507
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(_moved_attributes) + len(_urllib_parse_moved_attributes)
    assert _get_rewrites()[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert _get_rewrites()[-1] == ('urllib.robotparser.RobotFileParser', 'six.moves.urllib.robotparser.RobotFileParser')

# Generated at 2022-06-12 03:52:43.475329
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser.ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser.ConfigParser").new == "configparser.ConfigParser"


# Generated at 2022-06-12 03:52:47.735553
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"



# Generated at 2022-06-12 03:52:56.606279
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma1.name == "cStringIO"
    assert ma1.new_mod == "io"
    assert ma1.new_attr == "StringIO"

    ma2 = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert ma2.name == "filter"
    assert ma2.new_mod == "builtins"
    assert ma2.new_attr == "filter"

    ma3 = MovedAttribute("map", "itertools", "builtins")
    assert ma3.name == "map"
    assert ma3.new_mod == "builtins"
    assert ma3.new_attr == "map"


# Generated at 2022-06-12 03:52:57.729354
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer

# Generated at 2022-06-12 03:53:04.674188
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("foo", "bar")
    assert moved_module.name == "foo"
    assert moved_module.old == "bar"
    assert moved_module.new == "foo"
    moved_module = MovedModule("foo", "bar", "baz")
    assert moved_module.new == "baz"

# Generated at 2022-06-12 03:53:07.871676
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    at = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert at.name == "cStringIO"
    assert at.new_attr == "StringIO"
    assert at.new_mod == "io"



# Generated at 2022-06-12 03:53:09.987945
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute('test', 'old_mod', 'new_mod', 'old_attr', 'new_attr')


# Generated at 2022-06-12 03:53:13.591559
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("tkinter", "Tkinter")
    assert move.name == 'tkinter'
    assert move.old == "Tkinter"
    assert move.new == 'tkinter'

# Generated at 2022-06-12 03:53:18.153881
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("tkinter", "Tkinter")
    assert mod.name == 'tkinter'
    assert mod.new == 'tkinter'
    mod = MovedModule("foo", "bar", "baz")
    assert mod.name == 'foo'
    assert mod.new == 'baz'



# Generated at 2022-06-12 03:53:23.079170
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:53:25.812812
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("email", "email.mime.text") == MovedModule("email", "email.mime.text")



# Generated at 2022-06-12 03:53:30.627734
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test for SixMovesTransformer constructor."""
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']


# Unit test function for SixMovesTransformer

# Generated at 2022-06-12 03:53:45.304628
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('test', 'old', 'new', 'old_attr', 'new_attr')
    assert a.name == 'test'
    assert a.new_mod == 'new'
    assert a.new_attr == 'new_attr'
    a = MovedAttribute('test', 'old', 'new', 'old_attr')
    assert a.new_attr == 'old_attr'
    a = MovedAttribute('test', 'old', 'new')
    assert a.new_attr == 'test'
    a = MovedAttribute('test', 'old')
    assert a.new_mod == 'test'

# Generated at 2022-06-12 03:53:49.316876
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Make sure created object is an instance of BaseImportRewrite class
    assert isinstance(SixMovesTransformer(), BaseImportRewrite), \
        "created object must be an instance of BaseImportRewrite"

# Generated at 2022-06-12 03:53:54.997683
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "new"

    module = MovedModule("name", "old")
    assert module.name == "name"
    assert module.old == "old"
    assert module.new == "name"

# Generated at 2022-06-12 03:54:05.614526
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert move.name == "filter"
    assert move.new_mod == "builtins"
    assert move.new_attr == "ifilter"

    move = MovedAttribute("module", "old", "new")
    assert move.name == "module"
    assert move.new_mod == "new"
    assert move.new_attr == "module"


# Generated at 2022-06-12 03:54:11.973869
# Unit test for constructor of class MovedModule
def test_MovedModule():

    assert MovedModule("builtins", "__builtin__") == MovedModule("builtins",
                                                                 "__builtin__")
    assert "builtins" == MovedModule("builtins", "__builtin__").name
    assert "__builtin__" == MovedModule("builtins", "__builtin__").old
    assert "builtins" == MovedModule("builtins", "__builtin__").new



# Generated at 2022-06-12 03:54:13.412644
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer


# Unit test function for this module

# Generated at 2022-06-12 03:54:16.968319
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six.moves.http_cookies as cookies
    assert isinstance(cookies, six.moves.http_cookiejar.CookieJar)


# Generated at 2022-06-12 03:54:25.255009
# Unit test for constructor of class MovedModule
def test_MovedModule():
    old_module = 'test_module'
    new_module = 'new_module'

    assert MovedModule(old_module, old_module, new_module).name == old_module
    assert MovedModule(old_module, old_module, new_module).new == new_module
    assert MovedModule(old_module, old_module).name == old_module
    assert MovedModule(old_module, old_module).new == old_module
    with pytest.raises(TypeError):
        MovedModule(old_module, old_module, "")


# Generated at 2022-06-12 03:54:30.969420
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").name == "name"
    assert MovedModule("name", "old", "new").new == "new"

# Generated at 2022-06-12 03:54:32.908372
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert isinstance(SixMovesTransformer.rewrites, dict) and SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:54:48.542958
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert item.name == 'cStringIO'
    assert item.new_mod == 'io'
    assert item.new_attr == 'StringIO'


# Generated at 2022-06-12 03:54:56.809783
# Unit test for constructor of class MovedAttribute

# Generated at 2022-06-12 03:54:59.106548
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    my_SixMovesTransformer = SixMovesTransformer()

if __name__ == "__main__":
    # Run the unit test
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:55:07.451660
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('a', 'b', 'c').name == 'a'
    assert MovedModule('a', 'b', 'c').old == 'b'
    assert MovedModule('a', 'b', 'c').new == 'c'
    assert MovedModule('a', 'b').name == 'a'
    assert MovedModule('a', 'b').old == 'b'
    assert MovedModule('a', 'b').new == 'a'
    assert MovedModule('a').name == 'a'
    assert MovedModule('a').old == 'a'
    assert MovedModule('a').new == 'a'

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 03:55:11.569054
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == 'name'
    assert m.new == 'name'
    m = MovedModule("name", "old", "new")
    assert m.name == 'name'
    assert m.new == 'new'


# Generated at 2022-06-12 03:55:20.442612
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of class SixMovesTransformer."""
    assert SixMovesTransformer.target == (2, 7)
    assert len(SixMovesTransformer.rewrites) == 68
    assert sorted(SixMovesTransformer.rewrites)[0] == ('__builtin__.cStringIO', 'six.moves.cStringIO')
    assert sorted(SixMovesTransformer.rewrites)[-1] == ('urllib.robotparser.RobotFileParser',
                                                        'six.moves.urllib.robotparser.RobotFileParser')
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-12 03:55:25.739267
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    moved_attribute2 = MovedAttribute("cStringIO", "cStringIO", "io", None, None)
    moved_attribute3 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", None)
    assert moved_attribute1.name == 'cStringIO' and moved_attribute1.new_mod == "cStringIO" \
           and moved_attribute1.new_attr == 'StringIO'
    assert moved_attribute2.name == 'cStringIO' and moved_attribute2.new_mod == "cStringIO" \
           and moved_attribute2.new_attr == 'cStringIO'
    assert moved_attribute3.name == 'cStringIO' and moved_attribute3.new

# Generated at 2022-06-12 03:55:28.943033
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.target == (2, 7)
    assert t.dependencies == ['six']
    for path, move in t.rewrites:
        assert path == '{}.{}'.format(move.split('.')[-2], move.split('.')[-1])

# Generated at 2022-06-12 03:55:34.649873
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"



# Generated at 2022-06-12 03:55:39.005371
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute("name", "a", "b", "c", "d")
    assert test.name == "name"
    assert test.new_mod == "b"
    assert test.new_attr == "d"


# Generated at 2022-06-12 03:56:04.365628
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s is not None


if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:56:10.061969
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('builtins', '__builtin__').new == 'builtins'
    assert MovedModule('builtins', '__builtin__').old == '__builtin__'
    # MovedModule('configparser', 'ConfigParser')
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').new == 'configparser'
    assert MovedModule('configparser', 'ConfigParser').old == 'ConfigParser'
    # MovedModule('configparser', 'ConfigParser')
    assert MovedModule('configparser', 'ConfigParser', 'configparser2').name == 'configparser'

# Generated at 2022-06-12 03:56:12.217582
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rt = SixMovesTransformer()
    assert rt.target == (2, 7)
    assert rt.dependencies == ['six']
    assert rt.rewrites == _get_rewrites()


# Generated at 2022-06-12 03:56:13.914564
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("html_entities", "htmlentitydefs", "html.entities")
    assert moved_module.new == "html.entities"


# Generated at 2022-06-12 03:56:15.677354
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(Exception):
        MovedModule('builtins', '__builtin__', 'builtins')

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:56:16.622349
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert _get_rewrites()
    SixMovesTransformer()

# Generated at 2022-06-12 03:56:26.128630
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("testing", "test.old", "test.new")
    assert move.name == "testing"
    assert move.new_mod == "test.new"
    assert move.new_attr == "testing"
    move = MovedAttribute("testing", "test.old", "test.new", "testing", "other")
    assert move.name == "testing"
    assert move.new_mod == "test.new"
    assert move.new_attr == "other"
    move = MovedAttribute("testing", "test.old", "test.new", "other")
    assert move.name == "testing"
    assert move.new_mod == "test.new"
    assert move.new_attr == "other"


# Generated at 2022-06-12 03:56:32.411560
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("foo", "Foo")
    assert mm.name == "foo"
    assert mm.new == "foo"
    assert mm.old == "Foo"
    mm = MovedModule("foo", "Foo", "bar")
    assert mm.name == "foo"
    assert mm.new == "bar"
    assert mm.old == "Foo"
    mm = MovedModule("foo", "foo", "bar")
    assert mm.name == "foo"
    assert mm.new == "bar"
    assert mm.old is None

# Generated at 2022-06-12 03:56:44.181865
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    result = sorted(SixMovesTransformer.rewrites)

# Generated at 2022-06-12 03:56:52.824786
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests that all modules are replaced correctly."""
    transformer = SixMovesTransformer()
    rewrites = transformer._rewrites

    def _check(import_name, module_path, import_from):
        import_from = 'from six.moves' + import_from
        assert import_name in rewrites
        assert rewrites[import_name] == ((import_from,), module_path)

    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                _check(move.name, '{}.{}'.format(move.new_mod, move.new_attr),
                       '.{}.{}'.format(move.new_mod, move.new_attr))
            elif isinstance(move, MovedModule):
                _check

# Generated at 2022-06-12 03:57:49.690293
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:57:56.561951
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    # 'name' is the same as 'new_attr' when the constructor is called without 'new_attr' arg
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    # default values for 'old_attr' and 'new_attr' args when no value is passed
    assert MovedAttribute("cStringIO", "cStringIO", "io").old_attr is None

# Generated at 2022-06-12 03:58:04.910286
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == {'name': "cStringIO", 'new_mod': "io", 'new_attr': "StringIO"}

# Generated at 2022-06-12 03:58:08.939629
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old', 'new')
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'


# Generated at 2022-06-12 03:58:11.691298
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    try:
        assert all(SixMovesTransformer.rewrites)
    except Exception:
        assert all(_get_rewrites())

# Generated at 2022-06-12 03:58:15.981088
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert(m.name == "name")
    assert(m.old == "old")
    assert(m.new == "new")

    m = MovedModule("name")
    assert(m.name == "name")
    assert(m.old == "name")
    assert(m.new == "name")


# Generated at 2022-06-12 03:58:25.932419
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', None, None).new_attr == 'name'

# Generated at 2022-06-12 03:58:30.491157
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'cStringIO'
    assert move.new_attr == 'StringIO'
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.new_attr == 'cStringIO'



# Generated at 2022-06-12 03:58:39.669462
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    with pytest.raises(TypeError):
        MovedAttribute()
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO")
    with pytest.raises(TypeError):
        MovedAttribute("cStringIO", "cStringIO")
    MovedAttribute("cStringIO", "cStringIO", "io")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")


# Generated at 2022-06-12 03:58:43.140192
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name_of_module", "old_name", "new_name")
    assert moved_module.name == "name_of_module"
    assert moved_module.old == "old_name"
    assert moved_module.new == "new_name"