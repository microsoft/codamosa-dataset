

# Generated at 2022-06-12 03:50:46.549401
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Tests the SixMovesTransformer constructor."""
    assert SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:50:47.830549
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('a', 'b', 'c').name == 'c'



# Generated at 2022-06-12 03:50:56.609035
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from python_modernize.fixes.six_moves import _get_rewrites


# Generated at 2022-06-12 03:51:02.310150
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name','old','new').name == 'name'
    assert MovedModule('name','old','new').new == 'new'
    assert MovedModule('name','old').new == 'name'
    assert MovedModule('name').name == 'name'
    assert MovedModule('name').new == 'name'


# Generated at 2022-06-12 03:51:11.107985
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert a.name == "name"
    assert a.new_mod == "new_mod"
    assert a.new_attr == "new_attr"
    b = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert b.name == "name"
    assert b.new_mod == "new_mod"
    assert b.new_attr == "old_attr"
    c = MovedAttribute("name", "old_mod", "new_mod")
    assert c.name == "name"
    assert c.new_mod == "new_mod"
    assert c.new_attr == "name"

# Generated at 2022-06-12 03:51:15.921950
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    prop = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert prop.name == "name"
    assert prop.new_mod == "new_mod"
    assert prop.new_attr == "new_attr"


# Generated at 2022-06-12 03:51:27.040118
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

    move = MovedAttribute("cStringIO", "cStringIO", None)
    assert move.name == "cStringIO"
    assert move.new_mod == "cStringIO"
    assert move.new_attr == "cStringIO"

# Generated at 2022-06-12 03:51:37.566762
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:51:48.612147
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("builtins", "__builtin__")
    assert a.name == "builtins"
    assert a.new == "builtins"
    b = MovedModule("builtins", "__builtin__", "six.moves.builtins")
    assert a.name == "builtins"
    assert b.new == "six.moves.builtins"
    c = MovedModule("copyreg", "copy_reg")
    assert c.name == "copyreg"
    assert c.new == "copyreg"
    d = MovedModule("copyreg", "copy_reg", "six.moves.copyreg")
    assert d.name == "copyreg"
    assert d.new == "six.moves.copyreg"
    e = MovedModule("winreg", "_winreg")

# Generated at 2022-06-12 03:51:58.202801
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import port_for
    import py2to3.utils.http
    import py2to3.utils.helpers
    import py2to3.transforms.imports
    import py2to3.PLUGINS

    env_conf = {'PY2TO3': {'disable_database': True}}
    port = port_for.get(env_conf=env_conf)
    http.start_server(port)
    http.set_fake_responses(False)
    plugins = tuple(py2to3.PLUGINS)
    py2to3.PLUGINS.clear()
    py2to3.PLUGINS.add(SixMovesTransformer)
    code = "from cStringIO import StringIO"
    proc = py2to3.main.process_string(code, fixers=None)
   

# Generated at 2022-06-12 03:52:02.446241
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = SixMovesTransformer()
    assert s.target == (2, 7)
    assert len(s.rewrites) == 92
    assert len(s.dependencies) == 1
    assert s.dependencies[0] == "six"

# Generated at 2022-06-12 03:52:11.797381
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name_attr', 'old_attr', 'new_attr')
    assert a.name == 'name_attr'
    assert a.old == 'old_attr'
    assert a.new == 'new_attr'

    b = MovedModule('name_attr', 'old_attr')
    assert b.name == 'name_attr'
    assert b.old == 'old_attr'
    assert b.new == 'name_attr'

    c = MovedModule('name_attr')
    assert c.name == 'name_attr'
    assert c.old == 'name_attr'
    assert c.new == 'name_attr'



# Generated at 2022-06-12 03:52:25.023051
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"
    ma = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO", new_attr="Size")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "Size"
    ma = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="Size")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "Size"

# Generated at 2022-06-12 03:52:27.843171
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for ma in _moved_attributes:
        if isinstance(ma, MovedAttribute):
            assert ma.name == ma.new_attr
            break

# Generated at 2022-06-12 03:52:35.146127
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__') == MovedModule('builtins', '__builtin__')

    assert MovedModule('builtins', '__builtin__') != MovedModule('builtins', '__builtin__', 'builtins')
    assert MovedModule('builtins', '__builtin__') != MovedModule('_builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__') != MovedModule('builtin', '__builtin__')



# Generated at 2022-06-12 03:52:38.430441
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule("foo_module", "original.name", "new.name")
    assert mod.name == "foo_module"
    assert mod.old == "original.name"
    assert mod.new == "new.name"

# Generated at 2022-06-12 03:52:39.905047
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('a',1, 2)


# Generated at 2022-06-12 03:52:42.376757
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import run
    run()

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-12 03:52:49.955382
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert ('{}.{}'.format(path, move.new_attr), 'six.moves{}.{}'.format(prefix, move.name)) in _get_rewrites()
            elif isinstance(move, MovedModule):
                assert (move.new, 'six.moves{}.{}'.format(prefix, move.name)) in _get_rewrites()

# Generated at 2022-06-12 03:52:58.582275
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves = prefixed_moves[0][1]
    moves.append(MovedModule('test', 'test'))
    s = SixMovesTransformer()
    assert len(s.rewrites) == len(moves)
    for move, rewrite in zip(moves, s.rewrites):
        if isinstance(move, MovedAttribute):
            assert rewrite[0] == move.new_mod + '.' + move.new_attr
            assert rewrite[1] == 'six' + '.moves.' + move.name
        elif isinstance(move, MovedModule):
            assert rewrite[0] == move.new
            assert rewrite[1] == 'six' + '.moves.' + move.name

# Generated at 2022-06-12 03:53:04.724541
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('sys', 'os')
    assert m.name == 'sys'
    assert m.new == 'sys'


# Generated at 2022-06-12 03:53:07.377654
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedAttribute("configparser", "ConfigParser", "configparser")
    MovedAttribute("moved_attribute", "moved_module", "moved_module", "moved_attribute", "moved_attribute")

# Generated at 2022-06-12 03:53:17.945620
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == move.cStringIO

    move = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert move.name == 'input'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'input'


# Generated at 2022-06-12 03:53:26.551216
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == 'cStringIO'
    assert MovedAttribute("filter", "itertools", "builtins").new_mod == 'builtins'
    assert MovedAttribute("filterfalse", "itertools", "itertools").new_attr == 'filterfalse'
    assert MovedAttribute("input", "__builtin__", "builtins").new_attr == 'input'
    assert MovedAttribute("range", "__builtin__", "builtins").old_attr == 'xrange'


# Generated at 2022-06-12 03:53:38.126680
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "new_attr"

    attr = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new_attr == "old_attr"

    attr = MovedAttribute("name", "old_mod", "new_mod", None, "new_attr")
    assert attr.name == "name"
    assert attr.new_mod == "new_mod"
    assert attr.new

# Generated at 2022-06-12 03:53:42.235512
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_obj = MovedModule(name = "name", old = "old", new = "new")
    assert test_obj.name == "name"
    assert test_obj.old == "old"
    assert test_obj.new == "new"


# Generated at 2022-06-12 03:53:50.046109
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old', 'new')
    assert m.name == 'name'
    assert m.new_mod == 'new'
    assert m.new_attr == 'name'
    m = MovedAttribute('name', 'old', 'new', 'old_attr')
    assert m.new_attr == 'old_attr'
    m = MovedAttribute('name', 'old', 'new', None, 'new_attr')
    assert m.new_attr == 'new_attr'


# Generated at 2022-06-12 03:54:01.463973
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:54:12.701263
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # MovedAttribute(name, old_mod, new_mod, old_attr=None, new_attr=None):
    # MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"),
    assert(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io")
    assert(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO")
    assert(MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO")
    # MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter"),

# Generated at 2022-06-12 03:54:23.343800
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"

# Generated at 2022-06-12 03:54:34.337385
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == 'cStringIO'
    assert m.new_mod == 'io'
    assert m.new_attr == 'StringIO'


# Generated at 2022-06-12 03:54:39.441053
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old").name == "name"
    assert MovedModule("name", "old").old == "old"
    assert MovedModule("name", "old").new == "name"
    assert MovedModule("name", "old", "new").new == "new"


# Generated at 2022-06-12 03:54:43.372516
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    if sys.version_info >= (3,):
        return
    transformer = SixMovesTransformer()
    assert len(transformer.rewrites) > 0
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:54:48.792188
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule('asdf', 'asdf')
    assert x.name == 'asdf'
    assert x.new == 'asdf'

    x = MovedModule('asdf', 'asdf', 'sdfg')
    assert x.name == 'asdf'
    assert x.new == 'sdfg'

# Generated at 2022-06-12 03:54:56.930264
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Testing having just a module name
    assert MovedAttribute('_winreg', '_winreg').new_mod == '_winreg'
    assert MovedAttribute('_winreg', '_winreg').new_attr == '_winreg'

    # No old_attr, new_attr should be old_attr
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter').new_attr == 'ifilter'

    # No new_attr, new_attr should be old_attr
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'

    # None old_attr, new_attr
    assert MovedAttribute('filter', 'itertools', 'builtins', 'ifilter', 'filter').new_attr == 'filter'

# Generated at 2022-06-12 03:55:04.331085
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=missing-docstring
    assert MovedModule('foo', 'foo', 'foo').name == 'foo'
    assert MovedModule('foo', 'foo', 'foo').new == 'foo'

    assert MovedModule('foo', 'foo').name == 'foo'
    assert MovedModule('foo', 'foo').new == 'foo'

    assert MovedModule('foo', 'bar').name == 'foo'
    assert MovedModule('foo', 'bar').new == 'foo'

    assert MovedModule('foo', 'foo', 'bar').name == 'foo'
    assert MovedModule('foo', 'foo', 'bar').new == 'bar'


# Generated at 2022-06-12 03:55:05.242577
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:55:08.616626
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("a", "b").name == "a"
    assert MovedModule("a", "b").new == "a"
    assert MovedModule("a", "b").old == "b"


# Generated at 2022-06-12 03:55:13.625802
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "cStringIO"

# Generated at 2022-06-12 03:55:18.735096
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('test', 'old_mod', 'new_mod').name == 'test'
    assert MovedAttribute('test', 'old_mod', 'new_mod').new_mod == 'new_mod'
    assert MovedAttribute('test', 'old_mod', 'new_mod').new_attr == 'test'


# Generated at 2022-06-12 03:55:35.440178
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('a', 'b', 'c')
    assert mm.name == 'a'
    assert mm.old == 'b'
    assert mm.new == 'c'
    mm2 = MovedModule('d', 'e')
    assert mm2.name == 'd'
    assert mm2.old == 'e'
    assert mm2.new == 'd'

# Generated at 2022-06-12 03:55:38.198233
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-12 03:55:42.847715
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved_attribute.name == 'name'
    assert moved_attribute.new_mod == 'new_mod'
    assert moved_attribute.new_attr == 'new_attr'


# Generated at 2022-06-12 03:55:45.966275
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MM = MovedModule("name", "old", "new")
    assert MM.name == "name"
    assert MM.old == "old"
    assert MM.new == "new"


# Generated at 2022-06-12 03:55:48.700096
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.dependencies == ['six']
    assert t.target == (2, 7)
    assert isinstance(t.rewrites, tuple)

# Generated at 2022-06-12 03:55:55.900856
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a = MovedAttribute("map", "itertools", "builtins", "imap", "map")
    assert a.name == "map"
    assert a.new_mod == "builtins"
    assert a.new_attr == "map"


# Generated at 2022-06-12 03:56:00.642978
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"



# Generated at 2022-06-12 03:56:01.676379
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert list(_get_rewrites())

# Generated at 2022-06-12 03:56:08.495438
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.new == "builtins"
    assert move.old == "__builtin__"
    move = MovedModule("builtins", "__builtin__", "new_builtins")
    assert move.name == "builtins"
    assert move.new == "new_builtins"
    assert move.old == "__builtin__"
    move = MovedModule("builtins", "__builtin__", "new_builtins", "old_builtins")
    assert move.name == "builtins"
    assert move.new == "new_builtins"
    assert move.old == "old_builtins"


# Generated at 2022-06-12 03:56:09.205683
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()

# Generated at 2022-06-12 03:56:36.860970
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name', 'old', 'new')
    assert moved_module.name == 'name'
    assert moved_module.old is None
    assert moved_module.new == 'new'


# Generated at 2022-06-12 03:56:45.322022
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").name == "filterfalse"
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").name == "input"
    assert MovedAttribute("intern", "__builtin__", "sys").name == "intern"



# Generated at 2022-06-12 03:56:49.078586
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('b', 'a')
    assert mod.name == 'b'
    assert mod.new == 'b'

    mod = MovedModule('b', 'a', 'c')
    assert mod.name == 'b'
    assert mod.new == 'c'

# Generated at 2022-06-12 03:56:52.128254
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("Queue", "collections.deque", "queue")
    assert mm.name == "Queue"
    assert mm.old == "collections.deque"
    assert mm.new == "queue"



# Generated at 2022-06-12 03:56:57.213515
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('a', 'b', 'c')
    assert mod.name == 'a'
    assert mod.new == 'c'

    mod = MovedModule('a', 'b', 'a')
    assert mod.name == 'a'
    assert mod.new == 'a'

    mod = MovedModule('a', 'b')
    assert mod.name == 'a'
    assert mod.new == 'a'



# Generated at 2022-06-12 03:56:59.479866
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.new == "builtins"
    assert moved_module.name == "builtins"

# Generated at 2022-06-12 03:57:07.435633
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:57:08.668941
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert sorted(SixMovesTransformer.rewrites) == sorted(_get_rewrites())

# Generated at 2022-06-12 03:57:13.781259
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.new_attr == "cStringIO"



# Generated at 2022-06-12 03:57:21.008563
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # pylint: disable=protected-access
    assert MovedAttribute("a", "b", "c") == MovedAttribute("a", "b", "c")
    assert MovedAttribute("a", "b", "c")._replace(new_mod='e') == MovedAttribute("a", "b", "e")
    assert MovedAttribute("a", "b", "c", old_attr="d", new_attr="e") == MovedAttribute("a", "b", "c", old_attr="d", new_attr="e")
    assert MovedAttribute("a", "b", "c", old_attr="d", new_attr="e")._replace(new_mod='f') == MovedAttribute("a", "b", "f", old_attr="d", new_attr="e")

# Generated at 2022-06-12 03:58:27.384871
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("abc", "abc").name == "abc"
    assert MovedAttribute("abc", "abc").new_mod == "abc"
    assert MovedAttribute("abc", "abc").new_attr == "abc"

    assert MovedAttribute("abc", "lmn", "def").name == "abc"
    assert MovedAttribute("abc", "lmn", "def").new_mod == "def"

    assert MovedAttribute("abc", "lmn", "def", "ghi").name == "abc"
    assert MovedAttribute("abc", "lmn", "def", "ghi").new_mod == "def"
    assert MovedAttribute("abc", "lmn", "def", "ghi").new_attr == "ghi"


# Generated at 2022-06-12 03:58:37.498737
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "name"
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "old_attr"
    ma = MovedAttribute("name", "old_mod", "new_mod", new_attr="new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"


# Generated at 2022-06-12 03:58:40.025276
# Unit test for constructor of class MovedModule
def test_MovedModule():
    newModule = MovedModule('configparser','ConfigParser')
    assert newModule.name == 'configparser'
    assert newModule.old == 'ConfigParser'
    assert newModule.new == 'configparser'

# Generated at 2022-06-12 03:58:41.869251
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.new == 'new'

# Generated at 2022-06-12 03:58:50.100305
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()

# Generated at 2022-06-12 03:58:54.836202
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('tkinter', 'Tkinter').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter').new == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter', 'tkinter.tkinter').new == 'tkinter.tkinter'
    assert MovedModule('tkinter', 'Tkinter', 'tkinter.tkinter').name == 'tkinter'


# Generated at 2022-06-12 03:59:01.000706
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ma.name == "cStringIO"
    assert ma.new_mod == "io"
    assert ma.new_attr == "StringIO"

    ma = MovedAttribute("reduce", "__builtin__", "functools")
    assert ma.name == "reduce"
    assert ma.new_mod == "functools"
    assert ma.new_attr == "reduce"


# Generated at 2022-06-12 03:59:03.450640
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('builtins', '__builtin__')
    assert moved_module.name == 'builtins'
    assert moved_module.new == 'builtins'

# Generated at 2022-06-12 03:59:14.142927
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():  # noqa
    t = SixMovesTransformer()
    assert t.dependencies == ['six']
    assert len(t.rewrites) == 152
    assert t.rewrites[0][0] == 'os.getcwd'
    assert t.rewrites[0][1] == 'six.moves.getcwd'
    assert t.rewrites[1][0] == 'os.getcwdb'
    assert t.rewrites[1][1] == 'six.moves.getcwdb'
    assert t.rewrites[2][0] == 'io.StringIO'
    assert t.rewrites[2][1] == 'six.moves.StringIO'
    assert t.rewrites[3][0] == 'itertools.filter'

# Generated at 2022-06-12 03:59:17.289836
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    assert moved_attribute.name == "input"
    assert moved_attribute.new_mod == "builtins"
    assert moved_attribute.new_attr == "input"
