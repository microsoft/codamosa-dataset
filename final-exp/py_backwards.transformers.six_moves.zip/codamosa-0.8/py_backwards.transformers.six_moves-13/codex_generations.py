

# Generated at 2022-06-12 03:50:55.631087
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import libmodernize

    code = """
    from six.moves import range
    from six.moves import map
    """

    tree = ast.parse(code)
    mod = libmodernize.parse.Module('six.moves', tree)
    SixMovesTransformer(mod)

    assert mod.uses_imports == {'six.moves'}
    assert mod.uses_aliases == ['six_moves']

    code_expected = """
    from six.moves import map, range
    """

    assert mod.tree.body[1].value.args[0].id == 'map'
    assert mod.tree.body[1].value.args[1].id == 'range'
    assert ast.dump(mod.tree) == ast.dump(ast.parse(code_expected))

# Generated at 2022-06-12 03:50:59.104874
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Should be able to initialize instance of MovedModule
    MovedModule('test', 'oldtest')
    MovedModule('test', 'oldtest', 'newtest')
    MovedModule('test', 'oldtest', 'newtest')

# Generated at 2022-06-12 03:51:09.792386
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import inspect
    # Create a list of all possible attributes to six.moves
    moves_set = set(six.moves.__dict__.keys())
    # Remove the __builtins__
    moves_set.remove('__builtins__')
    # Create a list of all possible attributes to six
    six_set = set(six.__dict__.keys())
    # Create a list of all possible attributes to rewrites
    rewrites_set = set(SixMovesTransformer.rewrites.keys())
    # Check that there are no attributes to six.moves which are not in rewrites
    assert not moves_set - rewrites_set
    # Check that there are no attributes to six which are not in rewrites
    assert not six_set - rewrites_set
    # Check that there is an

# Generated at 2022-06-12 03:51:16.437541
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('json', 'json', 'json')
    assert moved_module.name == 'json'
    assert moved_module.old == 'json'
    assert moved_module.new == 'json'

    moved_module = MovedModule('json', 'json')
    assert moved_module.name == 'json'
    assert moved_module.old == 'json'
    assert moved_module.new == 'json'


# Generated at 2022-06-12 03:51:28.300034
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys

    # Just check that the method is actually working; the real tests are in six tests
    # (tests/test_six.py)
    #
    # This test is not valid if six is not installed, but failing to import six
    # is not the point
    transformer = SixMovesTransformer()
    assert transformer.rewrites != []
    transformer = SixMovesTransformer(rewrites=transformer.rewrites)
    assert transformer.rewrites != []
    transformer = SixMovesTransformer(target=(3,), rewrites=transformer.rewrites)
    assert transformer.rewrites == []
    transformer = SixMovesTransformer(target=sys.version_info, rewrites=transformer.rewrites)
    assert transformer.rewrites != []

# Generated at 2022-06-12 03:51:30.949877
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()
    assert MovedModule('name', 'old')


# Generated at 2022-06-12 03:51:40.292308
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'path', 'path')
    assert move.name == 'name'
    assert move.new_mod == 'path'
    assert move.new_attr == 'name'
    move = MovedAttribute('name', 'path', 'path', 'oldattr')
    assert move.name == 'name'
    assert move.new_mod == 'path'
    assert move.new_attr == 'oldattr'
    move = MovedAttribute('name', 'path', 'path', 'oldattr', 'newattr')
    assert move.name == 'name'
    assert move.new_mod == 'path'
    assert move.new_attr == 'newattr'
    move = MovedAttribute('name', 'path', None)
    assert move.name == 'name'

# Generated at 2022-06-12 03:51:46.603293
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert move.__dict__ == {
        'name': 'name', 'old_mod': 'old_mod', 'new_mod': 'new_mod', 'old_attr': 'old_attr', 'new_attr': 'new_attr'}


# Generated at 2022-06-12 03:51:49.497508
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = 'module'
    mov = MovedModule(mod, mod)
    assert mov.name == mod
    assert mov.old == mod
    assert mov.new == mod

    # New value should override old
    new_mod = 'new_module'
    mov2 = MovedModule(mod, mod, new_mod)
    assert mov2.name == mod
    assert mov2.old == mod
    assert mov2.new == new_mod


# Generated at 2022-06-12 03:51:51.360775
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StringIO")

# Generated at 2022-06-12 03:51:55.655253
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.dependencies == ['six']
    assert t.target == (2, 7)
    assert len(t.rewrites) == len(_get_rewrites())

# Generated at 2022-06-12 03:51:58.521887
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("urllib.request", "urllib2").__dict__ == {
        "name": "urllib.request",
        "old": "urllib2",
        "new": "urllib.request"}


# Generated at 2022-06-12 03:52:01.590294
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

# Generated at 2022-06-12 03:52:11.007042
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    sets = set()  # type: Set[Tuple[str, str]]
    sets.add(('a.b.c', 'six.moves.b'))
    sets.add(('a.d.e', 'six.moves.d'))
    # Will create a singleton list, so that it can be used to initialize the class variable `rewrites`
    rewrites = tuple([(set) for set in sets])
    smt = SixMovesTransformer(target=(2, 7), rewrites=rewrites, dependencies=['six'])
    assert smt.target == (2, 7)
    assert smt.rewrites == rewrites
    assert smt.dependencies == ['six']

# Generated at 2022-06-12 03:52:21.721293
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", None, None).new_attr == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", None).new_attr == "old_attr"



# Generated at 2022-06-12 03:52:23.129741
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']



# Generated at 2022-06-12 03:52:27.637354
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("tkinter", "Tkinter")
    assert "tkinter" == moved_module.name == moved_module.new


# Generated at 2022-06-12 03:52:30.983260
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule("name", "old", "new")
    assert a.name == "name"
    assert a.old == "old"
    assert a.new == "new"


# Generated at 2022-06-12 03:52:38.258419
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("tkinter", "Tkinter")
    assert mm.name == "tkinter"
    assert mm.new == "tkinter"
    assert mm.old == "Tkinter"
    mm1 = MovedModule("tkinter", "Tkinter", "tkinter")
    assert mm1.name == "tkinter"
    assert mm1.new == "tkinter"
    assert mm1.old == "Tkinter"
    mm2 = MovedModule("tkinter", "Tkinter", "tkinter.new")
    assert mm2.name == "tkinter"
    assert mm2.new == "tkinter.new"
    assert mm2.old == "Tkinter"


# Generated at 2022-06-12 03:52:43.538591
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    stmt = ast.parse('import six.moves.urllib')
    node = stmt.body[0]
    assert SixMovesTransformer(node).new is None
    assert node.module == 'six.moves'

    stmt = ast.parse('from six.moves import urlparse')
    node = stmt.body[0]
    assert SixMovesTransformer(node).new is None
    assert node.module == 'six.moves'
    assert node.names[0].name == 'urlparse'

    stmt = ast.parse('import six.moves.urllib as urls')
    node = stmt.body[0]
    assert SixMovesTransformer(node).new is None
    assert node.module == 'six.moves'
    assert node.asname == 'urls'

# Generated at 2022-06-12 03:52:50.167690
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    import sys
    # patch sys.modules so that six.moves always imports from six
    moves = six.moves
    sys.modules['six.moves'] = moves
    try:
        # make sure all attributes are imported
        for _, _ in SixMovesTransformer.rewrites:
            pass
    finally:
        # unpatch sys.modules
        sys.modules['six.moves'] = six

# Generated at 2022-06-12 03:52:52.072082
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_six import _get_expected_rewrites

    assert list(_get_expected_rewrites()) == list(_get_rewrites())

# Generated at 2022-06-12 03:52:55.969584
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert type(m) == MovedAttribute
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'

# Generated at 2022-06-12 03:53:01.235379
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('moved_name', 'old_name')
    assert moved_module.name == 'moved_name'
    assert moved_module.new == 'moved_name'
    assert moved_module.old == 'old_name'



# Generated at 2022-06-12 03:53:13.084113
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "StrIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StrIO"

    move = MovedAttribute("cStringIO")
    assert move

# Generated at 2022-06-12 03:53:21.502533
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").old_mod == "old_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").old_attr == "old_attr"


# Generated at 2022-06-12 03:53:24.963703
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    s = _moved_attributes[1]
    assert s.name == 'filter'
    assert s.new_attr == 'filter'
    assert s.old_attr == 'ifilter'


# Generated at 2022-06-12 03:53:35.484029
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").name == "name"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").old_mod == "old_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_mod == "new_mod"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").old_attr == "old_attr"
    assert MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr").new_attr == "new_attr"


# Generated at 2022-06-12 03:53:40.349177
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"



# Generated at 2022-06-12 03:53:51.904238
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"
    assert a.old_attr == None

    b = MovedAttribute("filter", "itertools", "itertools", "ifilter", "filter")
    assert b.name == "filter"
    assert b.new_mod == "itertools"
    assert b.new_attr == "filter"
    assert b.old_attr == "ifilter"

    c = MovedAttribute("shlex_quote", "pipes", "shlex", "quote")
    assert c.name == "shlex_quote"
    assert c.new_mod == "shlex"


# Generated at 2022-06-12 03:53:55.594912
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    item = MovedAttribute('name','old_mod','new_mod','old_attr','new_attr')
    assert item.name == 'name'
    assert item.new_mod == 'new_mod'
    assert item.new_attr == 'new_attr'
    assert 'MovedAttribute' == item.__class__.__name__


# Generated at 2022-06-12 03:53:59.611401
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'new'

    del obj
    obj = MovedModule('name', 'old')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'name'

# Generated at 2022-06-12 03:54:07.435226
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("builtins", "__builtin__")
    assert moved_module.name == "builtins"
    assert moved_module.new == "builtins"
    assert moved_module.old is None

    moved_module = MovedModule("tkinter", "Tkinter", "tkinter")
    assert moved_module.name == "tkinter"
    assert moved_module.new == "tkinter"
    assert moved_module.old == "Tkinter"


# Generated at 2022-06-12 03:54:12.722306
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test that the constructor works as expected
    obj = MovedModule('foo', 'bar')
    assert obj.name == 'foo'
    assert obj.new == 'bar'
    # Test that the constructor has a default value for the name of the new
    # location
    obj = MovedModule('foo', 'bar', 'baz')
    assert obj.name == 'foo'
    assert obj.new == 'baz'


# Generated at 2022-06-12 03:54:21.157607
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']


if __name__ == "__main__":
    # Run the unit test
    import sys
    import doctest
    doctest.testmod(verbose=True)

    # Run the transformer on stdin and print result to stdout
    transformer = SixMovesTransformer()
    transformer.run_stdin(sys.stdin, sys.stdout)

# Generated at 2022-06-12 03:54:33.282277
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites[0] == ('_winreg', 'six.moves._winreg')
    assert transformer.rewrites[1] == ('urllib.parse.urlencode', 'six.moves.urllib.urlencode')
    assert transformer.rewrites[2] == ('urllib.error.ContentTooShortError', 'six.moves.urllib.ContentTooShortError')
    assert transformer.rewrites[3] == ('urllib.request.ProxyDigestAuthHandler', 'six.moves.urllib.ProxyDigestAuthHandler')
    assert transformer.rewrites[4] == ('urllib.response.addclosehook', 'six.moves.urllib.addclosehook')

# Generated at 2022-06-12 03:54:38.168037
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test the constructor of class MovedModule
    name = 'test'
    old = 'test_old'
    new = 'test_new'

    moved_module = MovedModule(name, old, new)

    assert moved_module.name == name
    assert moved_module.new == new

# Generated at 2022-06-12 03:54:50.130477
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') == \
        MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') != \
        MovedAttribute('name2', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr') != \
        MovedAttribute('name', 'old_mod2', 'new_mod', 'old_attr', 'new_attr')

# Generated at 2022-06-12 03:54:52.745845
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for field in ['name', 'new_mod', 'new_attr', 'old_mod', 'old_attr']:
        assert hasattr(MovedAttribute("name", "mod", "attr"), field)



# Generated at 2022-06-12 03:55:00.742668
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", None, "filter").new_attr == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", None, "filter").name == "filter"

# Generated at 2022-06-12 03:55:14.000605
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').name \
        == 'name'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_mod \
        == 'new_mod'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr').new_attr \
        == 'new_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', None).new_attr \
        == 'old_attr'
    assert MovedAttribute('name', 'old_mod', 'new_mod', None, 'new_attr').new_attr \
        == 'new_attr'
    assert Moved

# Generated at 2022-06-12 03:55:17.061361
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module_name = MovedModule('name', 'old', 'new')
    assert module_name.name == 'name'
    assert module_name.old == 'old'
    assert module_name.new == 'new'

    module_name_2 = MovedModule('name', 'old')
    assert module_name_2.name == 'name'
    assert module_name_2.old == 'old'
    assert module_name_2.new == 'name'



# Generated at 2022-06-12 03:55:20.443882
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("name", "old", "new")
    assert mm.name == "name"
    assert mm.old == "old"
    assert mm.new == "new"


# Generated at 2022-06-12 03:55:29.836874
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").name == "cStringIO"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_mod == "io"
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").name == "filter"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_mod == "builtins"
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == "filter"

# Generated at 2022-06-12 03:55:34.438948
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:55:40.504229
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule('name', 'old')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'name'

    obj = MovedModule('name', 'old', 'new')
    assert obj.name == 'name'
    assert obj.old == 'old'
    assert obj.new == 'new'


# Generated at 2022-06-12 03:55:44.960032
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # type: () -> None
    moved_module = MovedModule('configparser', 'ConfigParser')
    assert getattr(moved_module, 'name') == 'configparser'
    assert getattr(moved_module, 'old') == 'ConfigParser'
    assert getattr(moved_module, 'new') == 'configparser'


# Generated at 2022-06-12 03:55:46.267924
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    obj = SixMovesTransformer()
    assert obj is not None

# Generated at 2022-06-12 03:55:53.155603
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    correct_name = "name"
    correct_old_mod = "old_mod"
    correct_new_mod = "new_mod"
    correct_old_attr = "old_attr"
    correct_new_attr = "new_attr"
    this = MovedAttribute(correct_name, correct_old_mod, correct_new_mod, correct_old_attr, correct_new_attr)
    assert this.name == correct_name
    assert this.new_mod == correct_new_mod
    assert this.new_attr == correct_new_attr

# Generated at 2022-06-12 03:55:57.925788
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.__name__ == 'SixMovesTransformer'
    assert SixMovesTransformer.target == (2, 7)
    assert SixMovesTransformer.dependencies == ['six']
    assert len(SixMovesTransformer.rewrites) == 110

# Generated at 2022-06-12 03:56:05.150557
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(set(_get_rewrites()))

# Generated at 2022-06-12 03:56:11.005803
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    import os
    import ast
    import unittest
    import tempfile
    from io import StringIO

    from importlib import reload  # type: ignore
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib import machinery

    sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/../../'))

    from japronto.jinja2.ext import is_ast_call, is_ast_attribute
    from .six_moves import SixMovesTransformer

    class SixMovesTransformer_test(unittest.TestCase):
        def setUp(self):
            dir_path = os.path.dirname(os.path.realpath(__file__))
            self.temps

# Generated at 2022-06-12 03:56:16.654436
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseReferenceRewrite
    from .base import BaseImportRewrite
    from .base import BaseRewrite
    from .base import BaseASTTransform
    from .base import BaseDocstringTransform
    from .base import BaseUnparseTransform
    from .base import BasePreTransform
    from .base import BasePostTransform
    from .base import BaseCodeTransform
    from .base import BaseNodeTransformer
    BaseReferenceRewrite()
    BaseImportRewrite()
    BaseRewrite()
    BaseASTTransform()
    BaseDocstringTransform()
    BaseUnparseTransform()
    BasePreTransform()
    BasePostTransform()
    BaseCodeTransform()
    BaseNodeTransformer()
    SixMovesTransformer()

# Generated at 2022-06-12 03:56:17.646221
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 83

# Generated at 2022-06-12 03:56:22.102134
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tests = {(2, 7): ['six.moves'],
             (3, 4): ['six'],
             (3, 5): ['six']}
    for target, dep in tests.items():
        x = SixMovesTransformer(target=target)
        assert x.dependencies == dep



# Generated at 2022-06-12 03:56:31.105425
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ret = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert ret.__dict__ == {'name': 'cStringIO', 'new_mod': 'io', 'new_attr': 'StringIO'}
    ret = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert  ret.__dict__ == {'name': 'filter', 'new_mod': 'builtins', 'new_attr': 'filter'}
    ret = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    assert  ret.__dict__ == {'name': 'filterfalse', 'new_mod': 'itertools', 'new_attr': 'filterfalse'}

# Generated at 2022-06-12 03:56:37.343558
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:41.005219
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('http_cookies', 'Cookie', 'http.cookies').name == 'http_cookies'
    assert MovedModule('http_cookies', 'Cookie', 'http.cookies').new == 'http.cookies'

# Generated at 2022-06-12 03:56:46.020120
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new is None


# Generated at 2022-06-12 03:56:47.305180
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule('builtins', '__builtin__')

# Generated at 2022-06-12 03:57:02.804433
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    m = SixMovesTransformer()
    assert m.rewrites == _get_rewrites()
    assert m.dependencies == [six.__name__]

# Generated at 2022-06-12 03:57:07.196628
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=invalid-name
    assert MovedModule("ht", "http").name == "ht"
    assert MovedModule("ht", "http").new == "http"
    assert MovedModule("ht", "http", "http2").name == "ht"
    assert MovedModule("ht", "http", "http2").new == "http2"

# Generated at 2022-06-12 03:57:16.620688
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    move = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    move = MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse")
    move = MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input")
    move = MovedAttribute("intern", "__builtin__", "sys")
    move = MovedAttribute("map", "itertools", "builtins", "imap", "map")
    move = MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd")

# Generated at 2022-06-12 03:57:19.100374
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('a', 'b', 'c')
    assert move.name == 'a'
    assert move.old == 'b'
    assert move.new == 'c'

# Generated at 2022-06-12 03:57:20.289015
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test the constructor of SixMovesTransformer"""
    SixMovesTransformer()

# Generated at 2022-06-12 03:57:25.438682
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute('name', 'old_mod', 'new_mod')
    assert m.name == 'name'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'name'
    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert m.new_attr == 'new_attr'


# Generated at 2022-06-12 03:57:30.301183
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'

    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'old'



# Generated at 2022-06-12 03:57:40.186218
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved.name == 'name'
    assert moved.new_mod == 'new_mod'
    assert moved.new_attr == 'new_attr'
    moved = MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr')
    assert moved.name == 'name'
    assert moved.new_mod == 'new_mod'
    assert moved.new_attr == 'old_attr'
    moved = MovedAttribute('name', 'old_mod', 'new_mod', new_attr='new_attr')
    assert moved.name == 'name'
    assert moved.new_mod == 'new_mod'
    assert moved.new_attr == 'new_attr'

# Generated at 2022-06-12 03:57:44.803249
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    M = MovedAttribute("aaa", "BBB", "CCC")
    assert M.name == "aaa"
    assert M.new_mod == "CCC"
    assert M.new_attr == "aaa"

    M = MovedAttribute("aaa", "BBB", "CCC", "DDD", "EEE")
    assert M.name == "aaa"
    assert M.new_mod == "CCC"
    assert M.new_attr == "EEE"


# Generated at 2022-06-12 03:57:50.356791
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('tkinter', 'Tkinter').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter').new == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter', 'Tkinter').name == 'tkinter'
    assert MovedModule('tkinter', 'Tkinter', 'Tkinter').new == 'Tkinter'


# Generated at 2022-06-12 03:58:22.510899
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 140

# Generated at 2022-06-12 03:58:32.751940
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # pylint: disable=missing-raises-doc,protected-access
    assert MovedModule("builtins", "__builtin__", "builtins") == \
        MovedModule("builtins", "__builtin__")
    assert MovedModule("copyreg", "copy_reg", "copyreg") == \
        MovedModule("copyreg", "copy_reg")
    assert MovedModule("dbm_gnu", "gdbm", "dbm.gnu") == \
        MovedModule("dbm_gnu", "gdbm")
    assert MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread") == \
        MovedModule("_dummy_thread", "dummy_thread")

# Generated at 2022-06-12 03:58:38.636130
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('test_module', 'old_module', 'new_module') == \
        MovedModule('test_module', 'old_module', 'new_module')
    assert MovedModule('test_module', 'old_module', 'new_module') != \
        MovedModule('test_module', 'old_module', 'new_module')
        # the first 'new_module' has been changed to something else


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:58:41.374324
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MA = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    assert MA.name == 'cStringIO'
    assert MA.new_mod == 'io'
    assert MA.new_attr == 'StringIO'

# Generated at 2022-06-12 03:58:46.065927
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    test = (2, 7)
    assert SixMovesTransformer.target == test
    test = {
        'indent': 'import six.moves.configparser',
        'cStringIO': 'from six.moves import cStringIO'}
    for key, value in test.items():
        assert SixMovesTransformer.rewrites[key] == value
    test = ['six']
    assert SixMovesTransformer.dependencies == test

# Generated at 2022-06-12 03:58:49.281567
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('a', 'b', 'c')
    assert m.name == 'a'
    assert m.new == 'c'

    m = MovedModule('a', 'b')
    assert m.name == 'a'
    assert m.new == 'a'

# Generated at 2022-06-12 03:58:52.199612
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"


# Generated at 2022-06-12 03:58:55.177180
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.new == "name"
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.new == "new"

# Generated at 2022-06-12 03:58:56.640868
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    with pytest.warns(DeprecationWarning):
        SixMovesTransformer()



# Generated at 2022-06-12 03:59:00.068924
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('name', 'old', 'new')
    assert isinstance(a, MovedModule)
    assert a.name == 'name'
    assert a.old == 'old'
    assert a.new == 'new'


# Generated at 2022-06-12 04:00:14.185447
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                new_import = (
                    '{0}.{1}.{2}'.format(move.new_mod, move.new_attr, move.name),
                    'six.moves{0}.{1}'.format(prefix, move.name))
                assert new_import in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                new_import = (move.new, 'six.moves{}.{}'.format(prefix, move.name))
                assert new_import in SixMovesTransformer.rewrites

# Generated at 2022-06-12 04:00:15.478740
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(SixMovesTransformer._get_rewrites()) >= 46

# Generated at 2022-06-12 04:00:24.195257
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    x = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert x.name == "cStringIO"
    assert x.new_mod == "io"
    assert x.new_attr == "StringIO"
    x = MovedAttribute("range", "__builtin__", "builtins", "xrange", "range")
    assert x.name == "range"
    assert x.new_mod == "builtins"
    assert x.new_attr == "range"
    x = MovedAttribute("range", "__builtin__", "builtins")
    assert x.name == "range"
    assert x.new_mod == "builtins"
    assert x.new_attr == "range"

# Generated at 2022-06-12 04:00:26.869787
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == len(list(SixMovesTransformer._get_rewrites()))

# Generated at 2022-06-12 04:00:29.009608
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer

if __name__ == '__main__':
    # Test for constructor of class SixMovesTransformer
    test_SixMovesTransformer()

# Generated at 2022-06-12 04:00:36.320725
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():

    # noinspection PyProtectedMember
    test = SixMovesTransformer.rewrites

    assert test is not None
    # 'six.moves.copyreg.copy_reg' -> 'six.moves.copy_reg'
    assert ('six.moves.copyreg.copy_reg', 'six.moves.copy_reg') in test
    # 'six.moves.urllib.parse.urlparse' -> 'six.moves.urllib_parse.urlparse'
    assert ('six.moves.urllib.parse.urlparse', 'six.moves.urllib_parse.urlparse') in test

# Generated at 2022-06-12 04:00:39.952914
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert obj.name == "cStringIO"
    assert obj.new_mod == "io"
    assert obj.new_attr == "StringIO"


# Generated at 2022-06-12 04:00:44.242106
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'
    assert MovedModule('name', 'old', 'new').name == 'name'
    assert MovedModule('name', 'old', 'new').old == 'old'
    assert MovedModule('name', 'old', 'new').new == 'new'



# Generated at 2022-06-12 04:00:50.020554
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert ('xmlrpc.client', 'six.moves.xmlrpc_client') in SixMovesTransformer.rewrites
    assert ('dbm.gnu', 'six.moves.dbm_gnu') in SixMovesTransformer.rewrites
    assert ('urllib.parse', 'six.moves.urllib_parse') in SixMovesTransformer.rewrites
    assert ('urllib.robotparser', 'six.moves.urllib_robotparser') in SixMovesTransformer.rewrites
    assert ('urllib.error', 'six.moves.urllib_error') in SixMovesTransformer.rewrites
    assert ('urllib.request', 'six.moves.urllib_request') in SixMovesTransformer.rewrites