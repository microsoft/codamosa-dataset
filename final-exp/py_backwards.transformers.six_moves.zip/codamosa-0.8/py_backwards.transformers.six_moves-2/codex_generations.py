

# Generated at 2022-06-12 03:50:46.437615
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"

# Generated at 2022-06-12 03:50:47.765522
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:50:56.516564
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").__dict__ == {
        'name': "cStringIO", 'new_mod': "cStringIO", 'new_attr': "StringIO"}
    assert MovedAttribute("cStringIO", "cStringIO", "io").__dict__ == {
        'name': "cStringIO", 'new_mod': "cStringIO", 'new_attr': "cStringIO"}
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "foo")\
        .__dict__ == {'name': "cStringIO", 'new_mod': "cStringIO", 'new_attr': "foo"}
    assert MovedAttribute("cStringIO", "cStringIO", "io", new_attr="foo")\
       

# Generated at 2022-06-12 03:51:00.700581
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('name','old','new')
    assert(moved_module.name == 'name')
    assert(moved_module.old == 'old')
    assert(moved_module.new == 'new')


# Generated at 2022-06-12 03:51:10.295184
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test that the constructor has created rewrites from the iter
    # that is used as the class variable rewrites
    six_moves_transformer = SixMovesTransformer()

# Generated at 2022-06-12 03:51:18.126446
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    assert repr(m) == "MovedModule(name='name', old='old', new='new')"
    m = MovedModule("name", "old")
    assert m.new == "name"
    assert repr(m) == "MovedModule(name='name', old='old', new='name')"



# Generated at 2022-06-12 03:51:22.955789
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move_attribute.name == "cStringIO"
    assert move_attribute.new_mod == "io"
    assert move_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:51:27.991948
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("x", "old", "new")
    assert m.name == "x"
    assert m.new == "new"

    m = MovedModule("x", "old")
    assert m.name == "x"
    assert m.new == "x"



# Generated at 2022-06-12 03:51:31.466786
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", True)
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"


# Generated at 2022-06-12 03:51:36.114596
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    class_MovedAttribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert class_MovedAttribute.name == 'cStringIO'
    assert class_MovedAttribute.new_mod == 'io'
    assert class_MovedAttribute.new_attr == 'StringIO'



# Generated at 2022-06-12 03:51:47.243436
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Unit test of constructor of MovedModule"""
    my_moved_modules = MovedModule('module1', 'module2', 'module3')
    assert my_moved_modules.name == 'module1'
    assert my_moved_modules.old == 'module2'
    assert my_moved_modules.new == 'module3'
    assert my_moved_modules.new == 'module3'
    my_moved_modules = MovedModule('module1', 'module2')
    assert my_moved_modules.name == 'module1'
    assert my_moved_modules.old == 'module2'
    assert my_moved_modules.new == 'module1'


# Generated at 2022-06-12 03:51:51.458076
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"


# Generated at 2022-06-12 03:51:54.978266
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    MOVE = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MOVE.name == "cStringIO"
    assert MOVE.new_mod == "io"
    assert MOVE.new_attr == "StringIO"

# Generated at 2022-06-12 03:52:01.977458
# Unit test for constructor of class MovedModule
def test_MovedModule():
    foo_bar = MovedModule(name='foo.bar', old='foo.bar', new='foo.bar')
    foo_bar_baz = MovedModule(name='foo.bar.baz', old='foo.bar.baz')
    assert foo_bar.name == 'foo.bar'
    assert foo_bar.old == 'foo.bar'
    assert foo_bar.new == 'foo.bar'
    assert foo_bar_baz.name == 'foo.bar.baz'
    assert foo_bar_baz.old == 'foo.bar.baz'
    assert foo_bar_baz.new == 'foo.bar.baz'

# Generated at 2022-06-12 03:52:12.816529
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys
    from types import ModuleType
    from .base import RewriteImporter
    from .lib2to3 import fix_import
    import six
    import six.moves as sm

    sys.modules['six_moves'] = ModuleType('six.moves')
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert path == fix_import(path, sys.modules['six_moves'], 'six.moves{}.{}'.format(prefix, move.name))
                path = '{}.{}'.format(move.old_mod, move.name)

# Generated at 2022-06-12 03:52:26.374648
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__').name == 'builtins'
    assert MovedModule('configparser', 'ConfigParser').name == 'configparser'
    assert MovedModule('copyreg', 'copy_reg').name == 'copyreg'
    assert MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu').name == 'dbm_gnu'
    assert MovedModule(
        '_dummy_thread', 'dummy_thread', '_dummy_thread').name == '_dummy_thread'
    assert MovedModule('http_cookiejar', 'cookielib',
                       'http.cookiejar').name == 'http_cookiejar'
    assert MovedModule('http_cookies', 'Cookie', 'http.cookies').name == 'http_cookies'
    assert Moved

# Generated at 2022-06-12 03:52:36.628233
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert moved.name == 'name'
    assert moved.new_mod == 'new_mod'
    assert moved.new_attr == 'new_attr'
    moved = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert moved.name == 'name'
    assert moved.new_mod == 'new_mod'
    assert moved.new_attr == 'old_attr'
    moved = MovedAttribute('name', 'old_mod', 'new_mod')
    assert moved.name == 'name'
    assert moved.new_mod == 'new_mod'
    assert moved.new_attr == 'name'

# Generated at 2022-06-12 03:52:38.922253
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert isinstance(MovedModule('foo', 'bar'), MovedModule)


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:52:48.912181
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert "six.moves.filter" in t.rewrites
    assert "six.moves.urllib.parse.urlencode" in t.rewrites
    assert "six.moves.urllib.error.URLError" in t.rewrites
    assert "six.moves.urllib.request.urlopen" in t.rewrites
    assert "six.moves.urllib.response.addbase" in t.rewrites
    assert "six.moves.urllib.robotparser.RobotFileParser" in t.rewrites


if __name__ == '__main__':
    from logging import basicConfig, DEBUG, INFO
    from sys import argv
    from tokenize import tokenize
    from token import STRING
    from io import Bytes

# Generated at 2022-06-12 03:52:54.990750
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.ast_transformer == 'SixMovesTransformer'
    assert transformer.tree_transformer == 'SixMovesTransformer'
    assert transformer.converter == 'SixMovesTransformer'
    assert transformer.pre_transform == 'SixMovesTransformer'
    assert transformer.translate_tree == 'SixMovesTransformer'
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:53:01.029396
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .testing import run_tests
    from .tests.six_moves import tests
    run_tests(SixMovesTransformer, tests)

# Generated at 2022-06-12 03:53:04.843896
# Unit test for constructor of class MovedModule
def test_MovedModule():
    d = MovedModule('name', 'old', 'new')
    assert d.name == 'name'
    assert d.old == 'old'
    assert d.new == 'new'

# Generated at 2022-06-12 03:53:10.550541
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                assert(SixMovesTransformer.rewrites[path] == 'six.moves{}.{}'.format(prefix, move.name))
            elif isinstance(move, MovedModule):
                assert(SixMovesTransformer.rewrites[move.new] == 'six.moves{}.{}'.format(prefix, move.name))

# Generated at 2022-06-12 03:53:12.320280
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("__builtin__")
    assert moved_attr

# Generated at 2022-06-12 03:53:17.039279
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("test", "test")
    assert(mm.name == "test")
    assert(mm.new == "test")
    mm = MovedModule("test", "test", "test2")
    assert(mm.name == "test")
    assert(mm.new == "test2")


# Generated at 2022-06-12 03:53:18.640634
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) == 114
    assert _get_rewrites() == _get_rewrites()

# Generated at 2022-06-12 03:53:30.777376
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"

    moved = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "cStringIO"

    moved = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"


# Generated at 2022-06-12 03:53:35.787264
# Unit test for constructor of class MovedModule
def test_MovedModule():
    a = MovedModule('builtins', '__builtin__')
    assert a.name == 'builtins'
    assert a.new == 'builtins'
    b = MovedModule('urllib.request', 'urllib2')
    assert b.name == 'urllib.request'
    assert b.new == 'urllib.request'


# Generated at 2022-06-12 03:53:40.255289
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module = open(os.path.join(importlib_folder, 'six.py'), 'r').read()
    parser = ast.parse(module)
    transform = SixMovesTransformer(parser)
    assert transform.rewrites == _get_rewrites()

# Generated at 2022-06-12 03:53:47.719610
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == move.new_attr
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "new_name")
    assert move.name == move.new_attr
    assert move.new_attr == "new_name"
    move = MovedAttribute("cStringIO", "cStringIO", "io", old_attr="StringIO")
    assert move.name == move.new_attr

# Generated at 2022-06-12 03:54:04.663143
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute1 = MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')
    attribute2 = MovedAttribute('urllib_parse', __name__+'.moves.urllib_parse', 'urllib.parse')
    attribute3 = MovedAttribute('urllib_error', __name__+'.moves.urllib_error', 'urllib.error')
    assert attribute1.name == 'cStringIO'
    assert attribute1.new_mod == 'io'
    assert attribute1.new_attr == 'StringIO'
    assert attribute2.name == 'urllib_parse'
    assert attribute2.new_mod == 'urllib.parse'
    assert attribute3.name == 'urllib_error'

# Generated at 2022-06-12 03:54:07.379217
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Just test that this does not throw an exception
    MovedAttribute('a', 'b', 'c', 'd', 'e')

# Generated at 2022-06-12 03:54:16.466351
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from ..utils.pyg3tmain import add_options
    from ..utils.pyg3tmain import process_opts
    from ..utils.pyg3tmain import get_default_encoding
    from ..utils.pyg3tmain import main
    from test.utils.pyg3tmain import gt_script_path
    from test.utils.pyg3tmain import make_test_context
    # test settings import
    settings = make_test_context('utf-8')
    settings.encoding = get_default_encoding()
    settings.verbosity = 3
    settings.basenamechoices = []
    settings.checks = []
    settings.filechoices = []
    settings.formats = []
    settings.output = '-'
    settings.pofilter = None
    settings.includef

# Generated at 2022-06-12 03:54:23.241373
# Unit test for constructor of class MovedModule
def test_MovedModule():
    def compare(cls, name, old, new):
        assert cls.name == name
        assert cls.new == new
    compare(MovedModule("six", "__six__"), "six", "__six__", "six")
    compare(MovedModule("six"), "six", "six")
    compare(MovedModule("six", "six", "__six__"), "six", "six", "__six__")


# Generated at 2022-06-12 03:54:30.176636
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """MovedModule test"""

    moved = MovedModule("test", "test")
    assert moved.name == 'test'
    assert moved.new == 'test'

    moved = MovedModule("test", "test", "newtest")
    assert moved.name == 'test'
    assert moved.new == 'newtest'


# Unit test to check that the constructor of class MovedAttribute
# raises a TypeError when passed an incorrect number of parameters

# Generated at 2022-06-12 03:54:35.702528
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    for move in _moved_attributes:
        if isinstance(move, MovedAttribute):
            assert move.name == 'filter'
            assert move.old_mod == 'itertools'
            assert move.new_mod == 'builtins'
            assert move.old_attr == 'ifilter'
            assert move.new_attr == 'filter'

# Generated at 2022-06-12 03:54:40.041427
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert move.name == 'name'
    assert move.new_mod == 'new_mod'
    assert move.new_attr == 'new_attr'

# Generated at 2022-06-12 03:54:49.955283
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    def evaluate(code):
        t = SixMovesTransformer(code, None)
        t.visit(ast.parse(code))
        return t.result

    assert evaluate('import ConfigParser') == 'import six.moves.configparser\n'
    assert evaluate('from ConfigParser import RawConfigParser') == 'from six.moves.configparser import RawConfigParser\n'
    assert evaluate('from ConfigParser import RawConfigParser as RP') == 'from six.moves.configparser import RawConfigParser as RP\n'
    assert evaluate('from ConfigParser import *') == 'from six.moves.configparser import *\n'

# Generated at 2022-06-12 03:54:54.776835
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test the constructor of class MovedModule."""
    a = MovedModule("module_name", "old_module")
    assert a.name == "module_name"
    assert a.new == "module_name"
    b = MovedModule("module_name", "old_module", "new_module")
    assert b.name == "module_name"
    assert b.new == "new_module"



# Generated at 2022-06-12 03:54:59.063980
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("hello", "goodbye")
    assert module.name == "hello"
    assert module.old == "goodbye"
    assert module.new == "hello"

    module = MovedModule("hello", "goodbye", "farewell")
    assert module.name == "hello"
    assert module.old == "goodbye"
    assert module.new == "farewell"

# Generated at 2022-06-12 03:55:13.998694
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma1 = MovedAttribute("foo", "os", "shutil")
    assert ma1.name == 'foo'
    assert ma1.new_mod == 'shutil'
    assert ma1.new_attr == 'foo'

    ma2 = MovedAttribute("foo", "os", "shutil", "bar")
    assert ma2.name == 'foo'
    assert ma2.new_mod == 'shutil'
    assert ma2.new_attr == 'bar'

    ma3 = MovedAttribute("foo", "os", "shutil", "bar", "baz")
    assert ma3.name == 'foo'
    assert ma3.new_mod == 'shutil'
    assert ma3.new_attr == 'baz'


# Generated at 2022-06-12 03:55:25.514252
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    stmt = "import six;six=six.moves"
    assert SixMovesTransformer(stmt, 2, 7)
    stmt = "import six;six=six.moves.urllib.parse"
    assert SixMovesTransformer(stmt)
    stmt = "import six;six=six.moves.urllib.error"
    assert SixMovesTransformer(stmt)
    stmt = "import six;six=six.moves.urllib.request"
    assert SixMovesTransformer(stmt)
    stmt = "import six;six=six.moves.urllib.response"
    assert SixMovesTransformer(stmt)
    stmt = "import six;six=six.moves.urllib.robotparser"
    assert SixMovesTransformer

# Generated at 2022-06-12 03:55:27.078190
# Unit test for constructor of class MovedModule
def test_MovedModule():
    obj = MovedModule("abc", "abc")
    assert obj.name == "abc"
    assert obj.new == "abc"

# Generated at 2022-06-12 03:55:37.596731
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:55:45.894292
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']

    # Test _get_rewrites().  Note that this is not a true unit test. It tests the
    # constructor of SixMovesTransformer, but not the actual behavior of the
    # class. However, it is still necessary to make sure that the
    # SixMovesTransformer constructor works as expected.
    rewrites = set(transformer.rewrites)
    for mod in ('urllib.parse', 'urllib.error', 'urllib.request',
                'urllib.response', 'urllib.robotparser'):
        assert ('{}'.format(mod), 'six.moves.{}'.format(mod)) in rewrites

# Generated at 2022-06-12 03:55:48.537644
# Unit test for constructor of class MovedModule
def test_MovedModule():
    actual = MovedModule('foo', 'bar', 'baz')
    expected = MovedModule('foo', 'bar', 'baz')
    assert actual == expected


# Generated at 2022-06-12 03:55:58.367529
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('k', 'a', 'b') == MovedAttribute('k', 'a', 'b')
    assert MovedAttribute('k', 'a', None) == MovedAttribute('k', 'a', 'k')
    assert MovedAttribute('k', 'a', 'b', 'h', 'i') == MovedAttribute('k', 'a', 'b', 'h', 'i')
    assert MovedAttribute('k', 'a', 'b', 'h') == MovedAttribute('k', 'a', 'b', 'h', 'h')
    assert MovedAttribute('k', 'a', 'b', new_attr='i') == MovedAttribute('k', 'a', 'b', 'k', 'i')


# Generated at 2022-06-12 03:56:05.834360
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    s = 'from six.moves.configparser import ConfigParser\n'
    s += 'from six.moves.urllib.request import urlopen\n'
    s += 'from six.moves.urllib.parse import parse_qs\n'
    s += 'from six.moves.urllib.error import URLError\n'
    assert SixMovesTransformer()(s) == \
        'from ConfigParser import ConfigParser\n' \
        'from urllib2 import urlopen\n' \
        'from urlparse import parse_qs\n' \
        'from urllib2 import URLError\n'

# Generated at 2022-06-12 03:56:06.677999
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer("x", "y")
    assert st is not None

# Generated at 2022-06-12 03:56:12.849623
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.config == {"shebang": "#!/usr/bin/env python", "line_length": 72}

# Generated at 2022-06-12 03:56:24.852052
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer()

# Generated at 2022-06-12 03:56:29.261552
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test the constructor of MovedModule."""
    module = MovedModule("module", "new_module")
    assert module.name == "module"
    assert module.new == "new_module"

    module = MovedModule("module", "new_module", "old")
    assert module.name == "module"
    assert module.new == "new_module"

# Generated at 2022-06-12 03:56:32.450026
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'
    mm = MovedModule('name', 'old')
    assert mm.new == 'name'


# Generated at 2022-06-12 03:56:44.181385
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'
    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'cStringIO'
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO", "cStringIO")
    assert move.name == 'cStringIO'
    assert move.new_mod == 'io'
    assert move.new_attr == 'StringIO'

# Generated at 2022-06-12 03:56:46.656028
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'


# Generated at 2022-06-12 03:56:54.635009
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # MovedAttribute(name, old_mod, new_mod, old_attr=None, new_attr=None)
    assert str(MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO')) == \
           "MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr='StringIO', new_attr='cStringIO')"
    assert str(MovedAttribute('cStringIO', 'cStringIO', 'io')) == \
           "MovedAttribute(name='cStringIO', old_mod='cStringIO', new_mod='io', old_attr=None, new_attr='cStringIO')"

# Generated at 2022-06-12 03:56:59.640499
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("getcwd", "os", "os")
    assert a.name == 'getcwd'
    assert a.new_mod == 'os'
    assert a.new_attr == 'getcwd'
    b = MovedAttribute("range", "__builtin__", "builtins")
    assert b.name == 'range'
    assert b.new_mod == 'builtins'
    assert b.new_attr == 'range'

# Generated at 2022-06-12 03:57:05.460258
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer.__new__(SixMovesTransformer)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)


SixMovesTransformer.test_SixMovesTransformer = test_SixMovesTransformer


if __name__ == "__main__":
    import six
    x = SixMovesTransformer()
    print(x.get_transforms())
    print(x.get_imports())

# Generated at 2022-06-12 03:57:11.653968
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == "StringIO"
    assert MovedAttribute("cStringIO","cStringIO", "io").new_attr == "cStringIO"
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map").new_attr == "map"
    assert MovedAttribute("getoutput", "commands", "subprocess").new_attr == "getoutput"
    assert MovedAttribute("reload_module", "__builtin__", "importlib", "reload").new_attr == "reload"
    assert MovedAttribute("html_parser", "HTMLParser", "html.parser").new_attr == "html.parser"

# Generated at 2022-06-12 03:57:17.990193
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.name == "cStringIO"
    assert moved.new_mod == "io"
    assert moved.new_attr == "StringIO"

    moved = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert moved.name == "filter"
    assert moved.new_mod == "builtins"
    assert moved.new_attr == "filter"


# Generated at 2022-06-12 03:57:47.284998
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from lib2to3 import fixer_util

    rewrites = set()
    for rewrite in _get_rewrites():
        rewrites.add(
            fixer_util.String(
                repr(rewrite[1]).lstrip("u"), prefix=u"u"
            )
        )

    from libmodernize.fixes.fix_six_moves import SixMovesTransformer

    smt = SixMovesTransformer(None)
    assert rewrites == set(smt.rewrites)

# Generated at 2022-06-12 03:57:58.030458
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import sys, io
    stdout, sys.stdout = sys.stdout, io.StringIO()
    SixMovesTransformer()
    result = sys.stdout.getvalue().strip()
    sys.stdout = stdout
    assert result == ""



if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(level=logging.DEBUG)
    from lib2to3.main import main

# Generated at 2022-06-12 03:58:00.098192
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves_module = MovedModule("tkinter", "Tkinter")
    assert moves_module.name == "tkinter"
    assert moves_module.new == "tkinter"

# Generated at 2022-06-12 03:58:01.652289
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old", "new")
    assert module.name == "name"
    assert module.new == "new"

# Generated at 2022-06-12 03:58:05.659772
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # pylint: disable=expression-not-assigned,pointless-statement
    _moved_attributes
    _urllib_parse_moved_attributes
    _urllib_error_moved_attributes
    _urllib_request_moved_attributes
    _urllib_response_moved_attributes
    _urllib_robotparser_moved_attributes
    assert len(SixMovesTransformer.rewrites) == 35 + 6 + 3 + 16 + 3 + 1

# Generated at 2022-06-12 03:58:12.923322
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer('six.moves', 'six', None)
    assert transformer.rewrites == SixMovesTransformer.rewrites
    assert transformer.find_module.__name__ == 'find_module'
    assert transformer.find_module.__module__ == 'six.moves'
    assert transformer.load_module.__name__ == 'load_module'
    assert transformer.load_module.__module__ == 'six.moves'
    assert transformer.dependencies == SixMovesTransformer.dependencies
    assert transformer.target == SixMovesTransformer.target

# Generated at 2022-06-12 03:58:18.350487
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    m = SixMovesTransformer()
    if hasattr(m, 'rewrites'):
        assert m.rewrites is not None
        assert len(m.rewrites) == 66
    else:
        assert isinstance(m.rewrites, types.GeneratorType)
        assert next(m.rewrites) is not None
        assert len(list(m.rewrites)) == 65
    assert m.dependencies == ['six']

# Generated at 2022-06-12 03:58:20.874972
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    tr = SixMovesTransformer
    assert len(tr.rewrites) == 72  # noqa: WPS331
    assert 'six.moves.winreg' in tr.rewrites

# Generated at 2022-06-12 03:58:26.862089
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    movedattribute = MovedAttribute("name", "old", "new")
    assert movedattribute.name == 'name'
    assert movedattribute.new_mod == 'new'
    assert movedattribute.new_attr == 'name'
    movedattribute = MovedAttribute("name", "old", "new", "oldattr", "newattr")
    assert movedattribute.name == 'name'
    assert movedattribute.new_mod == 'new'
    assert movedattribute.new_attr == 'newattr'

# Generated at 2022-06-12 03:58:29.444793
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    rewrites = [('six._six.MovedAttribute', 'six._six.MovedAttribute')]
    test = BaseImportRewrite(rewrites)
    assert test.rewrites == rewrites

# Generated at 2022-06-12 03:59:28.198198
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Test missing new module name
    with pytest.raises(TypeError):
        MovedModule('builtins')
    # Test all parameters given
    module = MovedModule('builtins', '__builtin__')
    assert module.name == 'builtins'
    assert module.old == '__builtin__'
    assert module.new == 'builtins'


# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:59:37.253261
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six

    moves = set(SixMovesTransformer.rewrites)
    for move in _moved_attributes:
        if isinstance(move, MovedAttribute):
            path = '{}.{}'.format(move.new_mod, move.new_attr)
            original_path = '{}.{}'.format(move.old_mod, move.old_attr or move.name)
            assert (original_path, 'six.moves.{}'.format(move.name)) in moves
            assert (path, 'six.moves.{}'.format(move.name)) in moves
        elif isinstance(move, MovedModule):
            assert move.new in moves
            assert 'six.moves.{}'.format(move.name) in moves


# Generated at 2022-06-12 03:59:40.640242
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Constructor of SixMovesTransformer"""
    transformer = SixMovesTransformer()
    assert transformer.rewrites[0][0] == "builtins.cStringIO"
    assert transformer.rewrites[0][1] == "six.moves.cStringIO"

# Generated at 2022-06-12 03:59:45.346916
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new_MovedModule = MovedModule("name", "old")
    assert new_MovedModule.name == "name"
    assert new_MovedModule.old == "old"
    assert new_MovedModule.new == "name"
    new_MovedModule = MovedModule("name", "old", "new")
    assert new_MovedModule.new == "new"


# Generated at 2022-06-12 03:59:54.122103
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("dummy", "dummy", "dummy").name == 'dummy'
    assert MovedAttribute("dummy", "dummy", "dummy").new_mod == 'dummy'
    assert MovedAttribute("dummy", "dummy", "dummy").new_attr == 'dummy'
    assert MovedAttribute("dummy", "dummy", "dummy", "dummy", "dummy").new_attr == 'dummy'
    assert MovedAttribute("dummy", "dummy", None, "dummy", "dummy").new_mod == 'dummy'
    assert MovedAttribute("dummy", "dummy", "dummy", "new_dummy", None).new_attr == 'new_dummy'

# Generated at 2022-06-12 03:59:59.994081
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # Test default value
    assert MovedAttribute("cStringIO", "cStringIO", "io").new_attr == "cStringIO"
    # Test old_attr which is different from name
    assert MovedAttribute("cStringIO", "cStringIO",
                          "io", "StringIO").new_attr == "StringIO"
    # Test new_attr is provided
    assert MovedAttribute("cStringIO", "cStringIO",
                          "io", "StringIO", "newStringIO").new_attr == "newStringIO"



# Generated at 2022-06-12 04:00:03.449827
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer(None)
    if st.rewrites == None:
        raise AssertionError("rewrites is None")
    if st.dependencies == None:
        raise AssertionError("dependencies is None")
    if st.dependencies != ['six']:
        raise AssertionError("dependencies is not ['six']: {}".format(st.dependencies))

# Generated at 2022-06-12 04:00:05.515107
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('winreg', '_winreg', 'winreg')
    assert mm.name == 'winreg'
    assert mm.new == 'winreg'



# Generated at 2022-06-12 04:00:08.530058
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("original_thing", "old_module")
    assert mm.name == "original_thing"
    assert mm.new == "original_thing"
    assert mm.old == "old_module"

# Generated at 2022-06-12 04:00:09.553049
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    _ = SixMovesTransformer()