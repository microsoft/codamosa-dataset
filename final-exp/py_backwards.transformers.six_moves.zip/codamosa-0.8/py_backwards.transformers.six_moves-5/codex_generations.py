

# Generated at 2022-06-12 03:50:44.535672
# Unit test for constructor of class MovedModule
def test_MovedModule():
    for move in _moved_attributes:
        if isinstance(move, MovedModule):
            assert move.name
            assert move.new

# Generated at 2022-06-12 03:50:46.537021
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mod = MovedModule('foo', 'foo')
    assert mod.name == 'foo'
    assert mod.new == 'foo'
    mod = MovedModule('foo', 'foo', 'bar')
    assert mod.name == 'foo'
    assert mod.new == 'bar'

# Generated at 2022-06-12 03:50:54.705104
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:50:57.670161
# Unit test for constructor of class MovedModule
def test_MovedModule():
    name = "foo"
    old = "bar"
    move = MovedModule(name, old)
    assert move.name == name
    assert move.old == old
    assert move.new == name

# Generated at 2022-06-12 03:51:08.890272
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:51:10.622903
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('_dummy_thread','dummy_thread','_dummy_thread')

# Generated at 2022-06-12 03:51:18.921575
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('foo', 'bar').name == 'foo'
    assert MovedModule('foo', 'bar').new == 'foo'
    assert MovedModule('foo', 'bar').old == 'bar'
    assert MovedModule('foo', 'bar', 'qux').name == 'foo'
    assert MovedModule('foo', 'bar', 'qux').new == 'qux'
    assert MovedModule('foo', 'bar', 'qux').old == 'bar'

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:51:23.297699
# Unit test for constructor of class MovedModule
def test_MovedModule():
    test_obj = MovedModule('test_name', 'test_old', 'test_new')
    assert test_obj.name == 'test_name'
    assert test_obj.old == 'test_old'
    assert test_obj.new == 'test_new'



# Generated at 2022-06-12 03:51:34.804468
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # default values
    m = MovedAttribute('cStringIO', 'cStringIO', '__builtin__', 'StringIO')
    assert m.name == 'cStringIO'
    assert m.new_mod == 'cStringIO'
    assert m.new_attr == 'StringIO'
    # specify new_attr
    m = MovedAttribute('cStringIO', 'cStringIO', '__builtin__', 'StringIO', 'StringIO')
    assert m.name == 'cStringIO'
    assert m.new_mod == 'cStringIO'
    assert m.new_attr == 'StringIO'
    # no old_attr
    m = MovedAttribute('cStringIO', 'cStringIO', '__builtin__', None, 'StringIO')
    assert m.name == 'cStringIO'
    assert m

# Generated at 2022-06-12 03:51:38.264415
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma.name == "name"
    assert ma.new_mod == "new_mod"
    assert ma.new_attr == "new_attr"

# Generated at 2022-06-12 03:51:44.403831
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

# Generated at 2022-06-12 03:51:47.414456
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:51:53.079830
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.new == 'new'

    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.new == 'name'

    with pytest.raises(TypeError):
        mm = MovedModule('name', new='new')



# Generated at 2022-06-12 03:51:56.169683
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old').old == 'old'
    assert MovedModule('name', 'old').new == 'name'


# Generated at 2022-06-12 03:52:04.376757
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedAttribute):
                path = '{}.{}'.format(move.new_mod, move.new_attr)
                path = path.replace('.', '[dot]')
                assert path.replace('[dot]', '.') in SixMovesTransformer.rewrites
                assert ('six.moves{}.{}'.format(prefix, move.name)).replace('.', '[dot]') in SixMovesTransformer.rewrites
            elif isinstance(move, MovedModule):
                path = move.new
                path = path.replace('.', '[dot]')
                assert path.replace('[dot]', '.') in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:52:08.728653
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    """Test constructor of SixMovesTransformer"""
    target = (2, 7)
    dependencies = ['six']
    rewrites = _get_rewrites()
    SixMovesTransformer(target, rewrites, dependencies)

# Generated at 2022-06-12 03:52:15.372610
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites['urllib.parse.urlparse'] == 'six.moves.urllib_parse.urlparse'
    assert SixMovesTransformer.rewrites['urllib.robotparser.RobotFileParser'] == 'six.moves.urllib_robotparser.RobotFileParser'
    assert SixMovesTransformer.rewrites['queue.Queue'] == 'six.moves.queue.Queue'

# Generated at 2022-06-12 03:52:21.931110
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.dependencies == ['six']
    assert len(transformer.rewrites) == 49
    assert transformer.rewrites[0] == ('io.StringIO', 'six.moves.cStringIO')
    assert transformer.rewrites[48] == ('urllib.robotparser.RobotFileParser', 'six.moves.urllib_robotparser.RobotFileParser')

# Generated at 2022-06-12 03:52:34.773097
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    cStringIO = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert cStringIO.name == "cStringIO"
    assert cStringIO.new_mod == "io"
    assert cStringIO.new_attr == "StringIO"

    cStringIO = MovedAttribute("cStringIO", "cStringIO", "io")
    assert cStringIO.name == "cStringIO"
    assert cStringIO.new_mod == "io"
    assert cStringIO.new_attr == "cStringIO"

    cStringIO = MovedAttribute("cStringIO", "cStringIO", "io", "cStringIO")
    assert cStringIO.name == "cStringIO"
    assert cStringIO.new_mod == "io"
    assert cStringIO.new_attr

# Generated at 2022-06-12 03:52:44.596695
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    t = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert t.name == "cStringIO"
    assert t.new_mod == "io"
    assert t.new_attr == "StringIO"

    t = MovedAttribute("cStringIO", "cStringIO", "io")
    assert t.name == "cStringIO"
    assert t.new_mod == "io"
    assert t.new_attr == "cStringIO"

    t = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="newStringIO")
    assert t.name == "cStringIO"
    assert t.new_mod == "io"
    assert t.new_attr == "newStringIO"


# Generated at 2022-06-12 03:52:56.941511
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer(None, None)
    assert t.target == (2, 7)

# Generated at 2022-06-12 03:53:05.385391
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "name"
    moved_module = MovedModule("name", "old", "new")
    assert moved_module.name == "name"
    assert moved_module.old == "old"
    assert moved_module.new == "new"


# Generated at 2022-06-12 03:53:15.126443
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").name == "builtins"
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("configparser", "ConfigParser", "configparser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "configparser").new == "configparser"
    assert MovedModule("configparser", "ConfigParser").name == "configparser"
    assert MovedModule("configparser", "ConfigParser").new == "ConfigParser"
    assert MovedModule("configparser", "ConfigParser", "").name == "configparser"
    assert MovedModule("configparser", "ConfigParser", "").new == "ConfigParser"


# Generated at 2022-06-12 03:53:21.982378
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert (MovedModule('builtins', '__builtin__').name
            == 'builtins')
    assert (MovedModule('builtins', '__builtin__').old
            == '__builtin__')
    assert (MovedModule('builtins', '__builtin__').new
            == 'builtins')
    assert (MovedModule('builtins', '__builtin__', 'foo').name
            == 'builtins')
    assert (MovedModule('builtins', '__builtin__', 'foo').old
            == '__builtin__')
    assert (MovedModule('builtins', '__builtin__', 'foo').new
            == 'foo')

# Generated at 2022-06-12 03:53:26.448750
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert attr.name == 'cStringIO'
    assert attr.new_mod == 'io'
    assert attr.new_attr == 'StringIO'

# Generated at 2022-06-12 03:53:29.648433
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    module = type("fake", (object,), {'__name__': "test"})
    transformer = SixMovesTransformer(module)
    assert transformer.module is module

# Generated at 2022-06-12 03:53:34.166227
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute(name='a', old_mod='b', new_mod='c', old_attr='d', new_attr='e')
    assert a.name == 'a'
    assert a.old_attr == 'd'
    assert a.new_mod == 'c'
    assert a.new_attr == 'e'

# Generated at 2022-06-12 03:53:35.278038
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:53:41.852023
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("builtins", "__builtin__")
    assert module.name == "builtins"
    assert module.new == "builtins"
    assert module.old is None
    module = MovedModule("configparser", "ConfigParser")
    assert module.name == "configparser"
    assert module.old == "ConfigParser"
    assert module.new == "configparser"


# Generated at 2022-06-12 03:53:53.802733
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    tup = (1, 2, 3)
    matr = MovedAttribute(*tup)
    assert matr.name == 1
    assert matr.old_mod == 2
    assert matr.new_mod == 3
    assert matr.old_attr is None
    assert matr.new_attr is None

    tup = (1, 2, 3, 4, 5)
    matr = MovedAttribute(*tup)
    assert matr.name == 1
    assert matr.old_mod == 2
    assert matr.new_mod == 3
    assert matr.old_attr == 4
    assert matr.new_attr == 5

    tup = (1, 2, 3, 4)
    matr = MovedAttribute(*tup)
    assert matr.name == 1
    assert matr.old

# Generated at 2022-06-12 03:54:07.434750
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("builtins", "__builtin__")
    assert mm.name == "builtins"
    assert mm.new == "builtins"
    mm = MovedModule("configparser", "ConfigParser")
    assert mm.name == "configparser"
    assert mm.new == "configparser"
    mm = MovedModule("queue", "Queue")
    assert mm.name == "queue"
    assert mm.new == "queue"

# Generated at 2022-06-12 03:54:16.496560
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute("testmod", "testmod1")
    assert ma.name == "testmod"
    assert ma.new_mod == "testmod"
    assert ma.new_attr == "testmod"
    ma = MovedAttribute("testmod", "testmod1", "testmod2", old_attr="testattr")
    assert ma.name == "testmod"
    assert ma.new_mod == "testmod2"
    assert ma.new_attr == "testattr"
    ma = MovedAttribute("testmod", "testmod1", "testmod2", new_attr="testattr2")
    assert ma.name == "testmod"
    assert ma.new_mod == "testmod2"
    assert ma.new_attr == "testattr2"

# Generated at 2022-06-12 03:54:17.694082
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    from six.moves import cStringIO as io
    from io import StringIO as io
    assert io.__file__

# Generated at 2022-06-12 03:54:28.950422
# Unit test for constructor of class MovedModule
def test_MovedModule():
    from .utils import import_all_submodules
    import_all_submodules(__name__)
    assert MovedModule('winreg', '_winreg') == MovedModule('winreg', '_winreg')
    assert MovedModule('winreg', '_winreg', 'winreg') == MovedModule('winreg', '_winreg', 'winreg')
    assert MovedModule('winreg', '_winreg') != MovedModule('other', '_winreg')
    assert MovedModule('winreg', '_winreg') != MovedModule('winreg', 'other')
    assert MovedModule('winreg', '_winreg') != MovedModule('winreg', '_winreg', 'other')

# Generated at 2022-06-12 03:54:31.754363
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer().rewrites == dict(_get_rewrites())

# Generated at 2022-06-12 03:54:36.099003
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for prefix, moves in prefixed_moves:
        for move in moves:
            if isinstance(move, MovedModule):
                path = '{}.{}'.format(move.new, move.name)
                assert path in SixMovesTransformer.rewrites

# Generated at 2022-06-12 03:54:46.176862
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule("builtins", "__builtin__")
    assert move.name == "builtins"
    assert move.new == "builtins"
    move = MovedModule("dbm_gnu", "gdbm", "dbm.gnu")
    assert move.new == "dbm.gnu"
    move = MovedModule("tkinter", "Tkinter")
    assert move.new == "tkinter"
    assert move.name == "tkinter"
    move = MovedModule("winreg", "_winreg")
    assert move.new == "winreg"
    assert move.name == "winreg"


# Generated at 2022-06-12 03:54:49.913849
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = _get_rewrites()
    smt = SixMovesTransformer.__new__(SixMovesTransformer)
    smt.rewrites = rewrites
    assert smt.rewrites == rewrites

# Generated at 2022-06-12 03:54:55.906659
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .. import base
    from .. import utils
    from .sixmoves import SixMovesTransformer

    if base.TYPE_CHECKING:
        from typing import List, Tuple  # NOQA

    assert SixMovesTransformer.rewrites == _get_rewrites()
    assert isinstance(SixMovesTransformer.rewrites, utils.lazy_object)
    assert isinstance(SixMovesTransformer.rewrites, List[Tuple[str, str]])

# Remove the test above from the docs:
test_SixMovesTransformer.__doc__ = ''

# Generated at 2022-06-12 03:54:58.847997
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("name", "old", "new") == MovedModule("name", "old", "new")
    assert MovedModule("name", "old", "new") != MovedModule("name", "old", "old")

# Generated at 2022-06-12 03:55:22.470205
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('builtins', '__builtin__') == \
           MovedModule('builtins', '__builtin__')
    assert MovedModule('builtins', '__builtin__') != \
           MovedModule('builtins', '__builtin__', 'six.moves.builtins')
    assert MovedModule('builtins', '__builtin__') != \
           MovedModule('builtins', '__builtin__', new='six.moves.builtins')
    assert MovedModule('builtins', '__builtin__') != \
           MovedModule('builtins', '__builtin__', new='six.moves.builtins')
    assert MovedModule('builtins', '__builtin__') != \
           MovedModule('builtins', '__builtin__', new='builtins')


# Generated at 2022-06-12 03:55:27.041372
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("Test1", "Test1", "Test1")
    assert m.name == "Test1"
    assert m.new == "Test1"
    m = MovedModule("Test2", "Test2")
    assert m.name == "Test2"
    assert m.new == "Test2"

# Generated at 2022-06-12 03:55:37.553914
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    rewrites = sorted(_get_rewrites())

# Generated at 2022-06-12 03:55:45.081755
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    image = """
        def fn(x, y):
            import os.path
            import a.b
            return os.path.join(x, y)
    """
    tree = astroid.parse(image)
    transformer = SixMovesTransformer()
    transformer.visit(tree)
    fixed_image = """
        from six.moves import os
        from six.moves.urllib.parse import quote as url_quote

        def fn(x, y):
            return os.path.join(x, y)
    """
    expected_tree = astroid.parse(fixed_image)
    assert are_astroid_trees_equivalent(tree, expected_tree)

# Generated at 2022-06-12 03:55:52.037577
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    m = SixMovesTransformer()
    assert m.rewrites.pop("urllib.parse.quote") == "six.moves.urllib_parse.quote"
    assert m.rewrites.pop("urllib.parse.urlencode") == "six.moves.urllib.urlencode"
    assert m.rewrites.pop("os.getcwd") == "six.moves.os.getcwdu"
    assert m.rewrites.pop("repr") == "six.moves.reprlib"

# Generated at 2022-06-12 03:55:53.524170
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert 'six.moves.urllib.parse.urlsplit' == SixMovesTransformer().rewrites['urlsplit']

# Generated at 2022-06-12 03:55:59.725087
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('userlist', 'UserList')
    assert m.name == 'userlist'
    assert m.new == 'userlist'
    assert m.old == 'UserList'

    m = MovedModule('UserList', 'UserList')
    assert m.name == 'UserList'
    assert m.new == 'UserList'
    assert m.old == 'UserList'

# Generated at 2022-06-12 03:56:04.818018
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        # too many parameters
        foo = MovedModule("six", "six", "six", "six")
    m = MovedModule("six", "six")
    assert m.name == "six"
    assert m.new == "six"
    m = MovedModule("six", "six", "six")
    assert m.name == "six"
    assert m.new == "six"


# Generated at 2022-06-12 03:56:06.677996
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from pickle import loads, dumps
    from io import BytesIO

    t = SixMovesTransformer()

    assert t.dependencies == ['six']

    t = loads(dumps(t))

    assert t.target == (2, 7)

# Generated at 2022-06-12 03:56:07.829363
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    for i in _get_rewrites():
        assert i in SixMovesTransformer.rewrites


# Generated at 2022-06-12 03:56:44.752663
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:56:47.805634
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .test_utils import assert_equivalent
    from .test_utils import generate_mutations

    for mut in generate_mutations(SixMovesTransformer):
        assert_equivalent(mut)

# Generated at 2022-06-12 03:56:53.836155
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    # default values
    m = MovedAttribute('name', 'old_mod', 'new_mod')
    assert m.new_attr == 'name'

    m = MovedAttribute('name', 'old_mod', None)
    assert m.new_mod == 'name'

    # no default values
    m = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert m.new_attr == 'old_attr'

    m = MovedAttribute('name', 'old_mod', 'new_mod', None, 'new_attr')
    assert m.new_attr == 'new_attr'

# Generated at 2022-06-12 03:56:56.822514
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("builtins", "__builtin__").new == "builtins"
    assert MovedModule("builtins", "__builtin__", new="new_builtins").new == "new_builtins"


# Generated at 2022-06-12 03:57:03.646271
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c').name == 'a'
    assert MovedAttribute('a', 'b', 'c').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c').new_attr == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'

# Generated at 2022-06-12 03:57:04.935778
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0
    # This test passes if it completes without error

# Generated at 2022-06-12 03:57:08.261775
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moves = MovedModule("foo", "bar")
    assert moves.name == "foo"
    assert moves.new == "foo"
    assert moves.old == "bar"

    moves = MovedModule("foo", "bar", "foobar")
    assert moves.name == "foo"
    assert moves.new == "foobar"
    assert moves.old == "bar"

# Generated at 2022-06-12 03:57:11.003677
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert str(m) == "<MovedModule: name>", 'str(m) not equal to "<MovedModule: name>"'
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"


# Generated at 2022-06-12 03:57:18.349591
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    instance = SixMovesTransformer()
    assert instances_equal(instance, SixMovesTransformer())

    assert 'six.moves.tkinter.messagebox' in instance.rewrites
    assert instance.rewrites['six.moves.tkinter.messagebox'] == 'six.moves.tkinter_messagebox'

    assert 'six.moves.tkinter.dialog' in instance.rewrites
    assert instance.rewrites['six.moves.tkinter.dialog'] == 'six.moves.tkinter_dialog'
    assert not instances_equal(instance, 'whatever')


# Test for function `test_get_rewrites`

# Generated at 2022-06-12 03:57:27.383263
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:58:33.049404
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert str(MovedAttribute("ab", "c", "d", "e", "f")) == "MovedAttribute( name='ab', old_mod='c', new_mod='d', old_attr='e', new_attr='f' )"


# Generated at 2022-06-12 03:58:35.083780
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    importlib.import_module("lib3to6.fixes.fix_six_moves")
    assert len(SixMovesTransformer.rewrites) == 69

# Generated at 2022-06-12 03:58:38.434855
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule("name", "old", "new")
    print(moved_module.name)
    print(moved_module.old)
    print(moved_module.new)



# Generated at 2022-06-12 03:58:43.180297
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    '''
    Test the constructor of class MovedAttribute
    '''
    m = MovedAttribute(name='m', old_mod='old_mod', new_mod='new_mod', old_attr='old_attr', new_attr='new_attr')
    assert m.name == 'm'
    assert m.new_mod == 'new_mod'
    assert m.new_attr == 'new_attr'


# Generated at 2022-06-12 03:58:46.183031
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule("a", "b")
    assert mm.name == "a"
    assert mm.new == "b"

    mm = MovedModule("c", "d", "e")
    assert mm.name == "c"
    assert mm.new == "e"

# Generated at 2022-06-12 03:58:50.564576
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule('builtins', '__builtin__')
    assert module.name == 'builtins'
    assert module.new == 'builtins'

    module = MovedModule('builtins', '__builtin__', 'six.moves.builtins')
    assert module.name == 'builtins'
    assert module.new == 'six.moves.builtins'


# Generated at 2022-06-12 03:58:59.567174
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    class TestMovedAttribute(MovedAttribute):
        def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
            self.name = name
            self.old_mod = old_mod
            self.new_mod = new_mod
            self.old_attr = old_attr
            self.new_attr = new_attr

    attr = TestMovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr',
                              new_attr='new_attr')
    assert attr.name == 'name'
    assert attr.old_mod == 'old_mod'
    assert attr.new_mod == 'new_mod'
    assert attr.old_attr == 'old_attr'
    assert attr.new_attr

# Generated at 2022-06-12 03:59:01.170014
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('bob', 'joe') == MovedModule('bob', 'joe')

# Generated at 2022-06-12 03:59:11.780741
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    """Test for constructor of class MovedAttribute"""
    assert MovedAttribute("a", "b", "c").name == "a"
    assert MovedAttribute("a", "b", "c").new_mod == "c"
    assert MovedAttribute("a", "b", "c").new_attr == "a"
    assert MovedAttribute("a", "b", "c", "d", "e").name == "a"
    assert MovedAttribute("a", "b", "c", "d", "e").new_mod == "c"
    assert MovedAttribute("a", "b", "c", "d", "e").new_attr == "e"
    assert MovedAttribute("a", "b", "c", "a", "e").name == "a"

# Generated at 2022-06-12 03:59:13.925277
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('name', 'old').name == 'name'
    assert MovedModule('name', 'old', 'new').new == 'new'