

# Generated at 2022-06-12 03:50:49.504487
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    print(SixMovesTransformer().rewrites)

# Generated at 2022-06-12 03:50:52.652656
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    test = MovedAttribute('os', 'os', 'builtins', 'sep', 'os')
    assert test.name == 'os'
    assert test.new_mod == 'builtins'
    assert test.new_attr == 'os'


# Generated at 2022-06-12 03:50:54.898533
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    transformer = SixMovesTransformer()
    assert transformer.rewrites == _get_rewrites()
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:50:57.446845
# Unit test for constructor of class MovedModule
def test_MovedModule():
    x = MovedModule("A", "B", "C")
    assert x.name == "A"
    assert x.new == "C"



# Generated at 2022-06-12 03:51:08.661596
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()

# Generated at 2022-06-12 03:51:12.295837
# Unit test for constructor of class MovedModule
def test_MovedModule():
    check_MovedModule = MovedModule('name', 'old', 'new')
    assert check_MovedModule.name == 'name'
    assert check_MovedModule.old == 'old'
    assert check_MovedModule.new == 'new'



# Generated at 2022-06-12 03:51:24.670675
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    code = '''
    import six
    from six.moves import cStringIO
    from six.moves.urllib.parse import ParseResult
    from six.moves.urllib_error import ContentTooShortError
    from six.moves.urllib_request import Request
    from six.moves.urllib_response import addbase
    from six.moves.urllib_robotparser import RobotFileParser

    cStringIO.StringIO('abc').read()
    ParseResult('http', 'netloc', 'path', 'params', 'query', 'fragment').fragment

    # Should not be transformed:
    from six.moves.urllib import robotparser

    # Should not be transformed:
    from six.moves.urllib.error import URLError
        '''

# Generated at 2022-06-12 03:51:33.477283
# Unit test for constructor of class MovedModule
def test_MovedModule():
	assert MovedModule("builtins", "__builtin__").name == "builtins"
	assert MovedModule("builtins", "__builtin__").new == "builtins"
	assert MovedModule("tkinter_tix", "Tix", "tkinter.tix").name == "tkinter_tix"
	assert MovedModule("tkinter_dialog", "Dialog", "tkinter.dialog").new == "tkinter.dialog"
	assert MovedModule("urllib", None, "six.moves.urllib").new == "six.moves.urllib"


# Generated at 2022-06-12 03:51:37.396578
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved.new_attr == "StringIO"
    moved_no_attr = MovedAttribute("cStringIO", "cStringIO", "io")
    assert moved_no_attr.new_attr == "cStringIO"

# Generated at 2022-06-12 03:51:41.932140
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('name', 'old', 'new')
    assert a.name == 'name'
    assert a.new_mod == 'new'
    assert a.new_attr == 'name'

    b = MovedAttribute('name', 'old', 'new', 'old_name', 'new_name')
    assert b.name == 'name'
    assert b.new_mod == 'new'
    assert b.new_attr == 'new_name'

# Generated at 2022-06-12 03:51:52.029712
# Unit test for constructor of class MovedModule
def test_MovedModule():
    import six
    import six.moves
    mm = MovedModule('configparser', 'ConfigParser')
    assert mm.name == 'configparser'
    assert mm.new == 'configparser'
    mm = MovedModule('configparser', 'ConfigParser', 'configparser')
    assert mm.name == 'configparser'
    assert mm.new == 'configparser'
    mm2 = MovedModule('io', 'StringIO', 'io')
    assert mm2.name == 'io'
    assert mm2.new == 'io'
    assert mm2 == six.moves.StringIO


# Generated at 2022-06-12 03:52:00.177657
# Unit test for constructor of class MovedModule
def test_MovedModule():
    MovedModule("name", "old", "new")
    MovedModule("name", "old", None)
    MovedModule("name", "old")
    expected = MovedModule("name", "old", "new")
    assert expected.name == "name"
    assert expected.old == "old"
    assert expected.new == "new"
    expected = MovedModule("name", "old", "name")
    assert expected.name == "name"
    assert expected.old == "old"
    assert expected.new == "name"
    expected = MovedModule("name", "old")
    assert expected.name == "name"
    assert expected.old == "old"
    assert expected.new == "name"



# Generated at 2022-06-12 03:52:02.814738
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test constructor
    trans = SixMovesTransformer(None, None, None)
    assert isinstance(trans, BaseImportRewrite)
    assert trans.target == (2, 7)
    assert trans.dependencies == ['six']


# Generated at 2022-06-12 03:52:10.107044
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved = MovedModule('ten', 'ten')
    assert moved.name == 'ten'
    assert moved.new == 'ten'

    moved = MovedModule('twenty', 'twenty', 'twenty')
    assert moved.name == 'twenty'
    assert moved.new == 'twenty'

    moved = MovedModule('thirty', 'thirty', 'thirty-one')
    assert moved.name == 'thirty'
    assert moved.new == 'thirty-one'


# Generated at 2022-06-12 03:52:12.977775
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move = MovedModule('queue', 'Queue')
    assert move.name == 'queue'
    assert move.new == 'queue'
    assert move.old == 'Queue'



# Generated at 2022-06-12 03:52:23.274642
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("a", "b", "c")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "a"

    a = MovedAttribute("a", "b", "c", "d")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "d"

    a = MovedAttribute("a", "b", "c", "d", "e")
    assert a.name == "a"
    assert a.new_mod == "c"
    assert a.new_attr == "e"



# Generated at 2022-06-12 03:52:27.512317
# Unit test for constructor of class SixMovesTransformer

# Generated at 2022-06-12 03:52:37.206951
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .base import BaseImportRewrite

    # type: ignore
    for cls in (SixMovesTransformer,):
        assert issubclass(cls, BaseImportRewrite)
        assert cls.target == (2, 7)
        assert cls.dependencies == ['six']
        assert isinstance(cls.rewrites, dict)
        assert 'six.moves.urllib.parse.urlparse' in cls.rewrites
        assert 'six.moves.urllib.parse.urlparse' in cls.rewrites.keys()
        assert cls.rewrites['six.moves.urllib.parse.urlparse'] == 'six.moves.urllib_parse.urlparse'
        assert 'six.moves.urllib.error.URLError' in cls.rewrites

# Generated at 2022-06-12 03:52:42.101684
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attr = MovedAttribute("StringIO", "cStringIO", "io", "StringIO")
    assert attr.name == "StringIO"
    assert attr.old_mod is None
    assert attr.new_mod == "io"
    assert attr.old_attr == "StringIO"
    assert attr.new_attr == "StringIO"

# Generated at 2022-06-12 03:52:47.595569
# Unit test for constructor of class MovedModule
def test_MovedModule():
    new = MovedModule("test", "old", "new")
    assert new.name == "test"
    assert new.old == "old"
    assert new.new == "new"

    new2 = MovedModule("test2", "old2")
    assert new2.name == "test2"
    assert new2.old == "old2"
    assert new2.new == "test2"

# Generated at 2022-06-12 03:52:55.091091
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("name", "old", "new")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "new"
    m = MovedModule("name", "old")
    assert m.name == "name"
    assert m.old == "old"
    assert m.new == "name"
    try:
        MovedModule("name", "old", "new", "old2")
        assert False, "extra arguments should cause an exception"
    except TypeError:
        pass

# Generated at 2022-06-12 03:53:07.904728
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert ma.name == 'name'
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'new_attr'

    ma = MovedAttribute('name', 'old_mod', 'new_mod', old_attr='old_attr')
    assert ma.new_attr == 'old_attr'

    ma = MovedAttribute('name', 'old_mod', 'new_mod')
    assert ma.new_mod == 'new_mod'
    assert ma.new_attr == 'name'

    ma = MovedAttribute('name', 'old_mod', None)
    assert ma.new_mod == 'name'
    assert ma.new_attr == 'name'


#

# Generated at 2022-06-12 03:53:09.901907
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert(SixMovesTransformer.rewrites == _get_rewrites())


if __name__ == '__main__':
    print(list(_get_rewrites()))

# Generated at 2022-06-12 03:53:13.077384
# Unit test for constructor of class MovedModule
def test_MovedModule():
    item = MovedModule('name', 'old', 'new')
    assert item.name == 'name'
    assert item.old == 'old'
    assert item.new == 'new'

# Generated at 2022-06-12 03:53:16.269543
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    st = SixMovesTransformer.__new__(SixMovesTransformer)
    assert st.target == (2, 7)
    assert st.dependencies == ['six']
    assert len(st.rewrites) == 45

# Generated at 2022-06-12 03:53:23.328671
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "io"
    assert a.new_attr == "StringIO"

    a = MovedAttribute("filter", "itertools", "builtins")
    assert a.name == "filter"
    assert a.new_mod == "builtins"
    assert a.new_attr == "filter"

    a = MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter")
    assert a.name == "filter"
    assert a.new_mod == "builtins"
    assert a.new_attr == "filter"


# Generated at 2022-06-12 03:53:31.374220
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    import six
    test_rewrites = _get_rewrites()
    for path, rewrite in test_rewrites:
        # 'six.moves' is not __init__, it is a 'six' module
        if isinstance(path, str) and path.startswith('six.moves'):
            continue
        assert isinstance(path, str)
        assert hasattr(six, path)
    assert SixMovesTransformer.rewrites == test_rewrites
    assert SixMovesTransformer.dependencies == ['six']

# Generated at 2022-06-12 03:53:37.765707
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('cStringIO', 'cStringIO', 'io', 'StringIO', 'StringIO').__dict__ == \
           {'name': 'cStringIO', 'old_mod': 'cStringIO', 'new_mod': 'io', 'old_attr': 'StringIO', 'new_attr': 'StringIO'}
    assert MovedAttribute('name', 'old_mod', 'new_mod').__dict__ == \
           {'name': 'name', 'old_mod': 'old_mod', 'new_mod': 'new_mod', 'old_attr': None, 'new_attr': 'name'}

# Generated at 2022-06-12 03:53:40.202895
# Unit test for constructor of class MovedModule
def test_MovedModule():
    try:
        moved_module = MovedModule("builtins", "__builtin__")
    except AttributeError:
        assert False

# Generated at 2022-06-12 03:53:51.744606
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("a", "b", "c")
    assert m.name == "a"
    assert m.new_mod == "c"
    assert m.new_attr == "a"

    m = MovedAttribute("a", "b", "c", "d", "e")
    assert m.name == "a"
    assert m.new_mod == "c"
    assert m.new_attr == "e"

    m = MovedAttribute("a", "b", "c", "d")
    assert m.name == "a"
    assert m.new_mod == "c"
    assert m.new_attr == "d"

    m = MovedAttribute("a", "b")
    assert m.name == "a"
    assert m.new_mod == "a"
    assert m.new

# Generated at 2022-06-12 03:54:09.384391
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    success = 'test_SixMovesTransformer: ok'

# Generated at 2022-06-12 03:54:21.431764
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    redefined_attribute = MovedAttribute("gcd", "math", "xyz", "mygcd", "mygcd")
    assert redefined_attribute.name == "gcd"
    assert redefined_attribute.old_mod == "math"
    assert redefined_attribute.new_mod == "xyz"
    assert redefined_attribute.old_attr == "mygcd"
    assert redefined_attribute.new_attr == "mygcd"

    same_name_attribute = MovedAttribute("gcd", "math", "xyz")
    assert same_name_attribute.name == "gcd"
    assert same_name_attribute.old_mod == "math"
    assert same_name_attribute.new_mod == "xyz"
    assert same_name_attribute.old_attr == "gcd"

# Generated at 2022-06-12 03:54:27.276900
# Unit test for constructor of class MovedModule
def test_MovedModule():
    move1 = MovedModule('builtins', '__builtin__')
    move2 = MovedModule('dbm_gnu', 'gdbm', 'dbm.gnu')
    assert move1.name == 'builtins'
    assert move1.new == 'builtins'
    assert move2.name == 'dbm_gnu'
    assert move2.new == 'dbm.gnu'



# Generated at 2022-06-12 03:54:28.795139
# Unit test for constructor of class MovedModule
def test_MovedModule():
    with pytest.raises(TypeError):
        MovedModule()



# Generated at 2022-06-12 03:54:34.034400
# Unit test for constructor of class MovedModule
def test_MovedModule():
    six_moves = MovedModule("builtins", "__builtin__")
    assert six_moves.name == "builtins"
    assert six_moves.old == "__builtin__"
    assert six_moves.new == "builtins"

# Generated at 2022-06-12 03:54:39.541724
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute=MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name=="cStringIO"
    assert moved_attribute.new_mod=="io"
    assert moved_attribute.new_attr=="StringIO"

# Unit tests for constructor of class MovedAttribute

# Generated at 2022-06-12 03:54:45.551891
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module = MovedModule('foo', 'bar')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'foo'

    moved_module = MovedModule('foo', 'bar', 'baz')
    assert moved_module.name == 'foo'
    assert moved_module.new == 'baz'

# Generated at 2022-06-12 03:54:49.735767
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    const = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert const.name == "cStringIO"
    assert const.new_mod == "io"
    assert const.new_attr == "StringIO"



# Generated at 2022-06-12 03:54:56.247954
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from . import assert_equal, assert_is_instance, assert_not_in
    # Test that we did not forget to include any moves from six.

# Generated at 2022-06-12 03:54:59.232042
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert SixMovesTransformer.rewrites is not None
    assert SixMovesTransformer.dependencies is not None
    assert not SixMovesTransformer.dependencies.empty()
    assert not SixMovesTransformer.rewrites.empty()


# Generated at 2022-06-12 03:55:15.775260
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    foo = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert foo.name == "cStringIO"
    assert foo.new_mod == "io"
    assert foo.new_attr == "StringIO"
    bar = MovedAttribute("foo", "bar", "baz", "quux")
    assert bar.name == "foo"
    assert bar.new_mod == "baz"
    assert bar.new_attr == "quux"
    baz = MovedAttribute("baz", "bat", "bat", "bat", "baz")
    assert baz.name == "baz"
    assert baz.new_mod == "bat"
    assert baz.new_attr == "baz"

# Generated at 2022-06-12 03:55:26.269723
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

    move = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "cStringIO"

# Generated at 2022-06-12 03:55:27.924442
# Unit test for constructor of class MovedModule
def test_MovedModule():
    module = MovedModule("name", "old")
    assert module.name == "name"
    assert module.new == "name"



# Generated at 2022-06-12 03:55:39.058900
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .testing import assertTransformedEquivalent
    from .testing import capture_logging
    from .testing import write_file_and_read


# Generated at 2022-06-12 03:55:46.334136
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    ma_1 = MovedAttribute("name", "old_mod", "new_mod", "old_attr", "new_attr")
    assert ma_1.name == "name"
    assert ma_1.new_mod == "new_mod"
    assert ma_1.new_attr == "new_attr"

    ma_2 = MovedAttribute("name", "old_mod", "new_mod", "old_attr")
    assert ma_2.name == "name"
    assert ma_2.new_mod == "new_mod"
    assert ma_2.new_attr == "old_attr"

    ma_3 = MovedAttribute("name", "old_mod", "new_mod")
    assert ma_3.name == "name"
    assert ma_3.new_mod == "new_mod"

# Generated at 2022-06-12 03:55:52.237012
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('a', 'b', 'c') == MovedModule('a', 'b', 'c')
    assert MovedModule('a', 'b') == MovedModule('a', 'b')
    assert MovedModule('a', 'b', 'c') != MovedModule('a', 'b')
    assert MovedModule('a', 'b', 'c') != MovedModule('a', 'd')


# Generated at 2022-06-12 03:56:02.689066
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") == \
        MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != \
        MovedAttribute("test", "cStringIO", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != \
        MovedAttribute("cStringIO", "test", "io", "StringIO")
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO") != \
        MovedAttribute("cStringIO", "cStringIO", "test", "StringIO")

# Generated at 2022-06-12 03:56:05.751101
# Unit test for constructor of class MovedModule
def test_MovedModule():
    s = '__builtin__.StringIO'
    b = MovedModule('StringIO', 'StringIO', 'StringIO')
    assert isinstance(b, MovedModule), "Object is not instance of MovedModule"
    assert b.name == 'StringIO', "Object has wrong name"
    assert b.old == 'StringIO', "Object has wrong old module"
    assert b.new == 'StringIO', "Object has wrong new module"
    assert str(b) == s, "Object has wrong representation"

# Generated at 2022-06-12 03:56:11.044458
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    m = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "cStringIO"

    m = MovedAttribute("cStringIO", "cStringIO", "io", None, "StringIO")
    assert m.name == "cStringIO"
    assert m.new_mod == "io"
    assert m.new_attr == "StringIO"


# Generated at 2022-06-12 03:56:15.218892
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule('mod', 'mod').new == 'mod'
    assert MovedModule('mod', 'mod').name == 'mod'
    assert MovedModule('mod', 'oldmod').new == 'mod'
    assert MovedModule('mod', 'oldmod').name == 'mod'
    assert MovedModule('mod', 'oldmod', 'newmod').new == 'newmod'
    assert MovedModule('mod', 'oldmod', 'newmod').name == 'mod'


# Generated at 2022-06-12 03:56:30.232690
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule("module1", "module_old", "module_new")
    assert m.name=="module1"
    assert m.old=="module_old"
    assert m.new=="module_new"

# Generated at 2022-06-12 03:56:31.142486
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    SixMovesTransformer()

# Generated at 2022-06-12 03:56:37.365366
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    attribute = MovedAttribute('attribute_name', 'old_module', 'new_module')
    assert attribute.name == 'attribute_name'
    assert attribute.old_mod == 'old_module'
    assert attribute.new_mod == 'new_module'
    assert attribute.old_attr is None
    assert attribute.new_attr == 'attribute_name'

    attribute = MovedAttribute('name', 'old', 'new', 'old_attr')
    assert attribute.name == 'name'
    assert attribute.old_mod == 'old'
    assert attribute.new_mod == 'new'
    assert attribute.old_attr == 'old_attr'
    assert attribute.new_attr == 'old_attr'


# Generated at 2022-06-12 03:56:40.630982
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Arrange
    test_six = SixMovesTransformer()

    # Assert
    assert test_six.target == (2, 7)
    assert test_six.dependencies == ['six']

# Generated at 2022-06-12 03:56:50.436178
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    obj = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert obj.name == 'name'
    assert obj.new_mod == 'new_mod'
    assert obj.new_attr == 'new_attr'

    obj = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert obj.new_attr == 'old_attr'

    obj = MovedAttribute('name', 'old_mod', 'new_mod', None, 'new_attr')
    assert obj.new_attr == 'new_attr'

    obj = MovedAttribute('name', 'old_mod', None)
    assert obj.new_mod == 'name'

    obj = MovedAttribute('name', 'old_mod', 'new_mod')

# Generated at 2022-06-12 03:56:59.561911
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute("cStringIO", "cStringIO", "io", "StringIO").new_attr == 'StringIO'
    assert MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter").new_attr == 'filter'
    assert MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse").new_attr == 'filterfalse'
    assert MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input").new_attr == 'input'
    assert MovedAttribute("intern", "__builtin__", "sys").new_attr == 'intern'
    assert MovedAttribute("map", "itertools", "builtins", "imap", "map").new_attr == 'map'

# Generated at 2022-06-12 03:57:02.425328
# Unit test for constructor of class MovedModule
def test_MovedModule():
    # Make sure typos in module name get caught
    with pytest.raises(TypeError):
        MovedModule('builtins', '__builtin__', 'bltins')

# Unit tests for translator

# Generated at 2022-06-12 03:57:08.137438
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # Test SixMovesTransformer with target version < 2.7
    with pytest.raises(TypeError):
        SixMovesTransformer(target=(2, 4))

    # Test when python version is < 2.7
    with pytest.raises(TypeError):
        SixMovesTransformer(target=(3, 0))

    # Test SixMovesTransformer with target version > 2.7
    with pytest.raises(TypeError):
        SixMovesTransformer(target=(3, 8))

# Generated at 2022-06-12 03:57:09.089179
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert len(_get_rewrites()) > 0

# Generated at 2022-06-12 03:57:12.510433
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('name', 'module', 'newmodule', 'attr')
    assert a.name == 'name'
    assert a.new_mod == 'newmodule'
    assert a.new_attr == 'attr'


# Generated at 2022-06-12 03:57:42.844278
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved_attribute = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert moved_attribute.name == "cStringIO"
    assert moved_attribute.new_mod == "io"
    assert moved_attribute.new_attr == "StringIO"


# Generated at 2022-06-12 03:57:47.495288
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    moved = MovedAttribute('foo', 'x', 'y')
    assert moved.name == 'foo'
    assert moved.new_mod == 'y'
    assert moved.new_attr == 'foo'
    moved = MovedAttribute('foo', 'x', 'y', 'old', 'new')
    assert moved.name == 'foo'
    assert moved.new_mod == 'y'
    assert moved.new_attr == 'new'

# Unit tests for constructor of class MovedModule

# Generated at 2022-06-12 03:57:52.957404
# Unit test for constructor of class MovedModule
def test_MovedModule():
    m = MovedModule('foo', 'bar')
    assert m == MovedModule('foo', 'bar', 'foo')
    m = MovedModule('foo', 'bar', 'baz')
    assert m == MovedModule('foo', 'bar', 'baz')


# Generated at 2022-06-12 03:57:59.284040
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute(name='cStringIO', old_mod=None, new_mod=None, old_attr=None, new_attr=None)
    assert move.name == 'cStringIO'
    assert move.new_mod == 'cStringIO'
    assert move.new_attr == 'cStringIO'

    move = MovedAttribute(name='filter', old_mod='itertools', new_mod='builtins', old_attr='ifilter', new_attr='filter')
    assert move.name == 'filter'
    assert move.new_mod == 'builtins'
    assert move.new_attr == 'filter'


# Generated at 2022-06-12 03:58:04.250663
# Unit test for constructor of class MovedModule
def test_MovedModule():
    moved_module_mock_1 = MovedModule('name', 'old')
    moved_module_mock_2 = MovedModule('name', 'old', 'new')
    assert moved_module_mock_1.name == 'name'
    assert moved_module_mock_1.new == 'name'
    assert moved_module_mock_1.old == 'old'
    assert moved_module_mock_2.name == 'name'
    assert moved_module_mock_2.new == 'new'
    assert moved_module_mock_2.old == 'old'


# Generated at 2022-06-12 03:58:07.011500
# Unit test for constructor of class MovedModule
def test_MovedModule():
    """Test import of moved modules."""
    module = MovedModule('Example', 'Example')
    assert module.name == 'Example'
    assert module.new == 'Example'


# Generated at 2022-06-12 03:58:09.310856
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    t = SixMovesTransformer()
    assert t.rewrites == _get_rewrites()
    assert t.target == (2, 7)
    assert t.dependencies == ['six']

# Generated at 2022-06-12 03:58:13.175746
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert a.name == "cStringIO"
    assert a.new_mod == "cStringIO"
    assert a.new_attr == "StringIO"

# Generated at 2022-06-12 03:58:16.135190
# Unit test for constructor of class MovedModule
def test_MovedModule():
    assert MovedModule("foo", "bar").name == "foo"
    assert MovedModule("foo", "bar").new == "bar"
    assert MovedModule("foo", "bar", "baz").new == "baz"


# Generated at 2022-06-12 03:58:18.965353
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mo = MovedModule("name", "old", "new")
    assert mo.name == "name"
    assert mo.old == "old"
    assert mo.new == "new"

# Generated at 2022-06-12 03:59:17.455282
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    assert next(_get_rewrites()) == ('cStringIO.StringIO', 'six.moves.StringIO')



# Generated at 2022-06-12 03:59:22.747753
# Unit test for constructor of class MovedModule
def test_MovedModule():
    mm = MovedModule('name', 'old', 'new')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'new'
    mm = MovedModule('name', 'old')
    assert mm.name == 'name'
    assert mm.old == 'old'
    assert mm.new == 'name'


# Generated at 2022-06-12 03:59:32.130133
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    from .util import RewriteTestCase, assert_equal
    from . import test_all_fixers
    test_all_fixers(__file__)
    RewriteTestCase(SixMovesTransformer, __file__, expected=(6, 0), input=(2, 7)).test()
    RewriteTestCase(SixMovesTransformer, __file__, expected=None, input=(6, 0)).test()
    RewriteTestCase(SixMovesTransformer, __file__, expected=None, input=(3, 3)).test()
    RewriteTestCase(SixMovesTransformer, __file__, expected=None, input=(3, 4)).test()


if __name__ == '__main__':
    test_SixMovesTransformer()

# Generated at 2022-06-12 03:59:35.289586
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move.name == "cStringIO"
    assert move.new_mod == "io"
    assert move.new_attr == "StringIO"



# Generated at 2022-06-12 03:59:36.367057
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    checker = SixMovesTransformer()

# Generated at 2022-06-12 03:59:41.083763
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    # This unit test is meant to test the constructor of the class SixMovesTransformer
    # As we are using eager.py to define rewrites, there is no need to test the rewrites attribute.
    # Instead we check the other attributes.
    six_moves_transformer = SixMovesTransformer()
    # check target
    assert six_moves_transformer.target == (2, 7)

# Generated at 2022-06-12 03:59:46.391272
# Unit test for constructor of class SixMovesTransformer
def test_SixMovesTransformer():
    moves = [('six.moves.urllib.parse', 'six.moves.urllib.parse.SOMETHING')]
    importer = SixMovesTransformer(version=(2, 7), rewrites=moves)
    assert importer.import_package_name == 'six'
    assert importer.required_version == (2, 7)
    assert importer.requested_version is None
    assert importer.rewrites == moves, moves

# Generated at 2022-06-12 03:59:55.269671
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    a = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr', 'new_attr')
    assert a.name == 'name'
    assert a.new_mod == 'new_mod'
    assert a.new_attr == 'new_attr'
    b = MovedAttribute('name', 'old_mod', 'new_mod')
    assert b.name == 'name'
    assert b.new_mod == 'new_mod'
    assert b.new_attr == 'name'
    c = MovedAttribute('name', 'old_mod', 'new_mod', 'old_attr')
    assert c.name == 'name'
    assert c.new_mod == 'new_mod'
    assert c.new_attr == 'old_attr'


# Generated at 2022-06-12 04:00:03.088591
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    move1 = MovedAttribute("cStringIO", "cStringIO", "io", "StringIO")
    assert move1.name == "cStringIO"
    assert move1.new_mod == "cStringIO"
    assert move1.new_attr == "StringIO"

    move2 = MovedAttribute("cStringIO", "cStringIO", "io")
    assert move1.name == "cStringIO"
    assert move1.new_mod == "cStringIO"
    assert move1.new_attr == "StringIO"

    move3 = MovedAttribute("cStringIO", "cStringIO", "io", new_attr="stringio")
    assert move3.name == "cStringIO"
    assert move3.new_mod == "cStringIO"
    assert move3.new_attr == "stringio"

# Generated at 2022-06-12 04:00:11.951816
# Unit test for constructor of class MovedAttribute
def test_MovedAttribute():
    assert MovedAttribute('a', 'b', 'c').name == 'a'
    assert MovedAttribute('a', 'b', 'c').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c').new_attr == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_mod == 'c'
    assert MovedAttribute('a', 'b', 'c', 'd', 'e').new_attr == 'e'
    assert MovedAttribute('a', 'b', 'c', 'a', 'e').name == 'a'
    assert MovedAttribute('a', 'b', 'c', 'a', 'e').new_mod == 'c'