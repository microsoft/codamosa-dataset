

# Generated at 2022-06-23 22:48:24.534475
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:33.638542
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # class with yield
    class WithYield(ast.AST):
        _fields = ('fn',)

        def __init__(self, fn):
            self.fn = fn
    # class w/o yield
    class NoYield(ast.AST):
        _fields = ('fn',)

        def __init__(self, fn):
            self.fn = fn

    # method with yield
    fn1 = ast.FunctionDef(
        name='fn',
        args=ast.arguments(args=[], defaults=[], kwonlyargs=[], kw_defaults=[], vararg=None, kwarg=None),
        body=[
            ast.Expr(ast.Yield(value=ast.Constant(value=1))),
            ast.Return(value=ast.Constant(value=5))
        ])



# Generated at 2022-06-23 22:48:39.563054
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fdef = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')

    fdef = ReturnFromGeneratorTransformer().visit(fdef)
    c = ast.Module()
    c.body = [fdef]


# Generated at 2022-06-23 22:48:50.581050
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:51.955088
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:52.903309
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:03.463124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import assert_dont_render_unchanged

    def test(code: str, expected: str) -> None:
        tree = ast.parse(code)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        assert_dont_render_unchanged(tree, expected)

    test(code=dedent('''\
        @decorator
        def f():
            pass
        '''),
         expected=dedent('''\
        @decorator
        def f():
            pass
        '''))

    test(code=dedent('''\
        @decorator
        def f():
            return 0
        '''),
         expected=dedent('''\
        @decorator
        def f():
            return 0
        '''))



# Generated at 2022-06-23 22:49:06.128617
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def run_test(code):
        return_from_generator.transform(code, ReturnFromGeneratorTransformer, verbose=False)


# Generated at 2022-06-23 22:49:13.147581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''def foo():
        yield 1
        return 2
        '''
    node = ast.parse(code).body[0]
    assert isinstance(node, ast.FunctionDef)

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit_FunctionDef(node)
    assert isinstance(new_node, ast.FunctionDef)

    # Bonus test that ensures that function returns the same ast.FunctionDef
    assert ast.dump(new_node) == ast.dump(ast.parse(code).body[0])



# Generated at 2022-06-23 22:49:22.925620
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''def f():
    yield 1
    return 5'''
    expected = '''def f():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc'''

    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    node = ast.fix_missing_locations(node)
    result = compile(node, filename="<ast>", mode="exec").co_consts[1]
    # result should be equal to expected
    assert result == expected
    # node should be an Ast after compile
    assert isinstance(result, str)



# Generated at 2022-06-23 22:49:26.840579
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    import sys
    assert sys.version_info >= (3, 2)
    tree = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    assert len(ReturnFromGeneratorTransformer(None).visit(tree).body) == 1
    tree = ast.parse("""
        def fn():
            yield 1
            return
    """)
    assert len(ReturnFromGeneratorTransformer(None).visit(tree).body) == 1

# Generated at 2022-06-23 22:49:34.753668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test code before transformation
    node_to_test = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    # Test code after transformation
    node_transformed_correctly = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    node_transformed = transformer.visit(node_to_test)

    assert ast.dump(node_transformed, include_attributes=True) == ast.dump(node_transformed_correctly, include_attributes=True)

# Generated at 2022-06-23 22:49:41.971103
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        def test(self):
            source = """
            def fn():
                yield 1
                return 5
            """
            expected_source = """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """
            tree = ast.parse(source)
            actual = ReturnFromGeneratorTransformer().visit(tree)
            self.assertEqual(expected_source, unparse(actual))
    Test().test()


# Generated at 2022-06-23 22:49:46.650760
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ...testing.transformer import assert_program_equal
    from ...testing.assertions import assert_node

    class Generator:
        def fn(self):
            yield 1
            return 5

    assert_program_equal(Generator(), ReturnFromGeneratorTransformer)
    assert_node(Generator, "fn", ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:49:53.508491
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def fn():
        return 1
    """
    tree = compile_snippet(code, '<test>', 'exec')

    expected_code = """
    def fn():
        exc = StopIteration()
        exc.value = 1
        raise exc
    """
    expected_tree = compile_snippet(expected_code, '<test>', 'exec')

    transformer = ReturnFromGeneratorTransformer()
    with pytest.raises(RuntimeError):
        transformer.visit(tree)

    code = """
    def fn():
        i = 1
        if i:
            return 2
        else:
            yield 3
            return 4
    """
    tree = compile_snippet(code, '<test>', 'exec')


# Generated at 2022-06-23 22:49:55.483329
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:56.507838
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:59.914310
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert (return_from_generator_transformer != None)

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:06.871161
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..unparse import Unparser

    source = """
        def gen():
            yield 1
            return 5
    """

    expected = """
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    module = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)
    unparser = Unparser(module)
    result = unparser.unparse_module()
    assert result.strip() == expected.strip()

# Generated at 2022-06-23 22:50:12.488851
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def my_function():
        let(seq)
        seq = [10, 20, 30]
        for x in seq:
            let(x)
            yield x
        let(x)
        return 3

    assert my_function.get_source() == '''
    def my_function():
        seq = [10, 20, 30]
        for x in seq:
            x = x
            yield x
        x = 3
        exc = StopIteration()
        exc.value = 3
        raise exc'''

# Generated at 2022-06-23 22:50:13.622537
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__doc__ is not None

# Generated at 2022-06-23 22:50:17.998411
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.node import print_node
    def fn():
        yield 1
        return 5

    tr = ReturnFromGeneratorTransformer()
    assert str(tr.transform(fn.__code__)) == str(fn.__code__)

# Generated at 2022-06-23 22:50:26.545605
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef, Return, Name, Load, Constant
    from typed_ast import ast3 as ast

    tree = FunctionDef(
        name='foo',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            Return(value=Constant(value=5)),
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-23 22:50:28.286731
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with let(x) as x:
        assert x
    assert x == 3
    assert x + 2 == 5

# Generated at 2022-06-23 22:50:29.883355
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:50:39.085829
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class NoYield:
        def __init__(self):
            self.body = [ast.Return(None)]

    class HasYield:
        def __init__(self):
            self.body = [ast.Yield(None), ast.Return(ast.Num(5))]

    class HasYieldReturn:
        def __init__(self):
            self.body = [ast.YieldFrom(None), ast.Return(None)]

    class HasMultipleYields:
        def __init__(self):
            self.body = [ast.YieldFrom(None), ast.Yield(None), ast.Return(ast.Num(5))]

    class CustomClass:
        def __init__(self):
            self.body = [ast.YieldFrom(None), ast.Return(ast.Num(5))]

# Generated at 2022-06-23 22:50:48.178768
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Check:
        def __init__(self, fn, expect):
            self.fn = fn
            self.expect = expect
        def __call__(self):
            module = ast.parse(self.fn)
            ret = ReturnFromGeneratorTransformer()(module)
            a = ast.fix_missing_locations(ret)
            b = compile(a, '<test>', 'exec')
            exec(b)
            assert test_fn() == self.expect

    fn = '''
    def test_fn():
        def fn():
            yield 1
            return 5
        return fn()

    test_fn()
    '''
    expect = (1, 5)
    Check(fn=fn, expect=expect)()


# Generated at 2022-06-23 22:50:55.389584
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.example import example_function, example_function_supplier

    # Example 1:
    input_ = example_function('''
        def fn(arg):
            for i in range(10):
                if i % 2 == 0:
                    return i
    ''')
    expected_output = example_function_supplier('''
        def fn(arg):
            for i in range(10):
                if i % 2 == 0:
                    exc = StopIteration()
                    exc.value = i
                    raise exc
    ''')
    assert ReturnFromGeneratorTransformer().visit(input_) == expected_output

    # Example 2:
    input_ = example_function('''
        def fn(arg):
            yield 1
            if arg:
                return ''
            yield 2
    ''')


# Generated at 2022-06-23 22:50:56.258690
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).__class__.__name__ == "ReturnFromGeneratorTransformer"


# Generated at 2022-06-23 22:51:02.635376
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transformer import Transformer, apply_transforms

    source = '''
    def fn():
        yield 0
        yield 1
        return 12
    '''

    expected = '''
    def fn():
        yield 0
        yield 1
        exc = StopIteration()
        exc.value = 12
        raise exc
    '''
    module = ast.parse(source)
    assert not apply_transforms(Transformer, [ReturnFromGeneratorTransformer])(module)
    assert ast.dump(module) == ast.dump(ast.parse(expected))
#



# Generated at 2022-06-23 22:51:11.736751
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Transformer(ReturnFromGeneratorTransformer):
        def __getattribute__(self, name):
            if name.startswith("_replace_return"):
                counter = getattr(self, "_counter", 0)
                setattr(self, "_counter", counter + 1)
            return super().__getattribute__(name)

    def get_code(fn, **kwargs):
        fn_ast = ast.parse(inspect.getsource(fn)).body[0]
        transformed_fn_ast = Transformer(**kwargs).visit(fn_ast)
        code = compile(transformed_fn_ast, filename="<ast>", mode="exec")
        fn.__code__ = code
        return fn

    @get_code
    def fn_return_from_generator_with_yield():
        yield 1

# Generated at 2022-06-23 22:51:16.914140
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .function_def_with_generator_returns import before
    from .function_def_with_generator_returns import after

    func_def = ast.parse(before).body[0]
    assert isinstance(func_def, ast.FunctionDef)

    t = ReturnFromGeneratorTransformer()
    r = t.visit(func_def)

    assert after == ast.unparse(r)

# Generated at 2022-06-23 22:51:23.284651
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Given
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse("""def fn():
        yield 2
        return 2""")

    # When
    transformer.visit(node)

    # Then
    assert transformer._tree_changed is True
    assert str(node) == """def fn():
    yield 2
    exc = StopIteration()
    exc.value = 2
    raise exc"""


# Generated at 2022-06-23 22:51:27.442635
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)
    assert ReturnFromGeneratorTransformer.target == (3, 2)
    x = ReturnFromGeneratorTransformer()
    assert x.target == (3, 2)



# Generated at 2022-06-23 22:51:28.480423
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:34.336560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MyReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def visit_Return(self, node):
            return {'return': node}

    class CustomNode:
        def __init__(self, body, value=None):
            self.body = body
            self.value = value

    assert MyReturnFromGeneratorTransformer().visit(ast.FunctionDef(body=[
        ast.Pass()
    ])) == ast.FunctionDef(body=[ast.Pass()])

    assert MyReturnFromGeneratorTransformer().visit(CustomNode([
        CustomNode([
            ast.Pass()
        ])
    ], value=ast.Pass())) == CustomNode([
        CustomNode([
            ast.Pass()
        ])
    ], value=ast.Pass())


# Generated at 2022-06-23 22:51:35.098773
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:39.116409
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer(): # FIXME
    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return super().visit_FunctionDef(node)

    return ReturnFromGeneratorTransformerTest

# Generated at 2022-06-23 22:51:48.758452
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests import TransformerTestCase

    class TestCase(TransformerTestCase):
        @property
        def transformer(self) -> ReturnFromGeneratorTransformer:
            return ReturnFromGeneratorTransformer()

        def test_return_from_generator(self):
            origin = """
                def fn():
                    yield 1
                    return 5
            """

            expected = """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            """

            self.assertEqual(self.transform(origin), expected)

        def test_return_from_nested_generator_twice(self):
            origin = """
                def fn():
                    yield 1
                    yield 2
                    return 5
                    
                    yield 10
                    yield 15
                    return -1
            """

            expected

# Generated at 2022-06-23 22:51:50.337996
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)

# Generated at 2022-06-23 22:51:52.378348
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3

# Generated at 2022-06-23 22:51:53.395074
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:51:54.598781
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)._find_generator_returns(None) == []

# Generated at 2022-06-23 22:52:03.636092
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test for return in generator feature"""
    from typed_ast import ast3
    import copy
    import pprint
    ast_ = ast3.parse('def fn(): \n return 5 \n')
    print(ast_.body[0])
    ast_.body[0].body.append(copy.copy(ast_.body[0].body[0]))
    ast_.body[0].body.append(ast3.Yield())
    print(ast_.body[0])
    print(ReturnFromGeneratorTransformer().visit(ast_))
    ast_visited = ReturnFromGeneratorTransformer().visit(ast_).body[0]
    print(ast_visited)
    print(pprint.pformat(ast_visited))

# Generated at 2022-06-23 22:52:04.511619
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:14.477168
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import ast_utils as au
    from .tree_transformer import TreeTransformer

    source = """\
    def generator():
        yield 99
        return 99
    """
    expected = """\
    def generator():
        yield 99
        exc = StopIteration()
        exc.value = 99
        raise exc\
    """

    module_ast = au.to_ast(source)
    transformed_ast = TreeTransformer(version=au.PYTHON_VERSION).visit(module_ast)
    # The astunparse.unparse() do not work if the tree contains `FunctionDef` nodes.
    # Therefore, we only pick the node we want.
    actual = au.unparse(transformed_ast.body[0])

    assert actual == expected

# Generated at 2022-06-23 22:52:20.669849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Given
    source = """
    def fn():
        yield 1
        if True:
            return 5

    def fn2():
        yield 1
        if True:
            if False:
                return 5
            else:
                return 2
        else:
            pass
    """
    expected = """
    def fn():
        yield 1
        if True:
            exc = StopIteration()
            exc.value = 5
            raise exc

    def fn2():
        yield 1
        if True:
            if False:
                exc = StopIteration()
                exc.value = 5
                raise exc
            else:
                exc = StopIteration()
                exc.value = 2
                raise exc
        else:
            pass
    """
    node = ast.parse(source)

    # When
    transformer = ReturnFromGener

# Generated at 2022-06-23 22:52:30.631581
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # using the return transformer
    class test_ReturnFromGeneratorTransformer(unittest.TestCase):
        # testing the constructor
        def test_ReturnFromGeneratorTransformer_constructor_with_valid_parameters(self):
            root = ast.parse(
                "def foo():\n"
                "    y = 1\n"
                "    return y\n"
            )
            expected = ast.parse(
                "def foo():\n"
                "    y = 1\n"
                "    exc = StopIteration()\n"
                "    exc.value = y\n"
                "    raise exc\n"
            )

            root = ReturnFromGeneratorTransformer().visit(root)
            self.assertTrue(are_asts_equal(root, expected))

        # testing the constructor
       

# Generated at 2022-06-23 22:52:39.963008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:40.472317
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:45.112610
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    actual_code = '''
        def fn():
            yield 1
            return 1
    '''
    expected_code = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
    '''

    ast_tree = ast.parse(actual_code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert astor.to_source(ast_tree) == expected_code

# Generated at 2022-06-23 22:52:46.528652
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)



# Generated at 2022-06-23 22:52:48.565976
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.codegen import to_source
    from ..utils import get_ast


# Generated at 2022-06-23 22:52:55.307966
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_utils import format_code
    from .unannotate import UnannotateTransformer

    source = """
    def fn():
        yield 1
    """
    expected = """
    def fn():
        yield 1
    """
    tree = ast.parse(source)
    tree = ast.fix_missing_locations(tree)
    result = UnannotateTransformer().visit(tree)
    result = ReturnFromGeneratorTransformer().visit(result)
    assert format_code(expected) == format_code(result)

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree

# Generated at 2022-06-23 22:52:57.125662
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)



# Generated at 2022-06-23 22:52:58.422102
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:52:59.945202
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_codegen import codegen_compile

# Generated at 2022-06-23 22:53:05.272334
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_code_before():
        def fn():
            yield 1
            return 5

    transformed = ReturnFromGeneratorTransformer().visit(test_code_before)
    expected = return_from_generator.as_func_def()

    assert transformed.body[0].name == expected.name
    assert ast.dump(transformed.body[0].body) == ast.dump(expected.body)

# Generated at 2022-06-23 22:53:07.267754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer"""
    pass  # No need to test the constructor


# Generated at 2022-06-23 22:53:11.968425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    source = """
        def fn():
            yield 1
            return 5
    """

    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    print(ast.dump(node))
    assert astor.to_source(node) == expected


# Generated at 2022-06-23 22:53:17.758524
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for ReturnFromGeneratorTransformer"""
    from .test_modules import get_test_objects
    from .test_modules import assert_module_function_body
    test_objects = get_test_objects('generator_return_import')
    assert_module_function_body(
        test_objects,
        'fn_1',
        '''def fn_1():
    exc = StopIteration()
    exc.value = 1
    raise exc''')
    assert_module_function_body(
        test_objects,
        'fn_2',
        '''def fn_2():
    exc = StopIteration()
    exc.value = 9
    raise exc''')

# Generated at 2022-06-23 22:53:22.160178
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn(): yield 1; return 5')
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == 'def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc'



# Generated at 2022-06-23 22:53:28.852534
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    fn = """
    def fn():
        yield 1
        return 5
    """

    result = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    result_compiled = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected = ast.parse(result)
    snippet = ast.parse(fn).body[0]
    actual = transformer.visit(snippet)  # type: ignore
    assert ast.dump(expected) == ast.dump(actual)

    result_compiled = compile(result_compiled, '<test>', 'exec')
    exec(result_compiled)

# Generated at 2022-06-23 22:53:38.491836
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    f0 = ast.FunctionDef(name='f0',
                         args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]),
                         body=[
                             ast.Yield(value=ast.Num(n=1)),
                             ast.Return(value=ast.Num(n=5))
                         ],
                         decorator_list=[],
                         returns=None)


# Generated at 2022-06-23 22:53:41.948108
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    node = ast.parse(fn.__code__.co_consts[0])

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

# Generated at 2022-06-23 22:53:50.700459
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert (ReturnFromGeneratorTransformer(None, None)._find_generator_returns(
        ast.parse('def foo():\n yield 1\n return 5', mode='exec').body[0]
    ) == [
        (
            ast.parse('def foo():\n yield 1\n return 5', mode='exec').body[0],
            ast.parse('def foo():\n yield 1\n return 5', mode='exec').body[0].body[1]
        )
    ])
    assert (ReturnFromGeneratorTransformer(None, None)._find_generator_returns(
        ast.parse('def foo():\n return 5', mode='exec').body[0]
    ) == [])

# Generated at 2022-06-23 22:53:52.119800
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:54:01.635725
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    module = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    ReturnFromGeneratorTransformer().visit(module)

# Generated at 2022-06-23 22:54:03.086465
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tester import assert_ast_is


# Generated at 2022-06-23 22:54:08.648857
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    result = ast.parse("""def fn(a):
                            def b():
                                return a
                            yield b()""", mode="exec")
    expected = ast.parse("""def fn(a):
                            def b():
                                exc = StopIteration()
                                exc.value = a
                                raise exc
                            yield b()""", mode="exec")
    assert result == expected

# Generated at 2022-06-23 22:54:11.836116
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test():
        yield 1
        return 5

    tree = ast.parse(inspect.getsource(test))
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed


# Generated at 2022-06-23 22:54:12.759283
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:19.688502
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn_src = """
    def f():
        yield 1
        return 'foo'
    """
    fn_correct = """
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 'foo'
        raise exc
    """
    fn = ast.parse(fn_src)
    node = ReturnFromGeneratorTransformer().visit(fn)
    assert ast.dump(node) == ast.dump(ast.parse(fn_correct))

# Generated at 2022-06-23 22:54:21.801298
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    c = ReturnFromGeneratorTransformer()
    assert c


# Generated at 2022-06-23 22:54:22.423345
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:31.587568
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def test_return_from_generator(snippet):
        tree = ast.parse(snippet)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        generated_code = compile(tree, filename="<ast>", mode="exec")
        expected_return_value = eval(snippet)
        # pylint: disable=exec-used
        exec (generated_code)

    test_return_from_generator.description = "Test compilation of return in generator"


# Generated at 2022-06-23 22:54:38.265835
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from io import StringIO

    root = ast.parse("""
        def fn():
            yield 5
            return 6
    """)  # type: ast.FunctionDef

    buf = StringIO()

    node_transf = ReturnFromGeneratorTransformer()

    node_transf.visit(root)

    mod = ast.Module([root], type_ignores=[])
    mod = ast.fix_missing_locations(mod)
    mod = ast.increment_lineno(mod, 1)

    codegen.to_source(mod, buf)

    assert buf.getvalue() == """
        def fn():
            yield 5
            exc = StopIteration()
            exc.value = 6
            raise exc
    """

# Generated at 2022-06-23 22:54:39.919230
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .asm_transformer import AsmTransformer

# Generated at 2022-06-23 22:54:45.739728
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformerTest
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast

    @snippet
    def before():
        def foo():
            yield 1
            return 2

    @snippet
    def after():
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

    assert BaseNodeTransformerTest.test_transform(ReturnFromGeneratorTransformer, before, after)



# Generated at 2022-06-23 22:54:51.923582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import _ast3 as ast
    import astunparse

    # Function without generator
    node = ast.parse("""
    def fn(a):
        return 1
    """, mode='exec').body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert not transformer._tree_changed
    assert astunparse.unparse(node) == """def fn(a): return 1"""

    # Function with generator
    node = ast.parse("""
    def fn(a):
        yield 1
        return 5
    """, mode='exec').body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer._tree_changed

# Generated at 2022-06-23 22:54:52.964240
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:04.769431
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tests = [
        ('def fn(): return 5',
         'def fn(): return 5'),
        ('def fn(): yield 1; return 5',
         'def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc'),
        ('def fn(): yield 1; return 5; yield 2',
         'def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc; yield 2'),
        ('def fn(): yield 1; return 5 if True else 6',
         'def fn(): yield 1; exc = StopIteration(); exc.value = (5 if True else 6); raise exc')
    ]
    for snippet, expected in tests:
        m = ast.parse(snippet)
        assert ast.dump(m) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:55:05.905825
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:15.469038
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import CompilerTestCase, raises
    from typed_ast.ast3 import parse

    class TestCase(CompilerTestCase):
        """Test ReturnFromGeneratorTransformer."""
        TRANSFORMER = ReturnFromGeneratorTransformer

        def test_return_from_generator(self):
            """Test `return` in generator."""
            code = """
        def foo():
            yield 1
            return 2

        def bar():
            return 'q'
        """
            expected = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

        def bar():
            return 'q'
        """
            self.assert_compiled(code, expected)

    if __name__ == '__main__':
        from .base import main
        main()

# Generated at 2022-06-23 22:55:17.116021
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:55:24.624227
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import dump
    from .. import parse

    for version in [3.5, 3.6, 3.7, 3.8]:
        tree = parse(
            '''\
            def fn():
                yield 1
                return 5
            ''',
            version=version
        )
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)

        assert dump(tree) == '''\
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            ''', 'version {}'.format(version)

        tree = parse(
            '''\
            def fn():
                yield 10
                return 5
                yield 20
            ''',
            version=version
        )
        transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:34.622801
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.transform_test_helper import transform_test

    # test1
    node1 = """
        def foo():
            yield 1
            return x + 5
    """
    result1 = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = x + 5
            raise exc
    """
    transform_test(ReturnFromGeneratorTransformer, node1, result1)

    # test2
    node2 = """
        def foo():
            yield 1
            return
    """
    result2 = """
        def foo():
            yield 1
    """
    transform_test(ReturnFromGeneratorTransformer, node2, result2)

    # test3

# Generated at 2022-06-23 22:55:35.539485
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:36.442555
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tf = ReturnFromGeneratorTransformer()
    assert tf

# Generated at 2022-06-23 22:55:37.362130
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:55:45.745484
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import get_node, compare_node
    from ..serializers.ast_serializer import AstSerializer
    from .. import tree_modifiers
    
    serializer = AstSerializer()

    def get_modifier(source: str) -> tree_modifiers.TreeModifier:
        source_node = get_node(source, 3, 2)
        return ReturnFromGeneratorTransformer(source_node)

    def test(source: str, expected: str) -> None:
        node = get_node(source, 3, 2)
        modifier = get_modifier(source)
        assert modifier._find_generator_returns(node) == [
            (node.body[2], node.body[2].body[1]),  # type: ignore
        ]

        assert modifier._find_generator_return

# Generated at 2022-06-23 22:55:55.516781
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_with_return = '''def fn():
        yield 1
        return 5'''

    function_with_two_returns = '''def fn():
        yield 1
        return 5
        yield 2
        return 6'''

    function_with_two_nested_returns = '''def fn():
        yield 1
        if True:
            yield 2
            return 5
        yield 3
        if True:
            yield 4
            return 7
        yield 5
        return 7'''

    function_with_two_nested_returns_in_else = '''def fn():
        yield 1
        if True:
            yield 2
            return 5
        else:
            yield 3
            return 7
        yield 4
        return 7'''


# Generated at 2022-06-23 22:56:05.449054
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import TransformerTestCase

    class Test(TransformerTestCase):
        transformer = ReturnFromGeneratorTransformer
        filename = __file__

        def test_simple(self):
            self.assertCode("""
            def test():
                return 1
            """, """
            def test():
                exc = StopIteration()
                exc.value = 1
                raise exc
            """, tree_changed=True)

        def test_sibling(self):
            self.assertCode("""
            def test():
                if True:
                    return 1
                return 2
            """, """
            def test():
                if True:
                    exc = StopIteration()
                    exc.value = 1
                    raise exc
                exc = StopIteration()
                exc.value = 2
                raise exc
            """, tree_changed=True)

# Generated at 2022-06-23 22:56:11.900515
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import transform_to_block, transform_from_block, transform_from_source, assert_source

    @transform_to_block
    @transform_from_block
    @transform_from_source
    @assert_source
    def test_1():
        def generator_fn():
            yield 1
            return 'returned'
        return generator_fn

    @transform_to_block
    @transform_from_block
    @transform_from_source
    @assert_source
    def test_2():
        def generator_fn():
            yield 1
            x = 3
            return x
        return generator_fn

    @assert_source
    @transform_to_block
    @transform_from_block
    @transform_from_source
    def test_3():
        def normal_fn():
            return

# Generated at 2022-06-23 22:56:18.045249
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert (
        ast.parse(ReturnFromGeneratorTransformer("""
            def fn():
                yield 1
                return 5
        """).apply()[0]).body[0]
    ) == ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """).body[0]


# Generated at 2022-06-23 22:56:20.692747
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-23 22:56:28.060072
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.ast_parser import ast_parse

    # Initializing module_node
    module_node = ast_parse("""def fn():
    yield 1
    return 5""")

    # Calling method under test
    ReturnFromGeneratorTransformer().visit_FunctionDef(module_node.body[0])

    # Verifying the result
    expected_module_str = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    assert astor.to_source(module_node) == expected_module_str



# Generated at 2022-06-23 22:56:37.213467
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typing import Generator

    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """).body[0]
    node = transformer.visit(node)
    assert isinstance(node.body[1], ast.Assign)
    assert isinstance(node.body[-1], ast.Raise)
    assert node.body[1].value.s == 'StopIteration'
    assert node.body[1].targets[0].id == 'exc'
    assert node.body[-1].exc.value == transformer._local_names['exc'].copy()
    assert node.body[-1].cause is None



# Generated at 2022-06-23 22:56:47.935339
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Mock(object):
        def __init__(self, fn: ast.FunctionDef):
            self._fn = fn
            self._tree_changed = False
            self._visited_nodes = []

        def _find_generator_returns(self, node):
            if node == self._fn:
                return [
                    (self._fn, ast.Return(value=ast.Num(n=3) if node == self._fn else ast.Num(n=4))),
                    (self._fn, ast.Return(value=ast.Num(n=5)))
                ]
            else:
                return []

        def generic_visit(self, node):
            self._visited_nodes.append(node)
            return node


# Generated at 2022-06-23 22:56:55.916768
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse("""
        def foo(a):
            yield 1
            return a
        def bar():
            yield 1
            yield 2
        def baz():
            return 1
    """)
    expected = ast.parse("""
        def foo(a):
            yield 1
            exc = StopIteration()
            exc.value = a
            raise exc
        def bar():
            yield 1
            yield 2
        def baz():
            return 1
    """)
    transformer = ReturnFromGeneratorTransformer()
    new_module = transformer.visit(module)
    assert ast.dump(new_module) == ast.dump(expected)

# Generated at 2022-06-23 22:56:57.151600
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = ReturnFromGeneratorTransformer()
    assert r is not None

# Generated at 2022-06-23 22:56:59.378880
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse('def fn(): yield 1; return 5'))
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:57:08.222122
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    from astor.code_gen import to_source

    class _ReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node: ast3.FunctionDef) -> List[Tuple[ast3.stmt, ast3.Return]]:
            return super()._find_generator_returns(node)

        def _replace_return(self, parent: ast3.stmt, return_: ast3.Return) -> None:
            return super()._replace_return(parent, return_)

    snippet1 = '''
        def fn():
            yield 1
            return 5
    '''
    snippet2 = '''
        def fn():
            yield 1
            return
    '''

# Generated at 2022-06-23 22:57:18.152811
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    sample = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')

    expected = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(sample)
    transformer.generic_visit(res)
    assert(ast.dump(res) == ast.dump(expected))

    sample = ast.parse('''
        def fn():
            yield 1
            yield 2
    ''')

    expected = ast.parse('''
        def fn():
            yield 1
            yield 2
    ''')

    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(sample)


# Generated at 2022-06-23 22:57:18.766586
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:29.553224
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    trans = ReturnFromGeneratorTransformer()
    # Test 'return' does not exist
    node = ast.parse('def fn(): pass')
    trans.visit(node)
    assert ast.dump(node) == "Module(body=[FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"
    # Test function have a 'return' and inside no 'yield'
    node = ast.parse('def fn(): return 1')
    trans.visit(node)

# Generated at 2022-06-23 22:57:31.678574
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t1 = ReturnFromGeneratorTransformer()
    assert isinstance(t1, BaseNodeTransformer)
    assert isinstance(t1, ast.NodeTransformer)

# Generated at 2022-06-23 22:57:34.066634
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    _ = transformer


# Generated at 2022-06-23 22:57:35.625507
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer((3, 2)).target == (3, 2)

# Generated at 2022-06-23 22:57:44.729782
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_return_in_generator():
        yield 1
        return 5
    node_return_in_generator = ast.parse(inspect.getsource(test_return_in_generator))
    ReturnFromGeneratorTransformer().visit(node_return_in_generator)

    def test_no_return():
        yield 1
    node_no_return = ast.parse(inspect.getsource(test_no_return))
    ReturnFromGeneratorTransformer().visit(node_no_return)

    def test_no_yield():
        return 5
    node_no_yield = ast.parse(inspect.getsource(test_no_yield))
    ReturnFromGeneratorTransformer().visit(node_no_yield)

# Generated at 2022-06-23 22:57:55.668276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from .generators import GeneratorTransformer
    from .types import TypeInferenceTransformer
    from .namespace import NamespaceTransformer

    transform_functions = [
        TypeInferenceTransformer.visit_FunctionDef,
        GeneratorTransformer.visit_FunctionDef,
        ReturnFromGeneratorTransformer.visit_FunctionDef,
        NamespaceTransformer.visit_FunctionDef
    ]

    code = '''
    def fn():
        yield 1
        return 5
    '''

    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

    BaseNodeTransformer.tree = ast.parse(code)

# Generated at 2022-06-23 22:58:01.089517
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    transformer = ReturnFromGeneratorTransformer()

    node = ast.parse('''
        def foo():
            yield 1
            return 2
    ''').body[0]

    transformer.visit(node)

    assert ast.dump(node) == '''
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
'''



# Generated at 2022-06-23 22:58:09.271175
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    from io import StringIO
    import sys

    class ReturnFromGeneratorTransformerTest(unittest.TestCase):
        def assertPrints(self, src, expected):
            old_stdout = sys.stdout
            try:
                out = StringIO()
                sys.stdout = out

                tree = ast.parse(src)
                ReturnFromGeneratorTransformer().visit(tree)
                compiled = compile(tree, "<test>", "exec")

                eval(compiled)
                output = out.getvalue().strip()
            finally:
                sys.stdout = old_stdout

            self.assertEqual(output, expected)


# Generated at 2022-06-23 22:58:18.362418
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..transpile import transpile
    from ast import parse, NameConstant

    source = """
    def foo(x):
        y = yield 2
        if x == 'bar':
            return 2
        return 5
    """

    t = transpile(source, 3.2)
    expected = """
    def foo(x):
        exc = StopIteration()
        exc.value = 2
        raise exc
        y = yield 2
        if x == 'bar':
            exc = StopIteration()
            exc.value = 2
            raise exc
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert t == expected


# Generated at 2022-06-23 22:58:26.709283
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    node = ast.parse(
        'def fn1():\n'
        '    yield 1\n'
        '    return 5\n'
    ).body[0]
    transformer = ReturnFromGeneratorTransformer()
    # Exercise & Verify
    actual = transformer.visit(node)