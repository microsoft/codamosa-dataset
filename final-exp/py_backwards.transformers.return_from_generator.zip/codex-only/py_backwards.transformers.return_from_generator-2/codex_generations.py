

# Generated at 2022-06-23 22:48:23.561099
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.target == (3,2)



# Generated at 2022-06-23 22:48:29.832990
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    code = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    return_transformer = ReturnFromGeneratorTransformer()
    return_transformer.visit(tree)
    actual = astor.to_source(tree)
    print(actual)
    assert actual == expected

# Generated at 2022-06-23 22:48:37.309179
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).visit_FunctionDef(
        ast.parse('def fn(): yield 1', mode='exec').body[0]
    ) == ast.parse('def fn(): yield 1', mode='exec').body[0]

    expected = ast.parse(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """,
        mode='exec'
    ).body[0]

    expected.body[-1].value.args[0].value.value = 5

    actual = ReturnFromGeneratorTransformer(None).visit_FunctionDef(
        ast.parse(
            """
            def fn():
                yield 1
                return 5
            """,
            mode='exec'
        ).body[0]
    )


# Generated at 2022-06-23 22:48:38.219517
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(0).target == (3, 2)


# Generated at 2022-06-23 22:48:39.142188
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:40.102734
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass



# Generated at 2022-06-23 22:48:48.266894
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Input
    fun_code = """
    def fn():
        yield 1
        return 5
    """

    # Expected output
    expected_fun_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    # Parse code string to AST
    tree = ast.parse(fun_code)

    # Optimize the tree
    ReturnFromGeneratorTransformer().visit(tree)

    # Compare the output with expected output
    assert astor.to_source(tree) == expected_fun_code

# Generated at 2022-06-23 22:48:57.744591
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test():
        yield 1
        return 5

    node = ast.parse(test.__code__.co_code, mode='exec')
    assert isinstance(node.body[0], ast.FunctionDef)
    node.body[0].body.extend([
        ast.Expr(ast.Yield(ast.Constant(1))),
        ast.Return(ast.Constant(5)),
    ])

    node = ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-23 22:49:07.926182
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .generic_nodes_transformer import GenericNodesTransformer
    from .name_resolver import NameResolver
    from .source_importer import SourceImporter
    from .arguments_transformer import ArgumentsTransformer
    
    source = '''def fn():
    yield 1
    return 4
'''
    return_transformer = ReturnFromGeneratorTransformer()
    source_importer = SourceImporter()
    name_resolver = NameResolver()
    generic_nodes_transformer = GenericNodesTransformer()
    ast_tree = ast.parse(source)
    ast_tree = return_transformer.visit(ast_tree)
    ast_tree = source_importer.visit(ast_tree)
    ast_tree = name_resolver.visit(ast_tree)
    ast_tree

# Generated at 2022-06-23 22:49:16.207320
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def fn():
        yield 1
        return 5

    assert ReturnFromGeneratorTransformer().visit(fn.get_ast()) == fn.get_ast()

    @snippet
    def fn():
        yield 1
        yield 2

    assert ReturnFromGeneratorTransformer().visit(fn.get_ast()) == fn.get_ast()

    @snippet
    def fn():
        yield 1
        return 5

    new_fn = ReturnFromGeneratorTransformer().visit(fn.get_ast())
    assert new_fn != fn

    @snippet
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    assert new_fn == fn.get_ast()

# Generated at 2022-06-23 22:49:26.209219
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import transform, check

    def fn():
        yield 1
        return 5

    def fn_out():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    tree = ast.parse(fn.__code__)
    tree = transform(ReturnFromGeneratorTransformer, tree)
    check(tree, fn_out)

    def fn2(a):
        yield 1
        if a:
            return 5
        else:
            return 6

    def fn2_out(a):
        yield 1
        if a:
            exc = StopIteration()
            exc.value = 5
            raise exc
        else:
            exc = StopIteration()
            exc.value = 6
            raise exc

    tree = ast.parse(fn2.__code__)

# Generated at 2022-06-23 22:49:27.704173
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:29.210280
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:49:39.832770
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast, ast_to_source
    fn1 = '''
        def fn(x):
            yield x
            return x
    '''
    expected_src1 = '''
        def fn(x):
            yield x
            exc = StopIteration()
            exc.value = x
            raise exc
    '''

    ast_ = source_to_ast(fn1)
    transformer = ReturnFromGeneratorTransformer()
    ast_ = transformer.visit(ast_)

    assert ast_to_source(ast_) == expected_src1


# Generated at 2022-06-23 22:49:43.596622
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    node = BaseNodeTransformer.parse('''
        def inner_fn():
            yield 1
            return 5
    ''')
    assert node.body[0].body[1].value.id == 'StopIteration'

# Generated at 2022-06-23 22:49:46.748872
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    toplevel_ast = ast.Module()
    toplevel_ast.body = []


# Generated at 2022-06-23 22:49:47.755097
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:58.822473
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...tests.lib.transforms import TransformTestCase
    from ..generator_return_transformer import \
        GeneratorReturnTransformer, GeneratorReturnStatementTransformer
    from ..yield_to_send_transformer import YieldToSendTransformer

    class Test(TransformTestCase):
        target = ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:50:08.722080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils.source import _remove_comments_and_docstrings
    from ..utils.lint import check_ast_eq
    from . import add_lineno_and_col_to_ast_nodes

    class_code = """
    class C:
        def fn(self):
            yield 1
            return 5
    """
    expected = """
    class C:
        def fn(self):
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    tree = ast.parse(_remove_comments_and_docstrings(class_code))
    tree = ReturnFromGeneratorTransformer().visit(tree)
    check_ast_eq(ast.parse(expected), tree)

# Generated at 2022-06-23 22:50:10.815715
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print(ReturnFromGeneratorTransformer.__name__)
    test_input = """def fn():
    yield 1
    return 5"""

# Generated at 2022-06-23 22:50:17.206684
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    def_fn = ast.parse("def fn():\n    yield\n    return 5")
    def_fn_transformed = transformer.visit(def_fn)

    assert def_fn_transformed.body[0].body[0].value.id == "StopIteration"
    assert def_fn_transformed.body[0].body[1].value.elts[0].value.id == "StopIteration"
    assert def_fn_transformed.body[0].body[2].value.value == 5
    assert def_fn_transformed.body[0].body[3].value.id == "StopIteration"

# Generated at 2022-06-23 22:50:22.360452
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # No changes in non-generator functions
    for source in [
        'def f():\n    pass',
        'def g():\n    x = 1\n    return x',
        'def h():\n    x = 1\n    raise x',
    ]:
        node = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)
        print(node)
        assert not transformer.tree_changed

    # No changes if there are no `return`s
    for source in [
        'def f():\n    yield 1\n    yield 2',
        'def f():\n    yield from (1, 2)',
    ]:
        node = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)

# Generated at 2022-06-23 22:50:29.884747
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(
        textwrap.dedent("""
        def fn():
            yield 1
            return 5
        """),
        mode='exec'
    )
    transformer = ReturnFromGeneratorTransformer()
    expected = ast.parse(
        textwrap.dedent("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        """),
        mode='exec'
    )
    assert transformer.visit(node).body[0] == expected.body[0]


# Generated at 2022-06-23 22:50:39.085175
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transpile import Transpiler
    from .simplify_branching import SimplifyBranchingTransformer
    from .extract_locals import ExtractLocalsTransformer
    from .extract_globals import ExtractGlobalsTransformer
    from .assign_items_to_locals import AssignItemsToLocalsTransformer

    tree = ast.parse('''
    def wrapper():
        yield 1

        def mt():
            yield 2
            yield 3
            return 5

        x = (yield mt())
        return x

    x = wrapper()
    while True:
        try:
            print(next(x))
        except StopIteration as e:
            print(e.value)
            break
    ''')  # noqa E501
    t = Transpiler()


# Generated at 2022-06-23 22:50:40.270461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse

# Generated at 2022-06-23 22:50:49.087006
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ...tests.transforms.utils import do_transformation_test
    from ...parsers import PythonParser
    from ..utils.snippet import Snippet
    from ..utils.source_code import split_lines

    code = Snippet(
        """
        def fn():
            yield 1
            return 5
        """
    ).deindent()
    ast_module = do_transformation_test(ReturnFromGeneratorTransformer, code)

    code_changed = PythonParser().module_ast_to_str(ast_module)
    code_changed = code_changed.replace('\t', '    ')
    code_changed = split_lines(code_changed)
    code_changed = [x.replace('\t', '') for x in code_changed]


# Generated at 2022-06-23 22:50:54.132535
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    source = ast.parse("""
        def fn():
            yield 1
            return 5
    """)

    expected_source = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    transformer.visit(source)

    assert ast.dump(source) == ast.dump(expected_source)

# Generated at 2022-06-23 22:51:00.351176
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse  # type: ignore
    from astunparse import unparse  # type: ignore
    from ..utils.exception import TransformError


# Generated at 2022-06-23 22:51:02.582601
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    t.visit("""
        def fn():
            yield 1
            return 5
    """)

# Generated at 2022-06-23 22:51:11.664287
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transform
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:22.157030
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockNode(object):
        body = None
        def __init__(self, body):
            self.body = body

    def mock_return(value):
        node = MockNode('return')
        node.value = value
        return node

    def mock_yield():
        node = MockNode('yield')
        return node

    def mock_yield_from():
        node = MockNode('yield from')
        return node
    # Test function with empty body
    node = MockNode([])
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(node)
    assert transformer._tree_changed == False

    # Test function with no yield and return
    node = MockNode([mock_return(1)])
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_Function

# Generated at 2022-06-23 22:51:23.678165
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), ast.NodeTransformer)

# Generated at 2022-06-23 22:51:24.275328
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-23 22:51:24.850887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:34.742783
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    generator_returns = ReturnFromGeneratorTransformer()._find_generator_returns(
            ast.parse('''
            def fn():
                yield 1
                return 5
            ''').body[0]
    )
    assert len(generator_returns) == 1

    generator_returns = ReturnFromGeneratorTransformer()._find_generator_returns(
            ast.parse('''
            def fn():
                if True:
                    yield 1
                return 5
            ''').body[0]
    )
    assert len(generator_returns) == 1

    generator_returns = ReturnFromGeneratorTransformer()._find_generator_returns(
            ast.parse('''
            def fn():
                pass
            ''').body[0]
    )

# Generated at 2022-06-23 22:51:44.853015
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..unparse import Unparser
    from ..utils.ast_helpers import get_source

    code = '''
    def gen():
        yield

    def gen2():
        yield
        return 5

    def gen3():
        def nested():
            yield
            return 5
        yield
        yield from nested()
    '''
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert get_source(tree) == '''
    def gen():
        yield
    def gen2():
        yield
        exc = StopIteration()
        exc.value = 5
        raise exc
    def gen3():
        def nested():
            yield
            exc = StopIteration()
            exc.value = 5
            raise exc
        yield
        yield from nested()
    '''



# Generated at 2022-06-23 22:51:49.991283
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(
        """
        def foo():
            yield 1
            return 5
        """
    )
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True
    assert len(transformer._find_generator_returns(node.body[0])) == 1

# Generated at 2022-06-23 22:51:59.373221
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Example(object):
        def __repr__(self):
            return "Example"

        def __eq__(self, other):
            return isinstance(other, Example)

    code = """
        def foo():
            yield 1
            return Example()
    """
    tree = ast.parse(code)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    to_check = [(new_tree, x) for x in new_tree.body]  # type: ignore

    result = True

    expected = [
        Example(),
        ast.Raise(
            exc=ast.Name(
                id='exc',
                ctx=ast.Load()
            ),
            cause=None
        )
    ]

    while to_check:
        parent, current = to_check.pop()

       

# Generated at 2022-06-23 22:52:05.847204
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent

    from .tools import assert_node

    source = dedent('''\
        def f():
            if x == y:
                return x

            yield x
            return y
    ''')
    expected = dedent('''\
        def f():
            if x == y:
                return x

            yield x
            exc = StopIteration()
            exc.value = y
            raise exc
    ''')

    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)

    assert_node(tree, expected)


# Generated at 2022-06-23 22:52:16.192800
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import compile_to_untyped_ast, patch
    from typed_ast import ast3 as ast
    patch(ReturnFromGeneratorTransformer)

    src = """
    def fn1():
        yield 1
        return 5

    def fn2():
        yield 1
        return

    def fn3():
        yield 1
        raise ValueError()
    """

    expected = """
    def fn1():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    def fn2():
        yield 1
        return
    
    def fn3():
        yield 1
        raise ValueError()
    """

    ast_module = compile_to_untyped_ast(src)
    ReturnFromGeneratorTransformer().visit(ast_module)

# Generated at 2022-06-23 22:52:20.424460
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import get_test_input_output
    from ..checker import check_program
    test_name = 'test_return_from_generator'
    test_input, test_output = get_test_input_output(test_name)
    module, output_lines = check_program(test_input, disabling_transformer_list=[ReturnFromGeneratorTransformer])
    assert ''.join(output_lines) == test_output



# Generated at 2022-06-23 22:52:22.551168
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:24.083560
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer("") is not None


# Generated at 2022-06-23 22:52:29.913850
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def foo():
        yield 1
        return 2
    """
    expected = """
    def foo():
        yield 1
        exc = StopIteration()  # type: ignore
        exc.value = 2
        raise exc  # type: ignore
    """
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    actual = astunparse.unparse(tree)
    assert expected == actual

# Generated at 2022-06-23 22:52:37.416573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(code, expected_code):
        node = ast.parse(code)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)
        actual_code = compiler.ast_to_source(node)
        assert actual_code == expected_code

    code = \
        '''
        def f():
            yield 1
            return 5
        '''
    expected_code = \
        '''
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    test(code, expected_code)

# Generated at 2022-06-23 22:52:42.933470
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_code = """
    def fn():
        yield 1
        return 5
    """
    result = compile(test_code, "snippet", mode="exec").co_code
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_code = compile(expected, "snippet", mode="exec").co_code
    assert result == expected_code

# Generated at 2022-06-23 22:52:46.735321
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # snippet

    class GeneratorTest:
        def fn(self):
            yield 1
            return 5

    assert GeneratorTest().fn().__next__() == 1
    assert GeneratorTest().fn().__next__() == 5

# Generated at 2022-06-23 22:52:48.018749
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer().target

# Generated at 2022-06-23 22:52:52.175874
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    example = """
        def x():
            yield 1
            return 2
    """
    expected = """
        def x():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    assert ReturnFromGeneratorTransformer().transform(example) == expected

# Generated at 2022-06-23 22:52:58.531499
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    target = ast.parse("""
    def fn():
        yield 1
        return None
    def fn2():
        yield 2
        return 2
    def fn3():
        yield 3
        return None
        yield 4
        return None
    """)
    out = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = None
        raise exc
    def fn2():
        yield 2
        exc = StopIteration()
        exc.value = 2
        raise exc
    def fn3():
        yield 3
        exc = StopIteration()
        exc.value = None
        raise exc
        yield 4
        exc = StopIteration()
        exc.value = None
        raise exc
    """)
    t = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:00.484816
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).target == (3, 2)


# Generated at 2022-06-23 22:53:06.840551
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def foo():\n'
                     '  yield 1\n'
                     '  return 5')
    expected_node = ast.parse('def foo():\n'
                              '  yield 1\n'
                              '  exc = StopIteration()\n'
                              '  exc.value = 5\n'
                              '  raise exc')
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected_node)

# Generated at 2022-06-23 22:53:11.576870
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn_example = """
        def fn():
            yield 1
            return 5
    """
    fn_expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    fn = ast.parse(fn_example)
    rfg = ReturnFromGeneratorTransformer()
    assert ast.dump(rfg.visit(fn)) == ast.dump(ast.parse(fn_expected))



# Generated at 2022-06-23 22:53:12.374237
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:20.834819
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    actual_code = """\
        def fn():
            yield 1
            return 5
        """
    expected_code = """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    actual_code = ast.parse(actual_code)
    expected_code = ast.parse(expected_code)
    transformer = ReturnFromGeneratorTransformer()
    actual_code = transformer.visit(actual_code)
    assert ast.dump(actual_code, annotate_fields=False) == ast.dump(expected_code, annotate_fields=False)

# Generated at 2022-06-23 22:53:25.499110
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    src = """
    def fn():
        yield 1
        return 2
    """
    expected = """
    def fn():
        yield 1
        if 1:
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    tree = ast.parse(src)
    transformer.visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:53:31.183761
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def example():
        def fn():
            yield 1
            return 5

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(example())
    ReturnFromGeneratorTransformer().visit(tree)
    assert expected == astor.to_source(tree)

# Generated at 2022-06-23 22:53:32.159510
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
	assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:40.884005
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .string import StringTransformer
    from .py_factories import make_function_def

    def test_str_fn(fn_str):
        node = StringTransformer.run(fn_str)
        node = ReturnFromGeneratorTransformer.run(node)  # type: ignore
        node = StringTransformer.run(node)
        return node

    def make_return_fn(return_value):
        fn = make_function_def(['yield 1'], return_value=return_value)
        return test_str_fn(fn)


# Generated at 2022-06-23 22:53:41.948475
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:50.661647
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:54.498621
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def example_function():
        yield 1
        yield 2
        return 3

    transformer = ReturnFromGeneratorTransformer()  # type: ignore
    transformer.visit(ast.parse(example_function.__code__))
    # assert transformer._tree_changed is True

# Generated at 2022-06-23 22:54:00.222087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def gen():
        yield
        return 5
    """

    expected = """
    def gen():
        yield
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    output = ast.dump(tree, Annotate.fields)
    assert output == expected



# Generated at 2022-06-23 22:54:01.505571
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

__transformer__ = ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:08.021435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source
    from ..visitor import TreeVisitor
    from .unwrap_yield_from import UnwrapYieldFromTransformer

    tree = source(r'''
        def generator():
            yield 1
            yield 2
            yield 3
            return 4
    ''')

    visitor = TreeVisitor()
    visitor.recursive_visit(tree, [
        UnwrapYieldFromTransformer,
        ReturnFromGeneratorTransformer,
    ])

    assert source(r'''
        def generator():
            yield 1
            yield 2
            yield 3
            exc = StopIteration()
            exc.value = 4
            raise exc
    ''') == tree



# Generated at 2022-06-23 22:54:08.866420
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-23 22:54:12.962681
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import _test_ast

    source = """
    def fn(a, b, c):
        yield 1
        return 5
    """
    tree = ast.parse(source)
    node = tree.body[0]  # type: ast.FunctionDef

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert transformer._tree_changed

    expected = """
    def fn(a, b, c):
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    _test_ast.compare_source(expected, tree)

# Generated at 2022-06-23 22:54:18.347548
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5
    t = ReturnFromGeneratorTransformer()
    result = t.visit_FunctionDef(  # type: ignore
        ast.parse(inspect.getsource(fn)).body[0])

# Generated at 2022-06-23 22:54:23.835293
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = ast.parse("""
    def fn():
        import sys
        yield 1
        print('fooo')
        yield 2
        return 5
    """)
    b = ast.parse("""
    def fn():
        import sys
        yield 1
        print('fooo')
        yield 2
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    m = ReturnFromGeneratorTransformer()
    assert b.body[0] == m.visit(a.body[0])


# Generated at 2022-06-23 22:54:27.826550
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = ReturnFromGeneratorTransformer()
    node = ast.parse("""
        def test(a):
            print(a)
            yield a
            return 5
        """)
    r.visit(node)
    return node.body[0].body

# Generated at 2022-06-23 22:54:37.606994
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .tests_common import run_transformer_test
    from ..utils.common import snippet_to_ast

    # Two return statements in one function
    run_transformer_test(
        ReturnFromGeneratorTransformer,
        {'node': snippet_to_ast(generator_returns_two_return),
         'wanted_node': snippet_to_ast(generator_returns_two_return_result)},
    )

    # Return statement in nested function
    run_transformer_test(
        ReturnFromGeneratorTransformer,
        {'node': snippet_to_ast(
            nested_generator_returns_two_return),
         'wanted_node': snippet_to_ast(
             nested_generator_returns_two_return_result)},
    )


generator_returns_

# Generated at 2022-06-23 22:54:39.581599
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:54:45.369706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    tree = ast.parse('def fn():\n'
                     '    yield 1\n'
                     '    print(x)\n'
                     '    return 5')

    tree.body[0].body[1].value.args[0].values[0].value = 2

    transformer = ReturnFromGeneratorTransformer(tree)
    tree = transformer.visit(tree)
    assert transformer.tree_changed

    # syntax check
    compile(tree, filename='<ast>', mode='exec')



# Generated at 2022-06-23 22:54:47.062372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(fn):
        tree = ast.parse(fn)
        ReturnFromGeneratorTransformer().visit(tree)
        return compile(tree, '<test>', 'exec')

    # Empty function

# Generated at 2022-06-23 22:54:50.085929
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Tests `ReturnFromGeneratorTransformer` constructor.
    """
    _ = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:54:50.744228
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:52.141501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:03.918050
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer"""

# Generated at 2022-06-23 22:55:06.726087
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def return_from_generator_transformer():
        return ReturnFromGeneratorTransformer()

    assert_that(return_from_generator_transformer, instance_of(ReturnFromGeneratorTransformer))


# Generated at 2022-06-23 22:55:12.025094
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .test_string_transformer import transform_and_compare
    transform_and_compare(
        """
        def fn():
            yield 1
            return 5
        """,
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

# Generated at 2022-06-23 22:55:20.641541
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def run_test(input, expected_output):
        input_module = ast.parse(input)
        transformer = ReturnFromGeneratorTransformer()
        transformed_tree = transformer.visit(input_module)
        transformed_tree_source = compile(transformed_tree, '<test>', 'exec')
        namespace = {}
        python_version = sys.version_info
        if python_version[0] == 3 and python_version[1] < 8:
            exec(transformed_tree_source, namespace)
        else:
            exec(transformed_tree_source, namespace)
        assert namespace['fn']() == expected_output


# Generated at 2022-06-23 22:55:23.678404
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import transform
    from ..utils.test_fixtures import basic_generator, basic_generator_returns
    transform.assert_transformation(
        ReturnFromGeneratorTransformer, basic_generator(), basic_generator_returns())



# Generated at 2022-06-23 22:55:29.908581
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import parse_node
    from .base import NodeTransformerTestCase

    source = """
    def generator():
        yield 1
        return 5
    """
    expected = """
    def generator():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    test = NodeTransformerTestCase(ReturnFromGeneratorTransformer())
    test.test(source, parse_node(expected))

# Generated at 2022-06-23 22:55:30.525889
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:35.408979
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert(ReturnFromGeneratorTransformer().visit(ast.parse(source)).body[0]) == ast.parse(expected).body[0]


# Generated at 2022-06-23 22:55:35.975639
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:44.450124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equals
    from ..Cython.Test.snippets import return_from_generator as snippet
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (3, 0)

        def _clean_node(self, node):
            from ..utils.test_utils import clean_node
            return clean_node(node)

    x = TestTransformer()

    node = x._parse(snippet.code)
    node = x._clean_node(node)
    node = x.visit(node)
    node = x._clean_node(node)
    x.finalize()

    expected = x._parse(snippet.expected)
    expected = x._clean_node(expected)
    assert_node_equals

# Generated at 2022-06-23 22:55:44.908063
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:53.881338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import dump, unparse
    import ast
    from typed_ast import ast3
    from .base import BaseNodeTransformer_visit_FunctionDef
    import astunparse
    from ..utils.helper import typed_astunparse
    from ..utils.helper import assert_code_equal
    from .base import BaseNodeTransformer_visit_FunctionDef

    # fmt: off
    class MyTrans(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            self._tree_changed = True
            return node
    # fmt: on


# Generated at 2022-06-23 22:55:54.889434
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:56.209933
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-23 22:56:06.093776
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""def fn():\n    yield 1\n    return 5""")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:56:08.296505
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_transformer import test_transformer
    from . import ReturnFromGeneratorTransformer as TestedClass

    test_transformer(TestedClass)

# Generated at 2022-06-23 22:56:11.053195
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)


# Generated at 2022-06-23 22:56:14.142543
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transformer import Transformer
    from ..utils.source import source_to_ast, code_equal
    from ..utils.node import print_node
    from .base import BaseNodeTransformer


# Generated at 2022-06-23 22:56:19.721762
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_transformed_code

    code = """
    def fn():
        print('aa')
        return 3
    """
    expected_code = """
    def fn():
        print('aa')
        exc = StopIteration()
        exc.value = 3
        raise exc
    """
    assert_transformed_code(
        ReturnFromGeneratorTransformer,
        code,
        expected_code
    )

# Generated at 2022-06-23 22:56:21.414144
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rft = ReturnFromGeneratorTransformer()
    assert rft is not None


# Generated at 2022-06-23 22:56:29.392342
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def foo():
        yield 1
        return 'a'
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)

    assert ast.dump(tree) == "Module(body=[FunctionDef(args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), name='foo', body=[Yield(value=Num(n=1)), Expr(value=Call(func=Name(id='return_from_generator', ctx=Load()), args=[Str(s='a')], keywords=[])), Return(value=None)], decorator_list=[], returns=None)])"



# Generated at 2022-06-23 22:56:30.441061
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-23 22:56:32.791902
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    return_from_generator_transformer.optimize()

# Generated at 2022-06-23 22:56:40.796731
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ''' Test the method visit_FunctionDef of class ReturnFromGeneratorTransformer
    '''
    from typed_ast import ast3 as ast
    from unittest_data_provider import data_provider
    from .snippets import BASE_CASE, DEFAULT_LN, FN_LN, DEFAULT_GEN_FN, RET_BODY_GEN_FN
    data = []
    data.extend(BASE_CASE)
    data.extend(DEFAULT_LN)
    data.extend(FN_LN)

# Generated at 2022-06-23 22:56:49.781957
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transform import transform

    source = '''
    def fn(x):
        yield 1
        return x + 1
    '''

    tree = transform(source, [ReturnFromGeneratorTransformer])


# Generated at 2022-06-23 22:56:59.620420
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer_test
    from .return_from_generator import ReturnFromGeneratorTransformer

    class TestTransformer(BaseNodeTransformer_test, ReturnFromGeneratorTransformer):
        pass


# Generated at 2022-06-23 22:57:08.441612
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_tree = ast.parse("""
    def fn():
        yield 1
        return 2
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)

# Generated at 2022-06-23 22:57:13.100873
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import test_utils
    from ..translators.node_transformer import all_node_transformers
    from .base import construct_source

    class_name = ReturnFromGeneratorTransformer.__name__
    all_node_transformers.append(ReturnFromGeneratorTransformer)
    test_utils.run_test(construct_source, class_name)

# Generated at 2022-06-23 22:57:13.983517
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:14.758211
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    instance = ReturnFromGeneratorTransformer()
    assert instance is not None

# Generated at 2022-06-23 22:57:21.248875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test():
        def foo():
            yield 1
            return 2
    test()

    node = ast.parse(inspect.getsource(test))
    node = ReturnFromGeneratorTransformer().visit(node)
    # Careful, the exact format may change with typed-ast version
    assert inspect.getsource(node) == 'def test() -> None:\n    def foo() -> typing.Iterator[typing.Any]:\n        yield 1\n        exc = StopIteration()\n        exc.value = 2\n        raise exc\n'

# Generated at 2022-06-23 22:57:31.311435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Simple return
    @snippet
    def source():
        def fn():
            yield 1
            return 5

    @snippet
    def expected():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    source_node = source.root
    expected_node = expected.root

    t = ReturnFromGeneratorTransformer()
    result = t.visit(source_node)

    assert result == expected_node

    # Simple return from loop
    @snippet
    def source():
        def fn():
            for i in range(10):
                yield i
            return 5

    @snippet
    def expected():
        def fn():
            for i in range(10):
                yield i
            exc = StopIteration()
            exc.value

# Generated at 2022-06-23 22:57:34.068284
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.name == "ReturnFromGeneratorTransformer"

# Generated at 2022-06-23 22:57:41.353034
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        yield 2
        return 5

    tree = ast.parse(fn.__code__)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    f = compile(tree, '', 'exec')

    g = fn()
    assert next(g) == 1
    assert next(g) == 2
    with pytest.raises(StopIteration) as exc_info:
        next(g)

    assert exc_info.value.value == 5


# Generated at 2022-06-23 22:57:43.329876
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    def fn():
        yield 1
        return 5
    transformer.visit(fn)
    pass

__transformer__ = ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:44.016148
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:57:53.691233
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:03.699802
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockNode:
        def __init__(self, body=None):
            if body is None:
                body = []
            self.body = body

    class MockReturn:
        def __init__(self, value):
            self.value = value

    class MockYield:
        pass

    class MockYieldFrom:
        pass

    rt = ReturnFromGeneratorTransformer()

    def assert_generator_returns(body, expected):
        body_node = MockNode(body=body)
        actual = rt._find_generator_returns(body_node)

        for a, e in zip(actual, expected):
            assert isinstance(a[1], MockReturn)
            assert a[1].value == e


# Generated at 2022-06-23 22:58:11.567326
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ff = """
    def fn():
        yield 1
        return 2
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    nt = ReturnFromGeneratorTransformer()
    nt.visit(ast.parse(ff))
    assert expected.strip() == astor.to_source(nt.root).strip()

    ff = """
    def fn():
        yield 1
        yield 2
    """

    nt = ReturnFromGeneratorTransformer()
    nt.visit(ast.parse(ff))
    assert ff.strip() == astor.to_source(nt.root).strip()


# Generated at 2022-06-23 22:58:12.753702
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:13.751987
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:20.051371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test"""
    assert ReturnFromGeneratorTransformer().visit_FunctionDef(
        ast.parse('def fn(): yield 1').body[0]
    ) == ast.parse('def fn(): yield 1').body[0]

# Generated at 2022-06-23 22:58:26.353754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Unit test for method _find_generator_returns of class ReturnFromGeneratorTransformer
    def test__find_generator_returns(source_code, expected_returns):
        node = ast.parse(source_code)
        transformer = ReturnFromGeneratorTransformer()
        generator_returns = transformer._find_generator_returns(node.body[0])

        for index, (parent, return_) in enumerate(generator_returns):
            assert_equals(expected_returns[index][0], line_of_source_code(source_code, return_))
            assert_equals(expected_returns[index][1], line_of_source_code(source_code, parent))
