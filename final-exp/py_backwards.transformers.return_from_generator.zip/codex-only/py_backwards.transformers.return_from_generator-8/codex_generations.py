

# Generated at 2022-06-23 22:48:31.426706
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .construct import construct_single_statement
    from .internals import BaseNodeTransformerInternals

    # type: (ast.AST) -> ast.AST
    fn = construct_single_statement('''
    def fn():
        yield 1
        return 5
    ''')
    assert isinstance(fn, ast.FunctionDef)

    # type: (ast.AST) -> ast.AST
    fn = construct_single_statement('''
    def fn():
        yield 1
        return 5
    ''', cls=ReturnFromGeneratorTransformer)
    assert isinstance(fn, ast.FunctionDef)

    internals = BaseNodeTransformerInternals(fn)
    assert len(internals.body) == 4

    assert isinstance(internals.body[0], ast.Expr)

# Generated at 2022-06-23 22:48:41.237642
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_code_1 = inspect.cleandoc("""
    def fn():
        yield 1
        return 5
    """)
    target_code_1 = inspect.cleandoc("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    test_node_1 = ast.parse(test_code_1)
    target_node_1 = ast.parse(target_code_1)

    ReturnFromGeneratorTransformer().visit(test_node_1)
    assert ast.dump(test_node_1) == ast.dump(target_node_1)

    test_code_2 = inspect.cleandoc("""
    def fn():
        yield 1
    """)

# Generated at 2022-06-23 22:48:52.287068
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Generate AST
    import astor
    input_string = """
    def fn():
        yield 1
        return 5

    def fn2():
        yield 1
        return

    def fn3():
        yield 1
        return 3
        yield 5

    def fn4():
        yield 1
        yield 2
        return 3
    """

    node = ast.parse(input_string)  # Generate AST

    # Transform the generated AST
    ReturnFromGeneratorTransformer().visit(node)

    # Compare the generated AST with expected AST

# Generated at 2022-06-23 22:48:56.575273
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfg = ReturnFromGeneratorTransformer()

    assert rfg.target == (3, 2)
    body = ast.parse('def fn():\n    yield 1\n    return 5').body
    assert [ast.Return] == list(map(type, rfg._find_generator_returns(body[0])))  # type: ignore

# Generated at 2022-06-23 22:48:58.443703
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:01.037257
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_From_Generator_Transformer = ReturnFromGeneratorTransformer
    with pytest.raises(TypeError):
        return_From_Generator_Transformer()



# Generated at 2022-06-23 22:49:04.962718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def func():
        for i in range(100):
            yield i
    """)
    # Expected output
    expected = ast.parse("""
    def func():
        for i in range(100):
            yield i
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 22:49:14.473629
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TransformedTreeMatcher(BaseNodeTransformer):
        def __init__(self, tree) -> None:
            self.tree = tree

        def visit_Return(self, node: ast.Return) -> ast.Return:
            raise AssertionError

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            if node.name == 'fn':
                self.generic_visit(self.tree)  # type: ignore
            return node

    if globals().get('ast'):
        tree = globals()['ast'].parse(dedent(
            """
            def fn():
                yield 1
                return yield 2
                """
        ))

# Generated at 2022-06-23 22:49:19.074438
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import create_node_transformer_class
    transformer_class = create_node_transformer_class(ReturnFromGeneratorTransformer)


# Generated at 2022-06-23 22:49:25.995878
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...tests.lib import compile_snippet, prepare_ast_for_unittest

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_result = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = prepare_ast_for_unittest(ast.parse(code))
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    result = compile_snippet(node)

    assert result == expected_result

# Generated at 2022-06-23 22:49:31.027853
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def assert_transform(source: str, expected: str):
        """Assert that transformer works as expected."""
        assert source != expected, source
        output = ReturnFromGeneratorTransformer(source).result()
        assert expected == output, output

    assert_transform(
        """
        def fn():
            yield 1
            return 2
        def nogenerator():
            return 2
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        def nogenerator():
            return 2
        """
    )

    # Test that it doesn't break on multiple returns

# Generated at 2022-06-23 22:49:40.083259
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Checker(BaseNodeTransformer):
        def __init__(self):
            self.visited_yield = False
            self.visited_function = False
            self.visited_return = False

        def visit_Yield(self, node):
            self.visited_yield = True
            return self.generic_visit(node)

        def visit_FunctionDef(self, node):
            self.visited_function = True
            return self.generic_visit(node)

        def visit_Return(self, node):
            self.visited_return = True
            return self.generic_visit(node)


# Generated at 2022-06-23 22:49:41.158851
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:50.518803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import mypy.checker
    import mypy.nodes
    import mypy.types

    snippet = '''
    def fn():
        yield 1
        return 5
    '''
    m = ast.parse(snippet)
    name = m.body[0].name

    f = mypy.checker.FunctionContext(name, m.body[0], mypy.types.Type.none(), None, None)  # type: ignore
    # The return type of a generator function is Generator[Any, None, Any]

# Generated at 2022-06-23 22:49:52.118092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""

# Generated at 2022-06-23 22:49:56.948334
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit = lambda node: node
    transformer.visit_FunctionDef = ReturnFromGeneratorTransformer.visit_FunctionDef.__get__(transformer)
    transformer.generic_visit = lambda node: node
    return transformer


# Generated at 2022-06-23 22:50:05.706011
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    init = (
        "def fn():\n"
        "    yield 1\n"
        "    return 5"
    )

    expected = (
        "def fn():\n"
        "    yield 1\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc"
    )

    tree = ast.parse(init)  # type: ignore
    node = tree.body[0]  # type: ignore

    ReturnFromGeneratorTransformer().visit(node)
    actual = ast.dump(tree)  # type: ignore

    assert actual == expected



# Generated at 2022-06-23 22:50:08.395328
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_return_from_generator():
        def fn():
            yield 1
            return 5


# Generated at 2022-06-23 22:50:13.232908
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('def fn():\n  yield 1\n  return 5')
    tr = ReturnFromGeneratorTransformer(tree)

    actual = tr.visit(tree)
    expected = ast.parse('def fn():\n  yield 1\n  exc = StopIteration()\n'
                         '  exc.value = 5\n  raise exc', mode='exec')

    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 22:50:15.684043
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def source():
        def gen(a):
            yield a
            return 3



# Generated at 2022-06-23 22:50:17.870502
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None



# Generated at 2022-06-23 22:50:26.485598
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from asttokens import ASTTokens
    from typed_astunparse import unparse
    from io import StringIO
    from pavelib.utils.test.snippet_tester import snippet_test
    import textwrap

    def check(py_code, expected_py_code):
        expected_py_code = textwrap.dedent(expected_py_code)
        ast_tree = parse(py_code)
        ast_tokens = ASTTokens(py_code, parse=False)
        out = StringIO()
        ReturnFromGeneratorTransformer().visit(ast_tree)
        unparse(ast_tree, file=out)
        actual = textwrap.dedent(out.getvalue())
        return snippet_test(actual, expected_py_code)


# Generated at 2022-06-23 22:50:32.798813
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """\
    def fn():
        yield 1
        return 5
    """

    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(code)  # type: ignore
    new_tree = transformer.visit(tree)  # type: ignore
    assert ast.unparse(new_tree) == expected

# Generated at 2022-06-23 22:50:40.719706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Simple test, where return is not in generator
    node_str_1 = """
    def fn():
        return 5
    """
    node_ast_1 = ast.parse(node_str_1)
    node_compiled_1 = ReturnFromGeneratorTransformer().visit(node_ast_1)

# Generated at 2022-06-23 22:50:48.521670
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    code = """
    def fn():
        yield 1
        return 5
    """
    module = ast.parse(code)
    t.visit(module)
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_module = ast.parse(expected_code)
    assert ast.dump(module) == ast.dump(expected_module)

# Generated at 2022-06-23 22:50:56.997697
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    from ..utils.test_utils import assert_equal_source
    transformer = ReturnFromGeneratorTransformer()

    # Test empty function
    function_one = ast3.parse(
        dedent('''\
            def fn():
                pass
        ''')
    )
    assert_equal_source(transformer.visit(function_one),
                        dedent('''\
            def fn():
                pass
        '''))

    # Test function with no generator
    function_two = ast3.parse(
        dedent('''\
            def fn():
                return 5
        ''')
    )
    assert_equal_source(transformer.visit(function_two),
                        dedent('''\
            def fn():
                return 5
        '''))



# Generated at 2022-06-23 22:50:58.594279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == "ReturnFromGeneratorTransformer"

# Generated at 2022-06-23 22:51:00.195359
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class A:
        def __init__(self):
            pass
    assert A


# Generated at 2022-06-23 22:51:06.235777
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""
    def fn():
        yield 1
        return 5
    """)

    res = ReturnFromGeneratorTransformer().visit(node)
    res = ast.fix_missing_locations(res)

    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    assert ast.dump(res) == ast.dump(expected)


# Generated at 2022-06-23 22:51:15.957684
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformerFixture(ReturnFromGeneratorTransformer):
        pass

    return_from_generator_transformer = ReturnFromGeneratorTransformerFixture()
    return_from_generator_transformer._tree_changed = False

    return_from_generator_transformer.visit_FunctionDef(
            ast.parse('''
            def fn():
                yield 1
                if True:
                    yield 2
                    return 5
                yield 3
            ''').body[0])

    return_from_generator_transformer._tree_changed == True

    return_from_generator_transformer.visit_FunctionDef(
            ast.parse('''
            def fn():
                yield 1
                if True:
                    yield 2
                    return 5
            ''').body[0])

    return_from

# Generated at 2022-06-23 22:51:22.047129
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Code that generates expected AST
    def fn_expected():
        def fn(a):
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    # Code that generates actual AST
    def fn_actual(a):
        yield 1
        return 5

    # Generate and compare
    assert ast.dump(ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(fn_actual))), annotate_fields=False) == ast.dump(ast.parse(inspect.getsource(fn_expected)), annotate_fields=False)


# Generated at 2022-06-23 22:51:23.488666
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert(ReturnFromGeneratorTransformer.__init__() != None)


# Generated at 2022-06-23 22:51:26.465981
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    visitor = ReturnFromGeneratorTransformer()
    assert eval(visitor.visit(ast.parse("""
        def fn():
            yield 1
            return 5
        """))) == (1, 5)

# Generated at 2022-06-23 22:51:29.405543
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..run import run_all_nodes, run_all_nodes_with_changed_ast

    def foo():
        yield 1
        return 2

    run_all_nodes(foo)
    run_all_nodes_with_changed_ast(foo, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:51:34.992880
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    return_in_generator = '''
        def fn():
            yield 1
            return 5
            '''
    return_in_normal_function = '''
        def fn():
            return 1
            '''
    return_with_yield_from = '''
        def foo():
            yield from [1,2,3]
            return 1
            '''
    assert transformer.visit(ast.parse(return_in_generator)).body[0] == \
        transformer.visit(ast.parse(return_with_yield_from)).body[0]
    assert transformer.visit(ast.parse(return_in_normal_function)).body[0] == \
        ast.parse(return_in_normal_function).body[0]

# Generated at 2022-06-23 22:51:39.401438
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astor.code_gen import to_source
    from .generator_function import generator_function
    source = to_source(generator_function)

    compiled = ReturnFromGeneratorTransformer().visit(generator_function)
    c_source = to_source(compiled)

    assert source == c_source

# Generated at 2022-06-23 22:51:42.345421
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == "ReturnFromGeneratorTransformer"
    assert 'operator' in (ReturnFromGeneratorTransformer.__bases__)[0].__name__


# Generated at 2022-06-23 22:51:52.013036
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing.utils import assert_code_equal

    code = """\
        def gen():
            if 1 == 1:
                return 4
            else:
                yield 2
    """

    expected = """\
        def gen():
            if 1 == 1:
                exc = StopIteration()
                exc.value = 4
                raise exc
            else:
                yield 2
    """

    tree = ast.parse(code)
    trns = ReturnFromGeneratorTransformer()
    trns.visit(tree)
    assert_code_equal(compile(tree, "<test>", "exec"), expected)

    code = """\
        def gen():
            if 1 == 1:
                yield 4
            else:
                return 2
    """


# Generated at 2022-06-23 22:51:53.030409
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:51:58.779227
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # fixture
    from .snippets import return_from_generator as code
    from ..utils.fixtures import make_fixture

    # run
    class_ = ReturnFromGeneratorTransformer()
    ast_tree = make_fixture(code, kind='ast')
    class_.run(ast_tree)

    # assert

# Generated at 2022-06-23 22:51:59.873892
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:03.513654
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.testing import assert_node_equals

    node = ast.parse('def fn(): yield 1\nreturn 5')

    transformer = ReturnFromGeneratorTransformer()
    transformed_node = transformer.visit(node)  # type: ignore


# Generated at 2022-06-23 22:52:13.779236
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node_fn_def = ast.FunctionDef(
        name='fn',
        body=[
            ast.Expr(
                value=ast.Yield(
                    value=ast.Num(n=1)
                )
            ),
            ast.Return(
                value=ast.Num(n=5)
            )
        ]
    )

    returned = ReturnFromGeneratorTransformer.run_on_node(node_fn_def, ast.parse('1'))[0]


# Generated at 2022-06-23 22:52:19.962734
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from shorthand.utils.test_dict_like import DictLike
    from shorthand.utils.test_compiler import test_on_file, test_on_source

    def test(
            source: str,
            tree: ast.AST,
            expected_source: str,
            expected_tree: ast.AST
    ) -> None:
        with DictLike(locals()):
            assert test_on_source(source, ReturnFromGeneratorTransformer) == expected_source
            assert test_on_file(source, ReturnFromGeneratorTransformer) == expected_tree


# Generated at 2022-06-23 22:52:30.537273
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    example_function_node = ast.parse('def fn():\n    yield 1\n    return 5').body[0]
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(example_function_node) == ast.parse('def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc').body[0]
    example_function_node = ast.parse('def fn():\n    yield 1\n    x = 2\n    return 3').body[0]
    assert transformer.visit(example_function_node) == ast.parse('def fn():\n    yield 1\n    x = 2\n    exc = StopIteration()\n    exc.value = 3\n    raise exc').body[0]
    example_function_node = ast

# Generated at 2022-06-23 22:52:32.005068
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-23 22:52:32.751264
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:38.639773
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    yavt = ReturnFromGeneratorTransformer()
    s = """def fn():
                yield 1
                return 5"""

    # Act
    tree = ast.parse(s)
    yavt.visit(tree)
    tree = ast.fix_missing_locations(tree)

    # Assert
    compiled = compile(tree, '<test>', mode='exec')
    fn = {}
    exec(compiled, None, fn)
    assert fn['fn']() == (1, 5)

# Generated at 2022-06-23 22:52:39.220180
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:40.428571
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-23 22:52:44.472206
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node

    class TestClass(object):
        def test_case(self):
            def fn():
                yield 1
                return 5
            return fn()

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_node(ReturnFromGeneratorTransformer, expected, TestClass)



# Generated at 2022-06-23 22:52:54.350287
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import tree, compile
    from ..utils.source import source

    # Tests all the cases described in the class docstring

# Generated at 2022-06-23 22:53:04.167627
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def test_yield(a):
            yield a
            if True:
                return

        def test_yield_value(a):
            yield a
            if True:
                return a
        """
    node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(node)

    expected = """
        def test_yield(a):
            yield a
            if True:
                exc = StopIteration()
                raise exc

        def test_yield_value(a):
            yield a
            if True:
                exc = StopIteration()
                exc.value = a
                raise exc
        """
    expected = ast.parse(expected)

    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:53:04.785230
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:10.819844
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import PythonicTranspiler

    input = """
        def foo():
            yield 1
            return 2
        """
    expected_output = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """
    pt = PythonicTranspiler()
    pt.register_transformer(ReturnFromGeneratorTransformer)
    pt.register_transformer(LineNumberTransformer)
    output = pt.transpile_code(input)
    print(output)
    assert output == expected_output

# Generated at 2022-06-23 22:53:11.304047
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:17.789923
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def _check(input_str, expected_str):
        input = ast.parse(input_str)
        expected = ast.parse(expected_str)
        assert ReturnFromGeneratorTransformer().visit(input) == expected

    _check(
        """def fn():
            yield 1
            return 5""",
        """def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc"""
    )

    _check(
        """def fn():
            return 5""",
        """def fn():
            return 5"""
    )


# Generated at 2022-06-23 22:53:19.427104
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:27.757386
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from typed_ast.ast3 import parse

# Generated at 2022-06-23 22:53:33.093316
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == expected


# Generated at 2022-06-23 22:53:42.199728
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equals_ast, assert_not_equals_ast
    from .base import strip_lineno

    @snippet
    def init_ast(return_value):
        def fn():
            yield 1
            return return_value

    @snippet
    def expect_ast(ret_val):
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = ret_val
            raise exc

    assert_not_equals_ast(expect_ast(5), init_ast(5))

    assert_equals_ast(
        strip_lineno(expect_ast(5)),
        strip_lineno(ReturnFromGeneratorTransformer().visit(init_ast(5)))
    )

# Generated at 2022-06-23 22:53:45.848711
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    expected_result = "exc = StopIteration()\nec.value = return_value"
    assert return_from_generator.get_text(return_value=None) == expected_result, "Test for ReturnFromGeneratorTransformer constructor failed."


# Generated at 2022-06-23 22:53:53.696646
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def foo():\n  yield 1\n  return 2')

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert transformer._tree_changed

# Generated at 2022-06-23 22:53:58.192749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compat import get_source
    from .base import DefaultTreeTransformer

    tree = ast.parse(get_source(ReturnFromGeneratorTransformer))
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert get_source(new_tree) == get_source(ReturnFromGeneratorTransformer)



# Generated at 2022-06-23 22:53:59.535782
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)



# Generated at 2022-06-23 22:54:00.492440
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:03.961788
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""
        def test(x):
            yield x
            return 3
    """)
    transformed = ReturnFromGeneratorTransformer().visit(node)
    expected = ast.parse(return_from_generator("3"))

    assert ast.dump(transformed) == ast.dump(expected)

# Generated at 2022-06-23 22:54:06.448983
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert type(ReturnFromGeneratorTransformer()).__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-23 22:54:13.783023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(
        """
        def fn():
            yield 1
            yield 2
            return 3

        def fn_ret():
            yield 1
            return 3
        """
    )
    ast.fix_missing_locations(tree)
    new_tree = transformer.visit(tree)

    assert transformer._tree_changed
    assert ast.dump(new_tree) == ast.dump(
        ast.parse(
            """
            def fn():
                yield 1
                yield 2
                exc = StopIteration()
                exc.value = 3
                raise exc

            def fn_ret():
                yield 1
                exc = StopIteration()
                exc.value = 3
                raise exc
            """
        )
    )



# Generated at 2022-06-23 22:54:19.593691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            super(TestReturnFromGeneratorTransformer, self).__init__(None)
            self._node_count = 0

        def visit_Return(self, node: ast.Return) -> None:
            self._node_count += 1


# Generated at 2022-06-23 22:54:28.102858
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def get_returns():
        yield 1, 2
        return 1
    class C:
        def get_returns():
            yield 1, 2
            return 1
        @staticmethod
        def static_get_returns():
            yield 1, 2
            return 1
    C().get_returns()
    C.get_returns()
    C().static_get_returns()
    get_returns()
    C.static_get_returns()
    C.get_returns()
    ReturnFromGeneratorTransformer()
test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:54:33.888753
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """

    desired = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)  # type: ignore

    assert(ast.dump(tree) == desired)

# Generated at 2022-06-23 22:54:43.096215
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .utils import roundtrip_inplace_visitor
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from ..utils.ast_helpers import ensure_equal_nodes
    from ..utils.path import os_path

    def check_roundtrip(expected, code):
        ensure_equal_nodes(
            expected=expected,
            actual=roundtrip_inplace_visitor(
                node=ast.parse(code),
                visitor=ReturnFromGeneratorTransformer()
            ).body[0],
            ignore_fields=BaseNodeTransformer.IGNORE_FIELDS
        )

    @snippet
    def expected():
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise

# Generated at 2022-06-23 22:54:49.556588
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    for version in [(3, 2), (3, 3), (3, 4)]:
        assert ReturnFromGeneratorTransformer(version).target == version

# Unit tests for method _find_generator_returns of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:58.843375
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..ast_converter import convert

    fn = """
    def fn():
        yield 1
        return 5
    """
    ast_node = convert(fn)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_node)

    fn_expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_node_expected = convert(fn_expected)

    assert ast.dump(ast_node, annotate_fields=False) == ast.dump(ast_node_expected, annotate_fields=False)

# Generated at 2022-06-23 22:55:00.456498
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:04.662552
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Compiler to convert the code string to ast.Module
    c = ast.parse
    # Assert the transformer is working properly

# Generated at 2022-06-23 22:55:06.197551
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:07.272270
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:16.029626
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test function
    def _function11(a):
        yield a

    def _function21(a):
        yield a
        return a

    def _function31(a):
        if a > 0:
            yield a
            return a
        else:
            yield a

    def _function41(a):
        if a > 0:
            yield a
            return a
        else:
            return a

    def _function51(a):
        if a > 0:
            yield a
        else:
            yield a
            return a

    def _function61(a):
        def f(x):
            return x
        if a > 0:
            yield a
        else:
            yield a
            return a
        return f(a)

    # Expected output
    def _function11_(a):
        yield a

# Generated at 2022-06-23 22:55:24.220613
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import compile_function, BaseTestCase

    class Tests(BaseTestCase):
        def test_1(self):
            def test_gen():
                pass

            self._test(test_gen, test_gen)

        def test_2(self):
            def test_gen():
                yield

            self._test(test_gen, test_gen)

        def test_3(self):
            def test_gen():
                for i in range(1):
                    yield
                return 12

            def test_gen_expected():
                for i in range(1):
                    yield
                exc = StopIteration()
                exc.value = 12
                raise exc

            self._test(test_gen, test_gen_expected)


# Generated at 2022-06-23 22:55:28.811334
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    node = ast.parse('def a():\n\tyield 1\n\treturn 1\n')
    assert str(node) == astor.to_source(node)
    node = ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-23 22:55:35.930102
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        a = 5
        return a
    """

    tree = ast.parse(code)  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    expected_code = """
    def fn():
        a = 5
        exc = StopIteration()
        exc.value = a
        raise exc
    """

    expected_tree = ast.parse(expected_code)  # type: ignore
    assert ast.dump(tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)

# Generated at 2022-06-23 22:55:36.828758
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:38.421276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse

# Generated at 2022-06-23 22:55:43.960526
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import TransformerSuite
    from .helpers import assert_equal_source
    from .unpacking import UnpackSequencesTransformer

    source = """\
    def fn():
        yield 1
        return 5
    """
    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    suite = TransformerSuite()
    suite.add_transformer(UnpackSequencesTransformer)
    suite.add_transformer(ReturnFromGeneratorTransformer)
    code = suite.transform_source(source)
    assert_equal_source(code, expected)



# Generated at 2022-06-23 22:55:49.399861
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor  # type: ignore
    import os

    return_from_generator = """
    def return_from_generator(return_value):
        exc = StopIteration()
        exc.value = return_value
        raise exc
    """

    g_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          '../utils/snippet.py')
    before = astor.code_to_ast.parse_file(g_path)
    expected = astor.code_to_ast.parse_file(g_path, transformers=ReturnFromGeneratorTransformer())
    expected = astor.to_source(expected)
    expected += return_from_generator
    assert astor.to_source(before) == expected


# Generated at 2022-06-23 22:55:59.824742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('def fn():\n'
                     '    yield 1\n'
                     '    return 5')
    expected = ast.parse("def fn():\n"
                         "    yield 1\n"
                         "    exc = StopIteration()\n"
                         "    exc.value = 5\n"
                         "    raise exc")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    print("    test_return_from_generator: ")
    print("        Input:  ", ast.dump(tree))
    print("        Expected:  ", ast.dump(expected))
    print("        Actual: ", ast.dump(tree))
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 22:56:05.924411
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(
        '''\
        def fn():
            yield 1
            return 5
        '''
    )
    expected = ast.parse(
        '''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    )
    ReturnFromGeneratorTransformer(None).visit(node)
    assert ast.dump(node, annotate_fields=False) == ast.dump(expected, annotate_fields=False)

# Generated at 2022-06-23 22:56:08.052262
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:18.210073
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    def fn_generator_with_return_in_for():
        for i in range(10):
            if i > 5:
                return i
            yield i

    def fn_generator_with_two_returns():
        yield 0
        if False:
            return 1
        else:
            return 2

    def fn_generator_with_return_in_try_finally():
        try:
            yield 0
        finally:
            return

    def fn_generator_with_return_in_try():
        try:
            yield 0
            return
        finally:
            return

    def fn_generator_with_return_in_except():
        try:
            yield 0
        except Exception:
            return


# Generated at 2022-06-23 22:56:28.238124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    import astor
    from ..test_utils import assert_code_equal

    tree = astor.parse('def fn():\n  yield 1\n  yield 2\n  return 1')
    tree.body[0].body.append(ast.Expr(value=ast.Num(n=1)))
    tree.body[0].body.append(ast.Return(value=ast.Num(n=1)))
    tree.body[0].body.append(ast.Return(value=None))
    astor.dump_tree(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    astor.dump_tree(tree)
    code = unparse(tree)

# Generated at 2022-06-23 22:56:29.992199
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:31.000665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:39.700774
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from unittest import TestCase
    from ..utils.source import source
    from ..utils.ast import parse
    from ..utils.snippet import snippet, let
    from ..utils.codegen import to_source

    parser = parse

    def test_simple_return(input_code, expected_code):
        class_name = 'ReturnFromGeneratorTransformer'

        transformer_cls = globals()[class_name]
        transformer = transformer_cls()

        input_tree = parser.parse(input_code)
        expected_tree = parser.parse(expected_code)

        new_tree = transformer.visit(input_tree)
        self.assertEqual(expected_tree, new_tree)

        if transformer._tree_changed:
            actual_code = to_source(new_tree)
            self.assertE

# Generated at 2022-06-23 22:56:41.385662
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import fix_missing_locations

# Generated at 2022-06-23 22:56:44.722701
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert isinstance(return_from_generator_transformer, BaseNodeTransformer)



# Generated at 2022-06-23 22:56:51.596103
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase
    from .._testutils import parse_ast_tree

    class ReturnFromGeneratorTransformerTest(BaseNodeTransformerTestCase):
        TRANSFORMER = ReturnFromGeneratorTransformer
        NODE = ast.FunctionDef
        BASIC = """
        def foo(): return 5
        """

        def test_basic(self):
            tree = parse_ast_tree(self.BASIC)
            self.transform(tree)

            self.assertEqual(tree.body[0].body[0].value, 5)

        SIMPLE_GENERATOR = """
        def foo():
            yield 1
            return 5
        """


# Generated at 2022-06-23 22:56:58.404189
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_node

    original_source = '''
        def fn():
            yield 1
            return 2
    '''
    expected_source = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    '''

    node = source_to_node(original_source)
    ReturnFromGeneratorTransformer().visit(node)

    actual_source = compile(node, '<test>', 'exec').co_consts[0]
    assert actual_source == expected_source

# Generated at 2022-06-23 22:57:04.965497
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
        def fn2():
            return 1
        def fn3():
            yield 1
            return 1
    """
    expected = """
        def fn():
        def fn2():
            return 1
        def fn3():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == expected

# Generated at 2022-06-23 22:57:06.068924
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    def fn():
        yield 1
        return 5

# Generated at 2022-06-23 22:57:16.995156
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # The test runs the snippet as a Python script and captures the output
    actual = return_from_generator.test(return_value=5)

    # Then we use Python's built-in ast parser to parse the string into an AST
    # and then pass the AST to the constructor of FunctionDefTransformer
    from typed_ast import ast3
    from typed_ast import convert
    code = ast3.parse(return_from_generator.get_snippet())
    typed_ast = convert(code, annotate_fields=False, annotate_types=False)
    fn = typed_ast.body[0]
    x = ReturnFromGeneratorTransformer()
    tree = x.visit(fn)

    # Then we write the FunctionDefTransformer output back out to a string,
    # and then use Python's built-in parser to parse

# Generated at 2022-06-23 22:57:19.216245
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None)
    assert transformer is not None

# Generated at 2022-06-23 22:57:30.054091
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import ast_converter
    from .. import ast_converter_2to3
    from typed_ast import ast3 as ast

    def test_it(input, expected_output):
        tree = ast_converter.parse_string(input)
        tree = ast.fix_missing_locations(tree)

        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)

        output = ast_converter_2to3.unparse(tree)
        assert expected_output == output

    input = '''
    def fn():
        yield 1
        return 5
    '''
    expected_output = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''


# Generated at 2022-06-23 22:57:40.943179
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    returndef = ast.Return()
    assert isinstance(returndef, ast.Return)
    returndef.value = None
    returndef.lineno = 1
    fn = ast.FunctionDef()
    fn.lineno = 1
    fn.name = "foo"
    fn.body = [ast.Yield(lineno=1, value=ast.Num(lineno=1, n=1)), returndef]
    return_from_generator_transformer.visit_FunctionDef(fn)
    assert returndef.value is None
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    returndef = ast.Retur

# Generated at 2022-06-23 22:57:42.627439
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    return transformer

# Generated at 2022-06-23 22:57:48.582221
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..transpile import transpile
    def fn():
        yield 1
        return 5

    ast_ = ast.parse(transpile(fn))
    node = ast_.body[0]

    assert isinstance(node.body[1], ast.Return)

    ReturnFromGeneratorTransformer().visit(ast_)
    code = astor.to_source(ast_)

    assert 'exc = StopIteration()' in code
    assert 'exc.value = 5' in code
    assert 'raise exc' in code

# Generated at 2022-06-23 22:57:59.554009
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node):
            if isinstance(node, ast.FunctionDef):
                return super()._find_generator_returns(node)

        def _replace_return(self, parent, return_):
            self.parent = parent
            self.return_ = return_
            super()._replace_return(parent, return_)

    text = '''
    def foo():
        yield

        return 3
    '''
    scope = {}
    tree = ast.parse(text)
    tr = ReturnFromGeneratorTransformerTest()
    tree = tr.visit(tree)
    exec(compile(tree, '<string>', 'exec'), scope)
    assert scope['foo']()


# Generated at 2022-06-23 22:58:06.867409
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ret = ast.Return()
    func = ast.FunctionDef()
    func.name = 'gen'
    func.body.append(ast.Yield())
    func.body.append(ret)
    mod = ast.Module([func])
    assert 'return' in ast.dump(mod, include_attributes=True, include_padding=True)
    trans = ReturnFromGeneratorTransformer()
    mod = trans.visit(mod)
    assert 'return' not in ast.dump(mod)
    assert 'StopIteration' in ast.dump(mod)
    assert not trans._tree_changed

# Generated at 2022-06-23 22:58:11.649166
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = ast.parse("""
    def foo():
        yield 1
        return 5
    """)
    node = code.body[0]
    expected_code = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed == True
    assert ast.dump(new_node) == expected_code



# Generated at 2022-06-23 22:58:22.089708
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transforms import TransformerResult
    from ..utils import dump_ast, load_ast

    class MockedBaseNodeTransformer(BaseNodeTransformer):
        def __init__(self, version: Tuple[int, int]):
            self._tree_changed = False
            self.__version = version

        @property
        def _tree_changed(self):
            return super(MockedBaseNodeTransformer, self)._tree_changed

        @_tree_changed.setter
        def _tree_changed(self, value):
            pass

        @property
        def target(self):
            return self.__version

    class MockedFunctionDef(ast.FunctionDef):
        def __init__(self, body: List[ast.stmt]):
            self.body = body