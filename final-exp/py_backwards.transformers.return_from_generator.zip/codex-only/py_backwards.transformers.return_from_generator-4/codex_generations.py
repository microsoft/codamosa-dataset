

# Generated at 2022-06-23 22:48:21.515542
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:48:29.573208
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import TransformerTestCase, Code

    class Test(TransformerTestCase):
        def test_return_in_generator(self):
            self.assert_transformation(
                ReturnFromGeneratorTransformer,
                Code('def fn():\n    yield 1\n    return 5'),
                Code('def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n')
            )

        def test_nothing_to_replace(self):
            self.assert_no_changes(
                ReturnFromGeneratorTransformer,
                Code('def fn():\n    return 5')
            )

# Generated at 2022-06-23 22:48:30.503926
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t is not None

# Generated at 2022-06-23 22:48:31.213894
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-23 22:48:35.218257
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = '''\
        def fn():
            yield 1
            return 5
    '''
    expected = '''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    tree = ast.parse(code)
    mod = ReturnFromGeneratorTransformer().visit(tree)
    mod = ast.fix_missing_locations(mod)
    assert ast.dump(mod) == expected

# Generated at 2022-06-23 22:48:36.808044
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:44.384023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def func_body():
        yield "Hello"
        return 15

    func = ast.parse(func_body.__code__).body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(func)

    expected = ast.parse(
        """
        def func_body():
            yield "Hello"
            exc = StopIteration()
            exc.value = 15
            raise exc
        """
    )

    assert ast.dump(expected) == ast.dump(func)


# Generated at 2022-06-23 22:48:54.649243
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def run(code: str) -> str:
        tree = ast.parse(code, mode='exec')
        ReturnFromGeneratorTransformer().visit(tree)
        return ast.unparse(tree)

    assert run("""
        def foo():
            yield 1
            return 1
        """) == """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
        """

    assert run("""
        def foo():
            yield 1
            return
        """) == """
        def foo():
            yield 1
            return"""


# Generated at 2022-06-23 22:48:56.439609
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:06.374897
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """
    module = ast.parse(code)
    new_module = ReturnFromGeneratorTransformer().visit(module)  # type: ignore

# Generated at 2022-06-23 22:49:08.141603
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from .base import TransformationTestCase
    

# Generated at 2022-06-23 22:49:08.741166
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:16.908440
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_test = ReturnFromGeneratorTransformer()
    assert return_from_generator_test._find_generator_returns("""
    def fn():
        yield 1
        return 5
    """) == [(node("""
    def fn():
        yield 1
        return 5
    """), node("""return 5""")),]
    assert return_from_generator_test._find_generator_returns("""
    def fn():
        for i in [1, 2, 3]:
            yield i
        return 5
    """) == [(node("""
    def fn():
        for i in [1, 2, 3]:
            yield i
        return 5
    """), node("""return 5""")),]

# Generated at 2022-06-23 22:49:21.562359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from .setup_test import setup_test
    module = setup_test(ReturnFromGeneratorTransformer)
    # module = setup_test(DummyTransformer)
    for funcname in dir(module):
        if funcname.startswith('test_'):
            locals()[funcname]()


# Generated at 2022-06-23 22:49:28.755331
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import get_arg
    from ..utils import source_to_ast

    code = """
    def fn(a):
        yield 1
        return a + 2
    """


# Generated at 2022-06-23 22:49:38.160946
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test if proper generators get transformed properly
    assert ReturnFromGeneratorTransformer().visit(ast.parse("""
        def gen():
            yield 1
            yield 2
            return 3
    """).body[0]) == ast.parse("""
        def gen():
            yield 1
            yield 2
            exc = StopIteration()
            exc.value = 3
            raise exc
    """).body[0]

    # Test other functions
    assert ReturnFromGeneratorTransformer().visit(ast.parse("""
        def fn():
            return
    """).body[0]) == ast.parse("""
        def fn():
            return
    """).body[0]

# Test if proper generators get transformed properly

# Generated at 2022-06-23 22:49:48.340640
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import unittest
    from collections import deque
    from typed_ast import ast3

    class TestCase(unittest.TestCase):
        def check(self, before, after):
            self.assertEqual(before, after)

    class NonLocalCorrector(BaseNodeTransformer):
        def __init__(self):
            self.nonlocals = set()

        def visit_FunctionDef(self, node):
            node.nonlocals = self.nonlocals.copy()
            return self.generic_visit(node)

        def visit_Global(self, node):
            self.nonlocals.update(node.names)
            return node


# Generated at 2022-06-23 22:49:55.133729
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = 'def fn():\n\tyield 1\n\treturn 5'
    ast_module = ast.parse(code)
    new_ast_module = ReturnFromGeneratorTransformer().visit(ast_module)
    assert astunparse.unparse(new_ast_module) == \
        'def fn():\nyield 1\nexc = StopIteration()\nexc.value = 5\nraise exc\n'
# END Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:56.260914
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:02.053665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    expect = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    actual = """def fn():
    yield 1
    return 5"""
    actual_node = ast.parse(actual)

    ReturnFromGeneratorTransformer().visit(actual_node)

    assert_equal_source(expect, actual_node)



# Generated at 2022-06-23 22:50:09.005967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astor.code_gen import to_source
    from ..utils.pytest_helpers import assert_equal_ast_source

    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    module_node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(module_node)
    assert_equal_ast_source(to_source(module_node), expected)



# Generated at 2022-06-23 22:50:09.892895
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:11.620053
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Unit tests for the snippet "return_from_generator"

# Generated at 2022-06-23 22:50:18.276581
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    def check(before, after):
        assert after == ast.dump(transformer.visit(ast.parse(before)))  # type: ignore

    check('''def fn():
        yield 1
        return 5''', '''def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc''')

    check('''def fn():
        return 5''', '''def fn():
    return 5''')

    check('''def fn():
        yield 1
        if True:
            return 7''', '''def fn():
    yield 1
    if True:
        exc = StopIteration()
        exc.value = 7
        raise exc''')


# Generated at 2022-06-23 22:50:20.953470
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """
    Test for constructor of class ReturnFromGeneratorTransformer
    """
    rfgt = ReturnFromGeneratorTransformer()
    assert rfgt.target == (3, 2)



# Generated at 2022-06-23 22:50:23.386984
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__repr__() == "<ReturnFromGeneratorTransformer()>"



# Generated at 2022-06-23 22:50:24.347312
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:29.839682
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    snippet = """
    def a():
        yield 1
        return ok
    """
    expect = """
    def a():
        yield 1
        exc = StopIteration()
        exc.value = ok
        raise exc
    """

    tree = ast.parse(snippet)
    tree = ReturnFromGeneratorTransformer.run(tree)
    assert expect == tree_to_code(tree)

# Generated at 2022-06-23 22:50:32.041876
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer


# Generated at 2022-06-23 22:50:35.652445
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    node = ast.parse(fn.__code__.co_code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert fn.__code__.co_code != transformer.to_code(node).encode()

# Generated at 2022-06-23 22:50:38.414688
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:48.610530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    This function transforms the function def statement in main()
    and returns a list of names of fields defined in the function.
    """
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse('''
        def main():
            yield 1
            return 5
    ''')
    transformer.visit(node)
    assert '''
        def main():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''' == ast.dump(node, annotate_fields=False)

    node = ast.parse('''
        def main(x):
            y = x+1
            return y
    ''')
    transformer.visit(node)

# Generated at 2022-06-23 22:50:57.071008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef
    from typed_ast.ast3 import Return
    from typed_ast.ast3 import Yield
    from typed_ast.ast3 import YieldFrom
    from .ast_helper import get_ast, get_funcdef_ast

    # Test for checking if we can replace empty return statement
    # For example function without 'return' statement is converted to:
    #   def fn():
    #       pass
    # Gives:
    #   def fn():
    #       pass
    def test_fn_without_return():
        ast1 = get_funcdef_ast("def fn(): pass")
        ast2 = get_funcdef_ast("def fn(): pass")
        ReturnFromGeneratorTransformer().visit(ast1)
        assert ast1 == ast2

    test_fn_without

# Generated at 2022-06-23 22:51:01.831479
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._find_generator_returns(ast.parse('''
        def foo():
            yield 1
            return 2
    ''')) == [(ast.parse('''
        def foo():
            yield 1
            return 2
    '''), ast.parse('return 2'))]



# Generated at 2022-06-23 22:51:04.901811
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import typed_astunparse
    def test(a):
        yield a
        return a


# Generated at 2022-06-23 22:51:07.374141
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test Transformer is properly created."""
    return_from_generator = ReturnFromGeneratorTransformer()
    assert return_from_generator.target == (3, 2)

# Generated at 2022-06-23 22:51:09.492965
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:51:19.336455
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer(): # type: ignore
    class Finder():
        """Test visitor"""
        def __init__(self):
            self.return_nodes = []

        def generic_visit(self, node): # type: ignore
            for field, value in ast.iter_fields(node):
                if isinstance(value, list):
                    for item in value:
                        if isinstance(item, ast.AST):
                            self.visit(item)
                elif isinstance(value, ast.AST):
                    self.visit(value)
            return node

        def visit_Return(self, node):
            self.return_nodes.append(node)
            return self.generic_visit(node)

    def check(func, expected_nodes): # type: ignore
        finder = Finder()

# Generated at 2022-06-23 22:51:20.407818
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:29.693233
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from textwrap import dedent

    tree = ast.parse(dedent('''\
        def fn():
            yield 1
            return 5
    '''))

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    expected_tree = ast.parse(dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''))

    ast3.fix_missing_locations(tree)
    ast3.fix_missing_locations(expected_tree)

    assert ast3.dump(tree) == ast3.dump(expected_tree)

# Generated at 2022-06-23 22:51:30.390835
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ret = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:31.561701
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # noinspection PyUnresolvedReferences
    def fn():
        yield 1
        return 5


# Generated at 2022-06-23 22:51:36.777352
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast, compare_asts
    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = get_ast(code)
    result = ReturnFromGeneratorTransformer().visit(node)
    expected_result = get_ast(expected_code)
    assert compare_asts(result, expected_result)


# Generated at 2022-06-23 22:51:46.522252
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse("""
    def f():
        yield 1
        return 5
    def g():
        yield 1
        yield 5
        return 6
    def h():
        return 1
    def i():
        return 1
        yield 1
    def j():
        pass
    """)
    t = ReturnFromGeneratorTransformer()
    t.visit(tree)

# Generated at 2022-06-23 22:51:51.498044
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse('def fn(): yield 1; return 5')
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(node)  # type: ignore
    source = ast.unparse(tree).strip().split('\n')


# Generated at 2022-06-23 22:51:55.762877
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5
    expected_fn = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert expected_fn == ReturnFromGeneratorTransformer().visit(fn)

# Generated at 2022-06-23 22:52:02.999549
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_cases import cases_from_snippets
    from ..utils.test_visitor import TestVisitor
    from .assert_result import assert_result


# Generated at 2022-06-23 22:52:09.810555
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .helpers import node_to_string, node_equals
    source = 'def x():\n    yield 1\n    return 2'
    expected = 'def x():\n    yield 1\n    exc = StopIteration()\n    exc.value = 2\n    raise exc'
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert node_to_string(node) == expected
    expected_node = ast.parse(expected)
    assert node_equals(node, expected_node)


# Generated at 2022-06-23 22:52:11.221722
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:52:16.525773
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5
    
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(fn.__code__)
    result = transformer.visit(tree)
    code = compile(result, "", "exec")
    f = code.co_consts[0]
    assert next(f()) == 1
    assert next(f()) == 5

# Generated at 2022-06-23 22:52:19.937125
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class MyTransformer(ReturnFromGeneratorTransformer):
        def visit(self, node):
            return self.generic_visit(node)  # type: ignore

    assert MyTransformer().visit(ast.parse("1")).body == [ast.Expr(value=ast.Num(n=1))]  # type: ignore

# Generated at 2022-06-23 22:52:21.698325
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    _ = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:26.393336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from .test_utils import assert_transformed  # noqa
    from ..utils.typed_ast_utils import ast_to_source  # noqa

    import typed_astunparse  # noqa
    import astunparse  # noqa

    module_ast = ast.parse('def f(): yield; return 1')
    tree_changed, module_ast = ReturnFromGeneratorTransformer().visit(module_ast)
    source_code = typed_astunparse.unparse(module_ast)

# Generated at 2022-06-23 22:52:26.721037
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:27.643942
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:52:37.427855
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class TestVisitor(unittest.TestCase):

        def test_simple_generator(self):
            node = ast.parse('def fn(): yield 1').body[0]

            t = ReturnFromGeneratorTransformer()
            t.visit(node)

            self.assertFalse(t._tree_changed)

        def test_return_in_generator(self):
            node = ast.parse('def fn(): yield 1; return 5').body[0]

            t = ReturnFromGeneratorTransformer()
            t.visit(node)

            self.assertTrue(t._tree_changed)

            body = '\n'.join(str(x) for x in node.body) + '\n'  # type: ignore


# Generated at 2022-06-23 22:52:43.256431
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ... import ast_transformer
    from ...compiler_data import Module
    from ..assertions import assert_program

    source = """
        def fn():
            yield 1
            return 5
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    module = ast_transformer.transform(Module('test', source))
    assert_program(module.source, expected)

# Generated at 2022-06-23 22:52:43.724199
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return

# Generated at 2022-06-23 22:52:45.832052
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.target == (3, 2)



# Generated at 2022-06-23 22:52:51.774805
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .function_transformer import FunctionTransformer

    code = """
            def fn():
                yield 1
                return 5
            """

    tr = ReturnFromGeneratorTransformer()
    checker = FunctionTransformer()
    tree = ast.parse(code)
    tr.visit(tree)
    checker.visit(tree)

    assert tree.body[0].body[1].value.func.id == 'StopIteration'



# Generated at 2022-06-23 22:52:52.222657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:52.639312
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert True

# Generated at 2022-06-23 22:52:56.076336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import simplediff

    for python_version in range(3, 9):
        node = ast.parse("def fn(): yield 1; return 'foo'", python_version=python_version)
        ReturnFromGeneratorTransformer().visit(node)
        assert python_version >= (3, 6)

# Generated at 2022-06-23 22:52:57.326625
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:52:58.224548
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:04.546312
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_code
    from ..utils.test_utils import assert_transformed_ast_is

    code = '''
        def fn():
            yield 1
            return 5
    '''

    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    assert_transformed_ast_is(code, expected, [ReturnFromGeneratorTransformer])



# Generated at 2022-06-23 22:53:05.630776
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Check correct initializing
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

    # Check correct executing of visit_FunctionDef method

# Generated at 2022-06-23 22:53:13.507733
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..resolver import FunctionNode
    from ..resolver import TransformFunction
    from ..transformer.local_variables import LocalVariablesCompiler
    from ..transformer.inner_function_converter import InnerFunctionConverter
    from ..transformer.ast_converter import AstConverter
    from ..transformer.primitive_converter import PrimitiveConverter
    from ..transformer.import_converter import ImportConverter
    from ..transformer.function_call import FunctionCallTransformer

    def test(code):
        source = 'def test():\n' + code
        node = FunctionNode(source)
        node.compile(TransformFunction())
        return node.code.rstrip()

    assert test('1') == 'def test():\n    return 1'

# Generated at 2022-06-23 22:53:14.248076
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:53:19.433059
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:26.441761
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..conftest import assert_code_equal

    code = '''
    def test(a, b):
        c = a + b
        yield c
        return c
    '''
    expected_source = '''
    def test(a, b):
        c = a + b
        yield c
        exc = StopIteration()
        exc.value = c
        raise exc
    '''

    tree = ast.parse(code)  # type: ignore
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(tree, expected_source)


# Generated at 2022-06-23 22:53:29.247219
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer is not None

# Generated at 2022-06-23 22:53:38.753635
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    #pylint: disable=W0212
    assert ReturnFromGeneratorTransformer._find_generator_returns(  # type: ignore
        ReturnFromGeneratorTransformer(),
        ast.parse("""
        def fn():
          yield 1
        """).body[0]
    ) == []
    assert ReturnFromGeneratorTransformer._find_generator_returns(  # type: ignore
        ReturnFromGeneratorTransformer(),
        ast.parse("""
        def fn():
          yield 1
          return 5
        """).body[0]
    ) == [(ast.parse("""def fn():\n  yield 1\n  return 5""").body[0], ast.parse("""return 5""").body[0])]

# Generated at 2022-06-23 22:53:48.535043
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .coverage_visitor import CoverageVisitor
    from .dead_branch_eliminator import DeadBranchEliminator
    from .anonymous_function_transformer import AnonymousFunctionTransformer
    from .argument_unpacking_transformer import ArgumentUnpackingTransformer
    from ..utils.source_code import SourceCode
    # Test single yield
    transformer_object = ReturnFromGeneratorTransformer()
    # This will give an error if test fails
    transformer_object.visit(ast.parse('''def fn():
        yield 1
        return 5'''))
    # Test multiple yields
    transformer_object.visit(ast.parse('''def fn():
        yield 1, 2
        return 5'''))
    # Test yield with list

# Generated at 2022-06-23 22:53:57.349264
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import utils
    from ..utils.ast_utils import parse_ast_tree, dump_ast_tree, dump_code

    code = utils.code_snippet("""
    def fn():
        yield 1
        return 5
    """)
    tree = parse_ast_tree(code)
    dump_ast_tree(tree)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    dump_ast_tree(tree)
    dump_code(tree)

    assert dump_code(tree) == utils.code_snippet("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

# Generated at 2022-06-23 22:54:02.937473
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.static_analysis import get_node

    def generator():
        yield 1
        return 90

    def test():
        for _ in generator():
            continue

    def expected():
        for _ in generator():
            continue
        return 90

    node = get_node(generator)
    x = ReturnFromGeneratorTransformer().visit(node)
    assert unparse(x) == unparse(expected())

# Generated at 2022-06-23 22:54:04.080743
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:10.583860
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    tree = ast.parse('def foo():\n    yield 1')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    expected_tree = ast.parse('def foo():\n    yield 1')
    assert astor.to_source(tree) == astor.to_source(expected_tree)

    tree = ast.parse('def foo():\n    1\n    return')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    expected_tree = ast.parse('def foo():\n    1\n    return')
    assert astor.to_source(tree) == astor.to_source(expected_tree)

    tree = ast.parse('def foo():\n    yield 1\n    return')
    transformer = ReturnFromGenerator

# Generated at 2022-06-23 22:54:21.675033
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("test_ReturnFromGeneratorTransformer")
    class A:
        def fn1(self):
            yield "yield 1"
            return "ret 1"

        def fn2(self):
            yield 1
            return
            yield 2

        def fn3(self):
            if True:
                yield 1
            else:
                return

        def fn4(self):
            if True:
                return
            else:
                yield 1

    node = ast.parse(inspect.getsource(A))

    print("Before transformation")
    print(inspect.getsource(A))

    rft = ReturnFromGeneratorTransformer()
    rft.visit(node)

    print("After transformation")
    print(astunparse.unparse(node))


# Generated at 2022-06-23 22:54:23.036599
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert x.target == (3, 2)

# Generated at 2022-06-23 22:54:33.889160
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generator import GeneratorTransformer
    from ..utils.source import source, NodeSource
    from ..utils.fake import FakeTree

    module = ast.Module([ast.FunctionDef('fn', None, [], [ast.Yield(ast.Num(1))], [])])
    expected = ast.Module([ast.FunctionDef('fn', None, [], [ast.Yield(ast.Num(1)),
                                                           ast.Expr(ast.Call(ast.Name('return_from_generator', ast.Load()),
                                                                             [ast.Num(5)], [], None, None)),
                                                           ], [])])

    tree = FakeTree(module)
    tree.set_source(NodeSource(module[0][2]))

# Generated at 2022-06-23 22:54:35.792417
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert type(t) == ReturnFromGeneratorTransformer
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-23 22:54:36.949841
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-23 22:54:37.496915
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:44.097558
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = (
        "def fn():\n"
        "  yield 1\n"
        "  return 5"
    )

    expected = (
        "def fn():\n"
        "  yield 1\n"
        "  exc = StopIteration()\n"
        "  exc.value = 5\n"
        "  raise exc"
    )

    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer.run(tree)
    result = ast.unparse(tree)

    assert result == expected

# Generated at 2022-06-23 22:54:51.773134
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse
    from ..utils.compat import NodeTransformer
    from ..utils.ast_utils import ast_to_source_code

    source = """
    def generator():
        yield
        return 5

    def generator2():
        yield
        return

    def generator3():
        yield
        return 5
        return 7

    def generator4():
        def inner():
            return 5
        return inner()

    def generator5():
        yield
        if True:
            return 5

    def generator5():
        if True:
            yield
        if True:
            return 5
    """

# Generated at 2022-06-23 22:54:53.640119
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert isinstance(t, BaseNodeTransformer)


# Generated at 2022-06-23 22:54:55.548295
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        assert ReturnFromGeneratorTransformer()
    except TypeError:
        pass


# Generated at 2022-06-23 22:55:02.797572
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Empty(object):
        def __init__(self):
            self._tree_changed = False
            self._filename = None
        def generic_visit(self, node):
            return node
        def visit_FunctionDef(self, node):
            generator_returns = self._find_generator_returns(node)
            if generator_returns:
                self._tree_changed = True
            for parent, return_ in generator_returns:
                self._replace_return(parent, return_)
            return self.generic_visit(node)
        @property
        def tree_changed(self):
            return self._tree_changed
        @property
        def filename(self):
            return self._filename


# Generated at 2022-06-23 22:55:12.617875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # It is desired to test the method visit_FunctionDef of class ReturnFromGeneratorTransformer.
    # The method visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef returns ast.FunctionDef.
    # The method visit_FunctionDef of class ReturnFromGeneratorTransformer requires ast.FunctionDef as a parameter.

    # creation of object ReturnFromGeneratorTransformer
    ReturnFromGeneratorTransformerObject = ReturnFromGeneratorTransformer()

    # creation of ast.FunctionDef object
    a = ast.FunctionDef()

    # creation of ast.Module object
    b = ast.Module()

    # creation of ast.Return object
    c = ast.Return()

    # creation of ast.Name object
    d = ast.Name()
    d.id = "d"

    # creation of ast.Yield object
    e

# Generated at 2022-06-23 22:55:13.572997
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert 1 == 1



# Generated at 2022-06-23 22:55:15.508787
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ast import parse
    from ..backport_ast import ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:55:17.126403
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield
        return 5

# Generated at 2022-06-23 22:55:20.806823
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer', \
        'Wrong class name'
    x = ReturnFromGeneratorTransformer()
    assert isinstance(x, BaseNodeTransformer), 'Wrong base class'


# Generated at 2022-06-23 22:55:28.444548
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_case(original):
        expected = ast.dump(ast.parse(expected), annotate_fields=False, include_attributes=False)
        original = ast.dump(ast.parse(original), annotate_fields=False, include_attributes=False)
        transformer = ReturnFromGeneratorTransformer()
        result = transformer.visit(ast.parse(original))
        result = ast.dump(result, annotate_fields=False, include_attributes=False)
        assert result == expected
    # Test for no yield case.
    original = """
    def test():
        s = 0
        def fn():
            return 5
        return fn()
        """
    expected = """
    def test():
        s = 0
        def fn():
            return 5
        return fn()
        """

# Generated at 2022-06-23 22:55:34.838651
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    tree = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')
    assert astor.to_source(tree) == '\n    def fn():\n        yield 1\n    return 5\n'
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert astor.to_source(tree) == '\n    def fn():\n        yield 1\n        exc = StopIteration()\n        exc.value = 5\n        raise exc\n'

# Generated at 2022-06-23 22:55:37.460469
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with open('./semantic_python/transformers/tests/files/return_in_generators/return_transformer.py') as file:
        tree = ast.parse(file.read())
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 22:55:43.932570
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import last_line_of_function
    from ..python_version import get_python_version
    if get_python_version() == 2:
        test_ReturnFromGeneratorTransformer_visit_FunctionDef_for_python_2()
    elif get_python_version() == 3:
        test_ReturnFromGeneratorTransformer_visit_FunctionDef_for_python_3()

    def test_ReturnFromGeneratorTransformer_visit_FunctionDef_for_python_2():
        from ..utils import compile_snippet
        from typed_ast import ast3
        def f():
            yield 1
            return 5
        tree = ast3.parse(compile_snippet(f))
        ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:55:49.364075
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import assert_node

    tree = ast.Module(body=[
        ast.FunctionDef(
            name='f',
            args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
            body=[
                ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
                ast.Return(value=ast.Num(n=5))
            ],
            decorator_list=[],
            returns=None
        )
    ])


# Generated at 2022-06-23 22:56:00.141910
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # ARRANGE #
    node0 = ast.FunctionDef(name="fn", args=None, body=[], decorator_list=[], returns=None)
    node1 = ast.FunctionDef(name="fn", args=None, body=[], decorator_list=[], returns=None)
    node1.body = [ast.Return()]
    node2 = ast.FunctionDef(name="fn", args=None, body=[], decorator_list=[], returns=None)
    node2.body = [ast.Return(value=ast.Constant(value=1))]
    node3 = ast.FunctionDef(name="fn", args=None, body=[], decorator_list=[], returns=None)
    node3.body = [ast.Yield(value=None)]

# Generated at 2022-06-23 22:56:08.981346
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as typed_ast
    from typed_ast.ast3 import FunctionDef, Yield, Name, Return, Load, Str
    from .node_util import to_source

    function_ast = FunctionDef(
        name='test_fn',
        args=typed_ast.arguments(
            posonlyargs=[],
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[
            Yield(value=Name(id='x', ctx=Load())),
            Return(value=Str(s='123')),
        ],
        decorator_list=[],
        returns=None,
    )

# Generated at 2022-06-23 22:56:10.762734
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:56:20.371811
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # This is function defination snippet
    def function_defination_snippet(return_value):
        def fn():
            yield 1
            return return_value
    # This is expected output snippet
    def expected_output_snippet(return_value):
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = return_value
            raise exc

    # Convert snippets to AST nodes
    function_defination_ast = ast.parse(function_defination_snippet(return_value=1).__doc__).body[0]
    expected_output_ast = ast.parse(expected_output_snippet(return_value=1).__doc__).body[0]

    # Create transformer instance
    transformer = ReturnFromGeneratorTransformer()

    # Visit function defination node and compare it with

# Generated at 2022-06-23 22:56:27.585524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def generator_return():
        yield 1
        return 5

    def test_function(function):
        return function()

    tested = ReturnFromGeneratorTransformer().visit(generator_return.__code__.co_consts[1])
    transformer = ReturnFromGeneratorTransformer()
    transformer._tree_changed = False
    result = transformer.visit(ast.parse(tested))
    assert transformer._tree_changed == True
    compiled = compile(result,"","exec")
    assert test_function(eval(compiled)) == [1]

# Generated at 2022-06-23 22:56:29.433639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:30.995257
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .raise_stop_iteration import RaiseStopIterationTransformer
    transformer = ReturnFromGeneratorTransformer()
    transformer = RaiseStopIterationTransformer().visit(transformer)
    assert transformer is not None


# Generated at 2022-06-23 22:56:39.659164
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create mock node
    class Node:
        def __init__(self, value=None, name='', body=None):
            self.value = value
            self.name = name
            self.body = body
    class List:
        def __init__(self, a):
            self.a = a
    class Function(Node):
        def __init__(self, value=None, name='', body=None):
            self.value = value
            self.name = name
            self.body = body
    class Return(Node):
        def __init__(self, value=None, name='', body=None):
            self.value = value
            self.name = name
            self.body = body

# Generated at 2022-06-23 22:56:42.093626
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

    # single return in generator

# Generated at 2022-06-23 22:56:46.158559
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astunparse
    module = ast.parse(
        """def fn():
                yield 1
                yield 2
                return 3
        """
    )
    module = ReturnFromGeneratorTransformer().visit(module)

# Generated at 2022-06-23 22:56:52.426107
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # test definition of a function without a yield
    tree = ast.parse("""
    def f(): return 'return'
    """)
    expected_tree = ast.parse("""
    def f(): return 'return'
    """)
    t = ReturnFromGeneratorTransformer()
    t.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)
    assert t._tree_changed == False

    # test case 1
    tree = ast.parse("""
    def f():
        yield 10
        return 'return'
    """)
    t = ReturnFromGeneratorTransformer()
    t.visit(tree)

# Generated at 2022-06-23 22:56:57.907161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import transform_and_compare

    before = '''
        def test():
            yield 1
            return 8
        '''

    after = '''
        def test():
            yield 1
            exc = StopIteration()
            exc.value = 8
            raise exc
        '''

    transform_and_compare(
        ReturnFromGeneratorTransformer,
        before,
        after,
    )



# Generated at 2022-06-23 22:57:04.465311
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(ReturnFromGeneratorTransformer):
        def __init__(self):
            super(Test, self).__init__()
            self.body = []

        def _replace_return(self, parent: Any, return_: ast.Return) -> None:
            self.body.append(return_)  # type: ignore
    
    def check(code):
        node = ast.parse(code)  # type: ignore
        transformer = Test()
        transformer.visit(node)
        assert len(transformer.body) == 1



# Generated at 2022-06-23 22:57:09.038010
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    root = ast.parse("""
    def fn():
        yield 1
        return 5
    """, mode='exec')

    assert ReturnFromGeneratorTransformer().visit(root) == ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """, mode='exec')



# Generated at 2022-06-23 22:57:12.186847
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_ = ast.Return(value=ast.Num(n=3))
    e = ReturnFromGeneratorTransformer()
    e._replace_return(ast.Module(body=[return_]), return_)  # type: ignore
    assert e._tree_changed == True

# Generated at 2022-06-23 22:57:15.262451
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from .return_from_generator import ReturnFromGeneratorTransformer
    instance = ReturnFromGeneratorTransformer()
    assert isinstance(instance, BaseNodeTransformer)

# Generated at 2022-06-23 22:57:16.239313
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:17.665124
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-23 22:57:28.878729
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tr = ReturnFromGeneratorTransformer()
    fn = ast.parse("""
    def foo():
        yield 1
        return 1
    """)
    tr.visit(fn)

# Generated at 2022-06-23 22:57:39.953111
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test(fn: ast.FunctionDef) -> ast.FunctionDef:
        transformer = ReturnFromGeneratorTransformer()
        return transformer.visit(fn)

    def call_test(node: ast.AST) -> ast.FunctionDef:
        return test(ast.parse(inspect.getsource(node)).body[0])  # type: ignore

    def check(fn: ast.FunctionDef, expected: ast.FunctionDef) -> None:
        assert fn == expected

    def test_0():
        @snippet
        def fn():
            yield 1
            return 5

        check(call_test(fn),
              call_test(ast.parse(return_from_generator.make_code_string(5))))

    def test_1():
        @snippet
        def fn():
            yield 1
            yield 2


# Generated at 2022-06-23 22:57:42.037379
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.make_snippets import get_ast
    import astor


# Generated at 2022-06-23 22:57:48.451962
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # (node, expected_tree_changed)
    data = [
        (
            ast.parse("def fn(): yield 1"),
            False,
        ),
        (
            ast.parse("def fn(): return 1"),
            False,
        ),
        (
            ast.parse("def fn(): yield 1\nreturn 1"),
            True,
        ),
        (
            ast.parse("""
            def fn():
                if 1:
                    yield 1
                else:
                    return 1
            """),
            True,
        ),
        (
            ast.parse("""
            def fn():
                if 1:
                    yield 1
            """),
            False,
        ),
    ]

    for node, expected_tree_changed in data:
        transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:57:49.796372
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:58:00.845096
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse('''
    def fn():
        exc = StopIteration()
        exc.value = 123
        raise exc
    '''))
    assert transformer._tree_changed is False

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse('''
    def fn1():
        return
        yield 1

    def fn2():
        yield 1
        yield 1
        return
    '''))
    assert transformer._tree_changed is False

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse('''
    def fn():
        yield 1
        return 2
    '''))
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:58:07.918632
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_utils import compile_to_legacy, dedent
    fn_decorator = dedent('''
        @return_from_generator(inline=True, add_self=True)
        def fn():
            yield 1
            return 5
    ''')
    fn_to_compare = dedent('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')
    assert compile_to_legacy(fn_decorator) == compile_to_legacy(fn_to_compare)

# Generated at 2022-06-23 22:58:18.454090
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_body = [
        ast.Return(ast.Num(1)),
        ast.Expr(ast.Call(
            func=ast.Name('f', ast.Load()),
            args=[],
            keywords=[],
        )),
        ast.Return(ast.Num(2)),
        ast.For(
            target=ast.Name('i', ast.Store()),
            iter=ast.Tuple(
                elts=[],
                ctx=ast.Load(),
            ),
            body=[
                ast.Expr(ast.Call(
                    func=ast.Name('f', ast.Load()),
                    args=[],
                    keywords=[],
                )),
                ast.Return(ast.Num(3)),
            ],
            orelse=[],
        ),
    ]

# Generated at 2022-06-23 22:58:26.764675
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Without generator
    class FakeNode:
        def __init__(self, body):
            self.body = body

    root = FakeNode([
        ast.Return(value=ast.Num(n=1)),
    ])
    node = ast.FunctionDef(body=[root])
    ReturnFromGeneratorTransformer().visit(node)
    assert node.body == [root]

    # With generator
    root = FakeNode([
        ast.Return(value=ast.Num(n=1)),
    ])
    node = ast.FunctionDef(body=[root])
    node.body[0].body.append(ast.Yield(value=ast.Num(n=2)))
    ReturnFromGeneratorTransformer().visit(node)