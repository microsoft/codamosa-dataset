

# Generated at 2022-06-23 22:48:26.118142
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def do_test(code, expected_code):
        tree = ast.parse(code)
        ReturnFromGeneratorTransformer().visit(tree)
        assert astor.to_source(tree) == expected_code


# Generated at 2022-06-23 22:48:31.628003
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = "def fn():\n    yield 1\n    return 5"
    node = ast.parse(code).body[0]  # type: ignore
    result = ReturnFromGeneratorTransformer().visit_FunctionDef(node)  # type: ignore
    expected = "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"
    assert ast.dump(result) == expected

# Generated at 2022-06-23 22:48:41.370710
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from typing import List
    from typed_ast import ast3 as ast
    from ...utils.testing import assert_equal_ast, assert_tree_changed

    def transpile_function(fn):
        node = ast.parse(fn)
        node = ReturnFromGeneratorTransformer().visit(node)
        return ast.Interactive(body=node.body)


    @assert_equal_ast(transpile_function)
    def test_return_in_generator(a, b):
        def fn(a, b):
            yield 1
            return a + b

        assert 5 == sum(fn(2, 3))



# Generated at 2022-06-23 22:48:45.638557
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer):

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-23 22:48:46.961651
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:48:52.376691
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse('def my_gen():\n    yield 5\n    return 6'))
    assert transformer.get_tree() == ast.parse('def my_gen():\n    yield 5\n    exc = StopIteration()\n    exc.value = 6\n    raise exc')
    return transformer


# Generated at 2022-06-23 22:49:02.918758
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_FunctionDef(code: str, expected: str):
        node, _ = ast.parse(code)
        transformer = ReturnFromGeneratorTransformer()
        node = transformer.visit(node)  # type: ignore
        print(ast.dump(node))
        assert ast.dump(node) == expected

    test_FunctionDef('''
        def fn1():
            return 1
    ''', '''
        Module(body=[FunctionDef(name='fn1', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Num(n=1))], decorator_list=[], returns=None)])
    ''')

# Generated at 2022-06-23 22:49:05.813583
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # type: ignore
    node = ast.parse('def foo():\n yield 1\n return 5')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:49:06.809581
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:10.796193
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Checking if the name of the class is correct
    test_return_transformer = ReturnFromGeneratorTransformer()

    assert test_return_transformer.__class__.__name__ == \
        "ReturnFromGeneratorTransformer"
    assert test_return_transformer._tree_changed == False


# Generated at 2022-06-23 22:49:12.572474
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    cls = ReturnFromGeneratorTransformer()
    assert cls.target == (3,2)

# Generated at 2022-06-23 22:49:24.474344
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse(textwrap.dedent("""
        def generator():
            for i in range(5):
                yield i
            return i
        """))
    node_visitor = ReturnFromGeneratorTransformer()
    node_visitor.visit(tree)

# Generated at 2022-06-23 22:49:25.625774
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t


# Generated at 2022-06-23 22:49:34.948157
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTest
    from astor.code_gen import to_source

    code = '''
    def fn(a):
        yield a
        return a.b
    '''

    class Testing(BaseNodeTest):
        def __init__(self):
            super().__init__(ReturnFromGeneratorTransformer)

        def test(self):
            self.assertNoModification(code)

    t = Testing()
    t.test()

    code = '''
    def fn(a):
        yield a
        return 5
    '''

    class Testing(BaseNodeTest):
        def __init__(self):
            super().__init__(ReturnFromGeneratorTransformer)

        def test(self):
            self.transformer.visit(self.parse(code))

# Generated at 2022-06-23 22:49:36.905787
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:47.284553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn1():
            yield 1
            return 5
        def fn2():
            yield 1
            return
        def fn3():
            a = 5
            if a:
                return 5
            return 6
        def fn4():
            a = 5
            if a:
                return 5
            return
    """


# Generated at 2022-06-23 22:49:58.352758
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    some = ast.Name(id='some', ctx=ast.Load())
    ret = ast.Return(value=some, lineno=1, col_offset=4)
    yield_ = ast.Yield(value=some, lineno=1, col_offset=4)
    targs = ast.arguments(args=[], vararg=None, kwonlyargs=[],
                          kw_defaults=[], kwarg=None, defaults=[])
    good_func = ast.FunctionDef(name='good_func', args=targs, body=[yield_, ret], decorator_list=[], returns=None)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(good_func)
    assert transformer._tree_changed == True


# Generated at 2022-06-23 22:49:59.861707
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  r = ReturnFromGeneratorTransformer()
  assert r.target is (3, 2)

# Generated at 2022-06-23 22:50:08.197845
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from python_transpiler.analysis.utils.source_tree import source_to_ast
    from python_transpiler.analysis.utils.ast_to_source import ast_to_source
    from ..vectorize import VectorizeTransformer
    src = """
    def foo():
        yield 1
        return 2
    """
    expected = """
    def foo():
        exc = StopIteration()
        exc.value = 2
        raise exc
        yield 1
    """
    tree = source_to_ast(src)
    transpiler = ReturnFromGeneratorTransformer()
    tree = transpiler.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-23 22:50:16.186806
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse(
        '''
        def fn():
            yield 1
            return 5
        def just_yield():
            yield 1
        def just_return():
            return 5
        def yield_and_just_return():
            yield 1
            return 5
        def yield_with_return_inside_generator():
            yield (1 for x in range(5))
        '''
    )

    tree = ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:50:17.997625
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3,2)

# Generated at 2022-06-23 22:50:21.719110
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(ast.parse('def f(): return 1')).visit(
        ast.parse('def f(): return 1')) == ast.parse('def f():\n    exc = StopIteration()\n    exc.value = 1\n    raise exc')


# Generated at 2022-06-23 22:50:25.577619
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:34.085518
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..testing.utils import transform_and_compare
    from .docstring import DocstringTransformer

    source = '''
        def some_func():
            yield 0
            return 1
    '''
    expected = '''
        def some_func():
            yield 0
            exc = StopIteration()
            exc.value = 1
            raise exc
    '''
    tree = ast.parse(source)

    results = transform_and_compare(
        DocstringTransformer, ReturnFromGeneratorTransformer, source, tree)
    for result in results:
        assert astor.to_source(result) == expected



# Generated at 2022-06-23 22:50:34.700985
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:45.477616
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import pytest
    from ..utils.source import source_from_node

    def test_return_from_generator(source_from_node, source_from_snippet):
        expected = source_from_snippet(
            """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """
        )

        source = source_from_snippet(
            """
            def fn():
                yield 1
                return 5
            """
        )

        ReturnFromGeneratorTransformer().visit(source)

        assert source == expected


# Generated at 2022-06-23 22:50:54.332011
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test():
        def test():
            yield 1
            return 5

        return
    input = test.__code__.co_consts[0]


# Generated at 2022-06-23 22:50:58.420194
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.target == (3, 2)
    obj = ReturnFromGeneratorTransformer()
    assert hasattr(obj, 'target')
    assert hasattr(obj, 'visit_FunctionDef')
    assert hasattr(obj, '_tree_changed')
    assert hasattr(obj, '_find_generator_returns')
    assert hasattr(obj, '_replace_return')

# Tests for _find_generator_returns

# Generated at 2022-06-23 22:51:00.270741
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    transformer = ReturnFromGeneratorTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:51:05.945846
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from .base import UnitTestTransformer
    from .base import BaseUnparseTransformer

    class Transformer(BaseUnparseTransformer, BaseNodeTransformer, UnitTestTransformer):
        def __init__(self):
            super(Transformer, self).__init__(ReturnFromGeneratorTransformer())
            self.imports = [] # type: List[str]

    transformer = Transformer()

# Generated at 2022-06-23 22:51:08.316536
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._tree_changed == False
    assert transformer.target == (3, 2)


# Generated at 2022-06-23 22:51:16.726910
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """It should compile return in generator."""
    # pylint: disable=import-outside-toplevel, invalid-name
    from typed_ast import ast3 as ast

    source = '''
        def foo():
            yield 1
            return 5
    '''
    tree = ast.parse(source)
    generator = ReturnFromGeneratorTransformer()
    tree = generator.visit(tree)
    expected = '''
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 22:51:21.922544
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(code)
    transformed_code = compile(ReturnFromGeneratorTransformer().visit(tree), '<string>', 'exec')
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert compile(ast.parse(expected_code), '<string>', 'exec').co_code == transformed_code.co_code



# Generated at 2022-06-23 22:51:23.386663
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test ReturnFromGeneratorTransformer constructor
    ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:51:33.611661
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # A case return inside generator
    source = '''
        def foo():
            yield "I am in a generator"
            return "I am returning from a generator"
    '''
    expected = '''
        def foo():
            yield "I am in a generator"
            exc = StopIteration()
            exc.value = "I am returning from a generator"
            raise exc
    '''
    actual = ReturnFromGeneratorTransformer().visit(
        ast.parse(source).body[0]  # type: ignore
    )
    assert ast.dump(actual) == ast.dump(ast.parse(expected).body[0])  # type: ignore

    # A case return outside generator

# Generated at 2022-06-23 22:51:35.402164
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Foo(object):
        pass

    a = Foo()
    assert isinstance(a, Foo)


# Generated at 2022-06-23 22:51:38.733458
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source_control import SourceMap
    from ..utils import load_ast

    source_map = SourceMap()

# Generated at 2022-06-23 22:51:44.374210
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform_test

    def test_function(x, y):
        yield x
        yield y
        return x + y

    transformed = transform_test(test_function, ReturnFromGeneratorTransformer)
    assert transformed == '''
        def test_function(x, y):
            yield x
            yield y
            exc = StopIteration()
            exc.value = x + y
            raise exc
    '''

# Generated at 2022-06-23 22:51:48.192544
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def foo():
        yield 1
        return 5

    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    assert ReturnFromGeneratorTransformer().visit(foo) == expected

# Generated at 2022-06-23 22:51:58.308719
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Case1:
        # Function with returns
        # No yield
        # Example:
            # def fn():
            #     return 5
    def fn():
        return 5

    # Case2:
        # Function with returns
        # Has yield
        # Example:
            # def fn():
            #     yield
            #     return 5
    def gn():
        yield
        return 5

    # Case3:
        # Function with no returns
        # Has yield
        # Example:
            # def fn():
            #     yield
    def hn():
        yield

    # Case4:
        # Function with no returns
        # No yield
        # Example:
            # def fn():
            #     pass
    def jn():
        pass


# Generated at 2022-06-23 22:52:01.570624
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_helpers import assert_transformation, transformation_fixture

    code, expected_code = transformation_fixture('return_from_generator')

    assert_transformation(ReturnFromGeneratorTransformer, code, expected_code)

# Generated at 2022-06-23 22:52:05.529926
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    glob = ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0]
    func = ReturnFromGeneratorTransformer()(glob)
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert func.__repr__() == expected

# Generated at 2022-06-23 22:52:15.853883
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class ReturnFromGeneratorTransformerForUnitTest(ReturnFromGeneratorTransformer):
        def __init__(self):
            self._tree_changed = False  # type: bool

        def generic_visit(self, node):
            return node

    transformer = ReturnFromGeneratorTransformerForUnitTest()

    def fn():
        """
        def fn():
            yield 1
            return 5
        """
        yield 1
        return 5

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    def _test_case(return_value: Any, expected: str) -> None:
        code = fn.__code__
        node = ast.parse(code.co_consts[0], "<test>", "exec")
        first_fn

# Generated at 2022-06-23 22:52:18.273504
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t._tree_changed is False
    # assert t._find_generator_returns() == []
    assert t.visit(ast.FunctionDef()) is None

# Generated at 2022-06-23 22:52:19.008948
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:26.301690
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.assertion_hints import assert_ast, assert_source
    source = """
    def my_func():
        yield 1
        return 5
    """
    expected = """
    def my_func():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_ast(tree, expected)
    assert_source(tree, expected)

# Generated at 2022-06-23 22:52:27.343388
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:37.091051
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_unicode
    from ..utils.source import Source

    source1 = Source("""
        def foo():
            return 5
        def bar():
            yield 1
            return 7
    """)
    expected1 = Source("""
        def foo():
            return 5
        def bar():
            yield 1
            exc = StopIteration()
            exc.value = 7
            raise exc
    """)

    source2 = Source("""
        def foo():
            yield 1
            return 'foo'
            yield 2
        def bar():
            return
            yield 1
            return
            yield 2
    """)

# Generated at 2022-06-23 22:52:39.038140
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-23 22:52:46.402005
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from ..utils.fake_context import FakeContext
    context = FakeContext()
    tree = ast3.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )
    transformer = ReturnFromGeneratorTransformer()
    transformed = transformer.visit(tree)
    func_def = transformed.body[0]
    assert func_def.name == "fn"
    assert isinstance(func_def, ast3.FunctionDef)
    expressions = func_def.body
    assert len(expressions) == 2

    # First expression should be yields
    yield_1_expression = expressions[0]
    assert isinstance(yield_1_expression, ast3.Expr)
    assert isinstance(yield_1_expression.value, ast3.Yield)

# Generated at 2022-06-23 22:52:54.352247
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # return_from_generator.get_body() is mocked:
    return_from_generator.get_body.return_value = [1, 2, 3]

    transformer = ReturnFromGeneratorTransformer()
    func_def = ast.parse('def gen(): yield 1; return 5').body[0]
    new_func_def = transformer.visit(func_def)
    assert len(new_func_def.body) == 3
    assert new_func_def.body[0] == 1
    assert new_func_def.body[1] == 2
    assert new_func_def.body[2] == 3

# Generated at 2022-06-23 22:53:00.534248
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse

    node = ast.FunctionDef('fn',
                           ast.arguments(args=[], vararg=None,
                                         kwonlyargs=[], kw_defaults=[],
                                         kwarg=None, defaults=[]),
                           [
                               ast.Pass(),
                               ast.Return(ast.Num(2))
                           ],
                           [],
                           None)

# Generated at 2022-06-23 22:53:09.747246
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()


# Unit tests for ReturnFromGeneratorTransformer().visit_FunctionDef()

# Generated at 2022-06-23 22:53:16.133800
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    def run_test(node, expected_output):
        actual_output = ReturnFromGeneratorTransformer().visit(ast.parse(node))
        assert ast.dump(actual_output) == expected_output

    # Test for functions with return statements with values
    run_test(
        """
        def generator():
            return 5
        """,
        """
        Module(
          body=[
            FunctionDef(
              name='generator',
              args=arguments(
                args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]
              ),
              body=[
                Return(value=Num(n=5)),
              ],
              decorator_list=[],
              returns=None),
          ]
        )
        """,
    )

    # Test for functions

# Generated at 2022-06-23 22:53:19.385927
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert(issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer))


# Generated at 2022-06-23 22:53:24.724849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformer_ast_converter import test_ast
    from ..utils import ast_print
    ast_print.print_ast(test_ast, 'test_ast.py')

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(test_ast)

# Generated at 2022-06-23 22:53:25.774921
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None, None)


# Generated at 2022-06-23 22:53:26.970323
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.get_name() == "ReturnFromGeneratorTransformer"

# Generated at 2022-06-23 22:53:28.697948
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(3, 2)

# Generated at 2022-06-23 22:53:36.506560
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0]

    assert isinstance(fn, ast.FunctionDef)

    transformed_fn = ReturnFromGeneratorTransformer().visit(fn)

    assert len(transformed_fn.body) == 3
    assert isinstance(transformed_fn.body[0], ast.Yield)
    assert isinstance(transformed_fn.body[1], ast.Expr)
    assert isinstance(transformed_fn.body[1].value, ast.Call)
    assert isinstance(transformed_fn.body[2], ast.Raise)

# Generated at 2022-06-23 22:53:43.297306
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from .test_helpers import assert_equal_code
    code = dedent('''\
    def f():
        yield 1
        return 3
    ''')
    expected_code = dedent('''\
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 3
        raise exc
    ''')
    assert_equal_code(code, expected_code, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:53:51.734331
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse('def fn(): yield 1; return 5')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 22:53:57.533475
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    with pytest.raises(AssertionError) as e_info:
        transformer.visit_ClassDef(ast.ClassDef())
    assert 'Not implemented' in str(e_info.value)

    with pytest.raises(AssertionError) as e_info:
        transformer.visit_Lambda(ast.Lambda())
    assert 'Not implemented' in str(e_info.value)

# Generated at 2022-06-23 22:54:06.090486
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_utils import roundtrip
    from .test_utils import transform_test
    from .test_utils import assert_source

    @roundtrip
    def test_simple():
        return '''
        def fn():
            yield 1
            return 2
        '''

    @transform_test(ReturnFromGeneratorTransformer)
    def test_transform():
        return '''
        def fn():
            yield 1
            return 2
        '''

    assert_source(test_simple, """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

    assert_source(test_transform, """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

# Generated at 2022-06-23 22:54:11.958177
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from typed_ast.ast3 import FunctionDef, Return, Yield
    from ..utils.snippet import snippet

    def v(tree):
        node_transformer = ReturnFromGeneratorTransformer()
        node_transformer.visit(tree)
        return tree

    tree = FunctionDef(
        body=[
            Yield(value=None),
            Return(value=None),
            Return(value=None),
        ],
        args=None,
        decorator_list=[],
        name=None,
        returns=None,
    )

# Generated at 2022-06-23 22:54:22.211590
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent

    source = dedent('''
        def foo():
            yield 1
            return 2
    ''')
    expected = dedent('''
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    ''')
    root = ast.parse(source)
    ret = ReturnFromGeneratorTransformer().visit(root)
    assert ast.dump(ret) == ast.dump(ast.parse(expected))

    source = dedent('''
        def foo():
            yield 1
            yield x
            return 2
    ''')
    root = ast.parse(source)
    ret = ReturnFromGeneratorTransformer().visit(root)
    assert ast.dump(ret) == ast.dump(ast.parse(source))

# Generated at 2022-06-23 22:54:26.915481
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse('def fn(): return 1')
    node.body[0].returns_value = True
    node = transformer.visit_FunctionDef(node.body[0])
    assert node.body[0].returns_value == False



# Generated at 2022-06-23 22:54:28.676803
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:54:31.814117
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)
    assert ReturnFromGeneratorTransformer.target == (3, 2)


# Generated at 2022-06-23 22:54:33.068013
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:54:35.834902
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import save_and_run

    @save_and_run
    def main():
        from .utils import parse
        from .utils import compare_ast


# Generated at 2022-06-23 22:54:44.642717
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.source import source
    from ..utils.ast import dump_ast, dump_code
    from ..utils.codegen import to_source

    class ReturnFromGeneratorTransformer(BaseNodeTransformer):
        """docstring for ReturnFromGeneratorTransformer"""

        @staticmethod
        def _find_generator_returns(node):
            """Using bfs find all `return` statements in function."""
            to_check = [(node, x) for x in node.body]
            returns = []
            has_yield = False
            while to_check:
                parent, current = to_check.pop()

                if isinstance(current, ast.FunctionDef):
                    continue

# Generated at 2022-06-23 22:54:49.928001
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generate_ast import generate_ast
    from ..utils.ast_checker import check_equal_asts

    tree = generate_ast("""
        def fn():
            yield 1
            return 5
    """)

    expected_tree = generate_ast("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(tree) == expected_tree
    assert transformer.tree_changed is True
    check_equal_asts(transformer.visit(tree), expected_tree)

# Generated at 2022-06-23 22:55:01.485723
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    case_1 = b'''
    def foo():
        yield 1
        return 5

    def bar():
        yield 1
        return 5
    '''

    case_2 = b'''
    def foo():
        if a:
            yield 1
        else:
            yield 2
        return 5
    '''

    case_3 = b'''
    def foo():
        if a:
            yield 1
        yield 2
        return 5
    '''

    case_4 = b'''
    def generator_fn():
        return 5
    '''

    cases = [case_1, case_2, case_3, case_4]

# Generated at 2022-06-23 22:55:06.275166
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = snippet('''
    def fn():
        yield 1
        return 5
    ''')

    result = snippet('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    transformed = ReturnFromGeneratorTransformer().visit(fn)
    assert transformed == result

# Generated at 2022-06-23 22:55:15.611877
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    fn = tree.body[0]
    yields = [x for x in fn.body if isinstance(x, ast.Yield)]
    returns = [x for x in fn.body if isinstance(x, ast.Return)]
    assert len(yields) == 1
    assert len(returns) == 1

    result = ReturnFromGeneratorTransformer().visit(tree)
    fn = result.body[0]
    yields = [x for x in fn.body if isinstance(x, ast.Yield)]
    returns = [x for x in fn.body if isinstance(x, ast.Return)]
    assert len(yields) == 1
    assert len(returns) == 0


# Generated at 2022-06-23 22:55:24.018155
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_code(self, input_code: str, output_code: str) -> None:
        fd = ast.parse(input_code)
        fn = fd.body[0]
        trans = ReturnFromGeneratorTransformer(None, None)
        new_fn = trans.visit(fn)
        new_fd = ast.Module(new_fn)
        self.assertEqual(ast.dump(new_fd), output_code)

    def test_generator(self, self):
        assert_code(self, """
        def fn():
            yield 1
            return 5
        """, """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)


# Generated at 2022-06-23 22:55:34.206531
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.unparse import unparse
    from astunparse import pprint
    from typed_astunparse import dump

    def test(src):
        node = ast.parse(src)
        node = ReturnFromGeneratorTransformer().visit(node)
        src_astunparse = pprint(node)
        src_unparse = unparse(node)
        src_typed_unparse = dump(node)
        print(src_astunparse)
        print(src_unparse)
        print(src_typed_unparse)
        assert src_astunparse == src_unparse == src_typed_unparse == src

    test("def foo():\n  yield 42\n  return 23\n")

# Generated at 2022-06-23 22:55:35.546021
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # arrange
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:39.330566
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input = """
    def fn():
        yield 1
        return 2
    """
    expected_output = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    node = parse(input)
    ReturnFromGeneratorTransformer().visit(node)
    assert expected_output.strip() == astunparse.unparse(node).strip()



# Generated at 2022-06-23 22:55:40.045410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:40.900286
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:41.737257
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(3, 2)

# Generated at 2022-06-23 22:55:49.418232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_for_generator_return_replacement(source, expected=""):
        if expected == "":
            expected = source
        transpiled = ast_to_source(ReturnFromGeneratorTransformer().visit(source))
        assert transpiled == expected

    test_for_generator_return_replacement('''
            @transform
            def foo():
                return 5
            ''', '')
    test_for_generator_return_replacement('''
            @transform
            def foo():
                yield 5
                return 5
            ''', '''
            @transform
            def foo():
                yield 5
                exc = StopIteration()
                exc.value = 5
                raise exc
            ''')

# Generated at 2022-06-23 22:55:59.421916
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.asserts import assert_node_equal

    tree = ast.parse('''
    def fn():
        yield 1
        return 1
    ''')

    expected_tree = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer({})
    tree = transformer.visit(tree)  # type: ignore

    assert transformer._tree_changed
    assert_node_equal(tree, expected_tree)

    transformer = ReturnFromGeneratorTransformer({})
    tree = transformer.visit(tree)  # type: ignore

    assert not transformer._tree_changed



# Generated at 2022-06-23 22:56:00.379880
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-23 22:56:09.121683
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import BaseNodeTransformerTestCase
    from .test_base import get_ast_tree
    from .test_base import get_source_code
    from .test_base import run_test_with_nodes
    # arrange
    class Test(BaseNodeTransformerTestCase):
        node_transformer = ReturnFromGeneratorTransformer()

        def _test_FunctionDef(self, tree: ast.AST):
            node = tree.body[0]  # type: ast.FunctionDef
            # act
            actual_node = self.node_transformer.visit_FunctionDef(node)
            # assert
            expected_node = get_ast_tree('def func(): yield 1')
            self.assertEqual(len(actual_node.body), 1)

# Generated at 2022-06-23 22:56:14.386553
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def before():
        def fn():
            yield from range(10)
            return 3

    @snippet
    def after():
        def fn():
            yield from range(10)
            exc = StopIteration()
            exc.value = 3
            raise exc

    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(before.as_ast()) == after.as_ast()

# Generated at 2022-06-23 22:56:15.287147
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:26.144732
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ast_helpers import (
        parse,
        find_return_from_generator,
        remove_return_from_generator,
    )
    from .base import BaseNodeTransformer

    code = """\
    def fn():
        yield 1
        return 5
    """
    node = parse(code)
    fn_def = node.body[0]
    has_return_from_generator = len(find_return_from_generator(fn_def)) > 0
    assert has_return_from_generator

    class DemoNodeTransformer(BaseNodeTransformer):
        target = (3, 6)
        def visit_FunctionDef(self, node):
            self._tree_changed = True
            return node
    transformer = DemoNodeTransformer()

# Generated at 2022-06-23 22:56:37.101943
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast
    import textwrap
    from nth.tests.utils import assert_ast

    def check(code_before, code_after):
        code_before = textwrap.dedent(code_before)
        code_after = textwrap.dedent(code_after)

        tree_before = ast.parse(code_before)
        tree_after = ast.parse(code_after)

        transformer = ReturnFromGeneratorTransformer()
        tree_transformed = transformer.visit(tree_before)

        assert_ast(tree_after, tree_transformed)


# Generated at 2022-06-23 22:56:38.870122
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:40.910064
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert hasattr(transformer, 'target')



# Generated at 2022-06-23 22:56:43.009100
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer, "visit_FunctionDef")

# Generated at 2022-06-23 22:56:50.718276
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("Test 1")
    node = ast.parse("""
    def f(x):
        y = 0
        while x > 0:
            y = y+1
            x = x-1
            if x == 2:
                return y
        return y
    """)
    t = ReturnFromGeneratorTransformer()
    t.visit(node)
    print(ast.dump(node))

# Generated at 2022-06-23 22:56:59.825206
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.stub_node import stub
    from ..utils.ast_converter import convert_to_standard_ast

    class Test(object):
        def fn():
            yield 5
            return 10


    module_stub = stub(Test)
    module = convert_to_standard_ast(module_stub)

    func_defs = module.body[2].body
    func_def = func_defs[1]

    rfg_transformer = ReturnFromGeneratorTransformer()

    assert not isinstance(func_def, ast.FunctionDef)
    func_def = rfg_transformer.visit(func_def)
    assert isinstance(func_def, ast.FunctionDef)

    # Return in generator has been replaced with exc raising

# Generated at 2022-06-23 22:57:07.450087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    foo = """
        def foo():
            yield 1
            return 2
    """
    foo_correct = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    foo_ast = ast.parse(dedent(foo))
    foo_correct_ast = ast.parse(dedent(foo_correct))
    transformer = ReturnFromGeneratorTransformer()
    foo_transformed = transformer.visit(foo_ast)
    assert ast.dump(foo_transformed, include_attributes=True) == ast.dump(foo_correct_ast, include_attributes=True)


# Generated at 2022-06-23 22:57:18.078252
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Check if after transform `ReturnFromGeneratorTransformer`
    generates correct code.
    """
    node = ast.parse(
        """
        def function():
            yield 5
            return 10
        """
    )
    node = ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-23 22:57:21.912362
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with open('tests/samples/return.py', 'r') as f:
        src = f.read()
    tree = ast.parse(src)

    result = ReturnFromGeneratorTransformer().visit(tree)
    assert result is not None

# Generated at 2022-06-23 22:57:23.783997
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)


# Generated at 2022-06-23 22:57:33.002616
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Create instance of ReturnFromGeneratorTransformer
    rtg = ReturnFromGeneratorTransformer()
    # Create function with return
    function = ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0]

    # Get the right return and parent line
    returns = rtg._find_generator_returns(function)
    assert len(returns) == 1
    parent, return_ = returns[0]
    assert isinstance(parent, ast.FunctionDef)
    assert isinstance(return_, ast.Return)

    # Replace return with exception raising
    rtg._replace_return(parent, return_)
    # Get code
    code = compile(parent, "<ast>", "exec")
    # Run code and get result
    result = []
    exec(code, None, result)

# Generated at 2022-06-23 22:57:39.704535
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # testing_node:
    """
    def fn():
        yield 1
        return 5
    """
    node = ast.parse(inspect.cleandoc(testing_node)).body[0]  # type: ignore
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal(ast.dump(ReturnFromGeneratorTransformer().visit(node)), expected)



# Generated at 2022-06-23 22:57:45.660618
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    node = ast.parse(
        textwrap.dedent('''
        def fn():
            yield 1
            return 5
        '''))

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer._tree_changed

    expected = textwrap.dedent('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:57:46.533978
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:53.642217
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    source = ast.parse(fn.__code__)
    node = source.body[0]  # type: ast.FunctionDef
    ReturnFromGeneratorTransformer().visit(source)
    assert len(node.body) == 4
    assert isinstance(node.body[2], ast.Assign)
    assert isinstance(node.body[3], ast.Raise)

# Generated at 2022-06-23 22:57:59.413636
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')
    expected = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-23 22:58:08.671225
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def run_test(test_input, expected):
        tree = ast.parse(test_input)
        transformer = ReturnFromGeneratorTransformer()
        new_tree = transformer.visit(tree)
        assert expected == ast.unparse(new_tree)

    # Empty FunctionDef
    test_input = """
        async def foo(a, b):
            pass
    """
    expected = test_input
    run_test(test_input, expected)

    # No generators
    test_input = """
        def foo():
            return 42
    """
    expected = test_input
    run_test(test_input, expected)

    # Generator without return
    test_input = """
        def foo():
            yield 42
    """
    expected = test_input
    run_test(test_input, expected)

   

# Generated at 2022-06-23 22:58:19.223876
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test class 'ReturnFromGeneratorTransformer'"""
    transformer = ReturnFromGeneratorTransformer()
    func_def = ast.parse("""
        def fn():
            yield 1
            return 5
    """).body[0]
    transformer.visit(func_def)
