

# Generated at 2022-06-23 22:48:19.232519
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:48:22.831179
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..tools import show_tree
    node = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')

    tree = ReturnFromGeneratorTransformer().visit(node)
    show_tree(tree)
    print(ast.dump(tree))



# Generated at 2022-06-23 22:48:28.826223
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = '''
    def generator():
        yield 1
        return 5
    '''
    expected = '''
    def generator():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    output = ReturnFromGeneratorTransformer().visit(ast.parse(source))
    expected_output = ast.parse(expected)
    assert ast.dump(output) == ast.dump(expected_output)


# Generated at 2022-06-23 22:48:30.094809
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:48:36.561079
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Example of function body before transformation
    function_def = ast.FunctionDef(
        name='g',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Yield(
                value=ast.Num(n=1)
            ),
            ast.Return(
                value=ast.Num(n=5)
            )
        ],
        decorator_list=[],
        returns=None
    )
    
    # Expected function body after transformation

# Generated at 2022-06-23 22:48:48.121491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    tree = ast.parse('def fn(): yield 1; return 5')
    tree = ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-23 22:48:49.281973
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:48:50.625931
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a = ReturnFromGeneratorTransformer()
    assert a is not None

# Generated at 2022-06-23 22:48:59.189100
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class ReturnFromGeneratorTransformer_visit_FunctionDef_TestCase(unittest.TestCase):
        def test_return(self):
            def fn():
                yield 1
                return 5

            expected = \
"""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
            self.assertEqual(expected, str(fn))

        def test_nested_return(self):
            def fn():
                yield 1
                if True:
                    return 5

            expected = \
"""def fn():
    yield 1
    if True:
        exc = StopIteration()
        exc.value = 5
        raise exc"""
            self.assertEqual(expected, str(fn))

        def test_return_with_argument(self):
            def fn():
                return

# Generated at 2022-06-23 22:49:05.486399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import get_ast, get_node

    # 1. No return
    generator_func = """
        def fn():
            yield 1
            yield 2
    """
    tree = get_ast(generator_func)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == False
    assert tree.body[0].body == [get_node('yield 1'), get_node('yield 2')]

    # 2. Single return
    generator_func = """
        def fn():
            yield 1
            return 2
    """
    tree = get_ast(generator_func)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True

# Generated at 2022-06-23 22:49:14.905080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_case import TestCase

    source = """
        def a():
            return 1
        def b():
            yield 1
        def c():
            yield 1
            yield 2
            return 3
        def d():
            pass
        def e():
            yield 1
            return 2
    """
    expected_output = """
        def a():
            return 1
        def b():
            yield 1
        def c():
            yield 1
            yield 2
            exc = StopIteration()
            exc.value = 3
            raise exc
        def d():
            pass
        def e():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    with TestCase(source, expected_output, ReturnFromGeneratorTransformer) as test:
        test.assert_

# Generated at 2022-06-23 22:49:17.253967
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:49:18.393262
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:22.388711
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    import ast as python_ast
    import sys
    input_source = '''def fn():
    yield 1
    return 5'''
    expected_output = '''def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc'''
    module = ast.parse(input_source)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(module)
    assert astunparse.unparse(result).strip() == expected_output.strip()

# Generated at 2022-06-23 22:49:25.547496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_transformer_on_expression(expr, expected_expr):
        transformer = ReturnFromGeneratorTransformer()
        new_expr = transformer.visit(expr)
        assert str(new_expr) == expected_expr

# Generated at 2022-06-23 22:49:26.545220
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:49:27.744369
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer('', '', {})



# Generated at 2022-06-23 22:49:28.892082
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()._tree_changed == False


# Generated at 2022-06-23 22:49:30.241717
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t


# Generated at 2022-06-23 22:49:36.088641
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''def fn(): yield 1; return 5'''
    expected_code = '''def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc'''
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    actual_code = astor.to_source(tree).strip()
    assert expected_code == actual_code

# Generated at 2022-06-23 22:49:46.398556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = """\
    def fn():
        yield 1
        return 5
    """

    node = ast.parse(fn)
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:49:53.403433
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astunparse

    code = """
        def gen(num):
            if not num:
                return 0
            else:
                yield from range(num)
                return 1

        def gen2(num):
            try:
                yield from range(num)
                return 1
            except:
                return 2
    """

    expected = """
        def gen(num):
            if not num:
                return 0
            else:
                yield from range(num)
                exc = StopIteration()
                exc.value = 1
                raise exc

        def gen2(num):
            try:
                yield from range(num)
                exc = StopIteration()
                exc.value = 1
                raise exc
            except:
                return 2
    """

    expected = expected.strip()
    tree = ast.parse(code)

# Generated at 2022-06-23 22:49:54.447032
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print('test')

# Generated at 2022-06-23 22:49:55.628438
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:50:06.240313
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""

    fdef = ast.FunctionDef(name='fn',
                           body=[
                               ast.Yield(value=ast.Constant(1)),
                               ast.Return(value=ast.Constant(5)),
                           ],
                           decorator_list=[],
                           args=ast.arguments())
    expected = ast.Module(body=[])
    expected.body.extend([ast.Expr(value=return_from_generator.get_snippet())])

# Generated at 2022-06-23 22:50:13.088824
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn1():
        yield 1

    def fn2():
        yield 1
        return 5

    node1 = ast.parse(fn1.__code__).body[0]
    node2 = ast.parse(fn2.__code__).body[0]

    trans = ReturnFromGeneratorTransformer()
    node1 = trans.visit(node1)
    assert not hasattr(node1, '_changed')
    assert trans.get_tree_changed() == False

    node2 = trans.visit(node2)
    assert not hasattr(node2, '_changed')
    assert trans.get_tree_changed() == True

# Generated at 2022-06-23 22:50:14.594516
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    from ..utils import ast_utils


# Generated at 2022-06-23 22:50:17.648169
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    # Case 1: return in generator

# Generated at 2022-06-23 22:50:22.304575
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    module = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)
    assert ast.dump(module) == expected

# Generated at 2022-06-23 22:50:32.611555
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformer import transform
    from .test_transformer import generate_code
    from ..utils.common import runtime_import, mk_fake_module
    runtime_import('typed_ast.ast3')

    def f(x):
        y = x + 1
        for i in range(x):
            yield i
            if i > 10:
                return i
        else:
            return y

    f2 = transform(ast.parse(generate_code(f)), ReturnFromGeneratorTransformer)
    module = mk_fake_module(transformed_ast=f2)

    assert module.f(0) == 1
    assert list(module.f(1)) == [0]
    assert list(module.f(2)) == [0, 1]

# Generated at 2022-06-23 22:50:40.413835
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tf = ReturnFromGeneratorTransformer()
    tfa = tf.visit(ast.parse('''
        def fn():
            yield 1
            return 5
    '''))
    rfag = return_from_generator.get_ast()
    ast.fix_missing_locations(tfa)


# Generated at 2022-06-23 22:50:50.172624
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal


# Generated at 2022-06-23 22:50:53.160299
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transform = ReturnFromGeneratorTransformer()
    func = ast.parse('def test(): yield 1').body[0]
    func = transform.visit(func)
    assert isinstance(func, ast.FunctionDef)


# Generated at 2022-06-23 22:50:55.932830
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:02.331423
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    function = parse('''
        def fn():
            yield 1
            a = yield 2
            return 5
    ''')
    transformer.visit(function)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:51:03.368147
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:51:08.719527
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Tests ReturnFromGeneratorTransformer on function without generator return"""
    fn = ast.parse("def foo(): return 5")
    xf = ReturnFromGeneratorTransformer()
    tree = xf.visit(fn)
    compiled_tree = compile(tree, '', 'exec')
    namespace = {}
    exec(compiled_tree, namespace)
    foo = namespace['foo']
    assert foo() == 5


# Generated at 2022-06-23 22:51:17.613150
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    from ..utils import goto

    # Define test node
    return_node = ast.Return(ast.Constant(5, kind=None))
    function_def_node = ast.FunctionDef(
        'fn',
        ast.arguments(
            [], [], None, []),
        [ast.Yield(ast.Constant(1, kind=None)), return_node],
        [])

    # Run transformer
    transformer = ReturnFromGeneratorTransformer()
    tree_changed, node = transformer.visit(function_def_node)

    # Test
    assert tree_changed == True
    assert goto.get_return_value(node) == 5

# Generated at 2022-06-23 22:51:18.778015
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert not transformer._tree_changed

# Generated at 2022-06-23 22:51:20.259176
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import parse
    import astunparse

# Generated at 2022-06-23 22:51:21.248122
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:23.682060
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t.__class__.__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-23 22:51:28.289419
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """, mode='exec')  # type: ast.AST

    ast.fix_missing_locations(node)
    result = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(result) == """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """


# Generated at 2022-06-23 22:51:29.089796
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:30.874517
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:37.704475
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import typed_astunparse  # type: ignore

    # Testcase 1
    code = """
    def foo():
        yield from range(1, 5)
        return 5
"""
    tree = ast.parse(code)
    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(tree)

    expected_code = """
    def foo():
        yield from range(1, 5)
        exc = StopIteration()
        exc.value = 5
        raise exc
"""
    expected_tree = ast.parse(expected_code)
    expected_tree_string = typed_astunparse.unparse(expected_tree)

    tree_string = typed_astunparse.unparse(tree)
    assert tree_string == expected_tree_string, tree_string

    # Testcase 2
   

# Generated at 2022-06-23 22:51:47.868677
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test(fn):
        tree = ast.parse(fn)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        source = compile(tree, '<test>', 'exec')
        exec(source)

    def test_generator():
        yield 1
        return 5

    def test_generator_with_if():
        yield 1
        if True:
            return 5
        else:
            return 8

    def test_generator_with_elif():
        yield 1
        if True:
            return 5
        elif False:
            return 8
        else:
            return 11

    def test_generator_with_while():
        yield 1
        while False:
            return 5

    def test_generator_with_for():
        yield 1

# Generated at 2022-06-23 22:51:49.684559
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:59.120053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.setup_test import setup_test
    from .helpers import transform, assert_code_equal

    setup_test()

    T = ReturnFromGeneratorTransformer()

    def __test(test_input, expected):
        tree = transform(test_input, T)
        assert_code_equal(tree, expected)

    code = """
        def func():
            yield 1
            return 1
    """
    expected = """
        def func():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
    """
    __test(code, expected)

    code = """
        def func():
            yield 1
            if True:
                return 2
            else:
                return 3
    """

# Generated at 2022-06-23 22:52:00.970725
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    c = ReturnFromGeneratorTransformer()
    assert c

test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:08.218033
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def test(
        code: str,
        result: str,
        test_snippets: bool = False,
        test_function_name: bool = False,
    ):
        tree = ast.parse(code)
        ReturnFromGeneratorTransformer().visit(tree)
        result_code = astor.to_source(tree)
        if test_snippets:
            result_snippets = [
                (line.start - 1, line.end - 1)
                for line in ast.walk(tree)
                if isinstance(line, ReturnFromGeneratorTransformer.Snippet)
            ]
            result_snippets.sort()
            result_code = result_snippets

        if test_function_name:
            result_code = tree.body[0].name
        assert result_code == result

# Generated at 2022-06-23 22:52:09.607123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-23 22:52:18.973402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    root = ast.parse('def fn(): yield 1; return 5')
    node = root.body[0]
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    assert len(new_node.body) == 4
    assert isinstance(new_node.body[0], ast.Expr)
    assert isinstance(new_node.body[0].value, ast.Yield)
    assert new_node.body[0].value.value.n == 1
    assert isinstance(new_node.body[1], ast.Assign)
    assert isinstance(new_node.body[2], ast.Assign)
    assert isinstance(new_node.body[3], ast.Raise)



# Generated at 2022-06-23 22:52:25.675524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node1 = ast.parse('def fn(): yield 1\nreturn 1').body[0]
    node2 = ast.parse('def fn():\n    yield 1\n    return 1').body[0]

    res1 = ReturnFromGeneratorTransformer().visit(node1)
    res2 = ReturnFromGeneratorTransformer().visit(node2)
    
    assert res1.__repr__() == res2.__repr__()

# Generated at 2022-06-23 22:52:27.133566
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:36.888213
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Function contains return statement in body
    node = ast.parse('def fn(): return 5')
    ret_return = node.body[0].body[0]
    assert isinstance(ret_return, ast.Return)
    assert ret_return.value.n == 5

    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(node)

    body = res.body[0].body
    assert len(body) == 2
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[1], ast.Raise)
    assert body[1].exc.func.id == 'StopIteration'
    assert isinstance(body[1].exc.args[0], ast.Num)
    assert body[1].exc.args[0].n == 5

    # Function contains return statement in body

# Generated at 2022-06-23 22:52:45.497510
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:55.100449
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    path = "simple_example.py"
    with open(path, "r") as source:
        source = source.read()
        tree = ast.parse(source)
        tree = ReturnFromGeneratorTransformer().visit(tree)
        assert isinstance(tree, ast.Module)
        tree = ast.fix_missing_locations(tree)
        tree = ast.increment_lineno(tree, 1)
        codeobj = compile(tree, path, 'exec')

        globs = {}
        exec(codeobj, globs)  # pylint: disable=exec-used

        self = globs['self']  # pylint: disable=undefined-variable
        assert self.init_called is True
        self.init_called = False


# Generated at 2022-06-23 22:53:02.160593
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    o = ReturnFromGeneratorTransformer()
    code = """
    def fn():
        yield 1
        return 2
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    actual = compile(ast.parse(code), '', 'exec')
    expected = compile(ast.parse(expected), '', 'exec')
    assert o.visit(actual) == expected.body[0]


# Generated at 2022-06-23 22:53:03.111558
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:11.543222
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import cStringIO
    import contextlib
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import (
        FunctionDef, Pass, Assign, Name, Store, Expr, Call, Attribute, Arg, Num
    )
    from ..target import TargetInfo
    from ..transform import TransformInfo
    from ..evaluator import Evaluator

    cls = ReturnFromGeneratorTransformer

    ast_tree = ast.parse("""\
        def fn(a, b):
            yield a
            return b
    """).body[0]
    assert isinstance(ast_tree, FunctionDef)
    assert cls.is_target_node(ast_tree)

    # Make sure node is compiled successfully to Python 2.7

# Generated at 2022-06-23 22:53:12.666057
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compile import compile

# Generated at 2022-06-23 22:53:23.501577
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """def fn():
        yield 1
        return 2

    def fn2():
        yield 1
        return 2
        return 3

    def fn3():
        a = 1 + yield 2
        return 3

    def fn4():
        yield
        return 2

    def fn5():
        yield 1
        return

    def fn6():
        def fn7():
            return 2
        return 2

    def fn8():
        if True:
            return 2"""

# Generated at 2022-06-23 22:53:24.416721
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:53:31.182169
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef in ReturnFromGeneratorTransformer."""
    node_transformer = ReturnFromGeneratorTransformer()
    node = ast.parse('''
    def f():
        yield 1
        yield 2
        return 3
    ''')
    expected = ast.parse('''
    def f():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 3
        raise exc
    ''')
    assert node_transformer.generic_visit(node) == expected

# Generated at 2022-06-23 22:53:39.646649
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_snippet(arg1, arg2):
        a1 = 10
        for i in range(arg1):
            yield a1
            a1 = 20
            return a1

    expected_output = """def test_snippet(arg1, arg2):
    a1 = 10
    for i in range(arg1):
        yield a1
        a1 = 20
        exc = StopIteration()
        exc.value = a1
        raise exc

    """

    node = ast.parse(inspect.getsource(test_snippet))
    ReturnFromGeneratorTransformer().visit(node)
    output = astor.to_source(node)
    assert output == expected_output



# Generated at 2022-06-23 22:53:41.400973
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert(x is not None)

# Generated at 2022-06-23 22:53:45.221366
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('def a(): yield 1;return 5')
    transformer = ReturnFromGeneratorTransformer.from_node(node)
    assert transformer.code == 'def a(): yield 1;exc = StopIteration();exc.value = 5;raise exc' # noqa: E501


# Generated at 2022-06-23 22:53:46.159041
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-23 22:53:53.909271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    tree = ast.parse("""
    def function_with_return():
        yield 1
        return 5
    def function_without_return():
        return 5
    def function_with_return_in_if():
        yield 5
        if True:
            return 7
        yield 8
    def function_with_yield_in_try():
        try:
            yield 5
        finally:
            return 7
    def function_with_yield_in_try_2():
        try:
            yield 5
        except Exception:
            return 7
        finally:
            return 8
    def function_with_yield_in_try_3():
        try:
            yield 5
        finally:
            return 7
        return 8
    """)

# Generated at 2022-06-23 22:53:55.030157
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:58.620218
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..tests.utils import assert_equal_ast
    assert_equal_ast(ReturnFromGeneratorTransformer, '''
    def fn():
        yield 1
        return 2
    ''')


__all__ = [
    'ReturnFromGeneratorTransformer'
]

# Generated at 2022-06-23 22:54:06.837731
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')

    xformed = ReturnFromGeneratorTransformer().visit(node)
    second_return = xformed.body[0].body[1].body[2]

    assert isinstance(second_return, ast.Expr)
    assert isinstance(second_return.value, ast.Call)
    assert isinstance(second_return.value.func, ast.Name)
    assert second_return.value.func.id == 'StopIteration'
    assert second_return.value.args[0] is None

    assert isinstance(second_return.value.keywords[0].value, ast.Call)
    assert isinstance(second_return.value.keywords[0].value.func, ast.Attribute)
    assert second

# Generated at 2022-06-23 22:54:13.956390
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest

    class ReturnFromGeneratorTransformerTest(unittest.TestCase):
        def test_empty(self):
            node = ast.parse(
                text='''
                def f():
                    pass
                '''
            )
            ReturnFromGeneratorTransformer().visit(node)
            self.assertEqual(
                node,
                ast.parse(
                    text='''
                    def f():
                        pass
                    '''
                )
            )

        def test_no_yield(self):
            node = ast.parse(
                text='''
                def f():
                    return 5
                '''
            )
            ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-23 22:54:18.970671
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Make instance of class ReturnFromGeneratorTransformer
    example = ReturnFromGeneratorTransformer()
    # Test if a certain class is chosen to use for this unit test
    assert type(example) == ReturnFromGeneratorTransformer
    # Test if the __init__ function is functioning properly
    assert example.target == (3, 2)

# Generated at 2022-06-23 22:54:25.124670
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..parser import get_parser
    from ..main import get_transformed_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    ast_tree = get_parser('3.6').parse(code)
    ast_tree_transformed = get_transformed_ast(ast_tree, [ReturnFromGeneratorTransformer])

    assert isinstance(ast_tree_transformed.body[0].body[1], ast.Expr)

    assert isinstance(ast_tree_transformed.body[0].body[2], ast.Assign)

    assert isinstance(ast_tree_transformed.body[0].body[3], ast.Raise)


# Generated at 2022-06-23 22:54:34.809059
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestClass(ReturnFromGeneratorTransformer):
        def _replace_return(self, parent, return_):
            self.returns.append((parent, return_))

    class Test:
        def method():
            yield 12
            return 2

    test_class = TestClass()
    test_class.returns = []
    test_class._find_generator_returns(ast.parse(inspect.getsource(Test.method)).body[0])  # type: ignore
    assert test_class.returns == [(ast.parse(inspect.getsource(Test.method)).body[0],
                                   ast.parse(inspect.getsource(Test.method)).body[0].body[1])]  # type: ignore


# Generated at 2022-06-23 22:54:43.665033
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from .transformer_test_case import TransformerTestCase, run_transformer_test_cases

    class TestTransformer(TransformerTestCase):
        transformer = ReturnFromGeneratorTransformer
        method = 'visit_FunctionDef'

        def test_return_from_generator(self):
            before = """
            def fn():
                yield 1
                return 5
            """
            after = """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """

            self.assertCodeBeforeAndAfter(before, after)

        def test_not_generator_return(self):
            before = """
            def fn():
                yield 1
            """
            after = """
            def fn():
                yield 1
            """

           

# Generated at 2022-06-23 22:54:51.480930
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class RecursiveTransformer(Transformer):
        def __init__(self, compile_fn):
            self._compile_fn = compile_fn
            self._exports = []

        def get_exports(self) -> List[str]:
            return self._exports

        def visit_Module(self, node: ast.Module) -> ast.Module:
            return node

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.Module:
            assert self._compile_fn is None or self._compile_fn == node.name
            self._exports.append(node.name)
            return ast.Module([node])  # type: ignore


# Generated at 2022-06-23 22:54:59.645210
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import prettify, get_node

    def test(function: ast.FunctionDef, expected: ast.FunctionDef) -> None:
        node_transformer = ReturnFromGeneratorTransformer({})
        expected_function = prettify(expected)

        actual_function = node_transformer.visit(function)
        actual_function = prettify(ast.fix_missing_locations(actual_function))

        assert actual_function == expected_function


# Generated at 2022-06-23 22:55:03.001199
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def f():
        yield 1
        return 5

    transformer = ReturnFromGeneratorTransformer()
    ast.fix_missing_locations(transformer.visit(ast.parse(inspect.getsource(f))))

# Generated at 2022-06-23 22:55:04.078291
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:13.697111
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Configure test cases
    test_cases = []
    test_cases.append(
        ( 
            ast.parse("""
                def foo():
                    yield 1
                    return 2
            """),
            ast.parse("""
                def foo():
                    yield 1
                    exc = StopIteration()
                    exc.value = 2
                    raise exc
            """),
            True,
        )
    )
    test_cases.append(
        ( 
            ast.parse("""
                def foo():
                    yield 1
                    return 2
                    yield 3
            """),
            ast.parse("""
                def foo():
                    yield 1
                    exc = StopIteration()
                    exc.value = 2
                    raise exc
                    yield 3
            """),
            True,
        )
    )

# Generated at 2022-06-23 22:55:19.424238
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformed = ReturnFromGeneratorTransformer().visit(
        ast.parse('''
        def foo():
            yield
            return 5
        '''))
    expected = ast.parse('''
    def foo():
        yield
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    expected = expected.body[0]  # type: ignore
    assert transformed == expected

# Generated at 2022-06-23 22:55:21.573550
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert isinstance(x, BaseNodeTransformer)
    assert x.target == (3, 2)



# Generated at 2022-06-23 22:55:26.834295
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    source = """
    def foo():
        yield 1
        return 2
    """
    expected = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    source_ast = ast.parse(source)
    source_ast.body[0] = transformer.visit(source_ast.body[0])
    assert astor.to_source(source_ast) == expected

# Generated at 2022-06-23 22:55:28.855608
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None, None)
    assert transformer


# Generated at 2022-06-23 22:55:38.043743
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class EmptyNode:
        body = []

    class ValueNode:
        def __init__(self, value):
            self.value = value

    class YieldNode:
        def __init__(self):
            self.value = ValueNode(0)

    class YieldFromNode:
        def __init__(self):
            self.iter = ValueNode(0)

    class ReturnNode(ValueNode):
        pass

    class Tree:
        def __init__(self, body):
            self.body = body

    class FunctionDefinitionNode(Tree):
        pass

    # Case 0: generator with return outside of any loops.
    body = [
        YieldNode(),
        ReturnNode(ValueNode(0))
    ]
    ret = ReturnFromGeneratorTransformer().visit(FunctionDefinitionNode(body))

# Generated at 2022-06-23 22:55:44.537625
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from seven.visitors.to_source import to_source
    from seven import unittest

    class Test(unittest.TestCase):
        def test_1(self):
            code = """
                def fn():
                    yield 1
                    return 5
            """
            node = ast.parse(code)
            ReturnFromGeneratorTransformer().visit(node)
            self.assertEqual(
                to_source(node),
                """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc

                """
            )

        def test_2(self):
            code = """
                def fn():
                    if a:
                        yield 1
                        return 5

                    yield 3
            """
            node = ast.parse(code)

# Generated at 2022-06-23 22:55:49.969779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """def fn():
    yield 1
    return 5
    """
    node = ast.parse(code)

    result = ReturnFromGeneratorTransformer().visit(node)

    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
    """
    expected_result = ast.parse(expected)

    assert ast.dump(result) == ast.dump(expected_result)

# Generated at 2022-06-23 22:55:51.563383
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:53.324658
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert "StopIteration" in str(ReturnFromGeneratorTransformer)



# Generated at 2022-06-23 22:56:03.253365
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    def fn___return():
        yield 1
        return 5

    def fn___return_nested():
        yield 1
        while True:
            yield 2
            if a:
                return 5

    fn_tree = ast.parse(fn___return.__code__)
    fn_tree = fn_tree.body[0]  # type: ignore
    transformer.visit(fn_tree)
    exec(compile(fn_tree, '<string>', 'exec'), globals())
    assert list(fn___return()) == [1, 5]

    fn_tree = ast.parse(fn___return_nested.__code__)
    fn_tree = fn_tree.body[0]
    transformer.visit(fn_tree)

# Generated at 2022-06-23 22:56:05.538826
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class _Parser:
        def parse(self, source):
            return ast.parse(source)


# Generated at 2022-06-23 22:56:09.444574
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # create instance of ReturnFromGeneratorTransformer class
    returnFromGeneratorTransformer = ReturnFromGeneratorTransformer()
    # assert that instance of ReturnFromGeneratorTransformer class is created
    assert returnFromGeneratorTransformer



# Generated at 2022-06-23 22:56:18.987163
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import should_not_change, should_change, unit_test_ast_builder
    from ..utils.tooling import ASTPrintVisitor

    def test_should_not_change(node):
        should_not_change(ReturnFromGeneratorTransformer(), node)  # type: ignore

    def test_should_change(source, expected_source):
        should_change(ReturnFromGeneratorTransformer(), source, expected_source)  # type: ignore

    test_should_not_change(unit_test_ast_builder("def fn(): 5"))  # type: ignore
    test_should_not_change(unit_test_ast_builder("def fn(): a = 5"))  # type: ignore
    test_should_not_change(unit_test_ast_builder("def fn(): yield 1"))  # type: ignore
    test

# Generated at 2022-06-23 22:56:28.750361
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    class_def = ast.parse('class ClassName:\n'
                          '    def generator_method(self):\n'
                          '        yield 1\n'
                          '        yield 2\n'
                          '        return 5\n'
                          '    def empty_generator(self):\n'
                          '        yield 1\n'
                          '        return 5\n'
                          '    def regular_method(self):\n'
                          '        a = 1\n'
                          '        return 5\n'
                          ).body[0]


# Generated at 2022-06-23 22:56:36.497115
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    function_def = _parse_function_def("""
    def fn():
        yield 1
        return 5
    """)
    assert (return_from_generator_transformer._find_generator_returns(function_def)
            == [(function_def, function_def.body[1])])  # type: ignore
    assert (return_from_generator_transformer._find_generator_returns(_parse_function_def("""
    def fn():
        return 5
    """)) == [])


# Generated at 2022-06-23 22:56:38.535663
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:56:39.450435
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:49.094957
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    import os
    import astor
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    from transformers.base import BaseNodeTransformer

    class transformer(BaseNodeTransformer):
        target = (3, 8)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            node = astor.to_source(node)
            return node  # type: ignore

    input_1 = """
    def foo():
        for i in range(10):
            yield 1
            return i
    """
    transformer = transformer()
    x = """function_ = transformer.visit(ast.parse(input_1))"""


# Generated at 2022-06-23 22:56:57.698678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    from typed_ast.ast3 import parse as ast_parse
    from .control_flow import ControlFlowOptimizer
    from ..utils.ast_helper import print_ast
    import astor

    tree = ast_parse('''
    def generator():
        yield 1
        return 5
    ''')
    tree = ReturnFromGeneratorTransformer()(tree)
    tree = ControlFlowOptimizer()(tree)

    expected = '''
    def generator():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 22:56:59.926486
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    import astor as astor
    
    # Test Code

# Generated at 2022-06-23 22:57:00.867798
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer  # silence pyflakes

# Generated at 2022-06-23 22:57:07.100831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    result = ""
    code = "def f():\n    yield 1\n    return 5"
    expected = "def f():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    for line in ast.dump(new_tree).split("\n"):
        result += line.lstrip()
    assert result == expected

# Generated at 2022-06-23 22:57:17.370049
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from ..utils.test_utils import assert_programs_equal

    def source():
        def fn():
            yield 1
            return 5
        pass
    def expected():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        pass

    tree = ast.parse(source())
    expected_tree = ast.parse(expected())

    transformer = ReturnFromGeneratorTransformer()
    actual_tree = transformer.visit(tree)

    print("actual tree:")
    print(ast.dump(actual_tree))
    print("expected tree:")
    print(ast.dump(expected_tree))
    assert_programs_equal(actual_tree, expected_tree)



# Generated at 2022-06-23 22:57:28.837055
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import pytest

    from typed_ast import ast3 as ast

    from ..case_transformer import case
    from ..utils import codegen


# Generated at 2022-06-23 22:57:35.739349
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import UnitTestTransformer
    from ..utils.source import source

    gen_fn_return = 'def fn(): yield 1; return 5'
    compiled_fn_return = 'def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc'
    transformer = UnitTestTransformer(ReturnFromGeneratorTransformer())
    result = transformer.visit_and_transform(source(gen_fn_return))
    assert result == compiled_fn_return

# Generated at 2022-06-23 22:57:45.088391
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import unittest
    from typed_ast import ast3 as ast

    class TestVisit(unittest.TestCase):
        def check(self, before: str, after: str) -> None:
            transformer = ReturnFromGeneratorTransformer()
            res = transformer.visit(ast.parse(before))
            self.assertEqual(after, str(res).strip())

        def test_return_generator(self):
            before = """
            def fn():
                a = 5
                yield 1
                return a

            def fn2():
                return 1
            """
            after = """
            def fn():
                a = 5
                yield 1
                exc = StopIteration()
                exc.value = a
                raise exc

            def fn2():
                return 1
            """
            self.check(before, after)


# Generated at 2022-06-23 22:57:51.718835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import _ast
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = _ast.parse(source)  # type: ignore
    ReturnFromGeneratorTransformer().visit(tree)
    result = _ast.unparse(tree, '<string>', 'exec')  # type: ignore
    assert result == expected

# Generated at 2022-06-23 22:58:02.693999
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import math
    import random
    import sys
    import typing
    from codegen import CodeGen
    from ..utils.function_generator import FunctionGenerator
    from ..utils.test_utils import assert_code_equal
    from .simple_transformer import SimpleTransformer
    from .return_in_lambda_transformer import ReturnInLambdaTransformer


# Generated at 2022-06-23 22:58:07.212120
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform, compare
    source = """
        def fn():
            yield 1
            return 5
        """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    transform(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-23 22:58:17.686849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .transformer import Transformer as Transformer3
    from .unused_assignment_remover import UnusedAssignmentRemover
    from .dead_code_remover import DeadCodeRemover
    from ..utils.node_visitor import NodeVisitor
    from ..utils.ast_compare import compare_asts
    import astunparse

    code = """
                     def gen():
                         yield 1
                         return
    """
    expected = """
                     def gen():
                         yield 1
                         exc = StopIteration()
                         exc.value =
                         raise exc
    """

    tree = ast.parse(code)
    transformer = Transformer3([UnusedAssignmentRemover, DeadCodeRemover,
                                ReturnFromGeneratorTransformer], {})
    tree = transformer(tree)
    actual

# Generated at 2022-06-23 22:58:26.222787
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Test():
        def __init__(self, tree):
            self._tree = tree
            self._transformer = ReturnFromGeneratorTransformer()

        def test_basic(self):
            t = ast.parse(
                """
                def fn():
                    yield 2
                    return 2
                """
            )
            res = ast.parse(
                """
                def fn():
                    yield 2
                    exc = StopIteration()
                    exc.value = 2
                    raise exc
                """
            )
            self._transformer.visit(t)
            #assert ast.dump(t) == ast.dump(res)
