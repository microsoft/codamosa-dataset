

# Generated at 2022-06-23 22:48:28.289917
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    module = parse(
        'def fn(): yield 1 return 2',
        mode='exec'
    )
    node = module.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert isinstance(module, ast.Module)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)

    result = to_source(module)
    expected = [
        'def fn():',
        '    yield 1',
        '    exc = StopIteration()',
        '    exc.value = 2',
        '    raise exc'
    ]
    assert result == expected

# Generated at 2022-06-23 22:48:29.484983
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator.get_body()

# Generated at 2022-06-23 22:48:35.350183
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    FunctionDef = ast.FunctionDef
    Return = ast.Return
    generator_returns = [Return(value=None)]
    # Test find_generator_returns
    node = FunctionDef(name='', args=None, body=[], decorator_list=[], returns=None)
    rfg = ReturnFromGeneratorTransformer()
    assert rfg._find_generator_returns(node) == []
    node.body.append(Return(value=5))
    assert rfg._find_generator_returns(node) == generator_returns


# Generated at 2022-06-23 22:48:41.415170
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import Compiler

    code = """
    def a():
        yield 1
        return 5
    """

    expected_code = """
    def a():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    tree = Compiler().visit(tree)
    result = ast.unparse(tree)

    assert result == expected_code

# Generated at 2022-06-23 22:48:42.955218
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:48:53.376120
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Unit test for ReturnFromGeneratorTransformer
    import unittest
    import sys
    import astor
    from ..utils import compile_source

    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def test_return_is_replaced(self):
            src = """
            def fn(a):
                if a:
                    return 5
                else:
                    return 3
            """
            expected = """
            def fn(a):
                if a:
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                else:
                    exc = StopIteration()
                    exc.value = 3
                    raise exc
            """
            tree = compile_source(src, '<test>', 'exec')
            tree = ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:48:54.268714
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:49:01.789841
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Compiles return in generators:
    #     def fn():
    #         yield 1
    #         return 5
    # To:
    #     def fn():
    #         yield 1
    #         exc = StopIteration()
    #         exc.value = 5
    #         raise exc

    class FunctionDef:
        def __init__(self, body):
            self.body = body
    class Return:
        def __init__(self, value=None):
            self.value = value
    class Yield:
        pass
    class YieldFrom:
        pass
    class Attribute:
        def __init__(self, value, attr):
            self.value = value
            self.attr = attr
        def get_node(self):
            return self

# Generated at 2022-06-23 22:49:08.643218
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        pass
    assert not ReturnFromGeneratorTransformer()._find_generator_returns(fn.__code__.co_consts[0])

    def fn():
        yield

    assert not ReturnFromGeneratorTransformer()._find_generator_returns(fn.__code__.co_consts[0])

    def fn():
        yield
        return 5

    assert ReturnFromGeneratorTransformer()._find_generator_returns(fn.__code__.co_consts[0])

# Generated at 2022-06-23 22:49:16.857050
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.compat import to_tuple
    from .test_comments import strip_comments
    from .test_make_generator import transform as make_generator
    from .test_make_generator import make_generator_test as make_generator_test
    from .test_make_generator import visit_FunctionDef as make_generator_FunctionDef

    # Test case #1: return in generator
    def test_case_1():
        def fn():
            yield 1
            return 5

        fn = transform(fn, [make_generator, ReturnFromGeneratorTransformer])

# Generated at 2022-06-23 22:49:23.308795
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn(x):
        if x == 3:
            return 4

        yield 1
        return 5

    visitor = ReturnFromGeneratorTransformer()
    ast_ = ast.parse(fn)
    ast_ = visitor.visit(ast_)  # type: ignore
    code = compile(ast_, '<test>', 'exec')
    exec(code)

    assert fn(x=3) == 4
    assert list(fn(x=1)) == [1]

# Generated at 2022-06-23 22:49:27.313319
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:37.549997
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def_func = ast.FunctionDef(name='fn',
                               body=[
                                   ast.Yield(value=1),
                                   ast.Return(value=5)
                               ],
                               decorator_list=[],
                               returns=None,
                               args=ast.arguments(args=[],
                                                  vararg=None,
                                                  kwonlyargs=[],
                                                  kw_defaults=[],
                                                  kwarg=None,
                                                  defaults=[]),
                               async_=False)

# Generated at 2022-06-23 22:49:40.997010
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    Code = """
    def fn():
        yield 1
        return 5

    def fn2():
        yield from [1, 2, 3]
    """
    print(ReturnFromGeneratorTransformer().visit(ast.parse(Code)))

# Generated at 2022-06-23 22:49:50.380131
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def run_test(node, expected_node):
        class_name = ReturnFromGeneratorTransformer.__name__
        namespace = globals()
        namespace[class_name] = ReturnFromGeneratorTransformer
        namespace['return_from_generator'] = return_from_generator
        transformer = namespace[class_name]()
        actual_node = transformer.visit(node)
        assert_equal(ast.dump(actual_node), ast.dump(expected_node))

    def fn_with_return():
        yield 1
        return 5

    def fn_with_return_expected():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc


# Generated at 2022-06-23 22:50:00.972758
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node: ast.FunctionDef):
            return True

        def _replace_return(self, parent: Any, return_: ast.Return) -> None:
            assert parent == node
            assert return_ == ast.Return(2)
            assert node.body[1] == ast.Return(2)
            node.body.pop(1)
            node.body.append(ast.Expr(ast.Call(ast.Name("foo", ast.Load()), [], [])))

    node = ast.FunctionDef("f", ast.arguments([], [], [], [], None, []), [ast.Return(1), ast.Return(2)], [])

# Generated at 2022-06-23 22:50:02.416514
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:50:05.887233
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = '''
    def test():
        yield 1
        return 1
    '''
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse(code).body[0])


# Generated at 2022-06-23 22:50:07.451327
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:10.545665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.unparse import Unparser

    def compare(source):
        tree = ast.parse(source)  # type: ignore
        ReturnFromGeneratorTransformer().visit(tree)
        return Unparser(tree).unparse()

    # Test 1

# Generated at 2022-06-23 22:50:12.700915
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from .constant_folding import ConstantFoldingTransformer
    from .constant_propagation import ConstantPropagationTransformer


# Generated at 2022-06-23 22:50:17.254622
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    to_test = ast.parse(code)
    expected = ast.parse(expected)
    actual = ReturnFromGeneratorTransformer().visit(to_test)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 22:50:26.131089
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent

# Generated at 2022-06-23 22:50:29.295385
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    return_from_generator_transformer.visit(None)
    assert return_from_generator_transformer is not None

# Generated at 2022-06-23 22:50:31.042479
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == \
        "ReturnFromGeneratorTransformer"

# Generated at 2022-06-23 22:50:39.820358
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  transformer = ReturnFromGeneratorTransformer()

  # test normal case with return in generator
  source = """
  def fn():
    yield 1
    return 5
  """
  node = ast.parse(source)
  node = transformer.visit(node)

  expected = """
  def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
  """
  expected_node = ast.parse(expected)

  assert ast.dump(node) == ast.dump(expected_node)

  # test that nothing changes if there are no generators in code
  source = """
  def fn(a):
    for a in range(a):
      return 5
  """
  node = ast.parse(source)
  node = transformer.visit(node)


# Generated at 2022-06-23 22:50:41.096681
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:50:50.449763
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit tests for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    # Construct function definition node to be transformed
    function_def_node = ast.FunctionDef(name='fn',
                                        args=ast.arguments(args=[],
                                                           vararg=None,
                                                           kwonlyargs=[],
                                                           kw_defaults=[],
                                                           kwarg=None,
                                                           defaults=[]),
                                        body=[ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
                                              ast.Return(value=ast.Num(n=5))],
                                        decorator_list=[],
                                        returns=None)

    # Construct expected function definition node

# Generated at 2022-06-23 22:50:56.133697
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import pytest
    from typed_ast import parse, ast3
    from ..utils.test_utils import transform, compare_source

    def run_test(src, expected_src):
        module = parse(src)
        assert isinstance(module, ast3.Module)
        tree_changed, module, _ = transform(ReturnFromGeneratorTransformer(), module)
        compare_source(module, expected_src)


    @pytest.mark.parametrize('src', [
        'def fn():\n    return 3\n',
        'def fn():\n    yield 1\n    return 3\n'
    ])
    def test_no_changes(src):
        run_test(src, src)


    src = '''def fn():
        yield 1
        return 4
    '''


# Generated at 2022-06-23 22:50:56.856708
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None  # noqa: S101

# Generated at 2022-06-23 22:51:03.465743
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
        def gen():
            yield 1

            if True:
                return 5

            return 4
    """
    ast_ = ast.parse(code)
    ast_.body[0].body[1].value = ast.Num(1)  # type: ignore
    ast_.body[0].body[1].test = ast.NameConstant(True)  # type: ignore

    new_ast = ReturnFromGeneratorTransformer().visit(ast_)
    assert ast.dump(ast_) != ast.dump(new_ast)

# Generated at 2022-06-23 22:51:06.763558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = ReturnFromGeneratorTransformer
        

# Generated at 2022-06-23 22:51:10.447351
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator = ReturnFromGeneratorTransformer()
    assert isinstance(return_from_generator, BaseNodeTransformer)



# Generated at 2022-06-23 22:51:20.508323
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import ast_converter
    from .remove_with_statements import RemoveWithStatementsTransformer
    body = """
    def foo():
        a = b
        yield 4
        return 5
    """
    converted = ast_converter.parse(body)
    ReturnFromGeneratorTransformer().visit(converted)
    RemoveWithStatementsTransformer().visit(converted)
    expected = """
    def foo():
        a = b
        yield 4
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected = ast_converter.parse(expected)
    assert expected == converted, \
        '%s != %s' % (expected, converted)


# ______________________________________________________________________


# Generated at 2022-06-23 22:51:22.401121
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:51:29.582463
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ...errors import UnsupportedPythonError
    from ..transformers.remove_asserts import RemoveAssertsTransformer
    from ...utils.source import source
    from .loop_unrolling import LoopUnrollingTransformer
    from .remove_pass import RemovePassTransformer
    from .remove_brackets import RemoveBracketsTransformer
    from .remove_docstrings import RemoveDocstringsTransformer
    from .remove_locals import RemoveLocalsTransformer
    from .constant_folding import ConstantFoldingTransformer
    from .remove_asserts import RemoveAssertsTransformer
    from .remove_lambda import RemoveLambdaTransformer
    from .remove_unused_vars import RemoveUnusedVarsTransformer
    from .remove_unpacking import RemoveUnpackingTransformer
    from .remove_unpacking_assign import RemoveUnpackingAssignTrans

# Generated at 2022-06-23 22:51:31.745951
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer is not None

# Generated at 2022-06-23 22:51:32.955280
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()
    assert rfgt is not None


# Generated at 2022-06-23 22:51:38.290199
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer()
    try:
        assert f._find_generator_returns('3') == []
    except:
        pass
    try:
        assert f._find_generator_returns('a') == []
    except:
        pass
    try:
        assert f._find_generator_returns('[1,2]') == []
    except:
        pass
    try:
        assert f._find_generator_returns('()') == []
    except:
        pass
    try:
        assert f._find_generator_returns('{a:1,b:2}') == []
    except:
        pass

# Generated at 2022-06-23 22:51:39.024195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:43.895835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    start_fn = """
    def fn():
        yield 1
        return 5
    """

    expected_fn = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    actual_fn = ReturnFromGeneratorTransformer().reduce(start_fn)
    assert expected_fn == actual_fn

# Generated at 2022-06-23 22:51:55.141806
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    function_def_node = ast.FunctionDef(name="fun_def",
                                        args=ast.arguments(args=[], vararg=None,
                                                           kwonlyargs=[], kw_defaults=[],
                                                           kwarg=None, defaults=[]),
                                        body=[ast.Expr(ast.Yield(ast.Constant(1))),
                                              ast.Return(ast.Constant(5))],
                                        decorator_list=[],
                                        returns=None)

# Generated at 2022-06-23 22:52:01.543103
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fake_ast import get_fake_ast_from_parse_tree

    t = ReturnFromGeneratorTransformer()
    tree = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    fn_node = tree.body[0]
    tree_changed = t.visit(tree)
    assert tree_changed == True
    assert t._tree_changed == True
    assert t._find_generator_returns(fn_node) == [(fn_node, fn_node.body[1])]

    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

    tree = get_fake_ast_from_parse_tree(t.generic_visit(fn_node))
   

# Generated at 2022-06-23 22:52:02.763080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:52:03.943415
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__ == ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:04.514159
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:14.851955
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from_source = source_to_ast(ReturnFromGeneratorTransformer._find_generator_returns.__func__)

    assert from_source('''
        def fn():
            yield 1
            return 5
    ''') == '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''


# Generated at 2022-06-23 22:52:21.032561
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  from ..utils.source_code import SourceCode
  from ..utils.ast_builder import AstBuilder
  from ..utils.ast_transformer import AstTransformer
  ast_builder = AstBuilder()
  source_code = SourceCode("def fn():\n   yield 1\n   return 5\n")
  node = ast_builder.string_to_ast(source_code.code)
  ast_transformer = AstTransformer()
  ast_transformer.register_transformer(ReturnFromGeneratorTransformer)
  node = ast_transformer.visit(node)
  source_code = SourceCode("def fn():\n   yield 1\n   exc = StopIteration()\n   exc.value = 5\n   raise exc\n", True)
  assert str(ast_builder.ast_to_string(node)) == source_

# Generated at 2022-06-23 22:52:30.924208
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class MockNode(object):
        pass

    class MockBody(list):
        pass

    class MockFuncDef(MockNode):
        pass

    class MockParent(MockNode):
        pass

    class MockReturn(MockNode):
        pass

    func_def = MockFuncDef()
    func_def.body = MockBody()
    parent = MockParent()
    parent.body = MockBody()
    parent.body.append(MockNode())
    parent.body.append(MockReturn())
    parent.body.append(MockNode())
    func_def.body.append(parent)

    transformer = ReturnFromGeneratorTransformer()
    result = transformer._find_generator_returns(func_def)
    assert result == [(parent, parent.body[1])]
    assert transformer._replace_

# Generated at 2022-06-23 22:52:40.118377
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # return_from_generator_transformer_visit_FunctionDef_gen
    @snippet
    def orig(x):
        def f():
            if x > 5:
                return 7

            yield x + 5

        return f()

    # return_from_generator_transformer_visit_FunctionDef_exp
    @snippet
    def exp(x):
        let(exc)
        def f():
            if x > 5:
                exc = StopIteration()
                exc.value = 7
                raise exc

            yield x + 5

        return f()

    node = orig.get_ast(3)
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    exp.compare(ast.parse(ast.unparse(node)))



# Generated at 2022-06-23 22:52:42.546416
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Test:
        def foo(self):
            yield 1
            return 5
    
    ReturnFromGeneratorTransformer().visit(Test)
    assert Test.foo.__code__.co_flags & 16



# Generated at 2022-06-23 22:52:43.089952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:52.522279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
        def fn():
            yield 1
            return 5
    ''')

    expected_source = source_to_unicode('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    expected_tree = ast.parse(expected_source)
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    assert tree == expected_tree
    assert transformer._tree_changed is True



# Generated at 2022-06-23 22:52:53.413151
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:55.376290
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  pass
#   instance = ReturnFromGeneratorTransformer()
#   assert instance.__class__.__name__ == "ReturnFromGeneratorTransformer"

# Generated at 2022-06-23 22:53:02.922832
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import assert_text_transformation

    assert_text_transformation(ReturnFromGeneratorTransformer, """
        def gen():
            yield 1
            return 2
        """, """
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """)

    assert_text_transformation(ReturnFromGeneratorTransformer, """
        def gen():
            yield 1
            return
        """, """
        def gen():
            yield 1
            return
        """)

# Generated at 2022-06-23 22:53:03.884408
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None, None)

# Generated at 2022-06-23 22:53:04.501368
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:06.178019
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:53:12.519517
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    node = ast.parse(dedent('''\
        def f(a):

            def g():
                return a

            yield 1
            return 2
        '''))

    expected = ast.parse(dedent('''\
        def f(a):

            def g():
                return a

            yield 1
            exc = StopIteration
            exc.value = 2
            raise exc
        '''))

    transformer = ReturnFromGeneratorTransformer()

    actual = transformer.visit(node)

    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 22:53:16.789769
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    transformer = ReturnFromGeneratorTransformer()
    def_ = ast.FunctionDef(
        name='fn',
        args=ast.arguments([], None, None, []),
        body=[
            ast.Expr(ast.Yield(ast.Num(1))),
            ast.Return(ast.Num(5))
        ],
        decorator_list=[],
        returns=None)

# Generated at 2022-06-23 22:53:22.966046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def x():
        yield 1
        return 5

    node = ast.parse(inspect.getsource(x))
    node = ReturnFromGeneratorTransformer().visit(node)
    code = compile(node, '<>', 'exec')
    got = fn = None
    exec(code, globals(), locals())
    assert got == 5



# Generated at 2022-06-23 22:53:32.532502
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer(),
        ast.parse('def fn(): yield 1').body[0],
    ) == []

    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer(),
        ast.parse('def fn(): return 1').body[0],
    ) == []

    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer(),
        ast.parse('def fn(): yield 1; return 2').body[0],
    ) == [(ast.parse('def fn(): yield 1; return 2').body[0].body[0], ast.parse('return 2').body[0])]


# Generated at 2022-06-23 22:53:38.836188
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_optimizer import optimize_code
    from .test_optimizer import assert_optimized_code

    test_code = """
    def test() -> None:
        i = 5
        yield i
        return 5
    """
    optimized_code = """
    def test() -> None:
        i = 5
        yield i
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_optimized_code(test_code, optimized_code, [ReturnFromGeneratorTransformer])



# Generated at 2022-06-23 22:53:46.235028
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_module = build_ast("""
        import cs50
        def fn():
            yield 1
            return 2
    """)
    fn = ast_module.body[1]
    assert len(fn.body) == 5

    fn = ReturnFromGeneratorTransformer().visit(fn)
    assert len(fn.body) == 7
    assert isinstance(fn.body[4], ast.Assign)
    assert isinstance(fn.body[5], ast.Raise)
    assert len(fn.body[5].exc.args) == 0

# Generated at 2022-06-23 22:53:47.812768
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:56.645552
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_ast = """
    a = "def"
    b = [1, 2, 3]

    def fn():
        yield 1
        return 5

    def fn1():
        return 5

    yield from [1, 2, 3]
    """
    expected_ast = """
    a = "def"
    b = [1, 2, 3]

    def fn():
        yield 1

        exc = StopIteration()
        exc.value = 5
        raise exc

    def fn1():
        return 5

    yield from [1, 2, 3]
    """
    actual_ast = ReturnFromGeneratorTransformer().visit(ast.parse(test_ast))
    assert astor.to_source(actual_ast) == expected_ast

# Generated at 2022-06-23 22:54:00.687816
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    fn_ = ReturnFromGeneratorTransformer().visit(ast.parse(dedent(fn.__doc__)))  # type: ignore
    assert compile(fn_, '', 'exec') == compile(dedent(fn.__doc__), '', 'exec')

# Generated at 2022-06-23 22:54:01.591638
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:54:08.728817
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.__code__.co_code)
    tree = ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:54:09.925959
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-23 22:54:11.822724
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:14.632989
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from ..utils.visitor import Visitor
    transformer = Visitor(ReturnFromGeneratorTransformer)

    # Simple example.

# Generated at 2022-06-23 22:54:20.949406
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import compile_snippet, round_trip

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    output = round_trip(compile_snippet(source, version='3.2'), version='3.2')

    assert output == expected



# Generated at 2022-06-23 22:54:32.107883
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    # create root node
    node = ast.Module([])
    # create FunctionDef nodes
    node_0 = ast.FunctionDef(name='fn', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Yield(value=ast.Num(n=1)), ast.Return(value=ast.Num(n=5))], decorator_list=[], returns=None)
    node_0_parent = node
    node_0_parent.body = [node_0]

    expected_node = ast.Module([])
    # create FunctionDef nodes (transformed)

# Generated at 2022-06-23 22:54:40.443693
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Simple case: the return statement is in the outer most body of the function
    code_str = """
    def fn():
        yield 1
        return 5
    """
    results = ReturnFromGeneratorTransformer.run_it(code_str)

# Generated at 2022-06-23 22:54:49.018032
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Transform function with no returns
    def some_function():
        yield 1
        yield 2

    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(inspect.getsource(some_function))
    transformer.visit(node)

    assert transformer._tree_changed is False
    assert ast.dump(node) == ast.dump(ast.parse(inspect.getsource(some_function)))

    # Transform function with one return and one yield
    def some_function():
        yield 1
        return 2

    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(inspect.getsource(some_function))
    transformer.visit(node)

    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:55:00.509455
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    f = ast.FunctionDef
    g = ast.arguments
    l = ast.arg
    o = ast.Lambda
    t = ast.Return
    u = ast.Str
    v = ast.Name
    w = ast.Yield
    x = ast.Add
    y = ast.Num
    z = ast.List

# Generated at 2022-06-23 22:55:02.110092
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() == ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:55:06.324941
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    fn = ast.parse("""
        def fn():
            pass
    """).body[0]
    node = transformer.visit_FunctionDef(fn)
    assert isinstance(node, ast.FunctionDef)


# Generated at 2022-06-23 22:55:08.693623
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast as pyast
    from typed_ast.ast3 import parse as ast_parse
    from pprint import pprint


# Generated at 2022-06-23 22:55:17.122527
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    expected_output = \
    """\
    def f(a):
        x = 10
        try:
            yield x
        except BaseException as e:
            e = e.__cause__ if e.__suppress_context__ else e
            raise e
        return 5
    """

    input_code = \
    """\
    def f(a):
        x = 10
        yield x
        return 5
    """

    tree = ast.parse(input_code)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    output_code = ast.unparse(tree)
    assert output_code == expected_output

# Generated at 2022-06-23 22:55:24.622496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_case(node, expected_node):
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)

        assert transformer._tree_changed
        assert ast.dump(node) == ast.dump(expected_node)

    # Simple generator case
    node = ast.parse(
        dedent('''\
        def fn():
            yield 1
            return 5
        ''')
    )
    expected_node = ast.parse(
        dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')
    )

    test_case(node, expected_node)

    # Complex generator case

# Generated at 2022-06-23 22:55:31.877271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .ast_builder import ast_builder

    tree = ast_builder("""
    def fn():
        yield 1
        return 5
    """, version=(3, 8))

    expected_tree = ast_builder("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """, version=(3, 8))

    tree_0 = ReturnFromGeneratorTransformer()
    tree_0.visit(tree)

    assert tree == expected_tree


# Generated at 2022-06-23 22:55:37.702348
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .visitor import WrappedVisitor
    node = ast.parse('def fn(): yield 1; return 2')
    transformer = ReturnFromGeneratorTransformer()
    visitor = WrappedVisitor()
    visitor.visit(transformer.visit(node))
    assert visitor.tree_changed == True
    assert visitor.result == '\ndef fn():\n    yield 1\n    import sys\n    exc = StopIteration()\n    exc.value = 2\n    raise exc\n'

# Generated at 2022-06-23 22:55:44.194068
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_me():
        def fn():
            yield 1
            return 5
        return fn

    module = ast.parse(test_me.__code__)
    module = ReturnFromGeneratorTransformer().visit(module)
    module = ast.fix_missing_locations(module)

    fn = module.body[0].value.body[0]
    assert fn.body[1].value.func.id == 'StopIteration'
    assert fn.body[2].value.func.id == 'StopIteration'
    assert fn.body[3].value.func.id == 'StopIteration'
    assert fn.body[4].value.func.id == 'StopIteration'
    assert fn.body[5].value.func.id == 'StopIteration'

# Generated at 2022-06-23 22:55:44.872402
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:55.419341
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def decorate(func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    @snippet
    def code():
        let(x)
        x = 1

        @decorate
        def foo():
            x = 2
            yield 1

            @decorate
            def bar():
                x = 3
                yield 2
                return x*2

            @decorate
            def baz():
                yield 3
                return x*3

            yield from bar()
            yield from baz()
            return x*4

        yield from foo()

    node = ast.parse(code.get_code())
    transformer = ReturnFromGeneratorTransformer('', {})
    transformer.visit(node)

    assert code.get_code() == transformer.get_new_code

# Generated at 2022-06-23 22:56:01.312739
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    code = """def fn():\n    yield 1\n    return 5"""
    exec(code)
    expected_result = """def fn():
    yield 1
    exc: StopIteration = StopIteration()
    exc.value = 5
    raise exc"""
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert astor.to_source(tree) == expected_result

# Generated at 2022-06-23 22:56:04.528895
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """

    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    result_source = ast.unparse(result)
    assert result_source == expected_source

# Generated at 2022-06-23 22:56:06.228964
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generator_wrapping import GeneratorWrappingTransformer

    # 1.

# Generated at 2022-06-23 22:56:16.682885
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()

    # Method 1: test actual code in compile() method:
    source_code = '''
        def test_gen():
            yield 1
            return 2
        '''
    root = ast.parse(source_code)
    t.visit(root)
    compiled_code = compile(root, filename='', mode='exec')
    local_variables = {}
    exec(compiled_code, None, local_variables)
    gen_obj = local_variables['test_gen']()
    assert gen_obj.__next__() == 1
    with pytest.raises(StopIteration) as exception:
        gen_obj.__next__()
    assert exception.value.value == 2

    # Method 2: test source code of transformed ast:

# Generated at 2022-06-23 22:56:27.349542
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    @snippet
    def function():
        yield 1
        return 5

    @snippet
    def function1():
        yield 1

    @snippet
    def function2():
        let(x)
        x = 5
        return x
        yield 1

    @snippet
    def function3():
        yield 1
        if 1:
            return 5
        return 6

    @snippet
    def function4():
        yield 1
        print(5)
        return 5

    @snippet
    def function5():
        yield 1
        return
        yield 2

    @snippet
    def function6():
        yield from [1, 2, 3]

    @snippet
    def function7():
        yield from range(10)
       

# Generated at 2022-06-23 22:56:37.911994
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.fake import FakeParser
    node = FakeParser().parse_str('''
        def fn():
            yield 1
            return 5
    ''')
    node = ReturnFromGeneratorTransformer(None).visit(node)

# Generated at 2022-06-23 22:56:44.964115
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    hello = ast.parse("def hello():\n\tyield 1\n\treturn 5")
    trans = ReturnFromGeneratorTransformer()
    actual = ast.dump(trans.visit(hello), include_attributes=True)
    expected = ast.dump(ast.parse("def hello():\n\tyield 1\n\texc = StopIteration()\n\texc.value = 5\n\traise exc"), include_attributes=True)
    assert actual == expected

# Generated at 2022-06-23 22:56:47.620308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_nodes_equals
    from typed_ast import ast3 as ast
    from ..transforms.return_from_generator import ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:56:48.335054
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:49.035794
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:50.334485
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)._tree_changed == False


# Generated at 2022-06-23 22:56:58.363323
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal, get_ast

    source = '''
        def fn(x):
            yield x
            return 5
    '''

    expected_source = '''
        def fn(x):
            yield x
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    node = get_ast(source)
    expected_node = get_ast(expected_source)

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert_source_equal(new_node, expected_node)
    assert transformer._tree_changed == True


# Generated at 2022-06-23 22:56:59.681893
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:57:04.880977
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source = '''
        def fn():
            yield 1
            return 5
    '''
    expected_source = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    tree = ast.parse(source)  # type: ignore
    transformer.visit(tree)
    assert ast.dump(tree) == expected_source

# Generated at 2022-06-23 22:57:06.860206
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for the ReturnFromGeneratorTransformer class."""
    from .test_BaseNodeTransformer import check_transformer


# Generated at 2022-06-23 22:57:18.036512
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class src:
        def fn_return_from_generator():
            yield 4
            return 5

        def fn_return_from_generator_complex():
            yield 4
            if 1 > 2:
                yield 5
                return 6
            return 7

        def fn_empty_generator():
            yield 4

        def fn_no_generator():
            return 5


# Generated at 2022-06-23 22:57:28.958655
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tester import make_snapshot_on_error

    make_snapshot_on_error(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return 5

        def fn2():
            if True:
                yield 1
                return 5
        """
    )

    make_snapshot_on_error(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            if True:
                yield 1
            elif False:
                yield 2
            return 5
        """
    )

    make_snapshot_on_error(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            for x in range(1, 3):
                yield 1
            return 5
        """
    )


# Generated at 2022-06-23 22:57:33.953503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .helpers import assert_equal_ast
    from ..utils import load_ast_tree
    source = """def fn():\n    yield 1\n    return 5"""
    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    tree = load_ast_tree(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-23 22:57:36.350851
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # All the assertions are false. If the code compiles and passes, it means
    # that no unit test is missing
    assert False


# Generated at 2022-06-23 22:57:41.079523
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    module = ast.parse('def fn(): yield 1; return 5')
    node = module.body[0]
    transformer = ReturnFromGeneratorTransformer()
    # Verify
    assert transformer.visit_FunctionDef(node) == ast.parse('def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc')

# Generated at 2022-06-23 22:57:47.483050
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ast import FunctionDef, Yield, Return


# Generated at 2022-06-23 22:57:51.154482
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    assert BaseNodeTransformer in ReturnFromGeneratorTransformer.__bases__
    assert 3.2 in ReturnFromGeneratorTransformer.target  # type: ignore

# Generated at 2022-06-23 22:58:02.138249
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fdef = ast.FunctionDef(
        name='foo',
        args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
        body=[
            ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
            ast.Return(value=ast.Num(n=5))
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-23 22:58:03.478138
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor  # type: ignore

# Generated at 2022-06-23 22:58:08.521618
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
    def fn():
        yield 1
        return 5
    '''

    expected_code = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(code)
    transformer.visit(tree)
    assert ast.dump(tree) == expected_code



# Generated at 2022-06-23 22:58:11.442069
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:22.048851
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    source = '''
    def f():
        yield 1
        return 5
    '''
    tree = ast.parse(source)
    tree = transformer.visit(tree)
    assert transformer._tree_changed, 'Transformer did not change tree.'