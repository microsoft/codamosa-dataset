

# Generated at 2022-06-23 22:48:29.442733
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_asts
    from .test_snippets import return_from_generator_source
    ast_ = ast.parse(return_from_generator_source)
    ReturnFromGeneratorTransformer().visit(ast_)
    ast.fix_missing_locations(ast_)
    assert_equal_asts(ast_, ast.parse("""
    import sys

    def gen():
        yield 5
        exc = StopIteration()
        exc.value = 'Canceled'
        raise exc
    """))

# Generated at 2022-06-23 22:48:34.511218
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse(
        '''def fn():
            yield 1
            return 5'''
    )
    refactored_tree = ReturnFromGeneratorTransformer().visit(tree)
    expected_tree = ast.parse(
        '''def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc'''
    )
    assert ast.dump(refactored_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:48:40.384401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fdef = ast.parse(
        '''
        def fn():
            yield 1
            return 5
        '''
    )
    fdef2 = ast.parse(
        '''
        def fn():
            if True:
                yield 1
            else:
                return 5
        '''
    )
    fdef3 = ast.parse(
        '''
        def fn():
            yield 1
            if True:
                return 5
        '''
    )
    fdef4 = ast.parse(
        '''
        def fn():
            yield 1
            def fn2():
                return 5
        '''
    )
    fdef5 = ast.parse(
        '''
        def fn():
            yield 1
            class C:
                return 5
        '''
    )

    transformer = ReturnFrom

# Generated at 2022-06-23 22:48:41.369928
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:52.424498
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_node(node):
        ReturnFromGeneratorTransformer().visit(node)
        return node

    generator_def = ast.parse("""
        def generator():
            x = 5
            yield 1
            return x
    """).body[0]
    expected = ast.parse("""
        def generator():
            x = 5
            yield 1
            exc = StopIteration()
            exc.value = x
            raise exc
    """).body[0]

    assert test_node(generator_def) == test_node(expected)

    generator_def = ast.parse("""
        def generator():
            x = 5
            yield 1
            return x
            yield 2
    """).body[0]

# Generated at 2022-06-23 22:49:02.999861
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..node_util import node_to_str, get_func_names, compare_nodes

    class Test(BaseNodeTransformerTest):
        transformer = ReturnFromGeneratorTransformer
        code = """\
        def fn():
            yield 1
            return 5
        """
        expected_code = """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

        def run_test(self):
            self.assert_node(self.node)
            self.assert_generators((
                ('fn', (1, 1), (3, 4), 1),
            ))
            self.assert_returns((
                ('fn', (2, 5), (2, 10)),
            ))
            self.assert_

# Generated at 2022-06-23 22:49:03.917182
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:07.831794
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import get_node
    tree = get_node('def fn(): yield 1; return 5', is_funcdef=True)
    converted = ReturnFromGeneratorTransformer().visit(tree)
    assert converted.body[1].value.func.id == 'StopIteration'

# Generated at 2022-06-23 22:49:15.613895
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(input, expected_output):
        input_ast=ast.parse(input)
        expected_output_ast=ast.parse(expected_output)
        transformer=ReturnFromGeneratorTransformer()
        new_ast = transformer.visit(input_ast)
        if new_ast != expected_output_ast:
            print('INPUT AST')
            print(ast.dump(input_ast))
            print('EXPECTED OUTPUT')
            print(ast.dump(expected_output_ast))
            print('OUTPUT AST')
            print(ast.dump(new_ast))
        assert(new_ast == expected_output_ast)


# Generated at 2022-06-23 22:49:19.025563
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:27.424331
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import inspect

    def check(node, transformed_node):
        assert node == transformed_node or inspect.getsource(transformed_node) == inspect.getsource(node)

    def check_returns(fn, *args):
        generator_returns = ReturnFromGeneratorTransformer._find_generator_returns(ReturnFromGeneratorTransformer, fn)
        assert args == tuple(x[1] for x in generator_returns)

    # Check if module with no generators is handled correctly
    fn1 = lambda: 1
    check(fn1, ReturnFromGeneratorTransformer.visit(fn1))

    # Check if generator with no returns is handled correctly
    def fn2():
        yield 1
    check(fn2, ReturnFromGeneratorTransformer.visit(fn2))
    check_returns(fn2)

    #

# Generated at 2022-06-23 22:49:31.964264
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer) is True, 'ReturnFromGeneratorTransformer constructor is wrong'


# Unit tests for the _get_returns method within class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:40.186086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test ReturnFromGeneratorTransformer.visit_FunctionDef method. """
    code = """
    def g():
        if x:
            return 5
        yield 1
    """
    expected = """
    def g():
        if x:
            exc = StopIteration()
            exc.value = 5
            raise exc
        yield 1
    """

    node = ast.parse(code)
    rfgt = ReturnFromGeneratorTransformer()
    rfgt.visit(node)
    code2 = astor.to_source(node)
    assert code2 == expected



# Generated at 2022-06-23 22:49:45.875425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import Base
    from typed_ast import ast3 as ast

    class Src(Base):
        def fn():
            yield 1
            return 5

    expected = Src()
    expected.fn.body[1] = return_from_generator.get_body(return_value=ast.Constant(5))

    node = Src()
    ReturnFromGeneratorTransformer().visit(node)

    assert node == expected

# Generated at 2022-06-23 22:49:53.271875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    ast1 = ast.parse('''
        def fn():
            yield 1
            return 5''')

    ast2 = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc''')

    ast3 = ast.parse('''
        def fn():
            yield 1
            return 5
            return 2
            ''')

    ast4 = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            exc = StopIteration()
            exc.value = 2
            raise exc
            ''')


# Generated at 2022-06-23 22:49:55.633440
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer


# Generated at 2022-06-23 22:49:57.724933
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__ == ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:50:01.954354
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast.parse
    code = ast.parse(return_from_generator.code)
    return_ = code.body[0].body[0].body[1]
    transformer = ReturnFromGeneratorTransformer()
    return_ = transformer.visit(return_)
    assert return_ is not None

# Generated at 2022-06-23 22:50:03.008771
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:04.916740
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transpile import transpile
    from .range_transformer import RangeTransformer


# Generated at 2022-06-23 22:50:07.579246
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.target == (3, 2)


# Unit tests for method _find_generator_returns of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:13.510663
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    return_node = ast.Return()
    return_node.value = ast.Num()
    return_node.value.n = 9

    def_node = ast.FunctionDef()
    def_node.body = [return_node]

    result = transformer.visit_FunctionDef(def_node)  # type: ignore
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.Assign)
    assert isinstance(result.body[1], ast.Raise)

# Generated at 2022-06-23 22:50:20.743495
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    import ast
    import sys
    import io

    node = ast.parse('def fn():\n  yield 1\n  return 5')
    ReturnFromGeneratorTransformer().visit(node)
    expected = 'def fn():\n  yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc'
    out = io.StringIO()
    unparse(node, out)
    assert out.getvalue() == expected

# Generated at 2022-06-23 22:50:31.615360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import transformers
    from ..utils.codegen import CodeGen
    from ..utils.snippet import snippet
    from .base import TransformerTestCase

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    class TestCase(TransformerTestCase):
        transformer = transformers.ReturnFromGeneratorTransformer
        transform_snippets = [(source, expected)]
        expected_imports = ['from typed_ast import ast3', 'from ..utils.snippet import snippet']
        expected_codegen_options = {'source_encoding': 'utf-8', 'filename': '<unknown>'}


# Generated at 2022-06-23 22:50:38.369483
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = textwrap.dedent(
    '''\
    def fn():
        yield 1
        return 5
    ''')
    tree = ast.parse(code)
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    expected = textwrap.dedent(
    '''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert ast.dump(result) == expected



# Generated at 2022-06-23 22:50:43.693274
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    trans = ReturnFromGeneratorTransformer()

    def fn():
        yield 1
        return 'hi'


# Generated at 2022-06-23 22:50:47.472630
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('''
        def fn():
            yield 1
            return 5
        ''')
    assert ReturnFromGeneratorTransformer().visit(node) == ast.parse('''
        def fn():
            import typing
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')



# Generated at 2022-06-23 22:50:55.367974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test:
        def generator():
            yield 1
            return True

        def function():
            yield 1
            yield 2
            return True

        def no_yield():
            return True

    assert Test.generator.__code__.co_flags & 0x20 == 0
    assert Test.function.__code__.co_flags & 0x20 == 0
    assert Test.no_yield.__code__.co_flags & 0x20 != 0

    @snippet
    def assert_function(function):
        code = function.__code__
        assert code.co_flags & 0x20 == 0
        assert code.co_flags & 0x80 != 0

        assert function().__next__() == 1
        assert function().__next__() == 2


# Generated at 2022-06-23 22:50:59.759384
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Unit test for visit_FunctionDef method of class
    # ReturnFromGeneratorTransformer
    # Test that transformation is performed when return in
    # generator is present.
    code = """
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(code)
    rfg = ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-23 22:51:01.258866
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    import typed_astunparse

# Generated at 2022-06-23 22:51:10.208775
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet, let
    from ..utils.context import temp_node
    from ..utils.environment import get_ast

    with temp_node(BaseNodeTransformer, ReturnFromGeneratorTransformer) as node:
        with snippet:
            @let(fn)
            def fn():
                yield 1
                return 5

            @let(fn)
            def fn():
                def fn():
                    yield 1
                    return 5
                return fn


# Generated at 2022-06-23 22:51:11.319544
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:21.788414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import inspect
    import ast as PythonAst
    import unittest
    import textwrap

    class Test(unittest.TestCase):
        def test(self):
            suite = unittest.TestSuite()
            suite.addTest(TestCase("test_simple_generator"))
            suite.addTest(TestCase("test_complex_generator"))

            unittest.TextTestRunner().run(suite)

        def test_simple_generator(self):
            class SimpleGeneratorTransformer(ReturnFromGeneratorTransformer):
                def visit_Return(self, return_: PythonAst.Return) -> PythonAst.Return:
                    self._tree_changed = True

                    exc = PythonAst.Name("exc")
                    exc_value = PythonAst.Name("exc_value")

# Generated at 2022-06-23 22:51:24.848722
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    import sys
    import ast

# Generated at 2022-06-23 22:51:25.957067
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import ast as pyast

# Generated at 2022-06-23 22:51:27.620815
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:28.758359
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-23 22:51:32.933849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equals(ReturnFromGeneratorTransformer().visit(parse_ast("""
        def fn():
            yield 1
            return 5
    """)), parse_ast("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """))

# Generated at 2022-06-23 22:51:35.540917
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.snippet import get_body

    assert get_body(ReturnFromGeneratorTransformer) == get_body(ReturnFromGeneratorTransformer.__init__)

# Generated at 2022-06-23 22:51:45.600708
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ret = ast.Return(value=ast.Num(n=5))
    fn = ast.FunctionDef(name='fn', body=[
        ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
        ret
    ])
    transformed_fn = ReturnFromGeneratorTransformer().visit(fn)

# Generated at 2022-06-23 22:51:55.847319
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .unittest_tools import source_to_ast, ast_to_source
    from .unittest_tools import should_transform_to

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        {
            exc = StopIteration()
            exc.value = 5
            raise exc
        }
    """

    ast_node = source_to_ast(source)
    new_ast_node = ReturnFromGeneratorTransformer().visit(ast_node)
    assert ast_to_source(new_ast_node)[0] == expected.format("" if any([isinstance(x, ast.Print) for x in new_ast_node.body]) else "\n")



# Generated at 2022-06-23 22:52:05.492770
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("def fn():\n"
                     "    yield 1\n"
                     "    return 5")
    fn = node.body[0]
    assert fn.name == 'fn'
    assert isinstance(fn, ast.FunctionDef)
    assert fn.args.args == []
    assert isinstance(fn.body[0], ast.Expr)
    assert isinstance(fn.body[1], ast.Return)
    assert isinstance(fn.body[2], ast.Return)
    assert fn.body[2].value.n == 5

    transformed = ReturnFromGeneratorTransformer(tree=node).visit(node)
    fn = transformed.body[0]
    assert fn.name == 'fn'
    assert isinstance(fn, ast.FunctionDef)
    assert fn.args.args == []


# Generated at 2022-06-23 22:52:10.624046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    node = ast.parse(inspect.getsource(fn))
    node = ReturnFromGeneratorTransformer().visit(node)
    code = compile(node, '<ast>', 'exec')
    ns = {}
    eval(code, ns)

    gen = ns['fn']()
    assert next(gen) == 1

    assert next(gen) == 5

# Generated at 2022-06-23 22:52:16.359232
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    check_snippet = ReturnFromGeneratorTransformer().visit
    check_snippet(snippet_without_return)
    assert check_snippet(snippet_with_return) == \
        snippet_with_return_compiled
    assert check_snippet(snippet_with_return_compiled) == \
        snippet_with_return_compiled



# Generated at 2022-06-23 22:52:19.223919
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # GIVEN
    # Empty function
    def f():
        pass

    # WHEN
    # Getting an instance of ReturnFromGeneratorTransformer
    transformer = ReturnFromGeneratorTransformer()

    # THEN
    # It should not be empty
    assert transformer is not None

# Generated at 2022-06-23 22:52:29.773273
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import ast_manipulation
    from .base import BaseTestTransformer
    from .generator import GeneratorTransformer

    def fn():
        yield 1
        return 5

    orig_source, orig_tree = ast_manipulation.get_ast(fn)
    tree = ast_manipulation.get_ast(fn)[1]
    generator_transformer = GeneratorTransformer()
    return_from_gen_transformer = ReturnFromGeneratorTransformer()
    tree = generator_transformer.visit(tree)
    tree = return_from_gen_transformer.visit(tree)
    BaseTestTransformer.assert_source_equal(return_from_gen_transformer,
        (orig_source, orig_tree), (return_from_gen_transformer.get_modified_source(), tree))

# Generated at 2022-06-23 22:52:39.181725
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.fixtures import generator, generator_with_return
    from ..utils.ast import ast_to_str, str_to_ast

    test_cases = [
        (generator, generator, []),
        (generator_with_return, generator_with_return, [2]),
    ]

    for num, (before, after, ret_index) in enumerate(test_cases):
        after_tree = ReturnFromGeneratorTransformer().visit(str_to_ast(before))
        after_code = ast_to_str(after_tree)
        assert after_code == after, f"Test {num}"

        if ret_index:
            for i in ret_index:
                assert isinstance(after_tree.body[i], ast.Raise)

# Generated at 2022-06-23 22:52:45.876052
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('def fn(): yield 1')
    trans = ReturnFromGeneratorTransformer()
    new_node = trans.visit(node)
    assert new_node == node

    node = ast.parse('def fn(): return 5')
    trans = ReturnFromGeneratorTransformer()
    new_node = trans.visit(node)
    assert new_node == node

    node = ast.parse('def fn(): yield 1; return 5')
    trans = ReturnFromGeneratorTransformer()
    new_node = trans.visit(node)
    expected = ast.parse('def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc')
    assert ast.dump(new_node) == ast.dump(expected)



# Generated at 2022-06-23 22:52:50.715899
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    node = ast.parse(inspect.getsource(fn))
    node = ReturnFromGeneratorTransformer().visit(node)
    fn = compile(node, '<test>', 'exec')
    exec(fn, locals())
    assert locals()['fn']() == 1

# Generated at 2022-06-23 22:52:53.069914
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert isinstance(transformer, ast.NodeTransformer)


# Generated at 2022-06-23 22:52:56.960406
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()
    assert t.visit_FunctionDef(ast.parse('''def fn():
        yield 1
        return 5''').body[0]) == ast.parse('''def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc''').body[0]

# Generated at 2022-06-23 22:53:00.384764
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    return_from_generator_transformer.visit_FunctionDef(ReturnFromGeneratorTransformer.example_tree)

# Generated at 2022-06-23 22:53:02.353285
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test for ReturnFromGeneratorTransformer class."""
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:53:10.995455
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import _compile

    def test_case(input, expected_output):
        expected_output = expected_output.strip()
        output = _compile(input, (3, 2), [ReturnFromGeneratorTransformer])
        output = output.strip()
        assert output == expected_output

    input_ = '''\
        def fn():
            print("fun")
            return 5
    '''
    expected_output = '''\
        def fn():
            print("fun")
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    test_case(input_, expected_output)

    input_ = '''\
        def fn():
            print("fun")
            yield 123
            return 5
    '''

# Generated at 2022-06-23 22:53:17.574513
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Foo(ast.ast):
        _fields = ['body']
    class Bar(ast.ast):
        _fields = ['body']
    class Return(ast.ast):
        _fields = ['value']

    original_code = '''
        def fn():
            yield 1
            return 5
    '''
    expected_code = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    tree = ast.parse(original_code)

    func = tree.body[0]
    returns = [Return(5)]
    func.body.extend(returns)

    node = Bar(body=[Foo(body=[func])])
    transformer = ReturnFromGeneratorTransformer()
    updated_node = transformer.visit(node)


# Generated at 2022-06-23 22:53:25.616193
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """\
    def fn():
        yield 1
        return 3
    """

    trg = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 3
        raise exc
    """

    src_ast = ast.parse(src)
    ReturnFromGeneratorTransformer().visit(src_ast)
    trg_ast = ast.parse(trg)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(src_ast)
    assert transformer._tree_changed
    assert ast.dump(src_ast) == ast.dump(trg_ast)


# Generated at 2022-06-23 22:53:30.199395
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    original = ast.parse(fn.__code__).body[0]
    expected = ast.parse(''.join(snippet.get_body(return_value=5))).body[0]
    assert expected == ReturnFromGeneratorTransformer().visit(original)

# Generated at 2022-06-23 22:53:35.571454
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """def fn():\n    yield 1\n    return 5"""
    expected = """def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"""
    tree = ast.parse(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(new_tree) == expected


# Generated at 2022-06-23 22:53:43.287886
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def _replace_return(self, parent, ret):
            self.parent = parent
            self.ret = ret

    node_text = '''
    def foo():
        yield 1
        return 'abc'
    '''
    node = ast.parse(node_text).body[0]

    transformer = TestReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert transformer.parent.body[-2].value.s == 'abc'



# Generated at 2022-06-23 22:53:47.412285
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(
        'def fn():\n    yield 1\n    return 5')
    expected = ast.parse(
        'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value'
        ' = 5\n    raise exc')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert node == expected


# Generated at 2022-06-23 22:53:49.490843
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestedClass(ReturnFromGeneratorTransformer):
        def visit_A(self, node):
            return node
    cls = TestedClass()
    assert isinstance(cls, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:53:56.224494
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.sampledata import func_with_yield_from
    from ..utils.source import source

    func_with_yield_from_ast = func_with_yield_from.ast()
    expected_func_with_yield_from_ast = source(
        "def fn():\n"
        "    yield 1\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc\n"
    )

    assert expected_func_with_yield_from_ast.ast() == ReturnFromGeneratorTransformer().visit(func_with_yield_from_ast)

    func_with_yield_from_param_ast = func_with_yield_from.param().ast()
    expected_func_with_y

# Generated at 2022-06-23 22:54:05.169613
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:13.237500
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import snippet, let

    let(test_data)
    let(test_data_expected)
    let(test_data_expected_ast)
    let(ast_tree)
    let(ast_tree_expected)


# Generated at 2022-06-23 22:54:23.178304
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_function():
        yield 1
        return 5
    from ..utils import get_all_nodes
    assert get_all_nodes(test_function) == [
        test_function,
        ast.Yield(value=ast.Constant(value=1, kind=None), kind=None),
        ast.Return(value=ast.Constant(value=5, kind=None), kind=None),
    ]
    from ..visitors import FullDispatcher
    from ..stages import print_function
    from ..transformers import ReturnFromGeneratorTransformer
    node = FullDispatcher(test_function, [ReturnFromGeneratorTransformer, print_function]).visit()
    node = node.body[0]

# Generated at 2022-06-23 22:54:24.620585
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:54:35.169500
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTestCase

    class ReturnFromGeneratorTransformerTestCase(BaseNodeTransformerTestCase):
        transformer = ReturnFromGeneratorTransformer
        filename = __file__

# Generated at 2022-06-23 22:54:43.923384
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from tests.test_transformer import assert_matches, assert_not_matches, assert_converted

    def fn():
        yield 1
        return 5

    no_ret = """
        def fn():
            yield 1
    """
    no_yield = """
        def fn():
            return 5
    """

    def fn_if():
        yield 1
        if 1:
            return 5

    if_ret = """
        def fn():
            yield 1
            if 1:
                return 5
    """

    def fn_nested():
        yield 1
        if 1:
            yield 2
            return 5
        elif 2:
            yield 3
            return 7
        else:
            return 9


# Generated at 2022-06-23 22:54:47.145028
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.test_utils import generate_function_body

    for body in generate_function_body(
        has_yield=True,
        emplace_function=False
    ):
        assert ReturnFromGeneratorTransformer().visit(body.ast) is not None

# Generated at 2022-06-23 22:54:53.850953
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(textwrap.dedent("""
    def fn():
        yield 1
        return 5
    """))

    fn_def = node.body[0]
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(fn_def) == ast.parse(textwrap.dedent("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """))

# Generated at 2022-06-23 22:55:00.840373
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source

    src = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    transformer = ReturnFromGeneratorTransformer(src)
    transformer.setup()

    assert source(transformer.visit(transformer.tree)) == expected



# Generated at 2022-06-23 22:55:03.758095
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Simple test case for ReturnFromGeneratorTransformer."""
    try:
        class_under_test = ReturnFromGeneratorTransformer()
    except Exception:
        raise AssertionError

# Generated at 2022-06-23 22:55:14.338019
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .remove_duplicate_function_definitions import RemoveDuplicatedFunctionDefinitionsTransformer
    from .split_function_definitions_with_yields import SplitFunctionDefinitionsWithYieldsTransformer
    from .replace_function_definitions_with_yields import ReplaceFunctionDefinitionsWithYieldsTransformer

    source = """
        def fn(): 
            yield 1
            return 5
    """
    expected = """
        def fn(): 
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)

    # Split FunctionDefinitionsWithYieldsTransformer
    RemoveDuplicatedFunctionDefinitionsTransformer().visit(tree)  # type: ignore
    SplitFunctionDefinitionsWithYieldsTransformer().visit(tree)

# Generated at 2022-06-23 22:55:15.426101
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:19.045907
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert (return_from_generator_transformer.target == (3, 2))
    
test_ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:55:27.137730
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast
    import textwrap
    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    from unittest import TestCase
    from .base import get_node_transformer

    class ReturnFromGeneratorTransformerTestCase(TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            self.maxDiff = None

        def test_01(self):
            source_code = textwrap.dedent(
                """
                from typing import Generator

                def fn(a: int) -> Generator[int, int, int]:
                    if a > 0:
                        yield 1
                    elif a < 0:
                        yield 2
                    return 1
                """)


# Generated at 2022-06-23 22:55:30.884363
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ast_unparse import unparse
    from test.parser.code_samples import return_in_generator

    tree = ast.parse(return_in_generator)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    from strgen import StringGenerator
    assert unparse(tree) == ReturnFromGeneratorTransformer._pre_transform + \
                            StringGenerator(return_from_generator).render() + \
                            ReturnFromGeneratorTransformer._post_transform

# Generated at 2022-06-23 22:55:35.138768
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        yield 2
        return 5
    assert ReturnFromGeneratorTransformer().transform_code(fn).code == \
           ReturnFromGeneratorTransformer().transform_snippet(return_from_generator.get_code()).code

# Generated at 2022-06-23 22:55:37.453469
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .. import compile_isolated
    from .inject_line_number import InjectLineNumberTransformer


# Generated at 2022-06-23 22:55:45.827498
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        # Test the return of _find_generator_returns
        def test_find_generator_returns(self):
            class TestFindGeneratorReturns(unittest.TestCase):
                def test_function_with_yield(self):
                    code = '''
                        def fn():
                            yield 1
                            return 2
                    '''
                    result = ast.parse(code)
                    node_transformer = ReturnFromGeneratorTransformer()
                    node_transformer.visit(result)
                    new_result = ast.parse(code)
                    self.assertEqual(new_result, result)

                def test_function_without_yield(self):
                    code = '''
                        def fn():
                            return 2
                    '''


# Generated at 2022-06-23 22:55:53.136578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fixtures import get_example_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = get_example_ast(source)
    fixed = ReturnFromGeneratorTransformer().visit(node)
    assert expected == ast.fix_missing_locations(ast.Module(body=fixed)).body[0].body[1].body[2].value.right.value.s  # noqa: E501

# Generated at 2022-06-23 22:56:03.127443
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Test function without yield or return statement
    def fn1():
        pass

    fdef = ast.parse(fn1.__code__).body[0]
    assert not ReturnFromGeneratorTransformer()._find_generator_returns(fdef)
    ReturnFromGeneratorTransformer().visit(fdef)
    assert not ReturnFromGeneratorTransformer()._tree_changed


    # Test function with yield statement, but w/o return statement
    def fn2():
        yield 1

    fdef = ast.parse(fn2.__code__).body[0]
    assert not ReturnFromGeneratorTransformer()._find_generator_returns(fdef)
    ReturnFromGeneratorTransformer().visit(fdef)
    assert not ReturnFromGeneratorTransformer()._tree_changed


    # Test function with return statement

# Generated at 2022-06-23 22:56:10.373465
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    transformer = ReturnFromGeneratorTransformer()
    assert unparse(transformer.visit(ast.parse("""
    def f():
        yield 1
        return 5
    """))) == "def f():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"

    assert unparse(transformer.visit(ast.parse("""
    def f():
        yield 1
        a = 1
        return 5
    """))) == "def f():\n    yield 1\n    a = 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"



# Generated at 2022-06-23 22:56:19.959049
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import get_node

    src = """
    def foo():
        return 5
    """
    node = get_node(src, 'FunctionDef')
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert result == node
    assert not transformer._tree_changed

    src = """
    def foo():
        yield 5
        return 5
    """
    node = get_node(src, 'FunctionDef')
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert result != node
    assert transformer._tree_changed

    expected = """
    def foo():
        yield 5
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

# Generated at 2022-06-23 22:56:27.818094
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    code = """
    def foo():
        yield 1
        return 2
    """
    parsed = ast.parse(code)
    tree = transformer.visit(parsed)
    assert transformer._tree_changed is True

    expected_code = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    expected_parsed = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_parsed)


# Generated at 2022-06-23 22:56:30.339582
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import utils
    from .list_comprehensions import ListComprehensionsTransformer


# Generated at 2022-06-23 22:56:31.337312
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:32.364438
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:33.406365
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:34.025018
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:35.384351
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:56:44.127469
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_fn(a):
        yield a
        return a + 1

    test_fn_source = inspect.getsource(test_fn)

    tree = ast.parse(test_fn_source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    fn = compile(tree, '<string>', 'exec')
    result = ReturnFromGeneratorTransformer().visit(fn)

    globs = globals().copy()
    exec(result)
    assert globs['test_fn'](5).__next__() == 5



# Generated at 2022-06-23 22:56:49.686667
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    before = """
        def fn():
            yield 1
            return 2
    """  # noqa: E501
    after = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """  # noqa: E501

    transformer = ReturnFromGeneratorTransformer()
    after_tree = transformer.visit(ast.parse(before))

    assert ast.dump(after_tree, include_attributes=True) == ast.dump(ast.parse(after), include_attributes=True)



# Generated at 2022-06-23 22:56:59.498708
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_ast_tree_1 = ast.parse("""
        def foo():
            yield 1
            return 2
    """)
    test_ast_tree_2 = ast.parse("""
        def foo():
            yield 1
            for i in [1, 2, 3]:
                return 2
    """)
    test_ast_tree_3 = ast.parse("""
        def foo():
            for i in [1, 2, 3]:
                yield 2
            return 2
    """)
    test_ast_tree_4 = ast.parse("""
        def foo():
            for i in [1, 2, 3]:
                yield 2
            for i in [1, 2, 3]:
                return 2
    """)

# Generated at 2022-06-23 22:57:01.609857
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with replaces(ReturnFromGeneratorTransformer):  # type: ignore
        transformer = ReturnFromGeneratorTransformer()

    assert transformer



# Generated at 2022-06-23 22:57:02.534435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:09.923412
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    code = """
        def f():
            yield from [1, 2, 3]
            if True:
                return 3
            else:
                return 4
    """
    expected_code = """
        def f():
            yield from [1, 2, 3]
            if True:
                exc = StopIteration()
                exc.value = 3
                raise exc
            else:
                exc = StopIteration()
                exc.value = 4
                raise exc
    """
    tree = ast.parse(code)

    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert ast.dump(new_tree) == expected_code

# Generated at 2022-06-23 22:57:11.230090
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test ReturnFromGeneratorTransformer()"""

# Generated at 2022-06-23 22:57:12.132590
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:13.015943
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:17.789686
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("Testing init of ReturnFromGeneratorTransformer")
    # Initialize a transformer instance
    transformer = ReturnFromGeneratorTransformer()
    
    # Check that the initialized class is of type ReturnFromGeneratorTransformer
    assert(isinstance(transformer, ReturnFromGeneratorTransformer))
    print("Test passed\n")


# Generated at 2022-06-23 22:57:19.317010
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 22:57:20.790598
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:27.168530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import compile_to_ast

    source = '''
    def fn():
        yield 1
        return 5
    '''
    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    transformer = ReturnFromGeneratorTransformer()
    actual = compile_to_ast(source, transformer)

    assert actual == expected


# Generated at 2022-06-23 22:57:29.088591
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer(None)
    assert(isinstance(return_from_generator_transformer, BaseNodeTransformer))

# Generated at 2022-06-23 22:57:36.021721
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    func = '''
    def generator():
        yield 0
        return 5
    '''
    expected_function = '''
    def generator():
        yield 0
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    func_tree = ast.parse(func)
    func_tree = ReturnFromGeneratorTransformer().visit(func_tree)
    assert astor.to_source(func_tree) == expected_function

# Generated at 2022-06-23 22:57:42.627228
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast, compare_asts
    AST = get_ast('''
    def foo():
        yield 1
        return 5
    ''')

    trans = ReturnFromGeneratorTransformer()
    new_ast = trans.visit(AST)

    assert compare_asts(
        AST,
        get_ast('''
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')
    )

# Generated at 2022-06-23 22:57:51.686784
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from code_transformer.typed_ast.typed_ast import ast3 as ast

    tree = ast.parse('''def fn():
        yield 1
        return 5''')
    rfgt = ReturnFromGeneratorTransformer()
    rfgt.visit(tree)

# Generated at 2022-06-23 22:57:55.200183
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_object = ReturnFromGeneratorTransformer()
    assert isinstance(class_object, BaseNodeTransformer)
    assert class_object.target == (3, 2)

# Generated at 2022-06-23 22:58:04.001360
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    '''Unit test for constructor of class ReturnFromGeneratorTransformer'''
    node = ast.parse("def fn():\n    yield 1\n    return 5")
    transformer = ReturnFromGeneratorTransformer(None)
    transformer.visit(node)
    assert node.body[0].body[0].value.n == 1
    assert node.body[0].body[1].value.func.id == 'StopIteration'
    assert node.body[0].body[2].value.func.id == 'StopIteration'
    assert node.body[0].body[3].value.func.id == 'raise'
    assert node.body[0].body[4].value.func.id == 'raise'

# Generated at 2022-06-23 22:58:11.649513
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Tree setup
    node = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Yield(
                value=ast.Num(n=1)
            ),
            ast.Return(
                value=ast.Num(n=5)
            )
        ],
        decorator_list=[],
        returns=None
    )

    # Test
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    # Assertions
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:58:22.089723
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source_1 = """
        def foo():
            pass
    """
    expected_1 = source_1
    source_2 = """
        def foo():
            yield 1
    """
    expected_2 = source_2
    source_3 = """
        def foo():
            yield 1
            return 5
    """
    expected_3 = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    source_4 = """
        def foo():
            yield 1
            return 5
            pass
    """
    expected_4 = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            pass
    """

# Generated at 2022-06-23 22:58:28.283372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.snippet import transform
    from ..utils.syntax import get_function_body, get_function_name, get_function_args
    from ..utils.source import dedent_source
    from ..utils.asserts import assert_transformed

    source = dedent("""
    def foo():
        if True:
            yield 1
            return 1

    def bar():
        if True:
            yield 2
            return 2

    def baz():
        yield 3
        if True:
            return 3
    """)
