

# Generated at 2022-06-23 22:48:20.980388
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:21.818505
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:48:31.425923
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # This code below is like :
    #  def fn():
    #     yield 1
    #     return 5
    fn_ast = ast.Module([ast.FunctionDef(name='fn',
                                         args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[],
                                                            kwarg=None, defaults=[]),
                                         body=[ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
                                               ast.Return(value=ast.Num(n=5))],
                                         decorator_list=[], returns=None)], type_ignores=[])

    # This code below is like :
    #  def fn():
    #     yield 1
    #     exc = StopIteration()
    #     exc.value =

# Generated at 2022-06-23 22:48:41.237854
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Check:
    # def fn():
    #     yield 5
    #     return 6
    # ->
    # def fn():
    #     yield 5
    #     exc = StopIteration()
    #     exc.value = 6
    #     raise exc
    node = ast.parse('''
        def fn():
            yield 5
            return 6
    ''')
    new_node = ReturnFromGeneratorTransformer().visit(node)
    expected_node = ast.parse('''
        def fn():
            yield 5
            exc = StopIteration()
            exc.value = 6
            raise exc
        ''')
    assert ast.dump(new_node, annotate_fields=False) == ast.dump(expected_node, annotate_fields=False)


# Generated at 2022-06-23 22:48:42.767997
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:48:52.815549
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import TEST_CASES_FOR_SOURCE
    from . import TEST_CASES_FOR_STMT

    for source, expected in TEST_CASES_FOR_SOURCE:
        tree = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        asserts = transformer.get_assertions(tree=tree)
        assert '\n'.join(expected) == asserts

    for source, expected in TEST_CASES_FOR_STMT:
        tree = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()
        tree = transformer.visit(tree)
        assert '\n'.join(expected) == tree.body[0].body[0].body[0].value.func.id

# Generated at 2022-06-23 22:48:53.378395
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:03.038725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from .simple_transformer import SimpleTransformer

    code = '''
        def fn():
            yield 1
            return 5
    '''
    tree = parse(code)
    transformer = SimpleTransformer()
    tree = transformer.visit(tree)  # type: ignore

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)  # type: ignore
    assert transformer._tree_changed

    simple_code = '''
        def fn():
            yield 1

            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    simple_tree = parse(simple_code)
    assert ast.dump(tree) == ast.dump(simple_tree)

# Generated at 2022-06-23 22:49:09.095067
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # input:
    """
    def fn():
        yield 1
        return 5
    """
    # comparison:
    """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(
        ast.parse(inspect.getsource(test_ReturnFromGeneratorTransformer_visit_FunctionDef)).body[0])

# Generated at 2022-06-23 22:49:17.127305
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
    def foo():
        yield 1
        return 9
    ''')
    visitor = ReturnFromGeneratorTransformer(node)
    visitor.visit(node)

# Generated at 2022-06-23 22:49:19.782890
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .conftest import compare_ast
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 22:49:22.364659
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert str(type(transformer)) == "<class 'ast_transformer.transformers.ReturnFromGeneratorTransformer'>"

# Generated at 2022-06-23 22:49:27.613123
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with open('./py3_transpile/test/test_files/test_return_in_generator.py') as f:
        tree = ast.parse(f.read())

    tree = ReturnFromGeneratorTransformer.run(tree)

    with open('./py3_transpile/test/test_files/test_return_in_generator_transformed.py') as f:
        expected_tree = ast.parse(f.read())

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:49:28.456725
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:38.925008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from .test_transformers import should_transform
    import inspect

    def test_code(*args):
        # type: (str) -> None
        # use `snippet` template
        def fn():
            yield 1
            return 5

        # use ast
        code = compile(fn(), '<ast>', 'exec')
        snippet_tree = ast.parse(snippet.get_body(return_value=5))
        snippet_code = compile(snippet_tree, '<ast>', 'exec')

        assert code.co_consts == snippet_code.co_consts
        assert code.co_varnames == snippet_code.co_varnames
        assert code.co_names == snippet_code.co_names
        assert code.co_nlocals

# Generated at 2022-06-23 22:49:48.973578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import pprint
    from typed_astunparse import unparse
    from .rewrite_generators import rewrite_generators

    class ReturnFromGeneratorTransformerForTest(ReturnFromGeneratorTransformer):
        def __init__(self):
            super(ReturnFromGeneratorTransformerForTest, self).__init__()
            self.__tree_changed = None

        def generic_visit(self, node):
            return node

        def get_tree_changed(self):
            return self.__tree_changed

    def check(before, after):
        node = ast.parse(before)
        node = rewrite_generators(node)
        node = ReturnFromGeneratorTransformerForTest().visit(node)
        node = ReturnFromGeneratorTransformerForTest().visit(node)
        assert after == unparse(node).strip

# Generated at 2022-06-23 22:49:59.306317
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    func = ast.parse("def foo():\n    yield 1\n    return 2").body[0]
    func = ReturnFromGeneratorTransformer().visit(func)

# Generated at 2022-06-23 22:50:04.962969
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    compiler = ReturnFromGeneratorTransformer()

    class Test:
        def test(self, a):
            yield a
            return 10

    test = Test()
    compiler.visit(ast.parse(inspect.getsource(test.test)))
    test.test.__code__ = compiler.get_code()

    assert next(test.test(1)) == 1
    assert next(test.test(1)) == 10

# Generated at 2022-06-23 22:50:05.932741
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:13.342350
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    node = ast.parse('\n'.join([
        'def fn():',
        '    yield 1',
        '    return 5',
    ]))
    expected_node = ast.parse('\n'.join([
        'def fn():',
        '    yield 1',
        '    exc = StopIteration()',
        '    exc.value = 5',
        '    raise exc'
    ]))
    actual_node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(actual_node) == ast.dump(expected_node)


# Generated at 2022-06-23 22:50:24.265940
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:50:34.292439
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree_return_only = ast.parse(
        """def fn():
            return 5"""
    )
    tree_return_after_yield = ast.parse(
        """
        def fn():
            yield 1
            return 5"""
    )
    tree_return_from_subblock = ast.parse(
        """
        def fn():
            yield 1
            if True:
                return 5"""
    )
    tree_return_from_subfunction = ast.parse(
        """
        def fn():
            def subfn():
                return 5
            yield 1
        """
    )

    res_return_only = ast.parse(
        """def fn():
            return 5"""
    )

# Generated at 2022-06-23 22:50:40.495441
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:49.441240
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    node = ast.parse('def foo(a):\n  yield 1\n  return a')
    trans = ReturnFromGeneratorTransformer()
    fn = trans.visit(node)

    assert len(fn.body) == 3
    assert_same_line(fn, 0, 'def foo(a):')
    assert_same_line(fn, 1, '  yield 1')
    assert_same_line(fn, 2, '  exc = StopIteration()')
    assert_same_line(fn, 3, '  exc.value = a')
    assert_same_line(fn, 4, '  raise exc')



# Generated at 2022-06-23 22:50:54.172688
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    code = "def foo(): yield 1\nreturn 5"
    t = ReturnFromGeneratorTransformer()
    t.visit(ast.parse(code))
    assert astunparse.unparse(t.result) == "def foo():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"


# Generated at 2022-06-23 22:50:54.808946
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:50:56.510754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert not t.tree_changed


# Generated at 2022-06-23 22:50:58.455008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""


# Generated at 2022-06-23 22:51:00.312131
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer._tree_changed == False

# Generated at 2022-06-23 22:51:09.723050
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import stmt

    class MockReturn(stmt):
        def __repr__(self):
            return 'Return(..)'

        def __init__(self):
            pass

    class Mock(ast.FunctionDef):
        def __init__(self, body):
            self.body = body
            self.decorator_list = []

    class MockGlobal(ast.Global):
        def __init__(self, names):
            self.names = names

    class MockYield(ast.Yield):
        def __init__(self, value):
            self.value = value

    def mock_generic(parent):
        return parent

    class MockTransformer(ReturnFromGeneratorTransformer):
        def generic_visit(self, parent):
            return mock_generic(parent)


# Generated at 2022-06-23 22:51:19.586306
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test_ReturnFromGeneratorTransformer_visit_FunctionDef(unittest.TestCase):
        def test_1(self):
            node = ast.parse("""def test(): yield 1; return 5""", "<test>", "exec")
            tree = ReturnFromGeneratorTransformer().visit(node)
            expected = """def test(): yield 1; exc = StopIteration(); exc.value = 5; raise exc"""
            self.assertEqual(expected, astor.to_source(tree).strip())

        def test_2(self):
            node = ast.parse("""def test(): if True: return 5; yield 1""", "<test>", "exec")
            tree = ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-23 22:51:29.997923
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    parent = ast.FunctionDef(lineno=1, col_offset=1, name="fn", args=(), body=[
        ast.Return(lineno=2, col_offset=2, value=ast.Num(lineno=2, col_offset=9, n=5)),
    ], decorator_list=[], returns=None)
    node_to_check = (parent, ast.Return(lineno=2, col_offset=2, value=ast.Num(lineno=2, col_offset=9, n=5)))
    generator_returns = ReturnFromGeneratorTransformer()._find_generator_returns(parent)
    assert node_to_check in generator_returns

# Generated at 2022-06-23 22:51:36.639567
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor

    tree = ast.parse(
        """
            def fn(x, y, z=5):
                yield x
                return x + y + z
        """
    )

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    result = astor.to_source(tree)

    expected = """
            def fn(x, y, z=5):
                yield x
                exc = StopIteration()
                exc.value = (x + y) + z
                raise exc
    """

    assert result == expected


# Generated at 2022-06-23 22:51:38.188806
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5



# Generated at 2022-06-23 22:51:48.173568
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():  # noqa: D103

    #
    # Test returns in generators
    #
    def _check_return(code, transformed_code):
        fn_node = ast.parse(code).body[0]
        ReturnFromGeneratorTransformer().visit(fn_node)
        assert transformed_code == ast.unparse(fn_node)


# Generated at 2022-06-23 22:51:53.871728
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_utils import assert_program

    program = """
    def foo():
        yield 1
        return 5
    """
    expected = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert_program(program, expected, [ReturnFromGeneratorTransformer])


# Generated at 2022-06-23 22:51:54.823660
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:02.408760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from _fixtures.generators_returns import fn

    class NodeTransformer(ReturnFromGeneratorTransformer):
        pass

    NodeTransformer().visit(fn)

    assert fn.__name__ == "fn"
    assert fn.__qualname__ == "fn"
    assert fn.__annotations__ == {}
    assert fn.__doc__ is None
    assert fn.__module__ is None
    assert fn.__defaults__ is None
    assert fn.__code__.co_argcount == 0
    assert fn.__code__.co_posonlyargcount == 0
    assert fn.__code__.co_kwonlyargcount == 0
    assert fn.__code__.co_nlocals == 1
    assert fn.__code__.co_stacksize == 5
    assert fn.__code__.co

# Generated at 2022-06-23 22:52:04.130179
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    instance = ReturnFromGeneratorTransformer()
    assert isinstance(instance, BaseNodeTransformer)


# Generated at 2022-06-23 22:52:06.270564
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    assert ReturnFromGeneratorTransformer().visit(fn)  # noqa: E741

# Generated at 2022-06-23 22:52:16.608085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformer

    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer, BaseNodeTransformerTest):
        pass


# Generated at 2022-06-23 22:52:23.628275
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source
    from .transformers.unpack_sequence import UnpackSequenceTransformer
    from .. import transform
    from .. import utils
    from ..utils import tree
    module = utils.parse('def fn():\n yield 1\n return 7')
    assert tree.find(module, ast.FunctionDef, lambda n: n.name == 'fn')
    # Function fn should have body
    assert tree.find(module, ast.FunctionDef, lambda n: n.name == 'fn')[0].body  # type: ignore
    # fn body should contain Return
    assert isinstance(tree.find(module, ast.FunctionDef, lambda n: n.name == 'fn')[0].body[-1], ast.Return)  # type: ignore
    # Return value should be 7

# Generated at 2022-06-23 22:52:25.341846
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(None)



# Generated at 2022-06-23 22:52:25.975732
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-23 22:52:30.551555
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTest
    from ..utils.snippet import snippet, let

    class ReturnFromGeneratorTransformerTest(BaseNodeTest):
        target = (3, 2)
        node = ast.Module([
            snippet.class_def("""
                def generator():
                    yield 1
                    return 2
            """)
        ])

        expected = ast.Module([
            snippet.class_def("""
                def generator():
                    yield 1
                    exc = StopIteration()
                    exc.value = 2
                    raise exc
            """)
        ])

    ReturnFromGeneratorTransformerTest().test()

# Generated at 2022-06-23 22:52:31.578985
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:52:33.081115
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:52:41.670949
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    inp = """
        def gen():
            yield 1
            return 5
    """
    node = ast.parse(inp)
    returned = ReturnFromGeneratorTransformer().visit(node)


# Generated at 2022-06-23 22:52:43.791688
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = lambda: (x for x in [1, 2, 3])
    x = ReturnFromGeneratorTransformer().visit_FunctionDef(fn.__code__)
    assert x == fn()

# Generated at 2022-06-23 22:52:48.334839
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from ..utils.snippet import get_func
    from ..test_data.test_return_from_generator_transformer import test_data

    for t in test_data:
        yield check_ReturnFromGeneratorTransformer_visit_FunctionDef, t



# Generated at 2022-06-23 22:52:49.537251
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:52:52.970098
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse("""
    def foo():
        yield from API.get_items('/lorem')
        yield from API.get_items('/ipsum')
        return 5
    
    assert foo().__next__() == 1
    """)

    tree = transformer.visit(tree)
    # TODO: Assert the tree
    pass

# Generated at 2022-06-23 22:52:54.239438
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-23 22:53:01.603524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    def test_fn():
        yield 1
        return 2
    tree = ast.parse(inspect.getsource(test_fn))
    transformer = ReturnFromGeneratorTransformer()
    expected = ast.parse("""
    def test_fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """)

    # Act
    transformer.visit(tree)
    actual = transformer.tree

    # Assert
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 22:53:10.499232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for version in [2, 3]:
        exec('''if version == 2:
    from typed_ast import ast{} as ast
elif version == 3:
    from typed_ast import ast{} as ast'''.format(version, version))

        node = ast.parse("""
    def gen():
        yield 1
        return 5
    """)

        transformer = ReturnFromGeneratorTransformer()
        result = transformer.visit(node)


# Generated at 2022-06-23 22:53:11.451280
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:12.262769
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a = ReturnFromGeneratorTransformer()
    

# Generated at 2022-06-23 22:53:18.268591
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Mock(ReturnFromGeneratorTransformer):
        def generic_visit(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    tree = ast.parse("""
    def fn(a: int, b: int) -> str:
        print(a)
        yield a
        return b
    """)
    mock = Mock()
    tree = mock.visit_FunctionDef(tree.body[0])

    assert tree.body[1].value == ast.Name(id='a', ctx=ast.Load())
    assert tree.body[2].value.value == ast.Name(id='a', ctx=ast.Load())
    assert tree.body[3].value.value.id == 'StopIteration'
    assert tree.body[4].value.value.id == 'exc'
   

# Generated at 2022-06-23 22:53:25.208449
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from ..utils.source import source_to_unicode
    from .utils import transform, compare_source

    source = source_to_unicode("""\
    def fn():
        yield 1
        return 2
    """)

    expected = source_to_unicode("""\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """)

    tree = ast.parse(source)

    transform(tree, ReturnFromGeneratorTransformer)

    compare_source(tree, expected)

# Generated at 2022-06-23 22:53:35.563177
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    node = ast.parse('\n'.join((
        'def fn():',
        '    yield 1',
        '    return 5',
        '',
        'def fn2():',
        '    yield 1',
        '    def fn3():',
        '        yield 2',
        '        return 4',
        '    yield 3',
        '    return fn3()',
    )))

    transformed_node = return_from_generator_transformer.visit(node)
    assert return_from_generator_transformer._tree_changed

    fn = transformed_node.body[0]
    assert [x.value for x in fn.body] == [1, 'exc', 'exc.value']


# Generated at 2022-06-23 22:53:44.325991
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import create_ast_from_snippet

    source = """
        def fn():
            return 5
    """
    expected = """
        def fn():
            return 5
    """

    node = create_ast_from_snippet(source)
    expected_node = create_ast_from_snippet(expected)

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit_FunctionDef(node)

    assert ast.dump(expected_node, include_attributes=False) == ast.dump(result, include_attributes=False)
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:53:49.910517
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    from ..testing import assert_code_equal

    code_before = """
    def gen():
        yield 1
        return 5
    """

    code_after = """
    def gen():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast3.parse(code_before)
    node = ReturnFromGeneratorTransformer.run(node)

    assert_code_equal(code_after, node)

# Generated at 2022-06-23 22:54:00.270263
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    functionDef = ast3.FunctionDef(name = "foo")
    functionDef.args = ast3.arguments(args = [],
                                 defaults = [],
                                 kwonlyargs = [],
                                 kw_defaults = [],
                                 kwarg = None,
                                 vararg = None)
    functionDef.decorator_list = []
    functionDef.returns = None
    functionDef.body = [ast3.Expr(value=ast3.Yield(value=ast3.Num(n=1))),
                        ast3.Return(value=ast3.Num(n=5))]

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit_FunctionDef(functionDef)
    assert len(result.body) == 3
   

# Generated at 2022-06-23 22:54:07.908789
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class FuncDefMock(object):
        def __init__(self, body, lineno, col_offset):
            self.body = body
            self.lineno = lineno
            self.col_offset = col_offset

        def __getitem__(self, index):
            return self.body[index]

        def index(self, item):
            return self.body.index(item)

    class ModuleMock(object):
        def __init__(self, body):
            self.body = body

    class ReturnMock(object):
        def __init__(self, value):
            self.value = value

    class YieldMock(object):
        pass

    class IfMock(object):
        def __init__(self, test, body):
            self.test = test
            self.body = body

# Generated at 2022-06-23 22:54:09.436268
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:54:15.069322
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from py_jobject import annotate
    from .test_base import compile_and_decompile
    @annotate
    def fn(x: int) -> str:
        yield "hello"
        return str(x)

    assert fn(1) == "hello"
    assert fn(2) == "hello"
    assert (next(fn(3))) == "hello"
    assert (next(fn(3))) == "3"

    new_fn = compile_and_decompile(fn)

    assert new_fn.__annotations__ == fn.__annotations__
    assert new_fn(1) == "hello"
    assert new_fn(2) == "hello"
    assert (next(new_fn(3))) == "hello"
    assert (next(new_fn(3))) == "3"

# Generated at 2022-06-23 22:54:22.586615
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    fn = ast.parse('''
        def fn():
            yield 1
            return 5
        ''').body[0]

    fn = transformer.visit(fn)  # type: ignore

    assert fn.body[1].value.func.func.value.id == 'StopIteration'
    assert fn.body[1].value.args[0].id == 'exc'
    assert fn.body[2].value.args[0].value.func.id == 'raise'
    assert fn.body[2].value.args[0].value.args[0].id == 'exc'

# Generated at 2022-06-23 22:54:33.455634
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import (
        generate_function_ast,
        generate_ast,
        compare_ast,
        transformer_test_helper,
    )
    code = 'def fn():\n    yield 1\n    return 5'
    ret_transformed_code = (
        'def fn():\n'
        '    yield 1\n'
        '    exc = StopIteration()\n'
        '    exc.value = 5\n'
        '    raise exc\n'
    )
    node = generate_function_ast(code)
    expected = generate_ast(ret_transformed_code, mode="exec")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    compare_ast(expected, node)

# Generated at 2022-06-23 22:54:41.413276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3  # type: ignore
    node = ast_parse("""
        def fn1():
            yield 1
            return 5
        def fn2():
            return 2
        def fn3():
            yield from (x for x in range(5))
            return 1
    """)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(node)
    expected_tree = ast_parse("""
        def fn1():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def fn2():
            return 2
        def fn3():
            yield from (x for x in range(5))
            exc = StopIteration()
            exc.value = 1
            raise exc
    """)

# Generated at 2022-06-23 22:54:45.149630
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  node = ast.parse(textwrap.dedent(ipy_snippet)).body[0]
  r = ReturnFromGeneratorTransformer()
  r.visit(node)
  new_src = astor.to_source(node)
  assert new_src == expected_src


# Generated at 2022-06-23 22:54:51.444796
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer:

        @staticmethod
        def test_find_generator_returns():
            def generator():
                yield 1
                return 5

            node = ast.parse(inspect.getsource(generator)).body[0]
            transformer = ReturnFromGeneratorTransformer()
            generator_returns = transformer._find_generator_returns(node)
            assert len(generator_returns) == 1
            assert isinstance(generator_returns[0][0], ast.FunctionDef)
            assert isinstance(generator_returns[0][1], ast.Return)
            assert generator_returns[0][1].value.n == 5

            def generator():
                return 5

            node = ast.parse(inspect.getsource(generator)).body[0]
            transformer = ReturnFrom

# Generated at 2022-06-23 22:55:02.329308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    result = ReturnFromGeneratorTransformer().visit_FunctionDef(ast.parse('def f():\n'
                                                                          '    yield 1\n'
                                                                          '    return 3\n',
                                                                          mode='exec').body[0])
    assert ast.dump(result) == ast.dump(ast.parse('def f():\n'
                                                  '    yield 1\n'
                                                  '    exc = StopIteration()\n'
                                                  '    exc.value = 3\n'
                                                  '    raise exc\n',
                                                  mode='exec').body[0])


# Generated at 2022-06-23 22:55:13.075378
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    from nuitka.nodes.StatementContexts import GeneratorReturnBreakExceptionHandler
    from nuitka.nodes.ConstantRefNodes import ExpressionConstantRef
    from nuitka.nodes.FunctionNodes import ExpressionGeneratorObjectBody
    from nuitka.nodes.NodeBases import StatementBase
    from nuitka.nodes.StatementNodes import StatementReturn
    from nuitka.utils.Indentation import getIndentation

    class CompileMode(object):
        is_module = True
        __slots__ = ()

    class TraceCollection(object):
        def __init__(self, trace_collection):
            self.traces = trace_collection.traces
            self.provides = trace_collection.provides


# Generated at 2022-06-23 22:55:13.941193
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:20.347853
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5


    transformer = ReturnFromGeneratorTransformer()
    # Get the compiled result in form of string.
    compiled_str = transformer(fn)

    assert 'def fn():' in compiled_str
    assert 'yield 1' in compiled_str
    assert 'exc = StopIteration()' in compiled_str
    assert 'exc.value = 5' in compiled_str
    assert 'raise exc' in compiled_str



# Generated at 2022-06-23 22:55:21.338697
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None, None).target == (3, 2)

# Generated at 2022-06-23 22:55:28.871315
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    example_function1 = ast.parse("""
        def fn():
            yield 1
            return 5
        """).body[0]

    example_function2 = ast.parse("""
        def fn():
            yield 1
            if True:
                return 5
        """).body[0]

    example_function3 = ast.parse("""
        def fn():
            yield 1
            if True:
                if True:
                    return 5
                    a = 1
        """).body[0]

    example_function4 = ast.parse("""
        def fn():
            yield 1
            return
        """).body[0]

    example_function5 = ast.parse("""
        def fn():
            yield 1
            if True:
                return
        """).body[0]


# Generated at 2022-06-23 22:55:29.812587
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert True



# Generated at 2022-06-23 22:55:38.923197
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Node(object):
        """Class Node is used in unit tests as an object,
        that has attribute `body`.
        """

        def __init__(self):
            self.body = []

    with patch('typed_astunparse.unparse.unparse', side_effect=lambda x: x):
        source = '''
        def fn():
            yield 1
            return 5
        '''
        node = ast.parse(source)
        func_def = node.body[0]  # type: ast.FunctionDef

        assert hasattr(func_def, 'body')
        assert isinstance(func_def.body, list)

        parent = Node()
        parent.body = func_def.body
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit_FunctionDef(func_def)


# Generated at 2022-06-23 22:55:40.439221
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer



# Generated at 2022-06-23 22:55:44.366716
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
        def generator():
            yield 1
            return 2
    '''
    expected = '''
        def generator():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    '''

    module = ast.parse(code)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)
    actual = ast.dump(module, indent=4)
    assert(expected == actual)


# Generated at 2022-06-23 22:55:47.357643
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for the constructor of class ReturnFromGeneratorTransformer"""
    options = DummyOptions()
    options.target = '3.9'
    transformer = ReturnFromGeneratorTransformer(options, name='ReturnFromGeneratorTransformer')
    assert transformer is not None

# Generated at 2022-06-23 22:55:57.612651
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse("""
    def generator():
        if True:
            yield 1
            return 2
        yield 3
        yield 4
        return 5
    """)
    expected = """def generator():
        if True:
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        yield 3
        yield 4
        exc = StopIteration()
        exc.value = 5
        raise exc"""

    transformed_node = transformer.visit(node)  # type: ignore
    transformed_code = compile(transformed_node, '<test>', 'exec')
    exec(transformed_code)
    assert generator.__name__ == 'generator'
    gen = generator()

    assert next(gen) == 1

# Generated at 2022-06-23 22:56:07.105762
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def f():
        yield 1
        return 5

    def g():
        return 1

    def h():
        yield 1
        print()
        return 5

    def i():
        yield 1
        if True:
            return 5

    def j():
        yield 1
        if True:
            print()
            return 5
        else:
            return 6

    def k():
        yield 1
        if True:
            print()
        else:
            g()

    def l():
        yield 1
        if True:
            print()
            return 5

    def m():
        yield 1

    def n():
        return 5

    def o():
        while True:
            yield 1
            return 5

    def p():
        while True:
            yield 1
            if True:
                return 5


# Generated at 2022-06-23 22:56:17.472744
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test():
        yield 1
        return 5

    def test2():
        yield from range(3)
        return 5

    def test3():
        yield from range(3)
        return
        yield 5

    def test4():
        for i in range(3):
            yield i
        return 5

    def test5():
        if True:
            yield 1
        if False:
            yield 2
        else:
            return 5

    def test6():
        if True:
            yield 1
        if False:
            return
        else:
            yield 2

    def test7():
        if True:
            return
        yield 1

    def test8():
        if True:
            return 1
        yield 2

    def test9():
        if True:
            return 1
        yield 2

# Generated at 2022-06-23 22:56:27.942193
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import NodeTransformerTest
    import ast

    class Test(NodeTransformerTest):
        def create_transformer(self):
            return ReturnFromGeneratorTransformer()

    def test_return_in_generator():
        test = Test()

        test.test('''
            def fn():
                yield 20
                return 6
            ''', '''
            def fn():
                yield 20
                exc = StopIteration()
                exc.value = 6
                raise exc
            ''')

    def test_return_in_if():
        test = Test()


# Generated at 2022-06-23 22:56:29.445029
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse(return_from_generator.get_source())
    new_ast = ReturnFromGeneratorTransformer().visit(tree)
    assert new_ast is not None

# Generated at 2022-06-23 22:56:29.986378
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:56:33.115260
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    import typed_ast.ast3 as ast

    from .base import BaseNodeTransformer
    from .helper import format_code, get_ast

    from unittest.mock import Mock


# Generated at 2022-06-23 22:56:34.842552
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert isinstance(t, ReturnFromGeneratorTransformer)


# Generated at 2022-06-23 22:56:45.915553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test processor of ReturnFromGeneratorTransformer.visit_FunctionDef."""
    code = """\
    def fn():
        yield 1
        return 5
    def fn2():
        yield 1
        return 5
    def fn3():
        yield 1
        return 5
    """
    ast_tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    def fn2():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    def fn3():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert astor.to

# Generated at 2022-06-23 22:56:52.282333
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    from .transformer import Transformer
    from .preprocessor import Preprocessor
    from .utility import compare_ast
    assert compare_ast(ast3.parse('''
        def f():
            yield 1
            return 5
        '''),
        Preprocessor().visit(Transformer(ReturnFromGeneratorTransformer).visit(ast3.parse('''
            def f():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            '''))))
    

# Generated at 2022-06-23 22:56:53.601980
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:02.228806
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source_to_ast, ast_to_source

    for snippet in [
            '''
            def fn():
                yield 1
                return 5
            ''',
            '''
            def fn():
                for i in range(4):
                    yield i
                return 5
            '''
    ]:
        tree = source_to_ast(snippet)
        node = tree.body[0]
        result = ReturnFromGeneratorTransformer().visit(node)
        expected = ast_to_source(result, include_attributes=True)
        expected = expected.strip()
        assert expected == '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''



# Generated at 2022-06-23 22:57:02.770557
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer

# Generated at 2022-06-23 22:57:09.602655
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node_example = ast.parse("""
        def fn():
            yield 1
            return 2
    """)
    node_expected = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

    fn = node_example.body[0]

    transformer = ReturnFromGeneratorTransformer()
    node_transformed = transformer.visit(node_example)

    assert ast.dump(node_transformed, include_attributes=True) == ast.dump(node_expected, include_attributes=True)



# Generated at 2022-06-23 22:57:14.790548
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Tests the constructor for ReturnFromGeneratorTransformer() with given Tree."""
    tree = ast.parse("""def fn():\n    yield 1\n    return 2""")
    result = ReturnFromGeneratorTransformer().visit(tree)
    assert len(result.body[0].body) == 4
    assert isinstance(result.body[0].body[-1], ast.Raise)

# Generated at 2022-06-23 22:57:16.656402
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 3
        return 4
    snippet.assert_matches(ReturnFromGeneratorTransformer, fn)

# Generated at 2022-06-23 22:57:27.355902
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import BaseNodeTransformerTest
    from .base import run_transformer_test
    from ..utils.fixtures.gen_substitution import gen_substitution
    from ..utils.fixtures.return_from_generator import return_from_generator
    from typing import cast

    return_substitution = cast(ast.Module, return_from_generator.ast)

    @run_transformer_test(BaseNodeTransformerTest, gen_substitution.ast,
                          return_substitution, ('generators', 'return_to_generator'),
                          options=['ReturnFromGeneratorTransformer'])
    def _(self):
        pass

# Generated at 2022-06-23 22:57:37.809837
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_node as stn
    from ..utils.source import source_to_nodes as stns
    from typed_astunparse import unparse

    source = """
    def x():
        yield 100
        return 200
    """

    expected = """
    def x():
        yield 100
        exc = StopIteration()
        exc.value = 200
        raise exc
    """

    root_node = sta(source)

    node = stn(source, ast.FunctionDef)

    nodes = stns(source, (ast.FunctionDef,))

    class_obj = ReturnFromGeneratorTransformer()

    node = class_obj.visit(node)

    assert unparse(node) == expected

    nodes = class_

# Generated at 2022-06-23 22:57:43.312388
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from .test_fixture import test_module_ast
    from ..utils.test_utils import get_test_module_compilation_results

    module = test_module_ast
    result = get_test_module_compilation_results(module)
    test = BaseNodeTransformerTest(ReturnFromGeneratorTransformer, module, result)
    test.test_visit_FunctionDef()

# Generated at 2022-06-23 22:57:46.210675
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    transformer = ReturnFromGeneratorTransformer(fn)
    assert len(transformer._find_generator_returns(fn.body[0])) == 1

# Generated at 2022-06-23 22:57:57.480488
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from ..utils.source import source_to_ast_nodes
    from ..utils.ast_visitor import ASTVisitor
    class ResVisitor(ASTVisitor):
        def __init__(self):
            self.out = []

        def visit_Return(self, node):
            self.out.append(node.value)

    # case 1 (with some more code around)
    node = parse("""
        def fn():
            yield 3
            return 5
        """)

    visitor = ResVisitor()
    visitor.visit(node)
    assert len(visitor.out) == 0

    new_node = ReturnFromGeneratorTransformer.run(node)

    visitor = ResVisitor()
    visitor.visit(new_node)
    assert len(visitor.out)

# Generated at 2022-06-23 22:58:07.254789
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fndef = ast.FunctionDef(
        name='fn',
        args=ast.arguments(args=[], vararg=None, kwonlyargs=None, kwarg=None, defaults=[], kw_defaults=[]),
        body=[
            ast.Expr(ast.Yield(ast.Num(1))),
            ast.Return(ast.Num(5)),
        ],
        decorator_list=[],
        returns=None,
    )

    tr = ReturnFromGeneratorTransformer('x.py')
    result = tr.visit(fndef) # type: ignore

# Generated at 2022-06-23 22:58:08.538915
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.tree_changed == False

# Generated at 2022-06-23 22:58:19.086975
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .tools import assert_equal_ignore_ws, run_local_tests
    from .tools import TreeBuilder, run_fragment
    from .tools import assert_tree_changed, assert_tree_not_changed

    with TreeBuilder() as tb:
        tb.function_body(
            ast.Yield(tb.name('x')),
            ast.Yield(tb.name('x')),
            ast.Return(tb.name('y')),
            ast.Yield(tb.name('x')),
            ast.Return(tb.name('y')),
        )


# Generated at 2022-06-23 22:58:27.185753
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Example(ast.AST):
        fields = ['a', 'b']
    test_object = ReturnFromGeneratorTransformer()

    # Example 1
    list1 = [ast.Expr(value=Example(a=Example(a=Example(a=Example(a=Example(a=Example(a=Example(a=Example(a='a')), b='b'))), b='b'))), b='b')]
    function_node1 = ast.FunctionDef(name='test_method', body=list1, decorator_list=[], returns=None)
    test_node1 = test_object.visit(function_node1)
    assert test_node1.body == list1

    # Example 2