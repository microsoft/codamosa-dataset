

# Generated at 2022-06-23 22:48:26.074608
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def test_find_generator_returns(self):
            def check_example(tree, result):
                transformer = ReturnFromGeneratorTransformer()
                transformed_tree = transformer.visit(tree)
                updated_result = transformer._find_generator_returns(transformed_tree)

                self.assertCountEqual(result, updated_result)


# Generated at 2022-06-23 22:48:26.999562
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:48:33.308685
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.zipper import zipper
    from ..utils.source import source

    code = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    tree = zipper(ast.parse(code))
    transformed_tree = tree.root.accept(transformer)
    assert source(transformed_tree) == expected



# Generated at 2022-06-23 22:48:36.698672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit_FunctionDef(parse_snippet('''
        def one():
            yield 1
            return 5
    ''')) == parse_snippet('''
        def one():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')



# Generated at 2022-06-23 22:48:38.841182
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:48:39.831190
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:48:40.423379
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:41.414917
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:48:49.433108
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    input_tree = ast.parse('''
    def fn(x: int, y: int) -> int:
        y = 1
        return x + y
    ''')
    expected_tree = ast.parse('''
    def fn(x: int, y: int) -> int:
        y = 1
        exc = StopIteration()
        exc.value = x + y
        raise exc
    ''')
    assert transformer.visit(input_tree) == expected_tree

# Generated at 2022-06-23 22:48:51.912158
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def check(source, expected):
        module = ast.parse(source)
        assert_source(ReturnFromGeneratorTransformer().visit(module), expected)


# Generated at 2022-06-23 22:49:00.018253
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_ = ReturnFromGeneratorTransformer
    test_input = []
    test_subinput = []
    test_suboutput = []
    test_output = []

    test_input.append("""
        def a():
            yield 1
            return 2
    """)
    test_subinput.append("")
    test_suboutput.append("")
    test_output.append("""
        def a():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

    test_input.append("""
        def b():
            yield from a()
            return 2
    """)
    test_subinput.append("")
    test_suboutput.append("")

# Generated at 2022-06-23 22:49:03.309378
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()._find_generator_returns(
        ast.parse(
            '''def fn():
        yield 5
        if 1:
            return 5
        else:
            return 6'''
        ).body[0]
    )

# Generated at 2022-06-23 22:49:04.688886
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-23 22:49:06.177604
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert not transformer.tree_changed

# Generated at 2022-06-23 22:49:07.586537
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:49:16.207418
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from minivisitor.utils.node_utils import node2code

    class GeneratorReturnTransformer(BaseNodeTransformer):
        target = (3, 2)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            generator_returns = ReturnFromGeneratorTransformer._find_generator_returns(self, node)

            if generator_returns:
                for parent, return_ in generator_returns:
                    ReturnFromGeneratorTransformer._replace_return(self, parent, return_)

            return self.generic_visit(node)

    class FakeTransformer(BaseNodeTransformer):
        target = (3, 2)

        def __init__(self, root: ast.AST) -> None:
            super().__init__(root)
            self._tree_changed = False



# Generated at 2022-06-23 22:49:26.198613
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test visit_FunctionDef of ReturnFromGeneratorTransformer."""

    # That is no need to test if not any return in generator
    source = """def fn():
        yield 1
        yield 2
    """
    result = ReturnFromGeneratorTransformer().visit(ast.parse(source))
    assert ast.dump(result) == ast.dump(ast.parse(source))

    # No need to test if not generator
    source = """def fn():
        return 5
    """
    result = ReturnFromGeneratorTransformer().visit(ast.parse(source))
    assert ast.dump(result) == ast.dump(ast.parse(source))

    # That is no need to test if return in generator but in if statement
    source = """def fn():
        yield 1
        if True:
            return 5
    """
    result

# Generated at 2022-06-23 22:49:28.019118
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # noqa: D103
    instance = ReturnFromGeneratorTransformer()
    assert isinstance(instance, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:49:29.914515
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # __init__ method of class ReturnFromGeneratorTransformer
    assert ReturnFromGeneratorTransformer("name") == "name"


# Generated at 2022-06-23 22:49:31.021957
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:49:32.011342
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:40.234392
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..transformer import Transformer
    from ..utils.ast import parse
    from ..utils.source import source
    from ..utils.test_utils import assert_source_equal

    source_ = \
        """
        def fn():
            yield 1
            return 5
        """
    expected_source = \
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    tree = parse(source_)
    Transformer(ReturnFromGeneratorTransformer).visit(tree)
    assert_source_equal(source(tree), expected_source)

# Generated at 2022-06-23 22:49:49.882156
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import Module
    from .template import print_ast_node_visit_tests
    from .util import parse_ast


# Generated at 2022-06-23 22:49:50.463310
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:51.374470
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:56.504443
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import compile_function_with_transformer

    def fn():
        yield 1
        yield 2
        return 5

    fn_transformed = compile_function_with_transformer(return_from_generator_transform, fn)

    assert list(fn()) == [1, 2]
    assert fn_transformed() == 5


# Generated at 2022-06-23 22:49:58.264441
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = ReturnFromGeneratorTransformer()
    r

# Code for testing functionality of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:00.191137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # TODO: rewrite this test
    import ast as pyast

# Generated at 2022-06-23 22:50:09.970331
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .base import BaseNodeTransformer

    class ReturnFromGeneratorTransformer_visit_FunctionDef_One(BaseNodeTransformer):
        """Compiles return in generators like:
            def fn():
                yield 1
                return 5
        To:
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        """
        target = (3, 2)

        def _find_generator_returns(self, node):  # type: ignore
            # Using bfs find all `return` statements in function.
            to_check = [(node, x) for x in node.body]  # type: ignore
            returns = []
            has_yield = False
            while to_check:
                parent, current = to_check.pop()

# Generated at 2022-06-23 22:50:17.212063
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print('Testing method visit_FunctionDef of class ReturnFromGeneratorTransformer')

    import astunparse
    import textwrap

    # Define some code samples
    code = textwrap.dedent('''
        def f():
            yield 1
            yield 2
            return
        ''')
    code1 = textwrap.dedent('''
        def g(x):
            r = x
            return r
        ''')
    code2 = textwrap.dedent('''
        def h(x):
            for i in range(x):
                yield 1
                return 2
        ''')
    code3 = textwrap.dedent('''
        def i(x):
            if x > 10:
                return x
            else:
                return 0
        ''')
    code4 = textwrap.ded

# Generated at 2022-06-23 22:50:18.053006
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    trans = ReturnFromGeneratorTransformer()
    assert trans.target == (3, 2)

# Generated at 2022-06-23 22:50:23.128668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from pprint import pprint as pp
    from nuitka.ast.nodes.AssignNodes import ExpressionTargetVariableRef
    from nuitka.ast.nodes.ExprNodes import ExpressionRaiseException
    from nuitka.ast.nodes.OperatorNodes import ExpressionOperationBinary
    from nuitka.ast.nodes.SubscriptNodes import ExpressionSubscriptLookup
    from nuitka.ast.nodes.CallNodes import ExpressionCallNoKeywords
    from nuitka.ast.nodes.FunctionNodes import ExpressionFunctionBody
    from nuitka.ast.nodes.ClassNodes import ExpressionClassBody
    from nuitka.ast.nodes.OperandNodes import ExpressionAttributeLookup

# Generated at 2022-06-23 22:50:27.667503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    ReturnFromGeneratorTransformer().visit(tree)

    assert tree_equal(tree, """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)


# Generated at 2022-06-23 22:50:29.699472
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-23 22:50:36.018134
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def code():
        def fn():
            yield
            return 1

    node = ast.parse(code.get())

    transformer = ReturnFromGeneratorTransformer(node)
    transformer.visit(node)

    @snippet
    def expected_code():
        def fn():
            yield
            exc = StopIteration()
            exc.value = 1
            raise exc

    expected_node = ast.parse(expected_code.get())

    assert ast.dump(node) == ast.dump(expected_node)

# Generated at 2022-06-23 22:50:47.218681
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def fn1():
        yield 1
        return 5

    @snippet
    def fn2():
        for x in range(5):
            if x > 3:
                return x
            yield x

    @snippet
    def fn3():
        for x in range(5):
            yield x

    @snippet
    def fn4():
        for x in range(5):
            if x > 3:
                return x
            else:
                yield x

    @snippet
    def fn5():
        while True:
            if x > 3:
                return x
            yield x

    source = '''
        def fn():
            yield 1
            return 5
    '''

# Generated at 2022-06-23 22:50:50.123950
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer()
    assert 'target' in class_.__dict__
    expected_target = (3, 2)
    assert class_.__dict__['target'] == expected_target


# Generated at 2022-06-23 22:50:54.724389
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.livestream import SnippetLiveStream
    stream = SnippetLiveStream()
    return_from_generator.add_to_env(stream.env)

    def test_case(code: str) -> str:
        node = ast.parse(code)
        node = ReturnFromGeneratorTransformer().visit(node)
        return ast.dump(node, indent=2)

    assert tes

# Generated at 2022-06-23 22:51:00.882763
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = lambda: None
    f.__name__ = 'f'
    f.__code__ = compile(
        textwrap.dedent('''
        def f():
            a = 5
            b = 6
            yield 7
            return a + b
            '''),
        filename='<stdin>',
        mode='single',
    )

    f2 = lambda: None
    f2.__name__ = 'f2'
    f2.__code__ = compile(
        textwrap.dedent('''
        def f2():
            yield 7
            return 5
            '''),
        filename='<stdin>',
        mode='single',
    )

    f3 = lambda: None
    f3.__name__ = 'f3'

# Generated at 2022-06-23 22:51:10.245738
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Fn(ast.FunctionDef):
        def __init__(self, body):
            self.body = body

    tree = (Fn(body=[
        ast.Yield(value=ast.Num(n=1)),
        ast.Return(value=ast.Num(n=5))
    ]))


# Generated at 2022-06-23 22:51:15.672539
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__doc__ == 'Compiles return in generators like:\n    def fn():\n    \tyield 1\n    \treturn 5\nTo:\n    def fn():\n    \tyield 1\n    \texc = StopIteration()\n    \texc.value = 5\n    \traise exc\n'

# Generated at 2022-06-23 22:51:21.598643
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_function(a: int) -> int:
        if a < 3:
            return a
        else:
            return a + 1

    node = ast.parse(test_function.__code__)

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert result != node
    code = compile(result, '', 'exec')
    ns = {}
    exec(code, ns)
    assert ns['test_function'](2) == 2
    assert ns['test_function'](3) == 4



# Generated at 2022-06-23 22:51:24.323962
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    t(ReturnFromGeneratorTransformer.test_snippet.make_ast('return_from_generator'))



# Generated at 2022-06-23 22:51:31.322274
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import Generator
    class Test(Generator):
        target = (3, 2)

        def func_1(self):
            yield 1
            return 2

        def func_2(self):
            yield 1
            if 10 > 5:
                return 2
            yield 3

        def func_3(self):
            yield 1
            for i in range(1):
                yield i
                yield i + 1
            return 2

        def func_4(self):
            yield 1
            try:
                yield 2
            except Exception:
                raise
            else:
                return 10

        def func_5(self):
            yield 1
            try:
                yield 2
            finally:
                return 12

    test = Test(ReturnFromGeneratorTransformer)
    test.run()
    assert test.func_1() == 2

# Generated at 2022-06-23 22:51:38.019620
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = ReturnFromGeneratorTransformer()
    ast_tree = ast.parse('''
    def a():
        yield 1
        return 5
    def b():
        yield 1
        if True:
            return 5
        return 1
    def c():
        if True:
            yield 1
        else:
            return 1
    ''')
    # Adding type comments to prevent mypy error
    ast.fix_missing_locations(ast_tree)
    r.visit(ast_tree)
    assert ast_tree.body[0].body[1].value.func.id == "StopIteration"
    assert ast_tree.body[0].body[2].func.value.id == "StopIteration"

# Generated at 2022-06-23 22:51:39.664920
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:51:44.557354
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # First check that class is well formed
    tf = ReturnFromGeneratorTransformer()
    assert tf.target == (3, 2), "Transformer has wrong target version"
    assert tf._node_name == "return_from_generator_transformer", \
           "Transformer has wrong class name"
    assert tf._tree_changed is False, "Transformer has wrong value for tree_changed"

# Generated at 2022-06-23 22:51:45.393770
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  pass

# Generated at 2022-06-23 22:51:56.060773
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    snippet1 = """
    def fn():
        yield 1
        return 5
    """
    snippet2 = """
    def fn():
        yield 1
        if x:
            return
        else:
            return y
    """
    snippet3 = """
    def fn():
        for x in y:
            yield 1
    """
    snippet4 = """
    def fn():
        return
    """
    snippet5 = """
    def fn():
        try:
            return 1
        except:
            return 2
    """
    for snippet_ in [snippet1, snippet2, snippet3, snippet4, snippet5]:
        tree = ast.parse(snippet_)  # type: ignore
        ReturnFromGeneratorTransformer().visit(tree)
        assert tree is not None, "Wrong type of ast."

# Generated at 2022-06-23 22:51:58.428149
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer(3, 2).visit_FunctionDef(None) == None


# Generated at 2022-06-23 22:52:04.515803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..unittest_tools import assert_conversion

    @assert_conversion("""
    def gen():
        yield 1
        return 5

    def no_gen():
        return 5
        return 6
    """, ReturnFromGeneratorTransformer)
    def test_no_error():
        """
        def gen():
            yield 1
            if False:
                return 5
            exc = StopIteration()
            exc.value = 5
            raise exc

        def no_gen():
            return 5
            return 6

        """
        print(1)

# Generated at 2022-06-23 22:52:10.358935
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def test_1():
        let(g)
        def g():
            yield 1
            return 1
        # end def

        return g()
    # end def

    @snippet
    def test_2():
        let(g)
        def g():
            return 1
        # end def

        return g()
    # end def

    assert test_1.get_ast() == test_2.get_ast()
# end def

# Generated at 2022-06-23 22:52:15.078502
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer.visit_FunctionDef(ReturnFromGeneratorTransformer, ast.parse('def fn():\n    yield 1\n    return 5')) == ast.parse('def fn():\n    yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc')

# Generated at 2022-06-23 22:52:21.131375
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transform = ReturnFromGeneratorTransformer()
    node = ast.parse('def fn(): yield 1')
    transform.visit(node)
    assert str(node) == 'def fn(): yield 1'

    node = ast.parse('def fn(): yield 1; return 5')
    transform.visit(node)
    assert str(node) == 'def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc'

    node = ast.parse('def fn(): yield 1; if cond: return 5')
    transform.visit(node)
    assert str(node) == 'def fn(): yield 1; if cond:\n    exc = StopIteration(); exc.value = 5; raise exc'

# Generated at 2022-06-23 22:52:30.966698
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor  # type: ignore
    import unittest  # type: ignore
    from ..compat import PY36

    # test data
    class TestData(unittest.TestCase):
        def test_return_in_generator(self):
            transformer = ReturnFromGeneratorTransformer()
            source = '''
            @pytest.mark.asyncio
            async def test_no_client_id(self):
                with pytest.raises(ResourceNotFoundError):
                    await self.client.get_client_by_id(123)
                '''

# Generated at 2022-06-23 22:52:32.420364
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test constructor
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:52:33.790313
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3

# Generated at 2022-06-23 22:52:41.414793
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.test_utils import transform, assert_equal_code
    from ..utils.test_utils import assert_equal_ast

    code = dedent("""\
    def gen():
        yield 1
        return 5
    """)
    expected_code = dedent("""\
    def gen():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    res = transform(ReturnFromGeneratorTransformer, code)
    assert res is not None
    assert_equal_code(res, expected_code)

    expected_ast = transform(ast.parse, expected_code)
    assert_equal_ast(res, expected_ast)

# Generated at 2022-06-23 22:52:47.670001
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import assert_expression_equal, assert_expression_unmodified, assert_expression_raises
    from ..stage import Stage
    from typed_ast.ast3 import parse as parse3


# Generated at 2022-06-23 22:52:52.219922
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    def fn():
        yield 1
        return 5

    ast_ = ast.parse(fn.__code__)
    ReturnFromGeneratorTransformer().visit(ast_)
    code = compile(ast_, '<string>', 'exec')
    assert eval(code) == fn()

# Generated at 2022-06-23 22:52:59.544594
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    input_code = "def fn():\n  yield 1\n  return 5\n"
    output_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(input_code)  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)  # type: ignore
    code = compile(new_tree, "<ast>", "exec")
    assert(code.co_firstlineno == 1)
    assert(code.co_consts[0].co_firstlineno == 2)

# Generated at 2022-06-23 22:53:04.920246
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .sample_asts import ReturnFromGeneratorTransformer_visit_FunctionDef as sample_asts
    from ...utils.python_source import PythonSource
    for sample_ast in sample_asts:
        node = PythonSource(sample_ast.code).ast()
        output = ReturnFromGeneratorTransformer().visit(node)
        assert ast.dump(output) == sample_ast.output


# Generated at 2022-06-23 22:53:07.266370
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  rfgt = ReturnFromGeneratorTransformer()
  assert isinstance(rfgt, BaseNodeTransformer)
  assert rfgt.target == (3, 2)


# Generated at 2022-06-23 22:53:08.536198
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == "ReturnFromGeneratorTransformer"


# Generated at 2022-06-23 22:53:14.932712
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typing import Generator
    from ..utils.source_code import source_to_ast, ast_to_source

    def test(source: str, expected_source: str) -> None:
        node = source_to_ast(source)
        actual = ReturnFromGeneratorTransformer().visit(node)
        actual_source = ast_to_source(actual)  # type: ignore
        assert actual_source == expected_source

    # Normal generator function
    test.parametrize('', [
        '''
        def fn():
            yield 1
            return 5
        ''',
        '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''])

    # Generator function with return on several lines

# Generated at 2022-06-23 22:53:25.824938
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        def test_return_from_generator_transformer_visit_functiondef(self):
            test_code = """def fn():
    yield 1
    return 5\n"""
            expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc\n"""
            # expected_code = """def fn():
    # yield 1
    # return 5\n"""
            test_ast = ast.parse(test_code)
            ReturnFromGeneratorTransformer().visit(test_ast)
            self.assertEqual(ast.dump(test_ast), expected_code)

    suite = unittest.TestLoader().loadTestsFromTestCase(Test)

# Generated at 2022-06-23 22:53:30.435173
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing.transformer import assert_transformed

    def f():
        yield 1
        return 5

    assert_transformed(ReturnFromGeneratorTransformer, f, """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

# Generated at 2022-06-23 22:53:31.921147
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer()

    assert class_


# Generated at 2022-06-23 22:53:34.469601
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast.parse('def fn(): yield 1; return 5')
    fn = ReturnFromGeneratorTransformer()
    fn.run(ast.parse('def fn(): yield 1; return 5'))

# Generated at 2022-06-23 22:53:45.181066
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    class TestTransformer(ReturnFromGeneratorTransformer):
        """
        Example of testing of transformer.
        Use it as example to make your own tests.
        """
        def __init__(self):
            self._tree_changes = False
            self._tree_changed = False

        def generic_visit(self, node):
            """Traverse node, do not change anything"""
            return super().generic_visit(node)

        def visit_FunctionDef(self, node) -> ast.FunctionDef:
            """Visit function, collect changes."""
            tree_changed = self._tree_changed
            self._tree_changed = False

            result = super().visit_FunctionDef(node)

            self._tree_changes |= self._tree_changed

            self._tree_changed = tree_

# Generated at 2022-06-23 22:53:51.882127
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .test_base import get_ast_node

    expected_ast = get_ast_node(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    code = """
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(code)
    expected_tree = expected_ast.body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformed_tree = transformer.visit(tree)
    assert transformed_tree.body[0] == expected_tree

# Generated at 2022-06-23 22:54:01.379068
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.test import expect_code
    from .parse import parse
    from .split_functions import SplitFunctionsTransformer
    from .return_to_assignment import ReturnToAssignmentTransformer
    from .merge_functions import MergeFunctionsTransformer

    code = """\
        def fn():
            yield 1
            return 5
        """

    expected_code = """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        """

    tree = parse(code)
    tree_after_split = SplitFunctionsTransformer().visit(tree)
    tree_after_return_to_assignment = ReturnToAssignmentTransformer().visit(
        tree_after_split)
    tree_after_transform = ReturnFromGeneratorTransformer().visit

# Generated at 2022-06-23 22:54:07.604434
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..rabbit_hole import compile_to_ast

    def fn():
        yield 1
        yield 2
        return 5

    expected = compile_to_ast("""
        def fn():
            yield 1
            yield 2
            stop_iteration = StopIteration()
            stop_iteration.value = 5
            raise stop_iteration
    """)

    assert expected == ReturnFromGeneratorTransformer().visit(fn.__code__)



# Generated at 2022-06-23 22:54:10.988220
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(
        """def fn():
            yield 1
            return 5
        """
    )
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert transformer.tree_changed is True


# Generated at 2022-06-23 22:54:20.482402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_func():
        if True:
            yield 1
            yield 2
            return 3

    assert ReturnFromGeneratorTransformer().visit(test_func) == test_func

    def test_func():
        if True:
            yield 1
            return 2

    def test_func_compiled():
        exc = StopIteration()
        exc.value = 2
        raise exc

        yield 1
        return 2

    assert ReturnFromGeneratorTransformer().visit(test_func) == test_func_compiled

    def test_func():
        if True:
            return 1

    assert ReturnFromGeneratorTransformer().visit(test_func) == test_func

# Generated at 2022-06-23 22:54:22.266107
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    new_transformer = ReturnFromGeneratorTransformer()
    assert new_transformer is not None

# Generated at 2022-06-23 22:54:25.137790
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rft = ReturnFromGeneratorTransformer()
    rft.visit(ast.parse("""\
            def fn():
                yield 1
                return 5
            """))

# Generated at 2022-06-23 22:54:26.301765
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:54:36.361366
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(target=(3, 2))

    def_ = ast.parse('def fn(): 1').body[0]
    node = transformer.visit_FunctionDef(def_)
    assert node == def_

    def_ = ast.parse('def fn():\n yield 1').body[0]
    node = transformer.visit_FunctionDef(def_)
    assert node == def_

    def_ = ast.parse('def fn():\n yield 1\n return 1').body[0]
    node = transformer.visit_FunctionDef(def_)
    assert not node == def_

    def_ = ast.parse('def fn():\n 1\n if 1:\n  return 2\n else:\n  3').body[0]
    node = transformer.visit_FunctionDef(def_)


# Generated at 2022-06-23 22:54:41.180594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Given test function
    # Given function node
    node = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """).body[0]

    # When
    result = ReturnFromGeneratorTransformer().visit(node)

    # Then
    assert isinstance(result, ast.FunctionDef)
    assert isinstance(result.body[1], ast.Assign)
    assert isinstance(result.body[1].value, ast.Call)
    assert isinstance(result.body[1].value.func, ast.Name)
    assert isinstance(result.body[2], ast.Raise)
    assert isinstance(result.body[2].exc, ast.Name)
    assert isinstance(result.body[2].exc.ctx, ast.Load)

# Generated at 2022-06-23 22:54:45.615463
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_fn():
        yield 1
        return 5

    class TestClass:
        def test_method(self):
            yield 1
            return 5

    ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(test_fn)))
    ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(TestClass.test_method)))

# Generated at 2022-06-23 22:54:46.794529
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    obj = ReturnFromGeneratorTransformer()
    assert obj is not None

# Generated at 2022-06-23 22:54:49.143719
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer.generate_test_code()

# Generated at 2022-06-23 22:54:56.820734
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import load_python_module
    from ..utils.test_utils import assert_equal_source

    transformer = ReturnFromGeneratorTransformer()

    src = """
        def fn():
            yield 1
            return 2
    """
    correct_src = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    module = load_python_module(src)
    transformer.visit_Module(module)
    assert_equal_source(module.body[0], correct_src)

# Generated at 2022-06-23 22:54:57.509831
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:55:06.118306
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test simple generator with `return`.
    assert ReturnFromGeneratorTransformer().transform_code(  # type: ignore
        'def fn():\n    yield 1\n    return 3\n') == \
        'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 3\n    raise exc\n'

    assert ReturnFromGeneratorTransformer().transform_code(  # type: ignore
        'def fn():\n    yield 1\n    return\n') == 'def fn():\n    yield 1\n    return\n'

    # Test nested generators, only last one should have `return`.

# Generated at 2022-06-23 22:55:07.163103
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:17.506931
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .testutils import build_functiondef_node
    from ..utils.snippet import snippet_to_functiondef
    from ..utils.source_code import SourceCode
    from .. import parse

    src = '''
    def gen():
        yield 1
        return 1
    '''

    expected_src = '''
    def gen():
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    '''

    expected_node = SourceCode(expected_src, '<string>').get_node()
    node = SourceCode(src, '<string>').get_node()

    snip_fn = ReturnFromGeneratorTransformer().visit(parse(snippet_to_functiondef(return_from_generator)))

# Generated at 2022-06-23 22:55:20.806882
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    class_ = ReturnFromGeneratorTransformer(ast.parse("def fn(): yield 1\n"))

    # Act
    result = class_()

    # Assert
    assert isinstance(result, ast.FunctionDef)

# Generated at 2022-06-23 22:55:21.541964
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:25.970285
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer([])
    assert (return_from_generator_transformer.__class__.__name__ ==
            'ReturnFromGeneratorTransformer')
    assert (return_from_generator_transformer.__class__.target == (3, 2))
    assert (return_from_generator_transformer._tree_changed is False)

# Generated at 2022-06-23 22:55:31.742887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import _ast
    import astunparse
    code = '''def f():
                 yield x
                 return 5'''
    fn = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(fn)
    assert astunparse.unparse(fn) == '''def f():
    yield x
    exc = StopIteration()
    exc.value = 5
    raise exc'''



# Generated at 2022-06-23 22:55:33.369235
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tf = ReturnFromGeneratorTransformer()
    assert tf is not None



# Generated at 2022-06-23 22:55:34.826768
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert (x != None)

# Generated at 2022-06-23 22:55:37.490212
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """ Test methods of class ReturnFromGeneratorTransformer
    """
    from ..utils.testutils import test_ast, parse_ast
    t = ReturnFromGeneratorTransformer({})

# Generated at 2022-06-23 22:55:42.295893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    test_case = 'def func_name():\n yield 1\n return 5\n'
    expected_result = 'def func_name():\n exc=StopIteration()\n exc.value=5\n raise exc\n'
    tree = ast.parse(test_case)
    # print(ast.dump(tree))
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert expected_result == astor.to_source(tree)
    # print(astor.to_source(tree))


# Generated at 2022-06-23 22:55:43.493530
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import dump_python_source

# Generated at 2022-06-23 22:55:49.034827
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Before compilation
    f = '''
        def fn():
            yield 1
            return 5
            '''
    expected_f = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            '''

    # After compilation
    g = '''
        def fn():
            yield 1
            yield 2
            return 5
            '''
    expected_g = '''
        def fn():
            yield 1
            yield 2
            exc = StopIteration()
            exc.value = 5
            raise exc
            '''

    transformer = ReturnFromGeneratorTransformer()
    new_f = transformer.visit(ast.parse(f))  # type: ignore
    new_g = transformer.visit(ast.parse(g))  # type: ignore



# Generated at 2022-06-23 22:55:59.769926
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    m_compile_strings = MagicMock()
    source_code = 'def foo(a, b):\n\tfor i in range(a, b):\n\t\treturn 1'
    m_compile_strings.return_value = ast.parse(source_code)
    m_compile_strings.return_value.compile()

# Generated at 2022-06-23 22:56:05.179237
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
    def fn():
        yield 1
        return 2
    ''')
    actual = ReturnFromGeneratorTransformer().visit(node)
    expected = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    ''')
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 22:56:10.401822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Test simple case with one yield and one return.
    """
    input = """def fn(x):\n    yield x\n    return x + 5"""
    expected_output = """def fn(x):\n    yield x\n    exc = StopIteration()\n    exc.value = x + 5\n    raise exc"""
    tree = ast.parse(input)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    output = ast.unparse(tree)
    assert output == expected_output


# Generated at 2022-06-23 22:56:11.785492
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:56:15.452361
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import compile
    exec(compile(
        '''
        def fn():
            yield 1
            return 5
        ''',
        ReturnFromGeneratorTransformer))
    assert fn().__next__() == 1
    assert fn().__next__().__next__() == 5


# Generated at 2022-06-23 22:56:23.720482
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(ast.parse(
        """
        def a():
            print('hello')
            return 1
        def b():
            print('hello')
        def c():
            yield 1
            return 1
        """
    )) == ast.parse(
        """
        def a():
            print('hello')
            return 1
        def b():
            print('hello')
        def c():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
        """
    )

# Generated at 2022-06-23 22:56:24.344862
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:25.292992
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:26.814193
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # class TestClass(ast.NodeTransformer):
    #     pass
    pass



# Generated at 2022-06-23 22:56:29.434966
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    assert transformer is not None

# Generated at 2022-06-23 22:56:31.679407
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer."""
    assert ReturnFromGeneratorTransformer("", "", "", "")

# Generated at 2022-06-23 22:56:33.973597
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class RC(ReturnFromGeneratorTransformer):
        pass
    r = RC()
    assert isinstance(r, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:56:36.033694
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:46.966104
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('''
    def fn():
        yield 1
        return 5
    def fn2():
        return 5
    def fn3():
        return
    def fn4():
        yield from range(10)
        return 5
    ''')

    compiled = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    def fn2():
        return 5
    def fn3():
        return
    def fn4():
        yield from range(10)
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert tree == compiled


# Generated at 2022-06-23 22:56:56.132899
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Create a new instance of ReturnFromGeneratorTransformer
    Return = ReturnFromGeneratorTransformer()

    # Create a test target
    target = ast.FunctionDef(
        name="fn",
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Yield(value=ast.Num(n=1)),
            ast.Return(value=ast.Num(n=2))
        ],
        decorator_list=[
        ],
        returns=None
    )

    # Check if the target has been transformed
    assert Return.visit(target) == target


# Generated at 2022-06-23 22:56:57.364674
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)._tree_changed == False

# Generated at 2022-06-23 22:57:06.369864
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor

    with open('test_cases/test_ReturnFromGeneratorTransformer.py') as fp:
        file_string = fp.read()

    # Parse string and check the result
    tree = ast.parse(file_string)
    assert tree is not None

    # Transform tree and check the result
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert tree is not None
    actual_tree_string = astor.to_source(tree)

    for module in tree.body:
        if (isinstance(module, ast.FunctionDef) and
                module.name == "return_from_generator"):
            expected_tree_string = astor.to_source(module)
            break

    assert actual_tree_string == expected_tree_string



# Generated at 2022-06-23 22:57:07.221876
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:18.077626
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transform import transform
    from .base import get_ast

    code = """
        def fn():
            yield 1
            return 5
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration\n\
            exc.value = 5
            raise exc
    """

    node = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    transform(node, result)

    result = compile(result, "", "exec")
    exec(result)

    o = fn()
    assert next(o) == 1
    assert o.send(None) == 5

    code = """
        def fn():
            return 5
    """

    expected = """
        def fn():
            return 5
    """

    node = get_

# Generated at 2022-06-23 22:57:20.690717
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer != None

# Generated at 2022-06-23 22:57:23.383711
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Test case for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    """

# Generated at 2022-06-23 22:57:23.736920
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:29.277602
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import generate_code
    import astor

    module_ast = ast.parse('def fn(): yield 1; return 2')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module_ast)
    assert astor.to_source(module_ast) == 'def fn(): yield 1; exc = StopIteration(); exc.value = 2; raise exc'

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-23 22:57:30.562323
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse

# Generated at 2022-06-23 22:57:36.553397
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test function
    def test(function):
        print("=======================")
        print(" Testing: " + function)
        node = ast.parse(function)
        rfg = ReturnFromGeneratorTransformer()
        new_node = rfg.visit(node)
        print("Converted to:")
        print(ast.unparse(new_node))


# Generated at 2022-06-23 22:57:45.548198
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:46.734924
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-23 22:57:58.038473
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import ast_to_source
    from .base import BaseNodeTransformer


# Generated at 2022-06-23 22:57:59.974195
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:09.027873
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def transform(stmt):
        module = ast.parse(stmt)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(module)
        return module

    def test(stmt, expected):
        module = transform(stmt)
        assert ast.dump(module) == expected

    test('def fn():\n    yield 1', 'Module(body=[FunctionDef(name=\'fn\', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Yield(value=Num(n=1)))], decorator_list=[], returns=None)])')

# Generated at 2022-06-23 22:58:10.277657
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None)
    return transformer

# Generated at 2022-06-23 22:58:12.128345
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:22.408433
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from typing import List, Tuple, Any
    from typed_ast import ast3 as ast

    class Dummy(BaseNodeTransformer):
        def __init__(self, tree, module_name) -> None:
            super(Dummy, self).__init__(tree, module_name)

        @staticmethod
        def _find_generator_returns(node: ast.FunctionDef)-> List[Tuple[ast.stmt, ast.Return]]:
            return_statement_1 = ast.Return(value=ast.Num(n=10))
            return_statement_2 = ast.Return(value=ast.Num(n=20))
            parent_stmt_1= ast.Expr(value=ast.Num(n=10))
            parent_stmt_2= ast.Ex