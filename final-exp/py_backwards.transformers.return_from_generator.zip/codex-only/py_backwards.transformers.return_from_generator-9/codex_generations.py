

# Generated at 2022-06-23 22:48:23.995307
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    sut = ReturnFromGeneratorTransformer()
    assert sut is not None

# Generated at 2022-06-23 22:48:24.972212
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:30.052134
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    node = astor.parse('def foo():\n  yield 1\n  return 5').body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert astor.to_source(node) == 'def foo():\n  yield 1\n  exc = StopIteration()\n  exc.value = 5\n  raise exc'



# Generated at 2022-06-23 22:48:35.514578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Tests whether the generated code is correct."""
    input = """
        def fn():
            yield 1
            return 5
    """
    output = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    transformer = ReturnFromGeneratorTransformer()

    tree = ast.parse(input)
    transformer.visit(tree)
    actual_output = ast.unparse(tree)

    assert actual_output.strip() == output.strip()



# Generated at 2022-06-23 22:48:36.372061
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:47.839098
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def check(src: str, expected_src: str) -> None:
        actual_src = ReturnFromGeneratorTransformer(
            src,
            filename='<test>').modify()
        assert actual_src == expected_src

    check(src='def fn():\n r',
          expected_src='def fn():\n r')
    check(src='def fn():\n yield 1\n r',
          expected_src='def fn():\n yield 1\n r')
    check(src='def fn():\n yield 1\n return',
          expected_src='def fn():\n yield 1\n return')

# Generated at 2022-06-23 22:48:57.466439
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    module = ast.parse("def fn():\n  yield 1\n  return 5")
    t.visit(module)

# Generated at 2022-06-23 22:49:00.273134
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..function import FunctionDefinition
    from ..utils.source import source_to_str
    from .base import BaseUnparseTransformer


# Generated at 2022-06-23 22:49:02.492717
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Return, Name, Pass, FunctionDef
    from .. import compile_isolated
    from ..utils import set_up_module


# Generated at 2022-06-23 22:49:12.400399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 22:49:14.510214
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    '''
    it('Create an instance of ReturnFromGeneratorTransformer', () => {
        const x = new ReturnFromGeneratorTransformer();
    });
    '''



# Generated at 2022-06-23 22:49:16.150149
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:26.166740
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Tests the visit_FunctionDef of method ReturnFromGeneratorTransformer."""

    # Test with return in an empty function
    node = ast.parse('''
        def fn():
            return 42
    ''')[0]
    node = ReturnFromGeneratorTransformer().visit(node)
    node = ast.fix_missing_locations(node)
    assert ast.dump(node) == ast.dump(ast.parse('''
        def fn():
            exc = StopIteration()
            exc.value = 42
            raise exc
    ''')[0])

    # Test with return in a function with content
    node = ast.parse('''
        def fn():
            x = 5
            y = x ** 3
            return y
    ''')[0]
    node = ReturnFromGeneratorTransformer().visit

# Generated at 2022-06-23 22:49:30.862455
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .ast_converter import convert_node
    from .base import BaseAstNodeTester

    class TestReturnFromGeneratorTransformer(BaseAstNodeTester):
        TRANSFORMER = ReturnFromGeneratorTransformer

        @staticmethod
        def make_test_snippet(fn_body, **kwargs):
            fn_name = 'test'

# Generated at 2022-06-23 22:49:35.284946
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Since we are using `raise` in the return_from_generator snippet, we need to enable
    # the python 3 syntax via `from __future__ import generator_stop`
    future_import = ast.parse('from __future__ import generator_stop').body[0]

# Generated at 2022-06-23 22:49:37.362777
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:49:43.862847
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    code = """def fn():
    yield 1
    return 5"""
    expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    tree = ast.parse(code)
    # pylint: disable=protected-access
    return_from_generator_transformer.visit(tree)
    assert ast.dump(tree) == expected_code


# Generated at 2022-06-23 22:49:50.783712
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    RETURN_FROM = "return 5"
    YIELD = "yield 1"
    FUNCTION_DEF = ast.parse(f"""def fn():\n{YIELD}\n{RETURN_FROM}""",
                             mode="exec").body[0]
    expected_node = ast.parse(
        f"""def fn():\n{YIELD}\nexc = StopIteration()\nexc.value = 5\nraise exc""",
        mode="exec").body[0]
    changed_node = ReturnFromGeneratorTransformer().visit(FUNCTION_DEF)

    assert changed_node == expected_node

# Generated at 2022-06-23 22:49:52.084066
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert type(ReturnFromGeneratorTransformer()) == ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:02.960045
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .rename_augassign import RenameAugAssignTransformer
    from .two_to_three import TwoToThreeTransformer
    from .extract_variables import ExtractVariablesTransformer
    from .inline_assignments import InlineAssignmentsTransformer
    from ..utils import get_node

    def compile(src: str) -> str:
        node = get_node(src)
        TwoToThreeTransformer().visit(node)
        RenameAugAssignTransformer().visit(node)
        ExtractVariablesTransformer().visit(node)
        InlineAssignmentsTransformer().visit(node)
        ReturnFromGeneratorTransformer().visit(node)
        return ast.unparse(node)

    assert compile('def f(): return 0') == 'def f():\n    return 0'
   

# Generated at 2022-06-23 22:50:12.184197
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def f():
        yield 1
        # Testing comment
        return 5

    expected_return_value = ast.Num(5)


# Generated at 2022-06-23 22:50:12.904011
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equals


# Generated at 2022-06-23 22:50:14.426824
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # FIXME: assert other attributes
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:25.190803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from mypy.nodes import MypyFile
    from mypy import units

    test_data = '''
        def foo() -> None:
            yield 1
            return 5
        '''
    tree = ast.parse(test_data)
    unit = units.Unit(tree=tree, path='/tmp/main.py')
    file_node = MypyFile(path='/tmp/main.py', source=test_data)
    fnt = ReturnFromGeneratorTransformer(unit)
    fnt.visit_function_def(file_node.items[0])

    assert str(file_node.items[0].body[0]) == 'return_value = 1'
    assert str(file_node.items[0].body[1]) == 'yield return_value'

# Generated at 2022-06-23 22:50:33.787503
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ast import parse
    from ..utils.code import Code
    from ..utils.compiler import compile_code_object
    from ..utils.python_source import PythonSource
    code_text = """
        def fn():
            yield 1
            return 5
        """
    code = Code(PythonSource(code_text))
    node = parse(code_text)
    node = ReturnFromGeneratorTransformer()(node)
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    actual = compile_code_object(code.compile(node))
    assert actual == expected

# Generated at 2022-06-23 22:50:36.141176
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:50:39.897079
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:48.696917
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_snippet(code):
        # type: (str) -> None
        fn = ast.parse(code)
        fn = ReturnFromGeneratorTransformer().visit(fn)
        fn = ast.fix_missing_locations(fn)  # type: ignore
        fn = compile(fn, '<string>', 'exec')
        namespace = {}
        exec(fn, namespace)

        assert namespace['f']() == 5

    yield test_snippet, """\
        def f():
            yield 1
            return 5
        """

    yield test_snippet, """\
        def f():
            yield 1
            if True:
                return 5
        """


# Generated at 2022-06-23 22:50:54.090344
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse  # type: ignore
    source = """\
    def fn():
        yield 1
        return 5
    """
    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert unparse(tree) == expected


# Generated at 2022-06-23 22:50:57.320824
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def gen():
        yield 1
        return 1
    fn = gen()
    assert fn.__class__.__name__ == 'generator'
    assert next(fn) == 1
    with pytest.raises(StopIteration) as exc:
        next(fn)
    assert exc.value.value == 1

# Generated at 2022-06-23 22:50:58.080706
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:51:00.404811
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .minify_ast import remove_python_ast_extra_nodes
    from .remove_assertions import RemoveAssertionsTransformer
    from .remove_assertions import remove_assertions
    from typed_ast.ast3 import parse
    import astunparse


# Generated at 2022-06-23 22:51:08.560042
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .stubs import module, funcdef, yield_, return_

    # Simple return
    returntype = funcdef(
        name='fn',
        body=[
            yield_(
                1
            ),
            return_(
                5
            )
        ]
    )
    assert ReturnFromGeneratorTransformer().visit(returntype) == module(
        body=[
            returntype(
                body=[
                    yield_(
                        1
                    ),
                    return_from_generator.body[-2:-1][0],
                    return_from_generator.body[0:-2][0],
                ],
                name='fn',
            ),
        ]
    )

# Generated at 2022-06-23 22:51:10.154558
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:51:20.017030
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import node_equal
    input = (
        ast.FunctionDef(
            name='fn',
            args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
            body=[
                ast.Yield(value=ast.Num(n=1)),
                ast.Return(value=ast.Num(n=5))
            ],
            decorator_list=[],
            returns=None
        )
    )


# Generated at 2022-06-23 22:51:29.243127
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer() # type: ReturnFromGeneratorTransformer
    tree = ast.parse('''
    def foo():
        yield 1
        yield 2
        return 5
    def bar():
        return 5
    ''')

    return_from_generator.setup()
    new_tree = transformer.visit(tree)
    return_from_generator.teardown()

    assert transformer._tree_changed
    assert ast.dump(new_tree) == ast.dump(ast.parse('''
    def foo():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 5
        raise exc
    def bar():
        return 5
    '''))

# Generated at 2022-06-23 22:51:29.720705
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:36.698884
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import NodeTestCase
    from typed_ast import ast3 as ast
    from typing import Any

    class Test(NodeTestCase):
        target_cls = ast.FunctionDef
        transformer = ReturnFromGeneratorTransformer
        transformer_kwargs = {'target': (3, 2)}

        def create_node(self) -> ast.FunctionDef:
            name = 'gen'
            args = ast.arguments(args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[])
            returns = ast.Return(value=ast.Str(s='hi'))
            body = [ast.Yield(value=ast.Str(s='hi')), returns]
            decorator_list = []


# Generated at 2022-06-23 22:51:44.375984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import pretty_print, compare_asts
    from ..plugins import Plugin

    code = """
        from typing import Any, Iterator
        import random

        def fn() -> Iterator[Any]:
            yield random.random()
            return 1
    """
    expected = """
        from typing import Any, Iterator
        import random

        def fn() -> Iterator[Any]:
            yield random.random()
            exc = StopIteration()
            exc.value = 1
            raise exc
    """
    compare_asts(code, expected, Plugin.ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:51:55.546083
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from .code_generator import CodeGenerator
    from .doc_string_transformer import DocStringTransformer
    from .multiline_lambda import MultilineLambdaTransformer
    from .print_function import PrintFunctionTransformer

    # Setup input
    source = """\
        def fn():
            yield 1
            return 5
    """
    source_tree = ast.parse(source)
    expected_source = """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_tree = ast.parse(expected_source)
    filename = 'test.py'

    # Setup transformer
    transformer = ReturnFromGeneratorTransformer()

    # Unit test
    BaseNodeTransformerTest.test_

# Generated at 2022-06-23 22:51:58.325152
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:00.097993
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:07.724823
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test for empty function
    def fn1():
        pass
    old_fn1 = fn1
    fn1 = ReturnFromGeneratorTransformer().visit(fn1)
    assert fn1 == old_fn1

    # Test for function without yield or return
    def fn2():
        print(2)
    old_fn2 = fn2
    fn2 = ReturnFromGeneratorTransformer().visit(fn2)
    assert fn2 == old_fn2

    # Test for function with yield but without return
    def fn3():
        yield 3
    old_fn3 = fn3
    fn3 = ReturnFromGeneratorTransformer().visit(fn3)
    assert fn3 == old_fn3

    # Test for function with yield and with return
    def fn4():
        yield 4
        return 5
    old_fn

# Generated at 2022-06-23 22:52:14.897096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source = dedent('''\
    def fn():
        yield 1
        return 5
    ''')
    tree = ast.parse(source)
    t = transformer.visit(tree)
    assert transformer._tree_changed is True
    expected = dedent('''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert ast_to_source(t) == expected

# Generated at 2022-06-23 22:52:17.988661
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected = """\
        def test():
            yield 1
            exc = StopIteration
            exc.value = 5
            raise exc
    """
    node = ast.parse("""\
        def test():
            yield 1
            return 5
    """)
    actual = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(actual) == expected

# Generated at 2022-06-23 22:52:18.711524
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:29.074878
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils.compile_to_ast import compile_to_ast

    class TestClass(object):
        def fn():
            yield 1
            return 5

        def fn1():
            pass

        def fn2():
            yield 1
            return 5

        def fn3():
            yield 1
            yield 5

        def fn4():
            return 5

        def fn5():
            return None

        def fn6():
            return

    module_ast = compile_to_ast(TestClass)
    transformer = ReturnFromGeneratorTransformer()
    new_module_ast = transformer.visit(module_ast)
    assert transformer.tree_changed is True

# Generated at 2022-06-23 22:52:30.202383
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:39.484978
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:44.281609
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..test_utils import assert_transformation_result
    from ..test_utils import parse_to_ast

    assert_transformation_result(
        ReturnFromGeneratorTransformer,
        before=('''
        def fn():
            yield 1
            return 5
        '''),
        after=('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        '''),
        parse=parse_to_ast
    )



# Generated at 2022-06-23 22:52:44.885717
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:54.388245
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import transforms_test
    t = transforms_test.ReturnFromGeneratorTestCase()
    t.test_replace_return()
    t.test_handle_multiple_returns()
    t.test_check_for_yield()
    t.test_check_for_yield_from()
    t.test_ignore_bare_returns()
    t.test_allow_bare_returns_in_generators()
    t.test_handle_loops()
    t.test_handle_while_loops()
    t.test_handle_if_else_loops()
    t.test_handle_if_else_loops_in_function()
    t.test_handle_if_else_loops_with_return()


# Generated at 2022-06-23 22:52:56.951448
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import verify_ast
    from .test_utils import extract_body, load_dict_ast


# Generated at 2022-06-23 22:53:02.114450
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import Compiler
    a = """
    def fn():
        yield 4
        return 5
    """
    b = """
    def fn():
        yield 4
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    Compiler.assert_program(a, b)



# Generated at 2022-06-23 22:53:08.101514
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_helpers import assert_transform

    # noinspection PyStatementEffect
    assert_transform(
        """
        def foo():
            yield 1
            return 3
        def bar():
            yield 1
        def baz():
            pass
        """,
        """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 3
            raise exc
        def bar():
            yield 1
        def baz():
            pass
        """
    )

# Generated at 2022-06-23 22:53:15.379859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case 1
    code = '''def fn():
    yield a
    return b'''
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    output = ast.fix_missing_locations(ast.Module(body=[tree.body[0]]))
    expect = ast.parse('''def fn():
    yield a
    exc = StopIteration()
    exc.value = b
    raise exc''')
    assert ast.dump(output) == ast.dump(expect)

    # Test case 2
    code = '''def fn():
    yield a
    return None'''
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:53:19.276023
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    # Create instance
    transformer = ReturnFromGeneratorTransformer()

    # Act
    # Call method visit_FunctionDef
    transformer.visit_FunctionDef()

# Generated at 2022-06-23 22:53:23.998372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    result = ReturnFromGeneratorTransformer().transform_source(source)
    assert expected == result

# Generated at 2022-06-23 22:53:24.904674
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:53:31.636246
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..snippets import ast_parse

    n = ast_parse(
        '''
        def f():
            yield 2
            return 3
        '''
    )
    t = ReturnFromGeneratorTransformer()
    t(n)

    assert ast_parse(
        '''
        def f():
            yield 2
            exc = StopIteration()
            exc.value = 3
            raise exc
        '''
    ) == n, 'ReturnFromGeneratorTransformer should correctly transform return values'

# Generated at 2022-06-23 22:53:40.355057
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(code):
        transformer = ReturnFromGeneratorTransformer()
        tree = ast.parse(code)
        transformer.visit(tree)
        return tree

    assert test('def fn():\n yield 1\n return 2') == \
        ast.parse('def fn():\n yield 1\n exc = StopIteration()\n exc.value = 2 \n raise exc')

    assert test('def fn():\n yield 1\n return 2\n return 3') == \
        ast.parse('def fn():\n yield 1\n exc = StopIteration()\n exc.value = 2 \n raise exc\n return 3')


# Generated at 2022-06-23 22:53:43.242357
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ret_fn = lambda : 1
    ret = ReturnFromGeneratorTransformer()
    assert ret_fn == ret_fn
    assert ret.target == (3,2)


# Generated at 2022-06-23 22:53:51.698814
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    def test(node, loc):
        transformer = ReturnFromGeneratorTransformer()
        actual_node = transformer.visit(node)

        actual_body = actual_node.body[loc]
        assert isinstance(actual_body, ast.Assign)
        assert actual_body.targets[0].id == 'exc'
        assert actual_body.value.id == 'StopIteration'

        actual_body = actual_node.body[loc + 1]
        assert isinstance(actual_body, ast.Assign)
        assert actual_body.targets[0].value.id == 'exc'
        assert actual_body.targets[0].attr == 'value'
        actual_value = actual_body.value

# Generated at 2022-06-23 22:54:01.207363
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import get_node


# Generated at 2022-06-23 22:54:02.146937
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:04.279262
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """ Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    """

# Generated at 2022-06-23 22:54:13.079785
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import Source
    from ..utils.testing import expect, expect_error, run_all_tests, TestError
    expect(ReturnFromGeneratorTransformer(Source("def fn():\n"
                                                  "    yield 1\n"
                                                  "    return 5\n")).visit_FunctionDef) \
        .to_equal(Source("def fn():\n"
                         "    yield 1\n"
                         "    exc = StopIteration()\n"
                         "    exc.value = 5\n"
                         "    raise exc\n"))

# Generated at 2022-06-23 22:54:14.029752
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:54:21.156455
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .tester import codegen
    from .ast_converter import convert

    root = convert('''
    def fn():
        yield 1
        return 5
    ''')

    converter = ReturnFromGeneratorTransformer()
    new_root = converter.visit(root)
    assert codegen(new_root) == codegen(convert('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''))



# Generated at 2022-06-23 22:54:32.367831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    # Provided by test_utils_ast
    from .utils import ast_for_source
    from .utils import dump_stmt


# Generated at 2022-06-23 22:54:40.680842
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    func = ast.parse("""
    def only_yield():
        yield 1
        yield 2
    """).body[0]
    assert not ReturnFromGeneratorTransformer._find_generator_returns(func)
    assert not ReturnFromGeneratorTransformer().visit(func)

    func = ast.parse("""
    def all_generators():
        yield 1
        return 1
        yield 2
        return 2
    """).body[0]
    assert (list(map(lambda parent_return: parent_return[1], ReturnFromGeneratorTransformer._find_generator_returns(func)))) == [ast.parse("return 1").body[0], ast.parse("return 2").body[0]]
    assert not ReturnFromGeneratorTransformer().visit(func)


# Generated at 2022-06-23 22:54:41.871404
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(source_version=None, target_version=None)

# Generated at 2022-06-23 22:54:46.595387
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .return_from_generator import ReturnFromGeneratorTransformer
    transformer = ReturnFromGeneratorTransformer()
    def fn():
        yield 1
        return 5
    node = ast.parse(fn.__code__)
    node = transformer.visit(node)
    node.body[0].body[1].value.func.id == "StopIteration" # return is replaced with StopIteration


# Generated at 2022-06-23 22:54:49.145309
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:50.532231
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)



# Generated at 2022-06-23 22:55:02.219659
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import const

    transformer = ReturnFromGeneratorTransformer()

    transformed = transformer.visit(ast.parse('''\
        def fn():
            yield 'a'
            return 5
'''))

    assert len(transformed.body) == 1
    fn = transformed.body[0]
    assert isinstance(fn, ast.FunctionDef)
    assert len(fn.body) == 4
    assert isinstance(fn.body[1], ast.Expr)
    assert isinstance(fn.body[1].value, ast.Yield)
    assert const(fn.body[1].value.value) == 'a'
    assert isinstance(fn.body[2],  ast.Assign)
    assert const(fn.body[2].targets[0]) == 'exc'

# Generated at 2022-06-23 22:55:12.983717
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    assert len(transformer._find_generator_returns(ast.parse("def fn(): return 1"))) == 0
    assert len(transformer._find_generator_returns(ast.parse("def fn(): yield 1"))) == 0
    assert len(transformer._find_generator_returns(ast.parse("def fn(): yield 1; return 1"))) == 1
    assert len(transformer._find_generator_returns(ast.parse("def fn():\n    yield 1\n    return 1\n"))) == 1
    assert len(transformer._find_generator_returns(ast.parse("def fn():\n    if True:\n        yield 1\n    return 1\n"))) == 1

# Generated at 2022-06-23 22:55:22.551393
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from typed_ast import ast3 as ast
    from ..utils.test_utils import build_program_from_snippets, compare_ast
    from jr import return_from_generator
    from jr.transformers.return_transformer import ReturnTransformer

    @snippet
    def function_with_generator_return(arg):
        let(a, b)
        a = 5
        b = 6
        yield a
        return b

    @snippet
    def function_with_generator_return_and_branches(arg):
        let(a, b, c)
        a = 5
        b = 6
        c = arg
        if c:
            yield a
        else:
            yield b
        return c


# Generated at 2022-06-23 22:55:29.605323
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    class Reverse:
        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return f"Reverse({self.x})"

        def __iter__(self):
            while True:
                if self.x <= 0:
                    raise StopIteration()
                yield self.x
                self.x -= 1

        def __getitem__(self, x: int) -> int:
            if x < 0:
                raise IndexError()
            return x + self.x

    class ReverseSquares:
        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return f"ReverseSquares({self.x})"


# Generated at 2022-06-23 22:55:30.572315
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:35.144248
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test for constructor of class ReturnFromGeneratorTransformer."""
    node = ast.parse("def fn():\n yield 1\n return 5")
    transf = ReturnFromGeneratorTransformer()
    transf.visit(node)
    # print(astunparse.unparse(node))
    assert node.body[0].body[1].value.func.id == "StopIteration"

# Generated at 2022-06-23 22:55:40.206716
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    as_source = '''
    def fn():
        yield 1
        return 5
    '''
    as_target = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    src = ast.parse(as_source)
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(src)
    assert transformer._tree_changed is True
    assert ast.dump(res, include_attributes=True) == ast.dump(ast.parse(as_target), include_attributes=True)



# Generated at 2022-06-23 22:55:43.415071
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer(None).visit_FunctionDef(
        ast.parse('def f():\n'
                  '    yield 1\n'
                  '    return 5\n')
    ) == ast.parse(return_from_generator.get(return_value='5'))
# test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-23 22:55:49.215322
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def fn(a):
        yield 1
        return a
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))
    g = fn(1)
    assert g.__next__() == 1
    assert g.__next__() == 1
    assert g.__next__() == 1

    g = fn(2)
    assert g.__next__() == 1
    assert g.__next__() == 2
    assert g.__next__() == 2

# Generated at 2022-06-23 22:55:56.163491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
        def fn(a):
            yield 2
            yield a
            return 5
    ''')

    expected = ast.parse('''
        def fn(a):
            yield 2
            yield a
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)

    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 22:56:01.979712
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import compile_to_ast
    from test.test_transformer import get_visitor_output
    from test.fixtures import simple_generator

    transformer = ReturnFromGeneratorTransformer()

    assert get_visitor_output(transformer, compile_to_ast(simple_generator)) == compile_to_ast(simple_generator)

    # Unit test for method replace_return of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:10.292778
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def f(): yield 42; return 7').body[0]

    assert list(node.body) == [
        ast.Yield(
            value=ast.Num(n=42),
            lineno=1,
            col_offset=6
        ),
        ast.Return(
            value=ast.Num(n=7),
            lineno=1,
            col_offset=14
        )
    ]

    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(node)


# Generated at 2022-06-23 22:56:14.142893
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformerTest
    from .tests.fixtures.return_from_generator import before
    from .tests.fixtures.return_from_generator import after

    return BaseNodeTransformerTest.test_node_transformer(ReturnFromGeneratorTransformer,before,after)

# Generated at 2022-06-23 22:56:20.463711
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Should not change FunctionDef without Yields
    def fn():
        return 1
    assert not ReturnFromGeneratorTransformer().visit(fn)

    # Should replace all GeneratorReturns
    def fn():
        yield 1
        return 2
    assert ReturnFromGeneratorTransformer().visit(fn)

    # Should replace only generator returns with non None values
    def fn():
        yield 1
        return 2
        yield 3
        return None
    assert ReturnFromGeneratorTransformer().visit(fn)

# Generated at 2022-06-23 22:56:29.471341
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..ast_analyser.plagiarism_checker import ast_equals
    import ast
    # We should have exactly the same trees
    tree1 = ast.parse('''def foo():
        yield 1
        return 2''')
    tree2 = ast.parse('''def foo():
    yield 1; exc = StopIteration(); exc.value = 2; raise exc''')
    tree1 = ReturnFromGeneratorTransformer().visit(tree1)
    assert ast_equals(tree1, tree2) is True
    # More complex case
    tree1 = ast.parse('''def foo():
        yield 1
        if True:
            return 2
        else:
            return 3''')

# Generated at 2022-06-23 22:56:38.733499
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..ast_compare import compare_trees
    from .test_fixtures import transformer_test_file_simple
    from .test_fixtures import simple_return_from_generator_test_cases

    directory = transformer_test_file_simple('return_from_generator')

    for file_name in simple_return_from_generator_test_cases:
        file = directory.joinpath(file_name)
        with file.open() as f:
            source = ''.join(f.readlines())

        tree = ast.parse(source)
        tree_copy = copy.deepcopy(tree)

        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)

        assert transformer._tree_changed
        assert compare_trees(tree_copy, tree, file_name)



# Generated at 2022-06-23 22:56:41.907334
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer
    assert class_.__name__ == "ReturnFromGeneratorTransformer"
    assert class_.__qualname__ == "ReturnFromGeneratorTransformer"


# Generated at 2022-06-23 22:56:48.712153
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    class ReturnFromGeneratorTransformer:
        def visit_FunctionDef(self, node):
            ...
    """
    # Initialization
    test_node = ast.parse("def fn(): return 5").body[0]
    gen = ReturnFromGeneratorTransformer()
    # Call of method
    res = gen.visit_FunctionDef(test_node)
    # Verification of the method result
    assert ast.dump(res) == ast.dump(ast.parse("def fn(): exc = StopIteration(); exc.value = 5; raise exc").body[0])

# Generated at 2022-06-23 22:56:52.522236
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def fn():
        yield 1
        return 5

    node = ast.parse(textwrap.dedent(inspect.getsource(fn)))
    node = ReturnFromGeneratorTransformer().visit(node)
    assert node.body[0].body[1].value.func.attr == 'StopIteration'



# Generated at 2022-06-23 22:56:53.426644
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast.parse('print("This works")') == ReturnFromGeneratorTransformer().visit(ast.parse('print("This works")'))


# Generated at 2022-06-23 22:56:54.344897
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-23 22:57:01.568460
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class SampleTransformer(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node: ast.FunctionDef):
            return [('parent', 'return')]

    source = """
    def foo():
        a = 1 + 2
        return a
    """
    class_ = SampleTransformer()
    result = class_.visit(ast.parse(source))
    expected = """
    def foo():
        a = 1 + 2
        exc = StopIteration()
        exc.value = a
        raise exc
    """
    assert ast.dump(result) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 22:57:04.931548
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def test():\n  yield 5\n  return 1""")
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(node)
    expected = ast.parse("""def test():\n  yield 5\n  exc = StopIteration()\n  exc.value = 1\n  raise exc""")
    assert ast.dump(res) == ast.dump(expected)

# Generated at 2022-06-23 22:57:14.981210
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test import check_transformer
    from ..utils.test import it_should_check_for_changes
    from ..utils.test import it_should_generic_visit
    from ..utils.test import it_should_visit_children
    from ..utils.test import it_should_visit_methods
    from ..utils.test import make_test_nodes
    from ..utils.test import node_equal

    def check_transform(transformer, node):
        if len(transformer._find_generator_returns(node)) > 0:
            generator_returns = transformer._find_generator_returns(node)
            for parent, return_ in generator_returns:
                transformer._replace_return(parent, return_)
            return node_equal(node, transformer._node)

# Generated at 2022-06-23 22:57:23.361193
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from .test_BaseNodeTransformer import BaseNodeTransformerSchema
    from .test_BaseNodeTransformer import BaseNodeTransformerTest

    source = """
    def my_generator(n):
        for i in range(n):
            yield i
        return 3
    """
    expected = """
    def my_generator(n):
        for i in range(n):
            yield i
        exc = StopIteration()
        exc.value = 3
        raise exc
    """

    tree = parse(source)
    node = ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-23 22:57:25.667607
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    "Does the constructor of ReturnFromGeneratorTransformer work?"
    assert ReturnFromGeneratorTransformer().version == (3, 2)


# Generated at 2022-06-23 22:57:26.726592
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:31.990473
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    obj = ReturnFromGeneratorTransformer()
    assert obj.target == (3, 2)
    assert obj.tree_changed == False
    assert obj.has_yield == False
    assert obj.generator_returns == [
        ([], 'return_value')]
    assert obj.parent == [Any]
    assert obj.return_ == ['parent', 'return_value']
    assert obj.index == [Any, 'parent', 'return_', Any]



# Generated at 2022-06-23 22:57:42.234606
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5
    t = ReturnFromGeneratorTransformer()
    trans = t.visit(ast.parse(fn))
    # On Python 2.6
    # "exec_compiled_code(code, self.locals, self.globals, self.frame.f_lasti)"
    # "missing yield statement, expected 'YieldExpression', got 'Return'"
    assert str(compile(trans, '', 'exec')) == "exec(compile('''def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc''', '', 'exec'))"
    return ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:48.484223
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_ast
    from .test_literals import _test_parse_function
    # Simple example
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    result = _test_parse_function(ReturnFromGeneratorTransformer, source)
    assert_equal_ast(result, expected)

    # If no yield no transformation
    source = """
    def fn():
        return 5
    """
    result = _test_parse_function(ReturnFromGeneratorTransformer, source)
    assert_equal_ast(result, source)

    # Nested generator

# Generated at 2022-06-23 22:57:49.841588
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3,2)

# Generated at 2022-06-23 22:57:50.913739
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:53.984234
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer



# Generated at 2022-06-23 22:57:54.961187
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:02.647065
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse("""def fn():\n    yield 1\n    return 5""")
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit_Module(module)
    module.body[0].body[2] = ast.Raise(
        exc=ast.Call(
            func=ast.Name(id='StopIteration'),
            args=[],
            keywords=[ast.keyword(arg='value', value=ast.Num(n=5))],
        ),
        cause=None,
    )
    assert ast.dump(result) == ast.dump(module)



# Generated at 2022-06-23 22:58:04.985355
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_helpers import assert_code_equal
    from typed_astunparse import unparse
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:08.036099
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    transformer = ReturnFromGeneratorTransformer()

    def compile(value):
        a_ast = ast.parse(value)
        transformer.visit(a_ast)
        return a_ast


# Generated at 2022-06-23 22:58:18.589854
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    # print(ast.dump(node))
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    # print(ast.dump(node))
    assert transformer._tree_changed

# Generated at 2022-06-23 22:58:26.855676
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest import TestCase
    from ..utils.source import source_to_ast, source_to_nodes

    class ReturnFromGeneratorTransformerTest(TestCase):
        def test(self):
            def test(before: str, after: str) -> None:
                node = source_to_ast(before)
                node = ReturnFromGeneratorTransformer().visit(node)
                transformed = node_to_source(node)
                self.assertEqual(transformed, after)

            def test_all(before: str, after: str, fn_name: str) -> None:
                node = source_to_ast(before)
                functions = source_to_nodes(before, ast.FunctionDef)
                node = ReturnFromGeneratorTransformer().visit(node)