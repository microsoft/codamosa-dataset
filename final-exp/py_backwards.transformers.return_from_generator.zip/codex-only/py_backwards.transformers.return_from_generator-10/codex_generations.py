

# Generated at 2022-06-23 22:48:26.161372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import generate_code_and_parse_ast, generate_ast


# Generated at 2022-06-23 22:48:27.087305
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:35.351012
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import c
    from ..parser import Parser

    source = """
    def fn(a):
        yield a
        return a
    def fn2(a):
        yield a
        return
    def fn3(a):
        return a
    """
    node = Parser().parse(source)
    expected = """
    def fn(a):
        yield a
        exc = StopIteration()
        exc.value = a
        raise exc
    def fn2(a):
        yield a
        return
    def fn3(a):
        return a
    """
    expected = Parser().parse(expected)

    node = c(node, [ReturnFromGeneratorTransformer])

    assert_equals(expected.body, node.body)



# Generated at 2022-06-23 22:48:39.567332
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
        obj = ReturnFromGeneratorTransformer()
        assert obj.target == (3, 2)
        assert isinstance(obj, BaseNodeTransformer)
        assert obj._tree_changed == False
        assert obj._find_generator_returns(obj) == []


# Generated at 2022-06-23 22:48:47.597954
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
        def fn():
            yield 1
            return 5
            yield 2
            return 6
    """

    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            yield 2
            exc = StopIteration()
            exc.value = 6
            raise exc
    """

    tree = ast.parse(dedent(source))
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert to_source(tree).strip() == expected_code.strip()

# Generated at 2022-06-23 22:48:57.315350
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    code_0 = (
        'def fn():\n'
        '    yield 1\n'
        '    return 5'
    )
    code_1 = (
        'def fn():\n'
        '    yield 1\n'
        '    return a'
    )
    code_2 = (
        'def fn():\n'
        '    return 5'
    )
    code_3 = (
        'def fn():\n'
        '    return'
    )
    code_4 = (
        'def fn():\n'
        '    if True:\n'
        '        return 5'
    )

# Generated at 2022-06-23 22:48:58.493153
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert(ReturnFromGeneratorTransformer() is not None)

# Generated at 2022-06-23 22:49:08.321365
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import parse, check_equal

    result_1 = parse(ReturnFromGeneratorTransformer, '''
    def test(self):
        yield 1
        return 2
    ''')
    expected_1 = '''
    def test(self):
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''
    check_equal(result_1, expected_1)

    result_2 = parse(ReturnFromGeneratorTransformer, '''
    def test(self):
        yield from some_gen()
        return 2

    def other_func():
        return 1
    ''')

# Generated at 2022-06-23 22:49:16.698851
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    # function with only last return
    def test_function_with_last_return():
        def fn():
            yield 1
            return 5
    assert astor.to_source(
        ReturnFromGeneratorTransformer().visit(
            ast.parse(test_function_with_last_return.__doc__)
        )
    ) == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

    # function with only first return
    def test_function_with_first_return():
        def fn():
            return 1
            yield 5

# Generated at 2022-06-23 22:49:26.325156
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    func_def_node = ast.parse("def fn(): yield 1; return 5").body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(func_def_node)

# Generated at 2022-06-23 22:49:36.306412
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    example = FunctionDef(name='fn',
                          body=[Expr(value=Yield(value=Num(n=1))),
                                Return(value=Num(n=5))])
    ast_ = ReturnFromGeneratorTransformer().visit_FunctionDef(example)

# Generated at 2022-06-23 22:49:37.410436
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:39.981971
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print("Testing ReturnFromGeneratorTransformer (visit_FunctionDef)")


# Generated at 2022-06-23 22:49:41.808055
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:50.955478
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    class_node = ast.ClassDef(name='Class', 
                              body=[],
                              decorator_list=[],
                              keywords=[],
                              starargs=None,
                              kwargs=None,
                              lineno=0,
                              col_offset=0)

# Generated at 2022-06-23 22:49:57.968432
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    parsed = ast.parse(source)
    fn = parsed.body[0]
    assert isinstance(fn, ast.FunctionDef)

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(parsed) == ast.parse(expected)

# Generated at 2022-06-23 22:50:07.981021
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test ReturnFromGeneratorTransformer."""
    from ..utils import get_ast
    transformer = ReturnFromGeneratorTransformer()

    assert transformer.visit(get_ast("""
        def foo():
            yield 1
            return 9
    """)) == get_ast("""
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 9
            raise exc
    """)

    assert transformer.visit(get_ast("""
        def foo():
            return 9
    """)) == get_ast("""
        def foo():
            return 9
    """)


# Generated at 2022-06-23 22:50:12.862806
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Given
    node = ast.parse(textwrap.dedent("""
        def f():
            yield 2
            return 2+3
    """))
    ReturnFromGeneratorTransformer().visit(node)

    # Then
    assert ast.dump(node) == textwrap.dedent("""
        def f():
            yield 2
            exc = StopIteration()
            exc.value = (2 + 3)
            raise exc
    """)



# Generated at 2022-06-23 22:50:16.402591
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    assert ReturnFromGeneratorTransformer().visit(node) == expected

# Generated at 2022-06-23 22:50:22.234029
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_function():
        yield 1
        return 2

    transformer = ReturnFromGeneratorTransformer()
    source = inspect.getsource(test_function)
    tree = ast.parse(source)
    transformer.visit(tree)

    expected_source = """def test_function():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc"""

    assert ast.dump(tree) == ast.dump(ast.parse(expected_source))

# Generated at 2022-06-23 22:50:24.106267
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import ast_export, ast_parse

# Generated at 2022-06-23 22:50:34.126330
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

# Generated at 2022-06-23 22:50:39.239376
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    import textwrap
    from typed_astunparse import unparse
    tree = ast.parse(textwrap.dedent('''
        def gen():
            yield 1
            return 2
            
        def gen2():
            yield 1
            a = 0
            return 2
            
        def gen3():
            return 2
            
        def gen4():
            yield 1
            if True:
                return 2
            else:
                return 3
    '''))
    # tree = ast.parse("def gen(a): return 2")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 22:50:47.101297
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source = '''
        def fn():
            yield 1
            return 5
    '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    node = ast.parse(source)
    transformed_node = transformer.visit(node)
    print(ast.dump(transformed_node))
    assert ast.dump(transformed_node) == expected

# Generated at 2022-06-23 22:50:51.015856
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.target == (3, 2)
    assert transformer._tree_changed is False
    assert transformer.generic_visit(object()) is None

# Generated at 2022-06-23 22:50:52.342745
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # noqa: D103
    from ..utils.test_utils import get_node_as_string

# Generated at 2022-06-23 22:50:59.858527
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from python_to_python.__test__.unit_test import UnitTestTransformer

    unit_test = UnitTestTransformer()

    # Test 'def fn():\n    yield 1\n    return 5'
    node = ast.parse('def fn():\n    yield 1\n    return 5')
    node_expected = ast.parse('def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc')
    node_transformed = ReturnFromGeneratorTransformer().visit_FunctionDef(node.body[0])
    unit_test.assertEqualAST(node_expected, node_transformed)

    # Test 'def fn():\n    yield from ()\n    return 5'

# Generated at 2022-06-23 22:51:09.308380
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node1 = ast.FunctionDef(name='fn', args=ast.arguments(
        args=[], defaults=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None
    ), body=[
        ast.Yield(value=ast.Num(1)),
        ast.Return(value=ast.Num(5))
    ], decorator_list=[], returns=None)


# Generated at 2022-06-23 22:51:10.295598
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:11.916050
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(lambda: 0, 3, 2).target == (3, 2)


# Generated at 2022-06-23 22:51:12.952220
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:18.204598
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
        def func():
            yield 1
            return 5
    """)

    new_tree = ReturnFromGeneratorTransformer().visit(tree)

    assert ast.dump(new_tree) == ast.dump(ast.parse("""
        def func():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """))

# Generated at 2022-06-23 22:51:24.175083
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def fn():
        yield 1
        return 2
    """)

    ReturnFromGeneratorTransformer().visit(tree)

    expected_tree = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """)

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:51:29.644657
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert astunparse.unparse(tree).strip() == expected.strip()

# Generated at 2022-06-23 22:51:33.760829
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    t = ReturnFromGeneratorTransformer()
    src = """
    def f():
        yield 1
        return 5
    """
    tree = ast.parse(src)
    tree = t.visit(tree)
    assert "raise exc" in astor.to_source(tree)

# Generated at 2022-06-23 22:51:43.713387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.io import StringIO
    from ..utils.trees import ast2text

    class TestTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            super().__init__()
            self._tree_changed = False
            self._io = StringIO()

        def _write(self, string: str):
            self._io.write(string)

        def _rewrite(self):
            self._io.truncate(0)
            self._io.seek(0)

    # Check not changed
    with open(__file__) as f:
        text = f.read()
        tree = ast.parse(text)

        transformer = TestTransformer()
        transformer.visit(tree)
        assert not transformer._tree_changed

    # Check changed

# Generated at 2022-06-23 22:51:44.185814
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:53.130497
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    foo_body = [ast.Yield(value=ast.Num(n=1)),
                ast.Return(value=ast.Num(n=5))]
    foo = ast.FunctionDef(name='foo',
                          args=ast.arguments(args=[], vararg=None,
                                             kwonlyargs=[], kwarg=None, defaults=[]),
                          body=foo_body, decorator_list=[], returns=None)
    foo = ReturnFromGeneratorTransformer().visit(foo)
    assert foo.body[1].value.func.id == 'StopIteration'



# Generated at 2022-06-23 22:52:01.338409
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    original_py_source = """
        def foo():
            yield 1
            return 5

        def bar():
            if True:
                yield 1
            else:
                return foo()
    """
    expected_py_source = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        def bar():
            if True:
                yield 1
            else:
                exc = StopIteration()
                exc.value = foo()
                raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    py_ast = ast.parse(original_py_source)
    transformer.visit(py_ast)
    actual_py_source = astor.to_source(py_ast)
    assert expected_py_source == actual_py_source

# Generated at 2022-06-23 22:52:07.804051
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    from . import get_ast
    from .base import BaseNodeTransformerTestCase

    source = """
        def fn():
            yield 1
            return 5
        """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    tree = get_ast(source)
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)

    self = BaseNodeTransformerTestCase()
    self.assertEqual(expected, str(node))


# Generated at 2022-06-23 22:52:14.897557
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Arrange
    input_code = """
    def generator():
        yield 1
        return 2
        """
    expected_code = """
    def generator():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
        """

    # Act
    actual_code = ReturnFromGeneratorTransformer().visit(ast.parse(input_code))

    # Assert
    assert ast.dump(ast.parse(expected_code)) == ast.dump(actual_code)

# Generated at 2022-06-23 22:52:16.526405
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer()
    assert isinstance(class_, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:52:17.580225
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return


# Generated at 2022-06-23 22:52:23.196563
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_cases = [
        ("""
            def fn():
                x = 100
                return x
            """, True),
        ("""
            def fn():
                return 100
            """, True),
        ("""
            def fn():
                yield 1
                yield 2
                return 100
            """, True),
        ("""
            def fn():
                yield 1
            """, False),
        ("""
            def fn():
                yield 1
                return
            """, False),
        ("""
            def fn():
                yield 1
                if x:
                    yield y
                    yield z
                    return
                yield 5
            """, True),

    ]
    for test_case, expected_result in test_cases:
        print(test_case)
        module_node = ast.parse(test_case)
        transformer

# Generated at 2022-06-23 22:52:24.260318
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap

# Generated at 2022-06-23 22:52:34.163070
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typing import Callable
    from ..utils.testing import assert_transformation, create_function_def
    from ..utils.pyversion import IS_PY35

    node = create_function_def(
        name='fn',
        body=[
            ast.Yield(value=ast.Num(n=1)),
            ast.Yield(value=ast.Num(n=2)),
            ast.Return(value=ast.Num(n=3))
        ]
    )


# Generated at 2022-06-23 22:52:39.103475
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source_to_function

    fn = source_to_function('''
        def fn():
            yield 1
            return 5
    ''')
    fn_transformed = source_to_function('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    assert ReturnFromGeneratorTransformer().visit(fn) == fn_transformed

# Generated at 2022-06-23 22:52:46.425760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source

    code = """
    def foo():
        return 42
    """
    expected_code = """
    def foo():
        return 42
    """
    result_code = source(ReturnFromGeneratorTransformer().visit(source(code)))
    print(result_code)
    assert expected_code == result_code

    code = """
    def foo():
        yield 1
        return 42
    """
    expected_code = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 42
        raise exc
    """
    result_code = source(ReturnFromGeneratorTransformer().visit(source(code)))
    print(result_code)
    assert expected_code == result_code


# Generated at 2022-06-23 22:52:49.490558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from .. import transform
    from .. import fixers
    from .. import visitors


# Generated at 2022-06-23 22:52:55.722919
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import textwrap
    return_from_generator.update_bindings({'exc': None})
    code = textwrap.dedent("""
    def fn():
        yield 1
        return 5
    """)
    expected = textwrap.dedent("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    node = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert ast.dump(new_node) == expected

# Generated at 2022-06-23 22:53:06.321979
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._tree_changed == False
    assert transformer._function_def_changed == False
    assert transformer._function_def_new_signature == None

    node = ast.FunctionDef(name='fn', args=ast.arguments(), body = [],
                           decorator_list = [], returns = None)
    assert transformer.visit(node) == node
    assert transformer._tree_changed == False
    assert transformer._function_def_changed == False
    assert transformer._function_def_new_signature == None

    node = ast.FunctionDef(name='fn', args=ast.arguments(args = []), body = [],
                           decorator_list = [], returns = None)
    assert transformer.visit(node) == node
    assert transformer._tree_changed == False


# Generated at 2022-06-23 22:53:08.666070
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn_def = ast.parse('def foo():\n  yield 1\n  return 5')
    assert ReturnFromGeneratorTransformer().visit(fn_def) == ast.parse('def foo():\n  yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc')

# Generated at 2022-06-23 22:53:09.464351
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:53:10.247445
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-23 22:53:11.451424
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), ReturnFromGeneratorTransformer)


# Generated at 2022-06-23 22:53:15.995315
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer
    assert transformer._find_generator_returns(ast.parse("a=1")) == []
    assert transformer._find_generator_returns(ast.parse("def fn(): return 1")) == []
    assert transformer._find_generator_returns(ast.parse("def fn(): yield 1; return 1")) != []
    assert transformer._find_generator_returns(ast.parse("def fn(): yield 1")) == []


# Generated at 2022-06-23 22:53:19.326861
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astimport import parse
    from ..utils.test_utils import build_ir


# Generated at 2022-06-23 22:53:23.014013
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    def node():
        def fn():
            yield 1
            return 5

    result = transformer.visit_FunctionDef(node())

# Generated at 2022-06-23 22:53:23.911402
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransfo

# Generated at 2022-06-23 22:53:31.137144
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..processor import Processor
    from .. import serialize_ast, parse_ast

    source = """
    def fn():
        yield 1
        return 5
    def fn2():
        yield 2
        return
    """

    tree = parse_ast(source)
    processor = Processor(
        tree, [ReturnFromGeneratorTransformer]
    )
    processor.process()
    assert serialize_ast(tree) == """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    def fn2():
        yield 2
    """

# Generated at 2022-06-23 22:53:34.518153
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    '''Unit test for constructor of class ReturnFromGeneratorTransformer'''
    target_code = ReturnFromGeneratorTransformer.__doc__

    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:53:45.306934
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case for a function that does not contain yield statement
    def test1_fn():
        return 5
    node = ast.parse(inspect.getsource(test1_fn))
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert_equal(new_node, node)

    # Test case for a function that returns yield
    def test2_fn():
        yield 1
        return 5
    node = ast.parse(inspect.getsource(test2_fn))
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert_equal(new_node, node)

    def test3_fn():
        yield 1
        if True:
            return 0
        else:
            return 10


# Generated at 2022-06-23 22:53:52.789244
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def function1():
        yield 1
        return 5

    def function2():
        return 1

    def function3():
        yield 1
        return 5
        return 6

    assert ReturnFromGeneratorTransformer().visit(ast.parse(function1.__code__)) == ast.parse(return_from_generator.get_code() + function1.__code__)
    assert ReturnFromGeneratorTransformer().visit(ast.parse(function2.__code__)) == ast.parse(function2.__code__)
    assert ReturnFromGeneratorTransformer().visit(ast.parse(function3.__code__)) == ast.parse(return_from_generator.get_code() + function3.__code__)


# Generated at 2022-06-23 22:53:59.855277
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..transpiler import Transpiler
    source = """
    def fn():
        yield 1
        return 5
    """
    node = parse(source)
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    t = Transpiler()
    t.add_transformer(ReturnFromGeneratorTransformer)

    result = t.visit(node)
    assert expected_source == t.dump_source(result)

# Generated at 2022-06-23 22:54:01.164108
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-23 22:54:02.337526
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:54:06.077858
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_generator():
        yield 1
        return 10

    def test_non_generator():
        yield 1
        return 10


# Generated at 2022-06-23 22:54:11.768070
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import transform

    def check(transformer, code, expected):
        tree = ast.parse(code)
        transformer.visit(tree)
        transformed = ast.unparse(tree)
        assert transformed == expected

    code = """
        def fn():
            yield 1
            return 5
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    check(ReturnFromGeneratorTransformer(), code, expected)

# Generated at 2022-06-23 22:54:13.086111
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)


# Generated at 2022-06-23 22:54:14.075503
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:15.367172
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:17.335962
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-23 22:54:18.683476
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:54:25.482731
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse as astunparse

    class T(ReturnFromGeneratorTransformer):
        def __init__(self, test_node):
            self.test_node = test_node
            super().__init__()

        def visit_Module(self, node):
            return self.generic_visit(self.test_node)

    node = ast.parse('''def fn():
        yield 1
        return 5
        yield 8
    ''')
    new_node = T(node).visit(node)
    expected_node = ast.parse('''def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        yield 8
    ''')

# Generated at 2022-06-23 22:54:35.627421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test with return in generator
    source1 = """def fn():
    yield 1
    return 5
    """
    expected1 = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
    """

    # Test with return in generator in if
    source2 = """def fn():
    yield 1
    if True:
        return 5
    """
    expected2 = """def fn():
    yield 1
    if True:
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    # Test no yield in generator
    source3 = """def fn():
    return 5
    """
    expected3 = """def fn():
    return 5
    """

    # Test no return in generator

# Generated at 2022-06-23 22:54:44.429596
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = textwrap.dedent('''
    def foo():
        a = 5
        yield a
        return a
    ''')
    ast_module = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(ast_module)

# Generated at 2022-06-23 22:54:50.810324
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse

    transformer = ReturnFromGeneratorTransformer()

    def _transformer(code):
        return transformer.visit(parse(code))

    assert _transformer('def foo(a): return a') == parse('def foo(a): return a')

    assert _transformer('def foo(a):\n  yield a\n  return a') == parse('def foo(a):\n  yield a\n  exc = StopIteration()\n  exc.value = a\n  raise exc')

    assert _transformer('def foo(a):\n  yield a\n  return a\n  yield b') == parse('def foo(a):\n  yield a\n  exc = StopIteration()\n  exc.value = a\n  raise exc\n  yield b')


# Generated at 2022-06-23 22:55:02.501764
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse(textwrap.dedent('''\
        def fn():
            yield 1
            return 5
        '''))
    ReturnFromGeneratorTransformer().visit(tree)
    expected = ast.parse(textwrap.dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''))
    assert ast.dump(expected) == ast.dump(tree)

    tree = ast.parse(textwrap.dedent('''\
        def fn():
            def fn_in():
                yield 1
                return 5
            return
        '''))
    ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:55:12.038277
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    test_cases = [
        {
            'in': """
                def fn():
                    yield 1
                    return 5
            """,
            'out': """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            """
        }
    ]

    for test_case in test_cases:
        code_in = test_case['in']
        code_out = test_case['out']

        node_in = ast.parse(code_in)
        node_out = ast.parse(code_out)

        assert transformer.visit(node_in) == node_out



# Generated at 2022-06-23 22:55:17.745466
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    ret = ReturnFromGeneratorTransformer()
    ret.visit(tree)
    tree = ast.parse(str(tree))

# Generated at 2022-06-23 22:55:19.189909
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    gen = ReturnFromGeneratorTransformer()
    assert gen is gen


# Generated at 2022-06-23 22:55:25.857773
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .unparser import Unparser
    from ..utils.source import Source
    from .. import run_transformer

    src = Source('''
        def fn():
            yield 1
            return 5
    ''')

    tree = src.tree
    assert isinstance(tree, ast.Module)
    transformer = ReturnFromGeneratorTransformer()
    run_transformer(tree, transformer)
    Unparser(tree)
    result = src.text

    expected = Source('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''').text

    assert expected == result

# Generated at 2022-06-23 22:55:31.966113
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_node_transformers import assert_transform

    def p(s):
        return s.replace('\n', '').replace(' ', '').replace('\t', '')

    def test(src, expected):
        expected = expected.replace('\n', '').replace(' ', '').replace('\t', '')
        actual = p(str(ast.parse(src)))
        assert actual == expected


# Generated at 2022-06-23 22:55:39.581014
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .serialize import to_source
    from astunparse import unparse
    from textwrap import dedent

    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer, BaseNodeTransformer):
        pass

    tree1 = ast.parse("""\
    def fn():
        yield 1
        return 5
    """)
    to_source(ast.parse("""\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """))
    TestReturnFromGeneratorTransformer().visit(tree1)

# Generated at 2022-06-23 22:55:44.076547
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse('def fn(): yield 1; return 5')
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == '''Module(body=[FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Yield(value=Num(n=1)), Return(value=Num(n=5))], decorator_list=[], returns=None)])'''

# Generated at 2022-06-23 22:55:47.533328
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def fn():\n    yield 1\n    return 5""")
    transformer = ReturnFromGeneratorTransformer()
    transformed = transformer.visit(node)
    eval(compile(transformed, '', 'exec'))

    # There should be no return exceptions
    assert(transformer._tree_changed is True)
    assert(len(list(ast.iter_child_nodes(transformed))) == 3)



# Generated at 2022-06-23 22:55:57.862194
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
  def fn():
      yield 1
      return 5
  """
    module = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    node = module.body[0]
    node = ReturnFromGeneratorTransformer().visit(node)
    assert isinstance(node, ast.FunctionDef)
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Yield)
    assert isinstance(node.body[1], ast.Assign)
    assert isinstance(node.body[2], ast.Assign)
    assert isinstance(node.body[3], ast.Raise)
    assert isinstance(node.body[3].exc, ast.Call)

# Generated at 2022-06-23 22:56:05.274497
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..main import AST_CACHE
    from ..utils.testing import assert_equal_ast
    tree = AST_CACHE["""
    def fn():
        y = yield 1
        return 5
    """]
    expected_tree = AST_CACHE["""
    def fn():
        y = yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """]
    assert_equal_ast(ReturnFromGeneratorTransformer().visit(tree), expected_tree)


ReturnFromGeneratorTransformer.PYTHON_VERSION_CHECK = (3,)

# Generated at 2022-06-23 22:56:15.371578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from ..compiler import compile_snippet
    from ..utils import generate_examples

    examples = generate_examples(ReturnFromGeneratorTransformer)
    for unmodified, modified in examples:
        if unmodified != modified:
            assert compile_snippet(unmodified, version=3.8) != \
                   compile_snippet(modified, version=3.8)
        else:
            assert compile_snippet(unmodified, version=3.8) == \
                   compile_snippet(modified, version=3.8)

    # Test that the original code is not changed

# Generated at 2022-06-23 22:56:26.223233
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import NodeTransformerTestCase

    class ReturnFromGeneratorTransformerTest(NodeTransformerTestCase):
        target = (3, 2)
        transformer = ReturnFromGeneratorTransformer

        def test_return_from_generator_1(self):
            code = """
                def fn(x):
                    yield x
                    return x
            """
            result = """
                def fn(x):
                    yield x
                    exc = StopIteration()
                    exc.value = x
                    raise exc
            """
            self.check(code, result)

        def test_return_from_generator_2(self):
            code = """
                def fn():
                    yield 1
                    return 5
                    return 10

                def fn2():
                    yield 1
                    return 10
            """

# Generated at 2022-06-23 22:56:34.350894
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import tests_helpers
    old_node = ast.parse('def fn():\n' +
                         '    yield 1\n' +
                         '    return 5\n')
    expected = ast.parse('def fn():\n' +
                         '    yield 1\n' +
                         '    exc = StopIteration()\n' +
                         '    exc.value = 5\n' +
                         '    raise exc')
    tests_helpers.assert_same_ast(old_node, expected, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:56:41.699697
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent

    from ..transformer import Transformer
    from ..utils.ast_helpers import dump

    input_source = dedent("""\
        def generator():
            x = 1
            if x == 1:
                return 0
            else:
                yield x
                for i in range(5):
                    yield(i)
        """)
    expected_source = dedent("""\
        def generator():
            x = 1
            if x == 1:
                exc = StopIteration()
                exc.value = 0
                raise exc
            else:
                yield x
                for i in range(5):
                    yield(i)
        """)

    transformer = Transformer()
    transformer.register_transformer(ReturnFromGeneratorTransformer)

    old_tree = ast.parse(input_source)


# Generated at 2022-06-23 22:56:48.534165
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.simplify_ast import simplify_ast
    code = """
    def foo():
        yield 1
        return 2
    """
    tree = ast.parse(code)
    tree = simplify_ast(tree)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    code = compile(tree, '', 'exec')
    ns = {}
    exec(code, ns)

    assert ns['foo']().__next__() == 1
    assert ns['foo']().__next__() == 2


# Generated at 2022-06-23 22:56:53.607401
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ...utils.testing import source_to_function_body
    from ..utils.test_fixtures import (
        simple_function,
        function_with_return,
        function_with_return_from_generator,
        function_with_yield_from_generator,
        function_with_yield_from_generator_return,
        function_with_return_from_nested_generator,
        function_with_return_from_nested_generator_2,
        function_with_return_from_nested_generator_return,
        class_with_generator_method,
    )

    rtg = ReturnFromGeneratorTransformer()

    assert rtg.visit(source_to_function_body(simple_function)) == \
        source_to_function_body(simple_function)



# Generated at 2022-06-23 22:56:55.713882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    # Transforming 'def a(): yield 1\n return 2'
    tree = ast.parse('def a():\n yield 1\n return 2')
    ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:57:00.077538
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
        def fn():
            yield 1
            return 2
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(source)
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed

    assert ast.dump(new_tree) == expected

# Generated at 2022-06-23 22:57:01.047006
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import compact_source


# Generated at 2022-06-23 22:57:05.500185
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    fn_def = ast.parse('def fn():\n'
                       '        yield 1\n'
                       '        return 5').body[0]
    return_from_generator_transformer.visit(fn_def)


# Functional test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:15.952173
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = '''
        def fn():
            yield 5
            return 1
    '''
    tree = ast.parse(code)
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(node)
    assert transformer._tree_changed
    assert transformer._visited_from_class == 2
    res2 = ast.dump(res)

# Generated at 2022-06-23 22:57:19.452675
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Set
    node_1 = ast.parse(return_from_generator.input)
    transformer = ReturnFromGeneratorTransformer()
    # Act
    node_2 = transformer.visit(node_1)
    # Assert
    assert ast.dump(node_2) == return_from_generator.output

# Generated at 2022-06-23 22:57:21.367890
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:57:25.322911
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        # Can we create object of class ReturnFromGeneratorTransformer ?
        ReturnFromGeneratorTransformer()
    except:
        assert False, "Can't create object of class ReturnFromGeneratorTransformer"
    assert True



# Generated at 2022-06-23 22:57:34.525991
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("def foo():\n    yield 1\n    return 2\n")
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(tree)
    assert ast.dump(res) == "def foo():\n    yield 1\n    exc = StopIteration()\n    exc.value = 2\n    raise exc"

    tree = ast.parse("def foo():\n    yield 1\n    if 2 > 1:\n        yield 3\n    return 5\n")
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(tree)
    assert ast.dump(res) == "def foo():\n    yield 1\n    if 2 > 1:\n        yield 3\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"

# Generated at 2022-06-23 22:57:44.275126
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import fixtured_test_visitor
    from .fixtures.return_from_generator.test_visit_FunctionDef import (
        AST_BEFORE,
        AST_AFTER,
    )
    from ..utils.scope import Scope
    from ..utils.fake_context import FakeContext

    METHOD_NAME = 'visit_FunctionDef'

    ast_before = fixtured_test_visitor(AST_BEFORE)
    ast_after = fixtured_test_visitor(AST_AFTER)

    scope = Scope(ast_before)
    fake_context = FakeContext(scope)

    visitor = ReturnFromGeneratorTransformer(
        context=fake_context,
        scope=scope,
    )
    getattr(visitor, METHOD_NAME)(ast_before)

    assert ast_before

# Generated at 2022-06-23 22:57:49.187694
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("test_ReturnFromGeneratorTransformer started")
    #with open('test-input.py', 'r') as test_file:
    #    test_code = test_file.read()
    #tree = ast.parse(test_code)

    assert ReturnFromGeneratorTransformer()
    print("test_ReturnFromGeneratorTransformer ended")

# Generated at 2022-06-23 22:57:58.629895
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .transpile_to_ast import transpile_function_def
    from .sample_generators import sample_generator_code

    ast_tree = transpile_function_def(sample_generator_code)
    before_return_count = len([x for x in ast.walk(ast_tree) if isinstance(x, ast.Return)])
    rfg = ReturnFromGeneratorTransformer()
    rfg.visit(ast_tree)
    after_return_count = len([x for x in ast.walk(ast_tree) if isinstance(x, ast.Return)])
    assert before_return_count - after_return_count == 2

# Generated at 2022-06-23 22:58:08.045205
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:09.327162
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t


# Generated at 2022-06-23 22:58:19.918097
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node):
            return [('parent', 'return')]
        def _replace_return(self, parent, return_):
            self.parent_node = (parent, return_)

    program = ast.parse("""
        def fn():
            yield 1
            return 5
    """).body[0]

    transformer = ReturnFromGeneratorTransformerTest()
    new_program = transformer.visit(program)

    # Check that transformer made changes to the program
    assert transformer._tree_changed
    assert new_program.body[-1] == return_from_generator.paste(None, 5)