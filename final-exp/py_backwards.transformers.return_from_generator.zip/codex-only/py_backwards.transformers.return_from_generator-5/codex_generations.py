

# Generated at 2022-06-23 22:48:24.536393
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-23 22:48:28.384190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert(str(ReturnFromGeneratorTransformer().visit(ast.parse('''
        def fn():
            yield 1
            return 5
    '''))) == '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

# Generated at 2022-06-23 22:48:34.909123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast1 = return_from_generator.get_ast(return_value=3)
    ast2 = return_from_generator.get_ast(return_value=3)
    ast3 = return_from_generator.get_ast(return_value=3)
    ast4 = return_from_generator.get_ast(return_value=3)

    # we need to update the nodes for the assertion because the parent field is not copied
    for line in ast1:
        line.parent = ast.Module(body=[line])
    for line in ast2:
        line.parent = ast.Module(body=[line])
    for line in ast3:
        line.parent = ast.Module(body=[line])
    for line in ast4:
        line.parent = ast.Module(body=[line])


# Generated at 2022-06-23 22:48:35.781913
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:43.992318
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import settings
    from .. import utils
    from .. import benchmarks
    settings.debug = True
    utils.DEBUG = settings.debug
    from pprint import pprint

    module = utils.get_ast_from_file('return_from_generator/return.py')
    node = module.body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    # pprint(ast.dump(node))
    exec(compile(module, '<test>', 'exec'), {}, {})

# Generated at 2022-06-23 22:48:48.655298
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    result = generate(dedent('''
    def fn():
        yield 1
        return 5
    '''))
    expected = dedent('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert result == expected

# Generated at 2022-06-23 22:48:50.066996
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:48:52.186819
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    transformed_fn = ReturnFromGeneratorTransformer.run(fn)
    assert transformed_fn()

# Generated at 2022-06-23 22:48:53.074954
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:48:54.310684
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    gen = ReturnFromGeneratorTransformer()
    assert gen is not None


# Generated at 2022-06-23 22:49:04.923587
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    class Foo:
        pass

    def bar(a):
        b = Foo()
        c = b.x
        yield c
        return 1

    def fn():
        a = 1
        if a > 2:
            return
        else:
            return 2

    def fn_simple_return():
        return 1

    def fn_tuple():
        return 1, 2, 3

    def generator_fn():
        yield 1
        return 2, 3

    def generator_fn_with_raise():
        yield 1
        return 2, 3
        raise RuntimeError('test')

    def generator_fn_with_raise_and_return():
        yield 1
        return 2, 3
        raise RuntimeError('test')

    def non_generator_fn():
        return 1


# Generated at 2022-06-23 22:49:14.436694
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import typed_ast.ast3 as ast
    from .generator_return_transformer import ReturnFromGeneratorTransformer
    transformer = ReturnFromGeneratorTransformer()
    test_ast = ast.FunctionDef(
        name="test",
        args=ast.arguments(args=[], vararg=None, kwonlyargs=[],
            kw_defaults=[], kwarg=None, defaults=[]),
        body=[ast.Expr(ast.Yield(value=ast.Num(n=1))),
            ast.Return(value=ast.Num(n=5))],
        decorator_list=[],
        returns=None)


# Generated at 2022-06-23 22:49:15.240101
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:17.916847
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:49:24.311119
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
        def fn():
            yield 1
            return 5
    """
    node = ast.parse(code)
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_node = ast.parse(expected_code)
    assert ast.dump(node) == ast.dump(expected_node)



# Generated at 2022-06-23 22:49:25.479574
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

#Unit test for the find_generator_returns method

# Generated at 2022-06-23 22:49:26.977874
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)
# Unit tests for function _find_generator_returns of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:37.002038
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import parse_function_def, dump

    def assert_transform(code_before, code_after):
        function_def = parse_function_def(code_before)

        assert dump(ReturnFromGeneratorTransformer().visit(function_def)) == code_after

    assert_transform('''
        def fn():
            yield 1
            return 5
    ''', '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    assert_transform('''
        def fn():
            yield 1
            x = 5
            return x
    ''', '''
        def fn():
            yield 1
            x = 5
            exc = StopIteration()
            exc.value = x
            raise exc
    ''')


# Generated at 2022-06-23 22:49:44.386177
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    n = ast.parse("""def fn():
    yield 1
    yield 2
    yield 3""")
    assert n.body[0].body == [ast.Yield(ast.Num(1)), ast.Yield(ast.Num(2)), ast.Yield(ast.Num(3))]

    t = ReturnFromGeneratorTransformer()
    t.visit(n)
    assert n.body[0].body == [ast.Yield(ast.Num(1)), ast.Yield(ast.Num(2)), ast.Yield(ast.Num(3))]

# Generated at 2022-06-23 22:49:46.798712
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer is not None

# Generated at 2022-06-23 22:49:47.257232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:48.173924
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:55.143596
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast as python_ast

    from ..utils.source import source_to_ast as to_ast, ast_to_source as to_source

    def check(input: str, expected: str) -> None:
        ast_tree = to_ast(input)

        t = ReturnFromGeneratorTransformer()
        new_ast = t.visit(ast_tree)

        assert(to_source(new_ast) == expected)

    # Simple case, return in function

# Generated at 2022-06-23 22:49:57.823940
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:07.855171
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
        def f2(l):
            for x in l:
                yield x

        def f1():
            yield 1
            return "a"

        def f3():
            v = yield from f2('ab')
            return v
    '''
    expected_code = '''
        def f2(l):
            for x in l:
                yield x

        def f1():
            yield 1
            exc = StopIteration()
            exc.value = "a"
            raise exc

        def f3():
            v = yield from f2('ab')
            exc = StopIteration()
            exc.value = v
            raise exc
    '''
    expected_tree = ast.parse(expected_code)
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(code)


# Generated at 2022-06-23 22:50:10.893667
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with pytest.raises(TypeError) as excinfo:
        ReturnFromGeneratorTransformer()
    assert excinfo.value.args[0] == 'Can\'t instantiate abstract class ReturnFromGeneratorTransformer with abstract methods visit_FunctionDef'


# Generated at 2022-06-23 22:50:16.088897
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typing import Generator
    from .. import compile_isolated

    def non_generator_return() -> int:
        return 1

    def generator_with_return() -> Generator[int, int, int]:
        yield 1
        return 2

    def test_transformer(*args, **kwargs):
        fn = compile_isolated(ReturnFromGeneratorTransformer, *args, **kwargs)
        for f in [non_generator_return, generator_with_return]:
            assert fn(f) == f()

    test_transformer()

# Generated at 2022-06-23 22:50:19.638611
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node1 = ast.FunctionDef(name="fn")
    node1 = ReturnFromGeneratorTransformer().visit(node1)
    assert ast.dump(node1) == "FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)"


# Generated at 2022-06-23 22:50:26.427136
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast1 = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    ast2 = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')
    fn1 = ast1.body[0]
    fn2 = ast2.body[0]
    assert ReturnFromGeneratorTransformer().visit(fn1) == fn2

# Generated at 2022-06-23 22:50:36.003281
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_transform, parse_ast

    # Test for:
    # def fn():
    #   for _ in range(5):
    #     yield 1
    #     return
    fn_1 = """
    def fn():
        for _ in range(5):
            yield 1
            return
    """
    fn_1_expected = """
    def fn():
        for _ in range(5):
            yield 1
    """
    assert_transform(ReturnFromGeneratorTransformer, fn_1, fn_1_expected)

    # Test for:
    # def fn():
    #   yield 5
    #   while True:
    #     return
    fn_2 = """
    def fn():
        yield 5
        while True:
            return
    """

# Generated at 2022-06-23 22:50:44.290955
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from .base import UnitTestTranspiler

    code = """
    def fn():
        yield 1
        return 5
    """
    transpiler = UnitTestTranspiler([ReturnFromGeneratorTransformer])
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    BaseNodeTransformerTest.test_code_transformation(transpiler, code, expected_code)

# Generated at 2022-06-23 22:50:51.626312
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from textwrap import dedent
    from ..utils.source import source_to_ast, source_to_str

    transformer = ReturnFromGeneratorTransformer()

    source = dedent('''
        def fn():
            yield 1
            return 5
        ''')
    ast_tree = source_to_ast(source)
    ast_tree2 = transformer.visit(ast_tree)
    expected = dedent('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')

    assert source_to_str(ast_tree2) == expected

# Generated at 2022-06-23 22:50:52.479970
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:50:53.653251
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:50:59.846306
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """def fn():
        yield 1
        yield 2
        return 3

    def fn2():
        yield 1
        yield 2
        return

    def fn3():
        return 4
        yield 5
        yield 6

    def fn4():
        print("q")
        yield 4
        return 5
        yield 6

    def fn5():
        print("q")
        return 6
"""

# Generated at 2022-06-23 22:51:08.956618
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def before():
        def fn():
            yield 1
            return 5

    def after():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    node_before = ast.parse(snippet(before).strip())
    node_after = ast.parse(snippet(after).strip())
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node_before)
    # print(ast.dump(node_after))
    # print(ast.dump(result))
    assert ast.dump(result, include_attributes=False) == ast.dump(node_after, include_attributes=False)

# Test that ReturnFromGeneratorTransformer does not modify code without changes.

# Generated at 2022-06-23 22:51:19.229393
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import parse_source
    from typing import List

    code = """
        def f():
            if x:
                yield 1
                x = 2
                def g(a, *args, b=1):
                    x = a if a else b
                    for y in range(1):
                        yield 2
                        return 4
                    return 2
                y = 1
                return g(y, 1, 3)
            return 3
            return 4
        """

# Generated at 2022-06-23 22:51:20.585267
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer({})
    assert transformer is not None

# Generated at 2022-06-23 22:51:23.021359
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_utils import make_fixture, assert_code_equal
    fixture = make_fixture('ReturnFromGenerator')
    t = ReturnFromGeneratorTransformer()

    assert_code_equal(t.visit(fixture.ast), fixture.expected)

# Generated at 2022-06-23 22:51:30.267617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generator_compat import GeneratorCompatibilityTransformer
    from .array_yield_from import ArrayYieldFromTransformer
    from .remove_null_assertions import RemoveNullAssertionsTransformer
    from ..utils.compile_snippet import compile_snippet, TestCase
    from ..utils.rmtree import rmtree

    class Test(TestCase):
        TRANSFORMERS = [
            RemoveNullAssertionsTransformer,
            GeneratorCompatibilityTransformer,
            ReturnFromGeneratorTransformer,
            ArrayYieldFromTransformer,
        ]

        def test_generator(self):
            @snippet
            def has_return(x):
                yield 1
                return x

            self.assertEqual(has_return(3), 3)


# Generated at 2022-06-23 22:51:37.228801
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("Test: ReturnFromGeneratorTransformer")
    # Test if working properly
    def test1():
        yield 1
        return 3
    ast_correct = ast.parse("""def test1():
        yield 1
        exc = StopIteration()
        exc.value = 3
        raise exc""")
    ast_test = ast.parse("def test1():\n        yield 1\n        return 3")
    rft = ReturnFromGeneratorTransformer()
    rft.visit(ast_test)
    assert ast_test == ast_correct

    # Test if works for multiple returns in function
    def test2():
        yield 1
        return 3
        return 4

# Generated at 2022-06-23 22:51:38.733383
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return True


# Generated at 2022-06-23 22:51:44.727286
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from .return_x_to_yield import ReturnXToYieldTransformer
    def fn():
        yield 1
        return 2

    node = BaseNodeTransformerTest.parse_function(fn)
    ReturnXToYieldTransformer().visit(node)
    ReturnFromGeneratorTransformer().visit(node)
    assert BaseNodeTransformerTest.compile_function(node)() == 2


# Generated at 2022-06-23 22:51:47.079633
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    import astor
    # Code for function_1

# Generated at 2022-06-23 22:51:57.448522
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_func_body
    from typed_ast import ast3 as ast

    class FakeFunctionDef(ast.FunctionDef):
        pass

    class FakeReturn(ast.Return):
        pass

    class FakeYield(ast.Yield):
        pass

    class FakeYieldFrom(ast.YieldFrom):
        pass

    class FakeParent(ast.AST):
        pass


    class FakeVisitor:
        def generic_visit(self, node: ast.AST) -> ast.AST:
            pass

    def fake_generic_visit(self, node: ast.AST) -> ast.AST:
        pass

    def setup_method(self, method):
        self.transformer = ReturnFromGeneratorTransformer()
        self.transformer._tree_changed = False
        self.transformer.generic_vis

# Generated at 2022-06-23 22:51:58.568376
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:51:59.913666
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert isinstance(transformer, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:52:05.672092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def func():
        n = 0
        while n < 5:
            n += 1
            return n
    """
    wanted = """
    def func():
        n = 0
        while n < 5:
            n += 1
            exc = StopIteration()
            exc.value = n
            raise exc
    """
    source = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(source)
    got = ast.dump(source)
    assert got == wanted


# Generated at 2022-06-23 22:52:16.023679
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .context import Context
    from ..utils import ast_inspect
    context = Context(target=(3, 5), mode=ast_inspect.COMPILE_MODE)
    transformer = ReturnFromGeneratorTransformer(context)
    ast_tree = ast.parse("""
    def func():
        yield 1
        return 2
    """, mode=ast_inspect.COMPILE_MODE)
    ast_tree = transformer.visit(ast_tree)  # type: ignore
    ast.fix_missing_locations(ast_tree)

# Generated at 2022-06-23 22:52:18.474136
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()
    assert ReturnFromGeneratorTransformer.target == (3, 2)
    assert isinstance(rfgt, ReturnFromGeneratorTransformer)


# Generated at 2022-06-23 22:52:19.653981
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:52:28.988605
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def fn(x):
        a = 1
        for i in range(x):
            yield i
            if i == 1:
                return 7
        return a + x
    """
    expected = """
    def fn(x):
        a = 1
        for i in range(x):
            yield i
            if i == 1:
                exc = StopIteration()
                exc.value = 7
                raise exc
        exc = StopIteration()
        exc.value = a + x
        raise exc
    """
    tr = ReturnFromGeneratorTransformer()
    actual = tr.visit(ast.parse(code))
    print(actual)
    assert ast.dump(actual) == expected

# Generated at 2022-06-23 22:52:38.639355
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

    # noinspection PyUnusedLocal
    def x():
        yield
        return 1

    # noinspection PyUnusedLocal
    def x2():
        yield 1
        return 1

    # noinspection PyUnusedLocal
    def x3():
        return 1

    # noinspection PyUnusedLocal
    def z():
        return
        yield 1

    # noinspection PyUnusedLocal
    def z1():
        yield 1
        return
        yield 2

    # noinspection PyUnusedLocal
    def y():
        yield
        return
        yield
    # noinspection PyUnusedLocal
    def y1():
        yield 2
        yield 2

    assert return_from_generator_transformer._find_generator_

# Generated at 2022-06-23 22:52:40.967522
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:42.249118
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    _ = ReturnFromGeneratorTransformer  # noqa: F841

# Generated at 2022-06-23 22:52:46.148514
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    s = """def fn():
        yield 1
        return 5"""
    expected = """def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc"""
    node = ast.parse(s).body[0]

    transformer = ReturnFromGeneratorTransformer(None)
    transformer.visit(node)

    assert expected == astor.to_source(node)


# Generated at 2022-06-23 22:52:55.585024
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .utils import to_source
    sample1 = """
    def foo():
        yield 1
        yield 2
    """
    sample2 = """
    def foo():
        yield 1
        return 2
    """
    sample3 = """
    def foo():
        yield 1
        for x in []:
            yield 2
        return 3
    """
    sample4 = """
    def foo():
        yield from [1, 2]
        return 3
    """
    sample5 = """
    def foo():
        yield from [1, 2]
        return
    """
    sample6 = """
    def foo():
        yield from [1, 2]
        return 3 if True else 5
    """
    sample7 = """
    def foo():
        yield 1
        return 2 if True else 5
    """
    sample8

# Generated at 2022-06-23 22:52:58.165959
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Test case for method _find_generator_returns of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:04.498762
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class _ReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        # noinspection PyUnusedLocal
        def visit_FunctionDef(self, node):
            node = self._find_generator_returns(node)
            return node

    returns = _ReturnFromGeneratorTransformer().visit(ast.parse('''
    def a():
        yield 1
        x = 5
        return x
    '''))
    assert len(returns) == 1

# Generated at 2022-06-23 22:53:12.628984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform_test

    @transform_test
    def test_transform(self, before, after):
        self.assertEqual(before, after)

    test_transform(
        before='''
            def fn():
                yield 1
                return 5
        ''',
        after='''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        '''
    )


# Generated at 2022-06-23 22:53:18.206732
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """def fn():
        yield 1
        return 5 + 3
    """
    expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5 + 3
    raise exc"""

    tree = ast.parse(code)  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(tree) == expected_code

# Generated at 2022-06-23 22:53:19.971991
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:21.252085
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:26.353741
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n    yield 1\n    return 5', '<string>', 'exec')

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    source = ast.unparse(node)
    expected = textwrap.dedent('''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert source == expected

# Generated at 2022-06-23 22:53:28.084388
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:37.883547
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import snippet

    def get_source(return_value=''):
        return snippet(
            """def fn():
                semicolon
                return {return_value}
            """
        ).get_source(return_value=return_value)

    def get_ast(source):
        return ast.parse(source)

    def get_test_case(return_value):
        return {
            'source': get_source(return_value),
            'expected': return_from_generator.get_source(return_value).split('\n'),
            'expected_name': 'value',
            'expected_len': 2,
            'expected_index': 1
        }

    def test_case(return_value):
        def test(actual):
            if isinstance(actual, list):
                actual

# Generated at 2022-06-23 22:53:47.635520
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:57.248111
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def should_not_change(code):
        node = ast.parse(dedent(code.strip()))
        processed_node = ReturnFromGeneratorTransformer().visit(node)
        assert ast.dump(node) == ast.dump(processed_node)

    should_not_change('''
        def foo():
            return bar()
        ''')

    def should_change(code, expected):
        node = ast.parse(dedent(code.strip()))
        processed_node = ReturnFromGeneratorTransformer().visit(node)
        assert ast.dump(processed_node) == expected


# Generated at 2022-06-23 22:54:05.866929
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .generator import ReturnFromGeneratorTransformer
    from ..utils.fixtures import read_python_snippet_and_compile
    from ..utils.test_utils import assert_nodes_equal

    snippet = ("""
        def fn(x):
            yield x
            return x + 5
    """)
    expected_source = ("""
        def fn(x):
            yield x
            exc = StopIteration()
            exc.value = x + 5
            raise exc
    """)
    expected_node = read_python_snippet_and_compile(expected_source)
    source, node = read_python_snippet_and_compile(snippet)
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)


# Generated at 2022-06-23 22:54:07.187098
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:54:11.773733
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n    yield 1\n    return 5\n')
    actual_node = ReturnFromGeneratorTransformer().visit(node)
    expected_node = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')
    assert ast.dump(actual_node) == ast.dump(expected_node)

# Generated at 2022-06-23 22:54:18.636336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    foo_expected = snippet('foo_expected')

    @snippet
    def foo(x, y):
        let(a, b)
        a = x
        b = y
        if a > b:
            return_from_generator(a)
        else:
            return_from_generator(b)

    foo_src = ReturnFromGeneratorTransformer().visit(foo).body[0]
    assert foo_src.body == foo_expected.body



# Generated at 2022-06-23 22:54:24.224345
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    # Setup
    node = ast.parse(
    """
    def fn():
        yield 1
        return 5
    """
    )

    expected = ast.parse(
    """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    )

    # Exercise
    result = transformer.visit(node)

    # Verify
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 22:54:34.812458
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..common import SkipNode


# Generated at 2022-06-23 22:54:39.806650
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ins = ReturnFromGeneratorTransformer()
    def fn():
        yield 1
        return 3

    expected = ast.parse(return_from_generator.get_source().strip())
    expected = ast.fix_missing_locations(expected)

    module = ast.parse(inspect.getsource(fn))
    module = ins.visit(module)
    assert ast.dump(module.body[0].body[1]) == ast.dump(expected)

# Generated at 2022-06-23 22:54:41.112428
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 22:54:47.746441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    before = textwrap.dedent(
        '''
        def gen(l):
            yield 1
            return 2
        ''')
    after = textwrap.dedent(
        '''
        def gen(l):
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        ''')
    t = ReturnFromGeneratorTransformer()
    transformed = t.visit_and_update(ast.parse(before))
    assert ast.dump(ast.parse(after)) == ast.dump(transformed)



# Generated at 2022-06-23 22:54:52.253750
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(textwrap.dedent('''
    def fn():
        yield 1
        return 5
    '''))

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    expected_node = ast.parse(textwrap.dedent('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''))

    assert ast.dump(node) == ast.dump(expected_node)

# Generated at 2022-06-23 22:55:04.078440
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # given
    transformer = ReturnFromGeneratorTransformer()

    # when
    actual = transformer.visit(ast.parse("""
        def function():
            yield 'This code is free'
            some_value = 'This code is free'
            if some_value:
                return 'This code is free'
            if not some_value:
                if some_value:
                    return 'This code is free'
            return 'This code is free'
    """))

    # then

# Generated at 2022-06-23 22:55:11.511610
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse('def a():\n  yield 1\n  return 2')
    tree = transformer.visit(tree)
    tree = ast.fix_missing_locations(tree)
    code = compile(tree, '<string>', 'exec')
    exec(code, globals())
    assert a().__next__() == 1
    with pytest.raises(StopIteration) as excinfo:
        a().__next__()
    assert excinfo.value.value == 2

# Generated at 2022-06-23 22:55:21.547822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor  # type: ignore

    def get_tree(source: str) -> ast.FunctionDef:
        return ast.parse(source).body[0]  # type: ignore

    def test_return_from_generator(source: str, expected: str) -> None:
        node = get_tree(source)
        assert isinstance(node, ast.FunctionDef)

        ReturnFromGeneratorTransformer.run_visitor(node)
        actual = astor.to_source(node)

        assert expected == actual

    def test_no_return_from_generator(source: str) -> None:
        node = get_tree(source)
        assert isinstance(node, ast.FunctionDef)

        ReturnFromGeneratorTransformer.run_visitor(node)

        expected = astor.to_source(node)


# Generated at 2022-06-23 22:55:22.778421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:23.684454
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:32.184382
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    gen = ast.parse("""
    def fn():
        yield 1
        return 2
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(gen)

    gen = ast.parse("""
    def fn():
        yield 1
        yield from [1, 2, 3]
        return 2
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(gen)

    gen = ast.parse("""
    def fn():
        yield 1
        return 2
        yield 3
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(gen)



# Generated at 2022-06-23 22:55:33.788806
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:55:42.416944
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    function_def = _get_function_code("""
        def fn1():
            yield 1
            return 5
    """)
    function_def = transformer.visit(function_def)
    assert transformer.tree_changed

    assert transformer._find_generator_returns(function_def)
    transformer._replace_return(function_def, transformer._find_generator_returns(function_def)[0][1])
    assert transformer.tree_changed

    function_def = _get_function_code("""
        def fn2():
            yield 1
            return 5
            yield 2
            yield 6
            return 9
    """)
    function_def = transformer.visit(function_def)
    assert transformer.tree_changed

    function_def = _get_function_code

# Generated at 2022-06-23 22:55:43.619390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer([], {}, {}, {})

# Generated at 2022-06-23 22:55:48.648753
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    # type: str
    fn = """\
    def fn():
        yield 1
        return 5"""
    fn = ast.parse(fn) # type: ignore


    target = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc"""
    target = ast.parse(target) # type: ignore

    assert transformer.visit(fn) == target.body[0] # type: ignore


# Generated at 2022-06-23 22:55:59.277380
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import sys
    from io import StringIO
    from textwrap import dedent
    from typed_ast import ast3 as ast
    from ..utils import run_transformer
    from .base import BaseNodeTransformerTestCase, assertUnchanged

    class TestCase(BaseNodeTransformerTestCase):
        def setUp(self):
            self.module_node = ast.parse('def fn():\n    yield 1\n    return 5')
            self.expected_module_node = ast.parse(dedent('''\
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc'''))

    TestCase.__name__ = 'Test_transformer_{}'.format(ReturnFromGeneratorTransformer.__name__)
    test_case = TestCase()


# Generated at 2022-06-23 22:56:06.094076
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    node = ast.parse('''
        def fn():
            yield 5
            return 6
        fn()
    ''')
    c_node = transformer.visit(node)
    assert isinstance(c_node, ast.Module)

    fn = c_node.body[0].body[0]
    assert transformer._tree_changed

    assert fn.body[1].value.func.id == 'StopIteration'
    assert fn.body[1].value.args[0].value.n == 6



# Generated at 2022-06-23 22:56:10.947739
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  transformer = ReturnFromGeneratorTransformer()
  result = transformer.visit_FunctionDef(ast.parse('def fn(): yield 1').body[0])
  assert ast.dump(result) == '''Module(body=[FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Yield(value=Num(n=1)))], decorator_list=[], returns=None)])'''


# Generated at 2022-06-23 22:56:20.508992
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with patch('typed_astunparse.Unparser.dump', return_value='hello') as mock_unparser:
        assert ReturnFromGeneratorTransformer.get_targets() == (3, 2)
        transformer = ReturnFromGeneratorTransformer()
        assert transformer.visit_FunctionDef(ast.parse('def fn(): pass').body[0]) == ast.FunctionDef(
            name='fn',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kwarg=None,
                defaults=[],
                kw_defaults=[]
            ),
            body=[ast.Pass()],
            decorator_list=[],
            returns=None,
            type_comment=None
        )


# Generated at 2022-06-23 22:56:24.152092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:28.837118
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert transform(
        """
        def fn():
            yield 1
            return 2
        """,
        ReturnFromGeneratorTransformer,
    ) == """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """



# Generated at 2022-06-23 22:56:30.339563
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import dump, load


# Generated at 2022-06-23 22:56:32.690235
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Given
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

# Generated at 2022-06-23 22:56:40.702427
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..utils.test_utils import transform, assert_node_equal
    from .return_from_generator import ReturnFromGeneratorTransformer

    node = parse("""
        @total_ordering
        class Person:
            def __init__(self, age) -> None:
                self.age = age

            def __eq__(self, rhs: 'Person') -> bool:
                return self.age == rhs.age

            def __lt__(self, rhs: 'Person') -> bool:
                return self.age < rhs.age

            def fn(self):
                yield 1
                return 5
    """)
    new_node = transform(node, ReturnFromGeneratorTransformer)

# Generated at 2022-06-23 22:56:46.330452
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    result = ReturnFromGeneratorTransformer().visit_FunctionDef(ast.parse(source).body[0])
    assert astor.to_source(result) == expected



# Generated at 2022-06-23 22:56:52.521021
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import Fixture
    import textwrap
    Transformer = ReturnFromGeneratorTransformer

    def get_normal_fn():
        return textwrap.dedent(
            """\
            def foo():
                yield 1
                return 5
            """
        )

    def get_transformed_fn():
        return textwrap.dedent(
            """\
            def foo():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """
        )

    def get_normal_gen_exp():
        return textwrap.dedent(
            """\
            def bar():
                return (x for x in l if x)
            """
        )


# Generated at 2022-06-23 22:56:56.029801
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
    def foo():
        yield 1
        return 3

    def bar():
        return 4
    """
    tree = ast.parse(source)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    expected_source = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 3
        raise exc

    def bar():
        return 4

    """

    assert expected_source == astor.to_source(tree)

# Generated at 2022-06-23 22:57:00.701060
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    ast_tree = ast.parse(source)
    expected_ast = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformed_ast = transformer.visit(ast_tree)  # type: ignore

    assert ast.dump(transformed_ast) == ast.dump(expected_ast)

# Generated at 2022-06-23 22:57:02.097559
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:57:03.704167
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer(), 'visit_FunctionDef')


# Generated at 2022-06-23 22:57:12.844003
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    from ..transformer import get_ast_transformer
    from .base import BaseNodeTransformer

    transformer = get_ast_transformer(
        version=(3, 2),
        transformers=[
            'ReturnFromGeneratorTransformer'
        ])

    # Example 1
    func_def_ast = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    func_def_ast = func_def_ast.body[0]

    assert isinstance(transformer, BaseNodeTransformer)
    transformer.visit(func_def_ast)

    desired_code = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

# Generated at 2022-06-23 22:57:18.364058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    arguments = [ast.arg('a', None)]
    returns = [ast.Return(ast.Num(5))]
    generator = ast.FunctionDef('gen', arguments, returns, [], None)
    root = ast.Module([generator])

    transformer = ReturnFromGeneratorTransformer()
    transformed = transformer.visit(root)
    # print(transformed)
    assert len(transformed.body) == 1
    assert len(transformed.body[0].body) == 3
    assert isinstance(transformed.body[0].body[0], ast.Return)
    assert isinstance(transformed.body[0].body[1], ast.Assign)
    assert isinstance(transformed.body[0].body[2], ast.Raise)

# Generated at 2022-06-23 22:57:29.238313
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fixtures import typed_ast_function_def_with_cls
    from ..utils.helpers import all_nodes_of_class


# Generated at 2022-06-23 22:57:40.399334
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test visit_FunctionDef method."""
    transformer = ReturnFromGeneratorTransformer()

    ast_to_transform = ast.parse("""
        def fn():
            yield 5
            return 6

        def fn2():
            yield 4
            return
    """)
    expected_code = """
        def fn():
            yield 5
            exc = StopIteration()
            exc.value = 6
            raise exc

        def fn2():
            yield 4
            return
    """

    transformed_ast = transformer.visit(ast_to_transform)
    assert transformer._tree_changed is True
    # Check that the code is still valid
    ast.fix_missing_locations(transformed_ast)
    compiled_code = compile(transformed_ast, "<test>", "exec")
    exec(compiled_code)
   

# Generated at 2022-06-23 22:57:41.266039
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:57:46.980382
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import compile_to_ast, evaluate_ast

    ast_ = compile_to_ast('''
    def fn():
        yield 1
        return 2
    ''')
    assert isinstance(ast_, ast.Module)
    assert isinstance(ast_.body[0], ast.FunctionDef)

    ReturnFromGeneratorTransformer().visit(ast_)

    code = evaluate_ast(ast_)
    assert code.fn().__next__() == 1
    exc = StopIteration()
    exc.value = 2
    try:
        code.fn().__next__()
        raise AssertionError()
    except StopIteration as e:
        assert e.value == 2



# Generated at 2022-06-23 22:57:48.948098
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typing as tp
    import astunparse

# Generated at 2022-06-23 22:57:50.301298
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class1 = ReturnFromGeneratorTransformer()
    assert class1()  # pass

# Generated at 2022-06-23 22:58:01.328807
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from ..utils.source import source_to_unicode

    source = textwrap.dedent("""
    def fn():
        yield 1
        return 5
    """)
    result = textwrap.dedent("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    assert source_to_unicode(ReturnFromGeneratorTransformer().visit(ast.parse(source))) == source_to_unicode(result)

    source = textwrap.dedent("""
    def fn():
        yield from range(5)
        return 5
    """)

# Generated at 2022-06-23 22:58:10.008259
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .method_transformer import MethodTransformer
    from .class_transformer import ClassTransformer
    from .module_transformer import ModuleTransformer
    from ..utils.source_code import SourceCode
    from ..utils.ast_builder import AstBuilder
    from .python_transpiler import PythonTranspiler

    class FakeClassTransformer(ClassTransformer):
        @classmethod
        def transform(cls, source_code: SourceCode, **kwargs):
            return cls(source_code).transform(**kwargs)

    class FakeModuleTransformer(ModuleTransformer):
        @classmethod
        def transform(cls, source_code: SourceCode, **kwargs):
            return cls(source_code).transform(**kwargs)


# Generated at 2022-06-23 22:58:20.617855
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    f = ReturnFromGeneratorTransformer()
    node = ast.parse("""
    def fn():
        yield from [1, 2, 3]
        return 5
    """)
    f.visit(node)

# Generated at 2022-06-23 22:58:25.291185
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():  # type: ignore
    from ..utils.testing import get_node, assert_node_equal
    from ..utils.testing_helpers import module  # type: ignore

    original = module("""
    def fn():
        yield 1
        return 'str'
    """)[0]
    expected = module("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 'str'
        raise exc
    """)[0]

    ret = ReturnFromGeneratorTransformer().visit(original)

    assert_node_equal(expected, ret)