

# Generated at 2022-06-23 22:48:32.502208
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer()

    assert not class_._find_generator_returns(None)

    assert not class_._find_generator_returns(ast.parse('def fn(): yield 1').body[0])

    assert not class_._find_generator_returns(ast.parse('def fn(): return 1').body[0])

    assert class_._find_generator_returns(ast.parse('def fn(): yield 1; return 1').body[0])
    assert class_._find_generator_returns(ast.parse('def fn(): yield 1; if 1:\n return 1').body[0])
    assert class_._find_generator_returns(ast.parse('def fn(): if 1:\n yield 1\n return 1').body[0])

    assert not class_._find_generator

# Generated at 2022-06-23 22:48:43.286624
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import random

    import astor

    @snippet
    def function1():
        a = 1
        b = 1

        yield a
        return b

    @snippet
    def function2():
        # yield inside if
        a = 1
        if False:
            yield a
        else:
            return a

    @snippet
    def function3():
        # yield inside if inside if
        a = 1
        if False:
            if False:
                yield a
            else:
                return a
        else:
            return a

    @snippet
    def function4():
        # yield inside if inside if inside if
        a = 1
        if False:
            if False:
                if False:
                    yield a
                else:
                    return a
            else:
                return a

# Generated at 2022-06-23 22:48:53.674825
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # The following test tries to test if the following snippet
    #   def fn():
    #       yield 1
    #       return 5
    # Is changed to
    #   def fn():
    #       yield 1
    #       exc = StopIteration()
    #       exc.value = 5
    #       raise exc
    # This is a unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

    test_code = '''
        def fn():
            yield 1
            return 5
    '''

    compare_ast = ast.parse(tuple(return_from_generator.get_body(return_value=5))[1])
    compare_ast.body[0].value = ast.parse('5').body[0].value

    expected_ast = ast.parse(test_code)
    expected_ast.body

# Generated at 2022-06-23 22:49:04.104174
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 22:49:05.169177
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:14.667272
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    def fn2():
        a = 5
        if a > 0:
            return a
        else:
            return a

    def fn3():
        a = 5
        if a > 0:
            return a
        else:
            return a

    fnx = ReturnFromGeneratorTransformer()(fn)
    fn2x = ReturnFromGeneratorTransformer()(fn2)
    fn3x = ReturnFromGeneratorTransformer()(fn3)
    assert fnx.__code__.co_code == b'x\x00|\x00d\x01\x83\x01\x00S\x00'

# Generated at 2022-06-23 22:49:22.967928
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.__code__)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    body = tree.body[0]
    assert len(body.body) == 3
    assert isinstance(body.body[1], ast.Expr)
    assert isinstance(body.body[1].value, ast.Call)
    assert isinstance(body.body[2], ast.Expr)
    assert isinstance(body.body[2].value, ast.Raise)

# Generated at 2022-06-23 22:49:28.547759
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Given
    s = """\
    def fn():
        yield 1
        yield 2
        return 5
    """
    # When
    result = ReturnFromGeneratorTransformer().visit(ast.parse(s))
    print(ast.dump(result))
    # Then

# Generated at 2022-06-23 22:49:34.850620
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code_snippet = """
    def fn():
        yield 1
        return 5
    """

    expected_snippet = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    module = ast.parse(code_snippet)  # type: ignore
    transformer = ReturnFromGeneratorTransformer().visit(module)
    assert ast.dump(transformer) == expected_snippet

# Generated at 2022-06-23 22:49:36.860443
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-23 22:49:41.916724
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_body():
        yield 1
        yield 1
        return 5

    class test(object):
        def __init__(self):
            pass

    test.__doc__ = test_body()
    assert test.__doc__.__name__ == 'generator'
    return_from_generator.get_body(return_value=ast.Num(n=5))

# Generated at 2022-06-23 22:49:44.808874
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ctor = ReturnFromGeneratorTransformer()
    assert isinstance(ctor, BaseNodeTransformer)
    assert "ReturnFromGeneratorTransformer" == ctor.__class__.__name__


# Generated at 2022-06-23 22:49:52.732418
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest import TestCase
    from ..ast_utils import dump_ast
    from typed_astunparse import unparse

    class ReturnFromGeneratorTransformerTest(TestCase):

        # test_return_from_generator_1
        def test_return_from_generator_1(self):
            # Just some syntax.
            code = """
            def foo():
                print(1)
                return 1
            """
            input_ast = ast.parse(code)
            expected_ast = ast.parse(code)
            transformer = ReturnFromGeneratorTransformer()
            new_ast = transformer.visit(input_ast)

# Generated at 2022-06-23 22:49:53.793197
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-23 22:50:01.695476
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..codegen import to_source
    from ..testing.utils import get_ast

    tree = get_ast("""
        def fn():
            yield 1
            x = 5
            return x
    """)

    expected = """
        def fn():
            yield 1
            x = 5
            exc = StopIteration()
            exc.value = x
            raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    transformed_tree = transformer.visit(tree)
    assert to_source(transformed_tree) == expected



# Generated at 2022-06-23 22:50:03.156120
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:50:07.579068
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def check_code(
            before: str,
            after: str,
    ) -> None:
        node = ast.parse(before)
        node = ReturnFromGeneratorTransformer().visit(node)

        assert before != after
        assert ast.dump(node) == ast.dump(ast.parse(after))


# Generated at 2022-06-23 22:50:08.476316
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:14.425579
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    fn = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')
    assert return_from_generator_transformer._find_generator_returns(fn.body[0]) == [(fn.body[0], fn.body[0].body[1])]
    assert return_from_generator_transformer.visit(fn) == ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

# Generated at 2022-06-23 22:50:19.644816
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from pprint import pprint
    import astunparse

    code = '''
        def fn():
            yield 1
            return 5
        def other():
            return 6
    '''
    root = ast.parse(code)

    pprint(ReturnFromGeneratorTransformer().visit(root))

   

# Generated at 2022-06-23 22:50:22.434970
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    trans = ReturnFromGeneratorTransformer()
    assert hasattr(trans, 'target')
    assert hasattr(trans, 'visit_FunctionDef')

# Generated at 2022-06-23 22:50:23.486364
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:50:28.335743
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    module = ast.parse('def fn(): yield 1; return 5')
    transformer = ReturnFromGeneratorTransformer()
    module = transformer.visit(module)
    assert str(module) == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n'

# Generated at 2022-06-23 22:50:29.970135
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:50:34.661158
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert_equal(
        ReturnFromGeneratorTransformer().visit(ast.parse('''
            def fn():
                yield 1
                return 5
        ''').body[0]),
        ast.parse('''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        ''').body[0]
    )

# Generated at 2022-06-23 22:50:35.258914
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:36.000046
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:50:39.116839
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer(None, None),
        ast.parse('def fn():\n    yield 1\n    return 5'))


# Generated at 2022-06-23 22:50:39.850808
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:45.476919
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    function_def = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    expected_function_def = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    actual_function_def = transformer.visit(function_def)

    assert ast.dump(actual_function_def) == ast.dump(expected_function_def)

# Generated at 2022-06-23 22:50:50.587380
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r1 = ReturnFromGeneratorTransformer()
    r2 = ReturnFromGeneratorTransformer()
    assert r1 is not r2

# Generated at 2022-06-23 22:50:58.598760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case 1 : Function contains return
    test_tree_1 = ast.parse('''def test1():
     return 5
     ''')
    transform = ReturnFromGeneratorTransformer().visit(test_tree_1)
    expected_1 = ast.parse('''def test1():
     exc = StopIteration()
     exc.value = 5
     raise exc
     ''')
    assert ast.dump(expected_1, include_attributes=False) == ast.dump(transform, include_attributes=False)

    # Test case 2 : Function contains multiple returns
    test_tree_2 = ast.parse('''def test2():
     if x:
        return 5
     else:
        return 6
     ''')
    transform = ReturnFromGeneratorTransformer().visit(test_tree_2)

# Generated at 2022-06-23 22:51:00.159576
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:07.665716
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse('\n'.join(
        "def foo():",
        "    yield 1",
        "    return 2"
    ))
    return_from_generator_transformer.visit(tree)
    expected_tree = ast.parse('\n'.join(
        "def foo():",
        "    yield 1",
        "    exc = StopIteration()",
        "    exc.value = 2",
        "    raise exc"
    ))
    assert ast.dump(expected_tree) == ast.dump(tree)

# Generated at 2022-06-23 22:51:09.588045
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer

# Generated at 2022-06-23 22:51:20.019355
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transform
    code = "def foo(): yield 42; return 'my return value'"
    expected_code = "def foo(): yield 42; exc = StopIteration(); exc.value = 'my return value'; raise exc"
    assert_transform(ReturnFromGeneratorTransformer, code, expected_code)

    code = "def foo(): yield 42"
    expected_code = "def foo(): yield 42"
    assert_transform(ReturnFromGeneratorTransformer, code, expected_code)

    code = "def foo(): return"
    expected_code = "def foo(): return"
    assert_transform(ReturnFromGeneratorTransformer, code, expected_code)

    code = "def foo(): if x: return 42; return"
    expected_code = "def foo(): if x: return 42; return"
   

# Generated at 2022-06-23 22:51:23.620999
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fixtures.generators import tree, code
    from ..utils.compiler import compile_code

    result = ReturnFromGeneratorTransformer().visit(tree)
    new_code = compile_code(result)
    assert new_code == code

# Generated at 2022-06-23 22:51:26.168540
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        return_from_generator.get_body(return_value='asd')
    except:
        print('Failed to compile ReturnFromGeneratorTransformer')

# Generated at 2022-06-23 22:51:35.784418
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test for empty generator
    transformer = ReturnFromGeneratorTransformer(None, None)
    func = ast.parse("""
    def gen():
        yield 1
    """)
    node = func.body[0]
    assert transformer._find_generator_returns(node) == []

    # Test for generator with return statement
    func = ast.parse("""
    def gen():
        yield 1
        return 2
    """)
    node = func.body[0]
    assert transformer._find_generator_returns(node) == [(func.body[0].body[1], func.body[0].body[1].value)]

    # Test for generator with multiple return statements

# Generated at 2022-06-23 22:51:45.805071
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestVisitor(ast.NodeVisitor):
        def __init__(self):
            self.res = []

        def generic_visit(self, node):
            self.res.append(node.__class__)
            super().generic_visit(node)


# Generated at 2022-06-23 22:51:56.018179
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """This test method checks the correctness of the visit_FunctionDef()
    method of class ReturnFromGeneratorTransformer. This method replaces a
    return statement in a generator function with a raise statement, so that
    the function will raise the StopIteration exception with the return value
    as the argument. The following tests are taken into consideration:
    1. Test to check if the visit_FunctionDef() method correctly identifies
       the return statement in a generator function.
    2. Test to check if the visit_FunctionDef() method correctly replaces
       the return statement with a raise statement.
    3. Test to check if the visit_FunctionDef() method correctly sets the
       _tree_changed flag to True when it replaces a return statement with
       a raise statement.
    """

# Generated at 2022-06-23 22:52:05.531422
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class FunctionDef(ast.FunctionDef):
        def __init__(self, name, children):
            self.name = name
            self.body = children

    class Return(ast.Return):
        def __init__(self):
            self.value = name

    def test_function_no_yield_no_return(args):
        assert args.name == 'test_function_no_yield_no_return'

    def test_function_no_yield_return(args):
        assert args.name == 'test_function_no_yield_return'
        return Return()

    def test_function_yield_no_return(args):
        assert args.name == 'test_function_yield_no_return'
        for i in (1, 2):
            yield i


# Generated at 2022-06-23 22:52:14.759732
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_transformer = ReturnFromGeneratorTransformer()

    node = ast.parse(
        "def fn():\n"
        "  yield 'a'\n"
        "  yield 'b'\n"
        "  return 5"
    )

    result_function = test_transformer.visit(node)
    result_expected = ast.parse(
        "def fn():\n"
        "    yield 'a'\n"
        "    yield 'b'\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc"
    )

    assert ast.dump(result_function) == ast.dump(result_expected)

# Generated at 2022-06-23 22:52:18.572773
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def result(src):
        ast_tree = ast.parse(src)
        return_from_generator_transformer = ReturnFromGeneratorTransformer()
        ast_tree = return_from_generator_transformer.visit(ast_tree)
        return astor.to_source(ast_tree)


# Generated at 2022-06-23 22:52:24.906429
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astor.code_gen import to_source

    fn = ast.FunctionDef('fn', [], [ast.Yield(ast.Num(1)), ast.Return(ast.Num(5))])
    transformed = to_source(ReturnFromGeneratorTransformer().visit(fn))
    assert transformed == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

# Generated at 2022-06-23 22:52:34.838161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import PY3, BaseNodeTransformerTest
    from ..utils import source_to_ast

    source = """
        def foo():
            yield 1
            return 2

        def bar():
            if True:
                yield 1
                return 2
    """

    expected_source = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

        def bar():
            if True:
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc
    """

    def test_fn(tree: ast.Module) -> None:
        node = tree.body[0]
        assert isinstance(node, ast.FunctionDef)
        assert len(node.body) == 2

# Generated at 2022-06-23 22:52:35.845327
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:36.764751
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:44.379463
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Instance of ReturnFromGeneratorTransformer
    transformer = ReturnFromGeneratorTransformer()

    # Generator with return statement
    generator_with_return = ast.parse(
        '''
        def fn():
            yield 1
            return 5
        '''
    )

    # Transformer should change the tree and return generator without return statement
    assert transformer.visit(generator_with_return) == ast.parse(
        '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    )

    # If generator does not have statement return, then transformer should not change the tree
    generator = ast.parse(
        '''
        def fn():
            yield 1
        '''
    )

# Generated at 2022-06-23 22:52:54.268521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # noinspection PyUnresolvedReferences
    from compiled.statement_unpacking import ReturnFromGeneratorTransformer


# Generated at 2022-06-23 22:52:55.024684
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-23 22:52:57.136551
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer."""
    print(ReturnFromGeneratorTransformer())


# Generated at 2022-06-23 22:52:59.281459
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rft = ReturnFromGeneratorTransformer(3.7)
    assert rft.target == (3, 2)

# Generated at 2022-06-23 22:53:01.601171
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:02.681766
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:11.233236
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import cst_to_ast

    generator1 = """
    def fn():
        return 1
        """
    generator2 = """
    def fn():
        i = 1
        if True:
            return i
        """
    generator3 = """
    def fn():
        i = 1
        if True:
            return i
        else:
            return 0
        """
    generator4 = """
    def fn():
        i = 1
        if True:
            pass
        else:
            return 0
        """
    generator5 = """
    def fn():
        def inner():
            return 2
        return 1
        """
    generator6 = """
    def fn():
        if True:
            def inner():
                return 2
            return 1
        """

# Generated at 2022-06-23 22:53:17.758565
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create AST structure
    # def a():
    #     yield 1
    #     return 2
    # @typed_ast.ast3.dump
    module = ast.Module()

    function_def = ast.FunctionDef()
    function_def.name = "a"
    function_def.args = ast.arguments()
    function_def.returns = None

    yield_ = ast.Yield()
    yield_.value = ast.Constant()
    yield_.value.value = 1
    yield_.value.kind = None

    return_ = ast.Return()
    return_.value = ast.Constant()
    return_.value.value = 2
    return_.value.kind = None

    function_def.body = [yield_, return_]

    module.body = [function_def]

    # Function to test

# Generated at 2022-06-23 22:53:26.993132
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Tester(ReturnFromGeneratorTransformer):
        def __init__(self):
            self.trees = []
            self.trees_changed = []

        def visit_FunctionDef(self, node):
            self.trees.append(deepcopy(node))
            r = super().visit_FunctionDef(node)
            self.trees_changed.append(deepcopy(r))
            return r

    tester = Tester()

    fn1 = FunctionDef(
        name='fn',
        args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
        body=[
            Return(value=Num(n=5)),
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-23 22:53:29.840364
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .utils import to_source
    from .utf8_literal import UTF8LiteralTransformer


# Generated at 2022-06-23 22:53:39.102887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_ = ReturnFromGeneratorTransformer
    func_ = class_._find_generator_returns

    case = ast.parse(textwrap.dedent("""
    def f():
        yield 1
        return 2
    """)).body[0]
    assert len(func_(class_, case)) == 1

    case = ast.parse(textwrap.dedent("""
    def f():
        yield from []
        return 2
    """)).body[0]
    assert len(func_(class_, case)) == 1

    case = ast.parse(textwrap.dedent("""
    def f():
        print()
        return 2
    """)).body[0]
    assert len(func_(class_, case)) == 0


# Generated at 2022-06-23 22:53:42.629718
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test constructor of class ReturnFromGeneratorTransformer"""
    instance = ReturnFromGeneratorTransformer()
    assert isinstance(instance, ReturnFromGeneratorTransformer)
    assert instance._tree_changed == False


# Generated at 2022-06-23 22:53:45.306848
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0]

    assert node == ReturnFromGeneratorTransformer().visit(node)


# Generated at 2022-06-23 22:53:46.920183
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Object creation of class ReturnFromGeneratorTransformer
    test = ReturnFromGeneratorTransformer()
    assert test != None

# Generated at 2022-06-23 22:53:47.763412
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)



# Generated at 2022-06-23 22:53:51.805853
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    s = 'def foo(): yield 1\nreturn 5'
    expected = 'def foo(): yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc'

    result = ReturnFromGeneratorTransformer.run_test(s)

    assert expected == result


# Generated at 2022-06-23 22:54:01.293459
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import ssa_to_ast, compare_asts, transform_and_compare_asts

    # testing functions
    def f():
        yield 1
        return 2

    def f2():
        for x in range(2):
            yield x
            return 1 + 2

    def f3():
        for x in range(2):
            for y in range(2):
                yield x, y
                return x + y

    def f4():
        for x in range(2):
            yield x
        return 2

    def f5():
        for x in range(2):
            yield x
            return x

        return 0

    def f6():
        return 2

    def f7():
        yield 1
        return None

    def f8():
        yield 1
        return 2
        yield 3

# Generated at 2022-06-23 22:54:10.165978
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import assert_transformed_code

    assert_transformed_code(ReturnFromGeneratorTransformer, '''
        def fn():
            yield 1
            return 5
    ''', '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    assert_transformed_code(ReturnFromGeneratorTransformer, '''
        def fn():
            return 5

        def fn():
            yield 1
            return 5

        def fn():
            return 5
            yield 1

        def fn():
            while True:
                yield 1
                if True:
                    return 5
    ''')



# Generated at 2022-06-23 22:54:13.038741
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast.ast3 import parse
    from .transformer import get_ast_as_string


# Generated at 2022-06-23 22:54:22.977106
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test = ReturnFromGeneratorTransformer()
    assert test._find_generator_returns(ast.parse('''
        def fn():
            pass
    ''').body[0]) == []

    assert test._find_generator_returns(ast.parse('''
        def fn():
            yield 1
            return 1
    ''').body[0]) == [(
        ast.parse('''
            def fn():
                yield 1
                return 1
        ''').body[0],
        ast.parse('''
            def fn():
                yield 1
                return 1
        ''').body[0].body[1]
    )]


# Generated at 2022-06-23 22:54:33.901095
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # a test generator-function
    def generator_func():
        yield 1
        return 5

    # return type annotation in python
    def generator_func_with_annotations() -> Generator[int, None, int]:
        yield 1
        return 5

    # function with body that is not a generator
    def test_func():
        return 5

    # function with body that is not a generator and return type annotation
    def test_func_with_annotations() -> int:
        return 5

    # function with body that yields and raises StopIteration exception
    def test_func_with_exception():
        yield 1
        raise StopIteration()

    # function with body that yields and raises StopIteration exception
    def test_func_with_exception_and_annotations() -> Generator[int, None, None]:
        yield 1
        raise

# Generated at 2022-06-23 22:54:43.101731
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    function = ast.parse(textwrap.dedent('''
        def fn():
            yield 1
            return 2
        '''))
    function = transformer.visit(function)

    assert transformer.tree_changed is True

# Generated at 2022-06-23 22:54:47.932140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer(do_return=False)
    node = ast.parse('''
    def foo():
        yield 1
        return 3
    ''')
    node = transformer.visit(node)
    expected = '''
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 3
        raise exc
    '''
    assert ast.dump(node) == expected


# Generated at 2022-06-23 22:54:49.963084
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert(return_from_generator_transformer is not None)


# Generated at 2022-06-23 22:54:51.041716
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:02.719279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import inspect
    import astor  # type: ignore
    from ..utils.typing import get_type_hints  # type: ignore

    def compile(fn):
        return return_from_generator_compile(fn, fn.__name__, get_type_hints(fn))

    # Case 1
    @compile
    def fn1():
        yield 1

    assert inspect.isgeneratorfunction(fn1)
    assert astor.to_source(ast.parse(inspect.getsource(fn1))) == 'def fn1():\n    yield 1\n'

    # Case 2
    @compile
    def fn2():
        yield 1
        return 5

    assert inspect.isgeneratorfunction(fn2)

# Generated at 2022-06-23 22:55:04.662604
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-23 22:55:14.405843
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer.'''
    import astunparse


# Generated at 2022-06-23 22:55:15.945629
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:55:18.365605
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast


# Generated at 2022-06-23 22:55:19.547770
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:55:27.499205
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .misc_transformer import MiscTransformer
    from ..utils.source import source_to_ast, source_to_code
    transformer = ReturnFromGeneratorTransformer()

    def check_result(source: str, expected: str) -> None:
        tree = source_to_ast(source)
        transformer.visit(MiscTransformer().visit(tree))
        assert source_to_code(tree) == expected

    check_result(
        source='''
            def test():
                yield 1
                yield 2
                yield 3
        ''',
        expected='''
            def test():
                yield 1
                yield 2
                yield 3
        '''
    )


# Generated at 2022-06-23 22:55:33.534876
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformed_function = ast.parse('def fn():\n    yield 1\n    return 5').body[0]
    expected_function = ast.parse(
        'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc').body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(transformed_function)
    assert ast.dump(transformed_function) == ast.dump(expected_function)

# Generated at 2022-06-23 22:55:37.947834
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("def fn():\n yield 1\n return 5\n")
    ast.fix_missing_locations(node)
    t = ReturnFromGeneratorTransformer(mode="test")
    new_node = t.visit(node)
    if not t._tree_changed:
        raise ValueError("Tree has not changed")
    assert new_node.body[0].body.pop().value.func.id == 'StopIteration'

# Generated at 2022-06-23 22:55:45.346632
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input = """
        def odd():
            if 5 % 2 == 0:
                return True
            else:
                return False

        def gen():
            yield 1
            return 5
    """

    expected = """
        def odd():
            if 5 % 2 == 0:
                return True
            else:
                return False

        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    node = ast.parse(input)
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    actual = ast.unparse(node)

    # assert expected == actual
    assert ast.parse(expected) == ast.parse(actual)

# Generated at 2022-06-23 22:55:51.882880
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    import ast
    import astunparse

    node = ast.parse(dedent("""
        def foo():
            yield 1
            return 5
        """))

    rfg = ReturnFromGeneratorTransformer()
    rfg.visit(node)

    assert astunparse.unparse(node).strip() == dedent("""
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """).strip()



# Generated at 2022-06-23 22:55:53.276934
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None


# Generated at 2022-06-23 22:56:03.253774
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.node import compare_ast

    source = """
    def f():
        for i in range(5):
            yield i
            return i

        yield 5
        return 5
    """
    expected = """
    def f():
        for i in range(5):
            yield i
            exc = StopIteration()
            exc.value = i
            raise exc

        yield 5
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = source_to_ast(source)
    node = ast_tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(ast_tree)

    assert compare_ast(new_tree, expected)

# Generated at 2022-06-23 22:56:09.747391
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_ReturnFromGeneratorTransformer_visit_FunctionDef(b):
        """
        def fn():
            yield 1
            return 5
    """
        return_from_generator_transformer = ReturnFromGeneratorTransformer(None, False)
        tree = ast.parse(b)
        new_tree = return_from_generator_transformer.visit(tree)
        expected = a
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
        assert new_tree.body == ast.parse(expected).body

# Generated at 2022-06-23 22:56:15.708115
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node1 = ast.FunctionDef('fn', ast.arguments([], [], [], [], None, [], []), [], [], None)
    node2 = ast.FunctionDef('fn', ast.arguments([], [], [], [], None, [], []), [], [], None)
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._find_generator_returns(node1) == []
    assert transformer._find_generator_returns(node2) == []


# Generated at 2022-06-23 22:56:23.525527
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    actual_result = transformer.visit(node)

    expected_result = ast.parse(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    assert ast.dump(actual_result) == ast.dump(expected_result)

# Generated at 2022-06-23 22:56:24.181000
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert bool(ReturnFromGeneratorTransformer())

# Generated at 2022-06-23 22:56:32.740419
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    code = "def fn():\n  return 1"
    expected = dedent(code)
    assert transformer.visit(ast.parse(code)) == ast.parse(expected)

    code = "def fn():\n  yield 1\n  return 1"
    expected = dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc''')
    tree = transformer.visit(ast.parse(code))
    assert tree == ast.parse(expected)


# Generated at 2022-06-23 22:56:38.409411
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import ast_converter

    src = """
        def fn():
            yield 1
            return 5
        """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    module = ast_converter.parse(src)
    ReturnFromGeneratorTransformer().visit(module)

    print(astor.to_source(module))

    assert astor.to_source(module) == expected



# Generated at 2022-06-23 22:56:43.944513
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
        def ff():
            yield 3
            return 5
        """
    tree = ast.parse(source)  # type: ignore
    ReturnFromGeneratorTransformer().visit(tree)
    code = compile(tree, '<test>', mode='exec', optimize=2)
    exec(code)
    assert ff().next() == 5

# Generated at 2022-06-23 22:56:50.305279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(ast.parse('')).target == (3, 2)

    tree = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """)
    old_tree_copy = copy.deepcopy(tree)

    transformer = ReturnFromGeneratorTransformer(tree)
    transformer.run()
    assert transformer.tree_changed()

    new_tree_copy = copy.deepcopy(tree)

    # we're only interested in changes to `FunctionDef`, so compare only that
    assert ast.dump(old_tree_copy.body[0]) == ast.dump(new_tree_copy.body[0])



# Generated at 2022-06-23 22:56:53.214901
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ast_tools.transformers.return_from_generator import ReturnFromGeneratorTransformer
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:54.476026
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 22:57:03.100213
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test if the line (yield 1) will be removed
    ast_tree = ast.parse(
        'def fn():\n'
        '    yield 1\n'
        '    return 5\n'
    )
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert len(new_ast.body) == 1
    func_def = new_ast.body[0]
    assert func_def.body[1].value.args[0].value.id == 'StopIteration'
    assert func_def.body[1].value.args[0].value.args == ()
    assert func_def.body[1].value.args[0].value.keywords == []



# Generated at 2022-06-23 22:57:11.312756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import compile_and_get_ast
    from ..utils.compare import assert_ast

    def fn():
        yield 1
        return 5

    expected = compile_and_get_ast("def fn():\n"
                                   "    yield 1\n"
                                   "    exc = StopIteration()\n"
                                   "    exc.value = 5\n"
                                   "    raise exc")

    tree = compile_and_get_ast(fn)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(tree)
    assert transformer._tree_changed
    assert_ast(expected, result)

# Generated at 2022-06-23 22:57:12.537984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse
    import astor


# Generated at 2022-06-23 22:57:14.114144
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
# test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:57:23.052076
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    orig = """
        def foo():
            yield 5
            return 1
        def bar():
            yield 5
            return 1.3
        def baz():
            yield 5
            return False
        def zab():
            yield 5
            return 'str'
        def zab():
            yield 5
            return 'str'
    """


# Generated at 2022-06-23 22:57:30.808078
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    func_def = ast.parse("""
        def test():
            yield 1
            return 2
    """).body[0]
    func_def = return_from_generator_transformer.visit(func_def)
    assert ''.join([line.strip() for line in ast.unparse(func_def).splitlines()]).strip() == 'def test():' + \
                  ' yield 1' + \
                  ' exc = StopIteration()' + \
                  ' exc.value = 2' + \
                  ' raise exc'


# Generated at 2022-06-23 22:57:42.086936
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import compile_function
    from .base import run_function
    from .base import generate_function_1

    fn = compile_function(ReturnFromGeneratorTransformer, generate_function_1.source)
    assert 'StopIter' in fn.__code__.co_code
    assert 'StopIteration' in fn.__code__.co_names
    assert 'exc' in fn.__code__.co_varnames
    assert fn(1) == 5

    fn = run_function(ReturnFromGeneratorTransformer, generate_function_1.source)
    assert 'StopIter' in fn.__code__.co_code
    assert 'StopIteration' in fn.__code__.co_names
    assert 'exc' in fn.__code__.co_varnames
    assert fn(1) == 5



# Generated at 2022-06-23 22:57:48.366514
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor  # type: ignore

    # Test simple function
    fn = """
    def fn():
        yield 1
        return 5
    """
    node = ast.parse(fn)
    ReturnFromGeneratorTransformer().visit(node)
    expected_fn = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
    
        raise exc
    """
    assert astor.to_source(node).strip() == expected_fn.strip()

    # Test complex function
    fn = """
    def fn():
        yield 1
        yield 2
        return 5
    """
    node = ast.parse(fn)
    ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-23 22:57:59.370461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test that return statement in generator gets replaced with raise."""
    # Given
    code = """
    def fn():
        yield 1
        return 5
    """
    # When
    tree = ast3.parse(code)
    node_transformer = ReturnFromGeneratorTransformer("")
    node_transformer.visit(tree)
    # Then

# Generated at 2022-06-23 22:58:00.415819
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:09.376020
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import typed_ast.ast3 as ast
    from .helpers import build_and_run
    from .return_from_generator import ReturnFromGeneratorTransformer
    node = ast.FunctionDef(name="fn", args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Yield(value=ast.Str(s="1")), ast.Return(value=ast.Num(n=5))], decorator_list=[], returns=None, type_comment=None)

# Generated at 2022-06-23 22:58:13.472749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import Node, assert_equal_ast
    from .function_simplifier import FunctionSimplifier

    # Preprocess
    src = 'def fn():\n    yield 1\n    return 5'
    src_ast = Node.parse(src)

# Generated at 2022-06-23 22:58:21.845614
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .test_helpers import round_trip
    from .test_helpers import assert_equal_ignore_lineno

    def check(code, expected_code=None):
        if expected_code is None:
            expected_code = code
        code_ast = ast.parse(code)
        expected_ast = ast.parse(expected_code)

        transformer = ReturnFromGeneratorTransformer()
        assert transformer.visit(code_ast) is not None

        assert_equal_ignore_lineno(round_trip(code_ast), round_trip(expected_ast))


# Generated at 2022-06-23 22:58:22.564006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:26.977275
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    s = """
    def fn():
        yield 1
        return 5
    """
    node = ast.parse(s)
    ReturnFromGeneratorTransformer().visit(node)

    expected_s = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert ast.dump(node) == ast.dump(ast.parse(expected_s))

