

# Generated at 2022-06-23 22:48:29.227183
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse("""
        def fn():
            yield 1
            print(42)
            return 1
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)

    assert str(module) == """
    import builtins
    def fn():
        yield 1
        print(42)
        exc = builtins.StopIteration()
        exc.value = 1
        raise exc
    """

# Generated at 2022-06-23 22:48:36.911847
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import ReturnFromGeneratorTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from typed_ast import ast3 as ast
    from inspect import isfunction
    node = ast.parse("""
    def foo():
        yield 1
        return 2
    assert (yield from bar())
    def bar():
        yield from foo()
        return 2
    """).body[0]

    transformer_instance = ReturnFromGeneratorTransformer()

    # Check that transformer instance is an instance of ReturnFromGeneratorTransformer class
    assert isinstance(transformer_instance, ReturnFromGeneratorTransformer)

    # Check that it is a subclass of BaseNodeTransformer
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)

    # Check that ReturnFromGeneratorTransformer class is a subclass

# Generated at 2022-06-23 22:48:38.534178
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:48:39.515464
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ret = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:48:44.092086
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ast.parse("""def fn():\n yield 1\n return 5""")
    ReturnFromGeneratorTransformer().visit(x)
    assert ast.dump(x) == "def fn():\n yield 1\n exc = StopIteration()\n exc.value = 5\n raise exc"

# Generated at 2022-06-23 22:48:54.352327
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse


# Generated at 2022-06-23 22:48:56.808760
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is ReturnFromGeneratorTransformer  # for mypy


# Generated at 2022-06-23 22:48:57.662967
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:05.348161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = snippet(
        """
        def fn():
            yield 1
            return 5
        """
    ).fn

    original_source = ast.dump(fn)

    fn_after = ReturnFromGeneratorTransformer().visit_FunctionDef(fn)
    source = ast.dump(fn_after)

    new_fn = ast.parse(source)
    fn_after = ReturnFromGeneratorTransformer().visit_FunctionDef(new_fn.body[0])
    source_2 = ast.dump(fn_after)

    assert source == source_2
    assert original_source != source


# Generated at 2022-06-23 22:49:06.083417
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:15.214172
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:25.995878
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    assert ReturnFromGeneratorTransformer().visit_FunctionDef(
        ast.parse("""
        def fn():
            yield 1
            return 5
        """).body[0]) == ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """).body[0]

    assert ReturnFromGeneratorTransformer().visit_FunctionDef(
        ast.parse("""
        def fn():
            return 5
        """).body[0]) == ast.parse("""
        def fn():
            return 5
        """).body[0]

    assert ReturnFromGeneratorTransformer().visit_FunctionDef(
        ast.parse("""
        def fn():
            yield 1
            yield 5
            return
        """).body[0]) == ast.parse

# Generated at 2022-06-23 22:49:26.775135
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:27.979214
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None)
    assert transformer is not None

# Generated at 2022-06-23 22:49:33.128843
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def fn():
        yield 5
        return 3

    gen = ReturnFromGeneratorTransformer().visit(fn.root)
    gen_fn = fn.evaluate()

    assert gen is not None
    assert gen_fn.__name__ == gen.name  # type: ignore
    assert [x for x in gen_fn()] == [x for x in gen()]



# Generated at 2022-06-23 22:49:34.709189
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for ReturnFromGeneratorTransformer class."""

# Generated at 2022-06-23 22:49:40.295316
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @ReturnFromGeneratorTransformer.transform()
    def f():
        yield 1
        return 5

    assert f() == 1
    try:
        next(f())
    except StopIteration as e:
        assert e.value == 5
        assert str(e) == 'StopIteration: 5'
    else:
        raise AssertionError('StopIteration was not raised')


# Generated at 2022-06-23 22:49:42.559941
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import transform
    from .agument_ast_with_line_numbers import ArgumentedASTWithLineNumbers


# Generated at 2022-06-23 22:49:51.429583
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node_1 = ast.FunctionDef(name='fn', body=[
        ast.Expr(value=ast.Yield(value=ast.Constant(value=1)), lineno=1, col_offset=4),
        ast.Return(value=ast.Constant(value=5), lineno=2, col_offset=8)
    ], lineno=1, col_offset=0, decorator_list=[], returns=None, args=ast.arguments(
        args=[], vararg=None, varargannotation=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
        kwargannotation=None, defaults=[], posonlyargs=[]),
        type_comment=None)


# Generated at 2022-06-23 22:49:53.246390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(tree=None)

    # OK

# Generated at 2022-06-23 22:49:59.116780
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def_node = ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformed_node = transformer.visit(def_node)
    assert transformed_node == ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

# Generated at 2022-06-23 22:50:00.686728
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:50:06.152653
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
        def test():
            yield 10
            return 22
    """
    expected = """
        def test():
            yield 10
            exc = StopIteration()
            exc.value = 22
            raise exc
    """

    node = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:50:07.797581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor  # type: ignore


# Generated at 2022-06-23 22:50:08.631324
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-23 22:50:16.491621
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import PythonLikeCode
    from ..api import compile_pythonlike
    from .generator import ReturnFromGeneratorTransformer

    code = \
        PythonLikeCode(
            function_defs = [
                PythonLikeCode.FunctionDef(
                    "fn",
                    [],
                    [
                        PythonLikeCode.Expr(
                            PythonLikeCode.Call(
                                PythonLikeCode.Name("yield"),
                                PythonLikeCode.Integer(1))),
                        PythonLikeCode.Return(
                            PythonLikeCode.Integer(5))
                    ])
            ])

    result = compile_pythonlike(
        code,
        transformer_classes=[ReturnFromGeneratorTransformer])


# Generated at 2022-06-23 22:50:17.205351
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:50:18.126181
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:50:26.568187
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class SimpleFunctionDef(ast.AST):
        _fields = ('body',)

    class SimpleStmt(ast.AST):
        _fields = ()

    def _assert(case: str, expected: str, node: ast.AST) -> None:
        node = ReturnFromGeneratorTransformer().visit(node)
        assert str(ast.dump(node, include_attributes=True)) == expected, f'Fail test case {case}'

    # """
    # def fn():
    #     yield 1
    # """

# Generated at 2022-06-23 22:50:36.130934
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source

    source1 = """
        def a():
            return 1
        """
    source2 = """
        def a():
            yield 1
            return 1
        """
    source3 = """
        def a():
            if False:
                return 1
        """
    source4 = """
        def a():
            if False:
                yield 1
                return 1
    """

    node1 = ast.parse(source1)
    node2 = ast.parse(source2)
    node3 = ast.parse(source3)
    node4 = ast.parse(source4)

    ReturnFromGeneratorTransformer().visit(node1)
    ReturnFromGeneratorTransformer().visit(node2)
    ReturnFromGeneratorTransformer().visit(node3)
    ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:47.218784
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:49.358207
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""

    from astunparse import unparse


# Generated at 2022-06-23 22:50:53.444197
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    for target in ((3, 2), (3, 3)):
        try:
            ReturnFromGeneratorTransformer(target)
        except Exception as exc:
            raise AssertionError(
                "Target version {0} should not raise any exception, but raised: {1}".format(target, repr(exc))
            )


# Generated at 2022-06-23 22:50:59.460623
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source

    source = """def fn(a):
        yield 1
        if a:
            yield a
        else:
            return 5
    """
    expected_source = """def fn(a):
        yield 1
        if a:
            yield a
        else:
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    module_node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module_node)
    assert_source(module_node, expected_source)

# Generated at 2022-06-23 22:51:00.041903
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:09.461745
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class `ReturnFromGeneratorTransformer`."""
    ast_node = ast.parse(textwrap.dedent(
        """
        def generator():
            yield 1
            return
        """))
    node_transformer = ReturnFromGeneratorTransformer()
    new_node = node_transformer.visit(ast_node)
    assert node_transformer._tree_changed is True
    assert ast.dump(new_node) == ast.dump(ast.parse(textwrap.dedent(
        """
        def generator():
            yield 1
            exc = StopIteration()
            raise exc
        """)))

    ast_node = ast.parse(textwrap.dedent(
        """
        def generator():
            yield 1
            return 5
        """))
    node_transformer = ReturnFromGenerator

# Generated at 2022-06-23 22:51:10.245897
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:11.843442
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._target == (3, 2)


# Generated at 2022-06-23 22:51:22.347414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import typed_astunparse
    from .test_BaseNodeTransformer import BaseNodeTransformerTestCase

    class ReturnFromGeneratorTransformerTestCase(BaseNodeTransformerTestCase):
        def test_return_from_generator(self):
            code = '''
            def fn():
                yield 1
                return 5
            '''
            expected_code = '''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            '''
            tree = ast.parse(code)
            new_tree = ReturnFromGeneratorTransformer().visit(tree)
            typed_astunparse.dump(new_tree)
            self.assertEqual(expected_code, typed_astunparse.unparse(new_tree))


# Generated at 2022-06-23 22:51:23.831555
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:51:28.931422
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
        def fn():
            yield 1
            return 5
        '''
    expect = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    assert ReturnFromGeneratorTransformer().visit(ast.parse(source)) == ast.parse(expect)


# Generated at 2022-06-23 22:51:34.659563
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast.ast3 import FunctionDef, Return, parse
    from .generator_to_listcomp import GeneratorToListcompTransformer

    code = """
    def fn():
        yield 1
        return 10
    """
    tree = parse(code)
    lc = GeneratorToListcompTransformer()
    lc.visit(tree)
    r = ReturnFromGeneratorTransformer()
    r.visit(lc.module)

    def test_fn():
        yield 1
        exc = StopIteration()
        exc.value = 10
        raise exc

    assert lc.fn is not None
    assert lc.fn.body[0] == lc.fn.body[1]

# Generated at 2022-06-23 22:51:42.757880
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def test_case_1(self):
            node = ast.parse(r'''
                def fn():
                    yield 1
                    return 5
            ''')
            expected = ast.parse(r'''
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            ''')

            c = ReturnFromGeneratorTransformer()
            result = c.visit(node)

            self.assertTrue(ast.dump(result) == ast.dump(expected))

    return TestReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:43.798548
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:54.590707
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # case 1
    code = """\
    def fn():
        yield 1
        return 5
    """
    expected_code = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert ast.dump(new_tree) == expected_code

    # case 2
    code = """\
    def fn():
        return 5
    """
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert ast.dump(new_tree) == code



# Generated at 2022-06-23 22:52:01.397450
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    example = '''\
    def fn():
        yield 1
        return 5
    '''
    expected = '''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    with BaseNodeTransformer.expand_ast(example) as tree:
        ReturnFromGeneratorTransformer().visit(tree)
        with BaseNodeTransformer.compile_ast(tree) as result:
            assert result == expected, result


# Generated at 2022-06-23 22:52:02.264157
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:52:03.980696
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer

# Generated at 2022-06-23 22:52:04.945765
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:52:11.271667
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source, mode='exec')
    tr = ReturnFromGeneratorTransformer()
    tr.visit(node)
    expected_node = ast.parse(expected, mode='exec')
    assert ast.dump(expected_node) == ast.dump(node)

# Generated at 2022-06-23 22:52:18.724894
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Check that the new code is generated correctly."""
    from ..utils import source_to_ast, source_to_code

    source = """def fn():
    yield 1
    return 5"""
    ast_tree = source_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    new_source = source_to_code(new_ast)
    expected_source = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    assert expected_source == new_source

# Generated at 2022-06-23 22:52:29.074190
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import make_function, assert_equal_ignore_whitespaces
    from ..compat import ast_parse, ast_dump

    code = make_function(
        # fmt: off
        '''
        def fn():
            yield 1
            yield 2
            return 5
        ''',
        # fmt: on
    )
    node = ast_parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    compiled = ast_dump(node)
    expected = make_function(
        # fmt: off
        '''
        def fn():
            yield 1
            yield 2
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''',
        # fmt: on
    )
    assert_equal_ignore_whitespaces(expected, compiled)

# Generated at 2022-06-23 22:52:30.960284
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None)
    assert transformer.tree_changed == False


# Generated at 2022-06-23 22:52:33.223055
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformer_axt import is_valid_ast, create_module_as_string


# Generated at 2022-06-23 22:52:34.212744
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:52:41.084783
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn_compiled():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc


    def fn_to_compile():
        yield 1
        return 5


    transformer = ReturnFromGeneratorTransformer()
    fn_compiled_ast = ast.parse(fn_compiled.__code__.co_code)
    fn_to_compile_ast = ast.parse(fn_to_compile.__code__.co_code)

    transformer.visit(fn_to_compile_ast)

    assert fn_to_compile_ast == fn_compiled_ast

# Generated at 2022-06-23 22:52:46.060461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.source import source_to_node
    from .blackbox import to_source

    code = dedent('''\
        def fn():
            yield 1
            return 4
        ''')

    node = source_to_node(code)
    node = ReturnFromGeneratorTransformer(returns_list=False)(node)
    assert to_source(node).strip() == dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 4
            raise exc
        ''').strip()

# Generated at 2022-06-23 22:52:46.896721
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-23 22:52:56.124882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    import inspect
    import textwrap
    from django_python3_ldap.utils.ast_helpers import dump_ast, get_password_validation_method_def
    from django_python3_ldap.compat import IS_PY36, IS_PY37, IS_PY38

    def check_func(func_source):
        """Check source code of function after rewriting."""
        func_ast = ast.parse(textwrap.dedent(func_source))
        tree_changed, _node = ReturnFromGeneratorTransformer().visit(func_ast)
        if tree_changed:
            source = inspect.getsource(func_ast)
            func_ast = ast.fix_missing_locations(func_ast)

# Generated at 2022-06-23 22:52:58.062699
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:07.935542
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..py2to3 import get_2to3_fixers
    _2to3_fixes = get_2to3_fixers()

    def test(before, after):
        node = ast.parse(before)
        node = ReturnFromGeneratorTransformer().visit(node)
        changed = astor.to_source(node)
        assert changed == after
        return changed

    before  = """def fn():\n""".split('\n')
    after   = """def fn():\n""".split('\n')
    assert test(before, after) == after

    before  = """def fn(): return\n""".split('\n')
    after   = """def fn(): return\n""".split('\n')
    assert test(before, after) == after


# Generated at 2022-06-23 22:53:13.471320
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import check_transformer
    from ..utils.testing import visit_body

    # Test - single return
    def test_simple_return():
        def fn():
            yield 1
            return 5

    def check_simple_return(module):
        def fn():
            yield 1
            return_from_generator()

    check_transformer(test_simple_return, check_simple_return, ReturnFromGeneratorTransformer)

    # Test - return tuple
    def test_return_tuple():
        def fn():
            yield 1
            return 5, 6

    def check_return_tuple(module):
        def fn():
            yield 1
            return_from_generator()

    check_transformer(test_return_tuple, check_return_tuple, ReturnFromGeneratorTransformer)

    #

# Generated at 2022-06-23 22:53:13.959670
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:15.324784
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(None)
    assert transformer



# Generated at 2022-06-23 22:53:19.617230
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    import _ast
    from ..ast_compiler import ASTCompiler, CompilationError
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:53:27.841296
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-23 22:53:32.305871
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...utils.source_repr import source_repr

    def _assert(source: str, expected: str) -> None:
        node = ast.parse(source, mode="exec")
        ReturnFromGeneratorTransformer().visit(node)

        assert source_repr(node) == expected


# Generated at 2022-06-23 22:53:37.453184
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import transform, run

    code = transform(ReturnFromGeneratorTransformer, """
    def fn():
        yield 1
        return 5
    """)
    expected = """
    def fn():
        yield 1
        
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert code == expected

    assert run(code) == 5



# Generated at 2022-06-23 22:53:39.965895
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for ReturnFromGeneratorTransformer."""
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:41.699506
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)

# Generated at 2022-06-23 22:53:46.533540
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""
    def foo():
        yield 1
        yield 2
        return 3
        return 4
    """)
    x = ReturnFromGeneratorTransformer()
    node2 = x.visit(node)
    assert ast.dump(node) == ast.dump(node2)

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:53:47.427475
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astunparse


# Generated at 2022-06-23 22:53:56.830244
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class DummyMethod:
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return self.name

    # test for search function
    function_body = [DummyMethod('yield'), DummyMethod('return'),
                     DummyMethod('yield'), DummyMethod('return')]
    function_def = ast.FunctionDef(name='function', body=function_body)

    class DummyModule:
        def __init__(self, body):
            self.body = body

    dummy_module = DummyModule([function_def])

    expected_returns = [(function_def, function_body[i]) for i in [1, 3]]

# Generated at 2022-06-23 22:54:04.091670
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor

    code2 = """def fn():
        yield 1
        return 2
    """
    code3 = """def fn():
        return 2
    """
    tree2 = ast.parse(code2)
    tree3 = ast.parse(code3)

    # no return statement
    node_transformer = ReturnFromGeneratorTransformer()
    node_transformer.visit(getattr(tree2, 'body')[0])
    node_transformer.visit(getattr(tree3, 'body')[0])

    code = astor.to_source(tree3)
    code = astor.to_source(tree2)

# Generated at 2022-06-23 22:54:09.681310
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # false negative: ReturnFromGeneratorTransformer._find_generator_returns
    def fn():
        if 1:
            return 1
        return 2
    ass = ast.parse(fn.__code__.co_consts[1]).body[0]
    r = ReturnFromGeneratorTransformer()
    r._find_generator_returns(ass)
    assert 0, "TODO"

# Generated at 2022-06-23 22:54:18.106832
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    et = ReturnFromGeneratorTransformer()
    src = """
    def test_method(param):
        yield 0
        return 1
    """
    tree = ast.parse(src)
    et.visit(tree)
    expected_src = """
    def test_method(param):
        yield 0
        exc = StopIteration()
        exc.value = 1
        raise exc
    """
    expected_tree = ast.parse(expected_src)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:54:25.252863
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # test find_generator_returns method
    transformer = ReturnFromGeneratorTransformer()
    def check(source, expected_result):
        ast_tree = ast.parse(source)
        result = transformer._find_generator_returns(ast_tree.body[0])
        assert result == expected_result

    source = """\
        def fn():
            yield 1
            return 5
    """
    expected_result = [
        (ast.parse(source).body[0], ast.parse(source).body[0].body[1])
    ]
    check(source, expected_result)

    source = """\
        def fn():
            yield 1
            if a:
                return 5
    """

# Generated at 2022-06-23 22:54:25.711799
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
	ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:54:33.725479
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    snippet = '''
    def fn():
        yield 1
        return 2
    '''
    tree = ast.parse(snippet)
    transformer = ReturnFromGeneratorTransformer()

    assert transformer.visit(tree) is not tree

    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''
    expected_tree = ast.parse(expected)

    assert ast.dump(transformer.visit(tree), include_attributes=True) == \
        ast.dump(expected_tree, include_attributes=True)

# Generated at 2022-06-23 22:54:34.639506
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:36.200641
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer(None, None)

# Generated at 2022-06-23 22:54:40.334822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.valu = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert expected == ast.dump(tree)


# Generated at 2022-06-23 22:54:41.319790
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    g = ReturnFromGeneratorTransformer()
    assert g

# Generated at 2022-06-23 22:54:48.221443
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    transformer = ReturnFromGeneratorTransformer()

    # Python source code
    src = """\
    def gen():
        yield 1
        return 2
    """

    # Expected output
    expected = """\
    def gen():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    # Parse source code and transform it
    module = ast.parse(src)
    new_module = transformer.visit(module)  # type: ignore

    # Compare source code of transformed module and expected source code
    assert astor.to_source(new_module) == expected



# Generated at 2022-06-23 22:54:48.764028
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert False



# Generated at 2022-06-23 22:54:55.593692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    from typed_ast import ast3
    function = """
        def fn():
            yield 1
            return 5
    """
    node = ast3.parse(function).body[0]
    t = ReturnFromGeneratorTransformer()
    node = t.visit(node)
    assert ast3.dump(node) == """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    function = """
        def fn():
            yield 1
            return
    """
    node = ast3.parse(function).body[0]
    t = ReturnFromGeneratorTransformer()
    node = t.visit(node)

# Generated at 2022-06-23 22:55:07.542197
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTest
    from .base import get_example_function as E

    class Test(BaseNodeTest):
        transformer = ReturnFromGeneratorTransformer()
        target = (3, 2)
        method_name = 'visit_FunctionDef'

        def test_with_return_in_generator(self):
            def original():
                def fn():
                    yield 1
                    return 5
            def expected():
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            self.assertCodeChanged(original, expected)

        def test_with_return_in_sub_generator(self):
            def original():
                def generator():
                    def fn():
                        yield 1
                        return 5
                    yield fn()

# Generated at 2022-06-23 22:55:09.455590
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    instance = ReturnFromGeneratorTransformer()
    assert isinstance(instance, ReturnFromGeneratorTransformer)


# Generated at 2022-06-23 22:55:10.794434
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:15.747730
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert ReturnFromGeneratorTransformer.target == (3, 2)
    assert hasattr(t, '_tree_changed')
    assert not t._tree_changed
    assert hasattr(t, 'target')
    assert t.target == (3, 2)
    assert hasattr(t, 'visit_FunctionDef')


# Generated at 2022-06-23 22:55:20.131492
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().visit(ast.parse("""
    def fn():
        yield 1
        return 5
    """)) == ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

# Generated at 2022-06-23 22:55:20.897100
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:22.662279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # type: ignore
    rfgt = ReturnFromGeneratorTransformer()
    assert isinstance(rfgt, ReturnFromGeneratorTransformer)


# Generated at 2022-06-23 22:55:27.432135
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import Compiler
    from astor.code_gen import to_source
    from ..utils.mockcode import generate_function

    def _test(code):
        compiler = Compiler([ReturnFromGeneratorTransformer])
        bits = compiler.compile_bits(code)
        return to_source(bits)

    for m in range(10):
        func, check_func = generate_function(m * 4, name='fn')
        assert _test(func) == check_func

# Generated at 2022-06-23 22:55:28.328422
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:55:32.619137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import get_tree
    from ..utils.source import get_ast
    from ..utils.visitor import print_tree
    from .unittest_transformer_visitor import UnitTestTransformerVisitor

    # Arrange
    class_under_test = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:55:33.872761
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer.test_snippet(return_from_generator)

# Generated at 2022-06-23 22:55:37.618191
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)
    assert ReturnFromGeneratorTransformer.target == (3, 2)
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)
    assert hasattr(ReturnFromGeneratorTransformer(), 'visit_Module')


# Generated at 2022-06-23 22:55:45.978050
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import assert_transform
    from . import compile_to_ast

    assert_transform(
        ReturnFromGeneratorTransformer,
        r'''
        def fn():
            yield 12
            return 3
        ''',
        r'''
        def fn():
            yield 12
            exc = StopIteration()
            exc.value = 3
            raise exc
        '''
    )

    # Code which can be reduced to yield:
    assert_transform(
        ReturnFromGeneratorTransformer,
        r'''
        def fn():
            x = 1
            return x
        ''',
        r'''
        def fn():
            x = 1
            return x
        '''
    )

    # Code which don't contain `yield`

# Generated at 2022-06-23 22:55:54.987506
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import test_transform_module
    from ..utils import pretty_ast
    from . import transformer_registry
    from .unwrap_exceptions import UnwrapExceptionsTransformer

    transformer_registry.register(UnwrapExceptionsTransformer)
    transformer_registry.register(ReturnFromGeneratorTransformer)

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformed_module = test_transform_module(source, [UnwrapExceptionsTransformer, ReturnFromGeneratorTransformer])
    assert pretty_ast(transformed_module) == expected

# Generated at 2022-06-23 22:55:56.714938
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = '''
    def fn():
        yield 1
        return 5
    '''

# Generated at 2022-06-23 22:56:01.301792
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('def fn():\n    yield 1\n    return 5')
    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(node)
    assert ast.dump(node) == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

# Generated at 2022-06-23 22:56:09.814116
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .regression import before_method, after_method
    from .base import BaseNodeTest
    
    class Test(BaseNodeTest):
        target_version = (3, 2)
        transformer = ReturnFromGeneratorTransformer()
        
        def test_method_a(self):
            before = before_method(self)
            after = after_method(self)
            
            self.assertEqual(self.transformer.visit(before), after)
            self.assertEqual(self.transformer.visit(before), self.transformer.visit(after))
            self.assertNotEqual(self.transformer.visit(before), before)
            self.assertNotEqual(self.transformer.visit(after), after)
            self.assertTrue(self.transformer.tree_changed)
        


# Generated at 2022-06-23 22:56:14.715164
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import assert_node_equal
    import ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    assert_node_equal(ReturnFromGeneratorTransformer().visit(ast.parse(code)), expected)

# Generated at 2022-06-23 22:56:17.319544
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:27.819824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_function_transformed(function, check_function):
        fn = ast.parse(function).body[0]  # type: ast.FunctionDef
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(fn)
        assert check_function == astor.to_source(fn)

    # Test for case where function contains return in generator
    assert_function_transformed(
        """
        def fn():
            yield 1
            return 5""",
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    # Test for case where function contains return in generator with if statements

# Generated at 2022-06-23 22:56:28.471063
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:38.131620
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import expect
    from typed_ast import ast3 as ast
    from ast_tools.transformers.typed_ast import TypedAstTransformer

# Generated at 2022-06-23 22:56:45.722718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        _find_generator_returns = lambda x, y: [('parent', 'return')]
        _replace_return = lambda x, y, z: None
        generic_visit = lambda x, y: y
    node = ast.FunctionDef('f', None, [], [], None, [])
    transformer = MockReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(node)
    assert transformer._tree_changed


# Generated at 2022-06-23 22:56:52.168760
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Just to keep mypy happy
    from typing import Callable
    from .transformer import Transformer
    from .unpacking_transformer import UnpackingTransformer
    from .patched_typed_ast import module
    from ...utils import codegen
    from ...tests.test_utils import assert_transformed_code_equals

    code = """
        def fn():
            yield 1
            return 5
    """
    if Transformer.is_target(3, 6):
        code += """
            def fn2():
                yield from [1, 2, 3]
                return 5
        """
    else:
        code += """
            def fn2():
                for i in [1, 2, 3]:
                    yield i
                return 5
        """

    tree = module.parse(code)

    # Just for mypy
   

# Generated at 2022-06-23 22:57:01.389627
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Function with no returns
    expected = ast.parse("""def fn():
    yield 1""")

    result = ast.parse("""def fn():
    yield 1""")
    ReturnFromGeneratorTransformer().visit(result)
    assert result == expected

    # Function with one return
    expected = ast.parse("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc""")

    result = ast.parse("""def fn():
    yield 1
    return 2""")
    ReturnFromGeneratorTransformer().visit(result)
    assert result == expected

    # Function with two returns

# Generated at 2022-06-23 22:57:08.887611
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    # Case: one generator return
    node_1 = ast.parse('''
    a = 5
    def fn():
        yield 1
        return 5
    ''')
    expected_node_1 = ast.parse('''
    a = 5
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert transformer.visit(node_1) == expected_node_1

    # Case: one return
    node_2 = ast.parse('''
    a = 5
    def fn():
        return 5
    ''')
    expected_node_2 = ast.parse('''
    a = 5
    def fn():
        return 5
    ''')

# Generated at 2022-06-23 22:57:12.132591
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)


# Generated at 2022-06-23 22:57:21.670829
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def run_test(func_source, expected_code):
        func_ast = ast.parse(func_source).body[0]  # type: ignore
        transformer = ReturnFromGeneratorTransformer()
        new_func_ast = transformer.visit(func_ast)  # type: ignore
        assert ast.dump(new_func_ast) == expected_code


# Generated at 2022-06-23 22:57:28.958513
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = '''
        def fn():
            yield 1
            return 1
    '''

    expected_source = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
    '''

    mod = ast.parse(source)
    new_mod = ReturnFromGeneratorTransformer.run(mod)

    assert ast.dump(new_mod) == ast.dump(ast.parse(expected_source))

# Test case for ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:57:30.562117
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer

# Generated at 2022-06-23 22:57:41.793201
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform_and_compare
    from .test_base import test_block_statement_ast

    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def __init__(self, tree: ast.AST):
            self._tree_changed = False
            self._current_node = tree
            self._visit(tree)


# Generated at 2022-06-23 22:57:47.734366
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

    @return_from_generator_transformer.transform
    def function_with_no_generator():
        return 1

    @return_from_generator_transformer.transform
    def function_with_generator():
        """Generator with one yield statement and one return statement."""
        yield 1
        return 2

    fn0 = function_with_no_generator()
    fn1 = function_with_generator()

    gen = fn0()
    with pytest.raises(StopIteration):
        next(gen)

    gen = fn1()
    assert next(gen) == 1
    with pytest.raises(StopIteration):
        next(gen)

# Generated at 2022-06-23 22:57:59.338774
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tests.fake_ast import fake_ast, FunctionDef
    from ..utils.tests.fake_ast import Assign, AssignTarget, AssignValue, AssignType
    from ..utils.tests.fake_ast import Raise, RaiseType, RaiseValue, RaiseExc
    from ..utils.tests.fake_ast import Name, NameID, NameCtx
    from ..utils.tests.fake_ast import Expr, Str

    def check_node(node):
        assert isinstance(node, FunctionDef)
        assert isinstance(node.body[1], Assign)
        assert isinstance(node.body[1].targets[0], AssignTarget)
        assert isinstance(node.body[1].targets[0].value, Name)

# Generated at 2022-06-23 22:58:08.597619
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    with let(node) as node:
        node.body = [
            ast.Yield(value=ast.Constant(value=1))
        ]
        node.args = ast.arguments(args=[], defaults=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
                                  annotations={})
        node.returns = None
        node.decorator_list = []

    with let(transformer) as transformer:
        transformer = ReturnFromGeneratorTransformer()

    result = transformer.visit_FunctionDef(node)

    assert isinstance(result.body, list)
    assert len(result.body) == 4
    assert isinstance(result.body[0], ast.Yield)
    assert isinstance(result.body[1], ast.Assign)

# Generated at 2022-06-23 22:58:10.190312
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    """Test 1"""


# Generated at 2022-06-23 22:58:17.493390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast

    fn = """
    def fn():
        yield 1
        return 5
    """

    # Test if the constructor raises no exception
    ReturnFromGeneratorTransformer()

    tree = ast.parse(fn)
    tree = ReturnFromGeneratorTransformer().visit(tree)

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:58:18.453578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:26.762817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source_helpers import source_from_snippet
    from ..parser import parse_source

    snippet1 = """
    def fn():
        yield 1
        return 5
    """
    expected1 = """
    def fn():
        yield 1
        exc = StopIteration
        exc.value = 5
        raise exc
    """

    snippet2 = """
    def fn():
        def sub():
            yield 1
            return 5
        return 6
    """
    expected2 = """
    def fn():
        def sub():
            yield 1
            exc = StopIteration
            exc.value = 5
            raise exc
        return 6
    """

    snippet3 = """
    def fn():
        def sub():
            yield 1
            return 5

        yield 2
        return 6
    """
    expected3