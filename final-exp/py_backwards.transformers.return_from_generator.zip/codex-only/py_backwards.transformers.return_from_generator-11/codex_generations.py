

# Generated at 2022-06-23 22:48:21.739086
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with pytest.raises(TypeError):
        ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:48:31.303552
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def get_function_body(node):
        return [line for line in node.body if not isinstance(line, ast.Expr)]

    def test_return_from_generator(func_name: str, args: Tuple[str], expected: str):
        code = f'def {func_name}({", ".join(args)}):\n'\
               f'        yield 1\n'\
               f'        return 5\n'
        tree = ast.parse(code)

        node = tree.body[0]
        assert isinstance(node, ast.FunctionDef)
        assert node.name == func_name

        body = get_function_body(node)
        assert len(body) == 2
        assert isinstance(body[0], ast.Expr)

# Generated at 2022-06-23 22:48:32.182445
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()



# Generated at 2022-06-23 22:48:33.777501
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-23 22:48:34.618244
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor


# Generated at 2022-06-23 22:48:38.182398
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef, Return, Yield, Load, Name
    from typed_ast.ast3 import parse as parse3
    from ..utils import check_equal

# Generated at 2022-06-23 22:48:43.843794
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 2
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    result = ast.unparse(node)
    assert result == expected

# Generated at 2022-06-23 22:48:50.489772
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    original_code = """
        def f():
            for n in range(4):
                yield n
            return 123
    """
    expected_code = """
        def f():
            for n in range(4):
                yield n
            exc = StopIteration()
            exc.value = 123
            raise exc
    """
    assert ReturnFromGeneratorTransformer().visit(ast.parse(original_code)) == ast.parse(expected_code)


# Generated at 2022-06-23 22:48:57.845096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(
        """
        def generator_fn(arg):
            if arg > 0:
                yield 1
                return 5
            if arg == 0:
                yield 2
        """
    ).body[0]

    expected = ast.parse(
        """
        def generator_fn(arg):
            if arg > 0:
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            if arg == 0:
                yield 2
        """
    ).body[0]

    assert transformer.visit(node) == expected



# Generated at 2022-06-23 22:49:07.969483
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer(None)

    class AssignNode:
        def __init__(self, value_: ast.Expr) -> None:
            self.value = value_  # type: ignore
    node = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            posonlyargs=[],
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[
            ast.Expr(ast.Yield(ast.Num(1))),
            ast.Return(ast.Num(5)),
        ],
        decorator_list=[],
        returns=None,
    )


# Generated at 2022-06-23 22:49:16.471568
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from .automatransformer import AutoTransformer
    from .removecomments import RemoveCommentsTransformer
    from .removeprintstmts import RemovePrintStmtsTransformer
    from .astunparse import Unparser
    from ..utils.typed_astunparse import TypedUnparser

    source = (
        "async def f():\n"
        "    yield 1\n"
        "    return 2\n"
    )
    base = BaseNodeTransformer()

    transformer = AutoTransformer()
    transformer.add_transformer(ReturnFromGeneratorTransformer)
    transformer.add_transformer(RemoveCommentsTransformer)
    transformer.add_transformer(RemovePrintStmtsTransformer)

# Generated at 2022-06-23 22:49:18.235530
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert x is not None


# Generated at 2022-06-23 22:49:22.537081
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer, 'visit_FunctionDef')
    assert hasattr(ReturnFromGeneratorTransformer, 'visit')
    assert hasattr(ReturnFromGeneratorTransformer, 'generic_visit')
    o = ReturnFromGeneratorTransformer()


# Generated at 2022-06-23 22:49:29.243700
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    g = ReturnFromGeneratorTransformer()
    assert g._find_generator_returns(ast.parse('''
    def fn():
        yield 1
        return 3
    ''').body[0]) == []
    assert g._find_generator_returns(ast.parse('''
    def fn():
        yield 1
    ''').body[0]) == []
    assert len(g._find_generator_returns(ast.parse('''
    def fn():
        yield 1
        return 3
    ''').body[0])) == 1
    assert len(g._find_generator_returns(ast.parse('''
    def fn():
        yield 1
        return 3
        return 3
    ''').body[0])) == 2

# Generated at 2022-06-23 22:49:30.669551
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t is not None


# Generated at 2022-06-23 22:49:38.498226
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse, render

    node = parse("""
        def fn():
            yield 1
            return 5
        def fn2():
            yield 1
            yield 2
        def fn3():
            yield 1
            return
    """)

    assert render(ReturnFromGeneratorTransformer().visit(node)) == \
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def fn2():
            yield 1
            yield 2
        def fn3():
            yield 1
            return
    """

# Generated at 2022-06-23 22:49:39.531440
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:40.578716
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:42.408923
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer."""
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:49:51.342551
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:49:58.017095
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def test_function(a):
        if a:
            yield 1
            return 5
        return 4

    expected_function = test_function

    node = ast.parse(snippet.getsource(test_function)).body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    actual_function = compile(node, "<string>", "exec")

    assert expected_function.__code__ == actual_function.__code__

# Generated at 2022-06-23 22:50:08.023338
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    return_test = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    assert transformer._find_generator_returns(return_test.body[0]) ==\
        [(return_test.body[0], return_test.body[0].body[1])]

    return_test = ast.parse('''
        def fn():
            return 5
    ''')
    assert transformer._find_generator_returns(return_test.body[0]) == []

    return_test = ast.parse('''
        def fn():
            5
            return 5
    ''')
    assert transformer._find_generator_returns(return_test.body[0]) == []


# Generated at 2022-06-23 22:50:16.023220
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Tests that the visitor replaces all `return` expressions in generator functions
    with assignment to StopIteration exception.
    """
    source = """
        def foo():
            yield 1
            return 2
            
        def bar():
            yield 1
            return
            
        def baz():
            yield 1
            return 2
            return 3
    """
    expected = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
            
        def bar():
            yield 1
            exc = StopIteration()
            exc.value = None
            raise exc
            
        def baz():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
            return 3
    """

# Generated at 2022-06-23 22:50:17.208234
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfg = ReturnFromGeneratorTransformer()
    assert rfg is not None


# Generated at 2022-06-23 22:50:22.496371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:50:32.800951
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def clean_source(src):
        return '\n'.join(l.strip() for l in src.split('\n'))

    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer):
        @classmethod
        def _get_node(cls, src):
            src = 'def func():\n' + src
            return ast.parse(clean_source(src))

        @classmethod
        def _apply_transform(cls, src):
            node = cls._get_node(src)
            cls.visit(node)
            return clean_source(node.body[0].body[0].value.func.id)

    def test_it_should_transform_return_in_generator():
        assert 'return_from_generator' == \
               ReturnFromGeneratorTransformerTest._

# Generated at 2022-06-23 22:50:38.933276
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        for x in range(1):
            yield x
            return 20
    a = ReturnFromGeneratorTransformer()
    res = a.visit(ast.parse(fn.__code__))
    # print(astor.to_source(res))
    assert(astor.to_source(res) == 'def fn():\n    for x in range(1):\n        yield x\n        exc = StopIteration()\n        exc.value = 20\n        raise exc\n')


# Generated at 2022-06-23 22:50:40.254717
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer

# Generated at 2022-06-23 22:50:48.349254
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...transpile import get_ast
    from ...utils.testing import assert_ast

    class Test(object):
        def foo():
            yield 1
            return 2

        def bar():
            return 2

        def baz():
            yield 1
            return 2

    a, = get_ast(Test)

    assert_ast(
        ReturnFromGeneratorTransformer().visit(a),
        """
        class Test():
            def foo():
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc

            def bar():
                return 2

            def baz():
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc
        """
    )


# Generated at 2022-06-23 22:50:50.614135
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:50:53.093013
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(before: str, after: str):
        before = ast.parse(before)

        after = ast.parse(after)  # type: ignore
        assert ReturnFromGeneratorTransformer().visit(before) == after  # type: ignore


# Generated at 2022-06-23 22:50:55.189109
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # type: ignore
    """Test constructor of class ReturnFromGeneratorTransformer."""
    assert isinstance(ReturnFromGeneratorTransformer(), ReturnFromGeneratorTransformer)



# Generated at 2022-06-23 22:51:01.861726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astunparse import dump
    from ..utils.tree_visitor import visit_ast

    tree = ast.parse("""
    def f1(a):
        for i in range(a):
            yield i
        return a
    
    def f2(a):
        for i in range(a):
            yield i
        return 3
    
    def f3(b):
        if b:
            yield 1
        return 5
    """)

    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.count = 0

        def visit_FunctionDef(self, node):
            self.count += 1

# Generated at 2022-06-23 22:51:10.996574
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    for version in (3, 2):
        for ctx in (ast.AugStore, ast.Store, ast.Del):
            transformer = ReturnFromGeneratorTransformer(version, ctx)
            transformer.visit(ast.parse("""
                def fn(a):
                    yield a
                    return 1
                """))
            transformer.visit(ast.parse("""
                def fn(a):
                    yield a
                    yield 1
                    return 1
                """))
            transformer.visit(ast.parse("""
                def fn():
                    return 1
                """))
            transformer.visit(ast.parse("""
                def fn():
                    if True:
                        return 1
                """))


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:51:20.557530
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .transformer import _compile_to_ast
    from .transformer import _dump_ast
    from ..utils.ast_node_type import ASTNodeType
    import astor

    src = """
    def fn():
        yield 1
        return 5
    """

    tree = _compile_to_ast(src, ASTNodeType.FunctionDef)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    src_transformed = _dump_ast(transformer._new_tree)

    expected_src = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert astor.to_source(expected_src) == src_transformed

# Generated at 2022-06-23 22:51:30.971811
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def generator():
        yield 1
        return 2
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:51:31.741745
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:51:32.741136
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:51:37.272974
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer"""
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'
    assert ReturnFromGeneratorTransformer.__doc__ == """Compiles return in generators like:
        def fn():
            yield 1
            return 5
    To:
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """


# Generated at 2022-06-23 22:51:39.258203
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)



# Generated at 2022-06-23 22:51:46.065798
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # The input code for this unit test
    INPUT = """
        def fn():
            yield 1
            return 5
    """

    # The expected output from this unit test
    EXPECTED = """
        def fn():
            yield 1
            exc = StopIteration()
    """

    # Perform the unit test
    node = ast.parse(INPUT)
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    actual = astor.to_source(node)

    # Perform the unit test
    assert actual == EXPECTED



# Generated at 2022-06-23 22:51:56.601683
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformerTest(ReturnFromGeneratorTransformer):
        def visit_FunctionDef(self, node):
            pass

    snippet1 = """
    def foo():
        yield 1
        return 2

    def bar():
        yield 1
        return 2
    """
    snippet2 = """
    def foo():
        yield 1

    def bar():
        yield 1
    """

    expected1 = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc

    def bar():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    expected2 = """
    def foo():
        yield 1

    def bar():
        yield 1
    """


# Generated at 2022-06-23 22:51:59.575694
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for python_version in [(3, 2), (3, 3)]:
        if sys.version_info[:2] < python_version:
            break


# Generated at 2022-06-23 22:52:07.395019
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import ast
    from ..utils.source import source

    def assert_no_change(src):
        source_ast = ast.parse(src)
        new_ast = ReturnFromGeneratorTransformer().visit(source_ast)
        assert not ReturnFromGeneratorTransformer._tree_changed
        assert ast.dump(source_ast) == ast.dump(new_ast)

    @source
    def generator_function():
        def fn():
            yield True
            return 1

    assert_no_change(generator_function)

    @source
    def no_yield():
        def fn():
            return 1

    assert_no_change(no_yield)

    @source
    def in_function_in_function_with_yield():
        def fn():
            def fn2():
                yield True
                return 1

# Generated at 2022-06-23 22:52:17.007570
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def fn():
        yield 1
        return 2

    @snippet
    def fn2():
        yield 1
        return 2

    units = [fn, fn2]

    transformer = ReturnFromGeneratorTransformer()
    for unit in units:
        unit = transformer.visit(ast.parse(fn))
        assert transformer._tree_changed == True

    @snippet
    def fn():
        yield 1
        return 2

    @snippet
    def fn2():
        return 2

    units = [fn, fn2]

    transformer = ReturnFromGeneratorTransformer()
    for unit in units:
        unit = transformer.visit(ast.parse(fn))
        assert transformer._tree_changed == True

# Generated at 2022-06-23 22:52:27.673468
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.test_utils import source_to_ast, source_to_code
    from ..utils import pformat_ast, pformat_code, pformat_code_min
    from ..utils.tree_manipulation import ast_or_node

    ast2 = source_to_ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )

    generator_return_transformer = ReturnFromGeneratorTransformer({})
    assert isinstance(generator_return_transformer, BaseNodeTransformer)
    assert generator_return_transformer.DEFAULT_DEBUG is False

    # Act
    ast2_transformed = generator_return_transformer.visit(ast2)
    code2_transformed = source_to_code(ast2_transformed)

    # Assert

# Generated at 2022-06-23 22:52:34.984519
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import code_snippet
    code = code_snippet(
        '''
        def fn():
            yield 1
            return 5
        '''
    )
    result = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    node = ast.parse(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    generated_code = compile(node, '', 'exec')
    exec(generated_code)

# Generated at 2022-06-23 22:52:40.933495
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """
    expected_result = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == expected_result



# Generated at 2022-06-23 22:52:41.894077
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-23 22:52:47.808492
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    # with self._find_generator_returns(node) as generator_returns:
    #     if generator_returns:
    #         self._tree_changed = True
    #
    #     for parent, return_ in generator_returns:
    #         self._replace_return(parent, return_)

    def fn():
        yield 1
        return 5

    node = ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(fn)))
    assert inspect.getsource(fn) == inspect.getsource(compile(node, '', 'exec'))

    def fn():
        if 1:
            yield 1
        return 5

    node = ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(fn)))

# Generated at 2022-06-23 22:52:56.500741
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(func_def, expected_return_indexes):
        fn_body = ast.parse(func_def, mode="exec").body[0].body

        to_check = [(fn_body, x) for x in fn_body]  # type: ignore
        returns = []
        while to_check:
            parent, current = to_check.pop()

            if isinstance(current, ast.FunctionDef):
                continue
            elif hasattr(current, 'value'):
                to_check.append((current, current.value))  # type: ignore
            elif hasattr(current, 'body') and isinstance(current.body, list):  # type: ignore
                to_check.extend([(parent, x) for x in current.body])  # type: ignore


# Generated at 2022-06-23 22:52:58.777278
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .functional_transformer import TransformerScheduler

# Generated at 2022-06-23 22:53:08.508137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    """
    # Test data
    filenames=['./test_source_code/test_source_for_unit_test_find_rewrite_return_from_generator.py']

    # Unit test execution
    my_transformer = ReturnFromGeneratorTransformer()
    for filename in filenames:
        with open(filename) as fd:
            ast_tree = ast.parse(fd.read(), filename=filename)
        print("AST before transformation", ast.dump(ast_tree))
        result = my_transformer.visit(ast_tree)
        print("AST after transformation", ast.dump(result))


# Main test execution

# Generated at 2022-06-23 22:53:14.902384
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from .base import BaseNodeTransformerTest


# Generated at 2022-06-23 22:53:25.814414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for src in [
            """
            def fn():
                yield 1
                return 5
            """,
            """
            def fn():
                yield from range(5)
                return 10
            """,
            """
            def fn():
                yield from range(3)
                if 5 > 3:
                    return 20
            """,
            """
            def fn():
                for x in range(10):
                    yield x
                    if x == 3:
                        return 20
            """,
            """
            def fn():
                class A:
                    def fn(self):
                        yield 1
                        return 20
            """,
    ]:
        tree = ast.parse(src)
        node_transformer = ReturnFromGeneratorTransformer()
        tree = node_transformer.visit(tree)

# Generated at 2022-06-23 22:53:36.174005
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def fn():
        yield 1
        return 2

    @snippet
    def fn_with_yield_from_for_return():
        yield from (1, 2, 3)
        return 4

    @snippet
    def fn_with_nested_return():
        if True:
            return 1

    @snippet
    def fn_without_yield():
        return 1

    @snippet
    def fn_with_return_from_if_expression():
        yield 1

        if True:
            a = yield 2
            return 3
        else:
            return 4

    @snippet
    def fn_with_return_from_if_expression_and_variable_insertion():
        yield 1

        if True:
            a = yield 2
            return 3
       

# Generated at 2022-06-23 22:53:46.752127
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # With simple example
    tree = ast.parse('''
            def fn():
                yield 1
                return 5
        ''')
    expected_tree = ast.parse('''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        ''')

    transformer = ReturnFromGeneratorTransformer()

    assert transformer.visit(tree) == expected_tree

    # With complex example
    tree = ast.parse('''
            def fn():
                if False:
                    yield 1
                else:
                    yield 2
                if True:
                    yield 3
                else:
                    return 5
        ''')

# Generated at 2022-06-23 22:53:47.409558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:53:52.330767
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # type: () -> None
    transformer = ReturnFromGeneratorTransformer()

    # Type error should be raised if target is not supported
    with pytest.raises(TypeError):
        transformer.target = "foo"

    # `target` should be frozen after transformation
    transformer.target = (1, 2)
    with pytest.raises(AttributeError):
        transformer.target = (1, 2)



# Generated at 2022-06-23 22:54:01.841193
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.test_utils import update_test_params
    from .utils import compile_snippet
    from .generator import GeneratorTransformer
    from .use_awaitable import UseAwaitableTransformer
    from .yield_from import YieldFromTransformer

    transformer_list = [
        ReturnFromGeneratorTransformer,
        GeneratorTransformer,
        UseAwaitableTransformer,
        YieldFromTransformer,
    ]

    code = '''
        def fn():
            yield 1
            return 5
    '''
    expected = '''
        @typing.coroutine
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    compile_snippet(code, transformer_list, expected)
    update_test_params

# Generated at 2022-06-23 22:54:08.313606
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(
        """def fn():
            yield 1
            return 5
        """
    )
    transformer = ReturnFromGeneratorTransformer()
    ast_2 = transformer.visit(node)
    target = ast.parse(
        """def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    assert ast.dump(ast_2) == ast.dump(target)

# Generated at 2022-06-23 22:54:13.509888
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(expected_code, source_code):
        transformer = ReturnFromGeneratorTransformer()
        tree = ast.parse(source_code.strip())
        tree = transformer.visit(tree)
        assert expected_code.strip() == ast.unparse(tree).strip()

    test(
        'def a():\n    yield 1',
        'def a():\n    yield 1\n'
    )
    test(
        'def a():\n    yield 1\n    return 1',
        'def a():\n    yield 1\n    return 1\n'
    )

# Generated at 2022-06-23 22:54:19.698768
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().visit(ast.parse('\n'.join([
        "def foo():",
        "    yield 1",
        "    return 5",
    ]))) == ast.parse('\n'.join([
        "def foo():",
        "    yield 1",
        "    exc = StopIteration()",
        "    exc.value = 5",
        "    raise exc"
    ]))

# Generated at 2022-06-23 22:54:24.876797
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    R = ReturnFromGeneratorTransformer()
    assert R._find_generator_returns == R.__class__._find_generator_returns
    assert R._replace_return == R.__class__._replace_return
    assert R.visit_FunctionDef == R.__class__.visit_FunctionDef

# Generated at 2022-06-23 22:54:35.335756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def run_test(source, expected):
        tree = ast.parse(source)
        transformed = ReturnFromGeneratorTransformer().visit(tree)
        assert ast.dump(transformed, annotate_fields=False) == expected

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    run_test(source, expected)

    source = """
        def fn():
            if True:
                return 5
    """
    expected = """
        def fn():
            if True:
                return 5
    """
    run_test(source, expected)

    source = """
        def fn():
            if True:
                yield 5
    """


# Generated at 2022-06-23 22:54:44.097972
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Temp:
        def __init__(self):
            self.has_yield = False
            self.returns = []
            self.to_check = []
        def _find_generator_returns(self, node: ast.FunctionDef) \
                -> List[Tuple[ast.stmt, ast.Return]]:
            while self.to_check:
                parent, current = self.to_check.pop()

                if isinstance(current, ast.FunctionDef):
                    continue
                elif hasattr(current, 'value'):
                    self.to_check.append((current, current.value))  # type: ignore

# Generated at 2022-06-23 22:54:45.374787
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test the constructor of the class ReturnFromGeneratorTransformer."""

# Generated at 2022-06-23 22:54:45.815326
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  pass

# Generated at 2022-06-23 22:54:48.119808
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-23 22:54:48.566803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:50.473178
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests import test_compile_tree as tct
    from typed_astunparse import unparse as unp

    # Test code

# Generated at 2022-06-23 22:54:52.343562
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import cmp_ast
    from .. import parse


# Generated at 2022-06-23 22:54:53.382330
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:54:54.445155
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:54:59.712462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    transformer = ReturnFromGeneratorTransformer(version=(3, 2))

    def test_this(code):
        node = ast.parse(code)
        transformed = transformer.visit(node)
        return astor.to_source(transformed)


# Generated at 2022-06-23 22:55:08.322183
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
        import inspect
        def fn():
            yield 1
            if inspect.stack()[0][3] == 'fn':
                if inspect.stack()[0][3] == 'fn':
                    return 5
    ''')  # noqa

    ReturnFromGeneratorTransformer().visit(node)

    assert ast.dump(node) == textwrap.dedent('''
        import inspect
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''').strip()



# Generated at 2022-06-23 22:55:15.218907
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .util import source_to_ast, source_to_code
    transpiler = ReturnFromGeneratorTransformer()
    source = r'''
    def fn():
        yield 1
        return 2
    '''
    tree = source_to_ast(source)
    new_tree = transpiler.visit(tree)
    assert source_to_code(new_tree) == r'''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''

# Generated at 2022-06-23 22:55:16.236006
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-23 22:55:24.316372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source_code = """def fn():
        yield 1
        return 5
    """

    test_node = ast.parse(source_code)
    ReturnFromGeneratorTransformer().visit(test_node)

# Generated at 2022-06-23 22:55:34.373625
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def check_transform(code: str, expected: str) -> None:
        node = ast.parse(code)
        new_node = ReturnFromGeneratorTransformer().visit(node)
        new_code = ast.unparse(new_node)
        assert new_code == expected


# Generated at 2022-06-23 22:55:43.001341
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import as_ast_node

    def test(node: ast.AST, expected: ast.AST) -> None:
        transformer = ReturnFromGeneratorTransformer()
        result = transformer.visit(node)
        assert result == expected
        assert transformer.tree_changed is transformer.modified

    test(
        as_ast_node('''
            def fn1():
                yield 1
                yield 2
                if True:
                    return 3
                yield 4
            '''),
        as_ast_node('''
            def fn1():
                yield 1
                yield 2
                if True:
                    exc = StopIteration()
                    exc.value = 3
                    raise exc
                yield 4
            ''')
    )


# Generated at 2022-06-23 22:55:50.265549
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compat import to_tuple
    from . import transform
    from .common import UNPYTHONIC_TEST_MODULES

    for m in UNPYTHONIC_TEST_MODULES:
        module = transform(m)
        for node in module.body:
            if isinstance(node, ast.FunctionDef):
                for parent, return_ in ReturnFromGeneratorTransformer()._find_generator_returns(node):
                    # Find last line
                    last_line = None
                    current = parent
                    while not last_line:
                        if not isinstance(current, ast.FunctionDef):
                            last_line = current
                        current = current.body[-1]

                    assert isinstance(last_line, ast.Raise)

                    return_val = last_line.exc.value.value

# Generated at 2022-06-23 22:55:53.039465
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    generator_return = ReturnFromGeneratorTransformer()
    assert issubclass(generator_return.__class__, BaseNodeTransformer)

# Generated at 2022-06-23 22:56:00.950565
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import unittest
    import astor
    """
    Unit test for constructor of class ReturnFromGeneratorTransformer

    Args:
        unittest (): UnitTest module

    """
    class TestContext(unittest.TestCase):
        """
        Test for constructor of class ReturnFromGeneratorTransformer
        """
        def test_factory(self):
            """
            Test for constructor of class ReturnFromGeneratorTransformer

            Args:

            Returns:

            """
            self.assertTrue(hasattr(ReturnFromGeneratorTransformer, 'visit_FunctionDef'))

    unittest.main()

# Generated at 2022-06-23 22:56:06.614356
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    test_tree = ast.parse("""
        def fn():
            yield 1
            return 5
        """)

    expected_tree = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(test_tree)
    assert ast.dump(node) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:56:16.899804
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('def foo():\n    yield 1; return 5')
    ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-23 22:56:18.125150
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:56:21.098532
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class SampleReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def visit_FunctionDef(self, node):
            return node


# Generated at 2022-06-23 22:56:29.807348
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compile import compile_
    from astmonkey import transformers
    fn = lambda: g()
    compiled = compile_(fn, 'fn.py', 'exec')
    code = compiled.code  # type: ignore
    assert code.co_flags & inspect.CO_GENERATOR != 0

    tree = ast.parse(code.co_consts[0])  # type: ignore

    transformers.ParentNodeTransformer().visit(tree)
    transformers.LocalizationTransformer().visit(tree)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    expected = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n'
    actual = ast.unparse(transformer.tree)


# Generated at 2022-06-23 22:56:36.288842
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = parse(textwrap.dedent(
        """
        def fn():
            yield 1
            return 2
    """
    ))

    expected_tree = parse(textwrap.dedent(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    ))

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert equals(expected_tree, tree)



# Generated at 2022-06-23 22:56:47.185566
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Testcase 1:
    # Simple function
    # def fn():
    #     return 42
    node = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Return(
                value=ast.Constant(value=42)
            )
        ],
        decorator_list=[],
        returns=None
    )

    # Expected result is:
    # def fn():
    #     return 42

# Generated at 2022-06-23 22:56:50.522403
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    def check(code_in: str, code_out: str) -> None:
        tree_in = ast.parse(code_in)
        tree_out = ast.parse(code_out)
        transformer.visit(tree_in)
        assert ast.dump(tree_in) == ast.dump(tree_out)

    # find generator returns

# Generated at 2022-06-23 22:56:51.444576
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:56:54.126817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print("test_ReturnFromGeneratorTransformer_visit_FunctionDef")

# Generated at 2022-06-23 22:57:03.100125
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def compare_ast(ast1, ast2):
        assert ast.dump(ast1) == ast.dump(ast2)

    def transform_code(text):
        tree = ast.parse(text)
        ReturnFromGeneratorTransformer().visit(tree)
        return tree

    def compile_ast(ast):
        return compile(ast, '<test>', 'exec')

    # simple generator with one return
    test_code = textwrap.dedent('''
        def fn():
            a = 1
            yield a
            return a
    '''.format())
    expected_code = textwrap.dedent('''
        def fn():
            a = 1
            yield a
            exc = StopIteration()
            exc.value = a
            raise exc
    '''.format())

# Generated at 2022-06-23 22:57:12.373831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Given a FunctionDef node with generator yield,
    source = """
        def fn():
            yield 1
            return 5
    """
    node = ast.parse(source)
    node = node.body[0]  # type: ignore

    # When I visit this node with ReturnFromGeneratorTransformer transformer,
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    # Then the node is modified to make sure it raises StopIteration correctly
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_node = ast.parse(expected_source)
    expected_node = expected_node.body[0]  # type: ignore

    assert_equal_ast(node, expected_node)

# Generated at 2022-06-23 22:57:18.442949
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    input = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    output = ReturnFromGeneratorTransformer().visit(ast.parse(input))
    assert ast.dump(ast.parse(expected)) == ast.dump(output)



# Generated at 2022-06-23 22:57:21.521474
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing.utils import make_dummy_fn, round_trip, to_source
    from ..utils import indent


# Generated at 2022-06-23 22:57:31.494936
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        def test_compiles_returns_in_generators(self):
            def fn():
                yield 1
                return 2

            expected = """\
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc
            """  # noqa: E501

            self._test(fn, expected)

        def test_skips_non_generators(self):
            def fn():
                return 1

            expected = """\
            def fn():
                return 1
            """  # noqa: E501

            self._test(fn, expected)

        def _test(self, test_fn, expected):
            tree = ast.parse(dedent(inspect.getsource(test_fn)))
            tree = ReturnFromGeneratorTrans

# Generated at 2022-06-23 22:57:42.794327
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(ast.parse(
        """def fn():
            yield 1
            if True:
                return 5
            else:
                def fn():
                    yield 1
                    return 5
                return 10"""))
    expected = ast.parse(
        """def fn():
            yield 1
            if True:
                exc = StopIteration()
                exc.value = 5
                raise exc
            else:
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                return 10""")
    assert ast.dump(tree) == ast.dump(expected)
    tree = transformer.visit(ast.parse(
        """def fn():
            yield 1
            return 5"""))

# Generated at 2022-06-23 22:57:50.025961
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    code = "def fn():\n\tyield 1\n\treturn 5\n"
    expected_code = "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n"
    module = ast.parse(code)
    tree_changed = False
    transformer = ReturnFromGeneratorTransformer()

    new_module = transformer.visit(node=module)
    tree_changed = transformer.tree_changed()

    assert expected_code == astunparse.unparse(new_module)
    assert tree_changed == True


# Generated at 2022-06-23 22:58:01.093509
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse
    from .base import BaseNodeTransformer
    from .. import utils

    class MockNodeTransformer(BaseNodeTransformer):
        pass

    class MockFunctionDef(utils.MockASTNode):
        def __init__(self, body, **kwargs):
            utils.MockASTNode.__init__(self, **kwargs)
            self.body = body

    class MockReturn(utils.MockASTNode):
        def __init__(self, value, **kwargs):
            utils.MockASTNode.__init__(self, **kwargs)
            self.value = value

    class MockIf(utils.MockASTNode):
        def __init__(self, body, **kwargs):
            utils.MockASTNode.__init__(self, **kwargs)


# Generated at 2022-06-23 22:58:02.090547
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-23 22:58:10.522510
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse


# Generated at 2022-06-23 22:58:18.262834
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    # Arrange
    code = """def fn():\n    yield 1\n    return 5"""
    t = ReturnFromGeneratorTransformer()
    # Act
    res = t.visit(ast.parse(code))
    # Assert
    expected = """def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n"""
    assert ast.dump(res) == expected

# Generated at 2022-06-23 22:58:19.220970
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-23 22:58:24.924060
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import CompilerTestCase
    from .test_main import main

    class Test(CompilerTestCase):
        def test_return_in_generator(self):
            self.assert_compilation(
                self.create_test_target(main, """
                    def fn():
                        yield 1
                        return 5
                """),
                self.create_test_target(main, """
                    def fn():
                        yield 1
                        exc = StopIteration()
                        exc.value = 5
                        raise exc
                """))
    return Test