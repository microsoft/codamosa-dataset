

# Generated at 2022-06-18 00:19:28.154659
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:19:39.862677
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_lineno
    from ..utils.test_utils import assert_equal_col_offset
    from ..utils.test_utils import assert_equal_end_lineno
    from ..utils.test_utils import assert_equal_end_col_offset
    from ..utils.test_utils import assert_equal_ctx
    from ..utils.test_utils import assert_equal_type_comment
    from ..utils.test_utils import assert_equal_decorator_list
    from ..utils.test_utils import assert_equal_returns

# Generated at 2022-06-18 00:19:45.427919
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_lineno
    from ..utils.test_utils import assert_equal_col_offset

    # Test 1

# Generated at 2022-06-18 00:19:51.486004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:19:59.178457
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:20:10.298812
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast_tree = transformer.visit(ast_tree)
    assert_equal_ast(new_ast_tree, get_ast(expected))
    assert_equal_source(new_ast_tree, expected)

    source = """
    def fn():
        return 5
    """

# Generated at 2022-06-18 00:20:14.540681
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_asts, dump_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_asts(expected, dump_ast(new_tree))



# Generated at 2022-06-18 00:20:25.023945
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert_tree_changed(transformer)
    assert_equal_ast(new_tree, ast.parse(expected_code))

# Generated at 2022-06-18 00:20:29.806541
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:20:34.182537
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, ast.parse(expected))
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:20:45.835868
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = get_ast(expected_code)

    transformer = ReturnFromGeneratorTransformer()
    ast_ = get_ast(code)
    transformer.visit(ast_)

    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:20:53.544729
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import get_ast_source

    source = """
    def fn():
        yield 1
        return 5
    """

    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = source_to_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert get_ast_source(node) == expected_source

# Generated at 2022-06-18 00:20:59.028308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)

# Generated at 2022-06-18 00:21:05.786650
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)

# Generated at 2022-06-18 00:21:11.079164
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:21:20.172716
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.source_helpers import source_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = source_to_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-18 00:21:26.978515
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    def fn():
        yield 1
        return 5
    ''')

    expected_tree = parse_ast_tree('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert_equal_ast(new_tree, expected_tree)

# Generated at 2022-06-18 00:21:34.344265
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_ast_for_snippet
    from ..utils.test_utils import get_ast_of_snippet

    snippet = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_snippet = generate_ast_for_snippet(snippet)
    ast_expected = generate_ast_for_snippet(expected)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_snippet)
    assert_equal_ast(ast_snippet, ast_expected)


# Generated at 2022-06-18 00:21:42.594884
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_ast(ast_tree, expected)

# Generated at 2022-06-18 00:21:45.295350
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-18 00:22:00.909455
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_code_equals
    from ..utils.test_utils import get_ast_from_code

    code = """
    def fn():
        yield 1
        return 5
    """

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = get_ast_from_code(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_transformed_code_equals(ast_tree, expected_code)

# Generated at 2022-06-18 00:22:03.043496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.compare_ast import compare_ast


# Generated at 2022-06-18 00:22:10.117667
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare_ast import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, expected)



# Generated at 2022-06-18 00:22:13.888997
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast


# Generated at 2022-06-18 00:22:22.888349
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert_source_equal(expected, new_node)



# Generated at 2022-06-18 00:22:31.322401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_function(a, b):
        yield a
        return b

    node = ast.parse(inspect.getsource(test_function))
    node = node.body[0]

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)

    assert transformer._tree_changed is True
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[1], ast.Return)
    assert node.body[1].value is None



# Generated at 2022-06-18 00:22:37.961755
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:22:44.870765
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    module = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(module)
    assert_equal_source(expected, module)



# Generated at 2022-06-18 00:22:52.346212
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception

    # Test for function with generator return

# Generated at 2022-06-18 00:23:00.466123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = parse_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_source(ast_tree, expected)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    ast_tree = parse_to_ast(source)
    transformer = ReturnFromGeneratorTrans

# Generated at 2022-06-18 00:23:26.421401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_lineno
    from ..utils.test_utils import assert_equal_col_offset
    from ..utils.test_utils import assert_equal_end_lineno
    from ..utils.test_utils import assert_equal_end_col_offset
    from ..utils.test_utils import assert_equal_field
    from ..utils.test_utils import assert_equal_fields
    from ..utils.test_utils import assert_equal_attr
    from ..utils.test_utils import assert_equal_attrs

# Generated at 2022-06-18 00:23:37.781286
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_not_equal
    from ..utils.test_utils import generate_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_source_equal(generate_source(tree), expected)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-18 00:23:47.038967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = get_ast(expected_source)

    transformer = ReturnFromGeneratorTransformer()
    ast_ = get_ast(source)
    transformer.visit(ast_)
    assert_equal_ast(ast_, expected_ast)
    assert_equal_source(ast_, expected_source)

    source = """
    def fn():
        yield 1
        return 5
    """


# Generated at 2022-06-18 00:23:49.167342
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body


# Generated at 2022-06-18 00:23:57.480232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_source

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source(tree, expected)



# Generated at 2022-06-18 00:24:03.918325
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:24:11.776702
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    node = get_ast(code)
    transformer.visit(node)
    assert_code_equal(expected_code, node)

# Generated at 2022-06-18 00:24:23.766513
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_snippet
    from ..utils.test_utils import get_source_from_ast

    source = get_source_from_snippet(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected = get_source_from_snippet(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    ast_ = get_ast_from_source(source)
    ast_ = ReturnFromGeneratorTransformer

# Generated at 2022-06-18 00:24:35.390484
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)

    source

# Generated at 2022-06-18 00:24:42.173044
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    expected_tree = get_func_ast(expected)
    assert_equal_ast(ast_tree, expected_tree)



# Generated at 2022-06-18 00:25:43.192297
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def_ast

    def test(fn):
        assert_equal_source(ReturnFromGeneratorTransformer().visit(generate_function_def_ast(fn)), fn)

    test('''
        def fn():
            yield 1
            return 5
    ''')

    test('''
        def fn():
            yield 1
            return
    ''')

    test('''
        def fn():
            yield 1
            return 5
            return 6
    ''')

    test('''
        def fn():
            yield 1
            if True:
                return 5
    ''')


# Generated at 2022-06-18 00:25:52.108657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_to_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:26:02.637401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    # Test case 1
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(tree, ast.parse(expected))
    assert_equal_source(tree, expected)

    # Test

# Generated at 2022-06-18 00:26:08.041875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)

# Generated at 2022-06-18 00:26:20.462296
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_transformed
    from ..utils.testing import assert_node_not_transformed

    # Test case 1
    # Before:
    #   def fn():
    #       yield 1
    #       return 5
    # After:
    #   def fn():
    #       yield 1
    #       exc = StopIteration()
    #       exc.value = 5
    #       raise exc
    before = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    after = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    assert_node_transformed(ReturnFromGeneratorTransformer, before, after)

    # Test case 2
    # Before

# Generated at 2022-06-18 00:26:22.496652
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse_to_ast, ast_to_source
    from ..utils.compare_ast import compare_ast


# Generated at 2022-06-18 00:26:23.584596
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_ast


# Generated at 2022-06-18 00:26:35.011431
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            return node

    def test_function_without_return():
        source = """
        def fn():
            yield 1
        """
        tree = ast.parse(source)
        transformer = TestTransformer()
        transformer.visit(tree)
        assert_source_equal(source, tree)

    def test_function_with_return():
        source = """
        def fn():
            yield 1
            return 5
        """
        expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """


# Generated at 2022-06-18 00:26:47.079453
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.source_code import SourceCode
    from ..utils.ast_helpers import get_ast, get_source_code
    from ..utils.compare_ast import compare_ast

    source_code = SourceCode("""
    def fn():
        yield 1
        return 5
    """)

    expected_ast = get_ast(source_code)

# Generated at 2022-06-18 00:26:54.834305
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_ast_node

    source = '''
    def fn():
        yield 1
        return 5
    '''
    expected_source = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(generate_source_for_ast_node(node), expected_source)



# Generated at 2022-06-18 00:28:32.835327
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_ast(ReturnFromGeneratorTransformer, code, expected)



# Generated at 2022-06-18 00:28:37.444336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:28:43.202040
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:28:54.693140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node_from_function_def
    from ..utils.test_utils import get_node_from_snippet
    from ..utils.test_utils import get_node_from_snippet_with_imports
    from ..utils.test_utils import get_node_from_snippet_with_imports_and_decorators
    from ..utils.test_utils import get_node_from_snippet_with_imports_and_decorators_and_args

    # Test case 1
    # Test case 1.1

# Generated at 2022-06-18 00:29:00.816982
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:29:08.942128
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:29:17.625053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:29:25.557318
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_line_by_line

    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = ast.parse(expected)
    expected_code = compile(expected_ast, '', 'exec')

    ast_ = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_)