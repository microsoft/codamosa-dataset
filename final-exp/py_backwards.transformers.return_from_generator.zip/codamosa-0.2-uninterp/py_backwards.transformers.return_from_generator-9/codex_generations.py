

# Generated at 2022-06-18 00:19:27.365358
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast


# Generated at 2022-06-18 00:19:34.674739
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)



# Generated at 2022-06-18 00:19:44.875562
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    code = '''
    def fn():
        yield 1
        return 5
    '''
    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    tree = ast.parse(code)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = TestTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:19:53.664908
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast_str

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, source_to_ast(expected))
    assert source_to_ast_str(new_tree) == source_to_ast_str(expected)

# Generated at 2022-06-18 00:20:01.754827
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:20:10.541627
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    source = get_source_from_ast(ast_tree)
    assert_equal_source(source, expected)



# Generated at 2022-06-18 00:20:17.542480
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    assert_tree_not_equal(tree, expected_tree)
    assert_code_equal(tree, expected_code)
    assert_tree_equal(tree, expected_tree)



# Generated at 2022-06-18 00:20:22.685526
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal

    def test_fn():
        yield 1
        return 5

    node = ast.parse(inspect.getsource(test_fn))
    node = ReturnFromGeneratorTransformer().visit(node)
    expected = ast.parse(inspect.getsource(return_from_generator.get_function()))
    assert_node_equal(node, expected)

# Generated at 2022-06-18 00:20:29.587410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_ast_equal

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = ast.parse(expected_code)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse(code))

    assert_code_equal(code, expected_code)
    assert_ast_equal(transformer.tree, expected_ast)



# Generated at 2022-06-18 00:20:35.253344
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_source(get_source_from_ast(ast_tree), expected)


# Generated at 2022-06-18 00:20:44.203769
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:20:52.988976
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import get_ast

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = get_ast(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert_code_equal(compile(node, '<test>', 'exec'), expected_code)



# Generated at 2022-06-18 00:21:02.974008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_source
    from ..utils.snippet import snippet
    from ..utils.source_helpers import get_source_lines

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn_with_yield_from():
        yield from [1, 2, 3]
        return 5

    @snippet
    def fn_with_nested_yield():
        yield 1
        if True:
            yield 2
        return 5

    @snippet
    def fn_with_nested_yield_from():
        yield from [1, 2, 3]
        if True:
            yield from [4, 5, 6]
        return 5


# Generated at 2022-06-18 00:21:11.107150
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name

    tree = parse_ast_tree('''
    def fn():
        yield 1
        return 5
    ''')

    node = get_ast_node(tree, 'FunctionDef')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    expected_tree = parse_ast_tree('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    assert_equal_ast(tree, expected_tree)

# Generated at 2022-06-18 00:21:22.739254
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_transform

    assert_transform(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    assert_transform(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return
        """,
        """
        def fn():
            yield 1
            return
        """
    )

    assert_transform(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            return 5
        """,
        """
        def fn():
            return 5
        """
    )


# Generated at 2022-06-18 00:21:27.328859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    source = get_source(ReturnFromGeneratorTransformer)
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ReturnFromGeneratorTransformer, ast_tree)

# Generated at 2022-06-18 00:21:30.419525
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree


# Generated at 2022-06-18 00:21:35.847712
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import get_ast_source
    from ..utils.source import source_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = source_to_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert get_ast_source(node) == expected



# Generated at 2022-06-18 00:21:43.748614
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_ast(ast_tree, expected)

# Generated at 2022-06-18 00:21:51.945621
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal

    tree = ast.parse("""
    def fn():
        yield 1
        return 5
    """)

    expected_tree = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    assert_tree_equal(tree, expected_tree)



# Generated at 2022-06-18 00:22:07.133594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(ast_tree, expected)



# Generated at 2022-06-18 00:22:12.298364
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)

# Generated at 2022-06-18 00:22:18.721172
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:22:28.420940
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast_from_source

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert_source_equal(expected, node)



# Generated at 2022-06-18 00:22:33.557086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source

    source = generate_source(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected = generate_source(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:22:38.947668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_node = generate_function_def_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_node)
    assert_equal_source(ast_node, expected)



# Generated at 2022-06-18 00:22:45.878657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, expected)



# Generated at 2022-06-18 00:22:54.088134
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = get_node(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    expected_node = get_node(expected)
    assert_node_equal(node, expected_node)



# Generated at 2022-06-18 00:22:58.747540
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    module = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(module)
    assert_code_equal(expected_code, module)

# Generated at 2022-06-18 00:23:07.594006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:23:26.633893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:23:34.877195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = '''
        def fn():
            yield 1
            return 5
    '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    node = get_ast(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:23:41.120197
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)

# Generated at 2022-06-18 00:23:48.857552
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_equal_ast(ast_tree, new_ast)
    assert_equal_source(expected_source, new_ast)



# Generated at 2022-06-18 00:23:59.902544
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import module_to_source
    import astor

    class Test(BaseNodeTransformerTest):
        target_transformer = ReturnFromGeneratorTransformer
        function_def = """
        def fn():
            yield 1
            return 5
        """
        expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    Test.test_visit_FunctionDef()

# Generated at 2022-06-18 00:24:06.361207
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:24:14.296663
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_snippet
    from ..utils.test_utils import get_source_from_ast

    source = get_source_from_snippet(test_ReturnFromGeneratorTransformer_visit_FunctionDef)
    expected_source = get_source_from_snippet(test_ReturnFromGeneratorTransformer_visit_FunctionDef, 1)
    ast_tree = get_ast_from_source(source)
    expected_ast_tree = get_ast_from_source(expected_source)
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-18 00:24:25.077859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(expected, tree)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
   

# Generated at 2022-06-18 00:24:32.640005
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:24:37.327830
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func
    from ..utils.test_utils import get_func_ast


# Generated at 2022-06-18 00:25:12.040935
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:25:17.805088
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:25:29.158591
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_equal(new_tree, get_ast(expected))
    assert_code_equal(new_tree, expected)

    code = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-18 00:25:41.044328
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    # Test 1
    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = parse_ast(expected_source)
    ast_ = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_)
    assert_equal_ast(ast_, expected_ast)
    assert_equal_source(ast_, expected_source)
   

# Generated at 2022-06-18 00:25:46.676104
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:25:58.143070
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)
    transformer = TestTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected_tree)

# Generated at 2022-06-18 00:26:05.036102
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import parse_ast

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = parse_ast(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_code_equal(node, expected_code)



# Generated at 2022-06-18 00:26:10.069507
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:26:20.736447
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = TestTransformer().visit(tree)
    assert_source_equal(tree, expected)

# Generated at 2022-06-18 00:26:28.164435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import parse_ast

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_tree = parse_ast(expected_code)
    tree = parse_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_tree_equal(tree, expected_tree)
    assert_code_equal(tree, expected_code)
    assert transformer._tree_changed


# Generated at 2022-06-18 00:27:50.478542
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:27:58.198286
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)



# Generated at 2022-06-18 00:28:07.604252
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = get_ast(expected_code)
    ast_ = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_)
    assert_equal_ast(expected_ast, new_ast)
    assert_equal_code(expected_code, new_ast)

# Generated at 2022-06-18 00:28:15.423336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:28:22.808246
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_ = get_ast(source)
    ast_ = ReturnFromGeneratorTransformer().visit(ast_)
    assert_equal_ast(ast_, expected)
    assert_equal_source(ast_, expected)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-18 00:28:26.834837
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:28:28.654379
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code


# Generated at 2022-06-18 00:28:37.339446
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(ast_tree, expected)

# Generated at 2022-06-18 00:28:42.985053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    def fn():
        yield 1
        return 5
    ''')

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert_equal_source('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''', tree)

# Generated at 2022-06-18 00:28:54.542836
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node_from_snippet
    from ..utils.test_utils import get_node_from_func
    from ..utils.test_utils import get_node_from_func_source

    def fn():
        yield 1
        return 5

    node = get_node_from_func(fn)
    node = ReturnFromGeneratorTransformer().visit(node)
    expected = get_node_from_func_source(fn)
    assert_node_equal(node, expected)

    def fn():
        yield 1
        return 5

    node = get_node_from_func(fn)
    node = ReturnFromGeneratorTransformer().visit(node)
    expected = get_node_from_func_source(fn)