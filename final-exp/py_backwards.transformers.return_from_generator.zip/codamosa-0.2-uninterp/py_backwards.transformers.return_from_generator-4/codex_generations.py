

# Generated at 2022-06-18 00:19:41.571084
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:19:48.060544
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = source_to_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert astor.to_source(ast_tree) == expected



# Generated at 2022-06-18 00:19:49.705917
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:19:58.253564
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:20:09.556969
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import get_ast

    source = generate_source(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected_source = generate_source(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast_tree = transformer.visit(ast_tree)

    assert_equal_source(expected_source, new_ast_tree)


# Generated at 2022-06-18 00:20:21.020962
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_ast_is_equal
    from ..utils.test_utils import get_ast_of_code
    from ..utils.test_utils import get_code_of_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast_of_code(code)
    expected_ast_tree = get_ast_of_code(expected_code)
    transformer = ReturnFromGeneratorTransformer()
    transformed_ast_tree = transformer.visit(ast_tree)

# Generated at 2022-06-18 00:20:27.908815
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(code)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:20:30.805857
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:20:33.006391
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree


# Generated at 2022-06-18 00:20:42.489224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source

    source = generate_source(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected = generate_source(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:20:53.501570
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:21:03.393152
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import snippet, let
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import print_ast

    let(source_code)
    source_code = source(
        """
        def fn():
            yield 1
            return 5
        """
    )

    let(expected_ast)
    expected_ast = get_ast(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    let(ast_)
    ast_ = get_ast(source_code)

    let(transformer)
    transformer = ReturnFromGeneratorTransformer()

    let(new_ast)

# Generated at 2022-06-18 00:21:09.708518
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:21:14.387840
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed


# Generated at 2022-06-18 00:21:20.541493
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal

    program = """
        def fn():
            yield 1
            return 5
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    assert_programs_equal(ReturnFromGeneratorTransformer, program, expected)



# Generated at 2022-06-18 00:21:27.018931
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = get_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:21:34.479064
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import parse_ast_tree

    code = """
    def fn():
        yield 1
        return 5
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(new_tree, """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)



# Generated at 2022-06-18 00:21:43.095765
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:21:51.497888
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:21:56.640371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.source import source_to_ast

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = ReturnFromGeneratorTransformer
        EXAMPLE_SOURCE = """
        def fn():
            yield 1
            return 5
        """
        EXPECTED_SOURCE = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    Test.do_test()

# Generated at 2022-06-18 00:22:09.890126
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)

# Generated at 2022-06-18 00:22:16.080962
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import transform_and_compile

    def test_case(fn):
        fn = transform_and_compile(fn, ReturnFromGeneratorTransformer)
        assert_equal_ast(fn, expected)

    def fn():
        yield 1
        return 5


# Generated at 2022-06-18 00:22:23.910189
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)



# Generated at 2022-06-18 00:22:27.557236
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:22:29.800578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:22:38.332156
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:22:44.104642
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_test
    from ..utils.test_utils import get_ast

    source = generate_source_for_test(ReturnFromGeneratorTransformer)

# Generated at 2022-06-18 00:22:52.928843
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_equals
    from ..utils.testing import get_ast_node

    node = get_ast_node('''
    def fn():
        yield 1
        return 5
    ''')

    expected = get_ast_node('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert_node_equals(result, expected)

# Generated at 2022-06-18 00:22:57.419632
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)

# Generated at 2022-06-18 00:23:03.854088
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal, assert_source_not_equal
    from ..utils.test_utils import get_ast_node, get_ast_node_with_source

    # Test case 1

# Generated at 2022-06-18 00:23:26.160994
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..utils.test_utils import assert_equal_ast
    from .base import BaseNodeTransformer


# Generated at 2022-06-18 00:23:33.828100
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_ast(ReturnFromGeneratorTransformer, code, expected)

    code = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    assert_equal_ast(ReturnFromGeneratorTransformer, code, expected)

    code = """
    def fn():
        return 5
    """
    expected = """
    def fn():
        return 5
    """
    assert_equal_ast

# Generated at 2022-06-18 00:23:41.865833
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_function_def

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    function_def = get_function_def(ast_tree)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(function_def)
    assert_equal_source(expected, ast_tree)

# Generated at 2022-06-18 00:23:49.834145
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_and_code

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_node = source_to_ast(source)
    assert isinstance(ast_node, ast.Module)
    assert len(ast_node.body) == 1
    assert isinstance(ast_node.body[0], ast.FunctionDef)

    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_node)


# Generated at 2022-06-18 00:23:59.601290
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_code_equal(expected_code, new_ast)



# Generated at 2022-06-18 00:24:04.869625
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    transformer = TestTransformer()

# Generated at 2022-06-18 00:24:13.049530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    source = """
        def fn():
            yield 1
            return 5
    """
    tree = parse_ast_tree(source)
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    expected_node = parse_ast_tree("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    assert_equal_ast(new_node, expected_node.body[0])



# Generated at 2022-06-18 00:24:22.463803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import ast_to_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = source_to_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:24:30.403783
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:24:38.165126
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import parse_ast

    node = get_node(ReturnFromGeneratorTransformer, 'test_data/return_from_generator.py', 'FunctionDef')
    expected = parse_ast('test_data/return_from_generator_expected.py')

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)

    assert_node_equal(result, expected)

# Generated at 2022-06-18 00:25:07.931928
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:25:13.114174
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:25:18.493913
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:25:29.158314
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = get_ast(expected_source)
    ast_ = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_)
    assert_equal_ast(ast_, expected_ast)
    assert_equal_source(ast_, expected_source)

# Generated at 2022-06-18 00:25:37.952982
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal, get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_source_equal(expected, new_ast)

# Generated at 2022-06-18 00:25:43.980667
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)


# Generated at 2022-06-18 00:25:52.317294
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal

    def test_fn():
        yield 1
        return 5

    expected = """
    def test_fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(inspect.getsource(test_fn))
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_node_equal(node, expected)

# Generated at 2022-06-18 00:25:56.949049
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_ast_is_equal
    from ..utils.test_utils import get_ast_of_code

    code = """
        def fn():
            yield 1
            return 5
    """

    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    ast_tree = get_ast_of_code(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_transformed_ast_is_equal(ast_tree, expected_code)

# Generated at 2022-06-18 00:26:05.076650
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source

    source = generate_source(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected = generate_source(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:26:13.466999
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.source import source_to_ast

    program = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = source_to_ast(program)
    ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_programs_equal(ast_tree, expected)

# Generated at 2022-06-18 00:27:15.590371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_node = source_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast_node = transformer.visit(ast_node)
    assert ast_to_source(new_ast_node) == expected

# Generated at 2022-06-18 00:27:22.201357
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(ast_tree, expected)



# Generated at 2022-06-18 00:27:30.817001
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        ReturnFromGeneratorTransformer,
        before='''
            def fn():
                yield 1
                return 5
        ''',
        after='''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        ''',
    )

    assert_transformed_ast(
        ReturnFromGeneratorTransformer,
        before='''
            def fn():
                yield 1
                return
        ''',
        after='''
            def fn():
                yield 1
                return
        ''',
    )


# Generated at 2022-06-18 00:27:38.612747
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:27:46.981629
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_to_ast(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)



# Generated at 2022-06-18 00:27:49.517950
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal


# Generated at 2022-06-18 00:27:53.871425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:28:01.896463
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:28:10.071583
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    def test(source, expected):
        tree = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()
        new_tree = transformer.visit(tree)
        assert_equal_source(expected, new_tree)

    test(
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    test(
        """
        def fn():
            yield 1
            return
        """,
        """
        def fn():
            yield 1
            return
        """
    )


# Generated at 2022-06-18 00:28:20.169391
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.snippet import snippet
    from ..utils.source import source

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn2():
        yield 1
        return 5

    @snippet
    def fn3():
        yield 1
        return 5

    @snippet
    def fn4():
        yield 1
        return 5

    @snippet
    def fn5():
        yield 1
        return 5

    @snippet
    def fn6():
        yield 1
        return 5

    @snippet
    def fn7():
        yield 1
        return 5

    @snippet
    def fn8():
        yield