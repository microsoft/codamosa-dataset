

# Generated at 2022-06-18 00:19:45.573161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:19:51.807556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:20:00.143435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:20:07.317665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)

# Generated at 2022-06-18 00:20:18.903137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast

    program = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_programs_equal(ReturnFromGeneratorTransformer, program, expected)

    program = """
    def fn():
        yield 1
        if True:
            return 5
    """
    expected = """
    def fn():
        yield 1
        if True:
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert_programs_equal(ReturnFromGeneratorTransformer, program, expected)


# Generated at 2022-06-18 00:20:27.848289
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import ast_to_source
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    generated = ast_to_source(new_tree)

    assert compare_ast(expected, generated)



# Generated at 2022-06-18 00:20:40.390726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal

    tree = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    expected = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_tree_equal(tree, expected)

    tree = ast.parse('''
        def fn():
            yield 1
            return
    ''')
    expected = ast.parse('''
        def fn():
            yield 1
            return
    ''')

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-18 00:20:48.869524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    def test_case(input, expected):
        node = ast.parse(input)
        transformer = ReturnFromGeneratorTransformer()
        new_node = transformer.visit(node)
        assert_equal_source(expected, new_node)

    test_case(
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    test_case(
        """
        def fn():
            yield 1
            return
        """,
        """
        def fn():
            yield 1
            return
        """
    )


# Generated at 2022-06-18 00:20:55.811195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:21:08.605433
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_equal_source(expected, new_ast)
    assert transformer.tree_changed is True

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-18 00:21:20.632992
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast_node

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_to_ast_node(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:21:29.247342
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:21:39.353257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_code_equals
    from ..utils.test_utils import get_ast_from_snippet

    snippet = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_ = get_ast_from_snippet(snippet)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_)
    assert_transformed_code_equals(ast_, expected)

# Generated at 2022-06-18 00:21:48.114582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(get_source_from_ast(ast_tree), expected)


# Generated at 2022-06-18 00:21:54.829779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:22:00.908534
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:10.673539
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_code
    from ..utils.test_utils import parse_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = parse_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(generate_code(ast_tree), expected_code)

    code = """
    def fn():
        yield 1
        return
    """
    expected_code = """
    def fn():
        yield 1
        return
    """
    ast

# Generated at 2022-06-18 00:22:12.864016
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:22:19.779167
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:26.891572
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_without_imports

    source = get_source(ReturnFromGeneratorTransformer, 'test_data/return_from_generator.py')
    expected_source = get_source_without_imports(ReturnFromGeneratorTransformer, 'test_data/return_from_generator.expected.py')

    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert_equal_source(expected_source, new_tree)

# Generated at 2022-06-18 00:22:38.999075
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = generate_function_def_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:45.914225
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = parse_to_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)

# Generated at 2022-06-18 00:22:52.291533
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:23:00.437035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_code_equal(expected, ast_tree)

    code = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    ast_tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)

# Generated at 2022-06-18 00:23:09.943479
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.source_helpers import source_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = source_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    result = ast_to_source(node)
    assert result == expected



# Generated at 2022-06-18 00:23:18.450320
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_from_ast
    from ..utils.test_utils import generate_ast_from_source
    from ..utils.test_utils import generate_ast_from_source_with_transformer

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = generate_ast_from_source(source)
    ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(generate_source_from_ast(ast_tree), expected_source)

    ast_tree = generate_ast

# Generated at 2022-06-18 00:23:28.338733
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    tree = get_ast(code)
    expected_tree = get_ast(expected_code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_node_equal(get_func_body(tree), get_func_body(expected_tree))

# Generated at 2022-06-18 00:23:29.446121
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:23:34.215117
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_source_equal(expected, node)



# Generated at 2022-06-18 00:23:43.673725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_re
    from ..utils.test_utils import assert_equal_code_with_exception_re
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg_re
    from ..utils.test_utils import assert_equal_code_with

# Generated at 2022-06-18 00:24:02.461442
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source

# Generated at 2022-06-18 00:24:09.935887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_code
    from ..utils.test_utils import generate_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = generate_ast(expected_code)
    ast_ = generate_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_)
    assert_equal_ast(generate_code(ast_), expected_code)
    assert_equal_ast(ast_, expected_ast)


# Generated at 2022-06-18 00:24:19.215190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(expected, tree)



# Generated at 2022-06-18 00:24:24.522595
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:24:36.935110
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    # Test 1
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)

    # Test 2
    source = """
    def fn():
        yield 1
        if True:
            return 5
    """

# Generated at 2022-06-18 00:24:45.983461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_equals
    from ..utils.testing import parse_ast_tree
    from ..utils.testing import get_ast_node

    tree = parse_ast_tree('''
    def fn():
        yield 1
        return 5
    ''')
    node = get_ast_node(tree, ast.FunctionDef)
    node = ReturnFromGeneratorTransformer().visit(node)

    assert_node_equals(node, '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

# Generated at 2022-06-18 00:24:57.389281
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import assert_tree_equals
    from ..utils.test_utils import assert_tree_not_equals
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import parse_source

    # Test for function with generator return
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast_tree(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_equ

# Generated at 2022-06-18 00:25:05.102771
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:25:15.511420
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)
    assert_equal_source(expected, new_tree)
    assert_tree_changed(transformer)


# Generated at 2022-06-18 00:25:22.758115
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_ast_node
    from ..utils.test_utils import generate_ast_for_source
    from ..utils.test_utils import get_ast_node_by_path

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = generate_ast_for_source(source)
    node = get_ast_node_by_path(ast_tree, ['fn'])
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    actual_source = generate_source_for_ast

# Generated at 2022-06-18 00:25:58.861154
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    expected_ast_tree = get_ast(expected_code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(ast_tree, expected_ast_tree)
    assert get_func_body(ast_tree) == get_func_body(expected_ast_tree)

# Generated at 2022-06-18 00:26:06.761074
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_lineno
    from ..utils.test_utils import assert_equal_col_offset
    from ..utils.test_utils import assert_equal_end_lineno
    from ..utils.test_utils import assert_equal_end_col_offset
    from ..utils.test_utils import assert_equal_field
    from ..utils.test_utils import assert_equal_fields
    from ..utils.test_utils import assert_equal_attr
    from ..utils.test_utils import assert_equal_attrs

# Generated at 2022-06-18 00:26:18.711321
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code

    class Test(BaseNodeTransformerTest):
        transformer = ReturnFromGeneratorTransformer

        def test_return_from_generator(self):
            code = '''
                def fn():
                    yield 1
                    return 5
            '''
            ast_ = source_to_ast(code)
            self.check_ast(ast_)

            code_ = source_to_code(ast_)
            self.check_code(code_)

        def test_return_from_generator_with_if(self):
            code = '''
                def fn():
                    yield 1
                    if True:
                        return 5
            '''
            ast_ = source_to_ast

# Generated at 2022-06-18 00:26:27.250213
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_node

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)
    assert_equal_ast(expected, tree)
    assert_equal_code(expected, tree)
    assert_equal_tree(expected, tree)
    assert_

# Generated at 2022-06-18 00:26:29.530512
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal


# Generated at 2022-06-18 00:26:38.000147
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, ast.parse(expected_source))
    assert_equal_source(new_tree, expected_source)

# Generated at 2022-06-18 00:26:47.579225
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_asts, dump_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast1 = source_to_ast(source)
    ast2 = source_to_ast(expected)
    transformer = ReturnFromGeneratorTransformer()
    ast1 = transformer.visit(ast1)
    assert compare_asts(ast1, ast2)

# Generated at 2022-06-18 00:26:54.547687
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:27:01.732930
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_tree_equal(tree, expected_tree)
    assert_code_equal(tree, expected_code)



# Generated at 2022-06-18 00:27:10.182443
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:28:07.215139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = source_to_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    node = source_to_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast_

# Generated at 2022-06-18 00:28:18.805776
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import round_trip
    from ..utils.source import source

    def test_case(code):
        node = ast.parse(code)
        node = ReturnFromGeneratorTransformer().visit(node)
        code = source(node)
        node = round_trip(node)
        node = ReturnFromGeneratorTransformer().visit(node)
        code2 = source(node)
        assert code == code2

    test_case("""
        def fn():
            yield 1
            return 5
    """)

    test_case("""
        def fn():
            yield 1
            return
    """)

    test_case("""
        def fn():
            yield 1
            return 5
            yield 2
    """)


# Generated at 2022-06-18 00:28:30.723399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = get_ast(expected_source)
    ast_ = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_)
    assert_equal_ast(ast_, expected_ast)
    assert_equal_source(ast_, expected_source)

    source = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-18 00:28:40.287955
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source

    source = get_source(ReturnFromGeneratorTransformer, '_find_generator_returns')
    expected = get_source(ReturnFromGeneratorTransformer, '_replace_return')
    ast_node = get_ast_node(source, ast.FunctionDef)
    transformer = ReturnFromGeneratorTransformer()
    actual = transformer.visit(ast_node)
    assert_equal_ast(actual, expected)

# Generated at 2022-06-18 00:28:49.107243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:28:52.256826
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_ast_equal


# Generated at 2022-06-18 00:29:00.469548
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func
    from ..utils.test_utils import get_func_ast

    def test_fn():
        def fn():
            yield 1
            return 5

    expected_fn = get_func('test_fn')

    actual_fn = get_func('test_fn', ReturnFromGeneratorTransformer)

    assert_programs_equal(expected_fn, actual_fn)

    expected_ast = get_ast(expected_fn)
    actual_ast = get_func_ast(actual_fn)

    assert_programs_equal(expected_ast, actual_ast)

# Generated at 2022-06-18 00:29:05.559726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:29:10.557978
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_transformed_ast(ReturnFromGeneratorTransformer, code, expected_code)

# Generated at 2022-06-18 00:29:15.124964
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    module = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(module)
    assert_equal_source(expected, module)

