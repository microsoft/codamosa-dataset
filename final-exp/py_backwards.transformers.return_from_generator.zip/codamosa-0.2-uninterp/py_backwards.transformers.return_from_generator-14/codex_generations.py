

# Generated at 2022-06-18 00:19:29.320742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:19:40.748300
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, expected)

    source = """
        def fn():
            yield 1
            yield 2
            return 5
    """
    expected = """
        def fn():
            yield 1
            yield 2
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_

# Generated at 2022-06-18 00:19:50.384107
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = source_to_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert ast_to_source(ast_tree) == expected

    code_tree = source_to_code(source)
    ReturnFromGenerator

# Generated at 2022-06-18 00:20:01.278026
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    actual = get_source_from_ast(ast_tree)

    assert_equal_source(expected, actual)



# Generated at 2022-06-18 00:20:06.980862
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(expected, tree)

# Generated at 2022-06-18 00:20:09.178304
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform, compare_source
    from ..utils.test_utils import assert_equal_ast


# Generated at 2022-06-18 00:20:17.254557
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:20:26.074746
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.source_repr import source_repr

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_source_equal(source_repr(tree), expected)

# Generated at 2022-06-18 00:20:33.645576
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast_tree(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(tree, expected_source)

# Generated at 2022-06-18 00:20:42.117328
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:20:53.872276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:20:59.770024
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:21:07.994913
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(expected, new_tree)



# Generated at 2022-06-18 00:21:09.363669
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast
    from ..utils.compare_ast import compare_ast


# Generated at 2022-06-18 00:21:16.899415
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:21:28.852161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn2():
        yield 1
        return

    @snippet
    def fn3():
        yield 1
        return 5
        yield 2

    @snippet
    def fn4():
        yield 1
        yield 2
        return 5

    @snippet
    def fn5():
        yield 1
        yield 2
        return

    @snippet
    def fn6():
        return 5

    @snippet
    def fn7():
        return


# Generated at 2022-06-18 00:21:39.249221
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    class TestTransformer(ReturnFromGeneratorTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.visited = []

        def visit_FunctionDef(self, node):
            self.visited.append(node)
            return super().visit_FunctionDef(node)

    tree = ast.parse("""
    def fn():
        yield 1
        return 5
    """)

    transformer = TestTransformer()
    transformer.visit(tree)

    assert transformer.visited == [tree.body[0]]



# Generated at 2022-06-18 00:21:45.136331
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:21:52.595972
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    code = """
    def fn():
        yield 1
        return 5
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_source(new_tree, """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

# Generated at 2022-06-18 00:21:58.600857
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:22:11.109511
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_ast_node

    def test_case(source, expected_source):
        node = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()
        node = transformer.visit(node)
        assert_equal_source(generate_source_for_ast_node(node), expected_source)


# Generated at 2022-06-18 00:22:22.694545
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_snippet
    from ..utils.test_utils import get_source_from_ast

    # Test for function with return in generator
    source = get_source_from_snippet(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected_source = get_source_from_snippet(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    ast_tree = get_ast_from_source

# Generated at 2022-06-18 00:22:29.173069
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_transformed_ast

    def fn():
        yield 1
        return 5

    assert_transformed_ast(
        ReturnFromGeneratorTransformer,
        fn,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )



# Generated at 2022-06-18 00:22:38.332674
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:45.439544
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    code = """
        def fn():
            yield 1
            return 5
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_source(transformer.result(), """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

# Generated at 2022-06-18 00:22:52.928896
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:58.836571
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body

    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(get_func_body(tree), get_func_body(get_ast(expected)))

# Generated at 2022-06-18 00:23:07.654280
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:23:15.874973
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_code
    from ..utils.test_utils import get_code_from_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast_from_code(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    actual_code = get_code_from_ast(ast_tree)
    assert_equal_ast(actual_code, expected_code)

# Generated at 2022-06-18 00:23:27.329650
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_program_equal
    from ..utils.test_utils import get_ast_of_snippet
    from ..utils.test_utils import get_ast_of_transformed_snippet
    from ..utils.test_utils import get_function_of_transformed_snippet

    snippet1 = """
        def fn():
            yield 1
            return 5
    """
    expected1 = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert_program_equal(expected1, get_ast_of_transformed_snippet(snippet1, ReturnFromGeneratorTransformer))

    snippet2 = """
        def fn():
            yield 1
            return
    """

# Generated at 2022-06-18 00:23:43.712780
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            return node


# Generated at 2022-06-18 00:23:48.437855
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)

# Generated at 2022-06-18 00:23:53.137474
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast_tree(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected_source, tree)



# Generated at 2022-06-18 00:24:02.874080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = parse_ast(expected_source)

    transformer = ReturnFromGeneratorTransformer()
    ast_ = transformer.visit(parse_ast(source))
    assert_equal_ast(ast_, expected_ast)
    assert_equal_source(ast_, expected_source)



# Generated at 2022-06-18 00:24:12.955009
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source

# Generated at 2022-06-18 00:24:22.776283
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_equal_source(expected, new_ast)



# Generated at 2022-06-18 00:24:35.047887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body

    # Test case 1
    code = '''
        def fn():
            yield 1
            return 5
    '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    ast_tree = get_ast(code)
    func_body = get_func_body(ast_tree)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(func_body)
    assert_equal_ast(func_body, expected)

    # Test case 2

# Generated at 2022-06-18 00:24:42.838039
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)

    source

# Generated at 2022-06-18 00:24:45.172259
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:24:53.340005
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.ast_builder import build_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = build_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:25:26.497849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:25:30.734195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(expected, tree)

# Generated at 2022-06-18 00:25:41.986404
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_re
    from ..utils.test_utils import assert_equal_code_with_exception_re
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg_re

# Generated at 2022-06-18 00:25:43.462256
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:25:55.806561
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_code_from_ast
    from ..utils.test_utils import generate_ast_from_code
    from ..utils.test_utils import generate_code_from_snippet
    from ..utils.test_utils import generate_ast_from_snippet
    from ..utils.test_utils import generate_ast_from_snippet_with_target

    # Test case 1
    code = generate_code_from_snippet(
        """
        def fn():
            yield 1
            return 5
        """
    )
    ast_tree = generate_ast_from_code(code)
    ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    expected_code = generate_code_from_

# Generated at 2022-06-18 00:26:02.262372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:26:08.105856
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:26:20.499451
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = TestTransformer().visit(tree)
    assert_source_equal(tree, expected)


# Generated at 2022-06-18 00:26:25.897190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:26:32.612595
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:27:39.247080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func

    program = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast1 = get_ast(program)
    ast2 = get_ast(expected)
    fn = get_func(ast1, 'fn')

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(fn)

    assert_programs_equal(ast1, ast2)

# Generated at 2022-06-18 00:27:49.105538
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_ast
    from ..utils.test_utils import get_func_source
    from ..utils.test_utils import get_func_source_after_transformation

    # Test 1
    source = get_func_source('def fn():\n    yield 1\n    return 5')
    expected_source = get_func_source_after_transformation('def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc')
    expected_ast = get_func_ast(expected_source)
    ast_ = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer

# Generated at 2022-06-18 00:27:55.499637
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    module = parse_ast(code)
    ReturnFromGeneratorTransformer().visit(module)
    assert_equal_ast(module, expected_code)

    code = """
        def fn():
            yield 1
            if True:
                return 5
    """
    expected_code = """
        def fn():
            yield 1
            if True:
                exc = StopIteration()
                exc.value = 5
                raise exc
    """
    module = parse_

# Generated at 2022-06-18 00:28:05.146437
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_ast(ast_tree, expected)
    assert_equal_source(ast_tree, expected)

# Generated at 2022-06-18 00:28:10.005240
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)



# Generated at 2022-06-18 00:28:20.099801
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast
    from ..utils.test_utils import get_source_from_snippet

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast_from_source(source)
    expected_ast = get_ast_from_source(expected)
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-18 00:28:22.905304
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def_ast


# Generated at 2022-06-18 00:28:30.656554
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_equal_source(expected, new_ast)



# Generated at 2022-06-18 00:28:38.525707
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(expected_code, tree)



# Generated at 2022-06-18 00:28:40.493100
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
