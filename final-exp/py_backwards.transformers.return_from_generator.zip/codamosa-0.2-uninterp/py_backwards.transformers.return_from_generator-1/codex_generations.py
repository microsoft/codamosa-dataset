

# Generated at 2022-06-18 00:19:39.542877
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)


# Generated at 2022-06-18 00:19:49.156571
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(expected, tree)

    source = """
    def fn():
        yield 1
        return 5
        yield 2
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        yield 2
    """
    tree = parse_

# Generated at 2022-06-18 00:19:53.052337
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_test

    source = generate_source_for_test(ReturnFromGeneratorTransformer)

# Generated at 2022-06-18 00:20:02.981808
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func

    program = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast1 = get_ast(program)
    ast2 = get_ast(expected)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast1)

    assert_programs_equal(get_func(ast1, 'fn'), get_func(ast2, 'fn'))

# Generated at 2022-06-18 00:20:09.929565
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fake import FakeFile
    from ..utils.source import source_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = source_to_ast(source)
    file_ = FakeFile.from_ast(ast_tree)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert file_.dumps() == expected

# Generated at 2022-06-18 00:20:12.270214
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:20:16.169181
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source

    source = generate_source(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected = generate_source(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:20:26.323821
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import assert_equal_source

    def test_case(input_src, expected_src):
        @transform_and_compare(ReturnFromGeneratorTransformer, input_src, expected_src)
        def test_fn(input_src, expected_src):
            assert_equal_source(input_src, expected_src)

    test_case(
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )


# Generated at 2022-06-18 00:20:33.555710
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:20:42.044972
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:20:49.437766
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body_ast
    from ..utils.test_utils import get_func_body_source


# Generated at 2022-06-18 00:20:58.956892
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = TestTransformer().visit(tree)
    assert_source_equal(tree, expected)


# Generated at 2022-06-18 00:21:05.775783
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_transformed

    def fn():
        yield 1
        return 5

    def fn_expected():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    assert_node_transformed(
        ReturnFromGeneratorTransformer,
        fn, fn_expected,
        '''
        def fn():
            yield 1
            return 5
        '''
    )



# Generated at 2022-06-18 00:21:11.050756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:21:17.279584
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:21:24.626035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_asts, dump_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast1 = source_to_ast(source)
    ast2 = source_to_ast(expected)

    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast1)

    assert compare_asts(new_ast, ast2)

# Generated at 2022-06-18 00:21:30.152441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:21:35.557918
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    tree = TestTransformer().visit(tree)
    assert_source_equal(expected, tree)



# Generated at 2022-06-18 00:21:46.491703
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_compare import compare_asts
    from ..utils.ast_helpers import ast_from_str
    from ..utils.snippet import snippet
    from ..utils.test_helpers import assert_equal_ast

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn_expected():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    fn_ast = ast_from_str(fn)
    fn_expected_ast = ast_from_str(fn_expected)
    fn_ast_transformed = ReturnFromGeneratorTransformer().visit(fn_ast)

    assert_equal_ast(fn_ast_transformed, fn_expected_ast)

# Generated at 2022-06-18 00:21:50.164947
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source


# Generated at 2022-06-18 00:22:01.722045
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:08.781697
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast

    source = '''
        def fn():
            yield 1
            return 5
    '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    module = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(module)
    assert_equal_source(expected, module)



# Generated at 2022-06-18 00:22:12.995479
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_code_equals
    from ..utils.test_utils import assert_transformed_tree_equals


# Generated at 2022-06-18 00:22:24.556428
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast

# Generated at 2022-06-18 00:22:34.308737
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, expected)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_

# Generated at 2022-06-18 00:22:45.441514
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_lineno
    from ..utils.test_utils import assert_equal_col_offset
    from ..utils.test_utils import assert_equal_end_lineno
    from ..utils.test_utils import assert_equal_end_col_offset
    from ..utils.test_utils import assert_equal_ctx
    from ..utils.test_utils import assert_equal_type_comment
    from ..utils.test_utils import assert_equal_returns
    from ..utils.test_utils import assert_equal_decorator_list

# Generated at 2022-06-18 00:22:53.999768
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_source(ast_tree, expected)


# Generated at 2022-06-18 00:22:58.145631
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:23:09.379330
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_from_snippet

    node = get_ast_node(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected_node = get_ast_node_from_snippet(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert_node_equal(node, expected_node)

# Generated at 2022-06-18 00:23:20.373151
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.snippet import snippet
    from ..utils.source_helpers import source_to_ast

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn2():
        yield 1
        return

    @snippet
    def fn3():
        return 5

    @snippet
    def fn4():
        yield 1
        yield 2
        return 5

    @snippet
    def fn5():
        yield 1
        yield 2
        return

    @snippet
    def fn6():
        yield 1
        yield 2

    @snippet
    def fn7():
        yield 1
        return 5
        yield 2



# Generated at 2022-06-18 00:23:41.545184
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

# Generated at 2022-06-18 00:23:46.965449
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)



# Generated at 2022-06-18 00:23:49.184201
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:23:55.053554
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast


# Generated at 2022-06-18 00:24:05.038333
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = parse_ast(expected_source)

    transformer = ReturnFromGeneratorTransformer()
    ast_ = parse_ast(source)
    transformer.visit(ast_)

    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:24:11.704066
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:24:23.730918
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast
    from ..utils.test_utils import get_source_from_snippet

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)

# Generated at 2022-06-18 00:24:32.402493
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(expected, tree)



# Generated at 2022-06-18 00:24:39.525486
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:24:48.094183
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = source_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert compare_ast(new_ast, expected)



# Generated at 2022-06-18 00:25:20.162607
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast_tree = transformer.visit(ast_tree)
    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:25:29.014594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    code = """
    def fn():
        yield 1
        return 5
    """
    tree = parse_ast_tree(code)
    node = tree.body[0]

    ReturnFromGeneratorTransformer().visit(node)

    assert_equal_source(
        node,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

# Generated at 2022-06-18 00:25:37.793251
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)



# Generated at 2022-06-18 00:25:46.129967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = source_to_ast(source)
    new_ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    assert compare_ast(new_ast_tree, source_to_ast(expected))
    assert compare_source(new_ast_tree, expected)

# Generated at 2022-06-18 00:25:54.877708
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    src = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(src)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:25:57.965777
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:26:07.431691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_source_after_transformation

    # Test 1
    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source_after_transformation(
        ReturnFromGeneratorTransformer, code, expected_code)

    # Test 2
    code = """
    def fn():
        yield 1
        return
    """
    expected_code = """
    def fn():
        yield 1
        return
    """
    assert_

# Generated at 2022-06-18 00:26:12.440698
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:26:17.663374
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet

    snippet = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_snippet = get_ast_from_snippet(snippet)
    ast_expected = get_ast_from_snippet(expected)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_snippet)
    assert_equal_ast(ast_snippet, ast_expected)


# Generated at 2022-06-18 00:26:25.683004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = ast.parse(expected_source)

    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, expected_ast)
    assert_equal_source(tree, expected_source)


# Generated at 2022-06-18 00:27:49.632937
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(expected, new_tree)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-18 00:27:57.889847
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_to_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:28:07.710295
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(tree, expected)

    source = """
    def fn():
        yield 1
        if True:
            return 5
    """
    expected = """
    def fn():
        yield 1
        if True:
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast(source)

# Generated at 2022-06-18 00:28:10.825509
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree


# Generated at 2022-06-18 00:28:20.745503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(new_tree, ast.parse(expected))
    assert_equal_source(new_tree, expected)


# Generated at 2022-06-18 00:28:26.564329
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast


# Generated at 2022-06-18 00:28:28.355759
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:28:39.208842
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.compare_ast import compare_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    ast_tree = source_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast_tree = transformer.visit(ast_tree)
    assert compare_ast(ast_tree, new_ast_tree) is False
    assert ast_to_source(new_ast_tree) == expected_source

# Generated at 2022-06-18 00:28:48.052642
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = '''
    def fn():
        yield 1
        return 5
    '''
    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_source_equal(ast_tree, expected)



# Generated at 2022-06-18 00:28:57.261920
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast
    from ..utils.ast_helpers import get_function_body
    from ..utils.ast_helpers import get_function_name

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    new_code = get_function_body(new_tree, get_function_name(tree))
    assert new_code == expected