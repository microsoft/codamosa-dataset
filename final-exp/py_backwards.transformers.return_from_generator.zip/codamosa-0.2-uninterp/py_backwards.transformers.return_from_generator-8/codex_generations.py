

# Generated at 2022-06-18 00:19:34.896388
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.source import source_to_ast

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = ReturnFromGeneratorTransformer
        EXAMPLE = """
        def fn():
            yield 1
            return 5
        """
        EXPECTED = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    Test.run_default_tests()

# Generated at 2022-06-18 00:19:39.181770
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_node


# Generated at 2022-06-18 00:19:46.152813
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import roundtrip_unparse

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(roundtrip_unparse(tree), expected)

# Generated at 2022-06-18 00:19:53.039055
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import ast_to_source
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = source_to_ast(expected_source)

    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)

    assert compare_ast(expected_ast, new_tree)
    assert ast_to_source(new_tree) == expected_source

# Generated at 2022-06-18 00:20:03.239203
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body
    from ..utils.test_utils import get_func_body_str

    program = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast1 = get_ast(program)
    ast2 = get_ast(expected)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast1)

    assert_programs_equal(ast1, ast2)



# Generated at 2022-06-18 00:20:12.200672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func
    from ..utils.test_utils import get_func_with_output

    program = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_programs_equal(ReturnFromGeneratorTransformer, program, expected)

    program = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    assert_programs_equal(ReturnFromGeneratorTransformer, program, expected)


# Generated at 2022-06-18 00:20:16.724503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:20:24.497815
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    func_body = get_func_body(ast_tree)
    ReturnFromGeneratorTransformer().visit(func_body)
    assert_equal_ast(func_body, get_ast(expected))

# Generated at 2022-06-18 00:20:30.128654
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal

    code = """
    def fn():
        yield 1
        return 5
    """

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    expected_tree = ast.parse(expected_code)
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_tree_equal(tree, expected_tree)
    assert_code_equal(code, expected_code)

# Generated at 2022-06-18 00:20:35.627458
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_snippet

    snippet_1 = """
    def fn():
        yield 1
        return 5
    """
    expected_1 = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    snippet_2 = """
    def fn():
        yield 1
        if True:
            return 5
    """

# Generated at 2022-06-18 00:20:44.959630
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.ast_builder import build_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = build_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_ast(ast_tree, expected)

# Generated at 2022-06-18 00:20:48.954006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_code_for_ast_node
    from ..utils.test_utils import generate_ast_for_code
    from ..utils.test_utils import get_ast_node_by_path


# Generated at 2022-06-18 00:20:53.487536
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:20:58.421946
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_source

    source = get_func_source(test_ReturnFromGeneratorTransformer_visit_FunctionDef)
    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_source(source, tree)

# Generated at 2022-06-18 00:21:05.245964
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = parse_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:21:10.965519
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:21:20.035346
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:21:26.258704
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:21:34.983882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_ast_for_snippet
    from ..utils.test_utils import get_ast_of_snippet
    from ..utils.test_utils import get_source_of_snippet

    snippet = """
    def fn():
        yield 1
        return 5
    """

    expected_ast = generate_ast_for_snippet(snippet)
    expected_source = get_source_of_snippet(snippet)

    ast_ = get_ast_of_snippet(snippet)
    transformer = ReturnFromGeneratorTransformer()
    ast_ = transformer.visit(ast_)

    assert_equal_ast(ast_, expected_ast)

# Generated at 2022-06-18 00:21:37.656357
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
    def fn():
        yield 1
        return 5
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    expected_tree = parse_ast_tree("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    assert_equal_ast(tree, expected_tree)

# Generated at 2022-06-18 00:21:52.596499
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast import ast_to_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_node = source_to_ast(source)
    node = ReturnFromGeneratorTransformer().visit(ast_node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-18 00:22:03.146563
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(expected, tree)
    assert_equal_source(expected, tree)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-18 00:22:10.272546
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:22:18.272274
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:22:23.420792
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(expected, tree)



# Generated at 2022-06-18 00:22:32.607215
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = ast.parse(expected_source)
    actual_ast = ast.parse(source)
    actual_ast = ReturnFromGeneratorTransformer().visit(actual_ast)
    assert_equal_ast(actual_ast, expected_ast)
    assert_equal_source(actual_ast, expected_source)

# Generated at 2022-06-18 00:22:44.275481
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef

    source = '''
        def fn():
            yield 1
            return 5
    '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    ast_tree = parse_to_ast(source)
    expected_ast = parse_to_ast(expected)
    transformer = ReturnFromGeneratorTransformer()
    assert_equal_ast(transformer.visit(ast_tree), expected_ast)

    source = '''
        def fn():
            yield 1
            return
    '''

# Generated at 2022-06-18 00:22:52.566771
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:22:57.896746
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:23:07.279655
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare_ast import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, expected)



# Generated at 2022-06-18 00:23:40.222803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast_from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_equal_source(get_source_from_ast(ast_tree), expected)

# Generated at 2022-06-18 00:23:46.517751
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_ast(node, expected)



# Generated at 2022-06-18 00:23:51.330284
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_equal_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:23:59.600536
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.source import source_to_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_ = source_to_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_)
    assert_programs_equal(new_ast, expected)

# Generated at 2022-06-18 00:24:05.553629
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert expected == ast.unparse(tree)

# Generated at 2022-06-18 00:24:12.379925
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    code = '''
        def fn():
            yield 1
            return 5
    '''
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_source(transformer.result(), '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')



# Generated at 2022-06-18 00:24:24.315101
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import ast_call, ast_name, ast_return, ast_yield
    from ..utils.source_code import SourceCode
    from ..utils.snippet import snippet

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn2():
        yield 1
        return

    @snippet
    def fn3():
        yield 1
        return 5
        yield 2

    @snippet
    def fn4():
        yield 1
        return 5
        return 6

    @snippet
    def fn5():
        yield 1
        return 5
        return

    @snippet
    def fn6():
        yield 1
        return 5
        return 6
        return 7


# Generated at 2022-06-18 00:24:36.708909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func
    from ..utils.test_utils import get_func_multi
    from ..utils.test_utils import get_func_recursive
    from ..utils.test_utils import get_func_with_kwargs
    from ..utils.test_utils import get_func_with_kwargs_and_defaults
    from ..utils.test_utils import get_func_with_kwargs_and_varargs
    from ..utils.test_utils import get_func_with_varargs
    from ..utils.test_utils import get_func_with_varargs_and_defaults
    from ..utils.test_utils import get_func_with_varargs_and_kw

# Generated at 2022-06-18 00:24:45.082515
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:24:56.743980
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def

    def test_case(source, expected):
        tree = ast.parse(source)
        ReturnFromGeneratorTransformer().visit(tree)
        assert_equal_source(expected, tree)


# Generated at 2022-06-18 00:25:39.893974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_code
    from ..utils.test_utils import generate_ast

    code = generate_code(
        """
        def fn():
            yield 1
            return 5
        """
    )
    ast_ = generate_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_)
    assert_equal_source(
        generate_code(ast_),
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

# Generated at 2022-06-18 00:25:44.661348
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast

    def fn():
        yield 1
        return 5

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_node = source_to_ast(fn)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_node)
    assert ast_node == source_to_ast(expected)

# Generated at 2022-06-18 00:25:53.402090
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:26:03.525581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = parse_ast(expected_source)

    ast_ = parse_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_)

    assert_equal_ast(new_ast, expected_ast)
    assert_equal_source(new_ast, expected_source)

# Generated at 2022-06-18 00:26:11.114261
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:26:18.617480
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(expected, ast_tree)



# Generated at 2022-06-18 00:26:24.422232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_code_equal(expected, node)



# Generated at 2022-06-18 00:26:32.872668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import roundtrip_unparse

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(roundtrip_unparse(tree), expected)



# Generated at 2022-06-18 00:26:39.213986
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node_transformed
    from ..utils.testing import assert_node_not_transformed

    assert_node_transformed(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    assert_node_transformed(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            if True:
                return 5
        """,
        """
        def fn():
            yield 1
            if True:
                exc = StopIteration()
                exc.value = 5
                raise exc
        """
    )


# Generated at 2022-06-18 00:26:49.307995
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_source_equal(expected, tree)



# Generated at 2022-06-18 00:28:22.488713
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
    def fn():
        yield 1
        return 5
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert transformer._tree_changed is True

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_tree = parse_ast_tree(expected_code)

    assert_equal_ast(new_tree, expected_tree)
    assert_equal_source(new_tree, expected_code)

# Generated at 2022-06-18 00:28:27.929824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            return node


# Generated at 2022-06-18 00:28:37.972570
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_or_raise

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = get_ast_node(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    node = get_ast_node_or_raise(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:28:43.555622
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)

# Generated at 2022-06-18 00:28:52.457588
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)



# Generated at 2022-06-18 00:28:59.361866
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_source(expected_code, new_tree)



# Generated at 2022-06-18 00:29:07.307867
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:29:18.833337
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_ast_node
    from ..utils.test_utils import generate_ast_for_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_node = generate_ast_for_source(source)
    transformed_ast_node = ReturnFromGeneratorTransformer().visit(ast_node)
    transformed_source = generate_source_for_ast_node(transformed_ast_node)
    assert_equal_source(transformed_source, expected_source)

# Generated at 2022-06-18 00:29:26.132682
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast_tree = transformer.visit(ast_tree)
    assert_tree_changed(transformer)
   