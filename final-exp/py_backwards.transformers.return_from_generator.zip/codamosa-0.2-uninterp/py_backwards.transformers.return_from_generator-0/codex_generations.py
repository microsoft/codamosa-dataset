

# Generated at 2022-06-18 00:19:40.507718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_code
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source

    source = get_source(ReturnFromGeneratorTransformer)
    tree = get_ast(source)
    node = get_node(tree, ast.FunctionDef, 'visit_FunctionDef')

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    assert_equal_code(get_code(new_node), get_source(ReturnFromGeneratorTransformer))

# Generated at 2022-06-18 00:19:49.158144
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = ast.parse(expected_code)

    node = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    assert_equal_code(expected_code, new_node)
    assert_equal_ast(expected_ast, new_node)



# Generated at 2022-06-18 00:19:57.407403
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = get_ast(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:20:03.943696
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:20:10.011866
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast)
    assert_equal_source(ast, expected)



# Generated at 2022-06-18 00:20:15.887496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ignore_ws
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    ast_tree = parse_to_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_ignore_ws(code, expected_code)
    assert_equal_ast(ast_tree, expected_code)


# Generated at 2022-06-18 00:20:23.182272
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transformed_code_equals
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_transformed_code_equals(ast_tree, expected_code)



# Generated at 2022-06-18 00:20:31.360200
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def_source
    from ..utils.test_utils import generate_function_def_ast

    def test(body, expected):
        source = generate_function_def_source(body=body)
        expected = generate_function_def_source(body=expected)
        tree = generate_function_def_ast(source)
        transformer = ReturnFromGeneratorTransformer()
        new_tree = transformer.visit(tree)
        assert_equal_source(new_tree, expected)


# Generated at 2022-06-18 00:20:42.117358
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast, ast_to_source
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (3, 2)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = source_to_ast(source)
    transformer = TestTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:20:44.575613
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import parse_ast_tree


# Generated at 2022-06-18 00:20:58.456569
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_function_def

    def test(fn):
        node = ast.parse(fn)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)
        assert_equal_source(fn, node)

    test(generate_function_def(
        'def fn():',
        '    yield 1',
        '    return 5',
    ))

    test(generate_function_def(
        'def fn():',
        '    yield 1',
        '    return',
    ))

    test(generate_function_def(
        'def fn():',
        '    yield 1',
        '    return None',
    ))


# Generated at 2022-06-18 00:21:04.981617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:21:12.293746
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source_for_ast_node
    from ..utils.test_utils import generate_ast_for_source
    from ..utils.test_utils import get_ast_node_by_path

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    root = generate_ast_for_source(source)
    node = get_ast_node_by_path(root, ['fn'])
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed is True
    assert_equal

# Generated at 2022-06-18 00:21:19.532192
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:21:28.323848
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transform
    from ..utils.test_utils import assert_transform_unchanged

    assert_transform(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    assert_transform_unchanged(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            return 5
        """
    )

    assert_transform_unchanged(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return
        """
    )


# Generated at 2022-06-18 00:21:35.202988
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    def fn():
        yield 1
        return 5
    ''')

    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_ast(tree, '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

# Generated at 2022-06-18 00:21:44.929478
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_ast = ast.parse(expected_source)

    node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)

    assert_equal_ast(node, expected_ast)
    assert_equal_source(node, expected_source)

# Generated at 2022-06-18 00:21:52.905023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)
    assert_code_equal(expected_code, new_ast)

# Generated at 2022-06-18 00:22:02.172531
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = parse_ast(expected_source)

    transformer = ReturnFromGeneratorTransformer()
    ast_ = parse_ast(source)
    ast_ = transformer.visit(ast_)
    assert_equal_ast(ast_, expected_ast)
    assert_equal_source(ast_, expected_source)



# Generated at 2022-06-18 00:22:06.644719
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:22:22.987907
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:22:30.781609
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:22:42.401296
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, let
    from ..utils.source import source
    from ..utils.ast import compare_asts

    @snippet
    def fn():
        let(x)
        x = 1
        yield x
        return x

    @snippet
    def fn_expected():
        let(x)
        x = 1
        yield x
        let(exc)
        exc = StopIteration()
        exc.value = x
        raise exc

    fn_ast = ast.parse(source(fn))
    fn_expected_ast = ast.parse(source(fn_expected))

    transformer = ReturnFromGeneratorTransformer()
    fn_ast_transformed = transformer.visit(fn_ast)


# Generated at 2022-06-18 00:22:55.198598
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_ast_for_snippet
    from ..utils.test_utils import get_ast_for_snippet
    from ..utils.test_utils import get_ast_for_snippet_with_target
    from ..utils.test_utils import get_ast_for_snippet_with_target_and_mode
    from ..utils.test_utils import get_ast_for_snippet_with_target_and_mode_and_tree_changed
    from ..utils.test_utils import get_ast_for_snippet_with_target_and_tree_changed
    from ..utils.test_utils import get_ast_for_snippet_with_tree_changed

# Generated at 2022-06-18 00:22:58.447900
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import generate_function_def_ast


# Generated at 2022-06-18 00:23:00.481321
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:23:11.689573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_source = get_ast_from_source(source)
    ast_expected = get_ast_from_source(expected)
    transformer = ReturnFromGeneratorTransformer()
    assert_tree_changed(transformer, ast_source)
   

# Generated at 2022-06-18 00:23:22.701524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import get_ast_from_snippet, get_ast_from_file
    from ..utils.test_utils import get_ast_from_file
    from ..utils.test_utils import get_ast_from_snippet

    snippet = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    compare_ast(transform(snippet, ReturnFromGeneratorTransformer), expected)

    snippet = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    compare_

# Generated at 2022-06-18 00:23:30.445463
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(expected, tree)

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(expected, tree)

    source

# Generated at 2022-06-18 00:23:37.126805
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_ast

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = get_ast(expected_code)

    transformer = ReturnFromGeneratorTransformer()
    actual_ast = transformer.visit(get_ast(code))

    assert_equal_ast(actual_ast, expected_ast)
    assert_equal_code(actual_ast, expected_code)


# Generated at 2022-06-18 00:24:00.507894
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.snippet import snippet

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn_expected():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    node = ast.parse(fn.get_source())
    expected = ast.parse(fn_expected.get_source())
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert_source_equal(result, expected)

# Generated at 2022-06-18 00:24:07.019862
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    ast_node = source_to_ast(source)
    transformer.visit(ast_node)
    result = ast_to_source(ast_node)
    assert result == expected

# Generated at 2022-06-18 00:24:14.669438
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new_tree, expected)

    source = """
        def fn():
            yield 1
            return
    """
    expected = """
        def fn():
            yield 1
            return
    """
    tree = source_to_ast(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_

# Generated at 2022-06-18 00:24:23.075092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:24:28.352692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet_to_ast
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_source = source_to_ast(source)
    ast_expected = snippet_to_ast(expected)
    transformer = ReturnFromGeneratorTransformer()
    actual = transformer.visit(ast_source)
    assert compare_ast(actual, ast_expected) is True
    assert transformer._tree_changed is True



# Generated at 2022-06-18 00:24:33.290195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_ast(ast_tree, expected)



# Generated at 2022-06-18 00:24:41.982127
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(expected, tree)

    source = """
    def fn():
        return 5
    """
    expected = """
    def fn():
        return 5
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(expected, tree)


# Generated at 2022-06-18 00:24:49.491418
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert_source_equal(expected, ast_tree)

# Generated at 2022-06-18 00:24:56.820748
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(expected, node)



# Generated at 2022-06-18 00:25:03.123452
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert_source(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-18 00:25:37.953115
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:25:45.981415
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    expected_ast = get_ast(expected_source)
    actual_ast = get_ast(source, ReturnFromGeneratorTransformer)

    assert_equal_ast(expected_ast, actual_ast)
    assert_equal_source(expected_source, actual_ast)



# Generated at 2022-06-18 00:25:55.517898
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from ..utils.source import source_to_function

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    fn = source_to_function(source)
    expected_fn = source_to_function(expected_source)
    assert_programs_equal(transformer.visit(fn), expected_fn)

# Generated at 2022-06-18 00:26:03.527002
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast_tree(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected_code, new_tree)



# Generated at 2022-06-18 00:26:10.025357
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:26:17.831275
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:26:20.988645
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:26:28.273840
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node_at_line
    from ..utils.test_utils import get_ast_node_at_pos

    code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse_ast(code)
    node = get_ast_node_at_line(tree, 3)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected_code)


# Generated at 2022-06-18 00:26:31.752121
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:26:37.607402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal

    @snippet
    def source():
        def fn():
            yield 1
            return 5

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    tree = ast.parse(source.get_source())
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-18 00:28:10.489694
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:28:18.551266
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast_node

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_to_ast_node(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:28:30.400723
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, get_ast(expected))

    source = """
    def fn():
        yield 1
        return
    """
    expected = """
    def fn():
        yield 1
        return
    """
    tree = get_ast(source)
   

# Generated at 2022-06-18 00:28:39.162952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.ast_builder import build_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = build_ast(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:28:50.805088
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_function
    from ..utils.test_utils import get_function_from_ast

    def test_function():
        def fn():
            yield 1
            return 5

        return fn

    expected_ast = get_ast_from_snippet(return_from_generator)
    expected_ast.body[0].body.insert(0, get_ast_from_snippet('''
        def fn():
            yield 1
    ''').body[0])

    actual_ast = get_ast_from_function(test_function)
    actual_ast = ReturnFromGeneratorTransformer().visit(actual_ast)


# Generated at 2022-06-18 00:28:57.761170
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = get_ast(source)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert_equal_source(ast_tree, expected)



# Generated at 2022-06-18 00:29:03.375001
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    ast_tree = source_to_ast(source)
    ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    assert compare_ast(ast_tree, expected)

# Generated at 2022-06-18 00:29:10.222945
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse_ast(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert_equal_source(node, expected)



# Generated at 2022-06-18 00:29:19.837770
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_code import SourceCode

    source = SourceCode("""
    def fn():
        yield 1
        return 5
    """)

    expected_ast = build_ast("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    actual_ast = transformer.visit(source.ast)

    assert_equal_ast(actual_ast, expected_ast)

# Generated at 2022-06-18 00:29:26.607556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def fn():
        yield 1
        return 5

    @snippet
    def fn2():
        yield 1
        return

    @snippet
    def fn3():
        yield 1
        return 5
        yield 6

    @snippet
    def fn4():
        yield 1
        if True:
            return 5
        yield 6

    @snippet
    def fn5():
        yield 1
        if True:
            return 5
        else:
            yield 6

    @snippet
    def fn6():
        yield 1
        if True:
            yield 2